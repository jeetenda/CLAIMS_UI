import React from 'react';
import { Provider } from 'react-redux';
import { PersistGate } from 'redux-persist/integration/react';
import {store, persistor} from './SharedModules/Store/store';
import { Router } from 'react-router-dom';
import NavigationMenu from './SharedModules/Navigation/navigationMenu';
import history from './SharedModules/Navigation/history';
import { ConfirmProvider } from './SharedModules/MUIConfirm/index';
import './App.scss';



//
function App () {
  return (
    <Provider store={store}>
      <Router history={history}>
        <PersistGate persistor={persistor}>
          <ConfirmProvider>
            <NavigationMenu />
          </ConfirmProvider>
        </PersistGate>
      </Router>
    </Provider>
  );
}

export default App;
