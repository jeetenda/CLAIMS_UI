/* eslint-disable arrow-parens */
import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';

export const resetSearchBPHierarchy = () => ({
    type: actionTypes.RESETDATA,
    resetData: []
});

export const dispatchBPHierarchySearch = (response) => ({
    type: actionTypes.BENEFIT_PLAN_HIERARCHY_SEARCH,
    benefitHiearchySearchData: response
});

export const dispatchBPHierarchyCreate = (response) => ({
    type: actionTypes.BENEFIT_PLAN_HIERARCHY_CREATE,
    createStatus: response
});

export const dispatchBPHierarchyUpdate = (response) => ({
    type: actionTypes.BENEFIT_PLAN_HIERARCHY_UPDATE,
    updateStatus: response
});


// export const dispatchBPHierarchyViewDetails = (response) => ({
//     type: actionTypes.BENEFIT_PLAN_HIERARCHY_VIEW_DETAILS_TYPE,
//     benefitSearchData: response
// });

// export const dispatchDropdowns = (response) => ({
//     type: actionTypes.BENEFIT_PLAN_HIERARCHY_DROPDOWNS,
//     dropdowns: response
// })

// export const benefitPlanHierarchyDropdowns = values => dispatch => {
//     return axios.post(`${serviceEndPoint.SYSTEM_LIST_GETREFERENCEDATA_ENDPOINT}`, values)
//         .then(response => {
//             if (Object.keys(response.data.listObj).length > 0) {
//                 dispatch(dispatchDropdowns(response.data.listObj));
//             }
//         })
// }

//export const benefitPlanHierarchySearchAction = values => dispatch => {
    export const benefitPlanHierarchySearchAction = () => dispatch => {
    return axios.get(`${serviceEndPoint.BENEFIT_PLAN_HIERARCHY_SEARCH_ENDPOINT}`)
        .then(response => {
                dispatch(dispatchBPHierarchySearch(response.data));
        })
        .catch(error => {
            //dispatch(dispatchBPHierarchySearch(error.data));
        })
}

export const benefitPlanHierarchyUpdateAction = values => dispatch => {
    const body = {
        data: values
    }
    return axios.post(`${serviceEndPoint.BENEFIT_PLAN_HIERARCHY_EDIT_ENDPOINT}`, body)
    .then(response => {
        dispatch(dispatchBPHierarchyUpdate(response.data));
    })
    .catch(error => {
        dispatch(dispatchBPHierarchyUpdate(error.data));
    })
    // return dispatch(dispatchctaSearch(claimTypeAssigmentData.criteriaSearch.searchResults));
};

export const benefitPlanHierarchyCreateAction = values => dispatch => {
    const body = {
        data: values
    }
    return axios.post(`${serviceEndPoint.BENEFIT_PLAN_HIERARCHY_ADD_ENDPOINT}`, body)
    .then(response => {
        dispatch(dispatchBPHierarchyCreate(response.data));
    })
    .catch(error => {
        dispatch(dispatchBPHierarchyCreate(error.data));
    })
    // return dispatch(dispatchctaSearch(claimTypeAssigmentData.criteriaSearch.searchResults));
};