import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import Checkbox from '@material-ui/core/Checkbox';
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import DateFnsUtils from '@date-io/date-fns';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker
} from '@material-ui/pickers';
import dateFnsFormat from 'date-fns/format';
import * as BenefitPlanHierarchyConstants from '../../../SharedModules/Messages/ErrorMsgConstants';

export default function BenefitPlanHierarchyEditForm(props) {
  
  const [selectedEndDate, setSelectedEndDate] = React.useState('');
  const [selectedBeginDate, setSelectedBeginDate] = React.useState('');



  React.useEffect(() => {
    props.values.endDate !== '' ? setSelectedEndDate(props.values.endDate) : setSelectedEndDate('');
    props.values.beginDate !== '' ? setSelectedBeginDate(props.values.beginDate) : setSelectedBeginDate('');
  }, []);

  const handleBeginDateChange = date => {
    // setSelectedBeginDate(date);
    props.handleDCDtChange('beginDate', formatDate(date));
  };

  const handleEndDateChange = date => {
    // setSelectedEndDate(date);
    props.handleDCDtChange('endDate', formatDate(date));
  };

  const formatDate = (dt) => {
    if (!dt) {
      return "";
  }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  return (
    <div className="set-form-wrapper">
      
    
    <form autoComplete="off">
      <div className="form-wrapper px-0">        
        
      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <div className="mui-custom-form input-md with-select">
                          <KeyboardDatePicker
                            id="bgnDate"
                            label="Begin Date"
                            format="MM/dd/yyyy"
                            disabled={props.dateBeginValidation ? "disabled" : ""}
                            InputLabelProps={{
                              shrink: true,
                              required: true
                            }}
                            placeholder="mm/dd/yyyy"
                            onChange={handleBeginDateChange}
                            value={props.values.beginDate}
                            helperText={props.showBeginDateError ? BenefitPlanHierarchyConstants.Begin_Date_Error : 
                              //props.errors.showBeginLesEndErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error :  
                            //shwBgnDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error : 
                              props.showBgdtGTEnddtErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error : 
                              props.beginDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_BEGIN_DATE_ERROR : null}
                            error={props.showBeginDateError ? BenefitPlanHierarchyConstants.Begin_Date_Error :
                              // props.errors.showBeginLesEndErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error :
                               //shwBgnDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error : 
                               props.showBgdtGTEnddtErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error : 
                               props.beginDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_BEGIN_DATE_ERROR : null}
              
                            KeyboardButtonProps={{
                              'aria-label': 'change date',
                            }}
                          />
                        </div>
                      </MuiPickersUtilsProvider>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <div className="mui-custom-form input-md with-select">
                          <KeyboardDatePicker
                            id="endDate"
                            label="End Date"
                            format="MM/dd/yyyy"
                             maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                            disabled={props.dateEndValidation ? "disabled" : ""}
                            InputLabelProps={{
                              shrink: true,
                              required: true
                            }}
                            placeholder="mm/dd/yyyy"
                            value={props.values.endDate}
                            onChange={handleEndDateChange}
                            helperText={props.showEndDateError ? BenefitPlanHierarchyConstants.End_Date_Error : 
                              //props.errors.shwEndDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error :
                              props.endDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_END_DATE_ERROR : null}
                            error={props.showEndDateError ? BenefitPlanHierarchyConstants.End_Date_Error : 
                              //props.errors.shwEndDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error : 
                              props.endDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_END_DATE_ERROR : null}
              
                            KeyboardButtonProps={{
                              'aria-label': 'change date',
                            }}
                          />
                        </div>
                      </MuiPickersUtilsProvider>
                      {props.values.voidIndicator == "1" ? <div className="mui-custom-form input-md">
                        <label className="MuiFormLabel-root MuiInputLabel-shrink">Void:</label>
                        <RadioGroup
                          row
                          aria-label="documentBatchType"
                          name="DocumentBatchType">
                          <FormControlLabel
                            value="0"
                            id="FeeForService"
                            label="Yes"
                            control={<Radio color="primary" />}
                            checked={props.values.void === '0'}
                            onChange={props.handleChanges('void')}
                          />
                          <FormControlLabel
                            value="1"
                            control={<Radio color="primary" />}
                            label="No"
                            checked={props.values.void === '1'}
                            onChange={props.handleChanges('void')}
                          />
                        </RadioGroup>
                      </div> : <div className="mui-custom-form input-md">
                          <label className="MuiFormLabel-root MuiInputLabel-shrink">Void:</label>
                          <RadioGroup
                            row
                            aria-label="documentBatchType"
                            name="DocumentBatchType">
                            <FormControlLabel
                              value="0"
                              id="FeeForService"
                              label="Yes"
                              control={<Radio color="primary" />}
                              checked={props.values.void === '0'}
                              onChange={props.handleChanges('void')}
                            />
                            <FormControlLabel
                              value="1"
                              control={<Radio color="primary" />}
                              label="No"
                              checked={props.values.void === '1'}
                              onChange={props.handleChanges('void')}
                            />
                          </RadioGroup>
                        </div>}
                     </div>
      
      
      <div className="clearfix" />
      
    </form>
    </div>
  );
}
