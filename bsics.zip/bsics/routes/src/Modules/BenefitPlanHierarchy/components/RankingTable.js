import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
import TableComponent from '../../../SharedModules/Table/Table';

const headCells = [
  {
    id: 'lobId', numeric: false, disablePadding: true, label: 'LOB', enableHyperLink: true, fontSize: 12, width: 200
  },
  {
    id: 'bpId', numeric: false, disablePadding: false, label: 'Benefit Plan', enableHyperLink: false, fontSize: 12, width: 200
  },
  {
    id: 'rank', numeric: false, disablePadding: false, label: 'Rank', enableHyperLink: false, fontSize: 12, width: 200
  }
];

function RankingTable(props) {
  const [showTable, setShowTable] = React.useState(true);
  
  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data); 
      tData = JSON.parse(tData);     
      tData.map((each,index) => {
        each.index = index;
        each.voidDate = each.voidDate ? moment(each.voidDate).format('MM/DD/YYYY') : '';
      });    
      return tData;           
    }else{
      return [];
    }
  }

  const editRow = row => (event) => {
    props.setadderrorMessages(false)
    props.seterrorMessages(false)
    props.setShowError({})
     props.setRankingShow(true);
     //setRankingEditorAddType('Edit')

     props.setRankingFormData({
      lobCode: row.benefitPlanRankId.lobCode, 
      benefitPlanID: row.benefitPlanRankId.benefitPlanID, 
      rankSK: row.benefitPlanRankId.rankSK, 
      rank: row.rank ,
      index: row.index,
      row: row
    });
    props.setRankingResetData({
      lobCode: row.benefitPlanRankId.lobCode, 
      benefitPlanID: row.benefitPlanRankId.benefitPlanID, 
      rankSK: row.benefitPlanRankId.rankSK, 
      rank: row.rank ,
      index: row.index,
      row: row
      });

  };

  const tableComp = <TableComponent 
  headCells={headCells}  
  tableData={getTableData(props.tableData ? props.tableData : [])} onTableRowClick={editRow} 
  defaultSortColumn="dataElementCriteria" 
  selected={props.selectDeleteArray} 
  setSelected={props.setSelectDeleteArray}  multiDelete
  />;
  return (
    showTable ? tableComp : null

  );
}
export default withRouter(RankingTable);
