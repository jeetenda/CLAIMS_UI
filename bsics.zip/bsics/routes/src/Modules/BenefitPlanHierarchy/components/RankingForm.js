import { useDispatch, useSelector } from 'react-redux';
import React, { useState, useEffect } from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import * as BenefitPlanHierarchyConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Radio from '@material-ui/core/Radio';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS, getBenefitPlansByLobCode } from '../../../SharedModules/Dropdowns/actions';

export default function RankingForm(props) {
  const dispatch = useDispatch();
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
  const benefitListDropdown=(values) => dispatch(getBenefitPlansByLobCode(values));
  const benefitCodeList = useSelector(state => state.appDropDowns.benefitDropDowns); 

//   useEffect(() => {       
//     benefitListDropdown({"lobCode": props.values.lobCode});    
// }, [props.values.lobCode]);

  useEffect(() => {
    onDropdowns([Dropdowns.REV_LOB, Dropdowns.SA_BENEFIT_PLAN_ID
    ]);
    benefitListDropdown({"lobCode": 'MED'}); 

}, []);

const benefitPlanIDDM = benefitCodeList && benefitCodeList.length ? benefitCodeList.map(each => (
    <MenuItem selected key={each.benefitPlanID} value={each.benefitPlanID}>{each.benefitPlanIDAndDesc}</MenuItem>
)) : [];
   
  return (
    <>
      
      <form autoComplete="off">
        <div className="form-wrapper">
        {props.dateValidation != true && props.ediFlag == true ?
          <div className="mui-custom-form input-md">
            <TextField
              id="standard-select-lob"
              select
              label="LOB"
              disabled
              value={props.values.lobCode}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('lobCode')}
              placeholder=""
              InputLabelProps={{
                shrink: true,
                required: true
              }}
              helperText={props.errors.shwLobReqBfrErr ? BenefitPlanHierarchyConstants.LOB_ID_Error : null}
              error={props.errors.shwLobReqBfrErr ? BenefitPlanHierarchyConstants.LOB_ID_Error : null}
            >
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
                                      </MenuItem>
              {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#R_LOB_CD'].length > 0 && addDropdowns['Claims#R_LOB_CD'].map( each => (
                                        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                      ))}
              {/* <MenuItem selected key="MED-Title XIX Medicaid" value="MED">MED-Title XIX Medicaid</MenuItem> */}
            </TextField>
          </div>:
          <div className="mui-custom-form input-md">
          <TextField
            id="standard-select-lob"
            select
            label="LOB"
            
            value={props.values.lobCode}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('lobCode')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
              required: true
            }}
            helperText={props.errors.shwLobReqBfrErr ? BenefitPlanHierarchyConstants.LOB_ID_Error : null}
            error={props.errors.shwLobReqBfrErr ? BenefitPlanHierarchyConstants.LOB_ID_Error : null}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
                                    </MenuItem>
            {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#R_LOB_CD'].length > 0 && addDropdowns['Claims#R_LOB_CD'].map( each => (
                                      <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                    ))}
            {/* <MenuItem selected key="MED-Title XIX Medicaid" value="MED">MED-Title XIX Medicaid</MenuItem> */}
          </TextField>
        </div>
          
          }
        {props.dateValidation != true && props.ediFlag == true ?  <div className="mui-custom-form input-md">
            <TextField
              id="standard-select-lob"
              select
              label="Benefit Plan"
              disabled
              value={props.values.benefitPlanID}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('benefitPlanID')}
              placeholder=""
              helperText={props.errors.showBenefitPlanIdError ? BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error : props.errors.shwBenefitPlanReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR : 
                props.errors.showInvBPID ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR :
                
                null}
              error={props.errors.showBenefitPlanIdError ? BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error : props.errors.shwBenefitPlanReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR : 
                props.errors.showInvBPID ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR :
                                null}
              InputLabelProps={{
                shrink: true,
                required: true
              }}

            >
              <MenuItem value='-1'>Please Select One</MenuItem>
                                {benefitPlanIDDM}
            </TextField>
          </div>:
          <div className="mui-custom-form input-md">
          <TextField
            id="standard-select-lob"
            select
            label="Benefit Plan"
            value={props.values.benefitPlanID}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('benefitPlanID')}
            placeholder=""
            helperText={props.errors.showBenefitPlanIdError ? BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error : props.errors.shwBenefitPlanReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR : 
              props.errors.showInvBPID ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR :
              
              null}
            error={props.errors.showBenefitPlanIdError ? BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error : props.errors.shwBenefitPlanReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR : 
              props.errors.showInvBPID ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR :
                              null}
            InputLabelProps={{
              shrink: true,
              required: true
            }}

          >
            <MenuItem value='-1'>Please Select One</MenuItem>
                              {benefitPlanIDDM}
          </TextField>
        </div>
          }
          {props.dateValidation != true && props.ediFlag == true ?  <div className="mui-custom-form input-md">
          <TextField
                        id="standard-rank"
                        label="Rank"
                        disabled
                        // type="number"
                        className="inline-lable-ttl"
                        value={props.values.rank}
                        inputProps={{ maxLength: 5 }}
                        onChange={props.handleChanges('rank')}
                        placeholder=""
                        helperText={props.errors.showRankError ? BenefitPlanHierarchyConstants.Rank_Error :
                                   props.errors.showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR : 
                                   props.errors.showRankCharError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO : 
                                   props.errors.showRankZeroError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO :
                                    props.errors.showInvRank ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR :
                                  
                                   null}

                        error={props.errors.showRankError ? BenefitPlanHierarchyConstants.Rank_Error : 
                              props.errors.showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR :
                              props.errors.showRankCharError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO :
                              props.errors.showRankZeroError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO :
                              props.errors.showInvRank ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR :
                              
                              null}

                        InputLabelProps={{
                            shrink: true,
                            required: true
                        }}
                    />
           
          </div>: <div className="mui-custom-form input-md">
          <TextField
                        id="standard-rank"
                        label="Rank"
                        // type="number"
                        className="inline-lable-ttl"
                        value={props.values.rank}
                        inputProps={{ maxLength: 5 }}
                        onChange={props.handleChanges('rank')}
                        placeholder=""
                        helperText={props.errors.showRankError ? BenefitPlanHierarchyConstants.Rank_Error :
                                   props.errors.showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR : 
                                   props.errors.showRankCharError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO :
                                   props.errors.showRankZeroError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO :
                                   props.errors.showInvRank ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR :
                              
                                   null}

                        error={props.errors.showRankError ? BenefitPlanHierarchyConstants.Rank_Error : 
                              props.errors.showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR :
                              props.errors.showRankCharError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO :
                              props.errors.showRankZeroError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO :
                              props.errors.showInvRank ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR :
                  
                              null}

                        InputLabelProps={{
                            shrink: true,
                            required: true
                        }}
                    />
           
          </div>}

        </div>
      </form>
    </>
  );
}
