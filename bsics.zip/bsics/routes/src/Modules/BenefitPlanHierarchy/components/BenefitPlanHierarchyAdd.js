import React, { useState, useEffect, useRef } from "react";
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import { benefitPlanHierarchyCreateAction, benefitPlanHierarchySearchAction, resetSearchBPHierarchy } from '../actions';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import BenefitPlanHierarchyAddForm from './BenefitPlanHierarchyAddForm';
import BenefitPlanHierarchySearchTableComponent from './BenefitPlanHierarchySearchTableComponent';
import RankingTable from './RankingTable';
import RankingForm from './RankingForm';
import * as serviceEndPoint from '../../../SharedModules/services/service'
import Axios from 'axios'
import * as BenefitPlanHierarchyConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import moment from "moment";
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import NavigationPrompt from "react-router-navigation-prompt";



function BenefitPlanHierarchyAdd(props) {
  const handelPromptSet = (set) => {
    if (set)
      setPrompt(true);
  }
  let errorMessagesArray = [];
  const printRef = useRef();
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
    const [deleteRankiItem, setdeleteRankiItem] = React.useState([]);
  const [prompt, setPrompt] = useState(false);
  const [showNavigation,setShowNavigation] = useState(true);
  const [voidIndicator, setVoidIndicator] = useState('');
  
  const [showNoRecords, setShowNoRecords] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);
  const [dialogType, setDialogType] = useState('');
  const [cancelType, setCancelType] = useState(false);
  const [values, setValues] = useState({
    beginDate: '',
    endDate: ''
  });
  const [adderrorMessages, setadderrorMessages] = React.useState([]);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [rankingSuccessMessages, setRankingSuccessMessages] = React.useState([]);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [successMessage, setSuccessMessage] = useState(null);
  const [showTable, setShowTable] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [rankingShow, setRankingShow] = useState(false);
  const [formEditorAddType, setFormEditorAddType] = useState(false);
  const [editAddValues, setEditAddValues] = useState(false);
  const [rankingtableData, setRankingTableData] = useState([]);
  const [payloadData, setPayLoadData] = useState([]);
  const [rankingEditorAddType, setRankingEditorAddType] = useState('add');
  const [ShowEditForm, setShowEditForm] = React.useState(false);
  const [editRanking, setEditRanking] = React.useState(false);
  const [voidFlag, setShowVoidRecord] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [rankingFormData, setRankingFormData] = useState({
    lobCode: '-1',
    benefitPlanID: '-1',
    rank: ''
  });
  const [rankingResetData, setRankingResetData] = useState({ lobCode: '-1', benefitPlanID: '-1', rank: '' });
  const [{ showRankError,showRankCharError, showBenefitPlanIdError, showBeginDateError,
    showEndDateError, shwLobReqBfrErr,showBeginLesEndErr, shwBenefitPlanReqBfrErr, showBgdtGTEnddtErr,
    beginDtInvalidErr, endDtInvalidErr, showRankReqBfrErr, showInvRank, showInvBPID, showRankZeroError }, setShowError] = React.useState(false);

  const paylod = useSelector(state => state.benefitPlanHierarchy.payload);
  const paylodtime = useSelector(state => state.benefitPlanHierarchy.payloadtime);

  const dispatch = useDispatch();
  const onReset = () => dispatch(resetSearchBPHierarchy());
  const getAllSearch = () => dispatch(benefitPlanHierarchySearchAction());
  const onCreateBPHierarchy = searchValues => dispatch(benefitPlanHierarchyCreateAction(searchValues));
  // values change function
  const handleChanges = name => (event) => {
    setValues({ ...values, [name]: event.target.value });
    setVoidIndicator(event.target.value)
  };
  const handelEditAddAchanges = name => (event) => {
    if (event.target.type === 'checkbox') {
      setEditAddValues({ ...editAddValues, [name]: event.target.checked });
    } else {
      setEditAddValues({ ...editAddValues, [name]: event.target.value });
    }
  }

  const handleRankingChanges = name => (event) => {
    setRankingFormData({ ...rankingFormData, [name]: event.target.value });
  };

  const handelDateChange = (name, date) => {
    setEditAddValues({ ...editAddValues, [name]: date });
  }

  const handleDCDtChange = (name, date) => {
    setValues({ ...values, [name]: date });
  }
  // useEffect(() => { 
  //   let temp1 = ;
  //   temp1.map((each,index) => {
  //     each.rowIndex = index;     
  //   });  
  //   setminorsavetabledata(temp1);          
  //   setCodesAndIndTableData(temp1.filter((a)=>{return a.voidIndicator == '0'}));
  // },[]);


  const tableErrorFunction = (error) => {
    setadderrorMessages(error);
  }

  const [formEditValues, setFormEditValues] = useState({
    //voidIndicator: '0',
    beginDate: '',
    endDate: '',
    voidIndicator: '',
    lob: '',
    benefitPlan: '',
    rank: ''
  });
  const handelEditChanges = (name) => (event) => {
    if (event.target.type === 'checkbox') {
      setFormEditValues({ ...formEditValues, [name]: event.target.checked });
    } else {
      setFormEditValues({ ...formEditValues, [name]: event.target.value });
    }
  }
  const handleformCIDtChanges = (name, date) => {
    setFormEditCandI({ ...formEditValues, [name]: date });
  }

  // reset table
  const resetTable = () => {
    setShowNoRecords(false);
    setadderrorMessages([]);
    setShowError({
      // showDiagnosisError: false,
      // showdiagnosisCodeError: false,
      // showdescriptionError: false
    });
    setValues(
      {
        beginDate: '',
        endDate: ''
      }
    );
    setShowTable(false);
    onReset()
  };

  const addForm = () => {

    setShowError(false);
    setShowEditForm(false);
    setEditRanking(false);
    setShowAddForm(true);
    setRankingShow(false);
    setFormEditorAddType('add');
    setEditAddValues(
      {
        "auditUserID": null,
        "auditTimeStamp": new Date(),
        "addedAuditUserID": null,
        "addedAuditTimeStamp": new Date(),
        "versionNo": 0,
        "dbRecord": false,
        "sortColumn": null,
        "auditKeyList": [],
        "auditKeyListFiltered": false,
        "beginDate": "",
        "endDate": "",
        "auditTimeStamp1": "",
        "voidIndicator": "1",
        "bpRankDeleteList": [],
        "bpRankList": [
          {
            "auditUserID": null,
            "auditTimeStamp": new Date(),
            "addedAuditUserID": null,
            "addedAuditTimeStamp": new Date(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
            "auditKeyListFiltered": false,
            "lobId": "",
            "benefitPlan": null,
            "benefitPlanRankId": {
              "lobCode": "",
              "benefitPlanID": ""
            },
            "bpIdDesc": "",
            "bpId": "",
            "rank": "",
            "lobDesc": ""
          }
        ],
        "noteSetVO": null,
        "voidFlag": "false"
      }
    );

  }

  useEffect(() => {


    if(paylod != null && paylod.length > 0) {
      let rowData = [] ;
    let beginDate = values.beginDate;
    let endDate = values.endDate;    
        
     let filterData = paylod.filter(e =>
        
        new Date(e.beginDate).getTime() == new Date(beginDate).getTime() &&
        new Date(e.endDate).getTime() == new Date(endDate).getTime()
        )
       
    
    filterData = getTableData(filterData)
    if(filterData ){
    const majorVlaues = {
      "row": filterData[0] ? filterData[0] : "",
      "index": filterData[0] && filterData[0].index ? filterData[0].index : 0,
        "voidIndicator": filterData[0] && filterData[0].voidIndicator  ? '1' : '0',
        "beginDate": filterData[0] && filterData[0].beginDate ? filterData[0].beginDate : "",
        "endDate": filterData[0] && filterData[0].endDate ? filterData[0].endDate : ""
    }

    const rankinglist = filterData[0] && filterData[0].bpRankList[0] ? filterData[0].bpRankList[0] : "";

    const bpRankList = [rankinglist];

    const currentstate = filterData[0] ? filterData[0] : "";

    const oldState = currentstate;


    if(filterData[0] && filterData[0].beginDate){
    props.history.push({
      pathname: '/BenefitPlanHierarchyEdit',
      state: { bpRankList,majorVlaues,oldState },
      message:BenefitPlanHierarchyConstants.SUCCESSFULLY_SAVED_INFORMATION,
    }); 
  }
  }
    }

  }, [paylodtime]);

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
      });
      return tData;
    } else {
      return [];
    }
  }
  
  
  
  const addUpdateSave = () => {
    const rankingtabledataSave = rankingtableData;
    let transRankingtabledata = [];
    let shwLobReqBfrErr;
    let showBeginDateError;
    let showBeginLesEndErr;
    let showEndDateError;
    let beginDtInvalidErr;
    let endDtInvalidErr;
    let showBgdtGTEnddtErr;
    let showRankError;
    let showBenefitPlanIdError;
    setspinnerLoader(false);
    errorMessagesArray = [];
    setadderrorMessages([]);
    let reqFieldArr = [];
    // if (rankingtabledataSave == 0) {
    //   setadderrorMessages(["If a date range is entered, at least one LOB/Benefit Plan row must be entered."]);
    //   setadderrorMessages(["Begin Date is Required."]);
    //   setSuccessMessages(false)
    //   // return false;
    // }
    if( (new Date(values.beginDate) >= new Date(values.endDate)))
    {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benifit_Hie_Error)
      showBeginLesEndErr = true
    }
    if (rankingtabledataSave  == 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.LOB_ID_Error)
      shwLobReqBfrErr = true
    }
    if (rankingtabledataSave == 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Rank_Error)
      showRankError = true
    }
    if (rankingtabledataSave == 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error)
      showBenefitPlanIdError = true
    }
    if(values.beginDate == ""){
      showBeginDateError = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Begin_Date_Error)
    }
    if(values.endDate == ""){
      showEndDateError = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.End_Date_Error)
    }
    if(values.beginDate.toString() == "Invalid Date"){
      beginDtInvalidErr = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_BEGIN_DATE_ERROR)
    }
    if(values.endDate.toString() == "Invalid Date"){
      endDtInvalidErr = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_END_DATE_ERROR);
    }
    if(values.beginDate != "" && values.endDate != "" && values.beginDate.toString() != "Invalid Date" && values.endDate.toString() == "Invalid Date" && (new Date(values.beginDate) <= new Date(values.endDate) == false)){
      showBgdtGTEnddtErr = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_ENDDATE_ERROR);
    }
    

    if (errorMessagesArray.length === 0) {
      let searchCriteria = {

        "auditUserID": "TCR-E05-6495",
        "auditTimeStamp": new Date(),
        "addedAuditUserID": "",
        "addedAuditTimeStamp": new Date(),
        "versionNo": 0,
        "beginDate": values.beginDate,
        "endDate": values.endDate,
        "auditTimeStamp1": new Date(),
        "voidIndicator": "1",
        "bpRankList": rankingtabledataSave,
        "noteSetVO": null,
      }
      setspinnerLoader(true);
      Axios.post(`${serviceEndPoint.BENEFIT_PLAN_HIERARCHY_ADD_ENDPOINT}`, searchCriteria)
        .then(res => {
          setspinnerLoader(false);
         // console.log(res)
          if(res.data.data === true){
            setSuccessMessages([BenefitPlanHierarchyConstants.SUCCESSFULLY_SAVED_INFORMATION])
            dispatch(benefitPlanHierarchySearchAction())
            setShowAddForm(false)
            setadderrorMessages(false);
            setRankingSuccessMessages(false)
            setShowNavigation(false)
          }else{
            if(res.data.message == "error.Dates_Overlap"){
              setadderrorMessages([BenefitPlanHierarchyConstants.BENEFIT_PLAN_DATE_OVERLAP_ERROR]);
              setspinnerLoader(false);
              setSuccessMessages(false)
              setRankingSuccessMessages(false)
            }else{
              setadderrorMessages([BenefitPlanHierarchyConstants.BENEFIT_PLAN_SAVE_ERROR]);
              setspinnerLoader(false);
              setSuccessMessages(false)
              setRankingSuccessMessages(false)
            }                    
          }
        })
        .catch(e => {
          setspinnerLoader(false);
          setSuccessMessages(false)
          setRankingSuccessMessages(false)
        })
    }else{        
      setadderrorMessages(errorMessagesArray);
      setRankingSuccessMessages(false);
      setSuccessMessages(false)
      setShowError({
        showBeginDateError,
        showEndDateError,
        beginDtInvalidErr,
        endDtInvalidErr,
        showBgdtGTEnddtErr,
        showBeginLesEndErr,
        shwLobReqBfrErr,
        showRankError,
        showBenefitPlanIdError
      });
    }
  }
  const handelDateRankArrayOverlap = ( Rank, inputArray) => {
    if (inputArray.length > 0) {
  const result = inputArray.map(each => {
      if (each.rank == Rank) {
        return true
      } 
      return false
   
  })
  if (result.filter(e => e === true).length > 0) {
    return true
  } else {
    return false;
  }
    } else {
        return false
    }
}


const handelDateBPArrayOverlap = ( bpId, inputArray) => {
  if (inputArray.length > 0) {
const result = inputArray.map(each => {
    if (each.benefitPlanID == bpId) {
      return true
    } 
    return false
 
})
if (result.filter(e => e === true).length > 0) {
  return true
} else {
  return false;
}
  } else {
      return false
  }
}

 const saveRanking = async () => {
    errorMessagesArray = [];
    seterrorMessages(false);
    //setShowError({});
    let showRankCharError;
    let showRankError;
    let showBenefitPlanIdError;
    let shwLobReqBfrErr;
    let showInvRank;
    let showInvBPID;
    let showRankZeroError;

    let overlapArray;
    let overlapArraybp;
		const tableData = rankingtableData;

    if (rankingFormData.index>-1) {
      overlapArray = tableData.filter( e => e.rank != rankingResetData.rank  )
      overlapArraybp = tableData.filter( e => e.benefitPlanID != rankingResetData.benefitPlanID  )

   } else { overlapArray = tableData 
    overlapArraybp = tableData
  }
		const rankOverlap = await handelDateRankArrayOverlap( rankingFormData.rank, overlapArray);
    const bpOverlap = await handelDateBPArrayOverlap( rankingFormData.benefitPlanID, overlapArraybp);

    
    if (rankingFormData.lobCode  == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.LOB_ID_Error)
      shwLobReqBfrErr = true
    }
    
    if(rankingFormData.rank != '' && rankingFormData.rank != null && isNaN(rankingFormData.rank)){
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO)
      showRankCharError = true
    }
    if (rankingFormData.rank == null || rankingFormData.rank == '') {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Rank_Error)
      showRankError = true
    }
    if(rankingFormData.rank != '' && rankingFormData.rank != null && rankingFormData.rank == 0 || rankingFormData.rank < 0){
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO)
      showRankZeroError = true
    }
    if (rankingFormData.benefitPlanID == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error)
      showBenefitPlanIdError = true
    }
    //for(var i=0; i<rankingtableData.length; i++){
      // if (rankingtableData[i].rank == rankingFormData.rank) {
      //   showInvRank = true;
      //   errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR)
      // }
      // if (rankingtableData[i].bpId == rankingFormData.benefitPlanID) {
      //   showInvBPID = true
      //   errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR);
      // }
    //}

    if(rankingFormData.rank &&  rankOverlap){
      showInvRank = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR)
    
    }

    if(rankingFormData.benefitPlanID &&  bpOverlap){
      showInvBPID = true
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR);
    
    }
   
      let rankingObj =
      {
  
        "auditUserID": "TCR-E05-6495",
  
        "addedAuditUserID": "ESPRD01183445",
  
        "versionNo": 0,
  
        "lobId": rankingFormData.lobCode,
  
        "benefitPlanRankId": {
  
          "lobCode": rankingFormData.lobCode,
  
          "benefitPlanID": rankingFormData.benefitPlanID
  
        },
  
        "bpId": rankingFormData.benefitPlanID,
  
        "bpIdDesc": rankingFormData.benefitPlanID,
  
        "rank": rankingFormData.rank
  
      };
  
      if (errorMessagesArray.length === 0) {
        const table = rankingtableData;
  
       
        // if (rankingEditorAddType === 'add') {
        //   table.push(rankingObj);
        //   setRankingTableData(table);
        // } else {//edit
        //   const change = table.filter(each => each.timeStamp !== rankingFormData.timeStamp);
        //   change.push(rankingFormData);
        //   setRankingTableData(change);
        // }
        rankingFormData.index > -1 ? rankingtableData[rankingFormData.index] = rankingObj : rankingtableData.push(rankingObj);

        setRankingSuccessMessages(["Ranking Details Saved Successfully"])
        setRankingShow(false);
        setadderrorMessages(false)
        seterrorMessages(false);
        setRankingResetData({ timeStamp: '', lobCode: '-1', benefitPlanID: '-1', rank: '' });
        setRankingFormData({ timeStamp: '', lobCode: '-1', benefitPlanID: '-1', rank: '' });
      } else {
        seterrorMessages(errorMessagesArray);
        setRankingSuccessMessages(false);
        setShowError({
          showRankError,
          showRankCharError,
          showBenefitPlanIdError,
          shwLobReqBfrErr,
          showInvBPID,
          showInvRank
        });
      }
    
    
  }

  const cancel = () => {
    setShowAddForm(true);
    setCancelDialogOpen(false)
    setRankingShow(false);
    setadderrorMessages(false)
    setRankingSuccessMessages(false)
    setSuccessMessages(false)
  }

  const cancelAddPage = () => {
    setShowAddForm(false);
    setDialogOpen(false)
    setRankingShow(false);
    setadderrorMessages(false)
    setRankingSuccessMessages(false)
    setSuccessMessages(false)
  }

  const deleteRakings = () => {
    setRankingSuccessMessages([]);
    let tempDeleteRank = deleteRankiItem

    let tempBpRankList = rankingtableData
    tempDeleteRank.push(tempBpRankList[rankingFormData.index])
    tempBpRankList.splice(rankingFormData.index, 1)

    setdeleteRankiItem(tempDeleteRank)
    setRankingTableData(tempBpRankList)

    setDialogOpen(false);

  }
  const multiDelete = () => {
    setDialogOpen(false); setDialogType('');
    setRankingSuccessMessages([]);
    setadderrorMessages(false)
    seterrorMessages(false)
    setShowError({})   //setMinorSuccessMessage(false); 
     //setSuccessMessages([]);
     if (selectDeleteArray.length > 0) {
         let CI = rankingtableData;
         selectDeleteArray.map((value, index) => {
           let curIndex = CI.findIndex(i => moment(i.rank).isSame(value.rank));
           CI.splice(curIndex,1);
         });
         setRankingTableData(CI);
         setdeleteRankiItem(selectDeleteArray);
         setSelectDeleteArray([]);

    }
  }

  // on plan hierarchy code page load

  const redirectHelp = () => {
    const win = window.open("/BenefitPlanHierarchyHelp", "_blank");
  win.focus();
  }



  
  const searchURParameter = () => {
    setCancelType(true);
    props.history.push({
      pathname: '/PlanHierachy'
    })
  }


  return (

    <div>
      {spinnerLoader ? <Spinner /> : null}

      
      {errorMessages.length > 0 ? (
                    <div className="alert alert-danger custom-alert" role="alert">
                    {errorMessages.map(message => <li>{message}</li>)
                    }
                    </div>
                    ) : null
                    }
     
      {adderrorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert" role="alert">
          {adderrorMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null
      }
      {successMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {successMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null}
     

      <div className="mb-2">
				 <BreadCrumbs
					parent="Benefits"
					child1="Add Benefit Plan Hierarchy"
				 />
      </div>

      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="page-heading float-left">Add Benefit Plan Hierarchy</h1>
          <div className="float-right th-btnGroup">
              <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => addUpdateSave()} disabled={props.privileges && !props.privileges.add? 'disabled':'' }>
                  Save
                </Button>
                <Button
              title="Notes"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-notes"
            //  onClick={() => { enableAuditLog() }}
            >
              Notes
            </Button>
           
            <Button
              title="Cancel"
              variant="outlined"
              color="primary"
              className="btn btn-cancel"
              onClick={() => searchURParameter()}
            >
              Cancel
                    </Button>
            
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
              Print
              </Button>)}
              content={() => printRef.current}
            /> <Button
              title="Help"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-help"
              onClick = {redirectHelp}
            >
              Help
            </Button>

          </div>
          <div className="clearfix"></div>
        </div>
        <div className="custom-hr my-1 pb-1" />
        <div className="tab-body container-space mt-3">
        { showNavigation &&  <NavigationPrompt
        when={(crntLocation, nextLocation) => { handelPromptSet(nextLocation); return true }}
      // when={true}
      >
        {({ onConfirm, onCancel }) => (
          <Dialog
            open={prompt}
            onClose={() => { setPrompt(false); }}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            className="custom-alert-box"
          >
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                {cancelType ? "Are you sure that you want to Cancel?" :
                  (<>Unsaved changes will be lost. <br />
                     Are you sure you want to continue?</>)}
              </DialogContentText>
            </DialogContent>
            {cancelType ? (<DialogActions>
              <Button title="Ok" onClick={onConfirm} color="primary" className="btn btn-success">
                Ok
                    </Button>
              <Button title="Cancel" onClick={() => { setPrompt(false); setCancelType(false); onCancel() }} color="primary" autoFocus>
                Cancel
                    </Button>
            </DialogActions>) : (<DialogActions>
              <Button title="Stay on this page" onClick={() => { setPrompt(false); setCancelType(false); onCancel() }} color="primary" className="btn btn-transparent">
                STAY ON THIS PAGE!
                    </Button>
              <Button title="Continue" onClick={onConfirm} color="primary" className="btn btn-success" autoFocus>
                CONTINUE <i className="fa fa-arrow-right ml-1"></i>
              </Button>
            </DialogActions>)}
          </Dialog>
        )}
      </NavigationPrompt> 
}
      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
          {dialogType == "majorDelete" || dialogType == "multiDelete"
              ? "Are you sure that you want to Delete."
              : dialogType == "Cancel" 
              ? "Changes you made may not be saved." : ""}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            title="ok"
            onClick={() => {
              dialogType == "multiDelete" ? multiDelete() : 
              dialogType == "Delete"
              ? deleteRakings() :
               dialogType == "Cancel" ?
              cancelAddPage() : ""
            }}
            color="primary"
          >
            Ok
          </Button>
          <Button
            title="Cancel"
            onClick={() => setDialogOpen(false)}
            color="primary"
            autoFocus
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>              
              <div className="tab-holder pt-2">
                <div className="tab-header">
                        <h2 className="tab-heading float-left">New LOB/Benefit Plan Hierarchy</h2>
                        <div className="clearfix"></div>
                      </div>
                      {/* add form */}
                      <BenefitPlanHierarchyAddForm
                        handelDateChange={handelDateChange}
                        values={values} 
                        handleDCDtChange={handleDCDtChange}
                        errorMessages={errorMessages}
                        handleChanges = {handleChanges}
                        errors={{
                          showBeginDateError,
                          showEndDateError,
                          shwLobReqBfrErr,
                          shwBenefitPlanReqBfrErr,
                          showRankReqBfrErr,
                          showBeginLesEndErr,
                          showBgdtGTEnddtErr, beginDtInvalidErr, endDtInvalidErr,
                          showRankError,
                          showBenefitPlanIdError

                        }}

                      />
              </div>
              <div className="tab-body-bordered container-space mt-3">
              {rankingSuccessMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {rankingSuccessMessages.map(message => <li>{message}</li>)}
        </div>
      ) : null}
                <div className="tab-header my-2">
                    <h2 className="tab-heading float-left">Ranking</h2>
                      <div className="float-right th-btnGroup">
                        <div className="float-right">
                        <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => {setDialogOpen(true); setDialogType('multiDelete');}}>
                          <i className="fa fa-trash" />
                        </Button>
                        <Button
                                title="Add Ranking"
                                variant="outlined"
                                color="primary"
                                className="btn btn-secondary btn-icon-only"
                                onClick={() => {
                                  setadderrorMessages(false)
                                  seterrorMessages(false)
                                  setShowError({})
                                  setRankingShow(true);
                                  setRankingSuccessMessages([]);
                                  setRankingEditorAddType('add');
                                  setRankingResetData({ timeStamp: new Date(), lobCode: '-1', benefitPlanID: '-1', rank: '' });
                                  setRankingFormData({ timeStamp: new Date(), lobCode: '-1', benefitPlanID: '-1', rank: '' })
                                }}
                               >
                                <i className="fa fa-plus" />
								
							</Button>

                        </div>
                        <div className="clearfix"></div>
                      </div>
                    </div>

                  <div className="tab-holder">
                      <RankingTable
                        tableData={rankingtableData}
                        setRankingFormData={setRankingFormData}
                        setRankingResetData={setRankingResetData}
                        setRankingShow={setRankingShow}
                        setRankingEditorAddType={setRankingEditorAddType}
                        selectDeleteArray={selectDeleteArray}
                        setSelectDeleteArray={setSelectDeleteArray} 
                        seterrorMessages = {seterrorMessages}
                        setadderrorMessages = {setadderrorMessages}
                        setShowError = {setShowError}
                      />

                    </div>

                    {/* new ranking start */}
                    {rankingShow ? (
                      
                      <>
               
                        {/* {errorMessages.length > 0 ? (
                        <div className="alert alert-danger custom-alert" role="alert">
                          {errorMessages.map(message => <li>{message}</li>)
                          }
                        </div>
                        ) : null
                        } */}
                        <Dialog
                          open={cancelDialogOpen}
                          onClose={() => setCancelDialogOpen(false)}
                          aria-labelledby="alert-dialog-title"
                          aria-describedby="alert-dialog-description"
                          className="custom-alert-box"
                        >
                          <DialogContent>
                            <DialogContentText id="alert-dialog-description">
                              If Data has been entered &amp; not saved, it will be lost.
                                                    Select 'OK' to navigate away from the page
                                                    or 'Cancel' to return to the page to save the Data
                                      </DialogContentText>
                          </DialogContent>
                          <DialogActions>
                            <Button title="Ok" onClick={cancel} color="primary" className="btn btn-success">
                              Ok
                                      </Button>
                            <Button title="Cancel" onClick={() => setCancelDialogOpen(false)} color="primary" autoFocus>
                              Cancel
                                      </Button>
                          </DialogActions>
                        </Dialog>
                        <div className="tabs-container mt-3">
                          <div className="tab-header">
                            <h2 className="tab-heading float-left">New Ranking</h2>
                            <div className="float-right th-btnGroup">
                              <Button title ={ rankingFormData.index > -1  ? "Update" : "Add" } variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => saveRanking()}>
                              { rankingFormData.index > -1  ? "Update" : "Add" }
                </Button>
                <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => {setDialogOpen(true); setDialogType('Delete');}}> Delete
                      </Button>
                              <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => {
                                setRankingFormData(rankingResetData),
                                setadderrorMessages(false)
                                seterrorMessages(false)
                                setShowError({})
                              }}>
                                  Reset
                </Button>
                              <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => {setDialogOpen(true); setDialogType('Cancel');}} >
                                Cancel
                </Button>

                            </div>
                            <div className="clearfix"></div>
                          </div>
                          <div className="tab-body-bordered mt-2">
                          <RankingForm

                            handleChanges={handleRankingChanges}
                            values={rankingFormData}
                            errorMessages={errorMessages}
                            errors={{ shwLobReqBfrErr,
                              showRankError,showRankCharError,
                              showBenefitPlanIdError,
                              showInvRank,
                              showInvBPID,
                              showRankZeroError }}
                          />
                        </div>
                        </div>
                      </>
                    ) : null}
                    {/* new ranking end */}
              </div>
            
        </div>
        <Footer print />

      </div>

    </div>
  );
}
export default withRouter(BenefitPlanHierarchyAdd);
