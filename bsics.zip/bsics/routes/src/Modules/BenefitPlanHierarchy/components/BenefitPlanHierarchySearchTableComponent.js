import React, { useState, useEffect } from 'react';
import { withRouter } from 'react-router';
import { Button } from 'react-bootstrap';
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import { benefitPlanHierarchyUpdateAction, benefitPlanHierarchySearchAction } from '../actions';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import dateFnsFormat from 'date-fns/format';
import RadioGroup from '@material-ui/core/RadioGroup';
import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import * as BenefitPlanHierarchyConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import * as serviceEndPoint from '../../../SharedModules/services/service'
import Axios from 'axios'
import Spinner from '../../../SharedModules/Spinner/Spinner'
import RankingForm from './RankingForm';
import Checkbox from '@material-ui/core/Checkbox';

import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import * as moment from "moment";
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS, getBenefitPlansByLobCode } from '../../../SharedModules/Dropdowns/actions';
const headCells = [

  {
    id: 'beginDate', numeric: false, disablePadding: false, label: 'Begin Date', enableHyperLink: true, width: '25%'
  },
  {
    id: 'endDate', numeric: false, disablePadding: false, label: 'End Date', enableHyperLink: false, width: '25%'
  },
  {
    id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date', enableHyperLink: false, width: '25%'
  }

];



const rankingHeadCells = [
  {
    id: 'lobId', numeric: false, disablePadding: false, label: 'LOB', enableHyperLink: true,
  },
  {
    id: 'bpIdDesc', numeric: false, disablePadding: false, label: 'Benefit Plan', enableHyperLink: false
  },
  {
    id: 'rank', numeric: false, disablePadding: false, label: 'Rank', enableHyperLink: false
  }
];

function BenefitPlanHierarchySearchTableComponent(props) {
  let errorMessagesArray = [];
  const [dialogOpen, setDialogOpen] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [showTable, setShowTable] = React.useState(false);
  const [rowDetails, setrowDetails] = React.useState(false);
  const [rankingRowDetails, setrankingRowDetails] = React.useState(false);
  const [rankingShow, setRankingShow] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [rankingEditorAddType, setRankingEditorAddType] = useState('Edit');
  const dispatch = useDispatch();
  const [voidRecords, setVoidRecords] = useState([])
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
  const benefitListDropdown=(values) => dispatch(getBenefitPlansByLobCode(values));
  const benefitCodeList = useSelector(state => state.appDropDowns.benefitDropDowns); 

 
 
  const [rankingFormData, setRankingFormData] = useState({ lobCode: '-1', benefitPlanID: '-1', rank: '' });
  const [successMessage, setSuccessMessage] = useState(null);
  const [rankingResetData, setRankingResetData] = useState({ lobCode: '-1', benefitPlanID: '-1', rank: '' });

  const handleRankingChanges = name => (event) => {
      setRankingFormData({ ...rankingFormData, [name]: event.target.value });
      if(name=="lobCode")
      rankingFormData.benefitPlanRankId.lobCode=event.target.value;

      benefitListDropdown({"lobCode": rankingFormData.benefitPlanRankId.lobCode});  
    if(name == "benefitPlanID" || name == "lobCode"){
      setRankingFormData({ ...rankingFormData, "benefitPlanRankId" :{...rankingFormData.benefitPlanRankId, [name]: event.target.value }});
      console.log(rankingFormData);
      }
  };

  const handleEditRankingChanges = name => (event) => {
    setrankingRowDetails({ ...rankingRowDetails, [name]: event.target.value });
  };
  const [dateValidation, setDateValidation] = useState(false);
  const [dateBeginValidation, setBeginDateValidation] = useState(false);
  const [dateEndValidation, setEndDateValidation] = useState(false);
  const [voidIndicator, setVoidIndicator] = useState('')
  const [endingDate, setEndingDate] = useState('')
  const [beginningDate, setBeginningDate] = useState('')
  const [finalDate, setfinalDate] = useState('')
  const [voidCheck, setVoidCheck] = useState('')
  const payload = useSelector(state => state.benefitPlanHierarchy.updateStatus);

  const handleChanges = name => (event) => {
    setValues({ ...values, [name]: event.target.value });
    setVoidIndicator(event.target.value)
  };
  const [oldState, setOldState] = React.useState(false);
  const [values, setValues] = useState({ void: "1", rank: '' });
  const [valuess, setValuess] = useState({ void: "0", rank: '' });
  const [showRecords, setShowRecords] = React.useState([])
  const [voidButton, setVodiButton] = React.useState(false);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [bpRankList, setBpRankList] = React.useState([]);
  const [bpRankListTime, setbpRankListTime] = React.useState([]);
  const [majorVlaues,setMajorValues] = React.useState([]);
  const [deleteRankiItem, setdeleteRankiItem] = React.useState([]);
  const [{ showRankError,showRankCharError, showBenefitPlanIdError, showBeginDateError,
    showEndDateError, shwLobReqBfrErr, shwBenefitPlanReqBfrErr, showBgdtGTEnddtErr,
    beginDtInvalidErr, endDtInvalidErr, showRankReqBfrErr, showRankZeroError }, setShowError] = React.useState(false);
  const getAllSearch = () => dispatch(benefitPlanHierarchySearchAction());
  const [selectedEndDate, setSelectedEndDate] = React.useState('');
  const [selectedBeginDate, setSelectedBeginDate] = React.useState('');
  const getBenefitDrpDwn = (values) => dispatch(getBenefitPlansByLobCode(values));
  const benefitDrpDwn =  useSelector(state => state.appDropDowns.benefitDropDowns);
  
  React.useEffect(() => {
    props.values.endDate !== '' ? setSelectedEndDate(props.values.endDate) : setSelectedEndDate('');
    props.values.beginDate !== '' ? setSelectedBeginDate(props.values.beginDate) : setSelectedBeginDate('');
  }, []);
  React.useEffect(() => {
    onDropdowns([Dropdowns.REV_LOB, Dropdowns.SA_BENEFIT_PLAN_ID
    ]);
    
}, []);
//   React.useEffect(() => {       
//   benefitListDropdown({"lobCode": rankingFormData.benefitPlanRankId.lobCode});    
// }, [props.values.lobCode]);
const benefitPlanIDDM = benefitCodeList && benefitCodeList.length ? benefitCodeList.map(each => (
  <MenuItem selected key={each.benefitPlanID} value={each.benefitPlanID}>{each.benefitPlanIDAndDesc}</MenuItem>
)) : [];
  const handleEndDateChange = date => {
    setEndingDate(event.target.value);
    setrowDetails({ ...rowDetails, 'endDate': formatDate(date) })
    props.handleDCDtChange('endDate', formatDate(date));
  };
  const handleBeginDateChange = date => {
    setBeginningDate(event.target.value)
    setrowDetails({ ...rowDetails, 'beginDate': formatDate(date) })
    props.handleDCDtChange('beginDate', formatDate(date));
  };
 /* useEffect(() => {       
    benefitListDropdown({"lobCode": props.values.lobCode});    
}, [rankingFormData.benefitPlanRankId.lobCode]);*/

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  useEffect(() => {
    if(bpRankList != null && props.redirect){
       props.setRedirect(false);
       setspinnerLoader(false);
         if( bpRankList){
           props.history.push({
             pathname: '/BenefitPlanHierarchyEdit',
             state: { bpRankList,majorVlaues,oldState }
           });
         }
      
     }
   },[bpRankListTime]);
 


  const editRow = row => (event) => {

    // props.setShowEditForm(true);
    // props.setShowAddForm(false);
    // setShowError({});
    // props.setadderrorMessages([]);
    // setSuccessMessages(false);
    // props.setFormEditValues({
    //   "row": row,
    //   "index": row.index,
    //   "voidIndicator": row.voidDate ? '1' : '0',
    //   "beginDate": row.beginDate,
    //   "endDate": row.endDate,
    // })
    // var currentDate = moment(new Date()).format('MM/DD/YYYY')
    // if (Date.parse(row.endDate) >= Date.parse(currentDate)) {
    //   setDateValidation(true)
    // } else {
    //   setDateValidation(false)
    // }
    // if (Date.parse(row.beginDate) < Date.parse(currentDate)) {
    //   setBeginDateValidation(true)
    // } else {
    //   setBeginDateValidation(false)
    // }
    // if (Date.parse(row.endDate) < Date.parse(currentDate)) {
    //   setEndDateValidation(true)
    // } else {
    //   setEndDateValidation(false)
    // }
     setOldState(row);
     setspinnerLoader(true);
    props.setRedirect(true);
    // setRankingShow(false);
    // props.setEditRanking(false);
    // setrowDetails(row);
    setMajorValues({  
      "row": row,
       "index": row.index,
       "voidIndicator": row.voidIndicator === '1' ? '1' : '0',
       "beginDate": row.beginDate,
       "endDate": row.endDate
    })
     setBpRankList(row.bpRankList)
     setbpRankListTime( new Date())
    // benefitListDropdown({"lobCode": rankingFormData.benefitPlanRankId.lobCode});
  };

  const checkOlderDate = dateValue => {
    let currentDate = moment(new Date()).format('MM/DD/YYYY')
    if (Date.parse(dateValue) < Date.parse(currentDate)) {
      return true;
    }
    else {
      return false;
    }
  }

  const editRankingRow = row => (event) => {
    setRankingFormData(row);
    setRankingResetData({
      // "row": row,
      // "index": row.index,
      // "lobCode": rankingRowDetails.benefitPlanRankId.lobCode ? rankingRowDetails.benefitPlanRankId.lobCode : '-1',
      // "benefitPlanID": rankingRowDetails.benefitPlanRankId.benefitPlanID ? rankingRowDetails.benefitPlanRankId.benefitPlanID : '-1',
     // 'rank': row.rank
    })
    getBenefitDrpDwn({"lobCode": rankingFormData.benefitPlanRankId.lobCode});
    props.setShowEditForm(true);
    props.setEditRanking(true);
    setRankingShow(false);
    props.setShowAddForm(false);
    setSuccessMessages(false);
    setrankingRowDetails(row);
    


  };

  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      if (voidCheck == '' || voidCheck == 0) {
        setShowRecords(props.tableData.filter((a) => { return a.voidIndicator == '1' }));
        setspinnerLoader(false);
        setShowTable(true);
      } else {
        setShowRecords(props.tableData);
      }
    }
  }, [props.tableData]);

  const handleVoidCheck = (e) => {
    let temp1 = props.tableData;
    setVoidCheck(event.target.checked);
    if (event.target.checked == true) {
      event.target.checked ? setShowRecords(temp1) : setShowRecords(temp1.filter((a) => { return a.voidIndicator == '0' }));
      setVodiButton(true)
    } else if (event.target.checked == false) {
      event.target.checked ? setShowRecords(temp1) : setShowRecords(temp1.filter((a) => { return a.voidIndicator == '1' }));
      setVodiButton(false)
    }
  };

  const getFullData = (tableData) => {
    if (tableData && tableData.length) {
      let fData = JSON.stringify(tableData);
      fData = JSON.parse(fData);
      fData.map((each, index) => {
        each.index = index;
        each.voidDate = each.voidIndicator == '1' ? '' : each.auditTimeStamp1;
      });
      return fData;
    } else {
      return [];
    }
  }

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
        each.voidDate = each.voidIndicator == '1' ? '' : each.auditTimeStamp1;
      });
      return tData;
    } else {
      return [];
    }
  }



  const deleteRakings = () => {
    let tempDeleteRank = deleteRankiItem

    let tempBpRankList = bpRankList
    tempDeleteRank.push(tempBpRankList[rankingRowDetails.index])
    tempBpRankList.splice(rankingRowDetails.index, 1)

    setdeleteRankiItem(tempDeleteRank)
    setBpRankList(tempBpRankList)

    props.setEditRanking(false);
    setDialogOpen(false);

  }

  const cancelRanking = () => {
    setCancelDialogOpen(false)
    props.setEditRanking(false),
      setRankingShow(false)
    props.setadderrorMessages(false),
      props.setRankingSuccessMessages(false),
      props.setSuccessMessages(false)
  }

  const cancelRankPage = () => {
    setRankingShow(false),
      setCancelDialogOpen(false),
      props.setadderrorMessages(false),
      props.setRankingSuccessMessages(false)
    props.setSuccessMessages(false)

  }


  const cancelEditPage = () => {
    props.setShowEditForm(false),
      setRankingShow(false),
      setCancelDialogOpen(false)
    props.setSuccessMessages(false),
      props.setRankingSuccessMessages(false),
      props.setadderrorMessages(false)
    setShowError({});
  }


  const update = () => {
    let showBeginDateError;
    let showBeginLesEndErr;
    let showEndDateError;
    let beginDtInvalidErr;
    let endDtInvalidErr;
    let showBgdtGTEnddtErr;
    errorMessagesArray = [];
    if( (new Date(rowDetails.beginDate) >= new Date(rowDetails.endDate)))
    {
      showBgdtGTEnddtErr = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benifit_Hie_Error);  
      
  }
  if(rowDetails.beginDate == ""){
    showBeginDateError = true;
    errorMessagesArray.push(BenefitPlanHierarchyConstants.Begin_Date_Error)
  }
  if(rowDetails.endDate == ""){
    showEndDateError = true;
    errorMessagesArray.push(BenefitPlanHierarchyConstants.End_Date_Error)
  }
  if(rowDetails.beginDate.toString() == "Invalid Date"){
    beginDtInvalidErr = true;
    errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_BEGIN_DATE_ERROR)
  }
  if(rowDetails.endDate.toString() == "Invalid Date"){
    endDtInvalidErr = true;
    errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_END_DATE_ERROR);
  }
  else if(rowDetails.beginDate != "" && rowDetails.endDate != "" && rowDetails.beginDate.toString() != "Invalid Date" && rowDetails.endDate.toString() == "Invalid Date" 
  && (new Date(rowDetails.beginDate) <= new Date(rowDetails.endDate) == false)){
    showBgdtGTEnddtErr = true;
    errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_ENDDATE_ERROR);
  }
  if( new Date(rowDetails.beginDate) < new Date() && new Date(rowDetails.endDate) < new Date()){
    errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_DATE_OVERLAP_ERROR_PAST);
  }
    if (errorMessagesArray.length === 0) {

    let searchCriteria = [{
      "auditUserID": rowDetails.auditUserID,
      "auditTimeStamp": rowDetails.auditTimeStamp,
      "addedAuditUserID": rowDetails.addedAuditUserID,
      "addedAuditTimeStamp": rowDetails.addedAuditTimeStamp,
      "versionNo": rowDetails.versionNo,
      "dbRecord": rowDetails.dbRecord,
      "sortColumn": rowDetails.sortColumn,
      "auditKeyList": rowDetails.auditKeyList,
      "auditKeyListFiltered": rowDetails.auditKeyListFiltered,
      "beginDate": rowDetails.beginDate,
      "endDate": rowDetails.endDate,
      "auditTimeStamp1": new Date(),
      "voidIndicator": voidIndicator ? voidIndicator : rowDetails.voidIndicator,
      "bpRankDeleteList": deleteRankiItem,
      "bpRankList": bpRankList,
      "noteSetVO": rowDetails.noteSetVO,
      "lastBeginDate" : oldState.beginDate,
      "lastEndDate" : oldState.endDate,
    }]
   
    setspinnerLoader(true);
    Axios.post(`${serviceEndPoint.BENEFIT_PLAN_HIERARCHY_EDIT_ENDPOINT}`, searchCriteria)
      .then(res => {
        setspinnerLoader(false);
        if (res.data.data == true) {
          props.setSuccessMessages([BenefitPlanHierarchyConstants.SUCCESSFULLY_SAVED_INFORMATION])
          props.setShowEditForm(false);
          props.setEditRanking(false);
          props.setRankingSuccessMessages(false)
          props.setadderrorMessages(false)
          getAllSearch();
          if(rowDetails.beginDate){
            let checkOlder = checkOlderDate(rowDetails.beginDate);
            if(checkOlder){
              setBeginDateValidation(true);
            }
          }
          if(rowDetails.endDate){
            let checkOlder = checkOlderDate(rowDetails.endDate);
            if(checkOlder){
              setEndDateValidation(true);
            }
          }
        } else {
          if(res.data.message == "error.Dates_Overlap"){
            props.setadderrorMessages([BenefitPlanHierarchyConstants.BENEFIT_PLAN_DATE_OVERLAP_ERROR]);
            setspinnerLoader(false);
            setSuccessMessages(false)
            setRankingSuccessMessages(false)
            return false;
          }else{
          props.setadderrorMessages([BenefitPlanHierarchyConstants.BENEFIT_PLAN_DEFAULT_WARNING, BenefitPlanHierarchyConstants.BENEFIT_PLAN_UPDATE_ERROR])
          props.setSuccessMessages(false);
          props.setEditRanking(false);
          props.setRankingSuccessMessages(false)
          }          
        }
      })
      .catch(e => {
        setspinnerLoader(false);
        //props.setadderrorMessages([BenefitPlanHierarchyConstants.BENEFIT_PLAN_UPDATE_ERROR])
        props.setRankingSuccessMessages(false)
        props.setSuccessMessages(false)
        
      })
    }else{  
      props.setadderrorMessages(errorMessagesArray);      
      setShowError({
        showBeginDateError,
        showEndDateError,
        beginDtInvalidErr,
        endDtInvalidErr,
        showBgdtGTEnddtErr,
        showBeginLesEndErr,
        shwLobReqBfrErr,
        showRankError,
        showRankCharError,
        showBenefitPlanIdError
      });
    }
    // }

  }



  const saveRanking = () => {
    errorMessagesArray = [];
    props.setadderrorMessages([]);
    setShowError({});
    let showRankError;
    let showBenefitPlanIdError;
    let shwLobReqBfrErr;
    let showRankZeroError;
    let showRankReqBfrErr;
    let shwBenefitPlanReqBfrErr;
    if (rankingFormData.rank == null || rankingFormData.rank == '') {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Rank_Error)
      showRankError = true;
    }
    if (rankingFormData.lobCode == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.LOB_ID_Error)
      shwLobReqBfrErr = true
    }
    if (rankingFormData.benefitPlanID == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error)
      showBenefitPlanIdError = true
    }
    if (rankingFormData.rank && rankingFormData.rank == 0 || rankingFormData.rank < 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO)
      showRankZeroError = true
    }
    for (var i = 0; i < bpRankList.length; i++) {
      if (bpRankList[i].rank == rankingFormData.rank) {
        errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR);
        showRankReqBfrErr = true;
      }
      if (bpRankList[i].bpId == rankingFormData.benefitPlanID) {
        shwBenefitPlanReqBfrErr = true
        errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR);
      }
    }
    if (errorMessagesArray.length === 0) {
      const table = bpRankList;
      let rankingObj =
      {

        "auditUserID": "TCR-E05-6495",

        "addedAuditUserID": "ESPRD01183445",

        "versionNo": 0,

        "lobId": rankingFormData.lobCode,

        "benefitPlanRankId": {

          "lobCode": rankingFormData.lobCode,

          "benefitPlanID": rankingFormData.benefitPlanID

        },

        "bpIdDesc": rankingFormData.benefitPlanID,

        "bpId": rankingFormData.benefitPlanID,

        "rank": rankingFormData.rank

      };

      if (rankingEditorAddType === 'Edit') {
        rankingFormData.index > -1 ? (table[rankingFormData.index] = rankingObj) : table.push(rankingObj);
        // table.push(rankingObj);
        setBpRankList(table);
        props.setRankingSuccessMessages(["Ranking Details Saved Successfully"])
        props.setSuccessMessages(false);
        props.setadderrorMessages(errorMessagesArray);
        seterrorMessages(false);
        getAllSearch()
        setRankingShow(false);
      } else {
        const change = table.filter(each => each.timeStamp !== rankingFormData.timeStamp);
        change.push(rankingFormData);
        setBpRankList(change);
      }

    } else {
      seterrorMessages(errorMessagesArray);
      props.setSuccessMessages(false);
      setShowTable(false);
      setShowError({
        showRankError,
        showBenefitPlanIdError,
        shwLobReqBfrErr,
        showRankZeroError,
        showRankReqBfrErr,
        shwBenefitPlanReqBfrErr
      });
    }
  }


  const updateRanking = () => {
    errorMessagesArray = [];
    props.setadderrorMessages([]);
    setShowError({});
    let showRankCharError;
    let showRankError;
    let showBenefitPlanIdError;
    let shwLobReqBfrErr;
    let showRankZeroError;
    let showRankReqBfrErr;
    let shwBenefitPlanReqBfrErr;
    setShowError({
      showRankCharError: !isNaN(rankingFormData.rank)
        ? false
        : (() => {
          errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO);
          showRankCharError =true;
          })(),
    });
    if (rankingFormData.rank == null || rankingFormData.rank == '') {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Rank_Error)
      showRankError = true;
    }
    if (rankingFormData.benefitPlanRankId.lobCode == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.LOB_ID_Error)
      shwLobReqBfrErr = true
    }
    if (rankingFormData.benefitPlanRankId.benefitPlanID == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error)
      showBenefitPlanIdError = true
    }
    if (rankingFormData.rank && rankingFormData.rank == 0 || rankingFormData.rank < 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO)
      showRankZeroError = true
    }
    for (var i = 0; i < bpRankList.length; i++) {
      if (bpRankList[i].rank == rankingFormData.rank && rankingFormData.index!=i) {
        errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR);
        showRankReqBfrErr = true;
      }
      if (bpRankList[i].bpId == rankingFormData.benefitPlanID && rankingFormData.index!=i) {
        shwBenefitPlanReqBfrErr = true
        errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR);
      }
    }
    if (errorMessagesArray.length === 0) {
      const table = bpRankList;
      let rankingObj =
      {

        "auditUserID": "TCR-E05-6495",

        "addedAuditUserID": "ESPRD01183445",

        "versionNo": 0,

        "lobId": rankingFormData.lobCode ? rankingFormData.lobCode : rankingRowDetails.benefitPlanRankId.lobCode,

        "benefitPlanRankId": {

          "lobCode": rankingFormData.lobCode ? rankingFormData.lobCode : rankingRowDetails.benefitPlanRankId.lobCode,

          "benefitPlanID": rankingFormData.benefitPlanID ? rankingFormData.benefitPlanRankId.lobCode : rankingRowDetails.benefitPlanRankId.benefitPlanID,
          "rankSK": rankingRowDetails.benefitPlanRankId.rankSK
        },

        "bpIdDesc": rankingFormData.benefitPlanID ? rankingFormData.benefitPlanRankId.benefitPlanID : rankingRowDetails.benefitPlanRankId.benefitPlanID,

        "bpId": rankingFormData.benefitPlanID ? rankingFormData.benefitPlanRankId.benefitPlanID : rankingRowDetails.benefitPlanRankId.benefitPlanID,

        "rank": rankingFormData.rank ? rankingFormData.rank : rankingRowDetails.rank

      };
    rankingFormData.index > -1 ? (table[rankingFormData.index] = rankingObj) : table.push(rankingObj);
    // table.push(rankingObj);
    setBpRankList(table);
    props.setRankingSuccessMessages(["Ranking Details Updated Successfully"])
    props.setSuccessMessages(false);
    props.setadderrorMessages(errorMessagesArray);
    seterrorMessages(false);
    getAllSearch()
    setRankingShow(false);
    props.setEditRanking(false);
  } else {
    props.setadderrorMessages(errorMessagesArray);
    props.setSuccessMessages(false);
    setShowTable(false);
    setShowError({
      showRankError,
      showRankCharError,
      showBenefitPlanIdError,
      shwLobReqBfrErr,
      showRankZeroError,
      showRankReqBfrErr,
      shwBenefitPlanReqBfrErr
    });
  }
  }

  const handelResetClick = () => {
    setrowDetails(oldState);
    setValues({ ...values, "void": '1' });
  };

  const handelRankReset = () => {
    setrankingRowDetails(rankingRowDetails.index>-1?
      rankingRowDetails:{
      "benefitPlanRankId": {
        "lobCode": "-1",
        "benefitPlanID": "-1"
      },
      "rank": ""
    });
    // seterrorMessages(false);
    setRankingFormData(rankingRowDetails.index>-1?
      rankingRowDetails:{
      "benefitPlanRankId": {
        "lobCode": "-1",
        "benefitPlanID": "-1"
      },
      "rank": ""
    });
    seterrorMessages(false);
    setShowError({});
  };

  const benefitPlanDetails = addDropdowns &&  addDropdowns['A1#R_BP_ID'] && addDropdowns['A1#R_BP_ID'].map( each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
     ));

  return (
    < >
      {spinnerLoader ? <Spinner /> : null}
      

      <div className="mui-custom-form ml-3 mr-3 mt-2">
        <div className="sub-radio m-0">
          <label className="MuiFormControlLabel-root inline-radio-label float-left">
            <Checkbox
              type="checkbox"
              value="void"
              id="voidId"
              onChange={handleVoidCheck}
            />
            <span className="MuiFormControlLabel-label">Show Voids</span>
          </label>
          <div className="clearfix" />
        </div>
      </div>
      <div className="tab-holder mr-3 ml-3 mt-3 mb-3">

        <TableComponent headCells={headCells} tableData={showRecords ? getFullData(showRecords) : []} onTableRowClick={editRow}
          defaultSortColumn="beginDate" />
      </div>

      {props.ShowEditForm ? (
        <>
          <Dialog
            open={cancelDialogOpen}
            onClose={() => setCancelDialogOpen(false)}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                If Data has been entered and not saved, it will be lost.
                                      Select 'OK' to navigate away from the page
                                      or 'Cancel' to return to the page to save the Data
                                </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button onClick={cancelEditPage} color="primary">
                Ok
                                </Button>
              <Button onClick={() => setCancelDialogOpen(false)} color="primary" autoFocus>
                Cancel
                                </Button>
            </DialogActions>
          </Dialog>
          <div className="tabs-container tabs-container-inner">
            <div className="form-wrap-inner">
              <div className="tab-body-bordered my-2">
                <div className="tabs-container tabs-container-inner mt-0 mb-3">
                  <div className="tab-header mt-3">
                    <h1 className="tab-heading float-left">Edit LOB/Benefit Plan Hierarchy</h1>
                    <div className="float-right th-btnGroup">
                      {rowDetails.voidIndicator == "1" ? <Button variant="outlined" color="primary" className="btn btn-success" onClick={() => update()}>
                        <i className="fa fa-check" />Save   </Button> : <Button variant="outlined" color="primary" disabled className="btn btn-success" onClick={() => update()}>
                          <i className="fa fa-check" />Save
                                  </Button>}
                      <Button variant="outlined" color="primary" className="btn btn-primary" disabled>
                        Notes
                            </Button>

                      {rowDetails.voidIndicator == "1" ? <Button variant="outlined" color="primary" className="btn btn-reset" onClick={() => handelResetClick()}>
                        <i className="fa fa-undo" />Reset  </Button> : <Button variant="outlined" disabled color="primary" className="btn btn-reset" onClick={() => handelResetClick()}>
                          <i className="fa fa-undo" />Reset  </Button>}

                      <Button variant="outlined" color="primary" className="btn btn-primary"
                        onClick={() => setCancelDialogOpen(true)}>
                        Cancel
                            </Button>

                    </div>
                    <div className="clearfix"></div>
                  </div>

                  <div className="tab-body mt-2">
                    <div className="form-wrapper">
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <div className="mui-custom-form input-md with-select">
                          <KeyboardDatePicker
                            id="bgnDate"
                            label="Begin Date"
                            format="MM/dd/yyyy"
                            disabled={dateBeginValidation ? "disabled" : ""}
                            InputLabelProps={{
                              shrink: true,
                              required: true
                            }}
                            placeholder="mm/dd/yyyy"
                            onChange={handleBeginDateChange}
                            value={rowDetails.beginDate}
                            helperText={showBeginDateError ? BenefitPlanHierarchyConstants.Begin_Date_Error : 
                              //props.errors.showBeginLesEndErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error :  
                            //shwBgnDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error : 
                              showBgdtGTEnddtErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error : 
                              beginDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_BEGIN_DATE_ERROR : null}
                            error={showBeginDateError ? BenefitPlanHierarchyConstants.Begin_Date_Error :
                              // props.errors.showBeginLesEndErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error :
                               //shwBgnDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error : 
                               showBgdtGTEnddtErr ? BenefitPlanHierarchyConstants.Benifit_Hie_Error : 
                               beginDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_BEGIN_DATE_ERROR : null}
              
                            KeyboardButtonProps={{
                              'aria-label': 'change date',
                            }}
                          />
                        </div>
                      </MuiPickersUtilsProvider>
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <div className="mui-custom-form input-md with-select">
                          <KeyboardDatePicker
                            id="endDate"
                            label="End Date"
                            format="MM/dd/yyyy"
                             
							              maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                            disabled={dateEndValidation ? "disabled" : ""}
                            InputLabelProps={{
                              shrink: true,
                              required: true
                            }}
                            placeholder="mm/dd/yyyy"
                            value={rowDetails.endDate}
                            onChange={handleEndDateChange}
                            helperText={showEndDateError ? BenefitPlanHierarchyConstants.End_Date_Error : 
                              //props.errors.shwEndDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error :
                              endDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_END_DATE_ERROR : null}
                            error={showEndDateError ? BenefitPlanHierarchyConstants.End_Date_Error : 
                              //props.errors.shwEndDtReqBfrErr ? BenefitPlanHierarchyConstants.Header_Dates_ReqBfr_Error : 
                              endDtInvalidErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_END_DATE_ERROR : null}
              
                            KeyboardButtonProps={{
                              'aria-label': 'change date',
                            }}
                          />
                        </div>
                      </MuiPickersUtilsProvider>


                      {rowDetails.voidIndicator == "1" ? <div className="mui-custom-form input-md">
                        <label className="MuiFormLabel-root MuiInputLabel-shrink">Void:</label>
                        <RadioGroup
                          row
                          aria-label="documentBatchType"
                          name="DocumentBatchType">
                          <FormControlLabel
                            value="0"
                            id="FeeForService"
                            label="Yes"
                            control={<Radio color="primary" />}
                            checked={values.void === '0'}
                            onChange={handleChanges('void')}
                          />
                          <FormControlLabel
                            value="1"
                            control={<Radio color="primary" />}
                            label="No"
                            checked={values.void === '1'}
                            onChange={handleChanges('void')}
                          />
                        </RadioGroup>
                      </div> : <div className="mui-custom-form input-md">
                          <label className="MuiFormLabel-root MuiInputLabel-shrink">Void:</label>
                          <RadioGroup
                            row
                            aria-label="documentBatchType"
                            name="DocumentBatchType">
                            <FormControlLabel
                              value="0"
                              id="FeeForService"
                              label="Yes"
                              control={<Radio color="primary" />}
                              checked={valuess.void === '0'}
                              onChange={handleChanges('void')}
                            />
                            <FormControlLabel
                              value="1"
                              control={<Radio color="primary" />}
                              label="No"
                              checked={valuess.void === '1'}
                              onChange={handleChanges('void')}
                            />
                          </RadioGroup>
                        </div>}
                    </div>
                    <div className="form-wrap-inner">
                      <div className="tab-body-bordered my-2">
                        <div className="tabs-container tabs-container-inner mt-0">
                          <div className="tab-header mt-3">
                            <h1 className="tab-heading float-left">Ranking</h1>
                            <div className="float-right th-btnGroup">
                              {rowDetails.voidIndicator == "1" && dateValidation == true ? <Button variant="outlined" color="primary" className="btn btn-success" onClick={() => {
                                setRankingShow(true);
                                setRankingEditorAddType('Edit');
                                props.setEditRanking(false);
                                setRankingResetData({ timeStamp: new Date(), lobCode: '-1', benefitPlanID: '-1', rank: '' });
                                setRankingFormData({ timeStamp: new Date(), lobCode: '-1', benefitPlanID: '-1', rank: '' })
                              }}>
                                <i className="fa fa-plus" /> Add Ranking </Button> : <Button variant="outlined" disabled color="primary" className="btn btn-success" onClick={() => {
                                  setRankingShow(true);
                                  setRankingEditorAddType('Edit');
                                  props.setEditRanking(false);
                                  setRankingResetData({ timeStamp: new Date(), lobCode: '-1', benefitPlanID: '-1', rank: '' });
                                  setRankingFormData({ timeStamp: new Date(), lobCode: '-1', benefitPlanID: '-1', rank: '' })
                                }}>
                                  <i className="fa fa-plus" /> Add Ranking </Button>}
                            </div>
                          </div>
                          <div className="tab-holder mt-2 ml-3 mr-3">
                            <TableComponent headCells={rankingHeadCells} tableData={rowDetails.bpRankList ? getTableData(rowDetails.bpRankList) : []} onTableRowClick={editRankingRow} defaultSortColumn="lobCode" />
                          </div>
                          {rankingShow ? (
                            <>
                              {errorMessages.length > 0 ? (
                                <div className="alert alert-danger custom-alert" role="alert">
                                  {errorMessages.map(message => <li>{message}</li>)
                                  }
                                </div>
                              ) : null
                              }
                              <Dialog
                                open={cancelDialogOpen}
                                onClose={() => setCancelDialogOpen(false)}
                                aria-labelledby="alert-dialog-title"
                                aria-describedby="alert-dialog-description"
                              >
                                <DialogContent>
                                  <DialogContentText id="alert-dialog-description">
                                    If Data has been entered and not saved, it will be lost.
                                    Select 'OK' to navigate away from the page
                                    or 'Cancel' to return to the page to save the Data
                                </DialogContentText>
                                </DialogContent>
                                <DialogActions>
                                  <Button onClick={cancelRankPage} color="primary">
                                    Ok
                                </Button>
                                  <Button onClick={() => setCancelDialogOpen(false)} color="primary" autoFocus>
                                    Cancel
                                </Button>
                                </DialogActions>
                              </Dialog>
                              <div className="form-wrap-inner">
                                <div className="tab-body-bordered my-2">
                                  <div className="tabs-container">
                                    <div className="tab-header mt-3">
                                      <h1 className="tab-heading float-left">New Ranking</h1>
                                      <div className="float-right th-btnGroup">
                                        <Button variant="outlined" color="primary" className="btn btn-success" onClick={() => saveRanking()}>
                                          <i className="fa fa-check" />
                                          Save
          </Button>
                                        <Button variant="outlined" color="primary" className="btn btn-reset" onClick={() => {setRankingFormData(rankingResetData), seterrorMessages(false), setShowError({})} }>
                                          <i className="fa fa-undo" />
                                          Reset
          </Button>
                                        <Button variant="outlined" color="primary" className="btn btn-primary"
                                          onClick={() => { setCancelDialogOpen(true) }} >
                                          Cancel
          </Button>

                                      </div>
                                      <div className="clearfix"></div>
                                    </div>
                                    <RankingForm
                                      handleChanges={handleRankingChanges}
                                      values={rankingFormData}
                                      errors={{
                                        shwLobReqBfrErr,
                                        showRankError,
                                        showBenefitPlanIdError,
                                        showRankReqBfrErr,
                                        shwBenefitPlanReqBfrErr
                                      }}
                                    //errors={{ showAddCritbeginError, showAddCritEndError }}
                                    />
                                  </div>
                                </div>
                              </div>
                            </>
                          ) : null}
                          {props.editRanking ? (
                            <>
                             {errorMessages.length > 0 ? (
                                <div className="alert alert-danger custom-alert" role="alert">
                                  {errorMessages.map(message => <li>{message}</li>)
                                  }
                                </div>
                              ) : null
                              }
                              <Dialog
                                open={dialogOpen}
                                onClose={() => setDialogOpen(false)}
                                aria-labelledby="alert-dialog-title"
                                aria-describedby="alert-dialog-description"
                              >
                                <DialogContent>
                                  <DialogContentText id="alert-dialog-description">
                                    Are you sure that you want to Delete
                                </DialogContentText>
                                </DialogContent>
                                <DialogActions>
                                  <Button onClick={deleteRakings} color="primary">
                                    Ok
                                </Button>
                                  <Button onClick={() => setDialogOpen(false)} color="primary" autoFocus>
                                    Cancel
                                </Button>
                                </DialogActions>
                              </Dialog>

                              <Dialog
                                open={cancelDialogOpen}
                                onClose={() => setCancelDialogOpen(false)}
                                aria-labelledby="alert-dialog-title"
                                aria-describedby="alert-dialog-description"
                              >
                                <DialogContent>
                                  <DialogContentText id="alert-dialog-description">
                                    If Data has been entered and not saved, it will be lost.
                                      Select 'OK' to navigate away from the page
                                      or 'Cancel' to return to the page to save the Data
                                </DialogContentText>
                                </DialogContent>
                                <DialogActions>
                                  <Button onClick={cancelRanking} color="primary">
                                    Ok
                                </Button>
                                  <Button onClick={() => setCancelDialogOpen(false)} color="primary" autoFocus>
                                    Cancel
                                </Button>
                                </DialogActions>
                              </Dialog>
                              <div className="form-wrap-inner">
                                <div className="tab-body-bordered my-2">
                                  <div className="tabs-container tabs-container-inner mt-0">
                                    <div className="tab-header mt-3">
                                      <h1 className="tab-heading float-left">Edit Ranking</h1>
                                      <div className="float-right th-btnGroup">
                                        {dateValidation == false ? <Button variant="outlined" color="primary" className="btn btn-success" disabled onClick={() => {
                                          updateRanking();
                                        }}>
                                          <i className="fa fa-check" />
                                          Save
                    </Button> : <Button variant="outlined" color="primary" className="btn btn-success" onClick={() => {
                                            updateRanking();
                                          }}>
                                            <i className="fa fa-check" />
                                            Save
                          </Button>}                     

                                        <Button variant="outlined" color="primary" className="btn btn-transparent" onClick={() => setDialogOpen(true)}>
                                          <i className="fa fa-trash" />Delete
                      </Button>
                                        {dateValidation == false ? <Button variant="outlined" color="primary" className="btn btn-reset"  onClick={() => {
                                          handelRankReset();
                                        }}>
                                          <i className="fa fa-undo" />
                                          Reset
                                </Button> : <Button variant="outlined" color="primary" className="btn btn-reset" onClick={() => {
                                            handelRankReset();
                                          }}>
                                            <i className="fa fa-undo" />
                                            Reset
                                            </Button>}
                                        
                                        <Button variant="outlined" color="primary" className="btn btn-primary" onClick={() => setCancelDialogOpen(true)}>
                                          Cancel
                    </Button>

                                      </div>
                                      <div className="clearfix"></div>
                                    </div>

                                    <div className="form-wrapper other-search-form">
                                      <div className="mui-custom-form input-md">

                                        <TextField
                                          id="standard-select-lob"
                                          select
                                          label="LOB"
                                          value={rankingFormData.benefitPlanRankId.lobCode}

                                          inputProps={{ maxLength: 2 }}
                                          onChange={handleRankingChanges('lobCode')}
                                          placeholder=""
                                          InputLabelProps={{
                                            shrink: true,
                                          }}
                                        >
                                          <MenuItem selected key="Please Select One" value="-1">
                Please Select One
                                      </MenuItem>
              {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#R_LOB_CD'].length > 0 && addDropdowns['Claims#R_LOB_CD'].map( each => (
                                        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                      ))} 
                                        {/*   <MenuItem disabled selected key="Please Select One" value={rankingFormData.benefitPlanRankId.lobCode}>
                                            {rankingFormData.benefitPlanRankId.lobCode}
                                          </MenuItem>

                                          <MenuItem selected key="MED-Title XIX Medicaid" value="MED">MED-Title XIX Medicaid</MenuItem> */}
                                        </TextField>
                                      </div>
                                      <div className="mui-custom-form input-md">

                                        <TextField
                                          id="standard-select-lob"
                                          select

                                          label="Benefit Plan"
                                          value={rankingFormData.benefitPlanRankId.benefitPlanID}

                                          inputProps={{ maxLength: 2 }}
                                          onChange={handleRankingChanges('benefitPlanID')}
                                          placeholder=""
                                          InputLabelProps={{
                                            shrink: true,
                                          }}
                                        >
                                           <MenuItem selected key="Please Select One" value="-1">
                Please Select One
                                      </MenuItem>
                                      {benefitPlanIDDM}
              {/* {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['A1#R_BP_ID'].length > 0 && addDropdowns['A1#R_BP_ID'].map( each => (
                                        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                      ))}  */}
                                        {/*<MenuItem disabled selected key="Please Select One" value={rankingFormData.benefitPlanRankId.benefitPlanID}>
                                            {rankingFormData.benefitPlanRankId.benefitPlanID}
                                          </MenuItem>*/}
                                        </TextField>
                                      </div>

                                      {dateValidation == true ? <div className="mui-custom-form input-md">

                                        <TextField
                                          id="standard-rank"
                                          value={rankingFormData.rank}
                                          label='Rank'
                                          inputProps={{ maxLength: 5 }}
                                          onChange={handleRankingChanges('rank')}
                                          placeholder=""
                                          helperText={showRankError ? BenefitPlanHierarchyConstants.Rank_Error : 
                                                      showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR : 
                                                      showRankCharError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO : null}
                                          error={showRankError ? BenefitPlanHierarchyConstants.Rank_Error : 
                                                 showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR : 
                                                 showRankCharError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO : null}                    
                                          InputLabelProps={{
                                            shrink: true,
                                          }}
                                        />
                                      </div> : <div className="mui-custom-form input-md">

                                          <TextField
                                            id="standard-rank"
                                            type="number"
                                            value={rankingRowDetails.rank}
                                            label='Rank'
                                            disabled
                                            inputProps={{ maxLength: 10 }}
                                            onChange={handleEditRankingChanges('rank')}
                                            placeholder=""
                                            helperText={showRankError ? BenefitPlanHierarchyConstants.Rank_Error : showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR : showRankZeroError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO : null}
                                            error={showRankError ? BenefitPlanHierarchyConstants.Rank_Error : showRankReqBfrErr ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR : showRankZeroError ? BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO : null}                    
                                            InputLabelProps={{
                                              shrink: true,
                                            }}
                                          />
                                        </div>
                                      }
                                    </div>
                                    <div className="clearfix"></div>
                                  </div>
                                </div>
                              </div>
                            </>
                          ) : null}

                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="clearfix"></div>
                </div>
              </div>
            </div>
          </div>
        </>
      ) : null}
    </ >
  );

}
export default withRouter(BenefitPlanHierarchySearchTableComponent);
