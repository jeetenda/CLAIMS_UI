import React, { useState, useEffect,useRef } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import { benefitPlanHierarchyCreateAction, benefitPlanHierarchySearchAction, resetSearchBPHierarchy } from '../actions';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import BenefitPlanHierarchyAddForm from './BenefitPlanHierarchyAddForm';
import BenefitPlanHierarchySearchTableComponent from './BenefitPlanHierarchySearchTableComponent';
import RankingTable from './RankingTable';
import RankingForm from './RankingForm';
import * as serviceEndPoint from '../../../SharedModules/services/service'
import Axios from 'axios'
import * as BenefitPlanHierarchyConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';


function BenefitPlanSearchHierarchy(props) {
  const handelPromptSet = (set) => {
    if (set)
      setPrompt(true);
  }
  const printRef = useRef();
  let errorMessagesArray = [];
  const [showNoRecords, setShowNoRecords] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    beginDate: '',
    endDate: ''
  });
  const [adderrorMessages, setadderrorMessages] = React.useState([]);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [rankingSuccessMessages, setRankingSuccessMessages] = React.useState([]);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [successMessage, setSuccessMessage] = useState(null);
  const [showTable, setShowTable] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [rankingShow, setRankingShow] = useState(false);
  const [formEditorAddType, setFormEditorAddType] = useState(false);
  const [editAddValues, setEditAddValues] = useState(false);
  const [rankingtableData, setRankingTableData] = useState([]);
  const [payloadData, setPayLoadData] = useState([]);
  const [rankingEditorAddType, setRankingEditorAddType] = useState('add');
  const [ShowEditForm, setShowEditForm] = React.useState(false);
  const [editRanking, setEditRanking] = React.useState(false);
  const [voidFlag, setShowVoidRecord] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [rankingFormData, setRankingFormData] = useState({
    lobCode: '-1',
    benefitPlanID: '-1',
    rank: ''
  });
  const [rankingResetData, setRankingResetData] = useState({ lobCode: '-1', benefitPlanID: '-1', rank: '' });
  const [{ showRankError,showRankCharError, showBenefitPlanIdError, showBeginDateError,
    showEndDateError, shwLobReqBfrErr,showBeginLesEndErr, shwBenefitPlanReqBfrErr, showBgdtGTEnddtErr,
    beginDtInvalidErr, endDtInvalidErr, showRankReqBfrErr, showInvRank, showInvBPID, showRankZeroError }, setShowError] = React.useState(false);

  const paylod = useSelector(state => state.benefitPlanHierarchy.payload);

  const dispatch = useDispatch();
  const onReset = () => dispatch(resetSearchBPHierarchy());
  const getAllSearch = () => dispatch(benefitPlanHierarchySearchAction());
  const onCreateBPHierarchy = searchValues => dispatch(benefitPlanHierarchyCreateAction(searchValues));
  // values change function
  const handleChanges = name => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };
  const handelEditAddAchanges = name => (event) => {
    if (event.target.type === 'checkbox') {
      setEditAddValues({ ...editAddValues, [name]: event.target.checked });
    } else {
      setEditAddValues({ ...editAddValues, [name]: event.target.value });
    }
  }

  const handleRankingChanges = name => (event) => {
    setRankingFormData({ ...rankingFormData, [name]: event.target.value });
  };

  const handelDateChange = (name, date) => {
    setEditAddValues({ ...editAddValues, [name]: date });
  }

  const handleDCDtChange = (name, date) => {
    setValues({ ...values, [name]: date });
  }
  // useEffect(() => { 
  //   let temp1 = ;
  //   temp1.map((each,index) => {
  //     each.rowIndex = index;     
  //   });  
  //   setminorsavetabledata(temp1);          
  //   setCodesAndIndTableData(temp1.filter((a)=>{return a.voidIndicator == '0'}));
  // },[]);


  const tableErrorFunction = (error) => {
    setadderrorMessages(error);
  }

  const [formEditValues, setFormEditValues] = useState({
    //voidIndicator: '0',
    beginDate: '',
    endDate: '',
    voidIndicator: '',
    lob: '',
    benefitPlan: '',
    rank: ''
  });
  const handelEditChanges = (name) => (event) => {
    if (event.target.type === 'checkbox') {
      setFormEditValues({ ...formEditValues, [name]: event.target.checked });
    } else {
      setFormEditValues({ ...formEditValues, [name]: event.target.value });
    }
  }
  const handleformCIDtChanges = (name, date) => {
    setFormEditCandI({ ...formEditValues, [name]: date });
  }

  const redirectHelp = () => {
    const win = window.open("/BenefitPlanHierarchyHelp", "_blank");
    win.focus();
  }

  // reset table
  const resetTable = () => {
    setShowNoRecords(false);
    setadderrorMessages([]);
    setShowError({
      // showDiagnosisError: false,
      // showdiagnosisCodeError: false,
      // showdescriptionError: false
    });
    setValues(
      {
        beginDate: '',
        endDate: ''
      }
    );
    setShowTable(false);
    onReset()
  };

  const addForm = () => {
    props.history.push({
      pathname: '/BenefitPlanHierarchyAdd',
    });
    // setShowError(false);
    // setShowEditForm(false);
    // setEditRanking(false);
    // setShowAddForm(true);
    // setRankingShow(false);
    // setFormEditorAddType('add');
    // setEditAddValues(
    //   {
    //     "auditUserID": null,
    //     "auditTimeStamp": new Date(),
    //     "addedAuditUserID": null,
    //     "addedAuditTimeStamp": new Date(),
    //     "versionNo": 0,
    //     "dbRecord": false,
    //     "sortColumn": null,
    //     "auditKeyList": [],
    //     "auditKeyListFiltered": false,
    //     "beginDate": "",
    //     "endDate": "",
    //     "auditTimeStamp1": "",
    //     "voidIndicator": "1",
    //     "bpRankDeleteList": [],
    //     "bpRankList": [
    //       {
    //         "auditUserID": null,
    //         "auditTimeStamp": new Date(),
    //         "addedAuditUserID": null,
    //         "addedAuditTimeStamp": new Date(),
    //         "versionNo": 0,
    //         "dbRecord": false,
    //         "sortColumn": null,
    //         "auditKeyList": [],
    //         "auditKeyListFiltered": false,
    //         "lobId": "",
    //         "benefitPlan": null,
    //         "benefitPlanRankId": {
    //           "lobCode": "",
    //           "benefitPlanID": ""
    //         },
    //         "bpIdDesc": "",
    //         "bpId": "",
    //         "rank": "",
    //         "lobDesc": ""
    //       }
    //     ],
    //     "noteSetVO": null,
    //     "voidFlag": "false"
    //   }
    // );

  }

  const addUpdateSave = () => {
    const rankingtabledataSave = rankingtableData;
    let transRankingtabledata = [];
    let shwLobReqBfrErr;
    let showBeginDateError;
    let showBeginLesEndErr;
    let showEndDateError;
    let beginDtInvalidErr;
    let endDtInvalidErr;
    let showBgdtGTEnddtErr;
    let showRankError;
    let showBenefitPlanIdError;
    setspinnerLoader(false);
    errorMessagesArray = [];
    setadderrorMessages([]);
    let reqFieldArr = [];
    // if (rankingtabledataSave == 0) {
    //   setadderrorMessages(["If a date range is entered, at least one LOB/Benefit Plan row must be entered."]);
    //   setadderrorMessages(["Begin Date is Required."]);
    //   setSuccessMessages(false)
    //   // return false;
    // }
    if( (new Date(values.beginDate) >= new Date(values.endDate)))
    {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benifit_Hie_Error)
      showBeginLesEndErr = true
    }
    if (rankingtabledataSave  == 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.LOB_ID_Error)
      shwLobReqBfrErr = true
    }
    if (rankingtabledataSave == 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Rank_Error)
      showRankError = true
    }
    if (rankingtabledataSave == 0) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error)
      showBenefitPlanIdError = true
    }
    if(values.beginDate == ""){
      showBeginDateError = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Begin_Date_Error)
    }
    if(values.endDate == ""){
      showEndDateError = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.End_Date_Error)
    }
    if(values.beginDate.toString() == "Invalid Date"){
      beginDtInvalidErr = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_BEGIN_DATE_ERROR)
    }
    if(values.endDate.toString() == "Invalid Date"){
      endDtInvalidErr = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_HIERARCHY_END_DATE_ERROR);
    }
    if(values.beginDate != "" && values.endDate != "" && values.beginDate.toString() != "Invalid Date" && values.endDate.toString() == "Invalid Date" && (new Date(values.beginDate) <= new Date(values.endDate) == false)){
      showBgdtGTEnddtErr = true;
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_ENDDATE_ERROR);
    }
    

    if (errorMessagesArray.length === 0) {
      let searchCriteria = {

        "auditUserID": "TCR-E05-6495",
        "auditTimeStamp": new Date(),
        "addedAuditUserID": "",
        "addedAuditTimeStamp": new Date(),
        "versionNo": 0,
        "beginDate": values.beginDate,
        "endDate": values.endDate,
        "auditTimeStamp1": new Date(),
        "voidIndicator": "1",
        "bpRankList": rankingtabledataSave,
        "noteSetVO": null,
      }
      setspinnerLoader(true);
      Axios.post(`${serviceEndPoint.BENEFIT_PLAN_HIERARCHY_ADD_ENDPOINT}`, searchCriteria)
        .then(res => {
          setspinnerLoader(false);
          console.log(res)
          if(res.data.data === true){
            setSuccessMessages([BenefitPlanHierarchyConstants.SUCCESSFULLY_SAVED_INFORMATION])
            setShowAddForm(false)
            setadderrorMessages(false);
            setRankingSuccessMessages(false)
            dispatch(benefitPlanHierarchySearchAction())
          }else{
            if(res.data.message == "error.Dates_Overlap"){
              setadderrorMessages([BenefitPlanHierarchyConstants.BENEFIT_PLAN_DATE_OVERLAP_ERROR]);
              setspinnerLoader(false);
              setSuccessMessages(false)
              setRankingSuccessMessages(false)
            }else{
              setadderrorMessages([BenefitPlanHierarchyConstants.BENEFIT_PLAN_SAVE_ERROR]);
              setspinnerLoader(false);
              setSuccessMessages(false)
              setRankingSuccessMessages(false)
            }                    
          }
        })
        .catch(e => {
          setspinnerLoader(false);
          setSuccessMessages(false)
          setRankingSuccessMessages(false)
        })
    }else{        
      setadderrorMessages(errorMessagesArray);
      setRankingSuccessMessages(false);
      setSuccessMessages(false)
      setShowError({
        showBeginDateError,
        showEndDateError,
        beginDtInvalidErr,
        endDtInvalidErr,
        showBgdtGTEnddtErr,
        showBeginLesEndErr,
        shwLobReqBfrErr,
        showRankError,
        showBenefitPlanIdError
      });
    }
  }

 const saveRanking = () => {
    errorMessagesArray = [];
    seterrorMessages([]);
    //setShowError({});
    let showRankCharError;
    let showRankError;
    let showBenefitPlanIdError;
    let shwLobReqBfrErr;
    let showInvRank;
    let showInvBPID;
    let showRankZeroError;
    if (rankingFormData.lobCode  == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.LOB_ID_Error)
      shwLobReqBfrErr = true
    }
    setShowError({
      showRankCharError: !isNaN(rankingFormData.rank)
        ? false
        : (() => {
          errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO);
          showRankCharError = true;
          })(),
    });
    if (rankingFormData.rank == null || rankingFormData.rank == '') {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Rank_Error)
      showRankError = true
    }
    if(rankingFormData.rank != null && rankingFormData.rank == 0 || rankingFormData.rank < 0){
      errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANKING_ZERO)
      showRankZeroError = true
    }
    if (rankingFormData.benefitPlanID == -1) {
      errorMessagesArray.push(BenefitPlanHierarchyConstants.Benefit_Plan_ID_Error)
      showBenefitPlanIdError = true
    }
    for(var i=0; i<rankingtableData.length; i++){
      if (rankingtableData[i].rank == rankingFormData.rank) {
        showInvRank = true;
        errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_RANK_ERROR)
      }
      if (rankingtableData[i].bpId == rankingFormData.benefitPlanID) {
        showInvBPID = true
        errorMessagesArray.push(BenefitPlanHierarchyConstants.BENEFIT_PLAN_BPID_ERROR);
      }
    }
   
      let rankingObj =
      {
  
        "auditUserID": "TCR-E05-6495",
  
        "addedAuditUserID": "ESPRD01183445",
  
        "versionNo": 0,
  
        "lobId": rankingFormData.lobCode,
  
        "benefitPlanRankId": {
  
          "lobCode": rankingFormData.lobCode,
  
          "benefitPlanID": rankingFormData.benefitPlanID
  
        },
  
        "bpId": rankingFormData.benefitPlanID,
  
        "bpIdDesc": rankingFormData.benefitPlanID,
  
        "rank": rankingFormData.rank
  
      };
  
      if (errorMessagesArray.length === 0) {
        const table = rankingtableData;
  
       
        if (rankingEditorAddType === 'add') {
          table.push(rankingObj);
          setRankingTableData(table);
        } else {//edit
          const change = table.filter(each => each.timeStamp !== rankingFormData.timeStamp);
          change.push(rankingFormData);
          setRankingTableData(change);
        }
        setRankingSuccessMessages(["Ranking Details Saved Successfully"])
        setRankingShow(false);
        setadderrorMessages(false)
        seterrorMessages(false);
        setRankingResetData({ timeStamp: '', lobCode: '-1', benefitPlanID: '-1', rank: '' });
        setRankingFormData({ timeStamp: '', lobCode: '-1', benefitPlanID: '-1', rank: '' });
      } else {
        seterrorMessages(errorMessagesArray);
        setRankingSuccessMessages(false);
        setShowError({
          showRankError,
          showRankCharError,
          showBenefitPlanIdError,
          shwLobReqBfrErr,
          showInvBPID,
          showInvRank
        });
      }
    
    
  }

  const cancel = () => {
    setShowAddForm(true);
    setCancelDialogOpen(false)
    setRankingShow(false);
    setadderrorMessages(false)
    setRankingSuccessMessages(false)
    setSuccessMessages(false)
  }

  const cancelAddPage = () => {
    setShowAddForm(false);
    setDialogOpen(false)
    setRankingShow(false);
    setadderrorMessages(false)
    setRankingSuccessMessages(false)
    setSuccessMessages(false)
  }



  // on plan hierarchy code page load

  useEffect(() => {
    if(props.privileges && props.privileges.search){getAllSearch()};
    if ( paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      let temp1 = paylod;
      console.log(temp1)
      setPayLoadData(temp1)
      setShowTable(true);
      if (paylod.length == 0) {
        setShowNoRecords(true);
      }
    }
  }, []);

  // on diagnosis page search data
  useEffect(() => {
    if (paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      setspinnerLoader(false);
    }
    if (paylod && paylod.message != null) {
      setspinnerLoader(false);
      errorMessagesArray.push(BenefitPlanHierarchyConstants.ERROR_OCCURED_DURING_TRANSACTION);
      setadderrorMessages(errorMessagesArray);
    }
    if (paylod != null && paylod.length == 0) {
      setShowNoRecords(true);
    }
    if (paylod != null && paylod.length == 1 && redirect) {
      const benefitPlanViewData = paylod[0]
      onSearchView({ benefitPlanId: benefitPlanViewData.benefitPlanId });
      setspinnerLoader(true);
    }
  }, [paylod]);



  return (

    <div>
      {spinnerLoader ? <Spinner /> : null}
     
      {adderrorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert" role="alert">
          {adderrorMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null
      }
      {successMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {successMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null}
      {rankingSuccessMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {rankingSuccessMessages.map(message => <li>{message}</li>)}
        </div>
      ) : null}

      <div className="mb-2">
				 <BreadCrumbs
					parent="Benefits"
					child1="Search Benefit Plan Hierarchy"
					path=""
				 />
      </div>

      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="tab-heading page-heading float-left">Benefit Plan Hierarchy</h1>
          <div className="float-right th-btnGroup">
            <Button title="Add LOB/Benefit Plan Hierarchy" variant="outlined" color="primary" className="btn btn-ic btn-add" onClick={addForm} disabled={props.privileges && !props.privileges.add? 'disabled':'' }>
               Add 
                        </Button>
                        <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
              Print
              </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help" onClick = {redirectHelp}>
               Help
                        </Button>

          </div>
          <div className="clearfix"></div>
        </div>
        <div className="custom-hr my-1 pb-1" />
        <div className="tab-body mt-3 pt-2 pb-2">

          <BenefitPlanHierarchySearchTableComponent
            tableData={paylod}
            setShowEditForm={setShowEditForm}
            ShowEditForm={ShowEditForm}
            setEditRanking={setEditRanking}
            editRanking={editRanking}
            setShowAddForm={setShowAddForm}
            setFormEditValues={setFormEditValues}
            handelEditChanges={handelEditChanges}
            handleformCIDtChanges={handleformCIDtChanges}
            setRankingFormData={setRankingFormData}
            setRankingResetData={setRankingResetData}
            setRankingShow={setRankingShow}
            setRankingEditorAddType={setRankingEditorAddType}
            handleChanges={handleRankingChanges}
            setSuccessMessages={setSuccessMessages}
            setRankingSuccessMessages={setRankingSuccessMessages}
            setadderrorMessages={setadderrorMessages}
            handelDateChange={handelDateChange}
            values={values} 
            handleDCDtChange={handleDCDtChange}
            errors={{
              showBeginDateError,
              showEndDateError,
              shwLobReqBfrErr,
              shwBenefitPlanReqBfrErr,
              showRankReqBfrErr,
              showBgdtGTEnddtErr, beginDtInvalidErr, endDtInvalidErr,
              showRankError,
              showBenefitPlanIdError
            }}
            setRedirect={setRedirect}
            redirect={redirect}
          />

          
        </div>
        <Footer print />

      </div>
    </div>
  );
}
export default withRouter(BenefitPlanSearchHierarchy);
