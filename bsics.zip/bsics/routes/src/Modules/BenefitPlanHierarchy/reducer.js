import * as actionTypes from './actionTypes';

const axiosPayLoad = {
  payload: null
  //diagnosisCodeDetails: null
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.RESETDATA:
      return axiosPayLoad;
    // case actionTypes.BENEFIT_PLAN_HIERARCHY_DROPDOWNS:
    //   return { ...state, dropdowns: action.dropdowns }
    case actionTypes.BENEFIT_PLAN_HIERARCHY_SEARCH:
      return { ...state, payload: action.benefitHiearchySearchData,payloadtime: new Date()};
    case actionTypes.BENEFIT_PLAN_HIERARCHY_CREATE:
    return { ...state, createStatus: action.createStatus, createStatusTime: new Date()}
    case actionTypes.BENEFIT_PLAN_HIERARCHY_UPDATE:
     return { ...state, updateStatus: action.updateStatus, updateStatusTime: new Date()}
    // case actionTypes.BENEFIT_PLAN_HIERARCHY_VIEW_DETAILS_TYPE:
    //   return { ...state, benefitHiearchyPlanDetails: action.benefitHiearchySearchData, benefitHiearchyDetailsTime: new Date()};
    default: return state;
  }
};

export default reducer;
