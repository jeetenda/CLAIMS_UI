/* eslint-disable arrow-parens */
import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';

export const resetSearchBenefitPlan = () => ({
    type: actionTypes.RESETDATA,
    resetData: []
});

export const dispatchBenefitPlanSearch = (response) => ({
    type: actionTypes.BENEFIT_PLAN_SEARCH_TYPE,
    benefitSearchData: response
});

export const dispatchBenefitPlanViewDetails = (response) => ({
    type: actionTypes.BENEFIT_PLAN_VIEW_DETAILS_TYPE,
    benefitSearchData: response
});

export const dispatchDropdowns = (response) => ({
    type: actionTypes.BENEFIT_PLAN_DROPDOWNS,
    dropdowns: response
})

export const benefitPlanDropdowns = values => dispatch => {
    return axios.post(`${serviceEndPoint.GET_APP_DROPDOWN_ENDPOINT}`, values)
        .then(response => {
            if (Object.keys(response.data.listObj).length > 0) {
                dispatch(dispatchDropdowns(response.data.listObj));
            }
        })
}

export const benefitPlanSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.BENEFIT_PLAN_SEARCH_ENDPOINT}`, values)
        .then(response => {
            console.log(response);
                dispatch(dispatchBenefitPlanSearch(response.data.searchResults));
        })
        .catch(error => {
            dispatch(dispatchBenefitPlanSearch(error.data));
        })
}

export const benefitPlanDetailsAction = values => dispatch => {
    return axios.get(`${serviceEndPoint.BENEFIT_PLAN_GET_ENDPOINT}/${values.lobCode}/${values.benefitPlanID}`)
        .then(response => {
            dispatch(dispatchBenefitPlanViewDetails(response.data));
        })
        .catch(error => {
            dispatch(dispatchBenefitPlanViewDetails(error.data));
        })    
}