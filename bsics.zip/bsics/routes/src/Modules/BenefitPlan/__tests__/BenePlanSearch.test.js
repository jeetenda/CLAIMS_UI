import React from "react"
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { benefitPlanSearchAction } from '../actions'
import * as actionTypes from '../actionTypes'
import BenefitPlanSearchForm from "../Components/BenefitPlanSearchForm"

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 18-Oct-2020
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

const reactMock = require("react");

const setHookState = (newState) =>
    jest.fn().mockImplementation(() => [newState, () => { }]);

describe('Benefit Plan Search Form Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper

    // intitial state for component
    const initialState = {}

    // intitial props for component
    const componentProps = {
        dropdowns: { 'Claims#R_BP_TY_CD': [{ code: "C", description: "C-PCCM", longDescription: "Primary Care Case Management" }] },
        errors: {
            beginDtInvalidErr: true,
            benefitPlanIDLengtherror: true,
            benefitPlanIDerror: true,
            endDtInvalidErr: true,
            showBgnDtGtEndDtError: true,
            showdescriptionError: true,
            showdescriptionLengthError: true
        },
        handleChanges: jest.fn(),
        handleDCDtChange: jest.fn(),
        privileges: { add: true, update: true, search: true },
        resetTable: jest.fn(),
        searchCheck: jest.fn(),
        values: {
            beginDate: "",
            benefitPlanId: "",
            benefitPlanType: "-1",
            benefitStartsOrContains: null,
            description: "",
            descriptionCodeStartsOrContains: null,
            endDate: ""
        }
    }

    const stateChangeFn = jest.fn();
    const handleClick = jest.spyOn(React, "useState");
    handleClick.mockImplementation((showSsnFeinForm) => [
        showSsnFeinForm
    ]);

    reactMock.useState = setHookState({
        showForm: true
    });

    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><BenefitPlanSearchForm  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    //expect used for assert the component and match the output with testing condition


    describe('Render Benefit Plan Search Form Component', () => {

        it('should render Benefit Plan Search Form without error', () => {
            const component = wrapper.find("#form")
            expect(component.length).toBe(1);

        })

        it('should render Benefit Plan Id element without error', () => {
            const component = wrapper.find("#Benefit_plan_id_main")
            expect(component.length).toBe(1);

        })

        it('should render Benefit Plan satrt with without error', () => {
            const component = wrapper.find("#start_with_main")
            expect(component.length).toBe(1);

        })

        it('should render Benefit Plan contains without error', () => {
            const component = wrapper.find("#contains_main")
            expect(component.length).toBe(1);

        })

        it('should render Benefit Plan type without error', () => {
            const component = wrapper.find("#Benefit_plan_type_main")
            expect(component.length).toBe(1);

        })

        it('should render Benefit Plan description without error', () => {
            const component = wrapper.find("#Benefit_plan_description_main")
            expect(component.length).toBe(1);

        })



        it('should render search button without error', () => {
            const component = wrapper.find("#btn-search")
            expect(component.length).toBe(1);

        })

        it('should render reset button without error', () => {
            const component = wrapper.find("#btn-reset")
            expect(component.length).toBe(1);

        })


        it('should render reset button without error', () => {
            const component = wrapper.find("#btn-reset")
            expect(component.length).toBe(1);

        })

        it('should click begin date with date value', () => {
            const component = wrapper.find("#bgn_date_main");
            (component).simulate("change", new Date());
            expect(component.length).toBe(1);
        })

        it('should click end date with date value', () => {
            const component = wrapper.find("#end_date_main");
            (component).simulate("change", new Date());
            expect(component.length).toBe(1);
        })

        it('should click begin date with onKey', () => {
            const component = wrapper.find("#bgn_date_main");
            (component).simulate("keyup", {target:{value :  new Date()}});
            expect(component.length).toBe(1);
        })

        it('should click end date with date value', () => {
            const component = wrapper.find("#end_date_main");
            (component).simulate("keyup", {target:{value :  new Date()}});
            expect(component.length).toBe(1);
        })



    })

    describe('Benefit Plan Search API test cases', function () {

        // const reqBody = {
        //     beginDateStr: "",
        //     benefitPlanId: "12",
        //     benefitPlanIdStartsWithOrContains: "0",
        //     benefitPlanType: "",
        //     description: "",
        //     descriptionCodeStartsOrContains: "",
        //     endDateStr: ""
        // }

        // const resObject = {
        //     categoryOfServiceCode: "003",
        //     categoryOfServiceDesc: "003-InpHspMent",
        //     indicator: false,
        //     lobCode: "MED",
        //     lobCodeDesc: "MED-MEDICAID",
        //     modifierCode1: null,
        //     modifierCode1Desc: null,
        //     modifierCode2: null,
        //     modifierCode2Desc: null,
        //     modifierCode3: null,
        //     modifierCode3Desc: null,
        //     modifierCode4: null,
        //     modifierCode4Desc: null,
        //     nationalProcedureCode: null,
        //     procCode: "G8456",
        //     procShortDescription: "CURRENT SMKLESS TOBACCO USER",
        //     procedureCode: "G8456",
        //     ratePCCategoryOfServiceSK: null,
        //     recordCount: 0,
        //     searchResults: null,
        //     uniqueSArecCnt: 0
        // }

        // const reqResponse = {
        //     searchResults: resObject
        // }

        // beforeEach(function () {
        //     // import and pass your custom axios instance to this method
        //     moxios.install()
        // })

        // afterEach(function () {
        //     // import and pass your custom axios instance to this method
        //     moxios.uninstall()
        // })

        // it('should be success the api call', () => {

        //     moxios.wait(() => {

        //         let request = moxios.requests.mostRecent()
        //         request.respondWith(mockSuccess(reqResponse));

        //     })

        //     const dispatchBenefitPlanSearch = {
        //         type: actionTypes.BENEFIT_PLAN_SEARCH_TYPE,
        //         benefitSearchData: resObject
        //     }


        //     return store.dispatch(benefitPlanSearchAction(reqBody))
        //         .then(() => {
        //             const actions = store.getActions()
        //             expect(actions[0]).toEqual(dispatchBenefitPlanSearch);
        //         })

        // })

//         it('should be fail the api call', () => {
  const componentProps1 = {
        dropdowns: { 'Claims#R_BP_TY_CD': [{ code: "C", description: "C-PCCM", longDescription: "Primary Care Case Management" }] },
        errors: {
            beginDtInvalidErr: false,
            benefitPlanIDLengtherror: false,
            benefitPlanIDerror: false,
            endDtInvalidErr: false,
            showBgnDtGtEndDtError: false,
            showdescriptionError: false,
            showdescriptionLengthError: false
        },
        handleChanges: jest.fn(),
        handleDCDtChange: jest.fn(),
        privileges: { add: true, update: true, search: false },
        resetTable: jest.fn(),
        searchCheck: jest.fn(),
        values: {
            beginDate: "",
            benefitPlanId: "",
            benefitPlanType: "-1",
            benefitStartsOrContains: null,
            description: "",
            descriptionCodeStartsOrContains: null,
            endDate: ""
        }
    }

const componentProps2 = {
    dropdowns: { 'Claims#R_BP_TY_CD': [{ code: "C", description: "C-PCCM", longDescription: "Primary Care Case Management" }] },
    errors: {
        beginDtInvalidErr: false,
        benefitPlanIDLengtherror: false,
        benefitPlanIDerror: false,
        endDtInvalidErr: false,
        showBgnDtGtEndDtError: false,
        showdescriptionError: true,
        showdescriptionLengthError: true
    },
    handleChanges: jest.fn(),
    handleDCDtChange: jest.fn(),
    privileges: { add: true, update: true, search: false },
    resetTable: jest.fn(),
    searchCheck: jest.fn(),
    values: {
        beginDate: "",
        benefitPlanId: "",
        benefitPlanType: "-1",
        benefitStartsOrContains: null,
        description: "",
        descriptionCodeStartsOrContains: null,
        endDate: ""
    }
}
reactMock.useState = setHookState({
    showForm: true
});

const store1 = mockStore(initialState)
const wrapper1 = shallow(<Provider store={store1}><Router><BenefitPlanSearchForm  {...componentProps1} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
const wrapper2 = shallow(<Provider store={store1}><Router><BenefitPlanSearchForm  {...componentProps2} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

it('should click end date with date value', () => {
    const component = wrapper1.find("#end_date_main");
    (component).simulate("keyup", {target:{value : null}});
    expect(component.length).toBe(1);
})

it('should click end date with date value', () => {
    const component = wrapper2.find("#end_date_main");
    (component).simulate("keyup", {target:{value : null}});
    expect(component.length).toBe(1);
})



  
    })

})



