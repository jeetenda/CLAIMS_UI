import React, {
  useState,
  useEffect,
  useRef,
  forwardRef,
  useImperativeHandle,
} from "react";
import { mount, shallow } from "enzyme";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import thunk from "redux-thunk";
import "babel-polyfill";
import BenefitPlanCapitation from "../components/BenefitPlanCapitation";

const middlewares = [thunk];
// jest.mock("../Component/ClaimMassAdjSearchTable", (props) => (props) => (
//   <div id="test">Hello World</div>
// ));

/**
 * describe() is used to handle rendering Exception Search Component.
 * get element selector from componen using expect method of jest
 * @Date 27-Nov-2020
 * @author Jai Arora
 */
jest.mock("../components/CapitationTableComponent", (props) => (props) => (
  <div /*onClick={props.onTableRowClick()}*/ id="test">Hello World</div>
));
const calluseImperativeHandle=()=> {
    useImperativeHandle(useRef,()=>jest.fn())
  };

describe("Text Management Location Add Component", () => {
  const initialState = {};
  const mockStore = configureStore(middlewares);
  let store, wrapper;

  store = mockStore(initialState);

  const setup = function (initialState, componentProps) {
    const updateState = jest.fn();
    React.useState = jest.fn(() => [initialState, updateState]);
    // wrapper = shallow(
    //   <Provider store={store}>
    //     <Router>
    //       <BenefitPlanCapitation {...componentProps} />
    //     </Router>
    //   </Provider>
    // )
    //   .dive()
    //   .dive()
    //   .dive()
    //   .dive()
    //   .dive()
    //   .dive();

      wrapper = mount(
        <Provider store={store}>
          <Router>
            <BenefitPlanCapitation {...componentProps} />
          </Router>
        </Provider>
      )
      ;
    return wrapper;
  };

  it("should render location text without error", () => {
    const wrapper = setup(
      {
        showHeaderDateErr: true,
        showBeginDateError: true,
        showEndDateError: true,
        beginDtInvalidErr: true,
        endDtInvalidErr: true,
        showRankOverlapErr: true,
        mapIdErr: true,
        rateTypeCodeError: true,
        networkStatusError: true,
        rankError: true,
        rateError: true,
        showBgdtGTEnddtErr: true,
        RateErr: true,
        showRankErrSpe: true,
        showRankErrZero: true,
        banifitPlan: true,
       
      },
      {
        setTabChangeValue: jest.fn(),
        seterrorMessages: jest.fn(),
        setShowError: jest.fn(),
        setNewCohortState: jest.fn(),
        setDeleteCohortRow: jest.fn(),
        setholdbackVo1Values: jest.fn(),
        setholdbackVo2Values: jest.fn(),
        setcapitationValues: jest.fn(),
        handleCapitationChanges: jest.fn(),
        majorvalidationscapitation: jest.fn(),
        handleholdbackVo1Changes: jest.fn(),
        handleholdbackVo2Changes: jest.fn(),

        tabChangeValue: { tabChangeValue: true, capitationTab: "" },
        formValues: {
          beginDate: "2020-11-23T06:39:32.667+0000",
          endDate: "2020-11-23T06:39:32.667+0000",
        },
        mainValues: { planType: "M" },
        holdbackVo1Values: {
          addedAuditTimeStamp: "2020-11-23T06:39:32.667+0000",
          addedAuditUserID: "",
          versionNo: "",
          funcAreaCode: "",
          sysParamNum: "",
          auditTimeStamp: "2020-11-23T06:39:32.667+0000",
          auditUserID: "",
        },
        holdbackVo2Values: {
          addedAuditTimeStamp: "2020-11-23T06:39:32.667+0000",
          addedAuditUserID: "",
          versionNo: "",
          funcAreaCode: "",
          sysParamNum: "",
          auditTimeStamp: "2020-11-23T06:39:32.667+0000",
          auditUserID: "",
        },
        capitationValues: {
          addedAuditTimeStamp: "2020-11-23T06:39:32.667+0000",
          addedAuditUserID: "",
          versionNo: "",
          funcAreaCode: "",
          sysParamNum: "",
          auditTimeStamp: "2020-11-23T06:39:32.667+0000",
          auditUserID: "",
          currentProcCode: "",
          retroProcCode: "",
          futureVersionNo: "",
          futureProcCode: "",
        },
        newCohortState: true,
        deleteCohortRow: true,
        currprocErr: true,
        edit: true,
        retroprocErr : true,
        values: { benefitPlanID: "" },

        dropdowns: { 'R1#R_BP_NW_STAT_CD': [{ code: "C", description: "C-PCCM", longDescription: "Primary Care Case Management" }] ,
        'R1#R_BP_COHRT_RATE_TY_CD': [{ code: "C", description: "C-PCCM", longDescription: "Primary Care Case Management" }] ,},
        nonVvDropdown: {
          "20#R1": [
            {
              code: "C",
              description: "C-PCCM",
              longDescription: "Primary Care Case Management",
            },
          ],
          "21#R1": [
            {
              code: "C",
              description: "C-PCCM",
              longDescription: "Primary Care Case Management",
            },
          ],
          "41#R1": [
            {
              code: "C",
              description: "C-PCCM",
              longDescription: "Primary Care Case Management",
            },
          ],

          "31#R1": [
            {
              code: "C",
              description: "C-PCCM",
              longDescription: "Primary Care Case Management",
            },
          ],

          "30#R1": [
            {
              code: "C",
              description: "C-PCCM",
              longDescription: "Primary Care Case Management",
            },
          ],
          "40#R1": [
            {
              code: "C",
              description: "C-PCCM",
              longDescription: "Primary Care Case Management",
            },
          ],
          "23#R1": [
            {
              code: "C",
              description: "C-PCCM",
              longDescription: "Primary Care Case Management",
            },
          ],
        },
      }
    );
    console.log(wrapper.debug())
    // const component = wrapper.find("#add_cap_mgm").at(0);
    // component.simulate("click");
    const component1 = wrapper.find("#dialog_close").at(0);
    // component1.prop("onClose")({ target: { value: "" } });
    // const component2 = wrapper.find("#dialog_cancel").at(0);
    // component2.simulate("click");
    // const component3 = wrapper.find("#add_edit_button").at(0);
    // component3.simulate("click");
    // const component4 = wrapper.find("#reset_bp").at(0);
    // component4.simulate("click");
    // const component5 = wrapper.find("#cancel_bp").at(0);
    // component5.simulate("click");
    // const component6= wrapper.find("#standard-basic").at(0);
    // component6.simulate("change",{ target: { value: "12" } });
    // const component7= wrapper.find("#rate").at(0);
    // component7.simulate("change",{ target: { value: "12" } });
    // const component8= wrapper.find("#rateTypeCode").at(0);
    // component8.simulate("change",{ target: { value: "12" } });
    // const component9= wrapper.find("#mapID").at(0);
    // component9.simulate("change",{ target: { value: "12" } });
    // const component10= wrapper.find("#nwStatCode").at(0);
    // component10.simulate("change",{ target: { value: "12" } });
    // const component11 = wrapper.find("#Delete_bp").at(0);
    // component11.simulate("click");
    // const component12 = wrapper.find("#ok").at(0);
    // component12.simulate("click");
    expect(component1.length).toBe(1);
  });





  // it("should render location text without error", () => {
  //   const wrapper = setup(
  //     {
  //       showHeaderDateErr: false,
  //       showBeginDateError: true,
  //       showEndDateError: false,
  //       beginDtInvalidErr: true,
  //       endDtInvalidErr: true,
  //       showRankOverlapErr: true,
  //       mapIdErr: false,
  //       rateTypeCodeError: false,
  //       networkStatusError: false,
  //       rankError: false,
  //       rateError: false,
  //       showBgdtGTEnddtErr: true,
  //       RateErr: true,
  //       showRankErrSpe: true,
  //       showRankErrZero: true,
  //       banifitPlan: true,
  //     },
  //     {
  //       setTabChangeValue: jest.fn(),
  //       seterrorMessages: jest.fn(),
  //       setShowError: jest.fn(),
  //       setNewCohortState: jest.fn(),
  //       setDeleteCohortRow: jest.fn(),
  //       setholdbackVo1Values: jest.fn(),
  //       setholdbackVo2Values: jest.fn(),
  //       setcapitationValues: jest.fn(),
  //       handleCapitationChanges: jest.fn(),
  //       majorvalidationscapitation: jest.fn(),
  //       handleholdbackVo1Changes: jest.fn(),
  //       handleholdbackVo2Changes: jest.fn(),

  //       tabChangeValue: { tabChangeValue: true, capitationTab: "" },
  //       formValues: {
  //         beginDate: "2020-11-23T06:39:32.667+0000",
  //         endDate: "2020-11-23T06:39:32.667+0000",
  //       },
  //       mainValues: { planType: "Q" },
  //       holdbackVo1Values: {
  //         addedAuditTimeStamp: "2020-11-23T06:39:32.667+0000",
  //         addedAuditUserID: "",
  //         versionNo: "",
  //         funcAreaCode: null,
  //         sysParamNum: null,
  //         auditTimeStamp: "2020-11-23T06:39:32.667+0000",
  //         auditUserID: "",
  //       },
  //       holdbackVo2Values: {
  //         addedAuditTimeStamp: "2020-11-23T06:39:32.667+0000",
  //         addedAuditUserID: "",
  //         versionNo: "",
  //         funcAreaCode: null,
  //         sysParamNum: null,
  //         auditTimeStamp: "2020-11-23T06:39:32.667+0000",
  //         auditUserID: "",
  //       },
  //       capitationValues: {
  //         addedAuditTimeStamp: "2020-11-23T06:39:32.667+0000",
  //         addedAuditUserID: "",
  //         versionNo: "",
  //         funcAreaCode: null,
  //         sysParamNum: null,
  //         auditTimeStamp: "2020-11-23T06:39:32.667+0000",
  //         auditUserID: "",
  //         currentProcCode: "",
  //         retroProcCode: "",
  //         futureVersionNo: "",
  //         futureProcCode: null,
  //       },
  //       newCohortState: true,
  //       deleteCohortRow: true,
  //       currprocErr: false,
  //       edit: false,
  //       retroprocErr : false,
  //       values: { benefitPlanID: "" },

  //       dropdowns: { 'R1#R_BP_NW_STAT_CD': [{ code: "C", description: "C-PCCM", longDescription: "Primary Care Case Management" }] ,
  //       'R1#R_BP_COHRT_RATE_TY_CD': [{ code: "C", description: "C-PCCM", longDescription: "Primary Care Case Management" }] ,},
  //       nonVvDropdown: {
  //         "20#R1": [
  //           {
  //             code: "C",
  //             description: "C-PCCM",
  //             longDescription: "Primary Care Case Management",
  //           },
  //         ],
  //         "21#R1": [
  //           {
  //             code: "C",
  //             description: "C-PCCM",
  //             longDescription: "Primary Care Case Management",
  //           },
  //         ],
  //         "41#R1": [
  //           {
  //             code: "C",
  //             description: "C-PCCM",
  //             longDescription: "Primary Care Case Management",
  //           },
  //         ],

  //         "31#R1": [
  //           {
  //             code: "C",
  //             description: "C-PCCM",
  //             longDescription: "Primary Care Case Management",
  //           },
  //         ],
  //         "23#R1": [
  //           {
  //             code: "C",
  //             description: "C-PCCM",
  //             longDescription: "Primary Care Case Management",
  //           },
  //         ],
  //       },
  //     }
  //   );
  //   const component = wrapper.find("#add_cap_mgm").at(0);
  //   component.simulate("click");
  //   expect(component.length).toBe(1);
  // });
});
