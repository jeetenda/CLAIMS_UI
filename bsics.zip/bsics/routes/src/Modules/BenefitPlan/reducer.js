import * as actionTypes from './actionTypes';

const axiosPayLoad = {
  payload: null,
  benefitPlanDetails: null,
  type: 'Add'
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.RESETDATA:
      return axiosPayLoad;
    case actionTypes.BENEFIT_PLAN_DROPDOWNS:
      return { ...state, dropdowns: action.dropdowns }
    case actionTypes.BENEFIT_PLAN_SEARCH_TYPE:
      return { ...state, payload: action.benefitSearchData}
    case actionTypes.BENEFIT_PLAN_VIEW_DETAILS_TYPE:
      return { ...state, benefitPlanDetails: action.benefitSearchData, benefitPlanDetailsTime: new Date(), type: 'Edit'}
    default: return state;
  }
};

export default reducer;
