import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import { Button } from "react-bootstrap";
import Checkbox from "@material-ui/core/Checkbox";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker,
} from "@material-ui/pickers";
import Avatar from '@material-ui/core/Avatar';
import Chip from '@material-ui/core/Chip';
import DateFnsUtils from "@date-io/date-fns";
import dateFnsFormat from "date-fns/format";
import * as BenefitPlanConstants from "./BenefitPlanConstants";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
export default function BenefitPlanSearchForm(props) {
  const [selectedEndDate, setSelectedEndDate] = React.useState("");
  const [selectedBeginDate, setSelectedBeginDate] = React.useState("");
	const [charactersRem, setCharactersRem] = React.useState(40);
  const [
    { showBeginDateError, showEndDateError },
    setShowError,
  ] = React.useState(false);

  React.useEffect(() => {
    if (props.values.beginDate !== "" && props.values.endDate !== "") {
      setSelectedEndDate(props.values.endDate);
      setSelectedBeginDate(props.values.beginDate);
    } else {
      setSelectedEndDate("12/31/9999");
      setSelectedBeginDate("");
    }
    setCharactersRem(40-props.values.benefitPlanDesc.length);

  }, [props.updateTest]);

  const formatDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const handleBeginDateChange = (d) => {
    setSelectedBeginDate(d);

    let finaldate = formatDate(d);

    props.handleDCDtChange("beginDate", finaldate);
  };

  const handleBeginDateText = (thruBeginText) => {
    setSelectedBeginDate(thruBeginText.target.value);
    setBeginDatePress(true);
  };

  const handleEndDateChange = (d) => {
    setSelectedEndDate(d);

    let finaldate = formatDate(d);

    props.handleDCDtChange("endDate", finaldate);
  };

  
const checkCharacterRem = (event) => {
  setCharactersRem(40 - event.target.value.length);
}


  const handleEndDateText = (lastDateText) => {
    setSelectedEndDate(lastDateText.target.value);
    setEndDatePress(true);
  };

  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="bgn_date_update"
              label="Plan Begin Date"
              format="MM/dd/yyyy"
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
              placeholder="mm/dd/yyyy"
              value={selectedBeginDate === "" ? null : selectedBeginDate}
              onChange={handleBeginDateChange}
              // onKeyUp={handleBeginDateText}
              helperText={
                props.errors.planBeginDateError
                  ? ErrorConst.Begin_Date_Error
                  : props.errors.beginDtInvalidErr
                  ? ErrorConst.Plan_Begin_Date_Error
                  : props.errors.showBgdtGTEnddtErr
                  ? ErrorConst.Plan_Begin_Date_Error
                  : null
              }
              error={
                props.errors.planBeginDateError
                  ? ErrorConst.Begin_Date_Error
                  : props.errors.beginDtInvalidErr
                  ? ErrorConst.Plan_Begin_Date_Error
                  : props.errors.showBgdtGTEnddtErr
                  ? ErrorConst.Plan_Begin_Date_Error
                  : null
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </div>
        </MuiPickersUtilsProvider>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="end_date_update"
              label="Plan End Date"
              format="MM/dd/yyyy"
               
							maxDate={new Date('9999-12-31T13:00:00.000+0000')}
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
              placeholder="mm/dd/yyyy"
              value={selectedEndDate === "" ? null : selectedEndDate}
              onChange={handleEndDateChange}
              // onKeyUp={handleEndDateText}
              helperText={
                props.errors.planEndDateError
                  ? ErrorConst.End_Date_Error
                  : props.errors.endDtInvalidErr
                  ? ErrorConst.Plan_End_Date_Error
                  : null
              }
              error={
                props.errors.planEndDateError
                  ? ErrorConst.End_Date_Error
                  : props.errors.endDtInvalidErr
                  ? ErrorConst.Plan_End_Date_Error
                  : null
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </div>
        </MuiPickersUtilsProvider>
      
        <div className="form-inner-block">
          <div className="mui-custom-form with-select input-md">
            <TextField
              required
              id="lob_update"
              select
              required
              label="LOB"
              disabled={props.edit}
              value={props.values.lobId ? props.values.lobId : "-1"}
              inputProps={{ maxLength: 60 }}
              onChange={props.handleChanges("lobId")}
              placeholder=""
              helperText={
                props.errors.lobIdError ? ErrorConst.LOB_ID_Error : null
              }
              error={props.errors.lobIdError ? ErrorConst.LOB_ID_Error : null}
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
            >
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
              </MenuItem>
              {props.dropdowns &&
                Object.keys(props.dropdowns).length > 0 &&
                props.dropdowns["Claims#R_LOB_CD"] &&
                props.dropdowns["Claims#R_LOB_CD"].length > 0 &&
                props.dropdowns["Claims#R_LOB_CD"].map((each) => (
                  <MenuItem selected key={each.code} value={each.code}>
                    {each.description}
                  </MenuItem>
                ))}
              {/* <MenuItem selected key="MED-Medicaid" value="MED">MED-Medicaid</MenuItem> */}
            </TextField>
          </div>
          <div className="mui-custom-form input-md field-md md-field-lg">
            <TextField
              id="lob_description_update"
              label="LOB Description"
              value={props.values.lobDesc}
              disabled
              inputProps={{ maxLength: 50 }}
              onChange={props.handleChanges("lobDesc")}
              placeholder=""
              InputLabelProps={{
                shrink: true,
              }}
            />
          </div>
          <div className="mui-custom-form input-md wid-100">
            <TextField
              id="business_unit_update"
              label="Business Unit"
              value={props.values.benefitPlanAddlDesc}
              inputProps={{ maxLength: 320 }}
              onChange={props.handleChanges("benefitPlanAddlDesc")}
              placeholder=""
              InputLabelProps={{
                shrink: true,
              }}
              helperText={
                props.errors.businessUnitdSpclCharErr
                  ? ErrorConst.BENEFIT_BUSS_UNIT_SPCL_CHAR_ERR
                  : null
              }
              error={
                props.errors.businessUnitdSpclCharErr
                  ? ErrorConst.BENEFIT_BUSS_UNIT_SPCL_CHAR_ERR
                  : null
              }
            />
          </div>
          <div className="mui-custom-form input-md">
            <TextField
              id="benefit_plan_id_update"
              label="Benefit Plan ID"
              disabled={props.edit}
              value={props.values.benefitPlanID}
              inputProps={{ maxLength: 6 }}
              onChange={props.handleChanges("benefitPlanID")}
              placeholder=""
              helperText={
                props.errors.benefitPlanIDError
                  ? ErrorConst.Benefit_Plan_ID_Error
                  : props.errors.benefitPlanIdSpclCharErr
                    ? ErrorConst.BENEFIT_PLAN_ID_SPCL_CHAR_ERR
                    : null
              }
              error={
                props.errors.benefitPlanIDError
                  ? ErrorConst.Benefit_Plan_ID_Error
                  : props.errors.benefitPlanIdSpclCharErr
                    ? ErrorConst.BENEFIT_PLAN_ID_SPCL_CHAR_ERR
                    : null
              }
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
            />
          </div>
          <div className="mui-custom-form input-md field-md md-field-lg">
            <TextField
              id="benefit_plan_description_update"
              label="Benefit Plan Description"
              value={props.values.benefitPlanDesc}
              inputProps={{ maxLength: 40 }}
              onKeyUp={checkCharacterRem}
              onChange={props.handleChanges("benefitPlanDesc")}
              placeholder=""
              helperText={
                props.errors.benefitPlanDescError
                  ? ErrorConst.Benefit_Plan_Desc_Error
                  : props.errors.planDescSpclCharErr ? ErrorConst.BENEFIT_PLAN_DESC_SPCL_CHAR_ERR
                    : null
              }
              error={
                props.errors.benefitPlanDescError
                  ? ErrorConst.Benefit_Plan_Desc_Error
                  : props.errors.planDescSpclCharErr ? ErrorConst.BENEFIT_PLAN_DESC_SPCL_CHAR_ERR
                    : null
              }
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
            />
					<div className="mt-1"><Chip avatar={<Avatar>{charactersRem}</Avatar>} label="Characters remaining" /></div>

          </div>
        </div>

      </div>

      <div className="clearfix" />
    </form>
  );
}
