export const BenefitPlanID_Error = "Benefit Plan ID is a required field.";
export const BenefitPlanID_Err = "Benefit Plan ID is required.";
export const BenefitPlanType_Error = "Benefit Plan Type is a required field.";
export const BenefitPlanDescription_Error = "Description is a required field.";
export const DATE_RANGE_ERROR = 'End date must be after the begin date.';
export const Begin_Date_Error = "Begin Date is required.";
export const End_Date_Error = "End Date is required.";
export const BenefitPlan_Error = "A minimum of 2 characters must be entered for a starts with search and a contains search.";
export const Description_Error = "A minimum of 2 characters must be entered for a starts with search and a contains search.";
export const ERROR_OCCURED_DURING_TRANSACTION = "There was an error processing the request. Please retry the transaction.";
export const NO_RECORDS_FOUND = "No records found for the search criteria entered.";
//export const NO_RECORDS_FOUND_SEARCH = "No records found for the search criteria entered.";

export const Short_Desc_Error = "Short Description is required.";
export const Long_Desc_Error = "Long Description is required.";

export const OneCI_Error = "At least one detail row is required in Codes and Indicators.";
export const Age_Year_Error = "The valid range for the year portion of the age is between 0 and 999.";
export const Age_Month_Error = "The valid range for the month portion of the age is between 0 and 11.";
export const Diag_Code_Req_Error = "Diagnosis Code is required.";
export const Icd_Ver_Req_Error = "ICD Version is required.";
export const Invalid_Begin_Date_Error = "Begin Date that was entered is invalid.";
export const Invalid_End_Date_Error = "The End Date that was entered is invalid.";
export const Header_Dates_ReqBfr_Error = "Header Dates are required before the detail lines can be save.";
export const Plan_Invalid_Begin_Date_Error = "Plan Begin Date entered is invalid.";
export const Plan_Invalid_End_Date_Error = "Plan End Date entered is invalid.";
