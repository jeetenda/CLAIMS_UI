import React, { useState, useEffect, useRef, forwardRef,useImperativeHandle } from "react";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import DateFnsUtils from "@date-io/date-fns";
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import dateFnsFormat from "date-fns/format";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import * as moment from "moment";
import "moment-range";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import CoInsLmtTableComponent from "./CoInsLmtTable";
import { Button } from "react-bootstrap";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker,
} from "@material-ui/pickers";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import axios from "axios";
import isSpecialcharecter from './validations';
import { Link } from 'react-router-dom';

function BenefitPlanCoInsLmt(props,ref) {
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [coInsBenefitPlan, setcoInsBenefitPlan] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  const [success, setSuccess] = useState(false);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);

  const [newCoInsPlan, setnewCoInsPlan] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    mapSetID: "-1",
    seqNum: "",
    benefitPlanStatusNetworkCode: "",
    typeCode: "-1",
    indAmount: "",
    indPlusAmount: "",
    famAmount: "",
    overExceptionCode: "",
    metExceptionCode: "",
    bpNetworkCodeDesc: "",
    typeCodeDesc: "",
  });

  const [resetCoInsPlan, setresetCoInsPlan] = useState({
    beginDate: "",
    endDate: "",
    mapSetID: "-1",
    seqNum: "",
    benefitPlanStatusNetworkCode: "",
    typeCode: "-1",
    indAmount: "",
    indPlusAmount: "",
    famAmount: "",
    overExceptionCode: "",
    metExceptionCode: "",
    bpNetworkCodeDesc: "",
    typeCodeDesc: "",
  });

  const [selectedCovEndDate, setSelectedCovEndDate] = React.useState("");
  const [selectedCovBeginDate, setSelectedCovBeginDate] = React.useState("");
  const [
    {
      showHeaderDateErr,
      showHeaderEndDateErr,
      showBeginDateError,
      showEndDateError,
      beginDtInvalidErr,
      endDtInvalidErr,
      showRankOverlapErr,
      showNetworkOverlapErr,
      networkStatusError,
      mapIdErr,
      rankError,
      showRankErrSpe,
      showRankErrZero,
      showBgdtGTEnddtErr,
      RankErr,
      typeCodeErr,
      invalidIndAmntErr,
      invalidIndAmntmaxErr,
      indAmntErr,
      invalidIndPlusAmntErr,
      invalidIndPlusAmntmaxErr,
      invalidIndFamAmntErr,
      invalidIndFamAmntmaxErr,
      INVALID_LMT_MET_EXC_CODE,
      INVALID_LMT_MET_EXC_CODE_SPL,
      INVALID_LMT_OVR_EXC_CODE,
      INVALID_LMT_OVR_EXC_CODE_SPE,
      showBasicErr,
    },
    setShowError,
  ] = React.useState(false);

  const formatDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const formatCovDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const handelDateRngeWithin = (
    rangeStartDate,
    rangeEndDate,
    withInStartDate,
    withInEndDate
  ) => {
    if (rangeStartDate && rangeEndDate && withInStartDate && withInEndDate) {
      const range = moment().range(
        new Date(rangeStartDate),
        new Date(rangeEndDate)
      );
      return (
        range.contains(new Date(withInStartDate)) &&
        range.contains(new Date(withInEndDate))
      );
    }
    return false;
  };

  const handelDateRngeOverlap = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate
  ) => {
    const range1 = moment().range(
      new Date(initalStartDate),
      new Date(initialEndDate)
    );
    const range2 = moment().range(
      new Date(secondaryStartDate),
      new Date(secondaryEndDate)
    );
    return range1.overlaps(range2);
  };

  const handelDateNetworkArrayOverlap = (
    initalStartDate,
    initialEndDate,
    networkId,
    networkstatus,
    typeCode,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (
            each.mapSetID == networkId &&
            each.benefitPlanStatusNetworkCode == networkstatus &&
            each.beginDate == initalStartDate &&
            each.typeCode == typeCode
          ) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRankArrayOverlap = (
    initalStartDate,
    initialEndDate,
    Rank,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (each.seqNum == Rank) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handleCoverageBeginDateChange = (d) => {
    setSelectedCovBeginDate(d);
    let finaldate = formatCovDate(d);
    props.handleCovDtChange("beginDate", finaldate);
  };

  const handleCoverageEndDateChange = (d) => {
    setSelectedCovEndDate(d);
    let finaldate = formatCovDate(d);
    props.handleCovDtChange("endDate", finaldate);
  };

  const handelInputChange = (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, coinsurancelimitTab: true })
    if (event.target.name === "benefitPlanStatusNetworkCode") {
      setnewCoInsPlan({
        ...newCoInsPlan,
        [event.target.name]: event.target.value,
        bpNetworkCodeDesc: event.nativeEvent.target.textContent,
      });
    } else if (event.target.name === "typeCode") {
      setnewCoInsPlan({
        ...newCoInsPlan,
        [event.target.name]: event.target.value,
        typeCodeDesc: event.nativeEvent.target.textContent,
      });
    } else {
      setnewCoInsPlan({
        ...newCoInsPlan,
        [event.target.name]: event.target.value,
      });
    }
  };

  const handelDateChange = (type, name) => (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, coinsurancelimitTab: true })
        if (type === "setnewCoInsPlan") {
      setnewCoInsPlan({ ...newCoInsPlan, [name]: date });
    }
  };

  const validateExcCode = (c) => {
    return new Promise((resolve, reject) => {
      setspinnerLoader(true);
      axios
        .get(serviceEndPoint.BENEFIT_PLAN_EXC_CODE_VALIDATION + c +"/"+props.formValues.lobId)
        .then((response) => {
          if (response.data.data && response.data.data.excCodeDesc) {
            resolve(response.data.data.excCodeDesc);
          } else {
            resolve(false);
          }
        })
        .catch((error) => {
          resolve(false);
        })
        .then(() => {
          setspinnerLoader(false);
        });
    });
  };

  const handelClick = async () => {
    const tableData = props.newCoInsState;
    let errors = {};
    //webninja
    setSuccess(false);
    setDeleteSuccess(false);
    // props.seterrorMessages([]);
    // setSuccessMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newCoInsPlan.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetCoInsPlan.beginDate) ||
          e.endDate != formatDate(resetCoInsPlan.endDate) ||
          e.seqNum != resetCoInsPlan.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newCoInsPlan.beginDate),
      formatDate(newCoInsPlan.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newCoInsPlan.beginDate),
      formatDate(newCoInsPlan.endDate),
      newCoInsPlan.mapSetID,
      newCoInsPlan.benefitPlanStatusNetworkCode,
      newCoInsPlan.typeCode,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newCoInsPlan.beginDate),
      formatDate(newCoInsPlan.endDate),
      newCoInsPlan.seqNum,
      overlapArray
    );
    let metExcnDesc = await validateExcCode(newCoInsPlan.metExceptionCode);
   let  ovrExcnDesc = await validateExcCode(newCoInsPlan.overExceptionCode);
    setShowError({
      showBasicErr:
        props.coInsuranceData.length != 0
          ? false
          : (() => {
              reqFieldArr.push([
                "Atleast One Record Should Exist For Co-Insurance",
              ]);
              return true;
            })(),
      showBeginDateError: newCoInsPlan.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newCoInsPlan.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        formatDate(newCoInsPlan.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newCoInsPlan.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
      mapIdErr:
        newCoInsPlan.mapSetID && newCoInsPlan.mapSetID != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      networkStatusError:
        newCoInsPlan.benefitPlanStatusNetworkCode &&
        newCoInsPlan.benefitPlanStatusNetworkCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      rankError: newCoInsPlan.seqNum
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Rank_Error);
            return true;
          })(),
      showRankErrSpe: !isNaN(parseInt(newCoInsPlan.seqNum))
        ? false
        : (() => {
          if (newCoInsPlan.seqNum.length !== 0) {
            reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
            return true;
          } else return false;
        })(),
      showRankErrZero: newCoInsPlan.seqNum < 1 && newCoInsPlan.seqNum.length
        ? (() => {
          reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
          return true;
        })()
        : false,
      showBgdtGTEnddtErr:
        new Date(newCoInsPlan.beginDate) <= new Date(newCoInsPlan.endDate)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })(),
      // RankErr: !(
      //   isNaN(newCoInsPlan.seqNum) || parseInt(newCoInsPlan.seqNum) > 99999
      // )
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.Invalid_Rank_Error);
      //       return true;
      //     })(),
      // showHeaderDateErr:
      //   !headerTange && newCoInsPlan.beginDate
      //     ? (() => {
      //         reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk);
      //         return true;
      //       })()
      //     : false,
          showHeaderDateErr:
          !(new Date(newCoInsPlan.beginDate) >= new Date(props.formValues.beginDate) && new Date(newCoInsPlan.beginDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                );
                return true;
              })()
            : false,
          showHeaderEndDateErr:
          !(new Date(newCoInsPlan.endDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_End_Date_Err 
                );
                return true;
              })()
            : false,
      showRankOverlapErr:
        newCoInsPlan.beginDate &&
        newCoInsPlan.endDate &&
        newCoInsPlan.seqNum &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,
      typeCodeErr:
        newCoInsPlan.typeCode && newCoInsPlan.typeCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.TypeCodeInsError);
              return true;
            })(),
      // invalidIndAmntErr: !(
      //   isNaN(parseInt(newCoInsPlan.indAmount)) ||
      //   parseInt(newCoInsPlan.indAmount) > 99999
      // )
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.Invalid_Ind_Amount);
      //       return true;
      //     })(),

      // indAmntErr: newCoInsPlan.indAmount
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
      //       return true;
      //     })(),
      // invalidIndPlsAmntErr: !(
      //   (isNaN(parseInt(newCoInsPlan.indPlusAmount)) ||
      //     parseInt(newCoInsPlan.indPlusAmount) > 99999) &&
      //   newCoInsPlan.indPlusAmount
      // )
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.Invalid_Ind_Pls_Amount);
      //       return true;
      //     })(),
      // invalidFamAmntErr: !(
      //   (isNaN(parseInt(newCoInsPlan.famAmount)) ||
      //     parseInt(newCoInsPlan.famAmount) > 99999) &&
      //   newCoInsPlan.famAmount
      // )
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.Invalid_Fam_Amount);
      //       return true;
      //     })(),
      indAmntErr: newCoInsPlan.indAmount
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
            return true;
          })(),
      invalidIndAmntErr: !(newCoInsPlan.indAmount)
        ? false
        : !isNaN(parseInt(newCoInsPlan.indAmount))
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
            return true;
          })(),
      invalidIndAmntmaxErr: !(newCoInsPlan.indAmount)
        ? false
        : !(parseInt(newCoInsPlan.indAmount) > 99999999999)
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.IND_LIMIT_MAX);
            return true;
          })(),
      //Ind plus
      invalidIndPlusAmntErr:
        !(newCoInsPlan.indPlusAmount)
          ? false
          : !isNaN(parseInt(newCoInsPlan.indPlusAmount))
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
              return true;
            })(),
      invalidIndPlusAmntmaxErr:
      !(newCoInsPlan.indPlusAmount)
          ? false
          : !(parseInt(newCoInsPlan.indPlusAmount) > 99999999999)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.IND_PLUS_LIMIT_MAX);
              return true;
            })(),
      //Fam limit

      invalidIndFamAmntErr:
        !(newCoInsPlan.famAmount)
          ? false
          : !isNaN(parseInt(newCoInsPlan.famAmount))
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
              return true;
            })(),
      invalidIndFamAmntmaxErr:
        !(newCoInsPlan.famAmount)
          ? false
          : !(parseInt(newCoInsPlan.famAmount) > 99999999999)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.IND_FAM_LIMIT_MAX);
              return true;
            })(),
      showNetworkOverlapErr:
        newCoInsPlan.beginDate &&
        newCoInsPlan.endDate &&
        newCoInsPlan.mapSetID &&
        newCoInsPlan.benefitPlanStatusNetworkCode &&
        newCoInsPlan.typeCode &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.PLAN_LIMIT_NETWORK_MAP_OVERLAP);
              return true;
            })()
          : false,
          INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(newCoInsPlan.metExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE); return true; })(),
            INVALID_LMT_MET_EXC_CODE: newCoInsPlan.metExceptionCode ? (() => {
                if(!isSpecialcharecter(newCoInsPlan.metExceptionCode)){                     
                   if (!metExcnDesc) {                       
                       reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                       return true;
                   }else { return false; }                 
                
                }                 
               })() : false,
           INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(newCoInsPlan.overExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE); return true; })(),
           INVALID_LMT_OVR_EXC_CODE: newCoInsPlan.overExceptionCode ? (() => {
               if(!isSpecialcharecter(newCoInsPlan.overExceptionCode)){                     
                  if (!ovrExcnDesc) {                       
                   reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                      return true;
                  }else { return false; }                 
               
               }                 
              })() : false, 
    });
    props.setShowError({
      planBeginDateError: props.formValues.beginDate ? false : true,
      planEndDateError: props.formValues.endDate ? false : true,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    if (reqFieldArr.length) {
      setShowError(errors);
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    const data = {
      auditUserID:
        newCoInsPlan.row && newCoInsPlan.row.auditUserID
          ? newCoInsPlan.row.auditUserID
          : "wf_NH_MC_BP_SETUPV99",
      auditTimeStamp:
        newCoInsPlan.row && newCoInsPlan.row.auditTimeStamp
          ? newCoInsPlan.row.auditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
      addedAuditUserID:
        newCoInsPlan.row && newCoInsPlan.row.addedAuditUserID
          ? newCoInsPlan.row.addedAuditUserID
          : "wf_NH_MC_BP_SETUPV99",
      addedAuditTimeStamp:
        newCoInsPlan.row && newCoInsPlan.row.addedAuditTimeStamp
          ? newCoInsPlan.row.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
      versionNo:
        newCoInsPlan.row && newCoInsPlan.row.versionNo
          ? newCoInsPlan.row.versionNo
          : 0,
      dbRecord:
        newCoInsPlan.row && newCoInsPlan.row.dbRecord
          ? newCoInsPlan.row.dbRecord
          : false,
      sortColumn:
        newCoInsPlan.row && newCoInsPlan.row.sortColumn
          ? newCoInsPlan.row.sortColumn
          : null,
      auditKeyList:
        newCoInsPlan.row && newCoInsPlan.row.auditKeyList
          ? newCoInsPlan.row.auditKeyList
          : [],
      auditKeyListFiltered:
        newCoInsPlan.row && newCoInsPlan.row.auditKeyListFiltered
          ? newCoInsPlan.row.auditKeyListFiltered
          : false,
      beginDate: formatDate(newCoInsPlan.beginDate),
      seqNum: newCoInsPlan.seqNum,
      benefitPlanStatusNetworkCode: newCoInsPlan.benefitPlanStatusNetworkCode,
      endDate: formatDate(newCoInsPlan.endDate),
      mapSetID: newCoInsPlan.mapSetID,
      typeCode: newCoInsPlan.typeCode,
      indAmount: newCoInsPlan.indAmount== "" ? "0.00" : newCoInsPlan.indAmount,
      indPlusAmount: newCoInsPlan.indPlusAmount== "" ? "0.00" : newCoInsPlan.indPlusAmount,
      famAmount: newCoInsPlan.famAmount== "" ? "0.00" : newCoInsPlan.famAmount,
      maxAmount: newCoInsPlan.indAmount,
      overExceptionCode: newCoInsPlan.overExceptionCode,
      metExceptionCode: newCoInsPlan.metExceptionCode,
      metExcnDesc: metExcnDesc ? metExcnDesc : "",
      ovrExcnDesc: ovrExcnDesc ? ovrExcnDesc : "",
      benefitPlanCoInsLMTID:
        newCoInsPlan.row && newCoInsPlan.row.benefitPlanCoInsLMTID
          ? newCoInsPlan.row.benefitPlanCoInsLMTID
          : null,
    };

    // if(newCoInsPlan.indAmount && newCoInsPlan.indPlusAmount && newCoInsPlan.famAmount){
    // data.maxAmount = newCoInsPlan.indAmount+'/'+newCoInsPlan.indPlusAmount+ '/' +newCoInsPlan.famAmount;
    // }else if (newCoInsPlan.indAmount && newCoInsPlan.indPlusAmount){
    //     data.maxAmount = newCoInsPlan.indAmount+'/'+newCoInsPlan.indPlusAmount;
    // }else if(newCoInsPlan.indAmount && newCoInsPlan.famAmount){
    //     data.maxAmount = newCoInsPlan.indAmount+'/'+newCoInsPlan.famAmount;
    // }
    newCoInsPlan.index > -1
      ? (tableData[newCoInsPlan.index] = data)
      : tableData.push(data);
    props.setNewCoInsLmt(tableData);
    setSuccess(true);
    props.seterrorMessages([]);
    setnewCoInsPlan({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      seqNum: "",
      benefitPlanStatusNetworkCode: "",
      typeCode: "-1",
      indAmount: "",
      indPlusAmount: "",
      famAmount: "",
      overExceptionCode: "",
      metExceptionCode: "",
    });
    setresetCoInsPlan({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      seqNum: "",
      benefitPlanStatusNetworkCode: "",
      typeCode: "-1",
      indAmount: "",
      indPlusAmount: "",
      famAmount: "",
      overExceptionCode: "",
      metExceptionCode: "",
    });
    setcoInsBenefitPlan(false);
    props.setTabChangeValue({ ...props.tabChangeValue, coinsurancelimitTab: false })

  };

  const handelResetClick = () => {
    props.seterrorMessages([]);
    setnewCoInsPlan(resetCoInsPlan);
    setShowError(false);
    props.setTabChangeValue({ ...props.tabChangeValue, coinsurancelimitTab: false })
  };

  const handelCandelFunction = () => {
    setcoInsBenefitPlan(false);
    setShowError(false);
    setDialogOpen(false);
    setDialogType("");
  };

  const handelDeleteClick = () => {
    setSuccess(false)
    const tableData = props.newCoInsState;
    if (newCoInsPlan.row && newCoInsPlan.row.benefitPlanCoInsLMTID) {
      let deleteData = props.deleteCoInsLmt;
      deleteData.push({
        auditUserID:
          newCoInsPlan.row && newCoInsPlan.row.auditUserID
            ? newCoInsPlan.row.auditUserID
            : "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp:
          newCoInsPlan.row && newCoInsPlan.row.auditTimeStamp
            ? newCoInsPlan.row.auditTimeStamp
            : "2013-01-31T00:23:48.000+0000",
        addedAuditUserID:
          newCoInsPlan.row && newCoInsPlan.row.addedAuditUserID
            ? newCoInsPlan.row.addedAuditUserID
            : "wf_NH_MC_BP_SETUPV99",
        addedAuditTimeStamp:
          newCoInsPlan.row && newCoInsPlan.row.addedAuditTimeStamp
            ? newCoInsPlan.row.addedAuditTimeStamp
            : "2013-01-31T00:23:48.000+0000",
        versionNo:
          newCoInsPlan.row && newCoInsPlan.row.versionNo
            ? newCoInsPlan.row.versionNo
            : 0,
        dbRecord:
          newCoInsPlan.row && newCoInsPlan.row.dbRecord
            ? newCoInsPlan.row.dbRecord
            : false,
        sortColumn:
          newCoInsPlan.row && newCoInsPlan.row.sortColumn
            ? newCoInsPlan.row.sortColumn
            : null,
        auditKeyList:
          newCoInsPlan.row && newCoInsPlan.row.auditKeyList
            ? newCoInsPlan.row.auditKeyList
            : [],
        auditKeyListFiltered:
          newCoInsPlan.row && newCoInsPlan.row.auditKeyListFiltered
            ? newCoInsPlan.row.auditKeyListFiltered
            : false,
        beginDate: formatDate(newCoInsPlan.beginDate),
        seqNum: newCoInsPlan.seqNum,
        benefitPlanStatusNetworkCode: newCoInsPlan.benefitPlanStatusNetworkCode,
        endDate: formatDate(newCoInsPlan.endDate),
        mapSetID: newCoInsPlan.mapSetID,
        typeCode: newCoInsPlan.typeCode,
        indAmount: newCoInsPlan.indAmount,
        indPlusAmount: newCoInsPlan.indPlusAmount,
        famAmount: newCoInsPlan.famAmount,
        maxAmount: newCoInsPlan.indAmount,
        overExceptionCode: newCoInsPlan.overExceptionCode,
        metExceptionCode: newCoInsPlan.metExceptionCode,
        bpNetworkCodeDesc: newCoInsPlan.bpNetworkCodeDesc,
        typeCodeDesc: newCoInsPlan.typeCodeDesc,
        benefitPlanCoInsLMTID:
          newCoInsPlan.row && newCoInsPlan.row.benefitPlanCoInsLMTID
            ? newCoInsPlan.row.benefitPlanCoInsLMTID
            : null,
      });
      props.setDeleteCoInsLmt(deleteData);
    }
    tableData.splice(newCoInsPlan.index, 1);
    props.setNewCoInsLmt(tableData);
    setShowError(false);
    setnewCoInsPlan({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      seqNum: "",
      benefitPlanStatusNetworkCode: "",
      typeCode: "-1",
      indAmount: "",
      indPlusAmount: "",
      famAmount: "",
      overExceptionCode: "",
      metExceptionCode: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    setresetCoInsPlan({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      seqNum: "",
      benefitPlanStatusNetworkCode: "",
      typeCode: "-1",
      indAmount: "",
      indPlusAmount: "",
      famAmount: "",
      overExceptionCode: "",
      metExceptionCode: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    setcoInsBenefitPlan(false);
    setDialogOpen(false);
    setDialogType("");
    setDeleteSuccess(true);
  };

  
  const multiDelete = () => {
    setDialogOpen(false); setDialogType('');
    props.seterrorMessages([]);
    setSuccessMessages([]);
    if (selectDeleteArray.length > 0) {
        let CI = props.newCoInsState;
        selectDeleteArray.map((value, index) => {
          let curIndex = CI.findIndex(i => moment(i.beginDate).isSame(value.beginDate));
          CI.splice(curIndex,1);
        });
        props.setNewCoInsLmt(CI);
        props.setDeleteCoInsLmt(selectDeleteArray);
        setSelectDeleteArray([]);
        setDeleteSuccess(true);

    }
  }

  useImperativeHandle(ref, () => {
    return { validateFn };
  });

  const validateFn = () => {
    if (props.tabChangeValue.coinsurancelimitTab) {
      handelSaveValidationsCoinslmt();
    } 
    }

    const handelSaveValidationsCoinslmt = async() => {
      const tableData = props.newCoInsState;
      let errors = {};
      //webninja
      setSuccess(false);
      setDeleteSuccess(false);
      // props.seterrorMessages([]);
      // setSuccessMessages([]);
      let reqFieldArr = [];
      let overlapArray;
      if (newCoInsPlan.index > -1) {
        overlapArray = tableData.filter(
          (e) =>
            e.beginDate != formatDate(resetCoInsPlan.beginDate) ||
            e.endDate != formatDate(resetCoInsPlan.endDate) ||
            e.seqNum != resetCoInsPlan.seqNum
        );
      } else {
        overlapArray = tableData;
      }
      const headerTange = await handelDateRngeWithin(
        formatDate(props.formValues.beginDate),
        formatDate(props.formValues.endDate),
        formatDate(newCoInsPlan.beginDate),
        formatDate(newCoInsPlan.endDate)
      );
      const networkOverlap = await handelDateNetworkArrayOverlap(
        formatDate(newCoInsPlan.beginDate),
        formatDate(newCoInsPlan.endDate),
        newCoInsPlan.mapSetID,
        newCoInsPlan.benefitPlanStatusNetworkCode,
        newCoInsPlan.typeCode,
        overlapArray
      );
      const rankOverlap = await handelDateRankArrayOverlap(
        formatDate(newCoInsPlan.beginDate),
        formatDate(newCoInsPlan.endDate),
        newCoInsPlan.seqNum,
        overlapArray
      );
      let metExcnDesc = await validateExcCode(newCoInsPlan.metExceptionCode);
     let  ovrExcnDesc = await validateExcCode(newCoInsPlan.overExceptionCode);
      setShowError({
        showBasicErr:
          props.coInsuranceData.length != 0
            ? false
            : (() => {
                reqFieldArr.push([
                  "Atleast One Record Should Exist For Co-Insurance",
                ]);
                return true;
              })(),
        showBeginDateError: newCoInsPlan.beginDate
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Begin_Date_Error);
              return true;
            })(),
        showEndDateError: newCoInsPlan.endDate
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.End_Date_Error);
              return true;
            })(),
        beginDtInvalidErr:
          formatDate(newCoInsPlan.beginDate).toString() == "Invalid Date"
            ? (() => {
                reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
                return true;
              })()
            : false,
        endDtInvalidErr:
          formatDate(newCoInsPlan.endDate).toString() == "Invalid Date"
            ? (() => {
                reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
                return true;
              })()
            : false,
        mapIdErr:
          newCoInsPlan.mapSetID && newCoInsPlan.mapSetID != -1
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Map_Id_Error);
                return true;
              })(),
        networkStatusError:
          newCoInsPlan.benefitPlanStatusNetworkCode &&
          newCoInsPlan.benefitPlanStatusNetworkCode != -1
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Network_Status_Error);
                return true;
              })(),
        rankError: newCoInsPlan.seqNum
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })(),
        showRankErrSpe: !isNaN(parseInt(newCoInsPlan.seqNum))
          ? false
          : (() => {
            if (newCoInsPlan.seqNum.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
        showRankErrZero: newCoInsPlan.seqNum < 1 && newCoInsPlan.seqNum.length
          ? (() => {
            reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
            return true;
          })()
          : false,
        showBgdtGTEnddtErr:
          new Date(newCoInsPlan.beginDate) <= new Date(newCoInsPlan.endDate)
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
                return true;
              })(),
        // RankErr: !(
        //   isNaN(newCoInsPlan.seqNum) || parseInt(newCoInsPlan.seqNum) > 99999
        // )
        //   ? false
        //   : (() => {
        //       reqFieldArr.push(ErrorConst.Invalid_Rank_Error);
        //       return true;
        //     })(),
        showHeaderDateErr:
          !headerTange && newCoInsPlan.beginDate
            ? (() => {
                reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk);
                return true;
              })()
            : false,
            showHeaderEndDateErr:
            !(new Date(newCoInsPlan.endDate) <= new Date(props.formValues.endDate))
              ? (() => {
                  reqFieldArr.push(
                    ErrorConst.Fall_In_Header_End_Date_Err 
                  );
                  return true;
                })()
              : false,
            // End header date error
        showRankOverlapErr:
          newCoInsPlan.beginDate &&
          newCoInsPlan.endDate &&
          newCoInsPlan.seqNum &&
          rankOverlap
            ? (() => {
                reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
                return true;
              })()
            : false,
        typeCodeErr:
          newCoInsPlan.typeCode && newCoInsPlan.typeCode != -1
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.TypeCodeInsError);
                return true;
              })(),
        // invalidIndAmntErr: !(
        //   isNaN(parseInt(newCoInsPlan.indAmount)) ||
        //   parseInt(newCoInsPlan.indAmount) > 99999
        // )
        //   ? false
        //   : (() => {
        //       reqFieldArr.push(ErrorConst.Invalid_Ind_Amount);
        //       return true;
        //     })(),
  
        // indAmntErr: newCoInsPlan.indAmount
        //   ? false
        //   : (() => {
        //       reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
        //       return true;
        //     })(),
        // invalidIndPlsAmntErr: !(
        //   (isNaN(parseInt(newCoInsPlan.indPlusAmount)) ||
        //     parseInt(newCoInsPlan.indPlusAmount) > 99999) &&
        //   newCoInsPlan.indPlusAmount
        // )
        //   ? false
        //   : (() => {
        //       reqFieldArr.push(ErrorConst.Invalid_Ind_Pls_Amount);
        //       return true;
        //     })(),
        // invalidFamAmntErr: !(
        //   (isNaN(parseInt(newCoInsPlan.famAmount)) ||
        //     parseInt(newCoInsPlan.famAmount) > 99999) &&
        //   newCoInsPlan.famAmount
        // )
        //   ? false
        //   : (() => {
        //       reqFieldArr.push(ErrorConst.Invalid_Fam_Amount);
        //       return true;
        //     })(),
        indAmntErr: newCoInsPlan.indAmount
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
              return true;
            })(),
        invalidIndAmntErr: !(newCoInsPlan.indAmount)
          ? false
          : !isNaN(parseInt(newCoInsPlan.indAmount))
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
              return true;
            })(),
        invalidIndAmntmaxErr: !(newCoInsPlan.indAmount)
          ? false
          : !(parseInt(newCoInsPlan.indAmount) > 99999999999)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.IND_LIMIT_MAX);
              return true;
            })(),
        //Ind plus
        invalidIndPlusAmntErr:
          !(newCoInsPlan.indPlusAmount)
            ? false
            : !isNaN(parseInt(newCoInsPlan.indPlusAmount))
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
                return true;
              })(),
        invalidIndPlusAmntmaxErr:
        !(newCoInsPlan.indPlusAmount)
            ? false
            : !(parseInt(newCoInsPlan.indPlusAmount) > 99999999999)
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.IND_PLUS_LIMIT_MAX);
                return true;
              })(),
        //Fam limit
  
        invalidIndFamAmntErr:
          !(newCoInsPlan.famAmount)
            ? false
            : !isNaN(parseInt(newCoInsPlan.famAmount))
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
                return true;
              })(),
        invalidIndFamAmntmaxErr:
          !(newCoInsPlan.famAmount)
            ? false
            : !(parseInt(newCoInsPlan.famAmount) > 99999999999)
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.IND_FAM_LIMIT_MAX);
                return true;
              })(),
        showNetworkOverlapErr:
          newCoInsPlan.beginDate &&
          newCoInsPlan.endDate &&
          newCoInsPlan.mapSetID &&
          newCoInsPlan.benefitPlanStatusNetworkCode &&
          newCoInsPlan.typeCode &&
          networkOverlap
            ? (() => {
                reqFieldArr.push(ErrorConst.PLAN_LIMIT_NETWORK_MAP_OVERLAP);
                return true;
              })()
            : false,
            INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(newCoInsPlan.metExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE); return true; })(),
              INVALID_LMT_MET_EXC_CODE: newCoInsPlan.metExceptionCode ? (() => {
                  if(!isSpecialcharecter(newCoInsPlan.metExceptionCode)){                     
                     if (!metExcnDesc) {                       
                         reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                         return true;
                     }else { return false; }                 
                  
                  }                 
                 })() : false,
             INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(newCoInsPlan.overExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE); return true; })(),
             INVALID_LMT_OVR_EXC_CODE: newCoInsPlan.overExceptionCode ? (() => {
                 if(!isSpecialcharecter(newCoInsPlan.overExceptionCode)){                     
                    if (!ovrExcnDesc) {                       
                     reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                        return true;
                    }else { return false; }                 
                 
                 }                 
                })() : false, 
      });
      props.setShowError({
        planBeginDateError: props.formValues.beginDate ? false : true,
        planEndDateError: props.formValues.endDate ? false : true,
      });
  
      if (reqFieldArr.length) {
        props.seterrorMessages(reqFieldArr);
        return false;
      }
  
      if (reqFieldArr.length) {
        setShowError(errors);
        props.seterrorMessages(reqFieldArr);
        return false;
      }
  
     


    }
    
  const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
  const BPCOIrefdiv1 = useRef(null);
  const BPCIscrolltoViewedit = () => {
    setTimeout(function () {
      scrollToRef(BPCOIrefdiv1);
    }.bind(this), 500);
  };

  return (
    <>
      <div className="pos-relative">{/*webninja*/}</div>
      <Dialog
        open={dialogOpen}
        onClose={() => {
          setDialogOpen(false);
          setDialogType("");
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
      <DialogContentText id="alert-dialog-description">
        {dialogType == "Delete" || dialogType == "multiDelete"
          ? "Are you sure that you want to Delete."
          : dialogType == "Cancel" 
          ? "Changes you made may not be saved." : ""}
      </DialogContentText>
    </DialogContent>
    <DialogActions>
        <Button title="Ok" onClick={() => {
          dialogType == "Delete"
            ? handelDeleteClick() :
          dialogType == "multiDelete"
            ? multiDelete()
          : handelCandelFunction();
        }} color="primary" className="btn btn-success">
            Ok
        </Button>
        <Button title="Cancel"  onClick={() => { setDialogOpen(false); setDialogType(''); }} color="primary" autoFocus>
            Cancel
        </Button>
    </DialogActions>
      </Dialog>
      
      {success ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.SUCCESSFULLY_SAVED_INFORMATION}
        </div>
      ) : null}
      {deleteSuccess ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
        </div>
      ) : null}
      <div className="tab-holder mt-3">
          <div className="tab-header">
            <h3 className="tab-heading float-left">
              Benefit Plan - Co-Insurance Limit
            </h3>
            <div className="float-right th-btnGroup">
            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => {setDialogOpen(true); setDialogType('multiDelete');}}>
                          <i className="fa fa-trash" />

                        </Button>
              <Button
                title="Add Co-Insurance Limit"
                variant="outlined"
                color="primary"
                className="btn btn-secondary btn-icon-only"
                onClick={() => {
                  if( props.majorValidations()){
                props.setTabChangeValue({ ...props.tabChangeValue, coinsurancelimitTab: true })
                  setcoInsBenefitPlan(true);
                  setSuccess(false);
                  setDeleteSuccess(false);
                  setnewCoInsPlan({
                    beginDate: "",
                    endDate: "12/31/9999",
                    mapSetID: "-1",
                    seqNum: "",
                    benefitPlanStatusNetworkCode: "-1",
                    typeCode: "-1",
                    indAmount: "",
                    indPlusAmount: "",
                    famAmount: "",
                    overExceptionCode: "",
                    metExceptionCode: "",
                    bpNetworkCodeDesc: "",
                    typeCodeDesc: "",
                  });
                  setresetCoInsPlan({
                    beginDate: "",
                    endDate: "12/31/9999",
                    mapSetID: "-1",
                    seqNum: "",
                    benefitPlanStatusNetworkCode: "-1",
                    typeCode: "-1",
                    indAmount: "",
                    indPlusAmount: "",
                    famAmount: "",
                    overExceptionCode: "",
                    metExceptionCode: "",
                    bpNetworkCodeDesc: "",
                    typeCodeDesc: "",
                  });
                  BPCIscrolltoViewedit();
                }}}
              >
                <i className="fa fa-plus" />
              </Button>
            </div>
            <div className="clearfix" />
          </div>
        <div className="clearfix mt-2">
          <CoInsLmtTableComponent
            setSuccess={setSuccess}
            tabelRowData={props.newCoInsState}
            setnewCoInsPlan={setnewCoInsPlan}
            setcoInsBenefitPlan={setcoInsBenefitPlan}
            setresetCoInsPlan={setresetCoInsPlan}
            setTabChangeValue = {props.setTabChangeValue}
            selectDeleteArray={selectDeleteArray}
            setSelectDeleteArray={setSelectDeleteArray}
            BPCIscrolltoViewedit={BPCIscrolltoViewedit}
          />
        </div>
      </div>

      {coInsBenefitPlan ? (
        <div
          className="tabs-container tabs-container-inner mt-0"
          ref={BPCOIrefdiv1}
        >
          <div className="tab-header">
            <h1 className="tab-heading float-left">
              {newCoInsPlan.index > -1
                ? "Edit Co-insurance Limit"
                : "New Co-insurance Limit"}
            </h1>
            <div className="float-right th-btnGroup">
              <Button
                title={newCoInsPlan.index > -1 ? "Update" : "Add"}
                variant="outlined"
                color="primary"
                className={newCoInsPlan.index > -1 ? "btn btn-ic btn-update" : "btn btn-ic btn-add"}
                onClick={() => handelClick()}
                disabled={props.privileges && !props.privileges.add? 'disabled':'' }
              >
                {newCoInsPlan.index > -1 ? "Update" : "Add"}
              </Button>
              {newCoInsPlan.index > -1 ? (
                 <Link to="MapDefinition" target="_blank" 
                  title="View/Edit Map"
                   className="btn btn-ic btn-view"
                 >
                  View/Edit Map
                  </Link>
                
              ) : null}
              {newCoInsPlan.index > -1 ? (
                <Button
                  title="Delete"
                  variant="outlined"
                  color="primary"
                  className="btn btn-ic btn-delete"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("Delete");
                  }}
                >
                  Delete
                </Button>
              ) : null}
              <Button
                title="Reset"
                variant="outlined"
                color="primary"
                className="btn btn-ic btn-reset"
                onClick={() => handelResetClick()}
              >
                Reset
              </Button>
              <Button
                title="Cancel"
                variant="outlined"
                color="primary"
                className="btn btn-cancel"
                onClick={() => {
                  setDialogOpen(true);
                  setDialogType("Cancel");
                  props.setTabChangeValue({ ...props.tabChangeValue, coinsurancelimitTab: false });
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
          <div className="tab-body-bordered mt-2">
            <div className="form-wrapper">
              {/* <h1 className="tab-heading float-left">Batch Data</h1> */}
              <div className="flex-block">
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                  <div
                    className="mui-custom-form input-md with-select"
                    style={{ marginLeft: "30px" }}
                  >
                    <KeyboardDatePicker
                      id="bgn_date_insuranceLmt_cost_share_tab"
                      name="beginDate"
                      required
                      label="Begin Date"
                      format="MM/dd/yyyy"
                      InputLabelProps={{
                        shrink: true,
                      }}
                      placeholder="mm/dd/yyyy"
                      value={
                        !newCoInsPlan.beginDate || newCoInsPlan.beginDate == ""
                          ? null
                          : newCoInsPlan.beginDate
                      }
                      onChange={handelDateChange(
                        "setnewCoInsPlan",
                        "beginDate"
                      )}
                      helperText={
                        showHeaderDateErr
                          ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                          : showBeginDateError
                          ? ErrorConst.BEGIN_DATE_ERROR
                          : beginDtInvalidErr
                          ? ErrorConst.Invalid_Begin_Date_Error
                          : showBgdtGTEnddtErr
                          ? ErrorConst.DATE_RANGE_ERROR
                          : null
                      }
                      error={
                        showHeaderDateErr
                          ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                          : showBeginDateError
                          ? ErrorConst.BEGIN_DATE_ERROR
                          : beginDtInvalidErr
                          ? ErrorConst.Invalid_Begin_Date_Error
                          : showBgdtGTEnddtErr
                          ? ErrorConst.DATE_RANGE_ERROR
                          : null
                      }
                      KeyboardButtonProps={{
                        "aria-label": "change date",
                      }}
                    />
                  </div>
                </MuiPickersUtilsProvider>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                  <div
                    className="mui-custom-form input-md with-select"
                    style={{ marginLeft: "30px" }}
                  >
                    <KeyboardDatePicker
                      id="end_date_insuranceLmt_cost_share_tab"
                      name="endDate"
                      required
                      label="End Date"
                      format="MM/dd/yyyy"
                       
							        maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                      InputLabelProps={{
                        shrink: true,
                      }}
                      placeholder="mm/dd/yyyy"
                      value={
                        !newCoInsPlan.endDate || newCoInsPlan.endDate == ""
                          ? null
                          : newCoInsPlan.endDate
                      }
                      onChange={handelDateChange("setnewCoInsPlan", "endDate")}
                      helperText={
                        showEndDateError
                          ? ErrorConst.END_DATE_ERROR
                          : endDtInvalidErr
                          ? ErrorConst.Invalid_End_Date_Error
                          : showHeaderEndDateErr
                          ? ErrorConst.Fall_In_Header_End_Date_Err
                          : null
                      }
                      error={
                        showEndDateError
                          ? ErrorConst.END_DATE_ERROR
                          : endDtInvalidErr
                          ? ErrorConst.Invalid_End_Date_Error
                          : showHeaderEndDateErr
                          ? ErrorConst.Fall_In_Header_End_Date_Err
                          : null
                      }
                      KeyboardButtonProps={{
                        "aria-label": "change date",
                      }}
                    />
                  </div>
                </MuiPickersUtilsProvider>
              </div>

              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    required
                    id="network_status_insuranceLmt_cost_share_tab"
                    select
                    name="benefitPlanStatusNetworkCode"
                    label="Network Status"
                    onChange={(event) => handelInputChange(event)}
                    value={newCoInsPlan.benefitPlanStatusNetworkCode}
                    helperText={
                      networkStatusError
                        ? ErrorConst.Network_Status_Error
                        : null
                    }
                    error={
                      networkStatusError
                        ? ErrorConst.Network_Status_Error
                        : null
                    }
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {/* <MenuItem value="INN">INN-In Network</MenuItem> */}
                    {props.dropdowns &&
                      props.dropdowns["R1#R_BP_NW_STAT_CD"] &&
                      props.dropdowns["R1#R_BP_NW_STAT_CD"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="map_id_insuranceLmt_cost_share_tab"
                    select
                    required
                    name="mapSetID"
                    label="Map ID"
                    onChange={(event) => handelInputChange(event)}
                    value={newCoInsPlan.mapSetID}
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                    helperText={mapIdErr ? ErrorConst.Map_Id_Error : null}
                    error={mapIdErr ? ErrorConst.Map_Id_Error : null}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.mapIdDropdown &&
                      props.mapIdDropdown.map((each) => (
                        <MenuItem
                          selected
                          key={each.mapsetId}
                          value={each.mapsetId}
                        >
                          {each.mapsetId}-{each.mapDesc}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>
              </div>

              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="limit_type_insuranceLmt_cost_share_tab"
                    select
                    required
                    name="typeCode"
                    label="Limit Type Code"
                    onChange={(event) => handelInputChange(event)}
                    value={newCoInsPlan.typeCode}
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                    helperText={
                      typeCodeErr ? ErrorConst.TypeCodeInsError : null
                    }
                    error={typeCodeErr ? ErrorConst.TypeCodeInsError : null}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.dropdowns &&
                      props.dropdowns["R1#R_BP_COINS_LMT_TY_CD"] &&
                      props.dropdowns["R1#R_BP_COINS_LMT_TY_CD"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    required
                    name="indAmount"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 14 }}
                    value={newCoInsPlan.indAmount}
                    id="individual_lmt_insuranceLmt_cost_share_tab"
                    label="Individual Limit"
                    helperText={
                      indAmntErr
                        ? ErrorConst.INDIVIDUAL_LIMIT
                        : invalidIndAmntErr
                        ? ErrorConst.INVALID_IND_LIMIT
                        : invalidIndAmntmaxErr
                        ? ErrorConst.IND_LIMIT_MAX
                        : null
                    }
                    error={
                      indAmntErr
                        ? ErrorConst.INDIVIDUAL_LIMIT
                        : invalidIndAmntErr
                        ? ErrorConst.INVALID_IND_LIMIT
                        : invalidIndAmntmaxErr
                        ? ErrorConst.IND_LIMIT_MAX
                        : null
                    }
                  ></TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    name="indPlusAmount"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 14 }}
                    value={newCoInsPlan.indPlusAmount}
                    id="indi_plus_insuranceLmt_cost_share_tab"
                    label="Individual +1 Limit"
                    helperText={
                      invalidIndPlusAmntErr
                        ? ErrorConst.INVALID_IND_PLUS_LIMIT
                        : invalidIndPlusAmntmaxErr
                        ? ErrorConst.IND_PLUS_LIMIT_MAX
                        : null
                    }
                    error={
                      invalidIndPlusAmntErr
                        ? ErrorConst.INVALID_IND_PLUS_LIMIT
                        : invalidIndPlusAmntmaxErr
                        ? ErrorConst.IND_PLUS_LIMIT_MAX
                        : null
                    }
                  ></TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    name="famAmount"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 14 }}
                    value={newCoInsPlan.famAmount}
                    id="family_limit_insuranceLmt_cost_share_tab"
                    label="Family Limit"
                    helperText={
                      invalidIndFamAmntErr
                        ? ErrorConst.INVALID_IND_FAM_LIMIT
                        : invalidIndFamAmntmaxErr
                        ? ErrorConst.IND_FAM_LIMIT_MAX
                        : null
                    }
                    error={
                      invalidIndFamAmntErr
                        ? ErrorConst.INVALID_IND_FAM_LIMIT
                        : invalidIndFamAmntmaxErr
                        ? ErrorConst.IND_FAM_LIMIT_MAX
                        : null
                    }
                  ></TextField>
                </div>
              </div>
              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="limit_met_insuranceLmt_cost_share_tab"
                    name="metExceptionCode"
                    label="Limited Met Exception Code"
                    inputProps={{ maxLength: 4 }}
                    onChange={(event) => handelInputChange(event)}
                    value={newCoInsPlan.metExceptionCode}
                    helperText={
                      INVALID_LMT_MET_EXC_CODE
                        ? ErrorConst.INVALID_LMT_MET_EXC_CODE
                        : INVALID_LMT_MET_EXC_CODE_SPL
                          ? ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE
                          : null
                    }
                    error={
                      INVALID_LMT_MET_EXC_CODE
                        ? ErrorConst.INVALID_LMT_MET_EXC_CODE
                        : INVALID_LMT_MET_EXC_CODE_SPL
                          ? ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE
                          : null
                    }
                    InputLabelProps={{
                      shrink: true,
                    }}
                  ></TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="limit_over_insuranceLmt_cost_share_tab"
                    name="overExceptionCode"
                    label="Limited Over Exception Code"
                    inputProps={{ maxLength: 4 }}
                    onChange={(event) => handelInputChange(event)}
                    value={newCoInsPlan.overExceptionCode}
                    // helperText={
                    //   INVALID_LMT_OVR_EXC_CODE
                    //     ? ErrorConst.INVALID_LMT_OVR_EXC_CODE
                    //     : null
                    // }
                    // error={INVALID_LMT_OVR_EXC_CODE}
                    helperText={
                      INVALID_LMT_OVR_EXC_CODE
                          ? ErrorConst.INVALID_LMT_OVR_EXC_CODE
                          : INVALID_LMT_OVR_EXC_CODE_SPE
                              ? ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE
                              : null
                  }
                  error={
                      INVALID_LMT_OVR_EXC_CODE
                          ? ErrorConst.INVALID_LMT_OVR_EXC_CODE
                          : INVALID_LMT_OVR_EXC_CODE_SPE
                              ? ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE
                              : null
                  }
                    InputLabelProps={{
                      shrink: true,
                    }}
                  ></TextField>
                </div>

                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    required
                    name="seqNum"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 6 }}
                    value={newCoInsPlan.seqNum}
                    id="rank_insuranceLmt_cost_share_tab"
                    label="Rank"
                    // helperText={
                    //   rankError
                    //     ? ErrorConst.Rank_Error
                    //     : RankErr
                    //     ? ErrorConst.Invalid_Rank_Error
                    //     : showRankOverlapErr
                    //     ? ErrorConst.RANK_TABLE_OVERLAP
                    //     : null
                    // }
                    helperText={
                      rankError
                        ? ErrorConst.Rank_Error
                        : showRankErrSpe
                        ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                        : showRankErrZero
                        ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                        : null
                    }
                    error={
                      rankError
                      ? ErrorConst.Rank_Error
                      : showRankErrSpe
                      ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                      : showRankErrZero
                      ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                      : null
                    }
                  ></TextField>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}

export default forwardRef(BenefitPlanCoInsLmt);
