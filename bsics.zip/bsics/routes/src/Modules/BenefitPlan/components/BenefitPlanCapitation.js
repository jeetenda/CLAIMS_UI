import React, {
  useState,
  useEffect,
  useRef,
  forwardRef,
  useImperativeHandle,
} from "react";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import * as moment from "moment";
import "moment-range";
import DateFnsUtils from "@date-io/date-fns";
import dateFnsFormat from "date-fns/format";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from "@material-ui/pickers";
import AppBar from "@material-ui/core/AppBar";
import TabPanel from "../../../SharedModules/TabPanel/TabPanel";
import InputAdornment from "@material-ui/core/InputAdornment";
import { withRouter } from "react-router";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import { Button } from "react-bootstrap";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
/*tabel component import */
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import CapitationTableComponent from "./CapitationTableComponent";
import { Link } from "react-router-dom";



function BenefitPlanCapitation(props, ref) {
 
  const [banifitPlan, setbanifitPlan] = React.useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = React.useState("");
  const [success, setSuccess] = useState(false);
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);

  const [newProviderDate, setnewProviderDate] = useState({
    begDate: "",
    endDate: "12/31/9999",
    nwStatCode: "-1",
    rank: "",
    mapID: "",
    nwStatCodeDesc: "",
    rateTypeCode: "",
    rateTypeCodeDesc: "",
    rate: "",
  });

  const [resetProviderDate, setresetProviderDate] = useState({
    begDate: "",
    endDate: "12/31/9999",
    nwStatCode: "-1",
    rank: "",
    mapID: "",
    nwStatCodeDesc: "",
    rateTypeCode: "",
    rateTypeCodeDesc: "",
    rate: "",
  });

  //webninja
  const [
    {
      showHeaderDateErr,
      showBeginDateError,
      showEndDateError,
      beginDtInvalidErr,
      endDtInvalidErr,
      showRankOverlapErr,
      showNetworkOverlapErr,
      networkIDError,
      mapIdErr,
      rateTypeCodeError,
      networkStatusError,
      rankError,
      rateError,
      showBgdtGTEnddtErr,
      RankErr,
      RateErr,
      showRankErrSpe,
      showRankErrZero,
      showHeaderBeginDateErr,
      showHeaderEndDateErr,
    },
    setShowError,
  ] = React.useState(false);

  const [successMessages, setSuccessMessages] = useState([]);

  //webninja
  const formatDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const handelInputChange = (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, capitationTab: true });
    if (event.target.name === "nwStatCode") {
      setnewProviderDate({
        ...newProviderDate,
        [event.target.name]: event.target.value,
        nwStatCodeDesc: event.nativeEvent.target.textContent,
      });
    } else if (event.target.name === "rateTypeCode") {
      setnewProviderDate({
        ...newProviderDate,
        [event.target.name]: event.target.value,
        rateTypeCodeDesc: event.nativeEvent.target.textContent,
      });
    } else {
      setnewProviderDate({
        ...newProviderDate,
        [event.target.name]: event.target.value,
      });
    }
  };
  const handelDateChange = (type, name) => (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, tabChangeValue: true });
    if (type === "setnewProviderDate") {
      setnewProviderDate({ ...newProviderDate, [name]: date });
    }
  };

  const handelDateRngeWithin = (
    rangeStartDate,
    rangeEndDate,
    withInStartDate,
    withInEndDate
  ) => {
    if (rangeStartDate && rangeEndDate && withInStartDate && withInEndDate) {
      const range = moment().range(
        new Date(rangeStartDate),
        new Date(rangeEndDate)
      );
      return (
        range.contains(new Date(withInStartDate)) &&
        range.contains(new Date(withInEndDate))
      );
    }
    return false;
  };

  const handelDateRngeOverlap = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate
  ) => {
    const range1 = moment().range(
      new Date(initalStartDate),
      new Date(initialEndDate)
    );
    const range2 = moment().range(
      new Date(secondaryStartDate),
      new Date(secondaryEndDate)
    );
    return range1.overlaps(range2);
  };

  const handelDateNetworkArrayOverlap = (
    initalStartDate,
    initialEndDate,
    netWorkStatus,
    networkId,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.begDate,
            each.endDate
          )
        ) {
          if (
            each.mapID == networkId &&
            each.nwStatCode == netWorkStatus &&
            each.begDate == initalStartDate
          ) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRankArrayOverlap = (
    initalStartDate,
    initialEndDate,
    Rank,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.begDate,
            each.endDate
          )
        ) {
          if (each.seqNum == Rank) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelClick = async () => {
    const tableData = props.newCohortState;
    //webninja
    setSuccess(false);
    setDeleteSuccess(false);
    props.seterrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newProviderDate.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.begDate != formatDate(resetProviderDate.begDate) ||
          e.endDate != formatDate(resetProviderDate.endDate) ||
          e.seqNum != resetProviderDate.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newProviderDate.begDate),
      formatDate(newProviderDate.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newProviderDate.begDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.nwStatCode,
      newProviderDate.mapID,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newProviderDate.begDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.seqNum,
      overlapArray
    );
    setShowError({
      showBeginDateError: newProviderDate.begDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newProviderDate.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        newProviderDate.begDate &&
        formatDate(newProviderDate.begDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newProviderDate.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_End_Date_Error);
              return true;
            })()
          : false,
      networkStatusError:
        newProviderDate.nwStatCode && newProviderDate.nwStatCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      //rankError: newProviderDate.seqNum ? false : (() => { reqFieldArr.push(ErrorConst.Rank_Error); return true; })(),
      showBgdtGTEnddtErr:
        newProviderDate.begDate &&
        new Date(newProviderDate.begDate) >= new Date(newProviderDate.endDate)
          ? (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })()
          : false,
      //RankErr: !(isNaN(parseInt(newProviderDate.seqNum)) || parseInt(newProviderDate.seqNum) > 99999) ? false : (() => { reqFieldArr.push(ErrorConst.Invalid_Rank_Error); return true; })(),
      // showHeaderDateErr: !headerTange && newProviderDate.begDate && formatDate(newProviderDate.begDate).toString() != "Invalid Date" ? (() => { reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk); return true; })() : false,
      showNetworkOverlapErr:
        newProviderDate.begDate &&
        newProviderDate.endDate &&
        newProviderDate.nwStatCode &&
        newProviderDate.mapID &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.CAPITATION_OVERLAP);
              return true;
            })()
          : false,
      // End header date error defect 62452
      showHeaderDateErr: !(
        new Date(newProviderDate.begDate) >=
          new Date(props.formValues.beginDate) &&
        new Date(newProviderDate.begDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(
              ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
            );
            return true;
          })()
        : false,

      showHeaderEndDateErr: !(
        new Date(newProviderDate.endDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(ErrorConst.Fall_In_Header_End_Date_Err);
            return true;
          })()
        : false,
      // End header date error
      showRankOverlapErr:
        newProviderDate.begDate &&
        newProviderDate.endDate &&
        newProviderDate.seqNum &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,
      showRankErrSpe: !isNaN(parseInt(newProviderDate.seqNum))
        ? false
        : (() => {
            if (newProviderDate.seqNum.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
      showRankErrZero:
        newProviderDate.seqNum < 1 && newProviderDate.seqNum.length
          ? (() => {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
              return true;
            })()
          : false,
      rankError:
        newProviderDate.seqNum.length < 1
          ? (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })()
          : false,
      mapIdErr:
        newProviderDate.mapID && newProviderDate.mapID != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      rateError: newProviderDate.rate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Rate_Error);
            return true;
          })(),
      RateErr: newProviderDate.rate.match(/^\d*(\.\d{0,2})?$/)
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Invalid_Rate_Error);
            return true;
          })(),
      rateTypeCodeError:
        newProviderDate.rateTypeCode && newProviderDate.rateTypeCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Rate_Type_Code_Error);
              return true;
            })(),
    });
    props.setShowError({
      planbegDateError: props.formValues.beginDate ? false : true,
      planEndDateError: props.formValues.endDate ? false : true,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    const data = {
      auditUserID: "wf_NH_MC_BP_SETUPV99",
      auditTimeStamp: "2013-01-31T00:23:48.000+0000",
      addedAuditUserID: "wf_NH_MC_BP_SETUPV99",
      addedAuditTimeStamp: "2013-01-31T00:23:48.000+0000",
      versionNo:
        newProviderDate.row && newProviderDate.row.versionNo
          ? newProviderDate.row.versionNo
          : 0,
      dbRecord: false,
      sortColumn: null,
      auditKeyList: [],
      auditKeyListFiltered: false,
      begDate: formatDate(newProviderDate.begDate),
      seqNum: newProviderDate.seqNum,
      nwStatCode: newProviderDate.nwStatCode,
      mapID: newProviderDate.mapID,
      endDate: formatDate(newProviderDate.endDate),
      nwStatCodeDesc: newProviderDate.nwStatCodeDesc,
      rate: newProviderDate.rate,
      rateTypeCode: newProviderDate.rateTypeCode,
      rateTypeCodeDesc: newProviderDate.rateTypeCodeDesc,
      cohortRateSK:
        newProviderDate.row && newProviderDate.row.cohortRateSK
          ? newProviderDate.row.cohortRateSK
          : null,
    };

    newProviderDate.index > -1
      ? (tableData[newProviderDate.index] = data)
      : tableData.push(data);
    props.setNewCohortState(tableData);

    const vo1 = {
      addedAuditTimeStamp: props.holdbackVo1Values.addedAuditTimeStamp
        ? props.holdbackVo1Values.addedAuditTimeStamp
        : "2013-01-31T00:23:48.000+0000",
      addedAuditUserID: props.holdbackVo1Values.addedAuditUserID
        ? props.holdbackVo1Values.addedAuditUserID
        : "wf_NH_MC_BP_SETUPV99",
      auditTimeStamp: props.holdbackVo1Values.auditTimeStamp
        ? props.holdbackVo1Values.addedAuditTimeStamp
        : "2013-01-31T00:23:48.000+0000",
      auditUserID: props.holdbackVo1Values.auditUserID
        ? props.holdbackVo1Values.auditUserID
        : "wf_NH_MC_BP_SETUPV99",
      versionNo: props.holdbackVo1Values.versionNo
        ? props.holdbackVo1Values.versionNo
        : 0,
      dbRecord: false,
      funcAreaCode: props.holdbackVo1Values.funcAreaCode,
      sysParamNum: props.holdbackVo1Values.sysParamNum,
      updFlag: true,
    };

    const vo2 = {
      addedAuditTimeStamp: props.holdbackVo2Values.addedAuditTimeStamp
        ? props.holdbackVo2Values.addedAuditTimeStamp
        : "2013-01-31T00:23:48.000+0000",
      addedAuditUserID: props.holdbackVo2Values.addedAuditUserID
        ? props.holdbackVo2Values.addedAuditUserID
        : "wf_NH_MC_BP_SETUPV99",
      auditTimeStamp: props.holdbackVo2Values.auditTimeStamp
        ? props.holdbackVo2Values.addedAuditTimeStamp
        : "2013-01-31T00:23:48.000+0000",
      auditUserID: props.holdbackVo2Values.auditUserID
        ? props.holdbackVo2Values.auditUserID
        : "wf_NH_MC_BP_SETUPV99",
      versionNo: props.holdbackVo2Values.versionNo
        ? props.holdbackVo2Values.versionNo
        : 0,
      dbRecord: false,
      funcAreaCode: props.holdbackVo2Values.funcAreaCode,
      sysParamNum: props.holdbackVo2Values.sysParamNum,
      updFlag: true,
    };

    const casemngmnt = {
      addedAuditTimeStamp: props.capitationValues.addedAuditTimeStamp
        ? props.capitationValues.addedAuditTimeStamp
        : "2013-01-31T00:23:48.000+0000",
      addedAuditUserID: props.capitationValues.addedAuditUserID
        ? props.capitationValues.addedAuditUserID
        : "wf_NH_MC_BP_SETUPV99",
      auditTimeStamp: props.capitationValues.auditTimeStamp
        ? props.capitationValues.addedAuditTimeStamp
        : "2013-01-31T00:23:48.000+0000",
      auditUserID: props.capitationValues.auditUserID
        ? props.capitationValues.auditUserID
        : "wf_NH_MC_BP_SETUPV99",
      currentProcCode: props.capitationValues.currentProcCode,
      currentVersionNo: props.capitationValues.currentVersionNo
        ? props.capitationValues.currentVersionNo
        : "0",
      dbCurrentProcCode: props.capitationValues.currentProcCode,
      dbRecord: false,
      dbRetroProcCode: props.capitationValues.retroProcCode,
      futureProcCode: props.capitationValues.futureProcCode,
      futureVersionNo: props.capitationValues.futureVersionNo
        ? props.capitationValues.futureVersionNo
        : "0",
      retroProcCode: props.capitationValues.retroProcCode,
      retroVersionNo: "0",
      sortColumn: null,
      versionNo: props.capitationValues.versionNo
        ? props.capitationValues.versionNo
        : "0",
    };

    props.setholdbackVo1Values(vo1);
    props.setholdbackVo2Values(vo2);
    props.setcapitationValues(casemngmnt);

    setSuccess(true);
    setnewProviderDate({
      begDate: "",
      endDate: "12/31/9999",
      nwStatCode: "-1",
      seqNum: "",
      mapID: "",
      nwStatCodeDesc: "",
      rateTypeCode: "",
      rateTypeCodeDesc: "",
      rate: "",
    });
    setresetProviderDate({
      begDate: "",
      endDate: "12/31/9999",
      nwStatCode: "-1",
      seqNum: "",
      mapID: "",
      nwStatCodeDesc: "",
      rateTypeCode: "",
      rateTypeCodeDesc: "",
      rate: "",
    });
    setbanifitPlan(false);
    props.setTabChangeValue({ ...props.tabChangeValue, capitationTab: false });
  };

  const handelDeleteClick = () => {
    setSuccess(false);
    const tableData = props.newCohortState;
    if (newProviderDate.row && newProviderDate.row.cohortRateSK) {
      let deleteData = props.deleteCohortRow;
      deleteData.push({
        auditUserID: "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp: "2013-01-31T00:23:48.000+0000",
        addedAuditUserID: "wf_NH_MC_BP_SETUPV99",
        addedAuditTimeStamp: "2013-01-31T00:23:48.000+0000",
        versionNo:
          newProviderDate.row && newProviderDate.row.versionNo
            ? newProviderDate.row.versionNo
            : 0,
        dbRecord: false,
        sortColumn: null,
        auditKeyList: [],
        auditKeyListFiltered: false,
        begDate: formatDate(newProviderDate.begDate),
        seqNum: newProviderDate.seqNum,
        nwStatCode: newProviderDate.nwStatCode,
        endDate: formatDate(newProviderDate.endDate),
        rateTypeCode: newProviderDate.rateTypeCode,
        mapID: newProviderDate.mapID,
        rate: newProviderDate.rate,
        nwStatCodeDesc: newProviderDate.nwStatCodeDesc,
        cohortRateSK:
          newProviderDate.row && newProviderDate.row.cohortRateSK
            ? newProviderDate.row.cohortRateSK
            : null,
      });
      props.setDeleteCohortRow(deleteData);

      const vo1 = {
        addedAuditTimeStamp: props.holdbackVo1Values.addedAuditTimeStamp
          ? props.holdbackVo1Values.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
        addedAuditUserID: props.holdbackVo1Values.addedAuditUserID
          ? props.holdbackVo1Values.addedAuditUserID
          : "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp: props.holdbackVo1Values.auditTimeStamp
          ? props.holdbackVo1Values.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
        auditUserID: props.holdbackVo1Values.auditUserID
          ? props.holdbackVo1Values.auditUserID
          : "wf_NH_MC_BP_SETUPV99",
        versionNo: props.holdbackVo1Values.versionNo
          ? props.holdbackVo1Values.versionNo
          : 0,
        dbRecord: false,
        funcAreaCode: props.holdbackVo1Values.funcAreaCode,
        sysParamNum: props.holdbackVo1Values.sysParamNum,
        updFlag: false,
      };

      const vo2 = {
        addedAuditTimeStamp: props.holdbackVo2Values.addedAuditTimeStamp
          ? props.holdbackVo2Values.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
        addedAuditUserID: props.holdbackVo2Values.addedAuditUserID
          ? props.holdbackVo2Values.addedAuditUserID
          : "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp: props.holdbackVo2Values.auditTimeStamp
          ? props.holdbackVo2Values.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
        auditUserID: props.holdbackVo2Values.auditUserID
          ? props.holdbackVo2Values.auditUserID
          : "wf_NH_MC_BP_SETUPV99",
        versionNo: props.holdbackVo2Values.versionNo
          ? props.holdbackVo2Values.versionNo
          : 0,
        dbRecord: false,
        funcAreaCode: props.holdbackVo2Values.funcAreaCode,
        sysParamNum: props.holdbackVo2Values.sysParamNum,
        updFlag: false,
      };

      const casemngmnt = {
        addedAuditTimeStamp: props.capitationValues.addedAuditTimeStamp
          ? props.capitationValues.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
        addedAuditUserID: props.capitationValues.addedAuditUserID
          ? props.capitationValues.addedAuditUserID
          : "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp: props.capitationValues.auditTimeStamp
          ? props.capitationValues.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
        auditUserID: props.capitationValues.auditUserID
          ? props.capitationValues.auditUserID
          : "wf_NH_MC_BP_SETUPV99",
        currentProcCode: props.capitationValues.currentProcCode,
        currentVersionNo: props.capitationValues.currentVersionNo
          ? props.capitationValues.currentVersionNo
          : "0",
        dbCurrentProcCode: props.capitationValues.currentProcCode,
        dbRecord: false,
        dbRetroProcCode: props.capitationValues.retroProcCode,
        futureProcCode: props.capitationValues.futureProcCode,
        futureVersionNo: props.capitationValues.futureVersionNo
          ? props.capitationValues.futureVersionNo
          : "0",
        retroProcCode: props.capitationValues.retroProcCode,
        retroVersionNo: props.capitationValues.retroVersionNo
          ? props.capitationvalues.retroVersionNo
          : 0,
        sortColumn: null,
        versionNo: props.capitationValues.versionNo
          ? props.capitationValues.versionNo
          : 0,
      };

      props.setholdbackVo1Values(vo1);
      props.setholdbackVo2Values(vo2);
      props.setcapitationValues(casemngmnt);
    }
    tableData.splice(newProviderDate.index, 1);
    props.setNewCohortState(tableData);
    setShowError(false);
    setnewProviderDate({
      begDate: "",
      endDate: "12/31/9999",
      nwStatCode: "-1",
      seqNum: "",
      mapID: "",
      nwStatCodeDesc: "",
      rateTypeCode: "",
      rateTypeCodeDesc: "",
      rate: "",
    });
    setresetProviderDate({
      begDate: "",
      endDate: "12/31/9999",
      nwStatCode: "-1",
      seqNum: "",
      mapID: "",
      nwStatCodeDesc: "",
      rateTypeCode: "",
      rateTypeCodeDesc: "",
      rate: "",
    });
    setDeleteSuccess(true);
    setbanifitPlan(false);
    setDialogOpen(false);
    setDialogType("");
  };

  const handelResetClick = () => {
    props.seterrorMessages([]);
    setnewProviderDate(resetProviderDate);
    setShowError(false);
    props.setTabChangeValue({ ...props.tabChangeValue, capitationTab: false });
  };
  const handelCandelFunction = () => {
    setbanifitPlan(false);
    setShowError(false);
    setDialogOpen(false);
    setDialogType("");
  };

  const multiDelete = () => {
    setDialogOpen(false);
    setDialogType("");
    props.seterrorMessages([]);
    setSuccessMessages([]);
    if (selectDeleteArray.length > 0) {
      let CI = props.newCohortState;
      selectDeleteArray.map((value, index) => {
        let curIndex = CI.findIndex((i) =>
          moment(i.beginDate).isSame(value.beginDate)
        );
        CI.splice(curIndex, 1);
      });
      props.setNewCohortState(CI);
      props.setDeleteCohortRow(selectDeleteArray);
      setSelectDeleteArray([]);
      setDeleteSuccess(true);
    }
  };

  const scrollToRef = (ref) =>
    ref.current.scrollIntoView({ behavior: "smooth" });
  const hbpscrollview = useRef(null);
  const HBPscrolltoView = () => {
    setTimeout(
      function () {
        scrollToRef(hbpscrollview);
      }.bind(this),
      500
    );
  };

  React.useImperativeHandle(ref, () => {
    console.log("callling-----------------------------");
    return { validateCap };
  });

  const validateCap = () => {
    if (props.tabChangeValue.capitationTab) {
      handelSaveValidations();
    }
  };

  const handelSaveValidations = async () => {
    const tableData = props.newCohortState;
    //webninja
    setSuccess(false);
    setDeleteSuccess(false);
    props.seterrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newProviderDate.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.begDate != formatDate(resetProviderDate.begDate) ||
          e.endDate != formatDate(resetProviderDate.endDate) ||
          e.seqNum != resetProviderDate.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newProviderDate.begDate),
      formatDate(newProviderDate.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newProviderDate.begDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.nwStatCode,
      newProviderDate.mapID,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newProviderDate.begDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.seqNum,
      overlapArray
    );
    setShowError({
      showBeginDateError: newProviderDate.begDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newProviderDate.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        newProviderDate.begDate &&
        formatDate(newProviderDate.begDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newProviderDate.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_End_Date_Error);
              return true;
            })()
          : false,
      networkStatusError:
        newProviderDate.nwStatCode && newProviderDate.nwStatCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      //rankError: newProviderDate.seqNum ? false : (() => { reqFieldArr.push(ErrorConst.Rank_Error); return true; })(),
      showBgdtGTEnddtErr:
        newProviderDate.begDate &&
        new Date(newProviderDate.begDate) >= new Date(newProviderDate.endDate)
          ? (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })()
          : false,
      //RankErr: !(isNaN(parseInt(newProviderDate.seqNum)) || parseInt(newProviderDate.seqNum) > 99999) ? false : (() => { reqFieldArr.push(ErrorConst.Invalid_Rank_Error); return true; })(),
      //showHeaderDateErr: !headerTange && newProviderDate.begDate && formatDate(newProviderDate.begDate).toString() != "Invalid Date" ? (() => { reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err); return true; })() : false,
      // End header date error defect 62452
      showHeaderDateErr: !(
        new Date(newProviderDate.beginDate) >=
          new Date(props.formValues.beginDate) &&
        new Date(newProviderDate.beginDate) <=
          new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(
              ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
            );
            return true;
          })()
        : false,

      showHeaderEndDateErr: !(
        new Date(newProviderDate.endDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(ErrorConst.Fall_In_Header_End_Date_Err);
            return true;
          })()
        : false,
      showNetworkOverlapErr:
        newProviderDate.begDate &&
        newProviderDate.endDate &&
        newProviderDate.nwStatCode &&
        newProviderDate.mapID &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.CAPITATION_OVERLAP);
              return true;
            })()
          : false,
      showRankOverlapErr:
        newProviderDate.begDate &&
        newProviderDate.endDate &&
        newProviderDate.seqNum &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,
      showRankErrSpe: !isNaN(parseInt(newProviderDate.seqNum))
        ? false
        : (() => {
            if (newProviderDate.seqNum.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
      showRankErrZero:
        newProviderDate.seqNum < 1 && newProviderDate.seqNum.length
          ? (() => {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
              return true;
            })()
          : false,
      rankError:
        newProviderDate.seqNum.length < 1
          ? (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })()
          : false,
      mapIdErr:
        newProviderDate.mapID && newProviderDate.mapID != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      rateError: newProviderDate.rate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Rate_Error);
            return true;
          })(),
      RateErr: newProviderDate.rate.match(/^\d*(\.\d{0,2})?$/)
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Invalid_Rate_Error);
            return true;
          })(),
      rateTypeCodeError:
        newProviderDate.rateTypeCode && newProviderDate.rateTypeCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Rate_Type_Code_Error);
              return true;
            })(),
    });
    props.setShowError({
      planbegDateError: props.formValues.beginDate ? false : true,
      planEndDateError: props.formValues.endDate ? false : true,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }
  };
  return (
    <>
      <div className="pos-relative">{/*webninja*/}</div>
      <Dialog
        open={dialogOpen}
        id="dialog_close"
        onClose={() => {
          setDialogOpen(false);
          setDialogType("");
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          {console.log("dialogType",dialogType)}
          <DialogContentText id="alert-dialog-description">
            {dialogType == "Delete" || dialogType == "multiDelete"
              ? "Are you sure that you want to Delete."
              : dialogType == "Cancel"
              ? "Changes you made may not be saved."
              : ""}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            title="Ok"
            id="ok"
            onClick={() => {
              dialogType == "Delete"
                ? handelDeleteClick()
                : dialogType == "multiDelete"
                ? multiDelete()
                : handelCandelFunction();
            }}
            color="primary"
            className="btn btn-success"
          >
            Ok
          </Button>
          <Button
            title="Cancel"
            id="dialog_cancel"
            onClick={() => {
              setDialogOpen(false);
              setDialogType("");
            }}
            color="primary"
            autoFocus
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      {props.edit ? (
        <div className="tabs-container">
          <div className="tab-header">
            <h1 className="tab-heading float-left">
              Benefit Plan - Eligibility (MCT) Maps
            </h1>
            <div className="clearfix" />
          </div>
          <div className="tab-holder mt-3">
            <div class="pb-3">
              <span>{props.values.benefitPlanID} : </span>{" "}
              <a className="cndt-link" title="Benefit Plan Description">
                {props.values.benefitPlanDesc}
              </a>
            </div>
          </div>
        </div>
      ) : null}

      <div className="tabs-container tabs-container-inner mt-0">
        <div className="tab-header">
          <h3 className="tab-heading float-left">
            Benefit Plan - Capitation/Case Management
          </h3>
        </div>
        <div className="clearfix" />
        <div className="tab-body-bordered mt-2">
          <div className="form-wrapper">
            <div className="mui-custom-form with-select input-md">
              <TextField
                id="standard-select-modifier1"
                select
                required
                label="Current Procedure Code"
                value={props.capitationValues.currentProcCode}
                inputProps={{ maxLength: 10 }}
                onChange={props.handleCapitationChanges("currentProcCode")}
                placeholder="Please Select One"
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  props.currprocErr ? ErrorConst.Current_Procedure_Error : null
                }
                error={
                  props.currprocErr ? ErrorConst.Current_Procedure_Error : null
                }
              >
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.mainValues.planType == "M" &&
                props.nonVvDropdown &&
                Object.keys(props.nonVvDropdown).length > 0 &&
                props.nonVvDropdown["20#R1"]
                  ? props.nonVvDropdown["20#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))
                  : props.mainValues.planType == "Q" &&
                    props.nonVvDropdown &&
                    Object.keys(props.nonVvDropdown).length > 0 &&
                    props.nonVvDropdown["30#R1"]
                  ? props.nonVvDropdown["30#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))
                  : props.mainValues.planType == "T" &&
                    props.nonVvDropdown &&
                    Object.keys(props.nonVvDropdown).length > 0 &&
                    props.nonVvDropdown["40#R1"]
                  ? props.nonVvDropdown["40#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))
                  : props.nonVvDropdown["20#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))}
              </TextField>
            </div>

            <div className="mui-custom-form with-select input-md">
              <TextField
                id="standard-select-modifier1"
                select
                required
                label="Retro Procedure Code"
                value={props.capitationValues.retroProcCode}
                inputProps={{ maxLength: 2 }}
                onChange={props.handleCapitationChanges("retroProcCode")}
                placeholder="Please Select One"
                InputLabelProps={{
                  shrink: true,
                }}
                helperText={
                  props.retroprocErr ? ErrorConst.Retro_Procedure_Error : null
                }
                error={
                  props.retroprocErr ? ErrorConst.Retro_Procedure_Error : null
                }
              >
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.mainValues.planType == "M" &&
                props.nonVvDropdown &&
                Object.keys(props.nonVvDropdown).length > 0 &&
                props.nonVvDropdown["21#R1"]
                  ? props.nonVvDropdown["21#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))
                  : props.mainValues.planType == "Q" &&
                    props.nonVvDropdown &&
                    Object.keys(props.nonVvDropdown).length > 0 &&
                    props.nonVvDropdown["31#R1"]
                  ? props.nonVvDropdown["31#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))
                  : props.mainValues.planType == "T" &&
                    props.nonVvDropdown &&
                    Object.keys(props.nonVvDropdown).length > 0 &&
                    props.nonVvDropdown["41#R1"]
                  ? props.nonVvDropdown["41#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))
                  : props.nonVvDropdown["21#R1"].map((each) => (
                      <MenuItem selected key={each.code} value={each.code}>
                        {each.description}
                      </MenuItem>
                    ))}
              </TextField>
            </div>
            {props.mainValues.planType && props.mainValues.planType == "Q" ? (
              <div className="mui-custom-form with-select input-md">
                {props.capitationValues.futureProcCode == null ? (
                  <TextField
                    id="standard-select-modifier1"
                    select
                    label="Future Procedure Code"
                    value="-1"
                    inputProps={{ maxLength: 2 }}
                    onChange={props.handleCapitationChanges("futureProcCode")}
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.nonVvDropdown &&
                      Object.keys(props.nonVvDropdown).length > 0 &&
                      props.nonVvDropdown["31#R1"] &&
                      props.nonVvDropdown["31#R1"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                ) : (
                  <TextField
                    id="standard-select-modifier1"
                    select
                    label="Future Procedure Code"
                    value={props.capitationValues.futureProcCode}
                    inputProps={{ maxLength: 2 }}
                    onChange={props.handleCapitationChanges("futureProcCode")}
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.nonVvDropdown &&
                      Object.keys(props.nonVvDropdown).length > 0 &&
                      props.nonVvDropdown["31#R1"] &&
                      props.nonVvDropdown["31#R1"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                )}
              </div>
            ) : (
              ""
            )}
          </div>
          <div className="tabs-container tabs-container-inner mt-0">
            <div className="tab-header">
              <h3 className="tab-heading float-left">Hold Back Parameters</h3>
              <div className="clearfix" />
            </div>

            <div className="tab-body">
              <div className="form-wrapper">
                <div className="mui-custom-form with-select input-md">
                  {props.holdbackVo1Values.funcAreaCode == null ? (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="Functional Area Code"
                      value="-1"
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo1Changes("funcAreaCode")}
                      placeholder="Please Select Oneeeee"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      <MenuItem selected key="R1" value="R1">
                        R1-Reference
                      </MenuItem>
                    </TextField>
                  ) : (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="Functional Area Code"
                      value={props.holdbackVo1Values.funcAreaCode}
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo1Changes("funcAreaCode")}
                      placeholder="Please Select Oneeeee"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      <MenuItem selected key="R1" value="R1">
                        R1-Reference
                      </MenuItem>
                    </TextField>
                  )}
                </div>

                <div className="mui-custom-form with-select input-md">
                  {props.holdbackVo1Values.sysParamNum == null ? (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="System Parameter Number"
                      value="-1"
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo1Changes("sysParamNum")}
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      {props.nonVvDropdown &&
                        Object.keys(props.nonVvDropdown).length > 0 &&
                        props.nonVvDropdown["23#R1"] &&
                        props.nonVvDropdown["23#R1"]
                          .sort((a, b) => a.code - b.code)
                          .map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.code}
                            </MenuItem>
                          ))}
                    </TextField>
                  ) : (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="System Parameter Number"
                      value={props.holdbackVo1Values.sysParamNum}
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo1Changes("sysParamNum")}
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      {props.nonVvDropdown &&
                        Object.keys(props.nonVvDropdown).length > 0 &&
                        props.nonVvDropdown["23#R1"] &&
                        props.nonVvDropdown["23#R1"]
                          .sort((a, b) => a.code - b.code)
                          .map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.code}
                            </MenuItem>
                          ))}
                    </TextField>
                  )}
                </div>
                <div className="mui-custom-form with-select input-md">
                  {props.holdbackVo2Values.sysParamNum == null ? (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="Functional Area Code 2"
                      value="-1"
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo2Changes("funcAreaCode")}
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      <MenuItem selected key="R1" value="R1">
                        R1-Reference
                      </MenuItem>
                    </TextField>
                  ) : (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="Functional Area Code 2"
                      value={props.holdbackVo2Values.funcAreaCode}
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo2Changes("funcAreaCode")}
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      <MenuItem selected key="R1" value="R1">
                        R1-Reference
                      </MenuItem>
                    </TextField>
                  )}
                </div>
                <div className="mui-custom-form with-select input-md">
                  {props.holdbackVo2Values.sysParamNum == null ? (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="System Parameter Number 2"
                      value="-1"
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo2Changes("sysParamNum")}
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      {props.nonVvDropdown &&
                        Object.keys(props.nonVvDropdown).length > 0 &&
                        props.nonVvDropdown["24#R1"] &&
                        props.nonVvDropdown["24#R1"]
                          .sort((a, b) => a.code - b.code)
                          .map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.code}
                            </MenuItem>
                          ))}
                    </TextField>
                  ) : (
                    <TextField
                      id="standard-select-modifier1"
                      select
                      label="System Parameter Number 2"
                      value={props.holdbackVo2Values.sysParamNum}
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleholdbackVo2Changes("sysParamNum")}
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem value="-1">Please Select One</MenuItem>
                      {props.nonVvDropdown &&
                        Object.keys(props.nonVvDropdown).length > 0 &&
                        props.nonVvDropdown["24#R1"] &&
                        props.nonVvDropdown["24#R1"]
                          .sort((a, b) => a.code - b.code)
                          .map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.code}
                            </MenuItem>
                          ))}
                    </TextField>
                  )}
                </div>
              </div>
            </div>
          </div>

          {success ? (
            <div className="alert alert-success custom-alert" role="alert">
              {ErrorConst.SUCCESSFULLY_SAVED_INFORMATION}
            </div>
          ) : null}
          {deleteSuccess ? (
            <div className="alert alert-success custom-alert" role="alert">
              {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
            </div>
          ) : null}
          <div className="tabs-container mt-3">
            <div class="container-space">
              <div className="tab-header">
                <div className="float-right th-btnGroup">
                  <Button
                    title="Delete"
                    variant="outlined"
                    color="primary"
                    id="Delete_bp"
                    className="btn btn-transparent btn-icon-only"
                    disabled={selectDeleteArray.length == 0}
                    onClick={() => {
                      setDialogOpen(true);
                      setDialogType("multiDelete");
                    }}
                  >
                    <i className="fa fa-trash" />
                  </Button>
                  <Button
                    title="Add Capitation/Case Management"
                    id="add_cap_mgm"
                    variant="outlined"
                    color="primary"
                    className="btn btn-secondary btn-icon-only"
                    onClick={() => {
                      if (props.majorvalidationscapitation()) {
                        props.setTabChangeValue({
                          ...props.tabChangeValue,
                          capitationTab: true,
                        });
                        setDeleteSuccess(false);
                        setbanifitPlan(true);
                        setSuccess(false);
                        setnewProviderDate({
                          begDate: "",
                          endDate: "12/31/9999",
                          nwStatCode: "-1",
                          seqNum: "",
                          mapID: "-1",
                          nwStatCodeDesc: "",
                          rateTypeCode: "-1",
                          rateTypeCodeDesc: "",
                          rate: "",
                        });
                        setresetProviderDate({
                          begDate: "",
                          endDate: "12/31/9999",
                          nwStatCode: "-1",
                          seqNum: "",
                          mapID: "-1",
                          nwStatCodeDesc: "",
                          rateTypeCode: "-1",
                          rateTypeCodeDesc: "",
                          rate: "",
                        });
                        HBPscrolltoView();
                      }
                    }}
                  >
                    <i class="fa fa-plus" />
                  </Button>
                </div>
                <div className="clearfix" />
              </div>

              <div className="tab-holder mt-2">
                <CapitationTableComponent
                  tabelRowData={props.newCohortState}
                  setSuccess={setSuccess}
                  setnewProviderDate={setnewProviderDate}
                  setbanifitPlan={setbanifitPlan}
                  setresetProviderDate={setresetProviderDate}
                  selectDeleteArray={selectDeleteArray}
                  setSelectDeleteArray={setSelectDeleteArray}
                  HBPscrolltoView={HBPscrolltoView}
                  setTabChangeValue={props.setTabChangeValue}
                />
              </div>
            </div>

            {banifitPlan ? (
              <div className="container-space" ref={hbpscrollview}>
                <div className="tab-header">
                  <h3 className="tab-heading float-left">
                    {newProviderDate.index > -1
                      ? "Edit Capitation/Case Management"
                      : "New Capitation/Case Management"}
                  </h3>
                  <div className="float-right th-btnGroup">
                    <Button
                      title={newProviderDate.index > -1 ? "Update" : "Add"}
                      variant="outlined"
                      id="add_edit_button"
                      color="primary"
                      className={
                        newProviderDate.index > -1
                          ? "btn btn-ic btn-update"
                          : "btn btn-ic btn-add"
                      }
                      onClick={() => handelClick()}
                      disabled={
                        props.privileges && !props.privileges.add
                          ? "disabled"
                          : ""
                      }
                    >
                      {newProviderDate.index > -1 ? "Update" : "Add"}
                    </Button>
                    {newProviderDate.index > -1 ? (
                      <Link
                        to="MapDefinition"
                        target="_blank"
                        title="View/Edit Map"
                        className="btn btn-ic btn-view"
                      >
                        View/Edit Map{" "}
                      </Link>
                    ) : null}
                    {newProviderDate.index > -1 ? (
                      <Button
                        title="Delete"
                        variant="outlined"
                        color="primary"
                        className="btn btn-ic btn-delete"
                        onClick={() => {
                          setDialogOpen(true);
                          setDialogType("Delete");
                        }}
                      >
                        Delete
                      </Button>
                    ) : null}
                    <Button
                      title="Reset"
                      id="reset_bp"
                      variant="outlined"
                      color="primary"
                      className="btn btn-ic btn-reset"
                      onClick={() => handelResetClick()}
                    >
                      Reset
                    </Button>
                    <Button
                      title="Cancel"
                      id="cancel_bp"
                      variant="outlined"
                      color="primary"
                      className="btn btn-cancel"
                      onClick={() => {
                        setDialogOpen(true);
                        setDialogType("Cancel");
                        props.setTabChangeValue({
                          ...props.tabChangeValue,
                          capitationTab: false,
                        });
                      }}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
                <div className="tab-holder">
                  <form autoComplete="off">
                    <div className="tab-body-bordered">
                      <div className="form-wrapper">
                        <div className="flex-block">
                           <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select">
                            {/* <KeyboardDatePicker
                                required
                                id="begDate"
                                label="Begin Date"
                                format="MM/dd/yyyy"
                                InputLabelProps={{
                                  shrink: true,
                                }}
                                placeholder="mm/dd/yyyy"
                                value="01/01/2020"
                                onChange={handelDateChange(
                                  "setnewProviderDate",
                                  "begDate"
                                )}
                                helperText={
                                  showHeaderDateErr
                                    ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                                    : showBeginDateError
                                    ? ErrorConst.BEGIN_DATE_ERROR
                                    : beginDtInvalidErr
                                    ? ErrorConst.Plan_Begin_Date_Error
                                    : showBgdtGTEnddtErr
                                    ? ErrorConst.DATE_RANGE_ERROR
                                    : null
                                }
                                error={
                                  showHeaderDateErr
                                    ? ErrorConst.Fall_In_Header_Dates_Err
                                    : showBeginDateError
                                    ? ErrorConst.BEGIN_DATE_ERROR
                                    : beginDtInvalidErr
                                    ? ErrorConst.Plan_Begin_Date_Error
                                    : showBgdtGTEnddtErr
                                    ? ErrorConst.DATE_RANGE_ERROR
                                    : null
                                }
                                KeyboardButtonProps={{
                                  "aria-label": "change date",
                                }}
                              /> */}
                            </div> 
                          </MuiPickersUtilsProvider> 
                          <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select">
                               {/*  <KeyboardDatePicker
                                required
                                id="endDate"
                                label="End Date"
                                format="MM/dd/yyyy"
                                maxDate={
                                  new Date("9999-12-31T13:00:00.000+0000")
                                }
                                InputLabelProps={{
                                  shrink: true,
                                }}
                                placeholder="mm/dd/yyyy"
                                value={
                                  !newProviderDate.endDate ||
                                  newProviderDate.endDate == ""
                                    ? null
                                    : newProviderDate.endDate
                                }
                                onChange={handelDateChange(
                                  "setnewProviderDate",
                                  "endDate"
                                )}
                                helperText={
                                  showEndDateError
                                    ? ErrorConst.END_DATE_ERROR
                                    : endDtInvalidErr
                                    ? ErrorConst.Plan_End_Date_Error
                                    : null
                                }
                                error={
                                  showEndDateError
                                    ? ErrorConst.END_DATE_ERROR
                                    : endDtInvalidErr
                                    ? ErrorConst.Plan_End_Date_Error
                                    : null
                                }
                                KeyboardButtonProps={{
                                  "aria-label": "change date",
                                }}
                              />*/}
                            </div>
                          </MuiPickersUtilsProvider> 
                        </div>

                        <div className="flex-block">
                          <div className="mui-custom-form with-select input-md">
                            <TextField
                              required
                              id="nwStatCode"
                              select
                              name="nwStatCode"
                              label="Network Status"
                              onChange={(event) => handelInputChange(event)}
                              value={newProviderDate.nwStatCode}
                              helperText={
                                networkStatusError
                                  ? ErrorConst.Network_Status_Error
                                  : null
                              }
                              error={
                                networkStatusError
                                  ? ErrorConst.Network_Status_Error
                                  : null
                              }
                              placeholder="Please Select One"
                              InputLabelProps={{
                                shrink: true,
                              }}
                            >
                              <MenuItem value="-1">Please Select One</MenuItem>
                              {props.dropdowns &&
                                props.dropdowns["R1#R_BP_NW_STAT_CD"] &&
                                props.dropdowns["R1#R_BP_NW_STAT_CD"].map(
                                  (each) => (
                                    <MenuItem
                                      selected
                                      key={each.code}
                                      value={each.code}
                                    >
                                      {each.description}
                                    </MenuItem>
                                  )
                                )}
                            </TextField>
                          </div>
                          <div className="mui-custom-form with-select input-md">
                            <TextField
                              required
                              id="mapID"
                              select
                              name="mapID"
                              label="Map ID"
                              onChange={(event) => handelInputChange(event)}
                              value={
                                !newProviderDate.mapID ||
                                newProviderDate.mapID === ""
                                  ? null
                                  : newProviderDate.mapID
                              }
                              placeholder="Please Select One"
                              InputLabelProps={{
                                shrink: true,
                              }}
                              helperText={
                                mapIdErr ? ErrorConst.Map_Id_Error : null
                              }
                              error={mapIdErr ? ErrorConst.Map_Id_Error : null}
                            >
                              <MenuItem value="-1">Please Select One</MenuItem>

                              {props.mapIdDropdown &&
                                props.mapIdDropdown.map((each) => (
                                  <MenuItem
                                    selected
                                    key={each.mapsetId}
                                    value={each.mapsetId}
                                  >
                                    {each.mapsetId}-{each.mapDesc}
                                  </MenuItem>
                                ))}
                            </TextField>
                          </div>

                          <div className="mui-custom-form with-select input-md">
                            <TextField
                              required
                              id="rateTypeCode"
                              select
                              name="rateTypeCode"
                              label="Rate Type Code"
                              onChange={(event) => handelInputChange(event)}
                              value={
                                !newProviderDate.rateTypeCode ||
                                newProviderDate.rateTypeCode === ""
                                  ? null
                                  : newProviderDate.rateTypeCode
                              }
                              helperText={
                                rateTypeCodeError
                                  ? ErrorConst.Rate_Type_Code_Error
                                  : null
                              }
                              error={
                                rateTypeCodeError
                                  ? ErrorConst.Rate_Type_Code_Error
                                  : null
                              }
                              placeholder="Please Select One"
                              InputLabelProps={{
                                shrink: true,
                              }}
                            >
                              <MenuItem value="-1">Please Select One</MenuItem>
                              {/* <MenuItem value="MCAID">MCAID - Title XIX Benefit Plan Network</MenuItem> */}
                              {props.dropdowns &&
                                props.dropdowns["R1#R_BP_COHRT_RATE_TY_CD"] &&
                                props.dropdowns["R1#R_BP_COHRT_RATE_TY_CD"].map(
                                  (each) => (
                                    <MenuItem
                                      selected
                                      key={each.code}
                                      value={each.code}
                                    >
                                      {each.description}
                                    </MenuItem>
                                  )
                                )}
                            </TextField>
                          </div>
                          <div className="mui-custom-form with-select input-md">
                            <TextField
                              InputLabelProps={{
                                shrink: true,
                              }}
                              required
                              name="rate"
                              id="rate"
                              label="Rate"
                              onChange={(event) => handelInputChange(event)}
                              inputProps={{ maxLength: 10 }}
                              value={newProviderDate.rate}
                              InputProps={{
                                startAdornment: (
                                  <InputAdornment position="start">
                                    $
                                  </InputAdornment>
                                ),
                              }}
                              helperText={
                                rateError
                                  ? ErrorConst.Rate_Error
                                  : RateErr
                                  ? ErrorConst.Invalid_Rate_Error
                                  : null
                              }
                              error={
                                rateError
                                  ? ErrorConst.Rate_Error
                                  : RateErr
                                  ? ErrorConst.Invalid_Rate_Error
                                  : null
                              }
                              
                              label="Rate"
                            />
                          </div>
                        </div>
                        <div className="flex-block">
                          <div className="mui-custom-form with-select input-md">
                            <TextField
                              InputLabelProps={{
                                shrink: true,
                              }}
                              required
                              name="seqNum"
                              label="rank"
                              onChange={(event) => handelInputChange(event)}
                              inputProps={{ maxLength: 5 }}
                              value={newProviderDate.seqNum}
                              helperText={
                                rankError
                                  ? ErrorConst.Rank_Error
                                  : showRankOverlapErr
                                  ? ErrorConst.RANK_TABLE_OVERLAP
                                  : showRankErrSpe
                                  ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                                  : showRankErrZero
                                  ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                                  : null
                              }
                              error={
                                rankError
                                  ? ErrorConst.Rank_Error
                                  : showRankOverlapErr
                                  ? ErrorConst.RANK_TABLE_OVERLAP
                                  : showRankErrSpe
                                  ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                                  : showRankErrZero
                                  ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                                  : null
                              }
                              id="standard-basic"
                              label="Rank"
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      </div>
    </>
  );
}
export default forwardRef(BenefitPlanCapitation);
