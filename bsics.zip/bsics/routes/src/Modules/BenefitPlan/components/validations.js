const isSpecialcharecter = function (data) {
    if (data && data.length !== '' && data.length !== 0) {
        var iChars = "!`@#$%^&*()+=-[]\\\';,/{}|\":<>?~_";
        for (var i = 0; i < data.length; i++) {
            if (iChars.indexOf(data.charAt(i)) != -1) {
                return true;
            }
        }
    }

    return false;
}

export default isSpecialcharecter