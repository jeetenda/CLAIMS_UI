import React, { useEffect, useState } from "react";
import { withRouter } from "react-router";
import TableComponent from "../../../SharedModules/Table/Table";

function CoInsLmtTableComponent(props) {
  const headCells = [
    {
      id: "bpNetworkCodeDesc",
      numeric: false,
      disablePadding: false,
      label: "Network Status",
      enableHyperLink: true,
      fontSize: 12,
    },
    {
      id: "mapSetID",
      numeric: false,
      disablePadding: false,
      label: "Map ID",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "beginDate",
      numeric: false,
      isDate: true,
      disablePadding: true,
      label: "Begin Date",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "endDate",
      numeric: false,
      isDate: true,
      disablePadding: false,
      label: "End Date",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "typeCode",
      numeric: false,
      disablePadding: false,
      label: "Code",
      enableHyperLink: false,
      fontSize: 12,
    },
    // {
    // 	id: "indAmount",
    // 	numeric: true,
    // 	disablePadding: false,
    // 	label: "Individual Limit",
    // 	enableHyperLink: false,
    // 	fontSize: 12
    // },
    // {
    // 	id: "indPlusAmount",
    // 	numeric: true,
    // 	disablePadding: false,
    // 	label: "Individual +1 Limit",
    // 	enableHyperLink: false,
    // 	fontSize: 12
    // },
    {
      id: "maximum",
      numeric: true,
      disablePadding: false,
      label: "Maximum",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "metExceptionCode",
      numeric: false,
      disablePadding: false,
      label: "Limit Met Exception Code",
      enableHyperLink: false,
      fontSize: 12,
      isToolTip: true,
      toolTip: "metExcnDesc",
    },
    {
      id: "overExceptionCode",
      numeric: false,
      disablePadding: false,
      label: "Limit Over Exception Code",
      enableHyperLink: false,
      fontSize: 12,
      isToolTip: true,
      toolTip: "ovrExcnDesc",
    },
    {
      id: "seqNum",
      numeric: false,
      disablePadding: false,
      label: "Rank",
      enableHyperLink: false,
      fontSize: 12,
    },
  ];

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
        if (each.indAmount && each.indPlusAmount && each.famAmount) {
          each.maximum =
            each.indAmount + "/" + each.indPlusAmount + "/" + each.famAmount;
        } else if (each.indAmount && each.indPlusAmount) {
          each.maximum = each.indAmount + "/" + each.indPlusAmount;
        } else if (each.indAmount && each.famAmount) {
          each.maximum = each.indAmount + "/" + each.famAmount;
        }
      });
      return tData;
    } else {
      return [];
    }
  };

  const editRow = (row) => (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, coinsurancelimitTab: false });
    props.BPCIscrolltoViewedit();
    props.setcoInsBenefitPlan(true);
    props.setnewCoInsPlan({
      beginDate: row.beginDate,
      endDate: row.endDate,
      mapSetID: row.mapSetID,
      benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
      typeCode: row.typeCode,
      indAmount: row.indAmount,
      indPlusAmount: row.indPlusAmount,
      famAmount: row.famAmount,
      overExceptionCode: row.overExceptionCode,
      metExceptionCode: row.metExceptionCode,
      bpNetworkCodeDesc: row.bpNetworkCodeDesc,
      typeCodeDesc: row.typeCodeDesc,
      seqNum: row.seqNum,
      index: row.index,
      row: row,
    });

    props.setresetCoInsPlan({
      beginDate: row.beginDate,
      endDate: row.endDate,
      mapSetID: row.mapSetID,
      benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
      typeCode: row.typeCode,
      indAmount: row.indAmount,
      indPlusAmount: row.indPlusAmount,
      famAmount: row.famAmount,
      overExceptionCode: row.overExceptionCode,
      metExceptionCode: row.metExceptionCode,
      bpNetworkCodeDesc: row.bpNetworkCodeDesc,
      typeCodeDesc: row.typeCodeDesc,
      seqNum: row.seqNum,
      index: row.index,
      row: row,
    });
  };

  return (
    <TableComponent
      headCells={headCells}
      tableData={getTableData(props.tabelRowData)}
      onTableRowClick={editRow}
      defaultSortColumn="seqNum"
     selected={props.selectDeleteArray} 
     setSelected={props.setSelectDeleteArray}
      multiDelete

    />
  );
}
export default withRouter(CoInsLmtTableComponent);
