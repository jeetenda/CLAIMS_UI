import React, { useState, useEffect,useRef } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import * as BenefitPlanConstants from './BenefitPlanConstants';
import * as moment from "moment";
import { resetSearchBenefitPlan, benefitPlanSearchAction, benefitPlanDetailsAction, benefitPlanDropdowns } from '../actions';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import BenefitPlanSearchForm from './BenefitPlanSearchForm';
import BenefitPlanSearchTableComponent from './BenefitPlanSearchTableComponent';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import { GET_APP_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';

//import queryString from 'query-string';

function BenefitPlanSearch(props) {
  console.log(props);
  let errorMessagesArray = [];
  const [showNoRecords, setShowNoRecords] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    benefitPlanType: '-1',
    benefitPlanId: '',
    benefitStartsOrContains: null,
    description: '',
    descriptionCodeStartsOrContains: null,
    beginDate: '',
    endDate: ''
  });
  const printRef = useRef();
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [{endDtInvalidErr,beginDtInvalidErr,benefitPlanIDerror, benefitPlanIDLengtherror, showdescriptionError, showdescriptionLengthError, showBgnDtGtEndDtError},
    setShowError] = React.useState(false);
  const [showTable, setShowTable] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const [urlSearch, setUrlSearch] = useState('');
  const paylod = useSelector(state => state.benefitPlan.payload);

  const dispatch = useDispatch();
  const onReset = () => dispatch(resetSearchBenefitPlan());
  const onSearch = searchvalues => { return dispatch(benefitPlanSearchAction(searchvalues))};
  const onSearchView = searchvalues => dispatch(benefitPlanDetailsAction(searchvalues));
  const benefitPlanDetails = useSelector(state => state.benefitPlan.benefitPlanDetails);
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
//   useEffect(()=>{

//     // if(props&&props.location&&props.location.search){

//     //     let query = new URLSearchParams(props.location.search);
//     //     let valsmember = query.get('memberID');
//     //     if(valsmember ){
//     //         setMemberIdVal(valsmember)
//     //         setTabValue(2);
//     //     }else{
//           if(props&&props.location&&props.location.search){

//         let vals = props.location.search.split('=')[1];
//         setspinnerLoader(true);
                   
            
//         let searchCriteria = {
//           "benefitPlanId": vals,
//           "benefitPlanIdStartsWithOrContains": values.benefitStartsOrContains === 'StartsWith' ? "0" : values.benefitStartsOrContains === 'Contains' ? "1" : null,
//           "descriptionCodeStartsOrContains": values.descriptionCodeStartsOrContains === 'StartsWith' ? "0" : values.descriptionCodeStartsOrContains === 'Contains' ? "1" : null,
//           "description": values.description !== '' ? values.description : null,
//           "benefitPlanType": values.benefitPlanType !== 'Please Select One' ? values.benefitPlanType : null,
//           "beginDateStr": values.beginDate !== '' ? values.beginDate : null,
//           "endDateStr": values.endDate !== '' ? values.endDate : null,
//           // "lob":""  
//         };
//         setValues({ ...values, benefitPlanId: vals });
//         setUrlSearch(new Date());
//       onSearch(searchCriteria);
//       setRedirect(true);
//       setspinnerLoader(true);
//       setShowTable(true);
       
//         //sonSearch(searchCretira);
//         }
    

// }, [])
  // values change function
    const handleChanges = name => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };

  const handleCIDtChanges = (name,date)=>{
    setAddCandIVAlue({...addCandIVAlue, [name]: date});
  }

  const handleDCDtChange = (name,date)=>{
    setValues({ ...values, [name]:date });
  }

  const tableErrorFunction = (error) => {
    seterrorMessages(error);
  }

  // reset table
  const resetTable = () => {
    setShowNoRecords(false);
    seterrorMessages([]);
    setShowError({
      showBenefitPlanIDError: false,
      showBenefitPlanTypeError: false,
      showBeginDateError: false,
      showEndDateError: false
    });
    setValues(
      {
        benefitPlanType: '-1',
        benefitPlanId: '',
        benefitStartsOrContains: null,
        description: '',
        descriptionCodeStartsOrContains: null,
        beginDate: '',
        endDate: ''
      }
    );
    setShowTable(false);
    onReset();
  };

  // search function
  const searchCheck = () => {
    setShowTable(false);
    setspinnerLoader(false);
    errorMessagesArray = [];
    seterrorMessages([]);
    let benefitPlanIDerror;
    let showdescriptionError;
    let benefitPlanIDLengtherror;
    let showdescriptionLengthError;
    let showBgnDtGtEndDtError;
    let beginDtInvalidErr;
    let endDtInvalidErr;
   
    if((values.benefitStartsOrContains && !values.benefitPlanId )){
      benefitPlanIDerror=true;
      errorMessagesArray.push(BenefitPlanConstants.BenefitPlanID_Err);
      seterrorMessages(errorMessagesArray);
    }
    
    if (values.benefitPlanId &&  values.benefitPlanId.length < 2 && values.benefitStartsOrContains) {
      benefitPlanIDLengtherror =true
      errorMessagesArray.push(BenefitPlanConstants.BenefitPlan_Error);
      seterrorMessages(errorMessagesArray);
    }
    if (values.descriptionCodeStartsOrContains && !values.description) {
      showdescriptionError = true;
      errorMessagesArray.push(BenefitPlanConstants.BenefitPlanDescription_Error);
      seterrorMessages(errorMessagesArray);
    } 
    if (values.description && values.description.length < 2) {
      showdescriptionLengthError = true;
      errorMessagesArray.push(BenefitPlanConstants.Description_Error);
      seterrorMessages(errorMessagesArray);
    } 
    if (
      values.beginDate != "" &&
      values.beginDate !== null &&
      values.beginDate == "NaN/NaN/NaN"
    ) {
      beginDtInvalidErr = true;
      errorMessagesArray.push(
        BenefitPlanConstants.Plan_Invalid_Begin_Date_Error
      );
    }
    if (
      values.endDate != "" &&
      values.endDate !== null &&
      values.endDate == "NaN/NaN/NaN"
    ) {
      endDtInvalidErr = true;
      errorMessagesArray.push(
        BenefitPlanConstants.Plan_Invalid_End_Date_Error
      );
    }
    if (values.beginDate && values.endDate && moment(values.beginDate).isSameOrAfter(values.endDate)) {
      showBgnDtGtEndDtError = true;
      errorMessagesArray.push(BenefitPlanConstants.DATE_RANGE_ERROR);
      seterrorMessages(errorMessagesArray);
    }
    if (errorMessagesArray.length == 0) {
        let searchCriteria = {
          "benefitPlanId": values.benefitPlanId !== '' ? values.benefitPlanId : null,
          "benefitPlanIdStartsWithOrContains": values.benefitStartsOrContains === 'StartsWith' ? "0" : values.benefitStartsOrContains === 'Contains' ? "1" : null,
          "descriptionCodeStartsOrContains": values.descriptionCodeStartsOrContains === 'StartsWith' ? "0" : values.descriptionCodeStartsOrContains === 'Contains' ? "1" : null,
          "description": values.description !== '' ? values.description : null,
          "benefitPlanType": values.benefitPlanType !== '-1' ? values.benefitPlanType : null,
          "beginDateStr": values.beginDate !== '' ? values.beginDate : null,
          "endDateStr": values.endDate !== '' ? values.endDate : null,
          // "lob":""  
        };
      onSearch(searchCriteria);
      setRedirect(true);
      setspinnerLoader(true);
      setShowTable(true);
    }
    setShowError({
      benefitPlanIDerror,
      benefitPlanIDLengtherror,
      showdescriptionError,
      showdescriptionLengthError,
      showBgnDtGtEndDtError,
      beginDtInvalidErr,
      endDtInvalidErr
    });
  };

  const addBenefitPlan = () => {
    onReset();
    props.history.push({
      pathname: '/BenefitPlanDetails'
    })
  }

  // on Benefit Plan page load
  useEffect(() => {
   // onReset();
    if (paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      setShowTable(true);
      // if (paylod.length == 0) {
      //   setShowNoRecords(true);
      //}
    }
    onDropdowns(
    [Dropdowns.BENEFIT_PLAN_TYPE]
    );

    if(props&&props.location&&props.location.search){
      let vals = props.location.search.split('=')[1];
      var query = new URLSearchParams(props.location.search);
      let memberId =  query.get('memberID');
      if(!memberId){
      setValues({ ...values, benefitPlanId: vals });
      setUrlSearch(new Date());
      }
   }
  }, []);

  useEffect(() => {if (urlSearch != '') searchCheck()},[urlSearch]);
  // on diagnosis page search data
  useEffect(() => {
    if (paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      setspinnerLoader(false);
    }
    if (paylod && paylod.message != null) {
      setspinnerLoader(false);
      errorMessagesArray.push(BenefitPlanConstants.ERROR_OCCURED_DURING_TRANSACTION);
      seterrorMessages(errorMessagesArray);
    }
    if (paylod != null && paylod.length == 0) {
      setShowNoRecords(true);
    }
    if (paylod != null && paylod.length == 1 && redirect) {
      const benefitPlanViewData = paylod[0]
      onSearchView({ benefitPlanID: benefitPlanViewData.benefitPlanID, lobCode: benefitPlanViewData.lobCode });
      setspinnerLoader(true);
    }
  }, [paylod]);

  return (
    
    <div className="pos-relative" >
      {spinnerLoader ? <Spinner /> : null}
      <div ref={printRef}>
      { errorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert" role="alert">
          {errorMessages.map(message => <li>{message}</li>)
        }
        </div>
      ) : null
     }
      { errorMessages.length == 0 && paylod && paylod.length == 0 && showNoRecords ? (
        <div className="alert alert-danger custom-alert" role="alert">
          <li>{BenefitPlanConstants.NO_RECORDS_FOUND}</li>
        </div>
      ) : null
     }
      <div className="mb-2">
				 <BreadCrumbs
					parent="Benefits"
					child1="Search Benefit Plan"
					path="SearchBenefitPlan"
				 />
      </div>
      <div className="tabs-container"  >
        <div className="tab-header">
          <h1 className="tab-heading page-heading float-left">
            Search Benefit Plan
          </h1>
          <div className="float-right th-btnGroup">
          <Button title="Add Benefit Plan" variant="outlined" color="primary" className="btn btn-ic btn-add" onClick={() => addBenefitPlan()} disabled={props.privileges && !props.privileges.add? 'disabled':'' }>
          Add
            </Button>
            <Button title="Audit Log" variant="outlined" color="primary" className="btn btn-ic btn-audit">
                   AUDIT LOG
                </Button>
                <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))}
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
              Print
            </Button>)}
              content={() => printRef.current}
            />
           
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
            Help
            </Button>
          </div>
          <div className="clearfix" />
        </div>
        
        <div className="tab-body mt-2">
        <BenefitPlanSearchForm values={values} handleChanges={handleChanges} handleDCDtChange={handleDCDtChange} resetTable={resetTable} searchCheck={searchCheck} dropdowns={addDropdowns} errors={{endDtInvalidErr,beginDtInvalidErr,benefitPlanIDerror, benefitPlanIDLengtherror, showdescriptionError, showdescriptionLengthError, showBgnDtGtEndDtError}} privileges={props.privileges}/>

        {
          showTable && paylod && paylod.length > 0 ? (
            <div className="tab-holder mr-3 ml-3">
              <BenefitPlanSearchTableComponent
                tableData={paylod}
                tableErrorFunction={tableErrorFunction}
                setspinnerLoader={setspinnerLoader}
                setRedirect={setRedirect}
                redirect={redirect}
              />

            </div>
          ) : null
        }
        </div>
        <Footer print />
      </div>
      </div>
    </div>
  );
}
export default withRouter(BenefitPlanSearch);
