import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import TabPanel from '../../../SharedModules/TabPanel/TabPanel';
import { withRouter } from 'react-router';
import React, { useState, useEffect,useRef } from 'react';
import { Button } from 'react-bootstrap';
import Axios from 'axios';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import * as serviceEndPoint from '../../../SharedModules/services/service';
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import MainbenifitPlan from './MainBenifitPlan';
import BenifitPlanCoverage from './BenifitPlanCoverage';
import BenifitPlanSAReq from './BenefitPlanSAReq';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS, GET_NETWORKID_DROPDOWN,GET_MAP_SET_ID,GET_SYSTEM_LIST_NONVV_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';
import { useDispatch, useSelector } from 'react-redux';
import BenifitPlanForm from './BanifitPlanForm';
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import { resetSearchBenefitPlan , benefitPlanDetailsAction} from '../actions';
import BenefitPlanLimits from './BenefitPlanLimits';
import BenefitPlanCostShare from './BenefitPlanCostShare';
import { useStaticState } from '@material-ui/pickers';
import BenefitPlanCoInsLmt from "./BenefitPlanCoInsLmt";
import BPCostShareCoInsurance from "./BPCostShareCoInsurance";
import BenefitPlanDeductible from "./BenefitPlanDeductible";
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';

function a11yProps(index) {
    return {
      id: `scrollable-auto-tab-${index}`,
      'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}


function BenifitPlanAdd(props){
    const dispatch = useDispatch();
    const printRef = useRef();
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
    const benefitPlanDetails = useSelector(state => state.benefitPlan.benefitPlanDetails);
    // const sample = useSelector(state => state.benefitPlan.benefitPlanDetails.benefitPlanLimit);
    // console.log(sample);
    const benefitPlanDetailsTime = useSelector(state => state.benefitPlan.benefitPlanDetailsTime);
    const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
    const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
    const onNetworkidDropdown = () => dispatch(GET_NETWORKID_DROPDOWN());
    const onMapSetIdDropdown  = () => dispatch(GET_MAP_SET_ID());
    const networkidDropdown = useSelector(state => state.appDropDowns.networkIdDropdown);
    const onNonVvDropdown = (values) => dispatch(GET_SYSTEM_LIST_NONVV_DROPDOWNS(values));
    const mapIdDropdown = useSelector(state => state.appDropDowns.mapIDDropdown);
    const onSearchView = searchvalues => dispatch(benefitPlanDetailsAction(searchvalues));
    const nonVvDropdown = useSelector(state => state.appDropDowns.nonvvdropdowns);
    const [tabValue, setTabValue] = useState(0);
    const [newState, setNewState] = useState([]);
    const [newCohortState,setNewCohortState] = useState([])
    const [newSaReqState,setNewSaReqState] = useState([]);
    const [newCovState, setNewCovState] = useState([]);
    const [benefitPlanLimit, setNewBenefitPlantLimit] = useState([]);
    const [benefitPlanCopay, setNewBenefitPlanCopay] = useState([]);
    const [newCoInsState,setNewCoInsLmt] =useState([]);
    const [benefitPlanCopayLimit, setNewBenefitPlantCopayLimit] = useState([]);
    const [benefitPlanCoInsurance, setNewBenefitPlantCoInsurance] = useState([]);
    const [bpCoInsDeleteItems,setbpCoInsDeleteItems] = useState([]);
    const [coPayDeleteItems,setcoPayDeleteItems] = useState([]);
    const [coPayLimitDeleteItems,setcoPayLimitDeleteItems] = useState([]);
    const [values, setValues] = useState({});
    const [{ nwtAssReqErr,lobIdError,benefitPlanIDError,benefitPlanDescError,planBeginDateError,planEndDateError,planTypeErr,planOptionErr,planStatusErr,currprocErr,retroprocErr,beginDtInvalidErr,endDtInvalidErr,businessUnitdSpclCharErr, planDescSpclCharErr},setShowError] = React.useState(false);
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const [successMessages, setSuccessMessages] = React.useState([]);
    const [deleteRow, setDeleteRow] = useState([]);
    const [deleteCovRow, setDeleteCovRow] = useState([]);
    const [deleteSARow, setDeleteSARow] = useState([]);
    const [deleteCoInsLmt, setDeleteCoInsLmt] = useState([]);
    const [bpLimitsDeleteItems,setbpLimitsDeleteItems] = useState([]);
    const [bpDeductableState , setBpDeductableState] = useState([]);
    const [deductibleDeleteRow, setDeductibleDeleteRow] = useState([]);
    const [deleteCohortRow,setDeleteCohortRow] = useState([]);
    const [tabChangeValue, setTabChangeValue] = useState({mainTab: false,coverageTab:false,SaReqTab:false
        ,capitationTab:false,planLimitTab:false,copayTab:false,copaylimitTab:false,
        coinsuranceTab:false,coinsurancelimitTab:false,deductibleTab:false });
        const mainTabRef = useRef();
        const coverageRef = useRef();
        const saRef = useRef();
        const planLimitRef = useRef();
        const costshareRef = useRef();
        const coInsRef = useRef();
        const coInsLmtRef = useRef();
        const deductibleRef = useRef();

    const [mainValues, setMainValues] = useState({
        planType: '-1',
        optionsCode: '-1',
        benefitPlanStatCode: '-1'
    })

    const [capitationValues, setcapitationValues] = useState({
        currentProcCode: '-1',
        retroProcCode: '-1',
        futureProcCode: '-1',

    })
    

    const [holdbackVo1Values, setholdbackVo1Values] = useState({
        funcAreaCode: null,
        sysParamNum: null,
    })

    const [holdbackVo2Values, setholdbackVo2Values] = useState({
        funcAreaCode: '-1',
        sysParamNum: '-1',
    })

    const [coverageValues, setCoverageValues] = useState({
        netWorkStatus: '-1',
        MapId: '-1',
        coverageendDate: "12/31/9999",
        coveragebeginDate:'',
        coverageRank:''
    })
    const [updateTest, setUpdateTest] = useState(new Date());
    const [errorMessages, seterrorMessages] = React.useState([]);
    const [formValues, setFormValues] = useState({
        lobId: '',
        lobDesc:'',
        benefitPlanID:'',
		endDate: "12/31/9999",
        beginDate:'',
        benefitPlanAddlDesc:'',
        benefitPlanDesc:''
    })
    const onReset = () => dispatch(resetSearchBenefitPlan());
    const handleTabChange = (event, newValue) => {
        if (tabValue == 0 ) {
          if (tabChangeValue.mainTab || tabChangeValue.capitationTab) {
        mainTabRef.current.validateFn();
          }
          setTabValue(newValue);
        }else if (tabValue == 1) {
          if (tabChangeValue.coverageTab) {
            coverageRef.current.validateFn();
          }
          setTabValue(newValue);
        }
        else if (tabValue == 2) {
          if (tabChangeValue.SaReqTab) {
            saRef.current.validateFn();
          }
          setTabValue(newValue);
        }
        else if (tabValue == 3) {
          if (tabChangeValue.planLimitTab) {
            planLimitRef.current.validateFn();
          }
          setTabValue(newValue);
        } else if (tabValue == 4) {
          if (tabChangeValue.copayTab || tabChangeValue.copaylimitTab ) {
            costshareRef.current.validateFn();
          }
          if(tabChangeValue.coinsuranceTab){
           coInsRef.current.validateFn();
            }
          if(tabChangeValue.coinsurancelimitTab){
              coInsLmtRef.current.validateFn();
               }
          if(tabChangeValue.deductibleTab){
                deductibleRef.current.validateFn();
          }
          
        setTabValue(newValue);
    
        } else {
          setTabValue(newValue);
        }
      };

    const handleChanges= (name)=> event => {
        setFormValues({...formValues, [name]: event.target.value});
    }
   
    const handleDCDtChange = (name,date)=>{
        setFormValues({ ...formValues, [name]:date });
    }

    const handleMainChanges= (name)=> event => {
      //  setTabChangeValue({ ...tabChangeValue, mainTab: true })
        setMainValues({...mainValues, [name]: event.target.value});
        if( event.target.value == "2"||
     parseInt( event.target.value) == 2|| parseInt( event.target.value) == 3|| event.target.value=="3") {
      var index = errorMessages.indexOf(ErrorConst.Current_Procedure_Error);
      if(index!==-1)errorMessages.splice(index, 1);
      var index1 = errorMessages.indexOf(ErrorConst.Retro_Procedure_Error);
      if(index1!==-1)errorMessages.splice(index, 1); 
      
    }
    }

    const handleCapitationChanges = (name) => event => {
        setcapitationValues({...capitationValues,[name]: event.target.value})
    }

    const handleholdbackVo1Changes = (name) => event => {
        setholdbackVo1Values({...holdbackVo1Values,[name]: event.target.value,
         updFlag : true
        })
    }

    const handleholdbackVo2Changes = (name) => event => {
        setholdbackVo2Values({...holdbackVo2Values,[name]: event.target.value,
            updFlag : true
           })
       }
    const handleCoverageChanges= (name)=> event => {
        setCoverageValues({...coverageValues, [name]: event.target.value});
    }

    useEffect(() => {
        onNonVvDropdown([
            Dropdowns.SYSTEM_PARAMETER_NUMBER,
            Dropdowns. SYSTEM_PARAMETER_NUMBER_2,
             Dropdowns.FUNCTIONAL_AREA_CODE,
             Dropdowns.FUNCTIONAL_AREA_CODE_2,
             Dropdowns.RETRO_PROC_CODE_21,
             Dropdowns.RETRO_PROC_CODE_31,
             Dropdowns.RETRO_PROC_CODE_41,
             Dropdowns.CURRENT_PROC_CODE_20,
             Dropdowns.CURRENT_PROC_CODE_30,
             Dropdowns.CURRENT_PROC_CODE_40,
             Dropdowns.FUTURE_PROC_CODE 
        ])
        onDropdowns([Dropdowns.CO_INSURANCE_TYPE_CODE,
            Dropdowns.BENEFIT_PLAN_TYPE,
             Dropdowns.REV_LOB, 
             Dropdowns.NW_STATUS,
             Dropdowns.COPAY_TYPE_CODE,
             Dropdowns.INS_LMT_TYPE_CODE ,
             Dropdowns.MAP_SET_ID,
             Dropdowns.SERVICE_TYPE_PROIVDER,
             Dropdowns.PROVIDER_TYPE,
             Dropdowns.LIMIT_TY_CODE,
             Dropdowns.LIMIT_TY_CODE,
             Dropdowns.BYPASS_IF_CATEGORY_FUNCTIONAL_AREA, 
             Dropdowns.PROVIDER_NETWORK, 
             Dropdowns.BENEFIT_PLAN_OPTION,
             Dropdowns.BENEFIT_PLAN_STATUS,
             Dropdowns.SA_RULE,
             Dropdowns.DEDUCTIBLE_CODE ,
             Dropdowns.RATE_TYPE_CODE
              
            ]);
        onNetworkidDropdown();   
        onMapSetIdDropdown(); 

        if (props.showSuccessMessage) {
            setSuccessMessages(["Benefit Plan added successfully."])
            props.setShowSuccessMessage(false);
        }
    }, []);

    useEffect(() => {
        setMainValues({
            planType: benefitPlanDetails.planType.split('-')[0],
            optionsCode: benefitPlanDetails.optionsCode.split('-')[0],
            benefitPlanStatCode: benefitPlanDetails.benefitPlanStatCode.split('-')[0]
        });
        benefitPlanDetails.caseMgmnt[0] ?
        setcapitationValues(benefitPlanDetails.caseMgmnt[0]) : setcapitationValues([]);
        setholdbackVo1Values(benefitPlanDetails.benefitPlanMCOHoldbackVO1);
        setholdbackVo2Values(benefitPlanDetails.benefitPlanMCOHoldbackVO2);
        setFormValues({
            lobId: benefitPlanDetails.lobId,
            lobDesc: benefitPlanDetails.lobDesc,
            benefitPlanID: benefitPlanDetails.benefitPlanID,
            endDate: benefitPlanDetails.endDate,
            beginDate: benefitPlanDetails.beginDate,
            benefitPlanAddlDesc: benefitPlanDetails.benefitPlanAddlDesc,
            benefitPlanDesc: benefitPlanDetails.benefitPlanDesc
        });

        setNewState(benefitPlanDetails.benefitPlanNwAssoc);
        setNewCohortState(benefitPlanDetails.benefitPlanCohort)
        setNewCovState(benefitPlanDetails.benefitPlanCoverage);
        setNewSaReqState(benefitPlanDetails.benefitPlanSA)
        setNewBenefitPlantLimit(benefitPlanDetails.benefitPlanLimit);
        setNewBenefitPlanCopay(benefitPlanDetails.benefitPlanCoPay);
        setNewBenefitPlantCopayLimit(benefitPlanDetails.benefitPlanCoPayLMT)
        setNewCoInsLmt(benefitPlanDetails.benefitPlanCoInsLMT)
        setNewBenefitPlantCoInsurance(benefitPlanDetails.benefitPlanCoIns)
        setValues(benefitPlanDetails);
        setBpDeductableState(benefitPlanDetails.benefitPlanDeductable);
        setUpdateTest(new Date());
    }, [benefitPlanDetailsTime])

    const addBenefitPlan = () => {
        onReset();
      }
	
      const majorSave=()=>{
          
        seterrorMessages([]);
		setSuccessMessages([]);


        let reqFieldArr = [];
        let alphaNumRegex = /^[0-9a-zA-Z \s-]+$/;

		setShowError({
			lobIdError: formValues.lobId?false:(()=>{reqFieldArr.push(ErrorConst.LOB_ID_Error);return true;})(),
			benefitPlanIDError: formValues.benefitPlanID?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_ID_Error);return true;})(),      
			benefitPlanDescError: formValues.benefitPlanDesc?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Desc_Error);return true;})(),       
			planBeginDateError: formValues.beginDate?false:(()=>{reqFieldArr.push(ErrorConst.Begin_Date_Error);return true;})(),
			planEndDateError: formValues.endDate?false:(()=>{reqFieldArr.push(ErrorConst.End_Date_Error);return true;})(),
            planTypeErr: mainValues.planType && mainValues.planType != -1?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Type_Error);return true;})(),
            planOptionErr: !(isNaN(mainValues.optionsCode) || parseInt(mainValues.optionsCode) == -1)?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Option_Error);return true;})(),
            planStatusErr: mainValues.benefitPlanStatCode || mainValues.benefitPlanStatCode != -1?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Status_Error);return true;})(),
            //nwtAssReqErr: newState.length > 0 ? false : (()=>{reqFieldArr.push(ErrorConst.NWTACC_REQ_Error);return true;})(),
            currprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.currentProcCode && capitationValues.currentProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Current_Procedure_Error);return true;})():false,
            retroprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.retroProcCode && capitationValues.retroProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Retro_Procedure_Error);return true;})():false,
        });
		
		if(reqFieldArr.length){
			seterrorMessages(reqFieldArr);
			return false;
		}

		setShowError({
			beginDtInvalidErr: formValues.beginDate.toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);return true;})():false,
			endDtInvalidErr: formValues.endDate.toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);return true;})():false,
		});
		if(reqFieldArr.length){
			seterrorMessages(reqFieldArr);
			return false;
		}  
		setShowError({
			showBgdtGTEnddtErr: (new Date(formValues.beginDate) <= new Date(formValues.endDate))?false:(()=>{reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);return true;})(),
		});
		if(reqFieldArr.length){
			seterrorMessages(reqFieldArr);
			return false;
        } 

          if (formValues.benefitPlanAddlDesc !== "" && !alphaNumRegex.test(formValues.benefitPlanAddlDesc)) {
              setShowError({
                  businessUnitdSpclCharErr: true,
              });
              reqFieldArr.push(ErrorConst.BENEFIT_BUSS_UNIT_SPCL_CHAR_ERR);
              seterrorMessages(reqFieldArr);
              return false;
          }
          if (formValues.benefitPlanDesc !== "" && !alphaNumRegex.test(formValues.benefitPlanDesc)) {
              setShowError({
                  planDescSpclCharErr: true,
              });
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_DESC_SPCL_CHAR_ERR);
              seterrorMessages(reqFieldArr);
              return false;
          }
        setSuccessMessages([]);
        setspinnerLoader(true);
            //update service
            const data={
            "auditUserID": values.auditUserID,
            "auditTimeStamp": values.auditTimeStamp,
            "addedAuditUserID": values.addedAuditUserID,
            "addedAuditTimeStamp": values.addedAuditTimeStamp,
            "versionNo": values.versionNo,
            "dbRecord": values.dbRecord,
            "sortColumn": values.sortColumn,
            "auditKeyList": values.auditKeyList,
            "auditKeyListFiltered": values.auditKeyListFiltered,
            "planType": mainValues.planType,
            "lobId": formValues.lobId,
            "lobDesc": formValues.lobDesc,
            "benefitPlanID": formValues.benefitPlanID,
            "optionsCode": mainValues.optionsCode,
            "benefitPlanStatCode": mainValues.benefitPlanStatCode,
            "code": values.code,
            "endDate": formValues.endDate,
            "beginDate": formValues.beginDate,
            "benefitPlanDesc": formValues.benefitPlanDesc,
            "benefitPlanAddlDesc": formValues.benefitPlanAddlDesc,
            "benefitPlanCoIns": benefitPlanCoInsurance,
         //   "benefitPlanCoInsLMT": values.benefitPlanCoInsLMT,
            "benefitPlanCoInsLMT": newCoInsState,
            // "benefitPlanCoPay": values.benefitPlanCoPay,
            "benefitPlanCoPay":benefitPlanCopay,
            // "benefitPlanCoPayLMT": values.benefitPlanCoPayLMT,
            "benefitPlanCoPayLMT":benefitPlanCopayLimit,
            "benefitPlanCutBackCntl": values.benefitPlanCutBackCntl,
           // "benefitPlanCoverage": values.benefitPlanCoverage,
           "benefitPlanCoverage": newCovState,
            "benefitPlanDeductable": bpDeductableState,
            // "benefitPlanLimit": values.benefitPlanLimit,
            "benefitPlanLimit":benefitPlanLimit,
            "benefitPlanNwAssoc": newState,
            "benefitPlanOOP": values.benefitPlanOOP,
           // "benefitPlanSA": values.benefitPlanSA,
            "benefitPlanSA":newSaReqState,
            "benefitPlanCohort": newCohortState,
            "benefitPlanRank": values.benefitPlanRank,
            "caseMgmnt": capitationValues.length==0?[]:[capitationValues],
            "bpCohortDeleteItems": deleteCohortRow,
            "bpNwAssocDeleteItems": deleteRow,
            "bpCoverageDeleteItems": deleteCovRow,
            "bpSADeleteItems": deleteSARow,
            "bpLimitsDeleteItems": bpLimitsDeleteItems,
            "bpCoPayDeleteItems": coPayDeleteItems,
            "bpCoPayLimitDeleteItems": coPayLimitDeleteItems,
            "bpCoInsDeleteItems": bpCoInsDeleteItems,
            "bpCoInsLimitDeleteItems": deleteCoInsLmt,
            "bpDeductibleDeleteItems": deductibleDeleteRow,
            "bpOOPDeleteItems": values.bpOOPDeleteItems,
            "bpCutBackCntlDeleteItems": values.bpCutBackCntlDeleteItems,
            "benefitPlanMCOProcedure": values.benefitPlanMCOProcedure,
            "ratePCBenefitPlan": values.ratePCBenefitPlan,
            "ratePCProviderBenefitPlan": values.ratePCProviderBenefitPlan,
            "rateRCBenefitPlan": values.rateRCBenefitPlan,
            "benefitPlanToId": values.benefitPlanToId,
            "benefitPlanFromId": values.benefitPlanFromId,
            "eligibilityMCTMaps": values.eligibilityMCTMaps,
            "hiosPlanID": values.hiosPlanID,
            "dbEndDate": values.dbEndDate,
            "dbBeginDate": values.dbBeginDate,
            "dbDesc": values.dbDesc,
            "dbAddlDesc": values.dbAddlDesc,
            "dbTypeCode": values.dbTypeCode,
            "dbOptionsCode": values.dbOptionsCode,
            "dbBenefitPlanStatCode": values.dbBenefitPlanStatCode,
            "benefitPlanMCOHoldbackVO1": holdbackVo1Values ,
            "benefitPlanMCOHoldbackVO2": holdbackVo2Values ,
            "noteSetSK": values.noteSetSK
        }   
        
       // console.log("detete request"+JSON.stringify(data))

             Axios.post(`${serviceEndPoint.BENEFIT_PLAN_UPDATE_ENDPOINT}/${values.benefitPlanID}`,data).then(res=>{      
                setspinnerLoader(false);
                //resetAddDCMainForm();
                res.data.success===true?serviceSuccessHandel():res.data.success===false&&res.data.message
                ?seterrorMessages([res.data.message]):seterrorMessages(["Benefit Plan not updated."]);
                
                // serviceSuccessHandel();
            }).catch(e=>{
                setspinnerLoader(false);      
                seterrorMessages([e.message]);
            })
    }

    const serviceSuccessHandel = () => {
        // setSuccessMessages(["Procedure code added successfully."])
        // props.setShowSuccessMessage(true);
        setSuccessMessages(["Benefit Plan updated successfully."])
        onSearchView({ benefitPlanID: formValues.benefitPlanID, lobCode: formValues.lobId });
    }

    const majorValidations = () => {
      seterrorMessages([]);
      setSuccessMessages([]);
  
  
          let reqFieldArr = [];
          let alphaNumRegex = /^[0-9a-zA-Z \s-]+$/;
  
      setShowError({
        lobIdError: formValues.lobId?false:(()=>{reqFieldArr.push(ErrorConst.LOB_ID_Error);return true;})(),
        benefitPlanIDError: formValues.benefitPlanID?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_ID_Error);return true;})(),      
        benefitPlanDescError: formValues.benefitPlanDesc?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Desc_Error);return true;})(),       
        planBeginDateError: formValues.beginDate?false:(()=>{reqFieldArr.push(ErrorConst.Begin_Date_Error);return true;})(),
        planEndDateError: formValues.endDate?false:(()=>{reqFieldArr.push(ErrorConst.End_Date_Error);return true;})(),
              planTypeErr: mainValues.planType && mainValues.planType != -1?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Type_Error);return true;})(),
              planOptionErr: !(isNaN(mainValues.optionsCode) || parseInt(mainValues.optionsCode) == -1)?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Option_Error);return true;})(),
              planStatusErr: mainValues.benefitPlanStatCode || mainValues.benefitPlanStatCode != -1?false:(()=>{reqFieldArr.push(ErrorConst.Benefit_Plan_Status_Error);return true;})(),
              //nwtAssReqErr: newState.length > 0 ? false : (()=>{reqFieldArr.push(ErrorConst.NWTACC_REQ_Error);return true;})(),
              currprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.currentProcCode && capitationValues.currentProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Current_Procedure_Error);return true;})():false,
              retroprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.retroProcCode && capitationValues.retroProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Retro_Procedure_Error);return true;})():false,
         });
      
      if(reqFieldArr.length){
        seterrorMessages(reqFieldArr);
        return false;
      }
  
      setShowError({
        beginDtInvalidErr: formValues.beginDate.toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);return true;})():false,
        endDtInvalidErr: formValues.endDate.toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);return true;})():false,
      });
      if(reqFieldArr.length){
        seterrorMessages(reqFieldArr);
        return false;
      }  
      setShowError({
        showBgdtGTEnddtErr: (new Date(formValues.beginDate) <= new Date(formValues.endDate))?false:(()=>{reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);return true;})(),
      });
      if(reqFieldArr.length){
        seterrorMessages(reqFieldArr);
        return false;
          } 
  
            if (formValues.benefitPlanAddlDesc !== "" && !alphaNumRegex.test(formValues.benefitPlanAddlDesc)) {
                setShowError({
                    businessUnitdSpclCharErr: true,
                });
                reqFieldArr.push(ErrorConst.BENEFIT_BUSS_UNIT_SPCL_CHAR_ERR);
                seterrorMessages(reqFieldArr);
                return false;
            }
            if (formValues.benefitPlanDesc !== "" && !alphaNumRegex.test(formValues.benefitPlanDesc)) {
                setShowError({
                    planDescSpclCharErr: true,
                });
                reqFieldArr.push(ErrorConst.BENEFIT_PLAN_DESC_SPCL_CHAR_ERR);
                seterrorMessages(reqFieldArr);
                return false;
            }
            return true;


    }
    const searchBenefitPlan = () => {
      props.setCancelType(true);
      props.history.push({
        pathname: '/SearchBenefitPlan'
      })
    }
    return(
    <div className="tabs-container">
        {spinnerLoader ? <Spinner /> : null}
        { errorMessages.length > 0 ? (
				<div className="alert alert-danger custom-alert" role="alert">
				{errorMessages.map(message => <li>{message}</li>)
				}
				</div>
			) : null
            }
            { successMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {successMessages.map(message => <li>{message}</li>)
        }
        </div>
      ) : null
     }
     <div className="mb-2">
				 <BreadCrumbs
          parent="Benefits"
          child1="Search Benefit Plan"
					child2="Edit Benefit Plan"
					path="SearchBenefitPlan"
				 />
      </div>
      <div className="tab-container" ref={printRef}>
        <div className="tab-header">
            <h1 className="page-heading float-left">Edit Benefit Plan</h1>
            <div className="float-right th-btnGroup">           
             <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => majorSave()}  disabled={props.privileges && !props.privileges.update? 'disabled':''}  >
             Save
             </Button>
             <Button title="Notes" variant="outlined" color="primary" className="btn btn-ic btn-notes">
             Notes
            </Button>
             <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => searchBenefitPlan()} >
              Cancel
             </Button>
             <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))}
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-primary">
              <i className="fa fa-print" />
              Print
            </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
            Help
            </Button>
            </div>
        </div>
        <div className="tab-body mt-3">
        <BenifitPlanForm values={formValues} handleChanges={handleChanges} updateTest={updateTest} handleDCDtChange={handleDCDtChange} dropdowns={addDropdowns} edit={true} errors={{ lobIdError,benefitPlanIDError,benefitPlanDescError,planBeginDateError,planEndDateError,beginDtInvalidErr,endDtInvalidErr,businessUnitdSpclCharErr, planDescSpclCharErr}}/>
        <div className="tab-container container-space">
        <div className="tab-body-bordered my-2">
        <div className='tab-holder custom-tabber pb-3'>
        <AppBar position='static' color="default">
            <Tabs value={tabValue} onChange={handleTabChange} aria-label='simple tabs example'>
                <Tab  className={tabChangeValue.mainTab || tabChangeValue.capitationTab ? "tab-error" : ""} title="Benefit Plan-Main" label="Benefit Plan-Main" {...a11yProps(0)}/>
                <Tab className={tabChangeValue.coverageTab? "tab-error" : ""} title="Coverage" label="Coverage" {...a11yProps(1)}/>
                <Tab className={tabChangeValue.SaReqTab? "tab-error" : ""} title="SA Requirements" label="SA Requirements" {...a11yProps(2)}/>
                <Tab className={tabChangeValue.planLimitTab? "tab-error" : ""} title="Plan Limits" label="Plan Limits"{...a11yProps(3)}/>
                <Tab className={tabChangeValue.copayTab || tabChangeValue.copaylimitTab || 
                              tabChangeValue.coinsuranceTab || tabChangeValue.coinsurancelimitTab || 
                              tabChangeValue.deductibleTab ? "tab-error" : ""} title="Cost Share" label="Cost Share" {...a11yProps(4)}/>
                
            </Tabs>
        </AppBar>
        
        <TabPanel value={tabValue} index={0}>
            <MainbenifitPlan setNewState={setNewState} seterrorMessages={seterrorMessages} handleChanges={handleChanges} newState={newState} dropdowns={addDropdowns} networkidDropdown={networkidDropdown}
            formValues={formValues} setShowError={setShowError} mainValues={mainValues} setMainValues={setMainValues} handleMainChanges={handleMainChanges} handleCapitationChanges = {handleCapitationChanges} values={values} edit={true} errors={{ planTypeErr,planOptionErr,planStatusErr }}
            deleteRow={deleteRow} setDeleteRow={setDeleteRow} 
            capitationValues={capitationValues}
            setcapitationValues={setcapitationValues}
            setholdbackVo1Values = {setholdbackVo1Values}
            holdbackVo1Values = {holdbackVo1Values}
            setholdbackVo2Values = {setholdbackVo2Values}
            holdbackVo2Values = {holdbackVo2Values}
            setNewCohortState = {setNewCohortState}
            newCohortState = {newCohortState}
            handleholdbackVo2Changes = {handleholdbackVo2Changes}
            handleholdbackVo1Changes = {handleholdbackVo1Changes}
            mapIdDropdown={mapIdDropdown}
            deleteCohortRow = {deleteCohortRow}
            setDeleteCohortRow = {setDeleteCohortRow}
            nonVvDropdown = {nonVvDropdown}
            currprocErr = {currprocErr}
            retroprocErr = {retroprocErr}
            tabChangeValue = {tabChangeValue}
            setTabChangeValue = {setTabChangeValue}
            ref={mainTabRef}
            majorValidations = {majorValidations}
              />
        </TabPanel>
        <TabPanel value={tabValue} index={1}>
        <BenifitPlanCoverage privileges={props.privileges} setNewCovState={setNewCovState} seterrorMessages={seterrorMessages} handleChanges={handleChanges} newCovState={newCovState} dropdowns={addDropdowns} networkidDropdown={networkidDropdown}
           deleteCovRow={deleteCovRow} setDeleteCovRow={setDeleteCovRow} formValues={formValues} setShowError={setShowError} coverageValues={coverageValues} setCoverageValues={setCoverageValues} handleDCDtChange={handleDCDtChange} mapIdDropdown={mapIdDropdown} handleCoverageChanges={handleCoverageChanges} edit={true} values={values} errors={{planTypeErr}}
           tabChangeValue = {tabChangeValue}
           setTabChangeValue = {setTabChangeValue}
           ref = {coverageRef}
           majorValidations = {majorValidations}
           />
        </TabPanel>
        <TabPanel value={tabValue} index={2}>
        {<BenifitPlanSAReq  privileges={props.privileges} newSaReqState={newSaReqState} seterrorMessages={seterrorMessages} setNewSaReqState= {setNewSaReqState} dropdowns={addDropdowns} networkidDropdown={networkidDropdown}
           deleteSARow={deleteSARow} setDeleteSARow={setDeleteSARow} formValues={formValues} mapIdDropdown={mapIdDropdown} setShowError={setShowError} handleDCDtChange={handleDCDtChange} edit={true} errors={{planTypeErr}}
           tabChangeValue = {tabChangeValue}
           setTabChangeValue = {setTabChangeValue}
           ref = {saRef}
           majorValidations = {majorValidations}
           /> }
        </TabPanel>
        <TabPanel value={tabValue} index={3}>
             <BenefitPlanLimits  privileges={props.privileges} benefitPlanLimit={benefitPlanLimit} setNewBenefitPlantLimit={setNewBenefitPlantLimit}
               dropdowns={addDropdowns} seterrorMessages={seterrorMessages} mapIdDropdown={mapIdDropdown}
               bpLimitsDeleteItems={bpLimitsDeleteItems} formValues={formValues}
               setbpLimitsDeleteItems={setbpLimitsDeleteItems}
               tabChangeValue = {tabChangeValue}
               setTabChangeValue = {setTabChangeValue}
               ref = {planLimitRef}
               majorValidations = {majorValidations}
               />
        </TabPanel>
        <TabPanel value={tabValue} index={4}>
             <BenefitPlanCostShare  privileges={props.privileges} benefitPlanCopay={benefitPlanCopay} setNewBenefitPlanCopay={setNewBenefitPlanCopay} benefitPlanCoInsurance={benefitPlanCoInsurance} setNewBenefitPlantCoInsurance={setNewBenefitPlantCoInsurance} dropdowns={addDropdowns}
            mapIdDropdown={mapIdDropdown} seterrorMessages={seterrorMessages} benefitPlanCopayLimit={benefitPlanCopayLimit} setNewBenefitPlantCopayLimit = {setNewBenefitPlantCopayLimit}
            formValues={formValues} setShowError={setShowError} newCoInsState = {newCoInsState} setNewCoInsLmt={setNewCoInsLmt}
            setbpCoInsDeleteItems={setbpCoInsDeleteItems}
            setcoPayDeleteItems={setcoPayDeleteItems}
            setcoPayLimitDeleteItems={setcoPayLimitDeleteItems}
            bpCoInsDeleteItems={bpCoInsDeleteItems}
            coPayDeleteItems={coPayDeleteItems}
            coPayLimitDeleteItems={coPayLimitDeleteItems}
            setDeleteCoInsLmt = {setDeleteCoInsLmt} deleteCoInsLmt={deleteCoInsLmt}
             isEditOp={true}
             bpDeductableState={bpDeductableState} setBpDeductableState={setBpDeductableState} deductibleDeleteRow={deductibleDeleteRow} setDeductibleDeleteRow={setDeductibleDeleteRow}
             tabChangeValue = {tabChangeValue}
             setTabChangeValue = {setTabChangeValue}
             ref = {costshareRef}
             majorValidations = {majorValidations}
            />
                    
      <BPCostShareCoInsurance
        privileges={props.privileges}
        coInsuranceData={benefitPlanCoInsurance}
        setNewBenefitPlantCoInsurance={setNewBenefitPlantCoInsurance}
        coInsuranceDropdowns={addDropdowns}
        mapDropdown={mapIdDropdown}
        seterrorMessages={seterrorMessages}
        isEditOp={true}
        setbpCoInsDeleteItems={setbpCoInsDeleteItems}
        bpCoInsDeleteItems={bpCoInsDeleteItems}
        formValues={formValues}
        tabChangeValue = {tabChangeValue}
        setTabChangeValue = {setTabChangeValue}
        ref = {coInsRef}
        majorValidations = {majorValidations}
      />

      
        <BenefitPlanCoInsLmt
          privileges={props.privileges}
          dropdowns={addDropdowns}
          coInsuranceData={benefitPlanCoInsurance}
          setDeleteCoInsLmt={setDeleteCoInsLmt}
          deleteCoInsLmt={deleteCoInsLmt}
          mapIdDropdown={mapIdDropdown}
          setShowError={setShowError}
          seterrorMessages={seterrorMessages}
          newCoInsState={newCoInsState}
          setNewCoInsLmt={setNewCoInsLmt}
          formValues={formValues}
          tabChangeValue = {tabChangeValue}
          setTabChangeValue = {setTabChangeValue}
          ref = {coInsLmtRef}
          majorValidations = {majorValidations}
        />
      

      <BenefitPlanDeductible
        privileges={props.privileges}
        dropdowns={addDropdowns}
        mapIdDropdown={mapIdDropdown}
        setShowError={setShowError}
        seterrorMessages={seterrorMessages}
        bpDeductableState={bpDeductableState}
        setBpDeductableState={setBpDeductableState}
        formValues={formValues}
        deductibleDeleteRow={deductibleDeleteRow}
        setDeductibleDeleteRow={setDeductibleDeleteRow}
        tabChangeValue = {tabChangeValue}
        setTabChangeValue = {setTabChangeValue}
        ref = {deductibleRef}
        majorValidations = {majorValidations}
      />
        </TabPanel>
       
      </div>
      </div>
      </div>
      <Footer print />
      </div>
    </div>
    </div>
    )
}

export default BenifitPlanAdd;