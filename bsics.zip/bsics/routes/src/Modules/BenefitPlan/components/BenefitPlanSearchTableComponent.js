import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import { benefitPlanDetailsAction } from '../actions';
import * as BenefitPlanConstants from './BenefitPlanConstants';

const headCells = [
  {
    id: 'benefitPlanID', numeric: false, disablePadding: true, label: 'Benefit Plan ID', enableHyperLink: true, width: 110
  },
  {
    id: 'typeCodeDesc', numeric: false, disablePadding: false, label: 'Benefit Plan Type', enableHyperLink: false, width: 130
  },
  {
    id: 'beginDate', numeric: false, disablePadding: false, label: 'Plan Begin Date', enableHyperLink: false, width: 120
  },
  {
    id: 'endDate', numeric: false, disablePadding: false, label: 'Plan End Date', enableHyperLink: false, width: 110
  },
  {
    id: 'benefitPlanDesc', numeric: false, disablePadding: false, label: 'Description', enableHyperLink: false, width: 240
  }
];

function benefitPlanSearchTableComponent(props) {
  const errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(false);

  const dispatch = useDispatch();
  const onSearchView = searchvalues => dispatch(benefitPlanDetailsAction(searchvalues));
  const benefitPlanDetails = useSelector(state => state.benefitPlan.benefitPlanDetails);
  const benefitPlanDetailsTime = useSelector(state => state.benefitPlan.benefitPlanDetailsTime);
  
  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);

  useEffect(() => {
    if(benefitPlanDetails != null && props.redirect ){
      props.setRedirect(false);
      props.setspinnerLoader(false);
      if (benefitPlanDetails.message === null || benefitPlanDetails.message === undefined) {
        props.history.push({
          pathname: '/BenefitPlanDetails',
        });
      } else {
        errorMessagesArray.push(DiagnosisCodeConstants.ERROR_OCCURED_DURING_TRANSACTION);
        props.tableErrorFunction(errorMessagesArray)
      }
    }
  },[benefitPlanDetailsTime]);
  
  const editRow = row => (event) => {
    onSearchView({ benefitPlanID: row.benefitPlanID, lobCode: row.lobCode });
    props.setspinnerLoader(true);
    props.setRedirect(true);
  };
  const tableComp = <TableComponent headCells={headCells}  tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn="benefitPlanID" />;
  return (
    showTable ? tableComp : null

  );
}
export default withRouter(benefitPlanSearchTableComponent);
