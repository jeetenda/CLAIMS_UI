import React, { useState, useEffect } from 'react';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import BenefitPlanAdd from './BenifitPlanAdd';
import BenefitPlanEdit from './BenifitPlanEdit';
import NavigationPrompt from "react-router-navigation-prompt";
import { Button } from "react-bootstrap";
import { Divider, Modal } from 'react-bootstrap';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';

function BenefitPlanDetails(props) {
    const [showSuccessMessage, setShowSuccessMessage] = useState(false);
    const type = useSelector(state => state.benefitPlan.type);
    const [prompt, setPrompt] = useState(false)
    
    const [cancelType, setCancelType] = useState(false);
    const handelPromptSet = (set) => {
        if (set)
            setPrompt(true);
    }

    return (
        <>
            <NavigationPrompt
                when={(crntLocation, nextLocation) => {handelPromptSet(nextLocation); return true}}
                // when={true}
            >
                {({ onConfirm, onCancel }) => (
                    <Dialog
                        open={prompt}
                        onClose={() => {setPrompt(false); }}
                        aria-labelledby="alert-dialog-title"
                        aria-describedby="alert-dialog-description" 
                        className="custom-alert-box"
                    >
                        <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                            {cancelType ? "Are you sure that you want to Cancel?" : 
                            (<>Unsaved changes will be lost. <br/>
                             Are you sure you want to continue?</>)}
                        </DialogContentText>
                        </DialogContent>
                        {cancelType ? (<DialogActions>
                            <Button onClick={onConfirm} color="primary" className="btn btn-success">
                                Ok
                            </Button>
                            <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" autoFocus>
                                Cancel
                            </Button>
                        </DialogActions>) : (<DialogActions>
                            <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" className="btn btn-transparent">
                            STAY ON THIS PAGE!
                            </Button>
                            <Button onClick={onConfirm} color="primary" className="btn btn-success" autoFocus>
                            CONTINUE <i className="fa fa-arrow-right ml-1"></i>
                            </Button>
                        </DialogActions>)}
                    </Dialog>
                )}
            </NavigationPrompt>
            {type === 'Add' ? <BenefitPlanAdd cancelType={cancelType} setCancelType={setCancelType} setShowSuccessMessage={setShowSuccessMessage} history={props.history} privileges={props.privileges}/> : type === 'Edit' ? <BenefitPlanEdit cancelType={cancelType} setCancelType={setCancelType} showSuccessMessage={showSuccessMessage} setShowSuccessMessage={setShowSuccessMessage} history={props.history} privileges={props.privileges}/> : null}
        </>
    )
}

export default withRouter(BenefitPlanDetails);
