import React, { useState, useEffect, useRef ,forwardRef,useImperativeHandle} from "react";
import { Button } from "react-bootstrap";
import TableComponent from "./../../../SharedModules/Table/Table";
import TextField from "@material-ui/core/TextField";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from "@material-ui/pickers";
import * as moment from "moment";
import DateFnsUtils from "@date-io/date-fns";
import dateFnsFormat from "date-fns/format";
import MenuItem from "@material-ui/core/MenuItem";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import InputAdornment from "@material-ui/core/InputAdornment";
import axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import { useConfirm } from "../../../SharedModules/MUIConfirm/index";
import isSpecialcharecter from "./validations";
import { Link } from "react-router-dom";
const headCells = [
  {
    id: "bpNetworkCodeDesc",
    numeric: false,
    disablePadding: true,
    label: "Network Status",
    enableHyperLink: true,
    fontSize: 12,
  },
  {
    id: "mapSetID",
    numeric: false,
    disablePadding: true,
    label: "MAP ID",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "beginDate",
    numeric: false,
    disablePadding: true,
    label: "Begin Date",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "endDate",
    numeric: false,
    disablePadding: true,
    label: "End Date",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "typeCode",
    numeric: false,
    disablePadding: true,
    label: "Copay Code",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "coPayAmt",
    numeric: false,
    disablePadding: true,
    label: "Amount",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "coPayPCT",
    numeric: false,
    disablePadding: true,
    label: "Percent",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "applyOopNum",
    numeric: false,
    disablePadding: true,
    label: "% Applied to OOP Max",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "exceptionCode",
    numeric: false,
    disablePadding: true,
    label: "Exc Code",
    enableHyperLink: false,
    fontSize: 12,
    isToolTip: true,
    toolTip: "clmExcnDesc",
  },
  {
    id: "seqNum",
    numeric: false,
    disablePadding: true,
    label: "Rank",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "serviceTyCd",
    numeric: false,
    disablePadding: true,
    label: "Serivce Type Code",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "providerTyCd",
    numeric: false,
    disablePadding: true,
    label: "Provider Type",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "minAge",
    numeric: false,
    disablePadding: true,
    label: "Min Age",
    enableHyperLink: false,
    fontSize: 12,
  },
];

const copayLimitHeadCells = [
  {
    id: "bpNetworkCodeDesc",
    numeric: false,
    disablePadding: true,
    label: "Network Status",
    enableHyperLink: true,
    fontSize: 12,
  },
  {
    id: "mapSetID",
    numeric: false,
    disablePadding: true,
    label: "Map ID",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "beginDate",
    numeric: false,
    disablePadding: true,
    label: "Begin Date",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "endDate",
    numeric: false,
    disablePadding: true,
    label: "End Date",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "typeCode",
    numeric: false,
    disablePadding: true,
    label: "Code",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "limits",
    numeric: false,
    disablePadding: true,
    label: "Limits I / I + 1 / F",
    enableHyperLink: false,
    fontSize: 12,
  },
  {
    id: "metExceptionCode",
    numeric: false,
    disablePadding: true,
    label: "Limit Met Exc Code",
    enableHyperLink: false,
    fontSize: 12,
    isToolTip: true,
    toolTip: "metExcnDesc",
  },
  {
    id: "overExceptionCode",
    numeric: false,
    disablePadding: true,
    label: "Limit Over Exc Code",
    enableHyperLink: false,
    fontSize: 12,
    isToolTip: true,
    toolTip: "ovrExcnDesc",
  },
  {
    id: "seqNum",
    numeric: false,
    disablePadding: true,
    label: "Rank",
    enableHyperLink: false,
    fontSize: 12,
  },
];

function BenefitPlanCostShare(props,ref) {
  const [tableData, setTableData] = useState([]);
  const [tableDataCPL, setTableDataCPL] = useState([]);
  const [selectDeleteCopayArray, setSelectDeleteCopayArray] = useState([]);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);


  const voidRef = useRef();
  const muiconfirm = useConfirm();

  useEffect(() => {
    setTableData(props.benefitPlanCopay ? props.benefitPlanCopay : []);
  }, [props.benefitPlanCopay]);

  useEffect(() => {
    setTableDataCPL(
      props.benefitPlanCopayLimit ? props.benefitPlanCopayLimit : []
    );
  }, [props.benefitPlanCopayLimit]);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [tabName, setTabName] = useState("");

  const [banifitPlan, setbanifitPlan] = useState(false);
  const [newCopay, setNewCopay] = useState({});
  const [success, setSuccess] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [copayLimit, setCopayLimt] = useState(false);
  const [newCopayLimit, setNewCopayLimit] = useState({});
  const [selectedEndDate, setSelectedEndDate] = React.useState("");
  const [selectedBeginDate, setSelectedBeginDate] = React.useState("");

  const [selectedCoPayEndDate, setSelectedCoPayEndDate] = React.useState("");
  const [selectedCoPayBeginDate, setSelectedCoPayBeginDate] = React.useState(
    ""
  );
  const [
    { copayDelete, copayLimitDelete, coInsDelete, coInsLimitDelete, didetible },
    setDeleteSuccess,
  ] = React.useState(false);
  const [
    {
      showNetworkStatusErr,
      showmapSetIDErr,
      showLimitTypeCodErr,
      invalidIndAmntErr,
      invalidIndAmntmaxErr,
      indAmntErr,
      invalidIndPlusAmntErr,
      invalidIndPlusAmntmaxErr,
      invalidIndFamAmntErr,
      invalidIndFamAmntmaxErr,
      //showIndividualLimitErr,
      ShowLimitMetExcErr,
      showCopayAmtErr,
      ShowLimitoverExcCodeErr,
      ShowRankErr,
      ShowRankErrSpe,
      ShowRankErrZero,
      showBeginDate,
      ShowEndDate,
      INVALID_LMT_MET_EXC_CODE,
      INVALID_LMT_MET_EXC_CODE_SPL,
      INVALID_LMT_OVR_EXC_CODE,
      INVALID_LMT_OVR_EXC_CODE_SPE,
      showNetworkOverlapErrCopayLmt,
      showBasicErr,
      showHeaderDateErrCoPayLimit,
      showHeaderEndDateErrLimit
    },
    setShowError,
  ] = React.useState(false);

  const [
    {
      showBgdtGTEnddtErr,
      showHeaderDateErr,
      showHeaderEndDateErr,
      showBeginDateError,
      showEndDateError,
      beginDtInvalidErr,
      endDtInvalidErr,
      showRankOverlapErr,
      showNetworkOverlapErr,
      showcopayNetworkStatusErr,
      showcopaymapSetIDErr,
      showCopayTypeCodeErr,
      showPercentageAppliedtoMaxErr,
      EXC_CODE_NOT_MATCH_LOB,
      showMinageErr,
      showMinageInvalid,
      showMinAgeNan,
      showRankErrCoPay,
      ShowRankErrSpeCoPay,
      ShowRankErrCoPayZero,
      showServiceTypeErr,
      showApplyOopNumErr,
      showPercentageAppliedtoEmptyErr,
      percentageErr,
      coPayAmtFloatErr
    },
    setShowCopayError,
  ] = React.useState(false);

  const [editCopay, setEditCopay] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    mapSetID: "-1",
    seqNum: "",
    benefitPlanStatusNetworkCode: "-1",
    typeCode: "-1",
    coPayAmt: "",
    coPayPCT: "",
    applyOopNum: "",
    exceptionCode: "",
    minAge: "",
    providerTyCd: "-1",
    serviceTyCd: "-1",
  });

  const [resetCopay, setresetCopay] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    mapSetID: "-1",
    seqNum: "",
    benefitPlanStatusNetworkCode: "-1",
    typeCode: "-1",
    coPayAmt: "",
    coPayPCT: "",
    applyOopNum: "",
    exceptionCode: "",
    minAge: "",
    providerTyCd: "-1",
    serviceTyCd: "-1",
  });

  const [editCopayLimit, setEditCopayLimit] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    benefitPlanStatusNetworkCode: "-1",
    mapSetID: "-1",
    typeCode: "-1",
    indAmt: "",
    indPlusAmt: "",
    famAmt: "",
    metExceptionCode: "",
    overExceptionCode: "",
    seqNum: "",
  });

  const [resetCopayLimit, setresetCopayLimit] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    benefitPlanStatusNetworkCode: "-1",
    mapSetID: "-1",
    typeCode: "-1",
    indAmt: "",
    indPlusAmt: "",
    famAmt: "",
    metExceptionCode: "",
    overExceptionCode: "",
    seqNum: "",
  });

  const handelDateRngeWithin = (
    rangeStartDate,
    rangeEndDate,
    withInStartDate,
    withInEndDate
  ) => {
    if (rangeStartDate && rangeEndDate && withInStartDate && withInEndDate) {
      const range = moment().range(
        new Date(rangeStartDate),
        new Date(rangeEndDate)
      );
      return (
        range.contains(new Date(withInStartDate)) &&
        range.contains(new Date(withInEndDate))
      );
    }
    return false;
  };
  const getTableDataCopayLimit = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
        if (each.indAmt && each.indPlusAmt && each.famAmt) {
          each.limits = each.indAmt + "/" + each.indPlusAmt + "/" + each.famAmt;
        } else if (each.indAmt && each.indPlusAmt) {
          each.limits = each.indAmt + "/" + each.indPlusAmt;
        } else if (each.indAmt && each.famAmt) {
          each.limits = each.indAmt + "/" + each.famAmt;
        }
      });
      return tData;
    } else {
      return [];
    }
  };

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
      });
      return tData;
    } else {
      return [];
    }
  };

  const editRow = (row) => (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, copayTab: false });
    setbanifitPlan(true);
    console.log(row);
    setEditCopay(row);
    setNewCopay(row);
    setresetCopay({
      beginDate: row.beginDate,
      endDate: row.endDate,
      mapSetID: row.mapSetID,
      seqNum: row.seqNum,
      benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
      typeCode: row.typeCode,
      coPayAmt: row.coPayAmt,
      coPayPCT: row.coPayPCT,
      applyOopNum: row.applyOopNum,
      exceptionCode: row.exceptionCode,
      minAge: row.minAge,
      providerTyCd: row.providerTyCd,
      serviceTyCd: row.serviceTyCd,
      index: row.index,
      row: row,
    });
    BPCSscrolltoView();
  };

  const editRowCopay = (row) => (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, copaylimitTab: false });
    setCopayLimt(true);
    setEditCopayLimit(row);
    setNewCopayLimit(row);
    setresetCopayLimit({
      beginDate: row.beginDate,
      endDate: row.endDate,
      benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
      mapSetID: row.mapSetID,
      typeCode: row.typeCode,
      indAmt: row.indAmt,
      indPlusAmt: row.indPlusAmt,
      famAmt: row.famAmt,
      metExceptionCode: row.metExceptionCode,
      overExceptionCode: row.overExceptionCode,
      seqNum: row.seqNum,
    });
    BPCSscrolltoViewedit();
  };

  const handelInputChange = (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, copayTab: true })
    if (event.target.name === "benefitPlanStatusNetworkCode") {
      setEditCopay({
        ...editCopay,
        [event.target.name]: event.target.value,
        bpNetworkCodeDesc: event.nativeEvent.target.textContent,
      });
    } else {
      setEditCopay({
        ...editCopay,
        [event.target.name]: event.target.value,
      });
    }
  };

  const handelDateChange = (type, name) => (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, copayTab: true })
    setEditCopay({ ...editCopay, [name]: date });
  };

  const handelLimitDateChange = (type, name) => (date) => {
    setEditCopayLimit({ ...editCopayLimit, [name]: date });
  };

  const handleBeginDateChange = (date) => {
    setSelectedBeginDate(date);
    setEditCopay({ ...editCopay, ["beginDate"]: formatDate(date) });
  };

  const handleEndDateChange = (date) => {
    setSelectedEndDate(date);
    setEditCopay({ ...editCopay, ["endDate"]: formatDate(date) });
  };

  const handleCoPayBeginDateChange = (date) => {
    setSelectedCoPayBeginDate(date);
    setEditCopayLimit({ ...editCopayLimit, ["beginDate"]: formatDate(date) });
  };

  const handleCoPayEndDateChange = (date) => {
    setSelectedCoPayEndDate(date);
    setEditCopayLimit({ ...editCopayLimit, ["endDate"]: formatDate(date) });
  };

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const handelDateChangeCopayLimit = (type, name) => (date) => {
    setEditCopayLimit({ ...editCopayLimit, [name]: date });
  };

  const handelInputChangeLimit = (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, copaylimitTab: true })
    if (event.target.name === "benefitPlanStatusNetworkCode") {
      setEditCopayLimit({
        ...editCopayLimit,
        [event.target.name]: event.target.value,
        bpNetworkCodeDesc: event.nativeEvent.target.textContent,
      });
    } else if (event.target.name === "typeCode") {
      setEditCopayLimit({
        ...editCopayLimit,
        [event.target.name]: event.target.value,
        typeCodeDesc: event.nativeEvent.target.textContent,
      });
    } else {
      setEditCopayLimit({
        ...editCopayLimit,
        [event.target.name]: event.target.value,
      });
    }
  };
   

  const validateExcCode = (c) => {
    return new Promise((resolve, reject) => {
      setspinnerLoader(true);
      axios
        .get(serviceEndPoint.BENEFIT_PLAN_EXC_CODE_VALIDATION + c+"/"+props.formValues.lobId)
        .then((response) => {
          if (response.data.data && response.data.data.excCodeDesc) {
            resolve(response.data.data.excCodeDesc);
          } else {
            resolve(false);
          }
        })
        .catch((error) => {
          resolve(false);
        })
        .then(() => {
          setspinnerLoader(false);
        });
    });
  };

  const handelDateNetworkArrayOverlap = (
    initalStartDate,
    initialEndDate,
    networkId,
    networkstatus,
    serviceTyCd,
    typeCode,
    providerTyCd,
    minAge,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (
            each.mapSetID == networkId &&
            each.benefitPlanStatusNetworkCode == networkstatus &&
            each.beginDate == initalStartDate &&
            each.serviceTyCd == serviceTyCd &&
            each.typeCode == typeCode &&
            each.providerTyCd == providerTyCd &&
            each.minAge == minAge
          ) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateNetworkArrayOverlapCopayCode = (
    initalStartDate,
    initialEndDate,
    networkId,
    networkstatus,
    typeCode,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (
            each.mapSetID == networkId &&
            each.benefitPlanStatusNetworkCode == networkstatus &&
            each.beginDate == initalStartDate &&
            each.typeCode == typeCode
          ) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateNetworkArrayOverlapCopayLimit = (
    initalStartDate,
    initialEndDate,
    networkId,
    networkstatus,
    typeCode,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (
            each.mapSetID == networkId &&
            each.benefitPlanStatusNetworkCode == networkstatus &&
            each.beginDate == initalStartDate &&
            each.typeCode == typeCode
          ) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRngeOverlap = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate
  ) => {
    const range1 = moment().range(
      new Date(initalStartDate),
      new Date(initialEndDate)
    );
    const range2 = moment().range(
      new Date(secondaryStartDate),
      new Date(secondaryEndDate)
    );
    return range1.overlaps(range2);
  };

  const handelClick = async () => {
    let errors = {};
    let reqFieldArr = [];
    let clmExcnDesc = "";
    const tableData = props.benefitPlanCopay;
    let overlapArray;
    if (editCopay.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetCopay.beginDate) ||
          e.endDate != formatDate(resetCopay.endDate)
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(editCopay.beginDate),
      formatDate(editCopay.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(editCopay.beginDate),
      formatDate(editCopay.endDate),
      editCopay.mapSetID,
      editCopay.benefitPlanStatusNetworkCode,
      editCopay.serviceTyCd,
      editCopay.typeCode,
      editCopay.providerTyCd,
      editCopay.minAge,
      overlapArray
    );
    const networkOverlapCopayCode = await handelDateNetworkArrayOverlapCopayCode(
      formatDate(editCopay.beginDate),
      formatDate(editCopay.endDate),
      editCopay.mapSetID,
      editCopay.benefitPlanStatusNetworkCode,
      editCopay.typeCode,
      overlapArray
    );
    console.log("negative", editCopay.minAge < 0);
    //var checkAge = /^[0-9.]{1,3}$/;
    var checkAge = /^[0-9.]$/;
    clmExcnDesc = await validateExcCode(editCopay.exceptionCode);
   

    setShowCopayError({ 
      showBeginDateError: editCopay.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: editCopay.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      showBgdtGTEnddtErr:
        new Date(editCopay.beginDate) <= new Date(editCopay.endDate)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })(),
      beginDtInvalidErr:
        formatDate(editCopay.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(editCopay.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
      showcopayNetworkStatusErr:
        editCopay.benefitPlanStatusNetworkCode &&
        editCopay.benefitPlanStatusNetworkCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_ID_Error);
              return true;
            })(),
      showcopaymapSetIDErr:
        editCopay.mapSetID && editCopay.mapSetID != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      showCopayTypeCodeErr:
        editCopay.typeCode && editCopay.typeCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.TYPE_CODE);
              return true;
            })(),
      showApplyOopNumErr: !(
        parseFloat(editCopay.applyOopNum) <= 100.0 &&
        parseInt(editCopay.applyOopNum) >= 0
      )
        ? (() => {
            reqFieldArr.length = 0;
            reqFieldArr.push(ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET);
            return true;
          })()
        : false,
      // showHeaderDateErr:
      //   !headerTange && editCopay.beginDate
      //     ? (() => {
      //         reqFieldArr.push(
      //           ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
      //         );
      //         return true;
      //       })()
      //     : false,
          showHeaderDateErr:
          !(new Date(editCopay.beginDate) >= new Date(props.formValues.beginDate) && new Date(editCopay.beginDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                );
                return true;
              })()
            : false,
          showHeaderEndDateErr:
          !(new Date(editCopay.endDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_End_Date_Err 
                );
                return true;
              })()
            : false,
          // End header date error
      showPercentageAppliedtoEmptyErr:
        editCopay.applyOopNum.toString().length == 0
          ? (() => {
             // reqFieldArr.length = 0;
              reqFieldArr.push(
                ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
              );
              return true;
            })()
          : false,
          coPayAmtFloatErr:
          editCopay.coPayAmt &&
          !(
            parseFloat(editCopay.coPayAmt) <= 100 &&
            parseInt(editCopay.coPayAmt) >= 0
          )
            ? (() => {
                reqFieldArr.push(ErrorConst.COPAY_AMT_ERROR);
                return true;
              })()
            : false,
      percentageErr:
        editCopay.coPayPCT &&
        (
          parseFloat(editCopay.coPayPCT) >= 100 ||
          parseInt(editCopay.coPayPCT) == 0
        )
          ? (() => {
              reqFieldArr.push(ErrorConst.PERCENTAGE_ERROR);
              return true;
            })()
          : false,
      ShowRankErrSpeCoPay: !isNaN(parseInt(editCopay.seqNum))
        ? false
        : (() => {
            if (editCopay.seqNum.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
      ShowRankErrCoPayZero:
        editCopay.seqNum < 1 && editCopay.seqNum.length
          ? (() => {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
              return true;
            })()
          : false,
      showRankErrCoPay:
        editCopay.seqNum.length < 1
          ? (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })()
          : false,
      // showMinageErr: !isNaN(parseInt(editCopay.minAge))
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.MIN_AGE);
      //       return true;
      //     })(),

      showMinageErr:
        editCopay.minAge == ""
          ? (() => {
              reqFieldArr.push(ErrorConst.MIN_AGE);
              return true;
            })()
          : false,
      showMinAgeNan: isNaN(editCopay.minAge)
        ? (() => {
            reqFieldArr.push(ErrorConst.INVALID_AGE_NAN);
            return true;
          })()
        : false,
      //showMinageInvalid: checkAge.test(editCopay.minAge) && editCopay.minAge != ''

      showMinageInvalid:
        editCopay.minAge.indexOf(".") != -1 || editCopay.minAge < 0
          ? (() => {
              reqFieldArr.push(ErrorConst.INVALID_AGE);
              return true;
            })()
          : false,

      showNetworkOverlapErr:
        editCopay.beginDate &&
        editCopay.endDate &&
        editCopay.mapSetID &&
        editCopay.benefitPlanStatusNetworkCode &&
        editCopay.serviceTyCd &&
        editCopay.typeCode &&
        editCopay.providerTyCd &&
        editCopay.minAge &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.COPAY_OVERLAP_ERROR);
              return true;
            })()
          : editCopay.beginDate &&
            editCopay.endDate &&
            editCopay.mapSetID &&
            editCopay.benefitPlanStatusNetworkCode &&
            editCopay.typeCode &&
            networkOverlapCopayCode
          ? (() => {
              reqFieldArr.push(ErrorConst.COPAY_TYPE_CODE_OVERLAP_ERROR);
              return true;
            })()
          : false,
      showServiceTypeErr:
        editCopay.serviceTyCd && editCopay.serviceTyCd != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.SERVICE_TYPE_CODE);
              return true;
            })(),
      // showCopayAmtErr: !isNaN(parseInt(editCopay.coPayAmt)) ? false : (() => { reqFieldArr.push(ErrorConst.Benefit_Plan_Amount_Error); return true })()
   
      EXC_CODE_NOT_MATCH_LOB:  !isSpecialcharecter(
        editCopay.exceptionCode
      )
        ? false
        : (() => {
          reqFieldArr.push(ErrorConst.EXC_CODE_NOT_MATCH_LOB);
          reqFieldArr.push(ErrorConst.INVALID_SPL_EXC_CODE);  
            return true;
          })(),
   });
    if (reqFieldArr.length) {
      //setShowCopayError(errors);
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    // if (editCopay.exceptionCode && editCopay.exceptionCode.trim()) {
    //   if (editCopay.exceptionCode != "") {
    //     clmExcnDesc = await validateExcCode(editCopay.exceptionCode);
    //     if (!clmExcnDesc) {
    //       errors["EXC_CODE_NOT_MATCH_LOB"] = true;
    //       reqFieldArr.push(ErrorConst.EXC_CODE_NOT_MATCH_LOB);
    //       reqFieldArr.push(ErrorConst.INVALID_SPL_EXC_CODE);  
    //     }
    //    
    //   }
      if (reqFieldArr.length) {
        setShowCopayError(errors);
        props.seterrorMessages(reqFieldArr);
        return false;
      }
    //}
    let data = {
      auditUserID: editCopay.auditUserID ? editCopay.auditUserID : "52123327",
      addedAuditUserID: editCopay.addedAuditUserID
        ? editCopay.addedAuditUserID
        : "CR 8059 test",
      versionNo: editCopay.versionNo ? editCopay.versionNo : 0,
      dbRecord: editCopay.dbRecord ? editCopay.dbRecord : false,
      sortColumn: editCopay.sortColumn ? editCopay.sortColumn : null,
      auditKeyList: editCopay.auditKeyList ? editCopay.auditKeyList : [],
      auditKeyListFiltered: editCopay.auditKeyListFiltered
        ? editCopay.auditKeyListFiltered
        : false,
      benefitPlanCoPayID: editCopay.benefitPlanCoPayID
        ? editCopay.benefitPlanCoPayID
        : null,
      benefitPlanStatusNetworkCode: editCopay.benefitPlanStatusNetworkCode
        ? editCopay.benefitPlanStatusNetworkCode
        : "",
      beginDate: formatDate(editCopay.beginDate)
        ? formatDate(editCopay.beginDate)
        : "",
      typeCode: editCopay.typeCode ? editCopay.typeCode : "",
      mapSetID: editCopay.mapSetID ? editCopay.mapSetID : "",
      applyOopNum: editCopay.applyOopNum ? editCopay.applyOopNum : "",
      seqNum: editCopay.seqNum ? editCopay.seqNum : "",
      coPayAmt: editCopay.coPayAmt ? editCopay.coPayAmt : "",
      coPayPCT: editCopay.coPayPCT ? editCopay.coPayPCT : "",
      exceptionCode: editCopay.exceptionCode ? editCopay.exceptionCode : null,
      serviceTyCd: editCopay.serviceTyCd ? editCopay.serviceTyCd : null,
      endDate: formatDate(editCopay.endDate)
        ? formatDate(editCopay.endDate)
        : "12/31/9999",
      providerTyCd: editCopay.providerTyCd ? editCopay.providerTyCd : null,
      minAge: editCopay.minAge ? editCopay.minAge : "",
      benefitPlan: null,
      clmExcnDesc: clmExcnDesc ? clmExcnDesc : "",
      bpNetworkCodeDesc: editCopay.bpNetworkCodeDesc
        ? editCopay.bpNetworkCodeDesc
        : "",
      typeCodeDesc: null,
      serviceTypeCode: null,
      providerTypeCode: null,
    };
    editCopay.index > -1
      ? (tableData[editCopay.index] = data)
      : tableData.push(data);
    setSuccess(true);
    props.seterrorMessages([]);
    props.setNewBenefitPlanCopay(tableData);
    setbanifitPlan(false);
    setEditCopay({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      seqNum: "",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      coPayAmt: "",
      coPayPCT: "",
      applyOopNum: "",
      exceptionCode: "",
      minAge: "",
      providerTyCd: "-1",
      serviceTyCd: "-1",
    });
    setresetCopay({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      seqNum: "",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      coPayAmt: "",
      coPayPCT: "",
      applyOopNum: "",
      exceptionCode: "",
      minAge: "",
      providerTyCd: "-1",
      serviceTyCd: "-1",
    });
    props.setTabChangeValue({ ...props.tabChangeValue, copayTab: false });

  };

  const minorDelete = () => {
    //console.log("in minor delete");
    muiconfirm({
      title: "",
      description: "Are you sure that you want to delete.",
      dialogProps: { fullWidth: false },
    }).then(() => {
      let t = tableData;
      if (tableData.length == 1) {
        props.seterrorMessages(["Atleast One Record Should Exist For Co-Pay"]);
        setbanifitPlan(false);
        setSuccess(false);
      } else {
        props.setcoPayDeleteItems
          ? props.setcoPayDeleteItems([
              ...props.coPayDeleteItems,
              t[editCopay.index],
            ])
          : null;
        t.splice(editCopay.index, 1);
        props.setNewBenefitPlanCopay(t);
        setSuccess(false);
        setDeleteSuccess({
          copayDelete: true,
          copayLimitDelete: false,
          coInsDelete: false,
          coInsLimitDelete: false,
          didetible: false,
        });
        props.seterrorMessages([]);
        setbanifitPlan(false);
      }
    });
  };

  const handelResetClick = () => {
    props.seterrorMessages([]);
    setEditCopay(resetCopay);

    setShowCopayError({});
    props.setTabChangeValue({ ...props.tabChangeValue, copayTab: false });

  };

  const addCopay = () => {
    setbanifitPlan(true);
    handelResetClick();
  };

  const setRoundNum = (value) => {
    let roundNum = Number(Math.round(value + "e2") + "e-2").toFixed(2);
    return roundNum;
  };
  const handelClickCopayLimit = async () => {
    let errors = {};
    let reqFieldArr = [];
    let metExcnDesc = "";
    let ovrExcnDesc = "";
    const tableData = props.benefitPlanCopayLimit;

    let overlapArray;
    if (editCopayLimit.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetCopayLimit.beginDate) ||
          e.endDate != formatDate(resetCopayLimit.endDate) ||
          e.seqNum != resetCopayLimit.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const networkOverlapCopayLimit = await handelDateNetworkArrayOverlapCopayLimit(
      formatDate(editCopayLimit.beginDate),
      formatDate(editCopayLimit.endDate),
      editCopayLimit.mapSetID,
      editCopayLimit.benefitPlanStatusNetworkCode,
      editCopayLimit.typeCode,
      overlapArray
    );
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(editCopayLimit.beginDate),
      formatDate(editCopayLimit.endDate)
    );
    metExcnDesc = await validateExcCode(editCopayLimit.metExceptionCode);
    ovrExcnDesc = await validateExcCode(editCopayLimit.overExceptionCode);
    setShowError({
      showBasicErr:
        props.benefitPlanCopay.length != 0
          ? false
          : (() => {
              reqFieldArr.push(["Atleast One Record Should Exist For Co-Pay"]);
              return true;
            })(),
      showBeginDateError: editCopayLimit.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: editCopayLimit.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),

      beginDtInvalidErr:
        formatDate(editCopayLimit.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(editCopayLimit.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
          //showHeaderDateErrCoPayLimit:
          // !headerTange && editCopayLimit.beginDate
          //   ? (() => {
          //       reqFieldArr.push(
          //         ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
          //       );
          //       return true;
          //     })()
          //   : false,
            showHeaderDateErrCoPayLimit:
            !(new Date(editCopayLimit.beginDate) >= new Date(props.formValues.beginDate) && new Date(editCopayLimit.beginDate) <= new Date(props.formValues.endDate))
              ? (() => {
                  reqFieldArr.push(
                    ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                  );
                  return true;
                })()
              : false,
            showHeaderEndDateErrLimit:
            !(new Date(editCopayLimit.endDate) <= new Date(props.formValues.endDate))
              ? (() => {
                  reqFieldArr.push(
                    ErrorConst.Fall_In_Header_End_Date_Err 
                  );
                  return true;
                })()
              : false,
            // End header date error

      showNetworkStatusErr:
        editCopayLimit.benefitPlanStatusNetworkCode &&
        editCopayLimit.benefitPlanStatusNetworkCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      showmapSetIDErr:
        editCopayLimit.mapSetID && editCopayLimit.mapSetID != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      showLimitTypeCodErr:
        editCopayLimit.typeCode && editCopayLimit.typeCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.TYPE_CODE);
              return true;
            })(),
      // showIndividualLimitErr: !isNaN(editCopayLimit.indAmt)
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
      //       return true;
      //     })(),
      // ShowLimitMetExcErr: !isNaN(parseInt(editCopayLimit.metExceptionCode)) ? false : (() => { reqFieldArr.push(ErrorConst.ShowLimitMetExcErr); return true })(),
      // ShowLimitoverExcCodeErr: !isNaN(parseInt(editCopayLimit.overExceptionCode)) ? false : (() => { reqFieldArr.push(ErrorConst.LIMIT_MET_OVER_EXC_CODE); return true })(),
      ShowRankErrSpe: !isNaN(parseInt(editCopayLimit.seqNum))
        ? false
        : (() => {
            if (editCopayLimit.seqNum.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
      ShowRankErr:
        editCopayLimit.seqNum.length < 1
          ? (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })()
          : false,
      ShowRankErrZero:
        editCopayLimit.seqNum < 1 && editCopayLimit.seqNum.length
          ? (() => {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
              return true;
            })()
          : false,
      indAmntErr: editCopayLimit.indAmt
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
            return true;
          })(),
      invalidIndAmntErr: !editCopayLimit.indAmt
        ? false
        : !isNaN(parseInt(editCopayLimit.indAmt))
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
            return true;
          })(),
      invalidIndAmntmaxErr: !editCopayLimit.indAmt
        ? false
        : !(parseInt(editCopayLimit.indAmt) > 99999999999)
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.IND_LIMIT_MAX);
            return true;
          })(),
      //Ind plus
      invalidIndPlusAmntErr: !editCopayLimit.indPlusAmt
        ? false
        : !isNaN(parseInt(editCopayLimit.indPlusAmt))
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
            return true;
          })(),
      invalidIndPlusAmntmaxErr: !editCopayLimit.indPlusAmt
        ? false
        : !(parseInt(editCopayLimit.indPlusAmt) > 99999999999)
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.IND_PLUS_LIMIT_MAX);
            return true;
          })(),
      //Fam limit

      invalidIndFamAmntErr: !editCopayLimit.famAmt
        ? false
        : !isNaN(parseInt(editCopayLimit.famAmt))
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
            return true;
          })(),
      invalidIndFamAmntmaxErr: !editCopayLimit.famAmt
        ? false
        : !(parseInt(editCopayLimit.famAmt) > 99999999999)
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.IND_FAM_LIMIT_MAX);
            return true;
          })(),

      showNetworkOverlapErrCopayLmt:
        editCopayLimit.beginDate &&
        editCopayLimit.endDate &&
        editCopayLimit.mapSetID &&
        editCopayLimit.benefitPlanStatusNetworkCode &&
        editCopayLimit.typeCode &&
        networkOverlapCopayLimit
          ? (() => {
              reqFieldArr.push(ErrorConst.PLAN_LIMIT_NETWORK_MAP_OVERLAP);
              return true;
            })()
          : false,
      INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(
        editCopayLimit.metExceptionCode
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE);
            return true;
          })(),
      INVALID_LMT_MET_EXC_CODE: editCopayLimit.metExceptionCode
        ? (() => {
            if (!isSpecialcharecter(editCopayLimit.metExceptionCode)) {
              if (!metExcnDesc) {
                reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                return true;
              } else {
                return false;
              }
            }
          })()
        : false,
      INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(
        editCopayLimit.overExceptionCode
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE);
            return true;
          })(),
      INVALID_LMT_OVR_EXC_CODE: editCopayLimit.overExceptionCode
        ? (() => {
            if (!isSpecialcharecter(editCopayLimit.overExceptionCode)) {
              if (!ovrExcnDesc) {
                reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                return true;
              } else {
                return false;
              }
            }
          })()
        : false,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }
    // if (editCopayLimit.metExceptionCode) {
    //   if(isNaN(parseInt(editCopayLimit.metExceptionCode))){
    //     errors["INVALID_LMT_MET_EXC_CODE_SPL"] = true;
    //     reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE);
    //   }else{
    //   let metExcnDesc = await validateExcCode(editCopayLimit.metExceptionCode);
    //   let ovrExcnDesc = await validateExcCode(
    //     editCopayLimit.overExceptionCode
    //   );
    //   if (!metExcnDesc) {
    //     errors["INVALID_LMT_MET_EXC_CODE"] = true;
    //     reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
    //   }
    // }}
    // if (editCopayLimit.overExceptionCode) {
    //   if(isNaN(parseInt(editCopayLimit.overExceptionCode))){
    //     errors["INVALID_LMT_OVR_EXC_CODE_SPE"] = true;
    //     reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE);
    //   } else {
    //     let ovrExcnDesc = await validateExcCode(
    //       editCopayLimit.overExceptionCode
    //     );
    //     if (!ovrExcnDesc) {
    //       errors["INVALID_LMT_OVR_EXC_CODE"] = true;
    //       reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
    //     }
    //   }
    // }

    if (reqFieldArr.length) {
      setShowError(errors);
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    let data = {
      auditUserID: editCopayLimit.auditUserID
        ? editCopayLimit.auditUserID
        : "52123327",
      addedAuditUserID: editCopayLimit.addedAuditUserID
        ? editCopayLimit.addedAuditUserID
        : "CR 8059 test",
      versionNo: editCopayLimit.versionNo ? editCopayLimit.versionNo : 0,
      dbRecord: editCopayLimit.dbRecord ? editCopayLimit.dbRecord : false,
      sortColumn: editCopayLimit.sortColumn ? editCopayLimit.sortColumn : null,
      auditKeyList: editCopayLimit.auditKeyList
        ? editCopayLimit.auditKeyList
        : [],
      auditKeyListFiltered: editCopayLimit.auditKeyListFiltered
        ? editCopayLimit.auditKeyListFiltered
        : false,
      benefitPlanCopayLMTSK: editCopayLimit.benefitPlanCopayLMTSK
        ? editCopayLimit.benefitPlanCopayLMTSK
        : null,
      benefitPlanStatusNetworkCode: editCopayLimit.benefitPlanStatusNetworkCode
        ? editCopayLimit.benefitPlanStatusNetworkCode
        : "",
      beginDate: formatDate(editCopayLimit.beginDate)
        ? formatDate(editCopayLimit.beginDate)
        : "",
      typeCode: editCopayLimit.typeCode ? editCopayLimit.typeCode : "",
      mapSetID: editCopayLimit.mapSetID ? editCopayLimit.mapSetID : "",
      indAmt: editCopayLimit.indAmt ? setRoundNum(editCopayLimit.indAmt) : "",
      seqNum: editCopayLimit.seqNum ? editCopayLimit.seqNum : "",
      indPlusAmt: editCopayLimit.indPlusAmt
        ? setRoundNum(editCopayLimit.indPlusAmt)
        : "",
      famAmt: editCopayLimit.famAmt ? setRoundNum(editCopayLimit.famAmt) : "",
      metExceptionCode: editCopayLimit.metExceptionCode
        ? editCopayLimit.metExceptionCode
        : null,
      overExceptionCode: editCopayLimit.overExceptionCode
        ? editCopayLimit.overExceptionCode
        : null,
      metExcnDesc: metExcnDesc ? metExcnDesc : "",
      ovrExcnDesc: ovrExcnDesc ? ovrExcnDesc : "",
      bpNetworkCodeDesc: editCopayLimit.bpNetworkCodeDesc
        ? editCopayLimit.bpNetworkCodeDesc
        : "",

      endDate: formatDate(editCopayLimit.endDate)
        ? formatDate(editCopayLimit.endDate)
        : "12/31/9999",
    };
    editCopayLimit.index > -1
      ? (tableData[editCopayLimit.index] = data)
      : tableData.push(data);
    setSuccess(true);
    props.seterrorMessages([]);
    props.setNewBenefitPlantCopayLimit(tableData);
    setCopayLimt(false);
    props.setTabChangeValue({ ...props.tabChangeValue, copaylimitTab: false });

  };

  const minorDeleteCPL = () => {
    //console.log("in minor delete CPL");
    muiconfirm({
      title: "",
      description: "Are you sure that you want to delete.",
      dialogProps: { fullWidth: false },
    }).then(() => {
      let t = tableDataCPL;
      props.setcoPayLimitDeleteItems
        ? props.setcoPayLimitDeleteItems([
            ...props.coPayLimitDeleteItems,
            t[editCopayLimit.index],
          ])
        : null;
      t.splice(editCopayLimit.index, 1);
      props.setNewBenefitPlantCopayLimit(t);
      setSuccess(false);
      setDeleteSuccess({
        copayDelete: false,
        copayLimitDelete: true,
        coInsDelete: false,
        coInsLimitDelete: false,
        didetible: false,
      });
      props.seterrorMessages([]);
      setCopayLimt(false);
    });
  };

  const multiDeleteCopay = () => {
    setDialogOpen(false); setDialogType('');
    props.seterrorMessages([]);
    setSuccess(false);
    if (selectDeleteCopayArray.length > 0) {
        let CI = props.benefitPlanCopay;
        selectDeleteCopayArray.map((value, index) => {
          let curIndex = CI.findIndex(i => moment(i.beginDate).isSame(value.beginDate));
          CI.splice(curIndex,1);
        });
        props.setNewBenefitPlanCopay(CI);
        props.setcoPayDeleteItems(selectDeleteCopayArray);
        setSelectDeleteCopayArray([]);
        setDeleteSuccess({
          copayDelete: true,
          copayLimitDelete: false,
          coInsDelete: false,
          coInsLimitDelete: false,
          didetible: false,
        });
    }
  }

  const multiDelete = () => {
    setDialogOpen(false); setDialogType('');
    props.seterrorMessages([]);
    setSuccess(false);
    if (selectDeleteArray.length > 0) {
        let CI = props.benefitPlanCopayLimit;
        selectDeleteArray.map((value, index) => {
          let curIndex = CI.findIndex(i => moment(i.beginDate).isSame(value.beginDate));
          CI.splice(curIndex,1);
        });
        props.setNewBenefitPlantCopayLimit(CI);
        props.setcoPayLimitDeleteItems(selectDeleteCopayArray);
        setSelectDeleteArray([]);
        setDeleteSuccess({
          copayDelete: false,
          copayLimitDelete: true,
          coInsDelete: false,
          coInsLimitDelete: false,
          didetible: false,
        });
    }
  }

  useImperativeHandle(ref, () => {
    return { validateFn };
  });

   const validateFn = () => {
    if (props.tabChangeValue.copayTab) {
      handelSaveValidationsCopay();
    } if (props.tabChangeValue.copaylimitTab){
      handelSaveValidationscopayLimit();
    }
    }

    const handelSaveValidationsCopay = async() => {
      let errors = {},
      reqFieldArr = [],
      clmExcnDesc = "";
    const tableData = props.benefitPlanCopay;
    let overlapArray;
    if (editCopay.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetCopay.beginDate) ||
          e.endDate != formatDate(resetCopay.endDate)
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(editCopay.beginDate),
      formatDate(editCopay.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(editCopay.beginDate),
      formatDate(editCopay.endDate),
      editCopay.mapSetID,
      editCopay.benefitPlanStatusNetworkCode,
      editCopay.serviceTyCd,
      editCopay.typeCode,
      editCopay.providerTyCd,
      editCopay.minAge,
      overlapArray
    );
    const networkOverlapCopayCode = await handelDateNetworkArrayOverlapCopayCode(
      formatDate(editCopay.beginDate),
      formatDate(editCopay.endDate),
      editCopay.mapSetID,
      editCopay.benefitPlanStatusNetworkCode,
      editCopay.typeCode,
      overlapArray
    );
    console.log("negative", editCopay.minAge < 0);
    //var checkAge = /^[0-9.]{1,3}$/;
    var checkAge = /^[0-9.]$/;
    setShowCopayError({
      showBeginDateError: editCopay.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: editCopay.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      showBgdtGTEnddtErr:
        new Date(editCopay.beginDate) <= new Date(editCopay.endDate)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })(),
      beginDtInvalidErr:
        formatDate(editCopay.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(editCopay.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
      showcopayNetworkStatusErr:
        editCopay.benefitPlanStatusNetworkCode &&
        editCopay.benefitPlanStatusNetworkCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_ID_Error);
              return true;
            })(),
      showcopaymapSetIDErr:
        editCopay.mapSetID && editCopay.mapSetID != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      showCopayTypeCodeErr:
        editCopay.typeCode && editCopay.typeCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.TYPE_CODE);
              return true;
            })(),
      showApplyOopNumErr: !(
        parseFloat(editCopay.applyOopNum) <= 100.0 &&
        parseInt(editCopay.applyOopNum) >= 0
      )
        ? (() => {
            reqFieldArr.length = 0;
            reqFieldArr.push(ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET);
            return true;
          })()
        : false,
      // showHeaderDateErr:
      //   !headerTange && editCopay.beginDate
      //     ? (() => {
      //         reqFieldArr.push(
      //           ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
      //         );
      //         return true;
      //       })()
      //     : false,
      showHeaderDateErr:
          !(new Date(editCopay.beginDate) >= new Date(props.formValues.beginDate) && new Date(editCopay.beginDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                );
                return true;
              })()
            : false,
          showHeaderEndDateErr:
          !(new Date(newProviderDate.endDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_End_Date_Err 
                );
                return true;
              })()
            : false,
          // End header date error
      showPercentageAppliedtoEmptyErr:
        editCopay.applyOopNum.toString().length == 0
          ? (() => {
              reqFieldArr.length = 0;
              reqFieldArr.push(
                ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
              );
              return true;
            })()
          : false,
          coPayAmtFloatErr:
          editCopay.coPayAmt &&
          !(
            parseFloat(editCopay.coPayAmt) <= 100 &&
            parseInt(editCopay.coPayAmt) >= 0
          )
            ? (() => {
                reqFieldArr.push(ErrorConst.COPAY_AMT_ERROR);
                return true;
              })()
            : false,
      percentageErr:
        editCopay.coPayPCT &&
        (
          parseFloat(editCopay.coPayPCT) >= 100 ||
          parseInt(editCopay.coPayPCT) == 0
        )
          ? (() => {
              reqFieldArr.push(ErrorConst.PERCENTAGE_ERROR);
              return true;
            })()
          : false,
      ShowRankErrSpeCoPay: !isNaN(parseInt(editCopay.seqNum))
        ? false
        : (() => {
            if (editCopay.seqNum.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
      ShowRankErrCoPayZero:
        editCopay.seqNum < 1 && editCopay.seqNum.length
          ? (() => {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
              return true;
            })()
          : false,
      showRankErrCoPay:
        editCopay.seqNum.length < 1
          ? (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })()
          : false,
      // showMinageErr: !isNaN(parseInt(editCopay.minAge))
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.MIN_AGE);
      //       return true;
      //     })(),

      showMinageErr:
        editCopay.minAge == ""
          ? (() => {
              reqFieldArr.push(ErrorConst.MIN_AGE);
              return true;
            })()
          : false,
      showMinAgeNan: isNaN(editCopay.minAge)
        ? (() => {
            reqFieldArr.push(ErrorConst.INVALID_AGE_NAN);
            return true;
          })()
        : false,
      //showMinageInvalid: checkAge.test(editCopay.minAge) && editCopay.minAge != ''

      showMinageInvalid:
        editCopay.minAge.indexOf(".") != -1 || editCopay.minAge < 0
          ? (() => {
              reqFieldArr.push(ErrorConst.INVALID_AGE);
              return true;
            })()
          : false,

      showNetworkOverlapErr:
        editCopay.beginDate &&
        editCopay.endDate &&
        editCopay.mapSetID &&
        editCopay.benefitPlanStatusNetworkCode &&
        editCopay.serviceTyCd &&
        editCopay.typeCode &&
        editCopay.providerTyCd &&
        editCopay.minAge &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.COPAY_OVERLAP_ERROR);
              return true;
            })()
          : editCopay.beginDate &&
            editCopay.endDate &&
            editCopay.mapSetID &&
            editCopay.benefitPlanStatusNetworkCode &&
            editCopay.typeCode &&
            networkOverlapCopayCode
          ? (() => {
              reqFieldArr.push(ErrorConst.COPAY_TYPE_CODE_OVERLAP_ERROR);
              return true;
            })()
          : false,
      showServiceTypeErr:
        editCopay.serviceTyCd && editCopay.serviceTyCd != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.SERVICE_TYPE_CODE);
              return true;
            })(),
      // showCopayAmtErr: !isNaN(parseInt(editCopay.coPayAmt)) ? false : (() => { reqFieldArr.push(ErrorConst.Benefit_Plan_Amount_Error); return true })()
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    if (editCopay.exceptionCode && editCopay.exceptionCode.trim()) {
      if (editCopay.exceptionCode != "") {
        clmExcnDesc = await validateExcCode(editCopay.exceptionCode);
        if (!clmExcnDesc) {
          errors["EXC_CODE_NOT_MATCH_LOB"] = true;
          reqFieldArr.push(ErrorConst.EXC_CODE_NOT_MATCH_LOB);
        }
      }
      if (reqFieldArr.length) {
        setShowCopayError(errors);

        props.seterrorMessages(reqFieldArr);
        return false;
      }
    }
    
    }
  
    const handelSaveValidationscopayLimit = async() => {
      let errors = {};
      let reqFieldArr = [];
      let metExcnDesc = "";
      let ovrExcnDesc = "";
      const tableData = props.benefitPlanCopayLimit;
  
      let overlapArray;
      if (editCopayLimit.index > -1) {
        overlapArray = tableData.filter(
          (e) =>
            e.beginDate != formatDate(resetCopayLimit.beginDate) ||
            e.endDate != formatDate(resetCopayLimit.endDate) ||
            e.seqNum != resetCopayLimit.seqNum
        );
      } else {
        overlapArray = tableData;
      }
      const networkOverlapCopayLimit = await handelDateNetworkArrayOverlapCopayLimit(
        formatDate(editCopayLimit.beginDate),
        formatDate(editCopayLimit.endDate),
        editCopayLimit.mapSetID,
        editCopayLimit.benefitPlanStatusNetworkCode,
        editCopayLimit.typeCode,
        overlapArray
      );
      metExcnDesc = await validateExcCode(editCopayLimit.metExceptionCode);
      ovrExcnDesc = await validateExcCode(editCopayLimit.overExceptionCode);
      setShowError({
        showBasicErr:
          props.benefitPlanCopay.length != 0
            ? false
            : (() => {
                reqFieldArr.push(["Atleast One Record Should Exist For Co-Pay"]);
                return true;
              })(),
        showBeginDateError: editCopayLimit.beginDate
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Begin_Date_Error);
              return true;
            })(),
        showEndDateError: editCopayLimit.endDate
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.End_Date_Error);
              return true;
            })(),
  
        beginDtInvalidErr:
          formatDate(editCopayLimit.beginDate).toString() == "Invalid Date"
            ? (() => {
                reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
                return true;
              })()
            : false,
        endDtInvalidErr:
          formatDate(editCopayLimit.endDate).toString() == "Invalid Date"
            ? (() => {
                reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
                return true;
              })()
            : false,
        showNetworkStatusErr:
          editCopayLimit.benefitPlanStatusNetworkCode &&
          editCopayLimit.benefitPlanStatusNetworkCode != "-1"
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Network_Status_Error);
                return true;
              })(),
        showmapSetIDErr:
          editCopayLimit.mapSetID && editCopayLimit.mapSetID != "-1"
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Map_Id_Error);
                return true;
              })(),
        showLimitTypeCodErr:
          editCopayLimit.typeCode && editCopayLimit.typeCode != "-1"
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.TYPE_CODE);
                return true;
              })(),
        ShowRankErrSpe: !isNaN(parseInt(editCopayLimit.seqNum))
          ? false
          : (() => {
              if (editCopayLimit.seqNum.length !== 0) {
                reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
                return true;
              } else return false;
            })(),
        ShowRankErr:
          editCopayLimit.seqNum.length < 1
            ? (() => {
                reqFieldArr.push(ErrorConst.Rank_Error);
                return true;
              })()
            : false,
        ShowRankErrZero:
          editCopayLimit.seqNum < 1 && editCopayLimit.seqNum.length
            ? (() => {
                reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
                return true;
              })()
            : false,
        indAmntErr: editCopayLimit.indAmt
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
              return true;
            })(),
        invalidIndAmntErr: !editCopayLimit.indAmt
          ? false
          : !isNaN(parseInt(editCopayLimit.indAmt))
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
              return true;
            })(),
        invalidIndAmntmaxErr: !editCopayLimit.indAmt
          ? false
          : !(parseInt(editCopayLimit.indAmt) > 99999999999)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.IND_LIMIT_MAX);
              return true;
            })(),
        //Ind plus
        invalidIndPlusAmntErr: !editCopayLimit.indPlusAmt
          ? false
          : !isNaN(parseInt(editCopayLimit.indPlusAmt))
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
              return true;
            })(),
        invalidIndPlusAmntmaxErr: !editCopayLimit.indPlusAmt
          ? false
          : !(parseInt(editCopayLimit.indPlusAmt) > 99999999999)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.IND_PLUS_LIMIT_MAX);
              return true;
            })(),
        //Fam limit
  
        invalidIndFamAmntErr: !editCopayLimit.famAmt
          ? false
          : !isNaN(parseInt(editCopayLimit.famAmt))
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
              return true;
            })(),
        invalidIndFamAmntmaxErr: !editCopayLimit.famAmt
          ? false
          : !(parseInt(editCopayLimit.famAmt) > 99999999999)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.IND_FAM_LIMIT_MAX);
              return true;
            })(),
  
        showNetworkOverlapErrCopayLmt:
          editCopayLimit.beginDate &&
          editCopayLimit.endDate &&
          editCopayLimit.mapSetID &&
          editCopayLimit.benefitPlanStatusNetworkCode &&
          editCopayLimit.typeCode &&
          networkOverlapCopayLimit
            ? (() => {
                reqFieldArr.push(ErrorConst.PLAN_LIMIT_NETWORK_MAP_OVERLAP);
                return true;
              })()
            : false,
        INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(
          editCopayLimit.metExceptionCode
        )
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE);
              return true;
            })(),
        INVALID_LMT_MET_EXC_CODE: editCopayLimit.metExceptionCode
          ? (() => {
              if (!isSpecialcharecter(editCopayLimit.metExceptionCode)) {
                if (!metExcnDesc) {
                  reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                  return true;
                } else {
                  return false;
                }
              }
            })()
          : false,
        INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(
          editCopayLimit.overExceptionCode
        )
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE);
              return true;
            })(),
        INVALID_LMT_OVR_EXC_CODE: editCopayLimit.overExceptionCode
          ? (() => {
              if (!isSpecialcharecter(editCopayLimit.overExceptionCode)) {
                if (!ovrExcnDesc) {
                  reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                  return true;
                } else {
                  return false;
                }
              }
            })()
          : false,
      });
  
      if (reqFieldArr.length) {
        props.seterrorMessages(reqFieldArr);
        return false;
      }
      
  
      if (reqFieldArr.length) {
        setShowError(errors);
        props.seterrorMessages(reqFieldArr);
        return false;
      }
  
     
    }


 

  const copayHandelResetClick = () => {
    props.seterrorMessages([]);
    setEditCopayLimit(resetCopayLimit);
    setShowError({});

    setSelectedCoPayBeginDate(null);
    setSelectedCoPayEndDate(null);
    props.setTabChangeValue({ ...props.tabChangeValue, copaylimitTab: false });

  };

  const addCopaylimit = () => {
    setCopayLimt(true);
    copayHandelResetClick();
  };

  const handleCopayLimtCancel = () => {
    setCopayLimt(false);
  };
  const handelCancelFunction = () => {
    if (tabName === "coPay") {
      setbanifitPlan(false);
    } else if (tabName === "coPayLimit") {
      setCopayLimt(false);
    }
    setShowError({});
    setDialogOpen(false);
    setDialogType("");
    setTabName("");
  };

  const addcopaylimitrefs = useRef(null);
  const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
  const BPCSrefdiv1 = useRef(null);
  const BPCSscrolltoView = () => {
    setTimeout(function () {
      scrollToRef(BPCSrefdiv1);
    }.bind(this), 500);
  };

  const BPCSscrolltoViewedit = () => {
    setTimeout(function () {
      scrollToRef(addcopaylimitrefs);
    }.bind(this), 500);
  };


  return (
    <div>
      {success ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.SUCCESSFULLY_SAVED_INFORMATION}
        </div>
      ) : null}

      <Dialog
        open={dialogOpen}
        onClose={() => {
          setDialogOpen(false);
          setDialogType("");
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >  <DialogContent>
      <DialogContentText id="alert-dialog-description">
        {dialogType == "Delete" || dialogType == "multiDelete" || dialogType == "multiDeleteCopay"
          ? "Are you sure that you want to Delete."
          : dialogType == "Cancel" 
          ? "Changes you made may not be saved." : ""}
      </DialogContentText>
    </DialogContent>
    <DialogActions>
        <Button title="Ok" onClick={() => {
          dialogType == "Delete"
            ? handelDeleteClick() :
          dialogType == "multiDelete"
            ? multiDelete() : 
          dialogType == "multiDeleteCopay" 
            ? multiDeleteCopay() :
            handelCancelFunction();
        }} color="primary" className="btn btn-success">
            Ok
        </Button>
        <Button title="Cancel"  onClick={() => { setDialogOpen(false); setDialogType(''); }} color="primary" autoFocus>
            Cancel
        </Button>
    </DialogActions>
  
      </Dialog>


      {copayDelete ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
        </div>
      ) : null}

      <div className="tabs-container pt-2">
        <div className="tab-header">
          <h3 className="tab-heading float-left">Benefit Plan - Co-Pay</h3>
          <div className="float-right th-btnGroup">
          <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteCopayArray.length == 0} onClick={() => {setDialogOpen(true); setDialogType('multiDeleteCopay');}}>
                          <i className="fa fa-trash" />

                        </Button>
            <Button
              title="Add Co-Pay"
              variant="outlined"
              color="primary"
              className="btn btn-secondary btn-icon-only"
              onClick={() => {
                if( props.majorValidations()){
                 props.setTabChangeValue({ ...props.tabChangeValue, copayTab: true })
                setbanifitPlan(true);
                setSuccess(false);
                setDeleteSuccess({
                  copayDelete: false,
                  copayLimitDelete: false,
                  coInsDelete: false,
                  coInsLimitDelete: false,
                  didetible: false,
                });
                setEditCopay({
                  beginDate: "",
                  endDate: "12/31/9999",
                  mapSetID: "-1",
                  seqNum: "",
                  benefitPlanStatusNetworkCode: "-1",
                  typeCode: "-1",
                  coPayAmt: "",
                  coPayPCT: "",
                  applyOopNum: "",
                  exceptionCode: "",
                  minAge: "",
                  providerTyCd: "-1",
                  serviceTyCd: "-1",
                });
                BPCSscrolltoView();
              }}}
            >
              <i className="fa fa-plus" />
            </Button>
          </div>
          <div className="clearfix" />
        </div>

        <div className="tab-holder mt-2">
          <TableComponent
            headCells={headCells}
            multiDelete
            selected={selectDeleteCopayArray} setSelected={setSelectDeleteCopayArray}
            tableData={getTableData(props.benefitPlanCopay)}
            onTableRowClick={editRow}
          />
        </div>

        {banifitPlan ? (
          <div>
            <div className="tab-header mt-3" ref={BPCSrefdiv1}>
              <h1 className="tab-heading float-left">
                {editCopay.index > -1 ? "Edit Co-pay" : "New Co-pay"}
              </h1>
              <div className="float-right th-btnGroup">
                <Button
                  title={editCopay.index > -1 ? "Update" : "Add"}
                  color="primary"
                  className={
                    editCopay.index > -1
                      ? "btn btn-ic btn-save"
                      : "btn btn-ic btn-add"
                  }
                  onClick={() => handelClick()}
                  disabled={props.privileges && !props.privileges.add? 'disabled':'' }
                >
                  {editCopay.index > -1 ? "Update" : "Add"}
                </Button>
                {editCopay.index > -1 ? (
                  <Link to="MapDefinition" target="_blank" 
                      title="View/Edit Map"
                       className="btn btn-ic btn-view ml-2"
                     >
                      View/Edit Map
                   </Link>
                ) : null}
                <Button
                  title="Reset"
                  color="primary"
                  className="btn btn-ic btn-reset"
                  onClick={() => handelResetClick()}
                >
                  Reset
                </Button>

                {editCopay.index > -1 ? (
                  <Button
                    title="Delete"
                    variant="outlined"
                    color="primary"
                    className="btn btn-ic btn-delete"
                    onClick={minorDelete}
                  >
                    Delete
                  </Button>
                ) : null}
                <Button
                  title="Cancel"
                  color="primary"
                  className="btn btn-cancel"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("Cancel");
                    setTabName("coPay");
                    props.setTabChangeValue({ ...props.tabChangeValue, copayTab: false });
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>

            <div className="tabs-container tabs-container-inner mt-0">
              {/* <div className="tab-header"> */}
              {/* <h1 className="tab-heading float-left">
                                    New Co-Pay
                                </h1> */}
              {/* <h1 className="tab-heading float-left">{editCopay.index > -1 ? "Edit" : "Add"} Co-Pay</h1>
                                <div className="clearfix" />
                            </div> */}

              <div className="tab-body-bordered mt-2">
                <div className="form-wrapper">
                  <div className="flex-block">
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          id="bgn_date_copay_cost_share_tab"
                          name="beginDate"
                          required
                          label="Begin Date"
                          format="MM/dd/yyyy"
                          InputLabelProps={{
                            shrink: true,
                          }}
                          placeholder="mm/dd/yyyy"
                          value={
                            !editCopay.beginDate || editCopay.beginDate == ""
                              ? null
                              : editCopay.beginDate
                          }
                          onChange={handelDateChange(
                            "seteditCopay",
                            "beginDate"
                          )}
                          helperText={
                            showHeaderDateErr
                              ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                              : showBeginDateError
                              ? ErrorConst.BEGIN_DATE_ERROR
                              : beginDtInvalidErr
                              ? ErrorConst.Invalid_Begin_Date_Error
                              : showBgdtGTEnddtErr
                              ? ErrorConst.DATE_RANGE_ERROR
                              : null
                          }
                          error={
                            showHeaderDateErr
                              ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                              : showBeginDateError
                              ? ErrorConst.BEGIN_DATE_ERROR
                              : beginDtInvalidErr
                              ? ErrorConst.Invalid_Begin_Date_Error
                              : showBgdtGTEnddtErr
                              ? ErrorConst.DATE_RANGE_ERROR
                              : null
                          }
                          KeyboardButtonProps={{
                            "aria-label": "change date",
                          }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>

                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          id="end_date_copay_cost_share_tab"
                          name="endDate"
                          required
                          label="End Date"
                          format="MM/dd/yyyy"
                           
							            maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                          InputLabelProps={{
                            shrink: true,
                          }}
                          placeholder="mm/dd/yyyy"
                          value={
                            !editCopay.endDate || editCopay.endDate == ""
                              ? null
                              : editCopay.endDate
                          }
                          onChange={handelDateChange("seteditCopay", "endDate")}
                          helperText={
                            showEndDateError
                              ? ErrorConst.END_DATE_ERROR
                              : endDtInvalidErr
                              ? ErrorConst.Invalid_End_Date_Error
                              : showHeaderEndDateErr
                              ? ErrorConst.Fall_In_Header_End_Date_Err
                              : null
                          }
                          error={
                            showEndDateError
                            ? ErrorConst.END_DATE_ERROR
                            : endDtInvalidErr
                            ? ErrorConst.Invalid_End_Date_Error
                            : showHeaderEndDateErr
                            ? ErrorConst.Fall_In_Header_End_Date_Err
                            : null
                          }
                          KeyboardButtonProps={{
                            "aria-label": "change date",
                          }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>
                  </div>

                  <div className="flex-block">
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="network_status_copay_cost_share_tab"
                        select
                        required
                        label="Network Status"
                        name="benefitPlanStatusNetworkCode"
                        value={editCopay.benefitPlanStatusNetworkCode}
                        inputProps={{ maxLength: 2 }}
                        //onChange={(event) => handelInputChange(event)}
                        onChange={(event) => {
                          setEditCopay({
                            ...editCopay,
                            ["benefitPlanStatusNetworkCode"]: event.target.value,
                            ["bpNetworkCodeDesc"]:
                              event.nativeEvent.target.textContent,
                          });
                        }}
                        placeholder="Please Select One"
                        helperText={
                          showcopayNetworkStatusErr
                            ? ErrorConst.Network_ID_Error
                            : null
                        }
                        error={
                          showcopayNetworkStatusErr
                            ? ErrorConst.Network_ID_Error
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["R1#R_BP_NW_STAT_CD"] &&
                          props.dropdowns["R1#R_BP_NW_STAT_CD"].map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.description}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="map_id_copay_cost_share_tab"
                        select
                        label="Map ID"
                        name="mapSetID"
                        value={editCopay.mapSetID}
                        inputProps={{ maxLength: 2 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Select One"
                        helperText={
                          showcopaymapSetIDErr ? ErrorConst.Map_Id_Error : null
                        }
                        error={
                          showcopaymapSetIDErr ? ErrorConst.Map_Id_Error : null
                        }
                        InputLabelProps={{
                          shrink: true,
                          required: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.mapIdDropdown &&
                          props.mapIdDropdown.map((each) => (
                            <MenuItem
                              selected
                              key={each.mapsetId}
                              value={each.mapsetId}
                            >
                              {each.mapsetId}-{each.mapDesc}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="type_code_copay_cost_share_tab"
                        select
                        label="Co-pay Type Code"
                        name="typeCode"
                        value={editCopay.typeCode}
                        inputProps={{ maxLength: 2 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Select One"
                        helperText={
                          showCopayTypeCodeErr ? ErrorConst.TYPE_CODE : null
                        }
                        error={
                          showCopayTypeCodeErr ? ErrorConst.TYPE_CODE : null
                        }
                        InputLabelProps={{
                          shrink: true,
                          required: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["Reference#R_BP_COPAY_TY_CD"] &&
                          props.dropdowns["Reference#R_BP_COPAY_TY_CD"].map(
                            (each) => (
                              <MenuItem
                                selected
                                key={each.code}
                                value={each.code}
                              >
                                {each.description}
                              </MenuItem>
                            )
                          )}
                      </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="amount_copay_cost_share_tab"
                        label="Amount"
                        name="coPayAmt"
                        value={editCopay.coPayAmt}
                        inputProps={{ maxLength: 10 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Enter"
                        helperText={
                          showCopayAmtErr
                            ? ErrorConst.Benefit_Plan_Amount_Error
                            : coPayAmtFloatErr ? ErrorConst.COPAY_AMT_ERROR
                            : null
                        }
                        error={
                          showCopayAmtErr
                            ? ErrorConst.Benefit_Plan_Amount_Error
                            : coPayAmtFloatErr ? ErrorConst.COPAY_AMT_ERROR
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">$</InputAdornment>
                          ),
                        }}
                      ></TextField>
                    </div>
                  </div>

                  <div className="flex-block">
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="percent_copay_cost_share_tab"
                        label="Percent"
                        name="coPayPCT"
                        value={editCopay.coPayPCT}
                        inputProps={{ maxLength: 10 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Enter"
                        helperText={
                          percentageErr ? ErrorConst.PERCENTAGE_ERROR : null
                        }
                        error={
                          percentageErr ? ErrorConst.PERCENTAGE_ERROR : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        {/* <MenuItem value="-1">Please Select One</MenuItem>
                                                {props.dropdowns && Object.keys(props.dropdowns).length > 0 &&  props.dropdowns['Claims#R_BP_TY_CD'] && props.dropdowns['Claims#R_BP_TY_CD'].map( each => (
                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> 
                                                ))} */}
                      </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="exception_code_copay_cost_share_tab"
                        label="Exception Code"
                        name="exceptionCode"
                        value={editCopay.exceptionCode}
                        inputProps={{ maxLength: 4 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Enter"
                        helperText={
                          EXC_CODE_NOT_MATCH_LOB
                            ? ErrorConst.EXC_CODE_NOT_MATCH_LOB
                            : null
                        }
                        error={
                          EXC_CODE_NOT_MATCH_LOB
                            ? ErrorConst.EXC_CODE_NOT_MATCH_LOB
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      ></TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="pocket_max_copay_cost_share_tab"
                        name="applyOopNum"
                        required
                        label="Percent applied to out of Pocket Max"
                        value={editCopay.applyOopNum}
                        inputProps={{ maxLength: 10 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Enter"
                        helperText={
                          showPercentageAppliedtoEmptyErr
                            ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
                            : showApplyOopNumErr
                            ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
                            : null
                        }
                        error={
                          showPercentageAppliedtoEmptyErr
                            ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
                            : showApplyOopNumErr
                            ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        {/* <MenuItem value="-1">Please Select One</MenuItem>
                                                {props.dropdowns && Object.keys(props.dropdowns).length > 0 &&  props.dropdowns['Claims#R_BP_TY_CD'] && props.dropdowns['Claims#R_BP_TY_CD'].map( each => (
                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> 
                                                ))} */}
                      </TextField>
                    </div>
                  </div>

                  <div className="flex-block">
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="rank_copay_cost_share_tab"
                        required
                        label="Rank"
                        name="seqNum"
                        value={editCopay.seqNum}
                        inputProps={{ maxLength: 6 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Enter"
                        helperText={
                          showRankErrCoPay
                            ? ErrorConst.Rank_Error
                            : ShowRankErrSpeCoPay
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                            : ShowRankErrCoPayZero
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                            : null
                        }
                        error={
                          showRankErrCoPay
                            ? ErrorConst.Rank_Error
                            : ShowRankErrSpeCoPay
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                            : ShowRankErrCoPayZero
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        {/* <MenuItem value="-1">Please Select One</MenuItem>
                                                {props.dropdowns && props.dropdowns['Reference#P_SVC_TY_CD'] && props.dropdowns['Reference#P_SVC_TY_CD'].map(each => (
                                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                                ))} */}
                      </TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="min_age_copay_cost_share_tab"
                        required
                        label="Min Age"
                        name="minAge"
                        value={editCopay.minAge}
                        inputProps={{ maxLength: 3 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Enter"
                        helperText={
                          showMinageErr
                            ? ErrorConst.MIN_AGE
                            : showMinageInvalid
                            ? ErrorConst.INVALID_AGE
                            : showMinAgeNan
                            ? ErrorConst.INVALID_AGE_NAN
                            : null
                        }
                        error={
                          showMinageErr
                            ? ErrorConst.MIN_AGE
                            : showMinageInvalid
                            ? ErrorConst.INVALID_AGE
                            : showMinAgeNan
                            ? ErrorConst.INVALID_AGE_NAN
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        {/* <MenuItem value="-1">Please Select One</MenuItem>
                                                {props.dropdowns && Object.keys(props.dropdowns).length > 0 &&  props.dropdowns['Claims#R_BP_TY_CD'] && props.dropdowns['Claims#R_BP_TY_CD'].map( each => (
                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> 
                                                ))} */}
                      </TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="service_type_copay_cost_share_tab"
                        required
                        name="serviceTyCd"
                        label="Service Type Code"
                        select
                        value={editCopay.serviceTyCd}
                        inputProps={{ maxLength: 2 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Select One"
                        helperText={
                          showServiceTypeErr
                            ? ErrorConst.SERVICE_TYPE_CODE
                            : null
                        }
                        error={
                          showServiceTypeErr
                            ? ErrorConst.SERVICE_TYPE_CODE
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["Reference#P_TY_CD"] &&
                          props.dropdowns["Reference#P_TY_CD"].map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.description}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="provider_type_copay_cost_share_tab"
                        name="providerTyCd"
                        select
                        label="Provider Type Code"
                        value={editCopay.providerTyCd}
                        inputProps={{ maxLength: 2 }}
                        onChange={(event) => handelInputChange(event)}
                        placeholder="Please Select One"
                        // helperText={props.errors.planTypeErr ? ErrorConst.Benefit_Plan_Type_Error : null}
                        // error={props.errors.planTypeErr ? ErrorConst.Benefit_Plan_Type_Error : null}
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["P1#P_TY_CD"] &&
                          props.dropdowns["P1#P_TY_CD"].map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.description}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : null}

        {copayLimitDelete ? (
          <div className="alert alert-success custom-alert" role="alert">
            {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
          </div>
        ) : null}
        <div className="tab-header">
          <h3 className="tab-heading float-left">
            Benefit Plan - Co-Pay Limits
          </h3>
          <div className="float-right th-btnGroup">
          <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => {setDialogOpen(true); setDialogType('multiDelete');}}>
                          <i className="fa fa-trash" />

                        </Button>
            <Button
              title="Add Co-Pay Limits"
              variant="outlined"
              color="primary"
              className="btn btn-secondary btn-icon-only"
              onClick={() => {
                if( props.majorValidations()){
                props.setTabChangeValue({ ...props.tabChangeValue, copaylimitTab: true })
                setCopayLimt(true);
                setSuccess(false);
                setDeleteSuccess({
                  copayDelete: false,
                  copayLimitDelete: false,
                  coInsDelete: false,
                  coInsLimitDelete: false,
                  didetible: false,
                });
                setEditCopayLimit({
                  beginDate: "",
                  endDate: "12/31/9999",
                  benefitPlanStatusNetworkCode: "-1",
                  mapSetID: "-1",
                  typeCode: "-1",
                  indAmt: "",
                  indPlusAmt: "",
                  famAmt: "",
                  metExceptionCode: "",
                  overExceptionCode: "",
                  seqNum: "",
                });
                BPCSscrolltoViewedit();
              }}}
            >
              <i className="fa fa-plus" />
            </Button>
          </div>
          <div className="clearfix" />
        </div>

        <div className="tab-holder mt-2">
          <TableComponent
            headCells={copayLimitHeadCells}
            multiDelete selected={selectDeleteArray} setSelected={setSelectDeleteArray}
            tableData={getTableDataCopayLimit(props.benefitPlanCopayLimit)}
            onTableRowClick={editRowCopay}
          />
        </div>

        {copayLimit ? (
          <div>
            <div className="tab-header mt-3" ref={addcopaylimitrefs}>
              <h3 className="tab-heading float-left">
                {editCopayLimit.index > -1
                  ? "Edit Co-pay Limit"
                  : "New Co-pay Limit"}
              </h3>
              <div className="float-right th-btnGroup">
                <Button
                  title={editCopayLimit.index > -1 ? "Update" : "Add"}
                  color="primary"
                  className={
                    editCopayLimit.index > -1
                      ? "btn btn-ic btn-save"
                      : "btn btn-ic btn-add"
                  }
                  onClick={() => handelClickCopayLimit()}
                >
                  {editCopayLimit.index > -1 ? "Update" : "Add"}
                </Button>
                {editCopayLimit.index > -1 ? (
                  <Link to="MapDefinition" target="_blank" 
                      title="View/Edit Map"
                       className="btn btn-ic btn-view"
                     >
                      View/Edit Map
                   </Link>
                ) : null}
                <Button
                  title="Reset"
                  color="primary"
                  className="btn btn-ic btn-reset"
                  onClick={() => copayHandelResetClick()}
                >
                  Reset
                </Button>
                {editCopayLimit.index > -1 ? (
                  <Button
                    title="Delete"
                    variant="outlined"
                    color="primary"
                    className="btn btn-ic btn-delete"
                    onClick={minorDeleteCPL}
                  >
                    Delete
                  </Button>
                ) : null}
                <Button
                  title="Cancel"
                  color="primary"
                  className="btn btn-cancel"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("Cancel");
                    setTabName("coPayLimit");
                    props.setTabChangeValue({ ...props.tabChangeValue, copaylimitTab: false });
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>

            <div className="tabs-container tabs-container-inner mt-0">
              {/* <div className="tab-header"> */}
              {/* <h1 className="tab-heading float-left">
                                    New Co-pay Limits
                                </h1> */}
              {/* <h1 className="tab-heading float-left">{editCopayLimit.index > -1 ? "Edit" : "Add"} Co-pay Limits</h1>
                                <div className="clearfix" />
                            </div> */}

              <div className="tab-body-bordered mt-2">
                <div className="form-wrapper">
                  <div className="flex-block">
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          id="bgn_date_copay_lmt_cost_share_tab"
                          name="beginDate"
                          required
                          label="Begin Date"
                          format="MM/dd/yyyy"
                          InputLabelProps={{
                            shrink: true,
                          }}
                          placeholder="mm/dd/yyyy"
                          value={
                            !editCopayLimit.beginDate ||
                            editCopayLimit.beginDate == ""
                              ? null
                              : editCopayLimit.beginDate
                          }
                          onChange={handelLimitDateChange(
                            "setEditCopayLimit",
                            "beginDate"
                          )}
                          helperText={
                            showBeginDateError
                              ? ErrorConst.Begin_Date_Error
                              :showHeaderDateErrCoPayLimit
                              ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                              : null
                          }
                          error={
                            showBeginDateError
                              ? ErrorConst.Begin_Date_Error
                              :showHeaderDateErrCoPayLimit
                              ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                              : null
                          }
                          KeyboardButtonProps={{
                            "aria-label": "change date",
                          }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>

                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          id="end_date_copay_lmt_cost_share_tab"
                          name="endDate"
                          required
                          label="End Date"
                          format="MM/dd/yyyy"
                           
							            maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                          InputLabelProps={{
                            shrink: true,
                          }}
                          placeholder="mm/dd/yyyy"
                          value={
                            !editCopayLimit.endDate ||
                            editCopayLimit.endDate == ""
                              ? null
                              : editCopayLimit.endDate
                          }
                          onChange={handelLimitDateChange(
                            "setEditCopayLimit",
                            "endDate"
                          )}
                          helperText={
                            showEndDateError
                              ? ErrorConst.END_DATE_ERROR
                              : endDtInvalidErr
                              ? ErrorConst.Invalid_End_Date_Error
                              : showHeaderEndDateErrLimit
                              ? ErrorConst.Fall_In_Header_End_Date_Err
                              : null
                          }
                          error={
                            showEndDateError
                              ? ErrorConst.END_DATE_ERROR
                              : endDtInvalidErr
                              ? ErrorConst.Invalid_End_Date_Error
                              : showHeaderEndDateErrLimit
                              ? ErrorConst.Fall_In_Header_End_Date_Err
                              : null
                          }
                          KeyboardButtonProps={{
                            "aria-label": "change date",
                          }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>
                  </div>
                  <div className="flex-block">
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="network_status_copay_lmt_cost_share_tab"
                        required
                        select
                        name="benefitPlanStatusNetworkCode"
                        label="Network Status"
                        value={editCopayLimit.benefitPlanStatusNetworkCode}
                        inputProps={{ maxLength: 2 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Select One"
                        helperText={
                          showNetworkStatusErr
                            ? ErrorConst.Network_Status_Error
                            : null
                        }
                        error={
                          showNetworkStatusErr
                            ? ErrorConst.Network_Status_Error
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["R1#R_BP_NW_STAT_CD"] &&
                          props.dropdowns["R1#R_BP_NW_STAT_CD"].map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.description}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="map_id_copay_lmt_cost_share_tab"
                        required
                        select
                        label="Map ID"
                        name="mapSetID"
                        value={editCopayLimit.mapSetID}
                        inputProps={{ maxLength: 2 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Select One"
                        helperText={
                          showmapSetIDErr ? ErrorConst.Map_Id_Error : null
                        }
                        error={showmapSetIDErr ? ErrorConst.Map_Id_Error : null}
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.mapIdDropdown &&
                          props.mapIdDropdown.map((each) => (
                            <MenuItem
                              selected
                              key={each.mapsetId}
                              value={each.mapsetId}
                            >
                              {each.mapsetId}-{each.mapDesc}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="limit_type_copay_lmt_cost_share_tab"
                        required
                        select
                        label="Limit Type Code"
                        name="typeCode"
                        value={editCopayLimit.typeCode}
                        inputProps={{ maxLength: 2 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Select One"
                        helperText={
                          showLimitTypeCodErr ? ErrorConst.TYPE_CODE : null
                        }
                        error={
                          showLimitTypeCodErr ? ErrorConst.TYPE_CODE : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["Reference#R_BP_LMT_TY_CD"] &&
                          props.dropdowns["Reference#R_BP_LMT_TY_CD"].map(
                            (each) => (
                              <MenuItem
                                selected
                                key={each.code}
                                value={each.code}
                              >
                                {each.description}
                              </MenuItem>
                            )
                          )}
                      </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        InputLabelProps={{
                          shrink: true,
                        }}
                        id="individual_lmt_copay_lmt_cost_share_tab"
                        required
                        label="Individual Limit"
                        name="indAmt"
                        value={editCopayLimit.indAmt}
                        inputProps={{ maxLength: 14 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Enter"
                        helperText={
                          indAmntErr
                            ? ErrorConst.INDIVIDUAL_LIMIT
                            : invalidIndAmntErr
                            ? ErrorConst.INVALID_IND_LIMIT
                            : invalidIndAmntmaxErr
                            ? ErrorConst.IND_LIMIT_MAX
                            : null
                        }
                        error={
                          indAmntErr
                            ? ErrorConst.INDIVIDUAL_LIMIT
                            : invalidIndAmntErr
                            ? ErrorConst.INVALID_IND_LIMIT
                            : invalidIndAmntmaxErr
                            ? ErrorConst.IND_LIMIT_MAX
                            : null
                        }
                      ></TextField>
                    </div>
                  </div>

                  <div className="flex-block">
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="indi_plus_copay_lmt_cost_share_tab"
                        label="Individual +1 Limit"
                        name="indPlusAmt"
                        placeholder="Please Enter"
                        value={editCopayLimit.indPlusAmt}
                        inputProps={{ maxLength: 14 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Enter"
                        helperText={
                          invalidIndPlusAmntErr
                            ? ErrorConst.INVALID_IND_PLUS_LIMIT
                            : invalidIndPlusAmntmaxErr
                            ? ErrorConst.IND_PLUS_LIMIT_MAX
                            : null
                        }
                        error={
                          invalidIndPlusAmntErr
                            ? ErrorConst.INVALID_IND_PLUS_LIMIT
                            : invalidIndPlusAmntmaxErr
                            ? ErrorConst.IND_PLUS_LIMIT_MAX
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      ></TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="family_limit_copay_lmt_cost_share_tab"
                        label="Family Limit"
                        name="famAmt"
                        value={editCopayLimit.famAmt}
                        inputProps={{ maxLength: 14 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Enter"
                        helperText={
                          invalidIndFamAmntErr
                            ? ErrorConst.INVALID_IND_FAM_LIMIT
                            : invalidIndFamAmntmaxErr
                            ? ErrorConst.IND_FAM_LIMIT_MAX
                            : null
                        }
                        error={
                          invalidIndFamAmntErr
                            ? ErrorConst.INVALID_IND_FAM_LIMIT
                            : invalidIndFamAmntmaxErr
                            ? ErrorConst.IND_FAM_LIMIT_MAX
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      ></TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="limit_met_copay_lmt_cost_share_tab"
                        label="Limit met Exc Code"
                        name="metExceptionCode"
                        value={editCopayLimit.metExceptionCode}
                        inputProps={{ maxLength: 4 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Enter"
                        helperText={
                          INVALID_LMT_MET_EXC_CODE
                            ? ErrorConst.INVALID_LMT_MET_EXC_CODE
                            : INVALID_LMT_MET_EXC_CODE_SPL
                            ? ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE
                            : null
                        }
                        error={
                          INVALID_LMT_MET_EXC_CODE
                            ? ErrorConst.INVALID_LMT_MET_EXC_CODE
                            : INVALID_LMT_MET_EXC_CODE_SPL
                            ? ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      ></TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="limit_over_copay_lmt_cost_share_tab"
                        label="Limit over Exc Code"
                        name="overExceptionCode"
                        value={editCopayLimit.overExceptionCode}
                        inputProps={{ maxLength: 4 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Enter"
                        helperText={
                          INVALID_LMT_OVR_EXC_CODE
                            ? ErrorConst.INVALID_LMT_OVR_EXC_CODE
                            : INVALID_LMT_OVR_EXC_CODE_SPE
                            ? ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE
                            : null
                        }
                        error={
                          INVALID_LMT_OVR_EXC_CODE
                            ? ErrorConst.INVALID_LMT_OVR_EXC_CODE
                            : INVALID_LMT_OVR_EXC_CODE_SPE
                            ? ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      ></TextField>
                    </div>
                  </div>

                  <div className="flex-block">
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="rank_copay_lmt_cost_share_tab"
                        required
                        label="Rank"
                        name="seqNum"
                        value={editCopayLimit.seqNum}
                        inputProps={{ maxLength: 6 }}
                        onChange={(event) => handelInputChangeLimit(event)}
                        placeholder="Please Enter"
                        helperText={
                          ShowRankErr
                            ? ErrorConst.Rank_Error
                            : ShowRankErrSpe
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                            : ShowRankErrZero
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                            : null
                        }
                        error={
                          ShowRankErr
                            ? ErrorConst.Rank_Error
                            : ShowRankErrSpe
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                            : ShowRankErrZero
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                            : null
                        }
                        InputLabelProps={{
                          shrink: true,
                        }}
                      ></TextField>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : null}
      </div>

    </div>
  );
}

export default forwardRef(BenefitPlanCostShare);
