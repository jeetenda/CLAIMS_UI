import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import Checkbox from '@material-ui/core/Checkbox';
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import * as BenefitPlanConstants from './BenefitPlanConstants';
import DateFnsUtils from '@date-io/date-fns';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker
} from '@material-ui/pickers';

export default function BenefitPlanSearchForm(props) {

  const [selectedEndDate, setSelectedEndDate] = React.useState('');
  const [selectedBeginDate, setSelectedBeginDate] = React.useState('');
  const [{ showBeginDateError, showEndDateError }, setShowError] = React.useState(false);
  const [beginDatePress, setBeginDatePress] = React.useState(false);
  const [endDatePress, setEndDatePress] = React.useState(false);

  React.useEffect(() => {
    props.values.endDate !== '' ? setSelectedEndDate(props.values.endDate) : setSelectedEndDate('');
    props.values.beginDate !== '' ? setSelectedBeginDate(props.values.beginDate) : setSelectedBeginDate('');
  }, [props.values.beginDate, props.values.endDate]);

  const handleBeginDateChange = d => {
    setSelectedBeginDate(d);
    setBeginDatePress(false);
    // d && props.handleDCDtChange('beginDate',d);
    d && props.handleDCDtChange('beginDate', ((d.getMonth() + 1 + '').length == 1 ? ('0' + (d.getMonth() + 1)) : (d.getMonth() + 1)) + '/' + d.getDate() + '/' + d.getFullYear());
  };

  const handleBeginDateText = beginDateText => {
    setSelectedBeginDate(beginDateText.target.value);
    setBeginDatePress(true);
  };

  const handleEndDateChange = d => {
    setSelectedEndDate(d);
    setEndDatePress(false);
    d && props.handleDCDtChange('endDate', ((d.getMonth() + 1 + '').length == 1 ? ('0' + (d.getMonth() + 1)) : (d.getMonth() + 1)) + '/' + d.getDate() + '/' + d.getFullYear());
    //d && props.handleDCDtChange('endDate',d);

  };

  const handleEndDateText = endDateText => {
    setSelectedEndDate(endDateText.target.value);
    setEndDatePress(true);
  };

  return (

    // <div className="tab-body mt-2">
    <form autoComplete="off" id="form">
      <div className="form-wrapper">
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="bgn_date_main"
              label="Plan Begin Date"
              format="MM/dd/yyyy"
              InputLabelProps={{
                shrink: true,
                required: false
              }}
              placeholder="mm/dd/yyyy"
              value={selectedBeginDate === '' ? null : selectedBeginDate}
              onChange={handleBeginDateChange}
              onKeyUp={handleBeginDateText}
              helperText={props.errors.beginDtInvalidErr ? BenefitPlanConstants.Plan_Invalid_Begin_Date_Error : props.errors.showBgnDtGtEndDtError ? BenefitPlanConstants.DATE_RANGE_ERROR : null}
              error={props.errors.beginDtInvalidErr ? BenefitPlanConstants.Plan_Invalid_Begin_Date_Error : props.errors.showBgnDtGtEndDtError ? BenefitPlanConstants.DATE_RANGE_ERROR : null}
              KeyboardButtonProps={{
                'aria-label': 'change date',
              }}
            />
          </div>
        </MuiPickersUtilsProvider>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="end_date_main"
              label="Plan End Date"
              format="MM/dd/yyyy"

              maxDate={new Date('9999-12-31T13:00:00.000+0000')}
              InputLabelProps={{
                shrink: true,
                required: false
              }}
              placeholder="mm/dd/yyyy"
              value={selectedEndDate === '' ? null : selectedEndDate}
              onChange={handleEndDateChange}
              onKeyUp={handleEndDateText}
              helperText={props.errors.endDtInvalidErr ? BenefitPlanConstants.Plan_Invalid_End_Date_Error : null}
              error={props.errors.endDtInvalidErr ? BenefitPlanConstants.Plan_Invalid_End_Date_Error : null}
              KeyboardButtonProps={{
                'aria-label': 'change date',
              }}
            />
          </div>
        </MuiPickersUtilsProvider>

        <div className="flex-block">
          <div className="mui-custom-form input-md">
            <TextField
              id="Benefit_plan_id_main"
              label="Benefit Plan ID"
              value={props.values.benefitPlanId}
              inputProps={{ maxLength: 6 }}
              onChange={props.handleChanges('benefitPlanId')}
              placeholder=""
              helperText={
                props.errors.benefitPlanIDerror ? BenefitPlanConstants.BenefitPlanID_Err
                  : props.errors.benefitPlanIDLengtherror ? BenefitPlanConstants.BenefitPlan_Error
                    : null}
              InputLabelProps={{
                shrink: true,
                // required: true,
              }}
              error={
                props.errors.benefitPlanIDerror ? BenefitPlanConstants.BenefitPlanID_Err
                  : props.errors.benefitPlanIDLengtherror ? BenefitPlanConstants.BenefitPlan_Error
                    : null}
            />
            <div className="sub-radio mt-0">
              <RadioGroup
                row
                aria-label="startsContains"
                name="HideInactiveProviders"
                value={props.values.benefitStartsOrContains}
                onChange={props.handleChanges('benefitStartsOrContains')}
                InputLabelProps={{
                  shrink: true,
                  required: false
                }}
              >
                <FormControlLabel
                  id="start_with_main"
                  value="StartsWith"
                  control={<Radio color="primary" />}
                  label="Starts With"
                />
                <FormControlLabel
                  id="contains_main"
                  value="Contains"
                  control={<Radio color="primary" />}
                  label="Contains"
                />
              </RadioGroup>
            </div>
          </div>
          <div className="mui-custom-form with-select input-md">
            <TextField
              id="Benefit_plan_type_main"
              select
              label="Benefit Plan Type"
              value={props.values.benefitPlanType}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('benefitPlanType')}
              placeholder=""
              // helperText={props.errors.showBenefitPlanTypeError ? BenefitPlanConstants.BenefitPlanType_Error : null}
              InputLabelProps={{
                shrink: true,
                required: false
              }}
            // error={props.errors.showBenefitPlanTypeError ? BenefitPlanConstants.BenefitPlanType_Error : null}
            >
              {/* <MenuItem selected key="Please Select One" value="Please Select One">
          Please Select One
            </MenuItem>
            <MenuItem selected key="F" value="F">F</MenuItem> */}
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
            </MenuItem>
              {/* {console.log(" props.dropdowns=============", props.dropdowns)} */}
              {props.dropdowns && props.dropdowns['Claims#R_BP_TY_CD'] && props.dropdowns['Claims#R_BP_TY_CD'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}

            </TextField>
          </div>
          <div className="mui-custom-form input-md">
            <TextField
              id="Benefit_plan_description_main"
              label="Benefit Plan Description"
              value={props.values.description}
              inputProps={{ maxLength: 40 }}
              onChange={props.handleChanges('description')}
              placeholder=""
              helperText={props.errors.showdescriptionError ? BenefitPlanConstants.BenefitPlanDescription_Error : props.errors.showdescriptionLengthError ? BenefitPlanConstants.Description_Error : null}
              InputLabelProps={{
                shrink: true,
              }}
              error={props.errors.showdescriptionError ? BenefitPlanConstants.BenefitPlanDescription_Error : props.errors.showdescriptionLengthError ? BenefitPlanConstants.Description_Error : null}
            />
            <div className="sub-radio mt-0">
              <RadioGroup
                row
                aria-label="startsContains"
                name="HideInactiveProviders"
                value={props.values.descriptionCodeStartsOrContains}
                onChange={props.handleChanges('descriptionCodeStartsOrContains')}
                InputLabelProps={{
                  shrink: true,
                  required: false
                }}
              >
                <FormControlLabel
                  id="start_with_bpd_main"
                  value="StartsWith"
                  control={<Radio color="primary" />}
                  label="Starts With"
                />
                <FormControlLabel
                  id="contains_bpd_main"
                  value="Contains"
                  control={<Radio color="primary" />}
                  label="Contains"
                />
              </RadioGroup>
            </div>
          </div>
        </div>

      </div>
      <div className="container-space clearfix">
        <div className="float-right th-btnGroup">
          <Button
            title="Search"
            variant="outlined"
            color="primary"
            className="btn btn-ic btn-search"
            onClick={props.searchCheck}
            disabled={props.privileges && !props.privileges.search? 'disabled':'' }
            id="btn-search"
          >
            {' '}
            Search
          {' '}

          </Button>
          <Button
            title="Reset"
            variant="outlined"
            color="primary"
            className="btn btn-ic btn-reset"
            onClick={props.resetTable}
            id="btn-reset"
          >
            {' '}
            Reset
          {' '}

          </Button>

        </div>
      </div>
    </form>
    // </div>
  );
}
