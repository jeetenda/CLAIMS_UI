import React, { useState, useEffect, useRef , forwardRef,useImperativeHandle } from 'react';
import { Button } from "react-bootstrap";
import TableComponent from './../../../SharedModules/Table/Table';
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import BenfitTabelComponent from "./BenfitTabelComponent";
import * as moment from "moment";
import 'moment-range';
import DateFnsUtils from "@date-io/date-fns";
import dateFnsFormat from "date-fns/format";
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from "@material-ui/pickers";
import AppBar from "@material-ui/core/AppBar";
import TabPanel from "../../../SharedModules/TabPanel/TabPanel";
import { withRouter } from "react-router";
import { makeStyles } from "@material-ui/core/styles";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import InputAdornment from '@material-ui/core/InputAdornment';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import * as serviceEndPoint from '../../../SharedModules/services/service';
import axios from 'axios';
import isSpecialcharecter from './validations';
import { Link } from 'react-router-dom';
import { useConfirm } from "../../../SharedModules/MUIConfirm/index";

const headCells = [
    { id: "bpNetworkCodeDesc", numeric: false, disablePadding: true, label: 'Network Status', enableHyperLink: true, fontSize: 12 },
    { id: "mapSetID", numeric: false, disablePadding: true, label: 'Map ID', enableHyperLink: false, fontSize: 12 },
    { id: "beginDate", numeric: false, disablePadding: true, label: 'Begin Date', enableHyperLink: false, fontSize: 12 },
    { id: "endDate", numeric: false, disablePadding: true, label: 'End Date', enableHyperLink: false, fontSize: 12 },
    { id: "typeCode", numeric: false, disablePadding: true, label: 'Limit Code', enableHyperLink: false, fontSize: 12 },
    { id: "limits", numeric: false, disablePadding: true, label: 'Limits I/I+1/F', enableHyperLink: false, fontSize: 12 },
    { id: "metExceptionCode", numeric: false, disablePadding: true, label: 'Limit Met Exc Code', enableHyperLink: false, fontSize: 12,isToolTip:true,toolTip: "metExcnDesc" },
    { id: "overExceptionCode", numeric: false, disablePadding: true, label: 'Limit Met Over Exc Code', enableHyperLink: false, fontSize: 12,isToolTip:true,toolTip: "ovrExcnDesc" },
    { id: "seqNum", numeric: false, disablePadding: true, label: 'Rank', enableHyperLink: false, fontSize: 12 },
]

function BenefitPlanLimits(props,ref) {
    const [selectedEndDate, setSelectedEndDate] = React.useState('');
    const [selectedBeginDate, setSelectedBeginDate] = React.useState('');
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const [successMessages, setSuccessMessages] = React.useState([]);
    const [banifitPlan, setbanifitPlan] = useState(false);
    const [dialogOpen, setDialogOpen] = useState(false);
    const [dialogType, setDialogType] = useState('');
    const [tableData, setTableData] = useState([]);
    const [valuesForN, setValuesForN] = useState([]);
    const [valuesForCat, setValuesForCat] = useState([]);
    const [errorMessages, seterrorMessages] = React.useState([]);
    const [selectDeleteArray, setSelectDeleteArray] = useState([]);
    const [deleteSuccess, setDeleteSuccess] = useState(false);
    const muiconfirm = useConfirm();
    const [editBenefitPlan, setEditBenefitPlan] = useState({
        beginDate: '',
            endDate: "",
            benefitPlanStatusNetworkCode: "-1",
            mapSetID: "-1",
            typeCode: "-1",
            indAmt: "",
            indPlusAmt: "",
            famAmt: "",
            metExceptionCode: "",
            overExceptionCode: "",
            seqNum: "",
            saBYPSIndicator: "0",
            ctbckIndicator: "0",
            benefitPlanEligFunctionalAreaCode: "-1",
            benefitPlanEligFunctionalAreavalue : "-1",
            
    });
    const [resetBenefitPlan, setResetBenefitPlan] = useState({
        beginDate: '',
            endDate: "",
            benefitPlanStatusNetworkCode: "-1",
            mapSetID: "-1",
            typeCode: "-1",
            indAmt: "",
            indPlusAmt: "",
            famAmt: "",
            metExceptionCode: "",
            overExceptionCode: "",
            seqNum: "",
            saBYPSIndicator: "0",
            ctbckIndicator: "0",
            benefitPlanEligFunctionalAreaCode: "-1",
            benefitPlanEligFunctionalAreavalue : "-1",
            benefitPlanNursFunctionalAreaCode :"-1",
            benefitPlanNursFunctionalAreaValue: "-1"
    });

    const [{ showNetworkStatusErr,showFunctionalFieldErr,showFunctionalFieldErr1,showValueFieldErr,showValueFieldErr1, showmapSetIDErr,showNetworkOverlapErr, showLimitTypeCodErr, showIndividualLimitErr, showIndLimInvErr,
        showIndPlusInvErr,showFamInvErr, ShowLimitMetExcErr, ShowLimitoverExcCodeErr, ShowRankErr,showRankErrZero, showBeginDate, ShowEndDate,
        INVALID_LMT_MET_EXC_CODE,
        INVALID_LMT_OVR_EXC_CODE, showRankOverlapErr,
        showHeaderDateErr, showBeginDateError, showEndDateError,showBgdtGTEnddtErr, beginDtInvalidErr, endDtInvalidErr, INVALID_LMT_OVR_EXC_CODE_SPE, INVALID_LMT_MET_EXC_CODE_SPL, showHeaderEndDateErr
    }, setShowError] = React.useState(false);

    const handelInputChange = (event) => {
        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab : true })
        setEditBenefitPlan({
            ...editBenefitPlan, [event.target.name]: event.target.value
        })
        
    }

    const handleBeginDateChange = date => {
        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab : true })
        setSelectedBeginDate(date);
        setEditBenefitPlan({ ...editBenefitPlan, ['beginDate']: formatDate(date) })
    };

    const handleEndDateChange = date => {
        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab : true })
        setSelectedEndDate(date);
        setEditBenefitPlan({ ...editBenefitPlan, ['endDate']: formatDate(date) })
    };

    const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        dt = new Date(dt);
        if (dt.toString() == "Invalid Date") {
            return dt;
        } else {
            return dateFnsFormat(dt, "MM/dd/yyyy");
        }
    };

    const getTableData = (data) => {
        if (data && data.length) {
            let tData = JSON.stringify(data);
            tData = JSON.parse(tData);
            tData.map((each, index) => {
                each.index = index;
                each.limits = (each.indAmt?each.indAmt:'') + "/" + (each.indPlusAmt?each.indPlusAmt:'') + "/" + (each.famAmt?each.famAmt:'');
            });
            return tData;
        } else {
            return [];
        }
    }

    const getSystemListNumbers = () => {
        const v1 = axios.post(serviceEndPoint.SYSTEM_LIST_NUMBERS_ENDPOINT + 'B_COE_CD/MED/R2',{});
        const v2 = axios.post(serviceEndPoint.SYSTEM_LIST_NUMBERS_ENDPOINT + 'B_LTC_SPAN_TY_CD/MED/R2',{});
        setspinnerLoader(true);
        Promise.all([v1, v2]).then(function(values) {            
            setspinnerLoader(false);
            if(values[0].data.searchResultsValues){
                setValuesForCat(values[0].data.searchResultsValues);
            }
            if(values[1].data.searchResultsValues){
                setValuesForN(values[1].data.searchResultsValues);
            }
        }).catch(error => { 
            setspinnerLoader(false);
        });
    }

    useEffect(() => {
        getSystemListNumbers();
    }, []);

    useEffect(() => {
        setTableData(props.benefitPlanLimit ? props.benefitPlanLimit : []);
    }, [props.benefitPlanLimit]);

    useEffect(() => {
        editBenefitPlan.beginDate !== '' ? setSelectedBeginDate(editBenefitPlan.beginDate) : setSelectedBeginDate(null);
        editBenefitPlan.endDate !== '' ? setSelectedEndDate(editBenefitPlan.endDate) : setSelectedEndDate('');
    }, [editBenefitPlan.beginDate, editBenefitPlan.endDate]);

    const editRow = row => (event) => {
        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab: false });
        setbanifitPlan(true);
        setEditBenefitPlan(row);
        setResetBenefitPlan({
            beginDate: row.beginDate,
            endDate: row.endDate,
            benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
            mapSetID: row.mapSetID,
            typeCode: row.typeCode,
            indAmt: row.indAmt,
            indPlusAmt: row.indPlusAmt,
            famAmt: row.famAmt,
            metExceptionCode: row.metExceptionCode,
            overExceptionCode: row.overExceptionCode,
            seqNum: row.seqNum,
            saBYPSIndicator: row.saBYPSIndicator,
            ctbckIndicator: row.ctbckIndicator,
            benefitPlanEligFunctionalAreaCode: row.benefitPlanNursFunctionalAreaCode,
            index: row.index,
            row: row
        });
        setSuccessMessages([]);
        PLBPscrolltoView();
    };

    const validateExcCode =  (c) => {
       return new Promise((resolve,reject)=>{
            setspinnerLoader(true);
            axios.get(serviceEndPoint.BENEFIT_PLAN_EXC_CODE_VALIDATION+c+"/"+"MED")
            .then(response => {
               if(response.data.data && response.data.data.excCodeDesc){
                    resolve(response.data.data.excCodeDesc);
               }else{
                    resolve(false);
               }              
            })
            .catch((error) => {
                resolve(false);
            })
            .then(() => {
                setspinnerLoader(false);
            });
        });       
    };

    const formatCovDate = (dt) => {
		dt = new Date(dt);
		if (dt.toString() == "Invalid Date") {
			return dt;
		} else {
			return dateFnsFormat(dt, "MM/dd/yyyy");
		}
    };
    
    const handelDateRngeWithin = (rangeStartDate, rangeEndDate, withInStartDate, withInEndDate) => {
        if (rangeStartDate && rangeEndDate && withInStartDate && withInEndDate) {
			const range = moment().range(new Date(rangeStartDate), new Date(rangeEndDate));
            return range.contains(new Date(withInStartDate)) && range.contains(new Date(withInEndDate));
        }
        return false;
    }
    
    const handelDateRngeOverlap = (initalStartDate, initialEndDate, secondaryStartDate, secondaryEndDate) => {
        const range1 = moment().range(new Date(initalStartDate), new Date(initialEndDate));
        const range2 = moment().range(new Date(secondaryStartDate), new Date(secondaryEndDate));
        return range1.overlaps(range2);
    }

    const handelDateNetworkArrayOverlap = (initalStartDate, initialEndDate, networkId,networkstatus,typeCode, inputArray) => {
        if (inputArray.length > 0) {
            const result = inputArray.map(each => {
				if (handelDateRngeOverlap(initalStartDate, initialEndDate, each.beginDate, each.endDate)) {
					if (each.mapSetID == networkId && each.benefitPlanStatusNetworkCode == networkstatus && each.typeCode == typeCode && each.beginDate == initalStartDate) {
						return true
					}
					return false;
				}})
			if (result.filter(e => e === true).length > 0) {
				return true
			} else {
				return false;
			}
        } else {
            return false
        }
	}
	
	const handelDateRankArrayOverlap = (initalStartDate, initialEndDate, Rank, inputArray) => {
        if (inputArray.length > 0) {
			const result = inputArray.map(each => {
				if (handelDateRngeOverlap(initalStartDate, initialEndDate, each.beginDate, each.endDate)) {
					if (each.seqNum == Rank) {
						return true
					} 
					return false
				}})
			if (result.filter(e => e === true).length > 0) {
				return true
			} else {
				return false;
			}
        } else {
            return false
        }
    }

    const handelClick = async () => {
        let errors = {};
        let reqFieldArr = [];
        let overlapArray;
        if (editBenefitPlan.index > -1) {
            overlapArray = tableData.filter(
              (e) =>
                e.seqNum != editBenefitPlan.seqNum
            );
          } else {
            overlapArray = tableData;
          }
        setDeleteSuccess(false);
        const headerTange = await handelDateRngeWithin(formatDate(props.formValues.beginDate), formatDate(props.formValues.endDate), formatDate(editBenefitPlan.beginDate), formatDate(editBenefitPlan.endDate));
        const networkOverlap = await handelDateNetworkArrayOverlap(formatDate(editBenefitPlan.beginDate), formatDate(editBenefitPlan.endDate), editBenefitPlan.mapSetID, editBenefitPlan.benefitPlanStatusNetworkCode, editBenefitPlan.typeCode, overlapArray);
        const rankOverlap = await handelDateRankArrayOverlap(formatDate(editBenefitPlan.beginDate), formatDate(editBenefitPlan.endDate), editBenefitPlan.seqNum, overlapArray);
        
        let metExcnDesc = await validateExcCode(editBenefitPlan.metExceptionCode);
        let ovrExcnDesc = await validateExcCode(editBenefitPlan.overExceptionCode);
        let showFunctionalFieldErrValue= editBenefitPlan.benefitPlanEligFunctionalAreavalue == null ? "-1" : editBenefitPlan.benefitPlanEligFunctionalAreavalue;
        let showFunctionalFieldErr1Value= editBenefitPlan.benefitPlanNursFunctionalAreaValue == null ? "-1" : editBenefitPlan.benefitPlanNursFunctionalAreaValue;
        setShowError({
            showBeginDateError: editBenefitPlan.beginDate?false:(()=>{reqFieldArr.push(ErrorConst.Begin_Date_Error);return true;})(),
			showEndDateError: editBenefitPlan.endDate?false:(()=>{reqFieldArr.push(ErrorConst.End_Date_Error);return true;})(),      
			beginDtInvalidErr: formatDate(editBenefitPlan.beginDate).toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);return true;})():false,
			endDtInvalidErr: formatDate(editBenefitPlan.endDate).toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);return true;})():false,
            showNetworkStatusErr: editBenefitPlan.benefitPlanStatusNetworkCode == -1 ? (() => { reqFieldArr.push(ErrorConst.Network_Status_Error); return true })() : false,
            showFunctionalFieldErr: (editBenefitPlan.benefitPlanEligFunctionalAreaCode == -1 || editBenefitPlan.benefitPlanEligFunctionalAreaCode == null) && showFunctionalFieldErrValue != -1 ? (() => { reqFieldArr.push(ErrorConst.FUNCTIONAL_AREA_ERROR); return true })() : false,
            showFunctionalFieldErr1: (editBenefitPlan.benefitPlanNursFunctionalAreaCode == -1 || editBenefitPlan.benefitPlanNursFunctionalAreaCode == null)   && showFunctionalFieldErr1Value != -1 ? (() => { reqFieldArr.push(ErrorConst.FUNCTIONAL_AREA_ERROR1); return true })() : false,
            showValueFieldErr: (!(editBenefitPlan.benefitPlanNursFunctionalAreaCode == -1 || editBenefitPlan.benefitPlanNursFunctionalAreaCode == null) && (editBenefitPlan.benefitPlanNursFunctionalAreaValue == -1 || editBenefitPlan.benefitPlanNursFunctionalAreaValue == null)) ?
            (() => { reqFieldArr.push(ErrorConst.Value_Field_Error); 
                return true })() 
                : false,
            showValueFieldErr1: (!(editBenefitPlan.benefitPlanEligFunctionalAreaCode == -1 || editBenefitPlan.benefitPlanEligFunctionalAreaCode == null ) && (editBenefitPlan.benefitPlanEligFunctionalAreavalue == -1 || editBenefitPlan.benefitPlanEligFunctionalAreavalue == null) ) ?
                (() => { reqFieldArr.push(ErrorConst.Value_Field_Error1); 
                    return true })() 
                    : false,
          
            showmapSetIDErr: editBenefitPlan.mapSetID == -1 ? (() => { reqFieldArr.push(ErrorConst.Map_Id_Error); return true })() : false,
            showLimitTypeCodErr: editBenefitPlan.typeCode == -1 ? (() => { reqFieldArr.push(ErrorConst.TYPE_CODE); return true })() : false,
            showIndividualLimitErr: editBenefitPlan.indAmt ? false : (() => { reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT); return true })(),
            showIndLimInvErr:
            editBenefitPlan.indAmt && !isNaN(parseInt(editBenefitPlan.indAmt))
                ? false
                : (() => {
                    reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
                    return true;
                    })(),
            showIndPlusInvErr:
            editBenefitPlan.indPlusAmt &&
                isNaN(parseInt(editBenefitPlan.indPlusAmt))
                ? (() => {
                    reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
                    return true;
                    })()
                : false,
            showFamInvErr:
            editBenefitPlan.famAmt && isNaN(parseInt(editBenefitPlan.famAmt))
                ? (() => {
                    reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
                    return true;
                    })()
                : false,
                
            ShowLimitMetExcErr: editBenefitPlan.metExceptionCode ? false : (() => { reqFieldArr.push(ErrorConst.ShowLimitMetExcErr); return true })(),
            ShowLimitoverExcCodeErr: editBenefitPlan.overExceptionCode ? false : (() => { reqFieldArr.push(ErrorConst.LIMIT_MET_OVER_EXC_CODE); return true })(),
            ShowRankErr: editBenefitPlan.seqNum ? false : (() => { reqFieldArr.push(ErrorConst.Rank_Error); return true })(),
            showRankErrZero: editBenefitPlan.seqNum < 1 && editBenefitPlan.seqNum.length
             ? (() => {         
            reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
            return true;        
             })()
            : false,
            showRankOverlapErr: editBenefitPlan.beginDate && editBenefitPlan.endDate && editBenefitPlan.seqNum && rankOverlap ? (()=>{reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);return true;})() : false,
			showNetworkOverlapErr: editBenefitPlan.beginDate && editBenefitPlan.endDate && editBenefitPlan.mapSetID && editBenefitPlan.benefitPlanStatusNetworkCode && editBenefitPlan.typeCode && networkOverlap ? (()=>{reqFieldArr.push(ErrorConst.PLAN_LIMIT_NETWORK_MAP_OVERLAP);return true;})() : false,
            //showHeaderDateErr: !headerTange && editBenefitPlan.beginDate ? (()=>{reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk);return true;})() : false,
            showHeaderDateErr:
            !(new Date(editBenefitPlan.beginDate) >= new Date(props.formValues.beginDate) && new Date(editBenefitPlan.beginDate) <= new Date(props.formValues.endDate))
              ? (() => {
                  reqFieldArr.push(
                    ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                  );
                  return true;
                })()
              : false,
            showHeaderEndDateErr:
            !(new Date(editBenefitPlan.endDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                    ErrorConst.Fall_In_Header_End_Date_Err 
                );
                return true;
                })()
            : false,
            showBgdtGTEnddtErr: (new Date(editBenefitPlan.beginDate) <= new Date(editBenefitPlan.endDate))?false:(()=>{reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);return true;})(),  
            INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(editBenefitPlan.metExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE); return true; })(),
            INVALID_LMT_MET_EXC_CODE: editBenefitPlan.metExceptionCode ? (() => {
                if(!isSpecialcharecter(editBenefitPlan.metExceptionCode)){                     
                   if (!metExcnDesc) {                       
                       reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                       return true;
                   }else { return false; }                 
                
                }                 
               })() : false,
           INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(editBenefitPlan.overExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE); return true; })(),
           INVALID_LMT_OVR_EXC_CODE: editBenefitPlan.overExceptionCode ? (() => {
               if(!isSpecialcharecter(editBenefitPlan.overExceptionCode)){                     
                  if (!ovrExcnDesc) {                       
                   reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                      return true;
                  }else { return false; }                 
               
               }                 
              })() : false, 

        })

        if (reqFieldArr.length) {
            props.seterrorMessages(reqFieldArr);
            return false;
        }
        if (reqFieldArr.length) {
            setShowError(errors);
            props.seterrorMessages(reqFieldArr);
            return false;
        }

        let data = {
            "auditUserID": editBenefitPlan.auditUserID ? editBenefitPlan.auditUserID : "JavaUnitTesting",
            "addedAuditUserID": editBenefitPlan.addedAuditUserID ? editBenefitPlan.auditUserID : "JavaUnitTesting",
            "versionNo": editBenefitPlan.versionNo ? editBenefitPlan.versionNo : 0,
            "dbRecord": editBenefitPlan.dbRecord ? editBenefitPlan.dbRecord : false,
            "sortColumn": editBenefitPlan.sortColumn ? editBenefitPlan.sortColumn : null,
            "auditKeyList": editBenefitPlan.auditKeyList ? editBenefitPlan.auditKeyList : [],
            "auditKeyListFiltered": editBenefitPlan.auditKeyListFiltered ? editBenefitPlan.auditKeyListFiltered : false,
            "benefitPlanLimitID": editBenefitPlan.benefitPlanLimitID ? editBenefitPlan.benefitPlanLimitID : null,
            "benefitPlanStatusNetworkCode": editBenefitPlan.benefitPlanStatusNetworkCode && editBenefitPlan.benefitPlanStatusNetworkCode != "-1" ? editBenefitPlan.benefitPlanStatusNetworkCode : "",
            "beginDate": editBenefitPlan.beginDate ? editBenefitPlan.beginDate : "",
            "typeCode": editBenefitPlan.typeCode || editBenefitPlan.typeCode == "-1" ? editBenefitPlan.typeCode : "",
            "mapSetID": editBenefitPlan.mapSetID && editBenefitPlan.mapSetID != '-1' ? editBenefitPlan.mapSetID : "",
            "seqNum": editBenefitPlan.seqNum ? editBenefitPlan.seqNum : "",
            "overExceptionCode": editBenefitPlan.overExceptionCode ? editBenefitPlan.overExceptionCode : "",
            "metExceptionCode": editBenefitPlan.metExceptionCode ? editBenefitPlan.metExceptionCode : "",
            "endDate": editBenefitPlan.endDate ? editBenefitPlan.endDate : "",
            "indPlusAmt": editBenefitPlan.indPlusAmt ? editBenefitPlan.indPlusAmt : "0.00",
            "indAmt": editBenefitPlan.indAmt ? editBenefitPlan.indAmt : "0.00",
            "famAmt": editBenefitPlan.famAmt ? editBenefitPlan.famAmt : "0.00",
            "ctbckIndicator": editBenefitPlan.ctbckIndicator ? editBenefitPlan.ctbckIndicator : "",
            "saBYPSIndicator": editBenefitPlan.saBYPSIndicator ? editBenefitPlan.saBYPSIndicator : "",
            "metExcnDesc": metExcnDesc ? metExcnDesc : "",
            "ovrExcnDesc": ovrExcnDesc ? ovrExcnDesc : "",
            "bpNetworkCodeDesc": editBenefitPlan.bpNetworkCodeDesc ? editBenefitPlan.bpNetworkCodeDesc : "",
            "typeCodeDesc": editBenefitPlan.typeCodeDesc ? editBenefitPlan.typeCodeDesc : null,
            "benefitPlanEligFunctionalAreaCode": editBenefitPlan.benefitPlanEligFunctionalAreaCode &&  editBenefitPlan.benefitPlanEligFunctionalAreaCode!="-1" ? editBenefitPlan.benefitPlanEligFunctionalAreaCode : null,
            "benefitPlanNursFunctionalAreaCode": editBenefitPlan.benefitPlanNursFunctionalAreaCode && editBenefitPlan.benefitPlanNursFunctionalAreaCode!="-1" ? editBenefitPlan.benefitPlanNursFunctionalAreaCode : null,
            "benefitPlanEligFunctionalAreavalue": editBenefitPlan.benefitPlanEligFunctionalAreavalue && editBenefitPlan.benefitPlanEligFunctionalAreavalue !="-1" ? editBenefitPlan.benefitPlanEligFunctionalAreavalue : null,
            "benefitPlanNursFunctionalAreaValue": editBenefitPlan.benefitPlanNursFunctionalAreaValue &&  editBenefitPlan.benefitPlanNursFunctionalAreaValue !="-1"  ? editBenefitPlan.benefitPlanNursFunctionalAreaValue : null
        };
        editBenefitPlan.index > -1 ? tableData[editBenefitPlan.index] = editBenefitPlan : tableData.push(data);
        props.setNewBenefitPlantLimit(tableData);
        
        setbanifitPlan(false);
        setSuccessMessages([ErrorConst.SUCCESSFULLY_SAVED_INFORMATION]);
        props.seterrorMessages([]);
        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab: false });

    }


    const handelDeleteClick = () => {
        setSuccessMessages(false)
        const t = tableData;
        props.setbpLimitsDeleteItems?props.setbpLimitsDeleteItems([...props.bpLimitsDeleteItems, t[editBenefitPlan.index]]):null;
        t.splice(editBenefitPlan.index, 1);
        props.setNewBenefitPlantLimit(t);
        setDeleteSuccess(true);
        // setSuccessMessages([ErrorConst.SUCCESSFULLY_SAVED_INFORMATION]);
        setbanifitPlan(false);
        setbanifitPlan(false);
        setDialogOpen(false);
        setDialogType('');
    }

    const handelCandelFunction = () => {
        setbanifitPlan(false);
        setDialogOpen(false);
        setDialogType('');
    }

    const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
    const addBPPLscrolltoView = useRef(null);
    const PLBPscrolltoView = () => {
        setTimeout(function () {
            scrollToRef(addBPPLscrolltoView);
        }.bind(this), 500);
    };

    const addBenefitPlan = () => {
        if( props.majorValidations()){
        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab: true });
        setbanifitPlan(true);
        setDeleteSuccess(false);
        setEditBenefitPlan({
            beginDate: '',
            endDate: "12/31/9999",
            benefitPlanStatusNetworkCode: "-1",
            mapSetID: "-1",
            typeCode: "-1",
            indAmt: "",
            indPlusAmt: "",
            famAmt: "",
            metExceptionCode: "",
            overExceptionCode: "",
            seqNum: "",
            saBYPSIndicator: "0",
            ctbckIndicator: "0",
            benefitPlanEligFunctionalAreaCode: "-1",
            benefitPlanEligFunctionalAreavalue : "-1",
            benefitPlanNursFunctionalAreaCode : "-1",
            benefitPlanNursFunctionalAreaValue : "-1"
        });
        PLBPscrolltoView();
    }
    }
    const reload = () => {
        muiconfirm({
            title: "",
            description: "Changes you made may not be saved.",
            dialogProps: { fullWidth: false },
          }).then(() => {
            setspinnerLoader(true);
            setTimeout(function () {
                setspinnerLoader(false);
            }, 1000);
          });
    };


    const handelResetClick = () => {
        setSuccessMessages([]);
        props.seterrorMessages([]);
        setShowError(false);
        setEditBenefitPlan(resetBenefitPlan)
        setSelectedBeginDate(null);
        setSelectedEndDate("12/31/9999");       
        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab: false });

    };

    const multiDelete = () => {
        setDialogOpen(false); setDialogType('');
        props.seterrorMessages([]);
        setSuccessMessages([]);
        if (selectDeleteArray.length > 0) {
            let CI = props.benefitPlanLimit;
            selectDeleteArray.map((value, index) => {
              let curIndex = CI.findIndex(i => moment(i.beginDate).isSame(value.beginDate));
              CI.splice(curIndex,1);
            });
            props.setNewBenefitPlantLimit(CI);
            props.setbpLimitsDeleteItems(selectDeleteArray);
            setSelectDeleteArray([]);
            setDeleteSuccess(true);

        }
      }

      useImperativeHandle(ref, () => {
        return { validateFn };
      });
    
       const validateFn = () => {
        if (props.tabChangeValue.planLimitTab) {
          handelSaveValidations();
        } 
         }

         const  handelSaveValidations = async() => {
            let errors = {};
            let reqFieldArr = [];
            let overlapArray;
            if (editBenefitPlan.index > -1) {
                overlapArray = tableData.filter(
                  (e) =>
                    e.seqNum != editBenefitPlan.seqNum
                );
              } else {
                overlapArray = tableData;
              }
            setDeleteSuccess(false);
            const headerTange = await handelDateRngeWithin(formatDate(props.formValues.beginDate), formatDate(props.formValues.endDate), formatDate(editBenefitPlan.beginDate), formatDate(editBenefitPlan.endDate));
            const networkOverlap = await handelDateNetworkArrayOverlap(formatDate(editBenefitPlan.beginDate), formatDate(editBenefitPlan.endDate), editBenefitPlan.mapSetID, editBenefitPlan.benefitPlanStatusNetworkCode, editBenefitPlan.typeCode, overlapArray);
            const rankOverlap = await handelDateRankArrayOverlap(formatDate(editBenefitPlan.beginDate), formatDate(editBenefitPlan.endDate), editBenefitPlan.seqNum, overlapArray);
            
            let metExcnDesc = await validateExcCode(editBenefitPlan.metExceptionCode);
            let ovrExcnDesc = await validateExcCode(editBenefitPlan.overExceptionCode);
            setShowError({
                showBeginDateError: editBenefitPlan.beginDate?false:(()=>{reqFieldArr.push(ErrorConst.Begin_Date_Error);return true;})(),
                showEndDateError: editBenefitPlan.endDate?false:(()=>{reqFieldArr.push(ErrorConst.End_Date_Error);return true;})(),      
                beginDtInvalidErr: formatDate(editBenefitPlan.beginDate).toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);return true;})():false,
                endDtInvalidErr: formatDate(editBenefitPlan.endDate).toString() == "Invalid Date"?(()=>{reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);return true;})():false,
                showNetworkStatusErr: editBenefitPlan.benefitPlanStatusNetworkCode == -1 ? (() => { reqFieldArr.push(ErrorConst.Network_Status_Error); return true })() : false,
                showFunctionalFieldErr: editBenefitPlan.benefitPlanEligFunctionalAreaCode == null ? (() => { reqFieldArr.push(ErrorConst.FUNCTIONAL_AREA_ERROR); return true })() : false,
                showFunctionalFieldErr1: editBenefitPlan.benefitPlanNursFunctionalAreaCode == null ? (() => { reqFieldArr.push(ErrorConst.FUNCTIONAL_AREA_ERROR1); return true })() : false,
                showValueFieldErr: (!(editBenefitPlan.benefitPlanNursFunctionalAreaCode == -1 || editBenefitPlan.benefitPlanNursFunctionalAreaCode == null) && (editBenefitPlan.benefitPlanNursFunctionalAreaValue == -1 || editBenefitPlan.benefitPlanNursFunctionalAreaValue == null)) ?
                (() => { reqFieldArr.push(ErrorConst.Value_Field_Error); 
                    return true })() 
                    : false,
                showValueFieldErr1: (!(editBenefitPlan.benefitPlanEligFunctionalAreaCode == -1 || editBenefitPlan.benefitPlanEligFunctionalAreaCode == null ) && (editBenefitPlan.benefitPlanEligFunctionalAreavalue == -1 || editBenefitPlan.benefitPlanEligFunctionalAreavalue == null) ) ?
                    (() => { reqFieldArr.push(ErrorConst.Value_Field_Error1); 
                        return true })() 
                        : false,
              
                showmapSetIDErr: editBenefitPlan.mapSetID == -1 ? (() => { reqFieldArr.push(ErrorConst.Map_Id_Error); return true })() : false,
                showLimitTypeCodErr: editBenefitPlan.typeCode == -1 ? (() => { reqFieldArr.push(ErrorConst.TYPE_CODE); return true })() : false,
                showIndividualLimitErr: editBenefitPlan.indAmt ? false : (() => { reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT); return true })(),
                showIndLimInvErr:
                editBenefitPlan.indAmt && !isNaN(parseInt(editBenefitPlan.indAmt))
                    ? false
                    : (() => {
                        reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
                        return true;
                        })(),
                showIndPlusInvErr:
                editBenefitPlan.indPlusAmt &&
                    isNaN(parseInt(editBenefitPlan.indPlusAmt))
                    ? (() => {
                        reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
                        return true;
                        })()
                    : false,
                showFamInvErr:
                editBenefitPlan.famAmt && isNaN(parseInt(editBenefitPlan.famAmt))
                    ? (() => {
                        reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
                        return true;
                        })()
                    : false,
                ShowLimitMetExcErr: editBenefitPlan.metExceptionCode ? false : (() => { reqFieldArr.push(ErrorConst.ShowLimitMetExcErr); return true })(),
                ShowLimitoverExcCodeErr: editBenefitPlan.overExceptionCode ? false : (() => { reqFieldArr.push(ErrorConst.LIMIT_MET_OVER_EXC_CODE); return true })(),
                ShowRankErr: editBenefitPlan.seqNum ? false : (() => { reqFieldArr.push(ErrorConst.Rank_Error); return true })(),
                showRankErrZero: editBenefitPlan.seqNum < 1 && editBenefitPlan.seqNum.length
                ? (() => {         
                reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
                return true;        
                })()
          : false,
                showRankOverlapErr: editBenefitPlan.beginDate && editBenefitPlan.endDate && editBenefitPlan.seqNum && rankOverlap ? (()=>{reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);return true;})() : false,
                showNetworkOverlapErr: editBenefitPlan.beginDate && editBenefitPlan.endDate && editBenefitPlan.mapSetID && editBenefitPlan.benefitPlanStatusNetworkCode && editBenefitPlan.typeCode && networkOverlap ? (()=>{reqFieldArr.push(ErrorConst.PLAN_LIMIT_NETWORK_MAP_OVERLAP);return true;})() : false,
                //showHeaderDateErr: !headerTange && editBenefitPlan.beginDate ? (()=>{reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk);return true;})() : false,
                showHeaderDateErr:
                    !(new Date(editBenefitPlan.beginDate) >= new Date(props.formValues.beginDate) && new Date(editBenefitPlan.beginDate) <= new Date(props.formValues.endDate))
                        ? (() => {
                            reqFieldArr.push(
                                ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                            );
                            return true;
                        })()
                        : false,
                showHeaderEndDateErr:
                    !(new Date(editBenefitPlan.endDate) <= new Date(props.formValues.endDate))
                        ? (() => {
                            reqFieldArr.push(
                                ErrorConst.Fall_In_Header_End_Date_Err
                            );
                            return true;
                        })()
                        : false,

                showBgdtGTEnddtErr: (new Date(editBenefitPlan.beginDate) <= new Date(editBenefitPlan.endDate))?false:(()=>{reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);return true;})(),  
                INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(editBenefitPlan.metExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE); return true; })(),
                INVALID_LMT_MET_EXC_CODE: editBenefitPlan.metExceptionCode ? (() => {
                    if(!isSpecialcharecter(editBenefitPlan.metExceptionCode)){                     
                       if (!metExcnDesc) {                       
                           reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                           return true;
                       }else { return false; }                 
                    
                    }                 
                   })() : false,
               INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(editBenefitPlan.overExceptionCode) ? false : (() => { reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE); return true; })(),
               INVALID_LMT_OVR_EXC_CODE: editBenefitPlan.overExceptionCode ? (() => {
                   if(!isSpecialcharecter(editBenefitPlan.overExceptionCode)){                     
                      if (!ovrExcnDesc) {                       
                       reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                          return true;
                      }else { return false; }                 
                   
                   }                 
                  })() : false, 
    
            })
    
            if (reqFieldArr.length) {
                props.seterrorMessages(reqFieldArr);
                return false;
            }
            if (reqFieldArr.length) {
                setShowError(errors);
                props.seterrorMessages(reqFieldArr);
                return false;
            }
         }


    return (
        <div>
            <Dialog
                open={dialogOpen}
                onClose={() => { setDialogOpen(false); setDialogType('') }}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                className="custom-alert-box"
            >
               <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {dialogType == "Delete" || dialogType == "multiDelete"
              ? "Are you sure that you want to Delete."
              : dialogType == "Cancel" 
              ? "Changes you made may not be saved." : ""}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
            <Button title="Ok" onClick={() => {
              dialogType == "Delete"
                ? handelDeleteClick() :
              dialogType == "multiDelete"
                ? multiDelete()
              : handelCandelFunction();
            }} color="primary" className="btn btn-success">
                Ok
            </Button>
            <Button title="Cancel"  onClick={() => { setDialogOpen(false); setDialogType(''); }} color="primary" autoFocus>
                Cancel
            </Button>
        </DialogActions>
       </Dialog>
            {spinnerLoader ? <Spinner /> : null}           
                  
            
            {successMessages.length > 0 ? (
                <div className="alert alert-success custom-alert" role="alert">
                    {successMessages.map(message => <li>{message}</li>)
                    }
                </div>
            ) : null
            }     
            {deleteSuccess ? (
                <div className="alert alert-success custom-alert" role="alert">
                    {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
                </div>
            ) : null}

            <div className="tabs-container pt-2">
                <div className="tab-header">
                    <h3 className="tab-heading float-left">
                        Benefit Plan - Plan Limits
                    </h3>
                    <div className="float-right th-btnGroup">
                    <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => {setDialogOpen(true); setDialogType('multiDelete');}}>
                          <i className="fa fa-trash" />

                        </Button>
                        <Button
                            title="Add Plan Limits"
                            variant="outlined"
                            color="primary"
                            className="btn btn-secondary btn-icon-only"
                            onClick={addBenefitPlan}
                        >
                            <i className="fa fa-plus" />

                        </Button>
                    </div>
                    <div className="clearfix" />
                </div>

                <div className="tab-holder mt-2">
                    <TableComponent multiDelete selected={selectDeleteArray} setSelected={setSelectDeleteArray} headCells={headCells} tableData={getTableData(tableData)} onTableRowClick={editRow} PLBPscrolltoView={PLBPscrolltoView}/>                   
                </div>


                {banifitPlan ? (
                    <div>
                        <div className="tabs-container tabs-container-inner mt-0" ref={addBPPLscrolltoView}>
                            <div className="tab-header">
                                <h3 className="tab-heading float-left">
                                    {editBenefitPlan.index > -1 ? "Edit Plan Limit" : "New Plan Limit"} 
                                </h3>

                                <div className="float-right th-btnGroup">
                                    <Button
                                        title={editBenefitPlan.index > -1 ? "Update" : "Add"}
                                        variant="outlined"
                                        color="primary"
                                        className={editBenefitPlan.index > -1 ? "btn btn-ic btn-save" : "btn btn-ic btn-add"}
                                        onClick={() => handelClick()}
                                        disabled={props.privileges && !props.privileges.add? 'disabled':'' }
                                    >
                                        {editBenefitPlan.index > -1 ? "Update" : "Add"}
                                    </Button>
                                    {editBenefitPlan.index > -1 ?
                                     <Link to="MapDefinition" target="_blank" title="View/Edit Map" className="btn btn-ic btn-view">
                                        View/Edit Map 
                                     </Link>
                                    
                                    : null}
                                    {editBenefitPlan.index > -1 ?
                                    <Button title="View/Edit Map" color="primary" className="btn btn-ic btn-view" onClick={() =>{reload()}}>
                                        View/Edit COE List</Button>
                                    : null}
                                    {editBenefitPlan.index > -1 ?
                                    <Button title="View/Edit Map" color="primary" className="btn btn-ic btn-view" onClick={() =>{reload()}}>
                                        View/Edit NF Span Type List</Button>
                                    : null}
                                    {editBenefitPlan.index > -1 ?
                                        <Button
                                            title="Delete"
                                            variant="outlined"
                                            color="primary"
                                            className="btn btn-ic btn-delete"
                                            onClick={() => { setDialogOpen(true); setDialogType('Delete') }}
                                        >
                                            Delete
									</Button>
                                        : null}
                                    <Button
                                        title="Reset"
                                        variant="outlined"
                                        color="primary"
                                        className="btn btn-ic btn-reset"
                                        onClick={() => handelResetClick()}
                                    >
                                        Reset
									</Button>
                                    <Button
                                        title="Cancel"
                                        variant="outlined"
                                        color="primary"
                                        className="btn btn-cancel"
                                        onClick={() => { setDialogOpen(true); setDialogType('Cancel');
                                        props.setTabChangeValue({ ...props.tabChangeValue, planLimitTab: false });

                                     }}
                                    >
                                        Cancel
									</Button>
                                </div>
                            </div>
                        </div>


                        <div className="tabs-container tabs-container-inner mt-0">
                            {/* <div className="tab-header">
                                <h1 className="tab-heading float-left">
                                    New Plan Limits
                                </h1>
                                <div className="clearfix" />
                            </div> */}

                            <div className="tab-body-bordered mt-2">
                                <div className="form-wrapper">
                                    <div className="flex-block">
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    required
                                                    id="begin_date_network_plan_limit_tab"
                                                    label="Begin Date"
                                                    name="beginDate"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={selectedBeginDate}                                                    
                                                    onChange={handleBeginDateChange}                                                   
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                    helperText={
                                                        showHeaderDateErr
                                                            ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                                                            : showBeginDateError
                                                                ? ErrorConst.BEGIN_DATE_ERROR
                                                                : beginDtInvalidErr
                                                                    ? ErrorConst.Invalid_Begin_Date_Error
                                                                    : showBgdtGTEnddtErr
                                                                        ? ErrorConst.DATE_RANGE_ERROR
                                                                        : null
                                                    }
                                                    error={
                                                        showHeaderDateErr
                                                            ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                                                            : showBeginDateError
                                                                ? ErrorConst.BEGIN_DATE_ERROR
                                                                : beginDtInvalidErr
                                                                    ? ErrorConst.Invalid_Begin_Date_Error
                                                                    : showBgdtGTEnddtErr
                                                                        ? ErrorConst.DATE_RANGE_ERROR
                                                                        : null
                                                    }
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    required
                                                    id="end_date_network_plan_limit_tab"
                                                    name="endDate"
                                                    label="End Date"
                                                    format="MM/dd/yyyy"
                                                     
							                        maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={selectedEndDate ? selectedEndDate : ""}
                                                    onChange={handleEndDateChange}
                                                    maxDate={new Date('9999-12-31T13:00:00.000+0000')}                                                   
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                    helperText={
                                                        showEndDateError
                                                            ? ErrorConst.End_Date_Error
                                                            : showHeaderEndDateErr
                                                            ? ErrorConst.Fall_In_Header_End_Date_Err
                                                            : null
                                                    }
                                                    error={
                                                        showEndDateError
                                                            ? ErrorConst.End_Date_Error
                                                            : showHeaderEndDateErr
                                                            ? ErrorConst.Fall_In_Header_End_Date_Err
                                                            : null
                                                    }

                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>

                                    </div>

                                    <div className="flex-block">
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="network_status_network_plan_limit_tab"
                                                select
                                                name="benefitPlanStatusNetworkCode"
                                                label="Network Status"
                                                value={editBenefitPlan.benefitPlanStatusNetworkCode ? editBenefitPlan.benefitPlanStatusNetworkCode : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={event => handelInputChange(event)}
                                                placeholder=""
                                                helperText={showNetworkStatusErr ? ErrorConst.Network_Status_Error : null}
                                                error={showNetworkStatusErr ? ErrorConst.Network_Status_Error : null}
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                            >
                                                <MenuItem value="-1" key="networkid">Please Select One</MenuItem>
                                                {props.dropdowns && props.dropdowns['R1#R_BP_NW_STAT_CD'] && props.dropdowns['R1#R_BP_NW_STAT_CD'].map(each => (
                                                    <MenuItem key={each.code} value={each.code}>{each.description}</MenuItem>
                                                ))}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="map_id_network_plan_limit_tab"
                                                select
                                                name="mapSetID"
                                                label="Map ID"
                                                value={editBenefitPlan.mapSetID ? editBenefitPlan.mapSetID : "=1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={event => handelInputChange(event)}
                                                placeholder=""
                                                helperText={showmapSetIDErr ? ErrorConst.Map_Id_Error : null}
                                                error={showmapSetIDErr ? ErrorConst.Map_Id_Error :null}
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                            >
                                                <MenuItem key="mapsetidselect" value="-1">Please Select One</MenuItem>
                                                {props.mapIdDropdown && props.mapIdDropdown.map(each => (
                                                    <MenuItem key={each.mapsetId} value={each.mapsetId}>{each.mapsetId}-{each.mapDesc}</MenuItem>
                                                ))}
                                            </TextField>
                                        </div>

                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="limit_type_code_network_plan_limit_tab"

                                                select
                                                label="Limit Type Code"
                                                name="typeCode"
                                                placeholder=""
                                                value={editBenefitPlan.typeCode ? editBenefitPlan.typeCode : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={event => handelInputChange(event)}
                                                helperText={showLimitTypeCodErr ? ErrorConst.TYPE_CODE : null}
                                                error={showLimitTypeCodErr ? ErrorConst.TYPE_CODE : null}
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                            >

                                                <MenuItem key="limittypecode" value="-1">Please Select One</MenuItem>
                                                {props.dropdowns && props.dropdowns['Reference#R_BP_LMT_TY_CD'] && props.dropdowns['Reference#R_BP_LMT_TY_CD'].map(each => (
                                                    <MenuItem key={each.code} value={each.code}>{each.description}</MenuItem>
                                                ))}

                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="Start">$ </InputAdornment>,
                                                }}
                                                id="individual_limit_network_plan_limit_tab"
                                                required
                                                label="Individual Limit"
                                                name="indAmt"
                                                type="text"
                                                value={editBenefitPlan.indAmt}
                                                inputProps={{ maxLength: 14 }}
                                                onChange={event => handelInputChange(event)} placeholder=" Please Enter"
                                                helperText={showIndividualLimitErr ? ErrorConst.INDIVIDUAL_LIMIT 
                                                    : showIndLimInvErr
                                                    ? ErrorConst.INVALID_IND_LIMIT
                                                    : null}
                                                error={showIndividualLimitErr ? ErrorConst.INDIVIDUAL_LIMIT 
                                                    : showIndLimInvErr
                                                    ? ErrorConst.INVALID_IND_LIMIT
                                                    : null}

                                            >

                                            </TextField>
                                        </div>

                                    </div>


                                    <div className="flex-block">
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="indi_plus_limit_network_plan_limit_tab"
                                                label="Individual +1 Limit"
                                                name="indPlusAmt"
                                                type="text"
                                                value={editBenefitPlan.indPlusAmt}
                                                inputProps={{ maxLength: 14 }}
                                                onChange={event => handelInputChange(event)} placeholder=" Please Enter"                                               
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="Start">$ </InputAdornment>,
                                                }}
                                                helperText={
                                                    showIndPlusInvErr
                                                      ? ErrorConst.INVALID_IND_PLUS_LIMIT
                                                      : null
                                                  }
                                                  error={showIndPlusInvErr}
                                            >

                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="family_limit_network_plan_limit_tab"
                                                label="Family Limit"
                                                type="text"
                                                name="famAmt"
                                                value={editBenefitPlan.famAmt}
                                                inputProps={{ maxLength: 14 }}
                                                onChange={event => handelInputChange(event)} placeholder=" Please Enter"                                                
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="Start">$ </InputAdornment>,
                                                }}
                                                helperText={
                                                    showFamInvErr ? ErrorConst.INVALID_IND_FAM_LIMIT : null
                                                }
                                                error={showFamInvErr}
                                            >

                                            </TextField>
                                        </div>

                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="limit_met_network_plan_limit_tab"
                                                required
                                                label="Limit Met Exc Code"
                                                name="metExceptionCode"
                                                value={editBenefitPlan.metExceptionCode}
                                                inputProps={{ maxLength: 4 }}
                                                onChange={event => handelInputChange(event)} placeholder="Please Enter"
                                                helperText={ShowLimitMetExcErr ? ErrorConst.LIMIT_MET_EXC_CODE :
                                                     INVALID_LMT_MET_EXC_CODE? ErrorConst.INVALID_LMT_MET_EXC_CODE:INVALID_LMT_MET_EXC_CODE_SPL ? ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE : null}
                                                error={ShowLimitMetExcErr || INVALID_LMT_MET_EXC_CODE || INVALID_LMT_MET_EXC_CODE_SPL}
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                            >

                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="limit_over_network_plan_limit_tab"
                                                required
                                                label="Limit Over Exc Code"
                                                name="overExceptionCode"
                                                value={editBenefitPlan.overExceptionCode}
                                                inputProps={{ maxLength: 4 }}
                                                onChange={event => handelInputChange(event)} placeholder="Please Enter"
                                                helperText={ShowLimitoverExcCodeErr ? ErrorConst.LIMIT_MET_OVER_EXC_CODE : 
                                                    INVALID_LMT_OVR_EXC_CODE? ErrorConst.INVALID_LMT_OVR_EXC_CODE : INVALID_LMT_OVR_EXC_CODE_SPE ? ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE : null}
                                                error={ShowLimitoverExcCodeErr || INVALID_LMT_OVR_EXC_CODE || INVALID_LMT_OVR_EXC_CODE_SPE}

                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                            >

                                            </TextField>
                                        </div>

                                    </div>


                                    <div className="flex-block">
                                        <div className="mui-custom-form with-select input-md">


                                            <TextField
                                                id="rank_network_plan_limit_tab"
                                                type="text"
                                                required
                                                label="Rank"
                                                name="seqNum"
                                                value={editBenefitPlan.seqNum}
                                                inputProps={{ maxLength: 6 }}
                                                onChange={event => handelInputChange(event)}
                                                placeholder="Please Enter"
                                                helperText={ShowRankErr ? ErrorConst.Rank_Error :
                                                           showRankOverlapErr ? ErrorConst.RANK_TABLE_OVERLAP : 
                                                           showRankErrZero?ErrorConst.BENEFIT_PLAN_RANKING_ZERO:null}
                                                error={ShowRankErr ? ErrorConst.Rank_Error : 
                                                      showRankOverlapErr ? ErrorConst.RANK_TABLE_OVERLAP :
                                                      showRankErrZero?ErrorConst.BENEFIT_PLAN_RANKING_ZERO:null}
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                            >

                                            </TextField>
                                        </div>

                                        <div className="mui-custom-form">
                                            <label className="MuiFormLabel-root MuiInputLabel-shrink"><span className="MuiFormLabel-asterisk MuiInputLabel-asterisk">*</span> Cutback </label>
                                            <div className="sub-radio mt-1">
                                            <RadioGroup
                                                row
                                                aria-label="gender"
                                                name="ctbckIndicator"
                                                onChange={handelInputChange}
                                            >
                                                <FormControlLabel
                                                    id="cutback_yes_network_plan_limit_tab"
                                                    checked={editBenefitPlan.ctbckIndicator == '1' ? true : false}
                                                    value="1"
                                                    control={<Radio color="primary" />}
                                                    label="Yes"
                                                />

                                                <FormControlLabel
                                                    id="cutback_no_network_plan_limit_tab"
                                                    value="0"
                                                    checked={editBenefitPlan.ctbckIndicator == '0' ? true : false}
                                                    control={<Radio color="primary" />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                            </div>
                                        </div>

                                        <div className="mui-custom-form">
                                            <label className="MuiFormLabel-root MuiInputLabel-shrink"><span className="MuiFormLabel-asterisk MuiInputLabel-asterisk">*</span> Bypass if SA </label>
                                            <div className="sub-radio mt-1">
                                            <RadioGroup
                                                row
                                                aria-label="gender"
                                                name="saBYPSIndicator"
                                                onChange={handelInputChange}
                                            >
                                                <FormControlLabel
                                                    id="bypaas_yes_network_plan_limit_tab"
                                                    value="1"
                                                    checked={editBenefitPlan.saBYPSIndicator == '1' ? true : false}
                                                    control={<Radio color="primary" />}
                                                    label="Yes"
                                                />

                                                <FormControlLabel
                                                    id="bypass_no_network_plan_limit_tab"
                                                    value="0"
                                                    checked={editBenefitPlan.saBYPSIndicator == '0' ? true : false}
                                                    control={<Radio color="primary" />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div className="tabs-container tabs-container-inner mt-0 mb-3">
                                    <div className="tab-header">
                                        <h3 className="tab-heading float-left">
                                            Bypass If category of Eligibilty in List
                                        </h3>
                                        <div className="clearfix" />
                                    </div>
                                    <div className="tab-body mt-2">
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form with-select input-md">
                                                <TextField
                                                    id="func_area_bypaas_categoty_plan_limit_tab"
                                                    label="Functional Area"
                                                    select
                                                    name="benefitPlanEligFunctionalAreaCode"
                                                    onChange={event => { handelInputChange(event);}}
                                                    value={editBenefitPlan.benefitPlanEligFunctionalAreaCode?editBenefitPlan.benefitPlanEligFunctionalAreaCode:"-1"}
                                                    inputProps={{ maxLength: 2 }}                                                    
                                                    placeholder="Please Select One"  
                                                    helperText={showFunctionalFieldErr ? ErrorConst.FUNCTIONAL_AREA_ERROR : null}
                                                    error={showFunctionalFieldErr? ErrorConst.FUNCTIONAL_AREA_ERROR : null}                                                 
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                >
                                                    <MenuItem value="-1">Please Select One</MenuItem>
                                                    {props.dropdowns && props.dropdowns['Reference#R_FUNC_AREA_CD'] && props.dropdowns['Reference#R_FUNC_AREA_CD'].map(each => (
                                                        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                                    ))}

                                                </TextField>
                                            </div>

                                            <div className="mui-custom-form with-select input-md">
                                                <TextField
                                                    id="value_bypaas_categoty_plan_limit_tab"
                                                    label="Value"
                                                    select
                                                    name="benefitPlanEligFunctionalAreavalue"
                                                    value={editBenefitPlan.benefitPlanEligFunctionalAreavalue?editBenefitPlan.benefitPlanEligFunctionalAreavalue:"-1"}
                                                    inputProps={{ maxLength: 2 }}
                                                    onChange={event => handelInputChange(event)}
                                                    placeholder="Please Select One"                                                   
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    helperText={showValueFieldErr1 ? ErrorConst.Value_Field_Error1 : null}
                                                    error={showValueFieldErr1? ErrorConst.Value_Field_Error1 : null}                                                
                                                  
                                                >
                                                    <MenuItem value="-1">Please Select One</MenuItem>
                                                    {valuesForCat.map(each => (
                                                        <MenuItem selected key={each} value={each}>{each}</MenuItem>
                                                    ))}
                                                </TextField>
                                            </div>
                                        </div>
                                    </div>
                                </div>



                                <div className="tabs-container tabs-container-inner mt-0 mb-3">
                                    <div className="tab-header">
                                        <h3 className="tab-heading float-left">
                                            Bypass If Nursing Facility Span Type in List
                                        </h3>
                                        <div className="clearfix" />
                                    </div>
                                    <div className="tab-body mt-2">
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form with-select input-md">
                                             
                                                <TextField
                                                    id="func_area_bypaas_nursing_plan_limit_tab"
                                                    label="Functional Area"
                                                    select
                                                    name="benefitPlanNursFunctionalAreaCode"
                                                    onChange={event => { handelInputChange(event);}}
                                                    value={editBenefitPlan.benefitPlanNursFunctionalAreaCode?editBenefitPlan.benefitPlanNursFunctionalAreaCode:"-1"}
                                                    inputProps={{ maxLength: 2 }}                                                    
                                                    placeholder="Please Select One" 
                                                    helperText={showFunctionalFieldErr1 ? ErrorConst.FUNCTIONAL_AREA_ERROR1 : null}
                                                    error={showFunctionalFieldErr1? ErrorConst.FUNCTIONAL_AREA_ERROR1: null}                                                                                                   
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                >
                                                    <MenuItem value="-1">Please Select One</MenuItem>
                                                    {props.dropdowns && props.dropdowns['Reference#R_FUNC_AREA_CD'] && props.dropdowns['Reference#R_FUNC_AREA_CD'].map(each => (
                                                        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                                    ))}
                                                </TextField>
                                            </div>

                                            <div className="mui-custom-form with-select input-md">
                                                <TextField
                                                    id="value_bypaas_nursing_plan_limit_tab"
                                                    label="Value"
                                                    select
                                                    name="benefitPlanNursFunctionalAreaValue"
                                                    value={editBenefitPlan.benefitPlanNursFunctionalAreaValue?editBenefitPlan.benefitPlanNursFunctionalAreaValue:"-1"}
                                                    inputProps={{ maxLength: 2 }}
                                                    onChange={event => handelInputChange(event)} 
                                                    placeholder="Please Select One"  
                                                    helperText={showValueFieldErr ? ErrorConst.Value_Field_Error : null}
                                                    error={showValueFieldErr ? ErrorConst.Value_Field_Error : null}                                                
                                                    InputLabelProps={{
                                                        shrink: true
                                        
                                                    }}
                                                >
                                                    <MenuItem value="-1">Please Select One</MenuItem>
                                                    {valuesForN.map(each => (
                                                        <MenuItem selected key={each} value={each}>{each}</MenuItem>
                                                    ))}

                                                </TextField>
                                            </div>
                                        </div>
                                    </div>
                                </div>


                            </div>





                        </div>


                    </div>
                ) : null}

            </div>
        </div>
    )

}
export default forwardRef(BenefitPlanLimits);