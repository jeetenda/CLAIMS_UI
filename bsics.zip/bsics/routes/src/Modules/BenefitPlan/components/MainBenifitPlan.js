import React, {
  useState,
  useEffect,
  useRef,
  forwardRef,
  useImperativeHandle,
} from "react";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import Axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import * as moment from "moment";
import "moment-range";
import DateFnsUtils from "@date-io/date-fns";
import dateFnsFormat from "date-fns/format";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from "@material-ui/pickers";
import AppBar from "@material-ui/core/AppBar";
import TabPanel from "../../../SharedModules/TabPanel/TabPanel";
import { withRouter } from "react-router";
import { makeStyles } from "@material-ui/core/styles";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import { Button } from "react-bootstrap";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
/*tabel component import */
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import BenfitTabelComponent from "./BenfitTabelComponent";
import BenefitPlanCapitation from "./BenefitPlanCapitation";
import { Link } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}));

function MainbenifitPlan(props, ref) {
  const classes = useStyles();
  const [banifitPlan, setbanifitPlan] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [success, setSuccess] = useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);
  const capitationTabRef = useRef();
  // const [
  //   {
  //     networkDelete,
  //     providerDelete
  //   },setDeleteSuccess,
  // ] = React.useState(false);
  const [deleteSuccess, setDeleteSuccess] = useState(false);

  const [newProviderDate, setnewProviderDate] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    netWorkId: "-1",
    netWorkStatus: "-1",
    rank: "",
    netWorkSateDesc: "",
  });

  const [resetProviderDate, setresetProviderDate] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    netWorkId: "-1",
    netWorkStatus: "-1",
    rank: "",
    netWorkSateDesc: "",
  });

  //webninja
  const [
    {
      showHeaderDateErr,
      showBeginDateError,
      showEndDateError,
      beginDtInvalidErr,
      endDtInvalidErr,
      showRankOverlapErr,
      showNetworkOverlapErr,
      networkIDError,
      networkStatusError,
      rankError,
      showRankErrSpe,
      showRankErrZero,
      showBgdtGTEnddtErr,
      RankErr,
      showHeaderBeginDateErr,
      showHeaderEndDateErr,
    },
    setShowError,
  ] = React.useState(false);

  const [successMessages, setSuccessMessages] = React.useState([]);

  //webninja
  const formatDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const handelInputChange = (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, mainTab: true });
    if (event.target.name === "netWorkStatus") {
      setnewProviderDate({
        ...newProviderDate,
        [event.target.name]: event.target.value,
        netWorkSateDesc: event.nativeEvent.target.textContent,
      });
    } else {
      setnewProviderDate({
        ...newProviderDate,
        [event.target.name]: event.target.value,
      });
    }
  };
  const handelDateChange = (type, name) => (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, mainTab: true });
    if (type === "setnewProviderDate") {
      setnewProviderDate({ ...newProviderDate, [name]: date });
    }
  };

  const handelDateRngeWithin = (
    rangeStartDate,
    rangeEndDate,
    withInStartDate,
    withInEndDate
  ) => {
    if (rangeStartDate && rangeEndDate && withInStartDate && withInEndDate) {
      const range = moment().range(
        new Date(rangeStartDate),
        new Date(rangeEndDate)
      );
      return (
        range.contains(new Date(withInStartDate)) &&
        range.contains(new Date(withInEndDate))
      );
    }
    return false;
  };

  const handelDateRngeOverlap = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate
  ) => {
    const range1 = moment().range(
      new Date(initalStartDate),
      new Date(initialEndDate)
    );
    const range2 = moment().range(
      new Date(secondaryStartDate),
      new Date(secondaryEndDate)
    );
    return range1.overlaps(range2);
  };

  const handelDateNetworkArrayOverlap = (
    initalStartDate,
    initialEndDate,
    networkId,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.nwEndDate
          )
        ) {
          if (each.nwID == networkId && each.beginDate == initalStartDate) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRankArrayOverlap = (
    initalStartDate,
    initialEndDate,
    Rank,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.nwEndDate
          )
        ) {
          if (each.seqNum == Rank) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelClick = async () => {
    const tableData = props.newState;
    //webninja
    setSuccess(false);
    //setDeleteSuccess({networkDelete:false,providerDelete:false});
    setDeleteSuccess(false);
    props.seterrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newProviderDate.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetProviderDate.beginDate) ||
          e.nwEndDate != formatDate(resetProviderDate.endDate)
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newProviderDate.beginDate),
      formatDate(newProviderDate.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newProviderDate.beginDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.netWorkId,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newProviderDate.beginDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.rank,
      overlapArray
    );
    setShowError({
      showBeginDateError: newProviderDate.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newProviderDate.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        formatDate(newProviderDate.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newProviderDate.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
      networkIDError:
        newProviderDate.netWorkId && newProviderDate.netWorkId != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_ID_Error);
              return true;
            })(),
      networkStatusError:
        newProviderDate.netWorkStatus && newProviderDate.netWorkStatus != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      // rankError: newProviderDate.rank
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.Rank_Error);
      //       return true;
      //     })(),
      showRankErrSpe: !isNaN(parseInt(newProviderDate.rank))
        ? false
        : (() => {
            if (newProviderDate.rank.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
      showRankErrZero:
        newProviderDate.rank < 1 && newProviderDate.rank.length
          ? (() => {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
              return true;
            })()
          : false,
      rankError:
        newProviderDate.rank.length < 1
          ? (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })()
          : false,

      showHeaderBeginDateErr: !(
        new Date(newProviderDate.beginDate) >=
          new Date(props.formValues.beginDate) &&
        new Date(newProviderDate.beginDate) <=
          new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(
              ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
            );
            return true;
          })()
        : false,

      showHeaderEndDateErr: !(
        new Date(newProviderDate.endDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(ErrorConst.Fall_In_Header_End_Date_Err);
            return true;
          })()
        : false,
      // End header date error
      showBgdtGTEnddtErr:
        new Date(newProviderDate.beginDate) <= new Date(newProviderDate.endDate)
          ? false
          : (() => {
              //reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              reqFieldArr.push(ErrorConst.Date_Range_Error);
              return true;
            })(),
      showNetworkOverlapErr:
        newProviderDate.beginDate &&
        newProviderDate.endDate &&
        newProviderDate.netWorkId &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.NETWORK_TABLE_OVERLAP);
              return true;
            })()
          : false,
      showRankOverlapErr:
        newProviderDate.beginDate &&
        newProviderDate.endDate &&
        newProviderDate.rank &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,
    });
    props.setShowError({
      planBeginDateError: props.formValues.beginDate ? false : true,
      planEndDateError: props.formValues.endDate ? false : true,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    const data = {
      auditUserID: "wf_NH_MC_BP_SETUPV99",
      auditTimeStamp: "2013-01-31T00:23:48.000+0000",
      addedAuditUserID: "wf_NH_MC_BP_SETUPV99",
      addedAuditTimeStamp: "2013-01-31T00:23:48.000+0000",
      versionNo:
        newProviderDate.row && newProviderDate.row.versionNo
          ? newProviderDate.row.versionNo
          : 0,
      dbRecord: false,
      sortColumn: null,
      auditKeyList: [],
      auditKeyListFiltered: false,
      beginDate: formatDate(newProviderDate.beginDate),
      seqNum: newProviderDate.rank,
      nwStatCode: newProviderDate.netWorkStatus,
      nwEndDate: formatDate(newProviderDate.endDate),
      nwID: newProviderDate.netWorkId,
      nwStatCodeDesc: newProviderDate.netWorkSateDesc,
      associationSK:
        newProviderDate.row && newProviderDate.row.associationSK
          ? newProviderDate.row.associationSK
          : null,
    };

    newProviderDate.index > -1
      ? (tableData[newProviderDate.index] = data)
      : tableData.push(data);

    props.setNewState(tableData);
    setSuccess(true);
    setnewProviderDate({
      beginDate: "",
      endDate: "12/31/9999",
      netWorkId: "",
      netWorkStatus: "",
      rank: "",
      netWorkSateDesc: "",
    });
    setresetProviderDate({
      beginDate: "",
      endDate: "12/31/9999",
      netWorkId: "",
      netWorkStatus: "",
      rank: "",
      netWorkSateDesc: "",
    });
    setbanifitPlan(false);
    props.setTabChangeValue({ ...props.tabChangeValue, mainTab: false });
  };

  const handelDeleteClick = () => {
    setSuccess(false);
    const tableData = props.newState;
    if (newProviderDate.row && newProviderDate.row.associationSK) {
      let deleteData = props.deleteRow;
      deleteData.push({
        auditUserID: "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp: "2013-01-31T00:23:48.000+0000",
        addedAuditUserID: "wf_NH_MC_BP_SETUPV99",
        addedAuditTimeStamp: "2013-01-31T00:23:48.000+0000",
        versionNo:
          newProviderDate.row && newProviderDate.row.versionNo
            ? newProviderDate.row.versionNo
            : 0,
        dbRecord: false,
        sortColumn: null,
        auditKeyList: [],
        auditKeyListFiltered: false,
        beginDate: formatDate(newProviderDate.beginDate),
        seqNum: newProviderDate.rank,
        nwStatCode: newProviderDate.netWorkStatus,
        nwEndDate: formatDate(newProviderDate.endDate),
        nwID: newProviderDate.netWorkId,
        nwStatCodeDesc: newProviderDate.netWorkSateDesc,
        associationSK:
          newProviderDate.row && newProviderDate.row.associationSK
            ? newProviderDate.row.associationSK
            : null,
      });
      props.setDeleteRow(deleteData);
    }
    tableData.splice(newProviderDate.index, 1);
    props.setNewState(tableData);
    setShowError(false);
    setnewProviderDate({
      beginDate: "",
      endDate: "12/31/9999",
      netWorkId: "-1",
      netWorkStatus: "-1",
      rank: "",
      netWorkSateDesc: "",
    });
    setresetProviderDate({
      beginDate: "",
      endDate: "12/31/9999",
      netWorkId: "-1",
      netWorkStatus: "-1",
      rank: "",
      netWorkSateDesc: "",
    });
    //setDeleteSuccess({networkDelete:false,providerDelete:true});

    setbanifitPlan(false);
    setDialogOpen(false);
    setDialogType("");
    setDeleteSuccess(true);
  };

  const handelResetClick = () => {
    props.seterrorMessages([]);
    setnewProviderDate(resetProviderDate);
    setShowError(false);
    props.setTabChangeValue({ ...props.tabChangeValue, mainTab: false });
  };
  const handelCandelFunction = () => {
    setbanifitPlan(false);
    setShowError(false);
    setDialogOpen(false);
    setDialogType("");
  };

  const scrollToRef = (ref) =>
    ref.current.scrollIntoView({ behavior: "smooth" });
  const addnetassotiationrefs = useRef(null);
  const MBPscrolltoView = () => {
    setTimeout(
      function () {
        scrollToRef(addnetassotiationrefs);
      }.bind(this),
      500
    );
  };

  const multiDelete = () => {
    setDialogOpen(false);
    setDialogType("");
    props.seterrorMessages([]);
    setSuccess(false);
    setSuccessMessages([]);
    if (selectDeleteArray.length > 0) {
      let CI = props.newState;
      selectDeleteArray.map((value, index) => {
        let curIndex = CI.findIndex((i) =>
          moment(i.beginDate).isSame(value.beginDate)
        );
        CI.splice(curIndex, 1);
      });
      props.setNewState(CI);
      props.setDeleteRow(selectDeleteArray);
      setSelectDeleteArray([]);
      setDeleteSuccess(true);
    }
  };

  useImperativeHandle(ref, () => {
    return { validateFn };
  });

  const validateFn = () => {
    if (props.tabChangeValue.mainTab) {
      handelMainTabSaveValidations();
    }
    if (props.tabChangeValue.capitationTab) {
      capitationTabRef.current.validateCap();
    }
  };

  const handelMainTabSaveValidations = async () => {
    const tableData = props.newState;
    //webninja
    setSuccess(false);
    //setDeleteSuccess({networkDelete:false,providerDelete:false});
    setDeleteSuccess(false);
    props.seterrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newProviderDate.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetProviderDate.beginDate) ||
          e.nwEndDate != formatDate(resetProviderDate.endDate)
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newProviderDate.beginDate),
      formatDate(newProviderDate.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newProviderDate.beginDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.netWorkId,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newProviderDate.beginDate),
      formatDate(newProviderDate.endDate),
      newProviderDate.rank,
      overlapArray
    );
    setShowError({
      showBeginDateError: newProviderDate.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newProviderDate.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        formatDate(newProviderDate.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newProviderDate.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
      networkIDError:
        newProviderDate.netWorkId && newProviderDate.netWorkId != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_ID_Error);
              return true;
            })(),
      networkStatusError:
        newProviderDate.netWorkStatus && newProviderDate.netWorkStatus != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      showRankErrSpe: !isNaN(parseInt(newProviderDate.rank))
        ? false
        : (() => {
            if (newProviderDate.rank.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
      showRankErrZero:
        newProviderDate.rank < 1 && newProviderDate.rank.length
          ? (() => {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
              return true;
            })()
          : false,
      rankError:
        newProviderDate.rank.length < 1
          ? (() => {
              reqFieldArr.push(ErrorConst.Rank_Error);
              return true;
            })()
          : false,

      showHeaderBeginDateErr: !(
        new Date(newProviderDate.beginDate) >=
          new Date(props.formValues.beginDate) &&
        new Date(newProviderDate.beginDate) <=
          new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(
              ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
            );
            return true;
          })()
        : false,

      showHeaderEndDateErr: !(
        new Date(newProviderDate.endDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(ErrorConst.Fall_In_Header_End_Date_Err);
            return true;
          })()
        : false,
      // End header date error
      showBgdtGTEnddtErr:
        new Date(newProviderDate.beginDate) <= new Date(newProviderDate.endDate)
          ? false
          : (() => {
              //reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              reqFieldArr.push(ErrorConst.Date_Range_Error);
              return true;
            })(),
      showNetworkOverlapErr:
        newProviderDate.beginDate &&
        newProviderDate.endDate &&
        newProviderDate.netWorkId &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.NETWORK_TABLE_OVERLAP);
              return true;
            })()
          : false,
      showRankOverlapErr:
        newProviderDate.beginDate &&
        newProviderDate.endDate &&
        newProviderDate.rank &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,
    });
    props.setShowError({
      planBeginDateError: props.formValues.beginDate ? false : true,
      planEndDateError: props.formValues.endDate ? false : true,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }
  };

  return (
    <>
      <div className="pos-relative">{/*webninja*/}</div>
      <Dialog
        open={dialogOpen}
        onClose={() => {
          setDialogOpen(false);
          setDialogType("");
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {dialogType == "Delete" || dialogType == "multiDelete"
              ? "Are you sure that you want to Delete."
              : dialogType == "Cancel"
              ? "Changes you made may not be saved."
              : ""}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            title="Ok"
            onClick={() => {
              dialogType == "Delete"
                ? handelDeleteClick()
                : dialogType == "multiDelete"
                ? multiDelete()
                : handelCandelFunction();
            }}
            color="primary"
            className="btn btn-success"
          >
            Ok
          </Button>
          <Button
            title="Cancel"
            onClick={() => {
              setDialogOpen(false);
              setDialogType("");
            }}
            color="primary"
            autoFocus
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      {props.edit ? (
        <div className="tabs-container">
          <div className="tab-header">
            <h3 className="tab-heading float-left">
              Benefit Plan - Eligibility (MCT) Maps
            </h3>
            <div className="clearfix" />
          </div>
          <div className="tab-holder mt-3">
            <div className="pb-3">
              <span>{props.values.benefitPlanID} : </span>{" "}
              <Link className="cndt-link" to="MapDefinition">
                {props.values.benefitPlanDesc}
              </Link>
            </div>
          </div>
        </div>
      ) : null}
      <div className="tabs-container tabs-container-inner mt-0">
        <div className="tab-header">
          <h3 className="tab-heading float-left">Benefit Plan - Main</h3>
          <div className="clearfix" />
        </div>
        <div className="tab-body-bordered mt-2">
          <div className="form-wrapper">
            <div className="mui-custom-form with-select input-md">
              <TextField
                id="benefit_plan_type_bp_tab"
                select
                required
                label="Benefit Plan Type"
                value={props.mainValues.planType}
                inputProps={{ maxLength: 2 }}
                onChange={props.handleMainChanges("planType")}
                placeholder="Please Select One"
                helperText={
                  props.errors.planTypeErr
                    ? ErrorConst.Benefit_Plan_Type_Error
                    : null
                }
                error={
                  props.errors.planTypeErr
                    ? ErrorConst.Benefit_Plan_Type_Error
                    : null
                }
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.dropdowns &&
                  Object.keys(props.dropdowns).length > 0 &&
                  props.dropdowns["Claims#R_BP_TY_CD"] &&
                  props.dropdowns["Claims#R_BP_TY_CD"].map((each) => (
                    <MenuItem selected key={each.code} value={each.code}>
                      {each.description}
                    </MenuItem>
                  ))}
              </TextField>
            </div>

            <div className="mui-custom-form with-select input-md">
              <TextField
                id="benefit_plan_option_bp_tab"
                select
                required
                label="Benefit Plan Option"
                value={props.mainValues.optionsCode}
                inputProps={{ maxLength: 2 }}
                onChange={props.handleMainChanges("optionsCode")}
                placeholder="Please Select One"
                helperText={
                  props.errors.planOptionErr
                    ? ErrorConst.Benefit_Plan_Option_Error
                    : null
                }
                error={
                  props.errors.planOptionErr
                    ? ErrorConst.Benefit_Plan_Option_Error
                    : null
                }
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.dropdowns &&
                  Object.keys(props.dropdowns).length > 0 &&
                  props.dropdowns["R1#R_BP_OPTNS_CD"] &&
                  props.dropdowns["R1#R_BP_OPTNS_CD"].map((each) => (
                    <MenuItem selected key={each.code} value={each.code}>
                      {each.description}
                    </MenuItem>
                  ))}
              </TextField>
            </div>
            <div className="mui-custom-form with-select input-md">
              <TextField
                id="benefit_plan_status_bp_tab"
                select
                required
                label="Benefit Plan Status"
                value={props.mainValues.benefitPlanStatCode}
                inputProps={{ maxLength: 2 }}
                onChange={props.handleMainChanges("benefitPlanStatCode")}
                placeholder="Please Select One"
                helperText={
                  props.errors.planStatusErr
                    ? ErrorConst.Benefit_Plan_Status_Error
                    : null
                }
                error={
                  props.errors.planStatusErr
                    ? ErrorConst.Benefit_Plan_Status_Error
                    : null
                }
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.dropdowns &&
                  Object.keys(props.dropdowns).length > 0 &&
                  props.dropdowns["R1#R_BP_STAT_CD"] &&
                  props.dropdowns["R1#R_BP_STAT_CD"].map((each) => (
                    <MenuItem selected key={each.code} value={each.code}>
                      {each.description}
                    </MenuItem>
                  ))}
              </TextField>
            </div>
          </div>
        </div>
      </div>
      {props.nonVvDropdown &&
      Object.keys(props.nonVvDropdown).length > 0 &&
      props.mainValues.planType != -1 &&
      (props.mainValues.optionsCode == "1" ||
        props.mainValues.planType == "M" ||
        props.mainValues.planType == "Q") ? (
        <BenefitPlanCapitation
          privileges={props.privileges}
          setNewState={props.setNewState}
          seterrorMessages={props.seterrorMessages}
          handleChanges={props.handleChanges}
          newState={props.newState}
          dropdowns={props.dropdowns}
          networkidDropdown={props.networkidDropdown}
          formValues={props.formValues}
          setShowError={props.setShowError}
          mainValues={props.mainValues}
          setMainValues={props.setMainValues}
          handleMainChanges={props.handleMainChanges}
          values={props.values}
          deleteRow={props.deleteRow}
          setDeleteRow={props.setDeleteRow}
          mapIdDropdown={props.mapIdDropdown}
          capitationValues={props.capitationValues}
          setcapitationValues={props.setcapitationValues}
          handleCapitationChanges={props.handleCapitationChanges}
          nonVvDropdown={props.nonVvDropdown}
          setholdbackVo1Values={props.setholdbackVo1Values}
          holdbackVo1Values={props.holdbackVo1Values}
          setholdbackVo2Values={props.setholdbackVo2Values}
          holdbackVo2Values={props.holdbackVo2Values}
          setNewCohortState={props.setNewCohortState}
          newCohortState={props.newCohortState}
          deleteCohortRow={props.deleteCohortRow}
          setDeleteCohortRow={props.setDeleteCohortRow}
          handleholdbackVo1Changes={props.handleholdbackVo1Changes}
          handleholdbackVo2Changes={props.handleholdbackVo2Changes}
          currprocErr={props.currprocErr}
          retroprocErr={props.retroprocErr}
          tabChangeValue={props.tabChangeValue}
          setTabChangeValue={props.setTabChangeValue}
          majorvalidationscapitation={props.majorValidations}
          ref={capitationTabRef}
        />
      ) : (
        ""
      )}

      <div className="tabs-container mt-3">
        {success ? (
          <div className="alert alert-success custom-alert" role="alert">
            {ErrorConst.SUCCESSFULLY_SAVED_INFORMATION}
          </div>
        ) : null}
        {deleteSuccess ? (
          <div className="alert alert-success custom-alert" role="alert">
            {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
          </div>
        ) : null}
        <div className="tab-header">
          <h3 className="tab-heading float-left">
            Benefit Plan - provider Network Connection
          </h3>
          <div className="float-right th-btnGroup">
            <Button
              title="Delete"
              variant="outlined"
              color="primary"
              className="btn btn-transparent btn-icon-only"
              disabled={selectDeleteArray.length == 0}
              onClick={() => {
                setDialogOpen(true);
                setDialogType("multiDelete");
              }}
            >
              <i className="fa fa-trash" />
            </Button>
            <Button
              title="Add Network Association"
              variant="outlined"
              color="primary"
              className="btn btn-secondary btn-icon-only"
              onClick={() => {
                if (props.majorValidations()) {
                  props.setTabChangeValue({
                    ...props.tabChangeValue,
                    mainTab: true,
                  });
                  setbanifitPlan(true);
                  setSuccess(false);
                  setDeleteSuccess(false);
                  //setDeleteSuccess({networkDelete:false,providerDelete:false});
                  setnewProviderDate({
                    beginDate: "",
                    endDate: "12/31/9999",
                    netWorkId: "-1",
                    netWorkStatus: "-1",
                    rank: "",
                    netWorkSateDesc: "",
                  });
                  setresetProviderDate({
                    beginDate: "",
                    endDate: "12/31/9999",
                    netWorkId: "-1",
                    netWorkStatus: "-1",
                    rank: "",
                    netWorkSateDesc: "",
                  });
                  MBPscrolltoView();
                }
              }}
            >
              <i className="fa fa-plus" />
            </Button>
          </div>
          <div className="clearfix" />
        </div>

        <div className="tab-holder mt-2">
          <BenfitTabelComponent
            tabelRowData={props.newState}
            setSuccess={setSuccess}
            setnewProviderDate={setnewProviderDate}
            setbanifitPlan={setbanifitPlan}
            setresetProviderDate={setresetProviderDate}
            selectDeleteArray={selectDeleteArray}
            setSelectDeleteArray={setSelectDeleteArray}
            setTabChangeValue={props.setTabChangeValue}
            MBPscrolltoView={MBPscrolltoView}
          />
        </div>
        {banifitPlan ? (
          <div className="mt-0" ref={addnetassotiationrefs}>
            <div className="tab-header">
              <h3 className="tab-heading float-left">
                {newProviderDate.index > -1
                  ? "Edit Provider Network Association"
                  : "New Provider Network Association"}
              </h3>
              <div className="float-right th-btnGroup">
                <Button
                  title={newProviderDate.index > -1 ? "Update" : "Add"}
                  variant="outlined"
                  color="primary"
                  className={
                    newProviderDate.index > -1
                      ? "btn btn-ic btn-update"
                      : "btn btn-ic btn-add"
                  }
                  onClick={() => handelClick()}
                >
                  {newProviderDate.index > -1 ? "Update" : "Add"}
                </Button>
                {newProviderDate.index > -1 ? (
                  <Link
                    to="Network"
                    title="View/Edit Map"
                    color="primary"
                    className="btn btn-ic btn-view"
                  >
                    View/Edit Map
                  </Link>
                ) : null}
                {newProviderDate.index > -1 ? (
                  <Button
                    title="Delete"
                    variant="outlined"
                    color="primary"
                    className="btn btn-ic btn-delete"
                    onClick={() => {
                      setDialogOpen(true);
                      setDialogType("Delete");
                    }}
                  >
                    Delete
                  </Button>
                ) : null}
                <Button
                  title="Reset"
                  variant="outlined"
                  color="primary"
                  className="btn btn-ic btn-reset"
                  onClick={() => handelResetClick()}
                >
                  Reset
                </Button>
                <Button
                  title="Cancel"
                  variant="outlined"
                  color="primary"
                  className="btn btn-cancel"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("Cancel");
                    props.setTabChangeValue({
                      ...props.tabChangeValue,
                      mainTab: false,
                    });
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
            <form autoComplete="off">
              <div className="tab-body-bordered mt-2">
                <div className="form-wrapper">
                  <div className="flex-block">
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          required
                          id="begin_date_net_association_bp_tab"
                          label="Begin Date"
                          format="MM/dd/yyyy"
                          InputLabelProps={{
                            shrink: true,
                          }}
                          placeholder="mm/dd/yyyy"
                          value={
                            !newProviderDate.beginDate ||
                            newProviderDate.beginDate == ""
                              ? null
                              : newProviderDate.beginDate
                          }
                          onChange={handelDateChange(
                            "setnewProviderDate",
                            "beginDate"
                          )}
                          helperText={
                            //showHeaderDateErr
                            showBeginDateError
                              ? ErrorConst.BEGIN_DATE_ERROR
                              : showHeaderBeginDateErr
                              ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                              : beginDtInvalidErr
                              ? ErrorConst.Invalid_Begin_Date_Error
                              : showBgdtGTEnddtErr
                              ? ErrorConst.Date_Range_Error
                              : null
                          }
                          error={
                            //showHeaderDateErr
                            showBeginDateError
                              ? ErrorConst.BEGIN_DATE_ERROR
                              : showHeaderBeginDateErr
                              ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                              : beginDtInvalidErr
                              ? ErrorConst.Invalid_Begin_Date_Error
                              : showBgdtGTEnddtErr
                              ? ErrorConst.Date_Range_Error
                              : null
                          }
                          KeyboardButtonProps={{
                            "aria-label": "change date",
                          }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          required
                          id="begin_date_net_association_bp_tab2"
                          label="End Date"
                          format="MM/dd/yyyy"
                          maxDate={new Date("9999-12-31T13:00:00.000+0000")}
                          InputLabelProps={{
                            shrink: true,
                          }}
                          placeholder="mm/dd/yyyy"
                          value={
                            !newProviderDate.endDate ||
                            newProviderDate.endDate == ""
                              ? null
                              : newProviderDate.endDate
                          }
                          onChange={handelDateChange(
                            "setnewProviderDate",
                            "endDate"
                          )}
                          helperText={
                            showHeaderEndDateErr
                              ? ErrorConst.Fall_In_Header_End_Date_Err
                              : showEndDateError
                              ? ErrorConst.END_DATE_ERROR
                              : endDtInvalidErr
                              ? ErrorConst.Invalid_End_Date_Error
                              : null
                          }
                          error={
                            showHeaderEndDateErr
                              ? ErrorConst.Fall_In_Header_End_Date_Err
                              : showEndDateError
                              ? ErrorConst.END_DATE_ERROR
                              : endDtInvalidErr
                              ? ErrorConst.Invalid_End_Date_Error
                              : null
                          }
                          KeyboardButtonProps={{
                            "aria-label": "change date",
                          }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>
                  </div>
                  <div className="flex-block">
                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        required
                        id="network_id_bp_tab"
                        select
                        name="netWorkId"
                        label="Network ID"
                        onChange={(event) => handelInputChange(event)}
                        value={
                          !newProviderDate.netWorkId ||
                          newProviderDate.netWorkId === ""
                            ? null
                            : newProviderDate.netWorkId
                        }
                        helperText={
                          networkIDError ? ErrorConst.Network_ID_Error : null
                        }
                        error={
                          networkIDError ? ErrorConst.Network_ID_Error : null
                        }
                        placeholder="Please Select One"
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {/* <MenuItem value="MCAID">MCAID - Title XIX Benefit Plan Network</MenuItem> */}
                        {props.networkidDropdown &&
                          props.networkidDropdown.length > 0 &&
                          props.networkidDropdown.map((each) => (
                            <MenuItem
                              selected
                              key={each.networkID}
                              value={each.networkID}
                            >
                              {each.networkID} - {each.networkName}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        required
                        id="network_status_bp_tab"
                        select
                        name="netWorkStatus"
                        label="Network Status"
                        onChange={(event) => handelInputChange(event)}
                        //onChange={props.handleChanges('netWorkStatus')}
                        value={newProviderDate.netWorkStatus}
                        helperText={
                          networkStatusError
                            ? ErrorConst.Network_Status_Error
                            : null
                        }
                        error={
                          networkStatusError
                            ? ErrorConst.Network_Status_Error
                            : null
                        }
                        placeholder="Please Select One"
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem value="-1">Please Select One</MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["R1#R_BP_NW_STAT_CD"] &&
                          props.dropdowns["R1#R_BP_NW_STAT_CD"].map((each) => (
                            <MenuItem
                              selected
                              key={each.code}
                              value={each.code}
                            >
                              {each.description}
                            </MenuItem>
                          ))}
                      </TextField>
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        InputLabelProps={{
                          shrink: true,
                        }}
                        required
                        name="rank"
                        label="rank"
                        onChange={(event) => handelInputChange(event)}
                        //onChange={props.handleChanges('rank')}
                        inputProps={{ maxLength: 6 }}
                        value={newProviderDate.rank}
                        helperText={
                          rankError
                            ? ErrorConst.Rank_Error
                            : RankErr
                            ? ErrorConst.RANK_TABLE_OVERLAP
                            : showRankErrSpe
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                            : showRankErrZero
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                            : null
                        }
                        error={
                          rankError
                            ? ErrorConst.Rank_Error
                            : RankErr
                            ? ErrorConst.RANK_TABLE_OVERLAP
                            : showRankErrSpe
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                            : showRankErrZero
                            ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                            : null
                        }
                        id="rank_bp_tab"
                        label="Rank"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
        ) : null}
      </div>
    </>
  );
}
export default forwardRef(MainbenifitPlan);
