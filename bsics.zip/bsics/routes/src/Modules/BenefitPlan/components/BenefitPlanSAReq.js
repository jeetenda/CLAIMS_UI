import React, {
  useState,
  useEffect,
  useRef,
  forwardRef,
  useImperativeHandle,
} from "react";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import DateFnsUtils from "@date-io/date-fns";
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import dateFnsFormat from "date-fns/format";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import SaReqTableComponent from "./SaReqTableComponent";
import * as moment from "moment";
import "moment-range";
import axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import { Button } from "react-bootstrap";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker,
} from "@material-ui/pickers";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import isSpecialcharecter from "./validations";
import { Link } from "react-router-dom";

function BenifitPlanSAReq(props, ref) {
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [saReqBenefitPlan, setSaReqBenefitPlan] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [success, setSuccess] = useState(false);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);

  const [newSaReqPlan, setnewSaReqPlan] = useState({
    benefitPlanStatusNetworkCode: "",
    mapSetID: "",
    beginDate: "",
    endDate: "",
    saMetExceptionCode: "",
    saOverExceptionCode: "",
    ruleCode: "",
    seqNum: "",
    bpNWCodeDesc: "",
    saRuleCodeDesc: "",
  });
  const [resetSaReqPlan, setresetSaReqPlan] = useState({
    benefitPlanStatusNetworkCode: "",
    mapSetID: "",
    beginDate: "",
    endDate: "",
    saMetExceptionCode: "",
    saOverExceptionCode: "",
    ruleCode: "",
    seqNum: "",
    bpNWCodeDesc: "",
    saRuleCodeDesc: "",
  });

  const [selectedReqEndDate, setSelectedReqEndDate] = React.useState("");
  const [selectedReqBeginDate, setSelectedReqBeginDate] = React.useState("");
  const [
    {
      showHeaderDateErr,
      showBeginDateError,
      showEndDateError,
      beginDtInvalidErr,
      endDtInvalidErr,
      showRankOverlapErr,
      showNetworkOverlapErr,
      networkStatusError,
      mapIdErr,
      rankError,
      showBgdtGTEnddtErr,
      RankErr,
      showRankErrZero,
      metexcCodeError,
      metexcCodeInvalidError,
      overexcCodeError,
      overexcCodeInvalidError,
      saRuleError,
      saRuleInvalidError,
      INVALID_LMT_MET_EXC_CODE,
      INVALID_LMT_MET_EXC_CODE_SPL,
      INVALID_LMT_OVR_EXC_CODE,
      INVALID_LMT_OVR_EXC_CODE_SPE,
      showHeaderEndDateErr,
    },
    setShowError,
  ] = React.useState(false);

  const formatDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const formatCovDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const handelDateRngeWithin = (
    rangeStartDate,
    rangeEndDate,
    withInStartDate,
    withInEndDate
  ) => {
    if (rangeStartDate && rangeEndDate && withInStartDate && withInEndDate) {
      const range = moment().range(
        new Date(rangeStartDate),
        new Date(rangeEndDate)
      );
      return (
        range.contains(new Date(withInStartDate)) &&
        range.contains(new Date(withInEndDate))
      );
    }
    return false;
  };

  const handelDateRngeOverlap = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate
  ) => {
    const range1 = moment().range(
      new Date(initalStartDate),
      new Date(initialEndDate)
    );
    const range2 = moment().range(
      new Date(secondaryStartDate),
      new Date(secondaryEndDate)
    );
    return range1.overlaps(range2);
  };

  const handelDateNetworkArrayOverlap = (
    initalStartDate,
    initialEndDate,
    networkId,
    networkstatus,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (
            each.mapSetID == networkId &&
            each.benefitPlanStatusNetworkCode == networkstatus &&
            each.beginDate == initalStartDate
          ) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRankArrayOverlap = (
    initalStartDate,
    initialEndDate,
    Rank,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (each.seqNum == Rank) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handleReqBeginDateChange = (d) => {
    setSelectedReqBeginDate(d);
    let finaldate = formatCovDate(d);
    props.handleSADtChange("beginDate", finaldate);
  };

  const handleReqEndDateChange = (d) => {
    setSelectedReqEndDate(d);
    let finaldate = formatCovDate(d);
    props.handleSADtChange("endDate", finaldate);
  };

  const handelInputChange = (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, SaReqTab: true });
    if (event.target.name === "benefitPlanStatusNetworkCode") {
      setnewSaReqPlan({
        ...newSaReqPlan,
        [event.target.name]: event.target.value,
        bpNWCodeDesc: event.nativeEvent.target.textContent,
      });
    } else if (event.target.name === "ruleCode") {
      setnewSaReqPlan({
        ...newSaReqPlan,
        [event.target.name]: event.target.value,
        saRuleCodeDesc: event.nativeEvent.target.textContent,
      });
    } else {
      setnewSaReqPlan({
        ...newSaReqPlan,
        [event.target.name]: event.target.value,
      });
    }
  };

  const handelDateChange = (type, name) => (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, SaReqTab: true });
    if (type === "setnewSaReqPlan") {
      setnewSaReqPlan({ ...newSaReqPlan, [name]: date });
    }
  };

  const validateExcCode = (c) => {
    return new Promise((resolve, reject) => {
      setspinnerLoader(true);
      axios
        .get(
          serviceEndPoint.BENEFIT_PLAN_EXC_CODE_VALIDATION +
            c +
            "/" +
            props.formValues.lobId
        )
        .then((response) => {
          if (response.data.data && response.data.data.excCodeDesc) {
            resolve(response.data.data.excCodeDesc);
          } else {
            resolve(false);
          }
        })
        .catch((error) => {
          resolve(false);
        })
        .then(() => {
          setspinnerLoader(false);
        });
    });
  };

  const handelClick = async () => {
    const tableData = props.newSaReqState;
    let errors = {};
    //webninja
    setSuccess(false);
    setDeleteSuccess(false);
    props.seterrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newSaReqPlan.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetSaReqPlan.beginDate) ||
          e.endDate != formatDate(resetSaReqPlan.endDate) ||
          e.seqNum != resetSaReqPlan.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newSaReqPlan.beginDate),
      formatDate(newSaReqPlan.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newSaReqPlan.beginDate),
      formatDate(newSaReqPlan.endDate),
      newSaReqPlan.mapSetID,
      newSaReqPlan.benefitPlanStatusNetworkCode,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newSaReqPlan.beginDate),
      formatDate(newSaReqPlan.endDate),
      newSaReqPlan.seqNum,
      overlapArray
    );
    let metExcnDesc = await validateExcCode(newSaReqPlan.saMetExceptionCode);
    let ovrExcnDesc = await validateExcCode(newSaReqPlan.saOverExceptionCode);
    setShowError({
      showBeginDateError: newSaReqPlan.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newSaReqPlan.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        formatDate(newSaReqPlan.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newSaReqPlan.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,

      networkStatusError:
        newSaReqPlan.benefitPlanStatusNetworkCode &&
        newSaReqPlan.benefitPlanStatusNetworkCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      mapIdErr:
        newSaReqPlan.mapSetID && newSaReqPlan.mapSetID != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      saRuleError:
        newSaReqPlan.ruleCode && newSaReqPlan.ruleCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Sa_Rule_Error);
              return true;
            })(),
      rankError: newSaReqPlan.seqNum
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Rank_Error);
            return true;
          })(),
      showBgdtGTEnddtErr:
        new Date(newSaReqPlan.beginDate) <= new Date(newSaReqPlan.endDate)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })(),
      RankErr: !(
        isNaN(newSaReqPlan.seqNum) || parseInt(newSaReqPlan.seqNum) > 99999
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Invalid_Rank_Error);
            return true;
          })(),
      showRankErrZero: newSaReqPlan.seqNum < 1 && newSaReqPlan.seqNum.length
          ? (() => {         
            reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
            return true;        
          })()
          : false,
      // showHeaderDateErr: !headerTange && newSaReqPlan.beginDate ? (() => { reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk); return true; })() : false,
      showHeaderDateErr: !(
        new Date(newSaReqPlan.beginDate) >=
          new Date(props.formValues.beginDate) &&
        new Date(newSaReqPlan.beginDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(
              ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
            );
            return true;
          })()
        : false,
      showHeaderEndDateErr: !(
        new Date(newSaReqPlan.endDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(ErrorConst.Fall_In_Header_End_Date_Err);
            return true;
          })()
        : false,
      showNetworkOverlapErr:
        newSaReqPlan.beginDate &&
        newSaReqPlan.endDate &&
        newSaReqPlan.mapSetID &&
        newSaReqPlan.benefitPlanStatusNetworkCode &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.NETWORK_MAP_OVERLAP);
              return true;
            })()
          : false,
      showRankOverlapErr:
        newSaReqPlan.beginDate &&
        newSaReqPlan.endDate &&
        newSaReqPlan.seqNum &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,

      INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(
        newSaReqPlan.saMetExceptionCode
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE);
            return true;
          })(),
      INVALID_LMT_MET_EXC_CODE: newSaReqPlan.saMetExceptionCode
        ? (() => {
            if (!isSpecialcharecter(newSaReqPlan.saMetExceptionCode)) {
              if (!metExcnDesc) {
                reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                return true;
              } else {
                return false;
              }
            }
          })()
        : false,
      INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(
        newSaReqPlan.saOverExceptionCode
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE);
            return true;
          })(),
      INVALID_LMT_OVR_EXC_CODE: newSaReqPlan.saOverExceptionCode
        ? (() => {
            if (!isSpecialcharecter(newSaReqPlan.saOverExceptionCode)) {
              if (!ovrExcnDesc) {
                reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                return true;
              } else {
                return false;
              }
            }
          })()
        : false,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      setShowError(errors);
      return false;
    }

    const data = {
      auditUserID:
        newSaReqPlan.row && newSaReqPlan.row.auditUserID
          ? newSaReqPlan.row.auditUserID
          : "wf_NH_MC_BP_SETUPV99",
      auditTimeStamp:
        newSaReqPlan.row && newSaReqPlan.row.auditTimeStamp
          ? newSaReqPlan.row.auditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
      addedAuditUserID:
        newSaReqPlan.row && newSaReqPlan.row.addedAuditUserID
          ? newSaReqPlan.row.addedAuditUserID
          : "wf_NH_MC_BP_SETUPV99",
      addedAuditTimeStamp:
        newSaReqPlan.row && newSaReqPlan.row.addedAuditTimeStamp
          ? newSaReqPlan.row.addedAuditTimeStamp
          : "2013-01-31T00:23:48.000+0000",
      versionNo:
        newSaReqPlan.row && newSaReqPlan.row.versionNo
          ? newSaReqPlan.row.versionNo
          : 0,
      dbRecord:
        newSaReqPlan.row && newSaReqPlan.row.dbRecord
          ? newSaReqPlan.row.dbRecord
          : false,
      sortColumn:
        newSaReqPlan.row && newSaReqPlan.row.sortColumn
          ? newSaReqPlan.row.sortColumn
          : null,
      auditKeyList:
        newSaReqPlan.row && newSaReqPlan.row.auditKeyList
          ? newSaReqPlan.row.auditKeyList
          : [],
      auditKeyListFiltered:
        newSaReqPlan.row && newSaReqPlan.row.auditKeyListFiltered
          ? newSaReqPlan.row.auditKeyListFiltered
          : false,
      beginDate: formatDate(newSaReqPlan.beginDate),
      seqNum: newSaReqPlan.seqNum,
      benefitPlanStatusNetworkCode: newSaReqPlan.benefitPlanStatusNetworkCode,
      endDate: formatDate(newSaReqPlan.endDate),
      mapSetID: newSaReqPlan.mapSetID,
      saMetExceptionCode: newSaReqPlan.saMetExceptionCode,
      saOverExceptionCode: newSaReqPlan.saOverExceptionCode,
      metExcnDesc: metExcnDesc ? metExcnDesc : "",
      ovrExcnDesc: ovrExcnDesc ? ovrExcnDesc : "",
      ruleCode: newSaReqPlan.ruleCode,
      bpNWCodeDesc: newSaReqPlan.bpNWCodeDesc,
      saRuleCodeDesc: newSaReqPlan.saRuleCodeDesc,
      benefitPlanSAID:
        newSaReqPlan.row && newSaReqPlan.row.benefitPlanSAID
          ? newSaReqPlan.row.benefitPlanSAID
          : "",
    };

    newSaReqPlan.index > -1
      ? (tableData[newSaReqPlan.index] = data)
      : tableData.push(data);
    props.setNewSaReqState(tableData);
    setSuccess(true);

    setnewSaReqPlan({
      benefitPlanStatusNetworkCode: "",
      mapSetID: "",
      beginDate: "",
      endDate: "",
      saMetExceptionCode: "",
      saOverExceptionCode: "",
      ruleCode: "",
      seqNum: "",
      bpNWCodeDesc: "",
      saRuleCodeDesc: "",
    });
    setresetSaReqPlan({
      benefitPlanStatusNetworkCode: "",
      mapSetID: "",
      beginDate: "",
      endDate: "",
      saMetExceptionCode: "",
      saOverExceptionCode: "",
      ruleCode: "",
      seqNum: "",
      bpNWCodeDesc: "",
      saRuleCodeDesc: "",
    });
    setSaReqBenefitPlan(false);
    props.setTabChangeValue({ ...props.tabChangeValue, SaReqTab: false });
  };

  const handelResetClick = () => {
    props.seterrorMessages([]);
    setnewSaReqPlan(resetSaReqPlan);
    setShowError(false);
    props.setTabChangeValue({ ...props.tabChangeValue, SaReqTab: false });
  };

  const handelCandelFunction = () => {
    setSaReqBenefitPlan(false);
    setShowError(false);
    setDialogOpen(false);
    setDialogType("");
  };

  const handelDeleteClick = () => {
    const tableData = props.newSaReqState;
    setSuccess(false);
    if (newSaReqPlan.row && newSaReqPlan.row.benefitPlanSAID) {
      let deleteData = props.deleteSARow;
      deleteData.push({
        auditUserID: newSaReqPlan.row.auditUserID,
        auditTimeStamp: newSaReqPlan.row.auditTimeStamp,
        addedAuditUserID: newSaReqPlan.row.addedAuditUserID,
        addedAuditTimeStamp: newSaReqPlan.row.addedAuditTimeStamp,
        versionNo: newSaReqPlan.row.versionNo,
        dbRecord: false,
        sortColumn: null,
        auditKeyList: [],
        auditKeyListFiltered: false,
        beginDate: formatDate(newSaReqPlan.beginDate),
        seqNum: newSaReqPlan.seqNum,
        benefitPlanStatusNetworkCode: newSaReqPlan.benefitPlanStatusNetworkCode,
        endDate: formatDate(newSaReqPlan.endDate),
        mapSetID: newSaReqPlan.mapSetID,
        saMetExceptionCode: newSaReqPlan.saMetExceptionCode,
        saOverExceptionCode: newSaReqPlan.saOverExceptionCode,
        ruleCode: newSaReqPlan.ruleCode,
        bpNWCodeDesc: newSaReqPlan.bpNWCodeDesc,
        saRuleCodeDesc: newSaReqPlan.saRuleCodeDesc,
        benefitPlanSAID: newSaReqPlan.row.benefitPlanSAID,
      });
      props.setDeleteSARow(deleteData);
    }
    tableData.splice(newSaReqPlan.index, 1);
    props.setNewSaReqState(tableData);
    setShowError(false);
    setnewSaReqPlan({
      benefitPlanStatusNetworkCode: "",
      mapSetID: "",
      beginDate: "",
      endDate: "",
      saMetExceptionCode: "",
      saOverExceptionCode: "",
      ruleCode: "",
      seqNum: "",
      bpNWCodeDesc: "",
      saRuleCodeDesc: "",
    });
    setresetSaReqPlan({
      benefitPlanStatusNetworkCode: "",
      mapSetID: "",
      beginDate: "",
      endDate: "",
      saMetExceptionCode: "",
      saOverExceptionCode: "",
      ruleCode: "",
      seqNum: "",
      bpNWCodeDesc: "",
      saRuleCodeDesc: "",
    });
    setSaReqBenefitPlan(false);
    setDialogOpen(false);
    setDialogType("");
    setDeleteSuccess(true);
  };
  const scrollToRef = (ref) =>
    ref.current.scrollIntoView({ behavior: "smooth" });
  const addSARscrolltoView = useRef(null);
  const SARscrolltoView = () => {
    setTimeout(
      function () {
        scrollToRef(addSARscrolltoView);
      }.bind(this),
      500
    );
  };

  const multiDelete = () => {
    setDialogOpen(false);
    setDialogType("");
    props.seterrorMessages([]);
    setSuccess(false);
    setSuccessMessages([]);
    if (selectDeleteArray.length > 0) {
      let CI = props.newSaReqState;
      selectDeleteArray.map((value, index) => {
        let curIndex = CI.findIndex((i) =>
          moment(i.beginDate).isSame(value.beginDate)
        );
        CI.splice(curIndex, 1);
      });
      props.setNewSaReqState(CI);
      setDeleteSuccess(true);
      props.setDeleteSARow(selectDeleteArray);
      setSelectDeleteArray([]);
      //setDeleteSuccess(true);
    }
  };
  useImperativeHandle(ref, () => {
    return { validateFn };
  });

  const validateFn = () => {
    if (props.tabChangeValue.coverageTab) {
      handelSaveValidations();
    }
  };

  const handelSaveValidations = async () => {
    const tableData = props.newSaReqState;
    let errors = {};
    //webninja
    setSuccess(false);
    setDeleteSuccess(false);
    props.seterrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newSaReqPlan.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetSaReqPlan.beginDate) ||
          e.endDate != formatDate(resetSaReqPlan.endDate) ||
          e.seqNum != resetSaReqPlan.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newSaReqPlan.beginDate),
      formatDate(newSaReqPlan.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newSaReqPlan.beginDate),
      formatDate(newSaReqPlan.endDate),
      newSaReqPlan.mapSetID,
      newSaReqPlan.benefitPlanStatusNetworkCode,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newSaReqPlan.beginDate),
      formatDate(newSaReqPlan.endDate),
      newSaReqPlan.seqNum,
      overlapArray
    );
    let metExcnDesc = await validateExcCode(newSaReqPlan.saMetExceptionCode);
    let ovrExcnDesc = await validateExcCode(newSaReqPlan.saOverExceptionCode);
    setShowError({
      showBeginDateError: newSaReqPlan.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newSaReqPlan.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        formatDate(newSaReqPlan.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newSaReqPlan.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
      mapIdErr:
        newSaReqPlan.mapSetID && newSaReqPlan.mapSetID != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      networkStatusError:
        newSaReqPlan.benefitPlanStatusNetworkCode &&
        newSaReqPlan.benefitPlanStatusNetworkCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      rankError: newSaReqPlan.seqNum
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Rank_Error);
            return true;
          })(),
      showBgdtGTEnddtErr:
        new Date(newSaReqPlan.beginDate) <= new Date(newSaReqPlan.endDate)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })(),
      RankErr: !(
        isNaN(newSaReqPlan.seqNum) || parseInt(newSaReqPlan.seqNum) > 99999
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Invalid_Rank_Error);
            return true;
          })(),
      showRankErrZero: newSaReqPlan.seqNum < 1 && newSaReqPlan.seqNum.length
          ? (() => {         
            reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
            return true;        
          })()
          : false,
      //showHeaderDateErr: !headerTange && newSaReqPlan.beginDate ? (() => { reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk); return true; })() : false,
      showHeaderDateErr: !(
        new Date(newSaReqPlan.beginDate) >=
          new Date(props.formValues.beginDate) &&
        new Date(newSaReqPlan.beginDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(
              ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
            );
            return true;
          })()
        : false,
      showHeaderEndDateErr: !(
        new Date(newSaReqPlan.endDate) <= new Date(props.formValues.endDate)
      )
        ? (() => {
            reqFieldArr.push(ErrorConst.Fall_In_Header_End_Date_Err);
            return true;
          })()
        : false,
      showNetworkOverlapErr:
        newSaReqPlan.beginDate &&
        newSaReqPlan.endDate &&
        newSaReqPlan.mapSetID &&
        newSaReqPlan.benefitPlanStatusNetworkCode &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.NETWORK_MAP_OVERLAP);
              return true;
            })()
          : false,
      showRankOverlapErr:
        newSaReqPlan.beginDate &&
        newSaReqPlan.endDate &&
        newSaReqPlan.seqNum &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,
      saRuleError:
        newSaReqPlan.ruleCode && newSaReqPlan.ruleCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Sa_Rule_Error);
              return true;
            })(),
      INVALID_LMT_MET_EXC_CODE_SPL: !isSpecialcharecter(
        newSaReqPlan.saMetExceptionCode
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE);
            return true;
          })(),
      INVALID_LMT_MET_EXC_CODE: newSaReqPlan.saMetExceptionCode
        ? (() => {
            if (!isSpecialcharecter(newSaReqPlan.saMetExceptionCode)) {
              if (!metExcnDesc) {
                reqFieldArr.push(ErrorConst.INVALID_LMT_MET_EXC_CODE);
                return true;
              } else {
                return false;
              }
            }
          })()
        : false,
      INVALID_LMT_OVR_EXC_CODE_SPE: !isSpecialcharecter(
        newSaReqPlan.saOverExceptionCode
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE);
            return true;
          })(),
      INVALID_LMT_OVR_EXC_CODE: newSaReqPlan.saOverExceptionCode
        ? (() => {
            if (!isSpecialcharecter(newSaReqPlan.saOverExceptionCode)) {
              if (!ovrExcnDesc) {
                reqFieldArr.push(ErrorConst.INVALID_LMT_OVR_EXC_CODE);
                return true;
              } else {
                return false;
              }
            }
          })()
        : false,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      setShowError(errors);
      return false;
    }
  };
  return (
    <>
      <div className="pos-relative">{/*webninja*/}</div>
      <Dialog
        open={dialogOpen}
        onClose={() => {
          setDialogOpen(false);
          setDialogType("");
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {dialogType == "Delete" || dialogType == "multiDelete"
              ? "Are you sure that you want to Delete."
              : dialogType == "Cancel"
              ? "Changes you made may not be saved."
              : ""}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            title="Ok"
            onClick={() => {
              dialogType == "Delete"
                ? handelDeleteClick()
                : dialogType == "multiDelete"
                ? multiDelete()
                : handelCandelFunction();
            }}
            color="primary"
            className="btn btn-success"
          >
            Ok
          </Button>
          <Button
            title="Cancel"
            onClick={() => {
              setDialogOpen(false);
              setDialogType("");
            }}
            color="primary"
            autoFocus
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>

      {success ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.SUCCESSFULLY_SAVED_INFORMATION}
        </div>
      ) : null}
      {deleteSuccess ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
        </div>
      ) : null}
      <div className="tabs-container pt-2">
        <div className="tab-header">
          <h3 className="tab-heading float-left">
            Benifit Plan - SA Requirements
          </h3>
          <div className="float-right th-btnGroup">
            <Button
              title="Delete"
              variant="outlined"
              color="primary"
              className="btn btn-transparent btn-icon-only"
              disabled={selectDeleteArray.length == 0}
              onClick={() => {
                setDialogOpen(true);
                setDialogType("multiDelete");
              }}
            >
              <i className="fa fa-trash" />
            </Button>
            <Button
              title="Add SA Requirements"
              variant="outlined"
              color="primary"
              className="btn btn-secondary btn-icon-only"
              onClick={() => {
                if (props.majorValidations()) {
                  props.setTabChangeValue({
                    ...props.tabChangeValue,
                    SaReqTab: true,
                  });
                  setSaReqBenefitPlan(true);
                  setSuccess(false);
                  setDeleteSuccess(false);
                  setnewSaReqPlan({
                    benefitPlanStatusNetworkCode: "-1",
                    mapSetID: "-1",
                    beginDate: "",
                    endDate: "12/31/9999",
                    saMetExceptionCode: "",
                    saOverExceptionCode: "",
                    ruleCode: "-1",
                    seqNum: "",
                    bpNWCodeDesc: "",
                    saRuleCodeDesc: "",
                  });
                  setresetSaReqPlan({
                    benefitPlanStatusNetworkCode: "-1",
                    mapSetID: "-1",
                    beginDate: "",
                    endDate: "12/31/9999",
                    saMetExceptionCode: "",
                    saOverExceptionCode: "",
                    ruleCode: "-1",
                    seqNum: "",
                    bpNWCodeDesc: "",
                    saRuleCodeDesc: "",
                  });
                  SARscrolltoView();
                }
              }}
            >
              <i className="fa fa-plus" />
            </Button>
          </div>
          <div className="clearfix" />
        </div>
        <div className="tab-holder mt-2">
          {
            <SaReqTableComponent
              setSuccess={setSuccess}
              tabelRowData={props.newSaReqState}
              setnewSaReqPlan={setnewSaReqPlan}
              setSaReqBenefitPlan={setSaReqBenefitPlan}
              setresetSaReqPlan={setresetSaReqPlan}
              selectDeleteArray={selectDeleteArray}
              setSelectDeleteArray={setSelectDeleteArray}
              setTabChangeValue={props.setTabChangeValue}
              SARscrolltoView={SARscrolltoView}
            />
          }
        </div>
      </div>

      {saReqBenefitPlan ? (
        <div className="tabs-container mt-0" ref={addSARscrolltoView}>
          <div className="tab-header">
            <h3 className="tab-heading float-left">
              {newSaReqPlan.index > -1
                ? "Edit SA Requirements"
                : "New SA Requirements"}
            </h3>
            <div className="float-right th-btnGroup">
              <Button
                title={newSaReqPlan.index > -1 ? "Update" : "Add"}
                variant="outlined"
                color="primary"
                className={
                  newSaReqPlan.index > -1
                    ? "btn btn-ic btn-update"
                    : "btn btn-ic btn-add"
                }
                onClick={() => handelClick()}
                disabled={
                  props.privileges && !props.privileges.add ? "disabled" : ""
                }
              >
                {newSaReqPlan.index > -1 ? "Update" : "Add"}
              </Button>
              {newSaReqPlan.index > -1 ? (
                <Link
                  to="MapDefinition"
                  target="_blank"
                  title="View/Edit Map"
                  className="btn btn-ic btn-view"
                >
                  View/Edit Map
                </Link>
              ) : null}
              {newSaReqPlan.index > -1 ? (
                <Button
                  title="Delete"
                  variant="outlined"
                  color="primary"
                  className="btn btn-ic btn-delete"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("Delete");
                  }}
                >
                  Delete
                </Button>
              ) : null}
              <Button
                title="Reset"
                variant="outlined"
                color="primary"
                className="btn btn-ic btn-reset"
                onClick={() => handelResetClick()}
              >
                Reset
              </Button>
              <Button
                title="Cancel"
                variant="outlined"
                color="primary"
                className="btn btn-cancel"
                onClick={() => {
                  setDialogOpen(true);
                  setDialogType("Cancel");
                  props.setTabChangeValue({
                    ...props.tabChangeValue,
                    SaReqTab: false,
                  });
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
          <div className="tab-body-bordered mt-2">
            <div className="form-wrapper">
              {/* <h1 className="tab-heading float-left">Batch Data</h1> */}

              <div className="flex-block">
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                  <div className="mui-custom-form input-md with-select">
                    <KeyboardDatePicker
                      id="bgn_date_saReq_tab"
                      name="beginDate"
                      required
                      label="Begin Date"
                      format="MM/dd/yyyy"
                      InputLabelProps={{
                        shrink: true,
                      }}
                      placeholder="mm/dd/yyyy"
                      value={
                        !newSaReqPlan.beginDate || newSaReqPlan.beginDate == ""
                          ? null
                          : newSaReqPlan.beginDate
                      }
                      onChange={handelDateChange(
                        "setnewSaReqPlan",
                        "beginDate"
                      )}
                      helperText={
                        showBeginDateError
                          ? ErrorConst.BEGIN_DATE_ERROR
                          : showHeaderDateErr
                          ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                          : beginDtInvalidErr
                          ? ErrorConst.Invalid_Begin_Date_Error
                          : showBgdtGTEnddtErr
                          ? ErrorConst.DATE_RANGE_ERROR
                          : null
                      }
                      error={
                        showBeginDateError
                          ? ErrorConst.BEGIN_DATE_ERROR
                          : showHeaderDateErr
                          ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                          : beginDtInvalidErr
                          ? ErrorConst.Invalid_Begin_Date_Error
                          : showBgdtGTEnddtErr
                          ? ErrorConst.DATE_RANGE_ERROR
                          : null
                      }
                      KeyboardButtonProps={{
                        "aria-label": "change date",
                      }}
                    />
                  </div>
                </MuiPickersUtilsProvider>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                  <div
                    className="mui-custom-form input-md with-select"
                    style={{ marginLeft: "30px" }}
                  >
                    <KeyboardDatePicker
                      id="end_date_saReq_tab"
                      name="endDate"
                      required
                      label="End Date"
                      format="MM/dd/yyyy"
                      maxDate={new Date("9999-12-31T13:00:00.000+0000")}
                      InputLabelProps={{
                        shrink: true,
                      }}
                      placeholder="mm/dd/yyyy"
                      value={
                        !newSaReqPlan.endDate || newSaReqPlan.endDate == ""
                          ? null
                          : newSaReqPlan.endDate
                      }
                      onChange={handelDateChange("setnewSaReqPlan", "endDate")}
                      helperText={
                        showEndDateError
                          ? ErrorConst.END_DATE_ERROR
                          : endDtInvalidErr
                          ? ErrorConst.Invalid_End_Date_Error
                          : showHeaderEndDateErr
                          ? ErrorConst.Fall_In_Header_End_Date_Err
                          : null
                      }
                      error={
                        showEndDateError
                          ? ErrorConst.END_DATE_ERROR
                          : endDtInvalidErr
                          ? ErrorConst.Invalid_End_Date_Error
                          : null
                      }
                      KeyboardButtonProps={{
                        "aria-label": "change date",
                      }}
                    />
                  </div>
                </MuiPickersUtilsProvider>
              </div>
              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    required
                    id="network_status_saReq_tab"
                    select
                    name="benefitPlanStatusNetworkCode"
                    label="Network Status"
                    onChange={(event) => handelInputChange(event)}
                    value={newSaReqPlan.benefitPlanStatusNetworkCode}
                    helperText={
                      networkStatusError
                        ? ErrorConst.Network_Status_Error
                        : null
                    }
                    error={
                      networkStatusError
                        ? ErrorConst.Network_Status_Error
                        : null
                    }
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {/* <MenuItem value="INN">INN-In Network</MenuItem> */}
                    {props.dropdowns &&
                      props.dropdowns["R1#R_BP_NW_STAT_CD"] &&
                      props.dropdowns["R1#R_BP_NW_STAT_CD"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>

                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="map_id_saReq_tab"
                    select
                    required
                    name="mapSetID"
                    label="Map ID"
                    onChange={(event) => handelInputChange(event)}
                    value={newSaReqPlan.mapSetID}
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                    helperText={mapIdErr ? ErrorConst.Map_Id_Error : null}
                    error={mapIdErr ? ErrorConst.Map_Id_Error : null}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.mapIdDropdown.map((each) => (
                      <MenuItem
                        selected
                        key={each.mapsetId}
                        value={each.mapsetId}
                      >
                        {each.mapsetId}-{each.mapDesc}
                      </MenuItem>
                    ))}
                  </TextField>
                </div>

                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="limit_met_saReq_tab"
                    name="saMetExceptionCode"
                    label="Limit Met Exc Code"
                    inputProps={{ maxLength: 4 }}
                    onChange={(event) => handelInputChange(event)}
                    value={newSaReqPlan.saMetExceptionCode}
                    helperText={
                      INVALID_LMT_MET_EXC_CODE
                        ? ErrorConst.INVALID_LMT_MET_EXC_CODE
                        : INVALID_LMT_MET_EXC_CODE_SPL
                        ? ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE
                        : null
                    }
                    error={
                      INVALID_LMT_MET_EXC_CODE
                        ? ErrorConst.INVALID_LMT_MET_EXC_CODE
                        : INVALID_LMT_MET_EXC_CODE_SPL
                        ? ErrorConst.INVALID_LMT_MET_EXC_CODE_SPE
                        : null
                    }
                    InputLabelProps={{
                      shrink: true,
                    }}
                  ></TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="limit_over_saReq_tab"
                    name="saOverExceptionCode"
                    label="Limit Over Exc Code"
                    inputProps={{ maxLength: 4 }}
                    onChange={(event) => handelInputChange(event)}
                    value={newSaReqPlan.saOverExceptionCode}
                    helperText={
                      INVALID_LMT_OVR_EXC_CODE
                        ? ErrorConst.INVALID_LMT_OVR_EXC_CODE
                        : INVALID_LMT_OVR_EXC_CODE_SPE
                        ? ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE
                        : null
                    }
                    error={
                      INVALID_LMT_OVR_EXC_CODE
                        ? ErrorConst.INVALID_LMT_OVR_EXC_CODE
                        : INVALID_LMT_OVR_EXC_CODE_SPE
                        ? ErrorConst.BENIFIT_INVALID_LMT_OVR_EXC_CODE
                        : null
                    }
                    InputLabelProps={{
                      shrink: true,
                    }}
                  ></TextField>
                </div>
              </div>
              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="sa_rule_code_saReq_tab"
                    select
                    required
                    name="ruleCode"
                    label="SA Rule Code"
                    onChange={(event) => handelInputChange(event)}
                    value={newSaReqPlan.ruleCode}
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                    helperText={saRuleError ? ErrorConst.Sa_Rule_Error : null}
                    error={saRuleError ? ErrorConst.Sa_Rule_Error : null}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.dropdowns &&
                      props.dropdowns["R1#R_BP_SA_RULE_CD"] &&
                      props.dropdowns["R1#R_BP_SA_RULE_CD"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>

                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    required
                    name="seqNum"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 6 }}
                    value={newSaReqPlan.seqNum}
                    helperText={
                      rankError
                        ? ErrorConst.Rank_Error
                        : RankErr
                        ? ErrorConst.Invalid_Rank_Error
                        : showRankOverlapErr
                       
                        ? ErrorConst.RANK_TABLE_OVERLAP
                        :showRankErrZero
                        ?ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                        : null
                    }
                    error={
                      rankError
                        ? ErrorConst.Rank_Error
                        : RankErr
                        ? ErrorConst.Invalid_Rank_Error
                        : showRankOverlapErr
                        ? ErrorConst.RANK_TABLE_OVERLAP
                        :showRankErrZero
                        ?ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                        : null
                    }
                    id="rank_saReq_tab"
                    label="Rank"
                  ></TextField>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}

export default forwardRef(BenifitPlanSAReq);
