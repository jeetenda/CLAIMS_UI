import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import AppBar from "@material-ui/core/AppBar";
import TabPanel from "../../../SharedModules/TabPanel/TabPanel";
import { withRouter } from "react-router";
import React, { useState, useEffect , useRef} from "react";
import { Button } from "react-bootstrap";
import Axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import ExpansionPanel from "@material-ui/core/ExpansionPanel";
import ExpansionPanelSummary from "@material-ui/core/ExpansionPanelSummary";
import ExpansionPanelDetails from "@material-ui/core/ExpansionPanelDetails";
import Typography from "@material-ui/core/Typography";
import ExpandMoreIcon from "@material-ui/icons/ExpandMore";
import Spinner from "../../../SharedModules/Spinner/Spinner";
import MainbenifitPlan from "./MainBenifitPlan";
import BenifitPlanCoverage from "./BenifitPlanCoverage";
import * as Dropdowns from "../../../SharedModules/Dropdowns/dropdowns";
import {
  GET_APP_DROPDOWNS,
  GET_NETWORKID_DROPDOWN,
  GET_MAP_SET_ID,
  GET_SYSTEM_LIST_NONVV_DROPDOWNS,
} from "../../../SharedModules/Dropdowns/actions";
import { benefitPlanDetailsAction } from "../actions";
import { useDispatch, useSelector } from "react-redux";
import BenifitPlanForm from "./BanifitPlanForm";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import BenefitPlanLimits from "./BenefitPlanLimits";
import BenefitPlanCostShare from "./BenefitPlanCostShare";
import BenifitPlanSAReq from "./BenefitPlanSAReq";
import BenefitPlanCoInsLmt from "./BenefitPlanCoInsLmt";
import BPCostShareCoInsurance from "./BPCostShareCoInsurance";
import BenefitPlanDeductible from "./BenefitPlanDeductible";
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';

function a11yProps(index) {
  return {
    id: `scrollable-auto-tab-${index}`,
    "aria-controls": `scrollable-auto-tabpanel-${index}`,
  };
}

function BenifitPlanAdd(props) {
  const dispatch = useDispatch();
  const printRef = useRef();
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector((state) => state.appDropDowns.appdropdowns);
  const onNetworkidDropdown = () => dispatch(GET_NETWORKID_DROPDOWN());
  const onMapSetIdDropdown = () => dispatch(GET_MAP_SET_ID());
  const onNonVvDropdown = (values) => dispatch(GET_SYSTEM_LIST_NONVV_DROPDOWNS(values));
  const nonVvDropdown = useSelector(state => state.appDropDowns.nonvvdropdowns);
  
  const onSearchView = (searchvalues) =>
    dispatch(benefitPlanDetailsAction(searchvalues));
  const networkidDropdown = useSelector(
    (state) => state.appDropDowns.networkIdDropdown
  );
  const mapIdDropdown = useSelector(
    (state) => state.appDropDowns.mapIDDropdown
  );
  const [tabValue, setTabValue] = useState(0);
  const [newState, setNewState] = useState([]);
  const [newSaReqState, setNewSaReqState] = useState([]);
  const [newCovState, setNewCovState] = useState([]);
  const [benefitPlanLimit, setNewBenefitPlantLimit] = useState([]);
  const [benefitPlanCopay, setNewBenefitPlanCopay] = useState([]);
  const [benefitPlanCopayLimit, setNewBenefitPlantCopayLimit] = useState([]);
  const [benefitPlanCoInsurance, setNewBenefitPlantCoInsurance] = useState([]);
  const [bpCoInsDeleteItems,setbpCoInsDeleteItems] = useState([]);
  const [deleteCoInsLmt, setDeleteCoInsLmt] = useState([]);
  const [newCoInsState, setNewCoInsLmt] = useState([]);
  const [newCohortState, setNewCohortState] = useState([]);
  const [deleteCohortRow, setDeleteCohortRow] = useState([]);
  const [tabChangeValue, setTabChangeValue] = useState({mainTab: false,coverageTab:false,SaReqTab:false
    ,capitationTab:false,planLimitTab:false,copayTab:false,copaylimitTab:false,
    coinsuranceTab:false,coinsurancelimitTab:false,deductibleTab:false });
    const mainTabRef = useRef();
    const coverageRef = useRef();
    const saRef = useRef();
    const planLimitRef = useRef();
    const costshareRef = useRef();
    const coInsRef = useRef();
    const coInsLmtRef = useRef();
    const deductibleRef = useRef();

  const [values, setValues] = useState({});
  const [
    {
      nwtAssReqErr,
      lobIdError,
      benefitPlanIDError,
      benefitPlanDescError,
      planBeginDateError,
      planEndDateError,
      showBgdtGTEnddtErr,
      beginDtInvalidErr,
      endDtInvalidErr,
      failInvalidErr,
      planTypeErr,
      planOptionErr,
      planStatusErr,
      currprocErr,
      retroprocErr,
      networkStatusErr,
      mapIdErr,
      coverageBeginDateError,
      coverageEndDateError,
      coverageRankError,
      coverageinvalidRankErr,
      saBeginDateError,
      saEndDateError,
      saNetworkStatusErr,
      samapidError,
      saRankError,
      // saRuleError,
      sainvalidRankErr,
      benefitPlanIdSpclCharErr,
      businessUnitdSpclCharErr,
      planDescSpclCharErr
    },
    setShowError,
  ] = React.useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [deleteRow, setDeleteRow] = useState([]);
  const [bpDeductableState, setBpDeductableState] = useState([]);
  const [deductibleDeleteRow, setDeductibleDeleteRow] = useState([]);
  const [mainValues, setMainValues] = useState({
    planType: "-1",
    optionsCode: "-1",
    benefitPlanStatCode: "-1",
  });
  const [coverageValues, setCoverageValues] = useState({
    benefitPlanNetworkStatusCode: "-1",
    mapSetID: "-1",
    beginDate: "",
    endDate: "",
    exceptionCode: "",
    seqNum: "",
    coverageInd: "1",
  });

  const [capitationValues, setcapitationValues] = useState({
    currentProcCode: "-1",
    retroProcCode: "-1",
    futureProcCode: "-1",
  });

  const [holdbackVo1Values, setholdbackVo1Values] = useState({
    funcAreaCode: "-1",
    sysParamNum: "-1",
  });

  const [holdbackVo2Values, setholdbackVo2Values] = useState({
    funcAreaCode: "-1",
    sysParamNum: "-1",
  });

  const [saReqValues, setSaReqValues] = useState({
    benefitPlanStatusNetworkCode: -1,
    mapSetID: -1,
    beginDate: "",
    endDate: "",
    saMetExceptionCode: "",
    saOverExceptionCode: "",
    ruleCode: -1,
    seqNum: "",
  });

  const [updateTest, setUpdateTest] = useState(new Date());
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [formValues, setFormValues] = useState({
    lobId: "",
    lobDesc: "",
    benefitPlanID: "",
    endDate: "12/31/9999",
    beginDate: "",
    benefitPlanAddlDesc: "",
    benefitPlanDesc: "",
  });
  const handleTabChange = (event, newValue) => {
    if (tabValue == 0 ) {
      if (tabChangeValue.mainTab || tabChangeValue.capitationTab) {
    mainTabRef.current.validateFn();
      }
      setTabValue(newValue);
    }else if (tabValue == 1) {
      if (tabChangeValue.coverageTab) {
        coverageRef.current.validateFn();
      }
      setTabValue(newValue);
    }
    else if (tabValue == 2) {
      if (tabChangeValue.SaReqTab) {
        saRef.current.validateFn();
      }
      setTabValue(newValue);
    }
    else if (tabValue == 3) {
      if (tabChangeValue.planLimitTab) {
        planLimitRef.current.validateFn();
      }
      setTabValue(newValue);
    } else if (tabValue == 4) {
      if (tabChangeValue.copayTab || tabChangeValue.copaylimitTab ) {
        costshareRef.current.validateFn();
      }
      if(tabChangeValue.coinsuranceTab){
       coInsRef.current.validateFn();
        }
      if(tabChangeValue.coinsurancelimitTab){
          coInsLmtRef.current.validateFn();
           }
      if(tabChangeValue.deductibleTab){
            deductibleRef.current.validateFn();
      }
      
    setTabValue(newValue);

    } else {
      setTabValue(newValue);
    }
  };

  const handleChanges = (name) => (event) => {
    if (name == "lobId") {
      try {
        setFormValues({
          ...formValues,
          lobDesc: event.nativeEvent.target.innerText.split("-")[1],
          [name]: event.target.value,
        });
      } catch (e) {
        setFormValues({ ...formValues, [name]: event.target.value });
      }
    } else {
      name == "benefitPlanID"
        ? setFormValues({
            ...formValues,
            [name]: event.target.value.toUpperCase(),
          })
        : setFormValues({ ...formValues, [name]: event.target.value });
    }
  };

  const handleDCDtChange = (name, date) => {
    setFormValues({ ...formValues, [name]: date });
  };

  const handleMainChanges = (name) => (event) => {
  //  setTabChangeValue({ ...tabChangeValue, mainTab: true })
    setMainValues({ ...mainValues, [name]: event.target.value });
    
    if( event.target.value == "2"||
     parseInt( event.target.value) == 2|| parseInt( event.target.value) == 3|| event.target.value=="3") {
      var index = errorMessages.indexOf(ErrorConst.Current_Procedure_Error);
      if(index!==-1)errorMessages.splice(index, 1);
      var index1 = errorMessages.indexOf(ErrorConst.Retro_Procedure_Error);
      if(index1!==-1)errorMessages.splice(index, 1);
      
    }
  };

  const handleCapitationChanges = (name) => (event) => {
    setcapitationValues({ ...capitationValues, [name]: event.target.value });
  };

  const handleholdbackVo1Changes = (name) => event => {
    setholdbackVo1Values({...holdbackVo1Values,[name]: event.target.value,
     updFlag : true
    })
}

const handleholdbackVo2Changes = (name) => event => {
    setholdbackVo2Values({...holdbackVo2Values,[name]: event.target.value,
        updFlag : true
       })
   }

  const handleCoverageChanges = (name) => (event) => {
    if (name == "coverageInd") {
      setCoverageValues({
        ...coverageValues,
        [name]: (event.target.value = event.target.value == "Y" ? "1" : "0"),
      });
    } else {
      setCoverageValues({ ...coverageValues, [name]: event.target.value });
    }
  };

  const handleSaReqChanges = (name) => (event) => {
    setSaReqValues({ ...saReqValues, [name]: event.target.value });
  };

  const handleSADtChange = (name, date) => {
    setSaReqValues({ ...saReqValues, [name]: date });
  };

  const handleCovDtChange = (name, date) => {
    setCoverageValues({ ...coverageValues, [name]: date });
  };

  useEffect(() => {
    onNonVvDropdown([
      Dropdowns.SYSTEM_PARAMETER_NUMBER,
      Dropdowns.SYSTEM_PARAMETER_NUMBER_2,
      Dropdowns.FUNCTIONAL_AREA_CODE,
      Dropdowns.FUNCTIONAL_AREA_CODE_2,
      Dropdowns.RETRO_PROC_CODE_21,
      Dropdowns.RETRO_PROC_CODE_31,
      Dropdowns.RETRO_PROC_CODE_41,
      Dropdowns.CURRENT_PROC_CODE_20,
      Dropdowns.CURRENT_PROC_CODE_30,
      Dropdowns.CURRENT_PROC_CODE_40,
      Dropdowns.FUTURE_PROC_CODE,
    ]);
    onDropdowns([
      Dropdowns.BENEFIT_PLAN_TYPE,
      Dropdowns.CO_INSURANCE_TYPE_CODE,
      Dropdowns.REV_LOB,
      Dropdowns.NW_STATUS,
      Dropdowns.MAP_SET_ID,
      Dropdowns.PROVIDER_TYPE,
      Dropdowns.SERVICE_TYPE_PROIVDER,
      Dropdowns.LIMIT_TY_CODE,
      Dropdowns.BYPASS_IF_CATEGORY_FUNCTIONAL_AREA,
      Dropdowns.COPAY_TYPE_CODE,
      Dropdowns.PROVIDER_NETWORK,
      Dropdowns.BENEFIT_PLAN_OPTION,
      Dropdowns.BENEFIT_PLAN_STATUS,
      Dropdowns.SA_RULE,
      Dropdowns.INS_LMT_TYPE_CODE,
      Dropdowns.DEDUCTIBLE_CODE,
      Dropdowns.RATE_TYPE_CODE,
    ]);
    onNetworkidDropdown();
    onMapSetIdDropdown();
  }, []);

  const addBenefitPlan = () => {
    props.history.push({
      pathname: "/BenefitPlanAdd",
    });
  };

  const majorSave = () => {
    seterrorMessages([]);
    setSuccessMessages([]);

    let reqFieldArr = [];
    let alphaNumRegex = /^[0-9a-zA-Z \s-]+$/;
    setShowError({
      lobIdError:
        formValues.lobId && formValues.lobId != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.LOB_ID_Error);
              return true;
            })(),
      benefitPlanIDError: formValues.benefitPlanID
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Benefit_Plan_ID_Error);
            return true;
          })(),
      benefitPlanDescError: formValues.benefitPlanDesc
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Benefit_Plan_Desc_Error);
            return true;
          })(),
      planBeginDateError: formValues.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      planEndDateError: formValues.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      planTypeErr:
        mainValues.planType && mainValues.planType != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Benefit_Plan_Type_Error);
              return true;
            })(),
      planOptionErr: !(
        isNaN(mainValues.optionsCode) || parseInt(mainValues.optionsCode) == -1
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Benefit_Plan_Option_Error);
            return true;
          })(),
      planStatusErr:
        mainValues.benefitPlanStatCode && mainValues.benefitPlanStatCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Benefit_Plan_Status_Error);
              return true;
            })(),
      beginDtInvalidErr:
        formValues.beginDate.toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formValues.endDate.toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_End_Date_Error);
              return true;
            })()
          : false,
      failInvalidErr:
        formValues.beginDate == formValues.endDate
          ? (() => {
              reqFieldArr.push(ErrorConst.Fail_End_Date_Error);
              return true;
            })()
          : false,
      showBgdtGTEnddtErr:
        formValues.endDate.toString() != "Invalid Date" &&
        new Date(formValues.beginDate) > new Date(formValues.endDate)
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_Begin_Date_Error);
              return true;
            })()
          : false,
          currprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.currentProcCode && capitationValues.currentProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Current_Procedure_Error);return true;})():false,
          retroprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.retroProcCode && capitationValues.retroProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Retro_Procedure_Error);return true;})():false,

           });

    if (reqFieldArr.length) {
      seterrorMessages(reqFieldArr);
      return false;
    }
    if (formValues.benefitPlanID!=="" && !alphaNumRegex.test(formValues.benefitPlanID)) {
      setShowError({
        benefitPlanIdSpclCharErr: true,
      });
      reqFieldArr.push(ErrorConst.BENEFIT_PLAN_ID_SPCL_CHAR_ERR);
      seterrorMessages(reqFieldArr);
      return false;
    }
    if (formValues.benefitPlanAddlDesc!=="" && !alphaNumRegex.test(formValues.benefitPlanAddlDesc)) {
      setShowError({
        businessUnitdSpclCharErr: true,
      });
      reqFieldArr.push(ErrorConst.BENEFIT_BUSS_UNIT_SPCL_CHAR_ERR);
      seterrorMessages(reqFieldArr);
      return false;
    }
    if (formValues.benefitPlanDesc!=="" && !alphaNumRegex.test(formValues.benefitPlanDesc)) {
      setShowError({
        planDescSpclCharErr: true,
      });
      reqFieldArr.push(ErrorConst.BENEFIT_PLAN_DESC_SPCL_CHAR_ERR);
      seterrorMessages(reqFieldArr);
      return false;
    }

    setSuccessMessages([]);
    setspinnerLoader(true);
    //add service
    const data = {
      auditUserID: "JavaUnitTesting",
      auditTimeStamp: "2020-02-26T07:08:02.337+0000",
      addedAuditUserID: "JavaUnitTesting",
      addedAuditTimeStamp: "2020-02-26T07:08:02.337+0000",
      versionNo: 0,
      dbRecord: false,
      sortColumn: null,
      auditKeyList: [],
      auditKeyListFiltered: false,
      planType: mainValues.planType,
      lobId:
        formValues.lobId && formValues.lobId != "-1" ? formValues.lobId : "",
      lobDesc: formValues.lobDesc,
      benefitPlanID: formValues.benefitPlanID,
      optionsCode: mainValues.optionsCode,
      benefitPlanStatCode: mainValues.benefitPlanStatCode,
      code: mainValues.planType,
      endDate: formValues.endDate,
      beginDate: formValues.beginDate,
      benefitPlanDesc: formValues.benefitPlanDesc,
      benefitPlanAddlDesc: formValues.benefitPlanAddlDesc,
      benefitPlanCoIns: benefitPlanCoInsurance,
      benefitPlanCoInsLMT: newCoInsState,
      benefitPlanCoPay: benefitPlanCopay,
      benefitPlanCoPayLMT: benefitPlanCopayLimit,
      benefitPlanCutBackCntl: [],
      benefitPlanCoverage: newCovState,
      benefitPlanDeductable: bpDeductableState,
      // "benefitPlanLimit": [],
      benefitPlanLimit: benefitPlanLimit,
      benefitPlanNwAssoc: newState,
      benefitPlanOOP: [],
      benefitPlanSA: newSaReqState,
      benefitPlanCohort: newCohortState,
      benefitPlanRank: null,
      caseMgmnt: [{
        addedAuditTimeStamp: null,
        addedAuditUserID: null,
        auditTimeStamp: null,
        auditUserID: null,
        currentProcCode: capitationValues.currentProcCode == -1 ? null : capitationValues.currentProcCode ,
        currentVersionNo: 3,
        dbCurrentProcCode: capitationValues.dbCurrentProcCode == -1 ? null : capitationValues.dbCurrentProcCode,
        dbRecord: false,
        dbRetroProcCode: capitationValues.retroProcCode == -1 ? null : capitationValues.retroProcCode,
        futureProcCode: capitationValues.futureProcCode == -1 ? null : capitationValues.futureProcCode ,
        futureVersionNo: 0,
        retroProcCode: capitationValues.retroProcCode == -1 ? null : capitationValues.retroProcCode,
        retroVersionNo: 3,
        sortColumn: null,
        versionNo: 3

      }],
      bpCohortDeleteItems: deleteCohortRow,
      bpNwAssocDeleteItems: deleteRow,
      bpCoverageDeleteItems: null,
      bpSADeleteItems: null,
      bpLimitsDeleteItems: null,
      bpCoPayDeleteItems: null,
      bpCoPayLimitDeleteItems: null,
      bpCoInsDeleteItems: null,
      bpCoInsLimitDeleteItems: null,
      bpDeductibleDeleteItems: null,
      bpOOPDeleteItems: null,
      bpCutBackCntlDeleteItems: null,
      benefitPlanMCOProcedure: null,
      ratePCBenefitPlan: null,
      ratePCProviderBenefitPlan: null,
      rateRCBenefitPlan: null,
      benefitPlanToId: null,
      benefitPlanFromId: null,
      eligibilityMCTMaps: [],
      hiosPlanID: null,
      dbEndDate: formValues.endDate,
      dbBeginDate: formValues.beginDate,
      dbDesc: formValues.benefitPlanDesc,
      dbAddlDesc: formValues.benefitPlanAddlDesc,
      dbTypeCode: mainValues.planType,
      dbOptionsCode: mainValues.optionsCode,
      dbBenefitPlanStatCode: mainValues.benefitPlanStatCode,
      benefitPlanMCOHoldbackVO1: {
        auditUserID: "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp: "2013-01-31T00:23:48.000+0000",
        addedAuditUserID: "wf_NH_MC_BP_SETUPV99",
        addedAuditTimeStamp: "2013-01-31T00:23:48.000+0000",
        versionNo: 0,
        dbRecord: false,
        sortColumn: null,
        funcAreaCode: holdbackVo1Values.funcAreaCode == -1 ? null : holdbackVo1Values.funcAreaCode ,
        sysParamNum: holdbackVo1Values.sysParamNum == -1 ? null : holdbackVo1Values.sysParamNum,
        updFlag: holdbackVo1Values.funcAreaCode == -1 && holdbackVo1Values.sysParamNum == -1 ? false : true,
      },
      benefitPlanMCOHoldbackVO2: {
        auditUserID: "wf_NH_MC_BP_SETUPV99",
        auditTimeStamp: "2013-01-31T00:23:48.000+0000",
        addedAuditUserID: "wf_NH_MC_BP_SETUPV99",
        addedAuditTimeStamp: "2013-01-31T00:23:48.000+0000",
        versionNo: 0,
        dbRecord: false,
        sortColumn: null,
        funcAreaCode: holdbackVo2Values.funcAreaCode == -1 ? null : holdbackVo2Values.funcAreaCode,
        sysParamNum: holdbackVo2Values.sysParamNum == -1 ? null : holdbackVo2Values.sysParamNum ,
        updFlag: holdbackVo1Values.funcAreaCode == -1 && holdbackVo1Values.sysParamNum == -1 ? false : true,
      },
      noteSetSK: null,
    };

    Axios.post(
      `${serviceEndPoint.BENEFIT_PLAN_CREATE_ENDPOINT}/JavaUnitTesting`,
      data
    )
      .then((res) => {
        if (res.data && res.data.message == "BP_SAVE_SUCCESSFULL") {
          serviceSuccessHandel();
        } else {
          seterrorMessages([
            res.data && res.data.message
              ? res.data.message
              : "Benefit Plan not added.",
          ]);
          //console.log(res.data.message);
        }
        setspinnerLoader(false);
      })
      .catch((e) => {
        setspinnerLoader(false);
        seterrorMessages([e.message]);
      });
  };

  const serviceSuccessHandel = () => {
    // setSuccessMessages(["Procedure code added successfully."])
    props.setShowSuccessMessage(true);
    onSearchView({
      benefitPlanID: formValues.benefitPlanID,
      lobCode: formValues.lobId,
    });
  };

  const majorValidations = () => {
  seterrorMessages([]);
    setSuccessMessages([]);

    let reqFieldArr = [];
    let alphaNumRegex = /^[0-9a-zA-Z \s-]+$/;
    setShowError({
      lobIdError:
        formValues.lobId && formValues.lobId != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.LOB_ID_Error);
              return true;
            })(),
      benefitPlanIDError: formValues.benefitPlanID
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Benefit_Plan_ID_Error);
            return true;
          })(),
      benefitPlanDescError: formValues.benefitPlanDesc
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Benefit_Plan_Desc_Error);
            return true;
          })(),
      planBeginDateError: formValues.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      planEndDateError: formValues.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      planTypeErr:
        mainValues.planType && mainValues.planType != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Benefit_Plan_Type_Error);
              return true;
            })(),
      planOptionErr: !(
        isNaN(mainValues.optionsCode) || parseInt(mainValues.optionsCode) == -1
      )
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Benefit_Plan_Option_Error);
            return true;
          })(),
      planStatusErr:
        mainValues.benefitPlanStatCode && mainValues.benefitPlanStatCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Benefit_Plan_Status_Error);
              return true;
            })(),
      beginDtInvalidErr:
        formValues.beginDate.toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formValues.endDate.toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_End_Date_Error);
              return true;
            })()
          : false,
      failInvalidErr:
        formValues.beginDate == formValues.endDate
          ? (() => {
              reqFieldArr.push(ErrorConst.Fail_End_Date_Error);
              return true;
            })()
          : false,
      showBgdtGTEnddtErr:
        formValues.endDate.toString() != "Invalid Date" &&
        new Date(formValues.beginDate) > new Date(formValues.endDate)
          ? (() => {
              reqFieldArr.push(ErrorConst.Plan_Begin_Date_Error);
              return true;
            })()
          : false,
          currprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.currentProcCode && capitationValues.currentProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Current_Procedure_Error);return true;})():false,
          retroprocErr: (mainValues.planType == 'Q' || mainValues.planType == 'M' || mainValues.optionsCode == '1') && capitationValues.retroProcCode && capitationValues.retroProcCode == -1 ? (()=>{reqFieldArr.push(ErrorConst.Retro_Procedure_Error);return true;})():false,

           });
           

    if (reqFieldArr.length) {
      seterrorMessages(reqFieldArr);
      return false;
    }
    if (formValues.benefitPlanID!=="" && !alphaNumRegex.test(formValues.benefitPlanID)) {
      setShowError({
        benefitPlanIdSpclCharErr: true,
      });
      reqFieldArr.push(ErrorConst.BENEFIT_PLAN_ID_SPCL_CHAR_ERR);
      seterrorMessages(reqFieldArr);
      return false;
    }
    if (formValues.benefitPlanAddlDesc!=="" && !alphaNumRegex.test(formValues.benefitPlanAddlDesc)) {
      setShowError({
        businessUnitdSpclCharErr: true,
      });
      reqFieldArr.push(ErrorConst.BENEFIT_BUSS_UNIT_SPCL_CHAR_ERR);
      seterrorMessages(reqFieldArr);
      return false;
    }
    if (formValues.benefitPlanDesc!=="" && !alphaNumRegex.test(formValues.benefitPlanDesc)) {
      setShowError({
        planDescSpclCharErr: true,
      });
      reqFieldArr.push(ErrorConst.BENEFIT_PLAN_DESC_SPCL_CHAR_ERR);
      seterrorMessages(reqFieldArr);
      return false;
    }
    return true;
  }
  
  const searchBenefitPlan = () => {
    props.setCancelType(true)
    props.history.push({
      pathname: '/SearchBenefitPlan'
    })
  }

  return (
    <div className="tabs-container">
      {spinnerLoader ? <Spinner /> : null}
      {errorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert" role="alert">
          {errorMessages.map((message) => (
            <li>{message}</li>
          ))}
        </div>
      ) : null}
      {successMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {successMessages.map((message) => (
            <li>{message}</li>
          ))}
        </div>
      ) : null}
      <div className="mb-2">
        <BreadCrumbs
          parent="Benefits"
          child1="Search Benefit Plan"
          child2="Add Benefit Plan"
          path="SearchBenefitPlan"
        />
      </div>
      <div className="tab-container" ref={printRef}>
      <div className="tab-header">
        <h1 className="page-heading float-left">Add Benefit Plan</h1>
        <div className="float-right th-btnGroup">
          <Button
            title="Save"
            variant="outlined"
            color="primary"
            className="btn btn-ic btn-save"
            onClick={() => majorSave()}
            disabled={props.privileges && !props.privileges.add? 'disabled':'' }
          >
            Save
          </Button>
          <Button
            title="Notes"
            variant="outlined"
            color="primary"
            className="btn btn-ic btn-notes"
          >
            Notes
          </Button>
          <Button
            title="Audit Log"
            variant="outlined"
            color="primary"
            className="btn btn-transparent"
          >
            AUDIT LOG
          </Button>
          <Button
            title="Cancel"
            variant="outlined"
            color="primary"
            className="btn btn-cancel"
            onClick={() => searchBenefitPlan()}
          >
            Cancel
          </Button>
          <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))}
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-primary">
              <i className="fa fa-print" />
              Print
            </Button>)}
              content={() => printRef.current}
            />
        
          <Button
            title="Help"
            variant="outlined"
            color="primary"
            className="btn btn-ic btn-help"
          >
            Help
          </Button>
        </div>
      </div>
      <div className="tab-body mt-3">
        <BenifitPlanForm
          values={formValues}
          handleChanges={handleChanges}
          updateTest={updateTest}
          handleDCDtChange={handleDCDtChange}
          dropdowns={addDropdowns}
          errors={{
            lobIdError,
            benefitPlanIDError,
            benefitPlanDescError,
            planBeginDateError,
            beginDtInvalidErr,
            planEndDateError,
            showBgdtGTEnddtErr,
            endDtInvalidErr,
            failInvalidErr,
            benefitPlanIdSpclCharErr,
            businessUnitdSpclCharErr,
            planDescSpclCharErr
          }}
        />
        <div className="form-wrap-inner">
          <div className="tab-body-bordered my-2">
            <div className="tab-holder custom-tabber pb-3">
              <AppBar position="static" color="default">
                <Tabs
                  value={tabValue}
                  onChange={handleTabChange}
                  aria-label="simple tabs example"
                >
                  <Tab
                  className={tabChangeValue.mainTab || tabChangeValue.capitationTab ? "tab-error" : ""}
                    title="Benefit Plan-Main"
                    label="Benefit Plan-Main"
                    {...a11yProps(0)}
                  />
                  <Tab 
                  className={tabChangeValue.coverageTab? "tab-error" : ""}
                  title="Coverage" label="Coverage" {...a11yProps(1)} />
                  <Tab
                   className={tabChangeValue.SaReqTab? "tab-error" : ""}
                    title="SA Requirements"
                    label="SA Requirements"
                    {...a11yProps(2)}
                  />
                  <Tab
                   className={tabChangeValue.planLimitTab? "tab-error" : ""}
                   title="Plan Limits"
                    label="Plan Limits"
                    {...a11yProps(3)}
                  />
                  <Tab
                   className={tabChangeValue.copayTab || tabChangeValue.copaylimitTab || 
                              tabChangeValue.coinsuranceTab || tabChangeValue.coinsurancelimitTab || 
                              tabChangeValue.deductibleTab ? "tab-error" : ""}
                    title="Cost Share"
                    label="Cost Share"
                    {...a11yProps(4)}
                  />
                </Tabs>
              </AppBar>

              <TabPanel value={tabValue} index={0}>
                <MainbenifitPlan
                  setNewState={setNewState}
                  seterrorMessages={seterrorMessages}
                  handleChanges={handleChanges}
                  newState={newState}
                  dropdowns={addDropdowns}
                  networkidDropdown={networkidDropdown}
                  formValues={formValues}
                  setShowError={setShowError}
                  mainValues={mainValues}
                  setMainValues={setMainValues}
                  handleMainChanges={handleMainChanges}
                  values={values}
                  errors={{ planTypeErr, planOptionErr, planStatusErr }}
                  deleteRow={deleteRow}
                  setDeleteRow={setDeleteRow}
                  capitationValues={capitationValues}
                  setcapitationValues={setcapitationValues}
                  handleCapitationChanges={handleCapitationChanges}
                  setholdbackVo1Values={setholdbackVo1Values}
                  holdbackVo1Values={holdbackVo1Values}
                  setholdbackVo2Values={setholdbackVo2Values}
                  holdbackVo2Values={holdbackVo2Values}
                  setNewCohortState={setNewCohortState}
                  newCohortState={newCohortState}
                  handleholdbackVo2Changes={handleholdbackVo2Changes}
                  handleholdbackVo1Changes={handleholdbackVo1Changes}
                  mapIdDropdown={mapIdDropdown}
                  deleteCohortRow={deleteCohortRow}
                  setDeleteCohortRow={setDeleteCohortRow}
                  nonVvDropdown={nonVvDropdown}
                  currprocErr = {currprocErr}
                  retroprocErr = {retroprocErr}
                  tabChangeValue = {tabChangeValue}
                  setTabChangeValue = {setTabChangeValue}
                  ref={mainTabRef}
                  majorValidations = {majorValidations}
                />
              </TabPanel>
              <TabPanel value={tabValue} index={1}>
                <BenifitPlanCoverage
                  newCovState={newCovState}
                  setNewCovState={setNewCovState}
                  seterrorMessages={seterrorMessages}
                  handleChanges={handleChanges}
                  newState={newState}
                  dropdowns={addDropdowns}
                  networkidDropdown={networkidDropdown}
                  formValues={formValues}
                  mapIdDropdown={mapIdDropdown}
                  setShowError={setShowError}
                  add={true}
                  coverageValues={coverageValues}
                  setCoverageValues={setCoverageValues}
                  handleCovDtChange={handleCovDtChange}
                  handleCoverageChanges={handleCoverageChanges}
                  values={values}
                  tabChangeValue = {tabChangeValue}
                  setTabChangeValue = {setTabChangeValue}
                  ref = {coverageRef}
                  majorValidations = {majorValidations}

                />
              </TabPanel>
              <TabPanel value={tabValue} index={2}>
                <BenifitPlanSAReq
                  newSaReqState={newSaReqState}
                  setNewSaReqState={setNewSaReqState}
                  seterrorMessages={seterrorMessages}
                  handleChanges={handleChanges}
                  newState={newState}
                  dropdowns={addDropdowns}
                  networkidDropdown={networkidDropdown}
                  formValues={formValues}
                  mapIdDropdown={mapIdDropdown}
                  setShowError={setShowError}
                  add={true}
                  saReqValues={saReqValues}
                  setSaReqValues={setSaReqValues}
                  handleSADtChange={handleSADtChange}
                  handleSaReqChanges={handleSaReqChanges}
                  values={values}
                  tabChangeValue = {tabChangeValue}
                  setTabChangeValue = {setTabChangeValue}
                  ref = {saRef}
                  majorValidations = {majorValidations}

                />
              </TabPanel>
              <TabPanel value={tabValue} index={3}>
                <BenefitPlanLimits
                  benefitPlanLimit={benefitPlanLimit}
                  seterrorMessages={seterrorMessages}
                  formValues={formValues}
                  mapIdDropdown={mapIdDropdown}
                  setNewBenefitPlantLimit={setNewBenefitPlantLimit}
                  dropdowns={addDropdowns}
                  tabChangeValue = {tabChangeValue}
                  setTabChangeValue = {setTabChangeValue}
                  ref = {planLimitRef}
                  majorValidations = {majorValidations}

                />
              </TabPanel>
              <TabPanel value={tabValue} index={4}>
                <BenefitPlanCostShare
                  benefitPlanCopay={benefitPlanCopay}
                  setNewBenefitPlanCopay={setNewBenefitPlanCopay}
                  dropdowns={addDropdowns}
                  mapIdDropdown={mapIdDropdown}
                  benefitPlanCopayLimit={benefitPlanCopayLimit}
                  setNewBenefitPlantCopayLimit={setNewBenefitPlantCopayLimit}
                  newCoInsState={newCoInsState}
                  setNewCoInsLmt={setNewCoInsLmt}
                  bpDeductableState={bpDeductableState}
                  setBpDeductableState={setBpDeductableState}
                  formValues={formValues}
                  setShowError={setShowError}
                  seterrorMessages={seterrorMessages}
                  deductibleDeleteRow={deductibleDeleteRow}
                  setDeductibleDeleteRow={setDeductibleDeleteRow}
                  benefitPlanCoInsurance={benefitPlanCoInsurance}
                  setNewBenefitPlantCoInsurance={setNewBenefitPlantCoInsurance}
                    tabChangeValue = {tabChangeValue}
                  setTabChangeValue = {setTabChangeValue}
                  ref = {costshareRef}
                  majorValidations = {majorValidations}
                />
                
      <BPCostShareCoInsurance
        coInsuranceData={benefitPlanCoInsurance}
        setNewBenefitPlantCoInsurance={setNewBenefitPlantCoInsurance}
        coInsuranceDropdowns={addDropdowns}
        mapDropdown={mapIdDropdown}
        seterrorMessages={seterrorMessages}
        setbpCoInsDeleteItems={setbpCoInsDeleteItems}
        bpCoInsDeleteItems={bpCoInsDeleteItems}
        formValues={formValues}
        tabChangeValue = {tabChangeValue}
        setTabChangeValue = {setTabChangeValue}
        ref = {coInsRef}
                  majorValidations = {majorValidations}
      />

      
        <BenefitPlanCoInsLmt
          dropdowns={addDropdowns}
          coInsuranceData={benefitPlanCoInsurance}
          setDeleteCoInsLmt={setDeleteCoInsLmt}
          deleteCoInsLmt={deleteCoInsLmt}
          mapIdDropdown={mapIdDropdown}
          setShowError={setShowError}
          seterrorMessages={seterrorMessages}
          newCoInsState={newCoInsState}
          setNewCoInsLmt={setNewCoInsLmt}
          formValues={formValues}
          tabChangeValue = {tabChangeValue}
          setTabChangeValue = {setTabChangeValue}
          ref = {coInsLmtRef}
          majorValidations = {majorValidations}

        />
      

      <BenefitPlanDeductible
        dropdowns={addDropdowns}
        mapIdDropdown={mapIdDropdown}
        setShowError={setShowError}
        seterrorMessages={seterrorMessages}
        bpDeductableState={bpDeductableState}
        setBpDeductableState={setBpDeductableState}
        formValues={formValues}
        deductibleDeleteRow={deductibleDeleteRow}
        setDeductibleDeleteRow={setDeductibleDeleteRow}
        tabChangeValue = {tabChangeValue}
        setTabChangeValue = {setTabChangeValue}
        ref = {deductibleRef}
        majorValidations = {majorValidations}

      />
              </TabPanel>
            </div>
          </div>
        </div>
        <Footer print />
      </div>
    </div>
    </div>
  );
}

export default withRouter(BenifitPlanAdd);
