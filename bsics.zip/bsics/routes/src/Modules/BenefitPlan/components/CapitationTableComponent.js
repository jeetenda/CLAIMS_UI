import React, { useEffect, useState } from "react";
import { withRouter } from "react-router";
import TableComponent from "../../../SharedModules/Table/Table";

function CapitationTableComponent(props) {
	const headCells = [
        {
			id: "nwStatCodeDesc",
			numeric: false,
			disablePadding: false,
			label: "Network Status",
			enableHyperLink: true,
			fontSize: 12
		},
		{
			id: "mapID",
			numeric: false,
			disablePadding: false,
			label: "Map ID",
			enableHyperLink: false,
			fontSize: 12
        },
		{
			id: "begDate",
			numeric: false,
			disablePadding: true,
			label: "Begin Date",
			fontSize: 12
		},
		{
			id: "endDate",
			numeric: false,
			isDate: true,
			disablePadding: false,
			label: "End Date",
			enableHyperLink: false,
			fontSize: 12
        },
        {
			id: "rateTypeCodeDesc",
			numeric: false,
			disablePadding: false,
			label: "Rate Type Code",
			enableHyperLink: false,
			fontSize: 12
        },	
	
        {
			id: "rate",
			numeric: false,
			disablePadding: false,
			label: "Rate",
			enableHyperLink: false,
			fontSize: 12
        },
        
        
		{
			id: "seqNum",
			numeric: false,
			disablePadding: false,
			label: "Rank",
			enableHyperLink: false,
			fontSize: 12
		}
	];

	const getTableData = data => {
		if (data && data.length) {
			let tData = JSON.stringify(data); 
			tData = JSON.parse(tData);     
			tData.map((each,index) => {
				each.index = index;
			}); 
      return tData;
		} else {
			return [];
		}
	};

	const editRow = row => event => {
		props.setTabChangeValue({ ...props.tabChangeValue, capitationTab: false });
		props.HBPscrolltoView();
		props.setSuccess(false);
		props.setbanifitPlan(true);
		props.setnewProviderDate({
		begDate: row.begDate,
		endDate: row.endDate,
		nwStatCode: row.nwStatCode,
		seqNum: row.seqNum,
        mapID: row.mapID,
        nwStatCodeDesc: row.nwStatCodeDesc,
		rateTypeCode:row.rateTypeCode,
		rateTypeCodeDesc: row.rateTypeCodeDesc,
        rate:row.rate,
		index: row.index,
		row: row
		});
		props.setresetProviderDate({
		begDate: row.begDate,
		endDate: row.endDate,
		nwStatCode: row.nwStatCode,
		seqNum: row.seqNum,
        mapID: row.mapID,
        nwStatCodeDesc: row.nwStatCodeDesc,
		rateTypeCode:row.rateTypeCode,
		rateTypeCodeDesc: row.rateTypeCodeDesc,
        rate:row.rate,
	    index: row.index,
		row: row
		});
	};

	return (
		<TableComponent
			headCells={headCells}
			tableData={getTableData(props.tabelRowData)}
			onTableRowClick={editRow}
			defaultSortColumn="seqNum"
			selected={props.selectDeleteArray} setSelected={props.setSelectDeleteArray} multiDelete
		/>
	);
}
export default withRouter(CapitationTableComponent);
