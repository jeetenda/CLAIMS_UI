import React, { useEffect, useState } from "react";
import { withRouter } from "react-router";
import TableComponent from "../../../SharedModules/Table/Table";

function DeductableTableComponent(props) {
  const headCells = [
    {
      id: "bpNetworkCodeDesc",
      numeric: false,
      disablePadding: false,
      label: "Network Status",
      enableHyperLink: true,
      fontSize: 12,
    },
    {
      id: "mapSetID",
      numeric: false,
      disablePadding: false,
      label: "Map ID",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "beginDate",
      numeric: false,
      isDate: true,
      disablePadding: true,
      label: "Begin Date",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "endDate",
      numeric: false,
      isDate: true,
      disablePadding: false,
      label: "End Date",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "typeCode",
      numeric: false,
      disablePadding: false,
      label: "Code",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "allLimits",
      numeric: true,
      disablePadding: false,
      label: "Limits I/I+1/F",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "applyOopNum",
      numeric: false,
      disablePadding: false,
      label: "Percent Applied to OOP Max",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "exceptionCode",
      numeric: false,
      disablePadding: false,
      label: "Deductible Met Exception Code",
      enableHyperLink: false,
      fontSize: 12,
      isToolTip: true,
      toolTip: "clmExcnDesc",
    },
    {
      id: "seqNum",
      numeric: false,
      disablePadding: false,
      label: "Rank",
      enableHyperLink: false,
      fontSize: 12,
    },
  ];

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
        each.allLimits = `${each.indAmt}/ ${each.indPlusAmt}/ ${each.famAmt}`;
      });
      return tData;
    } else {
      return [];
    }
  };

  const editRow = (row) => (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, deductibleTab: false });
    props.BPDDscrolltoViewedit();
    props.setShowDeductable(true);
    props.setNewDeductable({
      beginDate: row.beginDate,
      endDate: row.endDate,
      mapSetID: row.mapSetID,
      benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
      typeCode: row.typeCode,
      indLimit: row.indAmt,
      indPlusLimit: row.indPlusAmt,
      famalyLimit: row.famAmt,
      percAppOppMax: row.applyOopNum,
      exceptionCode: row.exceptionCode,
      seqNum: row.seqNum,
      index: row.index,
      typeCodeDesc: row.typeCodeDesc,
      row: row,
    });

    props.setResetDeductable({
      beginDate: row.beginDate,
      endDate: row.endDate,
      mapSetID: row.mapSetID,
      benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
      typeCode: row.typeCode,
      indLimit: row.indAmt,
      indPlusLimit: row.indPlusAmt,
      famalyLimit: row.famAmt,
      percAppOppMax: row.applyOopNum,
      exceptionCode: row.exceptionCode,
      seqNum: row.seqNum,
      index: row.index,
      typeCodeDesc: row.typeCodeDesc,
      row: row,
    });
  };

  return (
    <TableComponent
      headCells={headCells}
      tableData={getTableData(props.tabelRowData)}
      onTableRowClick={editRow}
      defaultSortColumn="diagnosisCode"
		 selected={props.selectDeleteArray} setSelected={props.setSelectDeleteArray} multiDelete

    />
  );
}
export default withRouter(DeductableTableComponent);
