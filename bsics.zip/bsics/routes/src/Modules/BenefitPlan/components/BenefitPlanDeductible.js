import React, { useState, useEffect, useRef,forwardRef,useImperativeHandle } from "react";
import MenuItem from "@material-ui/core/MenuItem";
import TextField from "@material-ui/core/TextField";
import DateFnsUtils from "@date-io/date-fns";
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import dateFnsFormat from "date-fns/format";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import * as moment from "moment";
import "moment-range";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import DeductableTableComponent from "./DeductableTableComponent";
import { Button } from "react-bootstrap";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker,
} from "@material-ui/pickers";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import axios from "axios";
import { Link } from "react-router-dom";

function BenefitPlanDeductible(props,ref) {
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [showDeductable, setShowDeductable] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [success, setSuccess] = useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  // const [newDeductable, setnewDeductable] = useState({
  const [newDeductable, setNewDeductable] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    mapSetID: "-1",
    benefitPlanStatusNetworkCode: "-1",
    typeCode: "-1",
    indLimit: "",
    indPlusLimit: "",
    famalyLimit: "",
    percAppOppMax: "",
    exceptionCode: "",
    seqNum: "",
    bpNetworkCodeDesc: "",
    typeCodeDesc: "",
  });
  // const [resetCoInsPlan, setresetCoInsPlan] = useState({
  const [resetDeductable, setResetDeductable] = useState({
    beginDate: "",
    endDate: "12/31/9999",
    mapSetID: "-1",
    benefitPlanStatusNetworkCode: "-1",
    typeCode: "-1",
    indLimit: "",
    indPlusLimit: "",
    famalyLimit: "",
    percAppOppMax: "",
    exceptionCode: "",
    seqNum: "",
    bpNetworkCodeDesc: "",
    typeCodeDesc: "",
  });

  const [selectedCovEndDate, setSelectedCovEndDate] = React.useState("");
  const [selectedCovBeginDate, setSelectedCovBeginDate] = React.useState("");
  const [
    {
      showHeaderDateErr,
      showHeaderEndDateErr,
      showBeginDateError,
      showEndDateError,
      beginDtInvalidErr,
      endDtInvalidErr,
      showRankOverlapErr,
      typeCodeErr,
      showPerAppReqErr,
      showPerAppIndErr,
      showNetworkOverlapErr,
      networkStatusError,
      mapIdErr,
      rankError,
      showRankErrSpe,
      showRankErrZero,
      showBgdtGTEnddtErr,
      RankErr,
      showIndLmtReqErr,
      showIndLimInvErr,
      showIndPlusInvErr,
      showFamInvErr,
      INVALID_LMT_MET_EXC_CODE,
      INVALID_LMT_MET_EXC_CODE_SPL,
    },
    setShowError,
  ] = React.useState(false);

  const formatDate = (dt) => {
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const handelDateRngeWithin = (
    rangeStartDate,
    rangeEndDate,
    withInStartDate,
    withInEndDate
  ) => {
    if (rangeStartDate && rangeEndDate && withInStartDate && withInEndDate) {
      const range = moment().range(
        new Date(rangeStartDate),
        new Date(rangeEndDate)
      );
      return (
        range.contains(new Date(withInStartDate)) &&
        range.contains(new Date(withInEndDate))
      );
    }
    return false;
  };

  const handelDateRngeOverlap = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate
  ) => {
    const range1 = moment().range(
      new Date(initalStartDate),
      new Date(initialEndDate)
    );
    const range2 = moment().range(
      new Date(secondaryStartDate),
      new Date(secondaryEndDate)
    );
    return range1.overlaps(range2);
  };

  const handelDateNetworkArrayOverlap = (
    initalStartDate,
    initialEndDate,
    networkId,
    networkstatus,
    typeCode,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (
            each.mapSetID == networkId &&
            each.benefitPlanStatusNetworkCode == networkstatus &&
            each.beginDate == initalStartDate &&
            each.typeCode == typeCode
          ) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRankArrayOverlap = (
    initalStartDate,
    initialEndDate,
    Rank,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (each.seqNum == Rank) {
            return true;
          }
          return false;
        }
      });
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handleCoverageBeginDateChange = (d) => {
    setSelectedCovBeginDate(d);
    let finaldate = formatDate(d);
    props.handleCovDtChange("beginDate", finaldate);
  };

  const handleCoverageEndDateChange = (d) => {
    setSelectedCovEndDate(d);
    let finaldate = formatDate(d);
    props.handleCovDtChange("endDate", finaldate);
  };

  const handelInputChange = (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, deductibleTab: true })
    if (event.target.name === "benefitPlanStatusNetworkCode") {
      setNewDeductable({
        ...newDeductable,
        [event.target.name]: event.target.value,
        bpNetworkCodeDesc: event.nativeEvent.target.textContent,
      });
    } else if (event.target.name === "typeCode") {
      setNewDeductable({
        ...newDeductable,
        [event.target.name]: event.target.value,
        typeCodeDesc: event.nativeEvent.target.textContent,
      });
    } else {
      setNewDeductable({
        ...newDeductable,
        [event.target.name]: event.target.value,
      });
    }
  };

  const handelDateChange = (name) => (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, deductibleTab: true })
    setNewDeductable({ ...newDeductable, [name]: date });
  };

  const validateExcCode = (c) => {
    return new Promise((resolve, reject) => {
      setspinnerLoader(true);
      axios
        .get(serviceEndPoint.BENEFIT_PLAN_EXC_CODE_VALIDATION + c+"/"+props.formValues.lobId)
        .then((response) => {
          if (response.data.data && response.data.data.excCodeDesc) {
            resolve(response.data.data.excCodeDesc);
          } else {
            resolve(false);
          }
        })
        .catch((error) => {
          resolve(false);
        })
        .then(() => {
          setspinnerLoader(false);
        });
    });
  };

  const handelClick = async () => {
    const tableData = props.bpDeductableState;
    let errors = {};
    setSuccess(false);
    setDeleteSuccess(false);
    props.seterrorMessages([]);
    let reqFieldArr = [];
    let overlapArray;
    if (newDeductable.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetDeductable.beginDate) ||
          e.endDate != formatDate(resetDeductable.endDate)
      );
    } else {
      overlapArray = tableData;
    }
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(newDeductable.beginDate),
      formatDate(newDeductable.endDate)
    );
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(newDeductable.beginDate),
      formatDate(newDeductable.endDate),
      newDeductable.mapSetID,
      newDeductable.benefitPlanStatusNetworkCode,
      newDeductable.typeCode,
      overlapArray
    );
    const rankOverlap = await handelDateRankArrayOverlap(
      formatDate(newDeductable.beginDate),
      formatDate(newDeductable.endDate),
      newDeductable.seqNum,
      overlapArray
    );
    setShowError({
      showBeginDateError: newDeductable.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.Begin_Date_Error);
            return true;
          })(),
      showEndDateError: newDeductable.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.End_Date_Error);
            return true;
          })(),
      beginDtInvalidErr:
        formatDate(newDeductable.beginDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
              return true;
            })()
          : false,
      endDtInvalidErr:
        formatDate(newDeductable.endDate).toString() == "Invalid Date"
          ? (() => {
              reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
              return true;
            })()
          : false,
      mapIdErr:
        newDeductable.mapSetID && newDeductable.mapSetID != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Map_Id_Error);
              return true;
            })(),
      networkStatusError:
        newDeductable.benefitPlanStatusNetworkCode &&
        newDeductable.benefitPlanStatusNetworkCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Network_Status_Error);
              return true;
            })(),
      rankError: newDeductable.seqNum.length < 1
        ? (() => {
          reqFieldArr.push(ErrorConst.Rank_Error);
          return true;
        })()
        : false,
      showRankErrSpe: !isNaN(parseInt(newDeductable.seqNum))
        ? false
        : (() => {
          if (newDeductable.seqNum.length !== 0) {
            reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
            return true;
          } else return false;
        })(),
      showRankErrZero: newDeductable.seqNum < 1 && newDeductable.seqNum.length
        ? (() => {
          reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
          return true;
        })()
        : false,
      showBgdtGTEnddtErr:
        new Date(newDeductable.beginDate) <= new Date(newDeductable.endDate)
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
              return true;
            })(),
      // RankErr: !(
      //   isNaN(newDeductable.seqNum) || parseInt(newDeductable.seqNum) > 99999
      // )
      //   ? false
      //   : (() => {
      //       reqFieldArr.push(ErrorConst.Invalid_Rank_Error);
      //       return true;
      //     })(),
      // showHeaderDateErr:
      //   !headerTange && newDeductable.beginDate
      //     ? (() => {
      //         reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk);
      //         return true;
      //       })()
      //     : false,
      showHeaderDateErr:
      !(new Date(newDeductable.beginDate) >= new Date(props.formValues.beginDate) && new Date(newDeductable.beginDate) <= new Date(props.formValues.endDate))
        ? (() => {
            reqFieldArr.push(
              ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
            );
            return true;
          })()
        : false,
          showHeaderEndDateErr:
          !(new Date(newDeductable.endDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_End_Date_Err 
                );
                return true;
              })()
            : false,
      showNetworkOverlapErr:
        newDeductable.beginDate &&
        newDeductable.endDate &&
        newDeductable.mapSetID &&
        newDeductable.benefitPlanStatusNetworkCode &&
        newDeductable.typeCode &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.DEDUCATIBLE_OVERLAP_ERROR);
              return true;
            })()
          : false,
      showRankOverlapErr:
        newDeductable.beginDate &&
        newDeductable.endDate &&
        newDeductable.seqNum &&
        rankOverlap
          ? (() => {
              reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
              return true;
            })()
          : false,

      showPerAppIndErr: !(
        parseFloat(newDeductable.percAppOppMax) <= 100.0 &&
        parseInt(newDeductable.percAppOppMax) >= 0
      )
        ? (() => {
            reqFieldArr.length = 0;
            reqFieldArr.push(ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET);
            return true;
          })()
        : false,
      showPerAppReqErr:
        newDeductable.percAppOppMax.toString().length == 0
          ? (() => {
              reqFieldArr.length = 0;
              reqFieldArr.push(
                ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
              );
              return true;
            })()
          : false,
      typeCodeErr:
        newDeductable.typeCode && newDeductable.typeCode != -1
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.DEDUCT_TYPE_CODE_ERR);
              return true;
            })(),
      showIndLmtReqErr: newDeductable.indLimit
        ? false
        : (() => {
            reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
            return true;
          })(),
      showIndLimInvErr:
        newDeductable.indLimit && !isNaN(parseInt(newDeductable.indLimit))
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
              return true;
            })(),
      showIndPlusInvErr:
        newDeductable.indPlusLimit &&
        isNaN(parseInt(newDeductable.indPlusLimit))
          ? (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
              return true;
            })()
          : false,
      showFamInvErr:
        newDeductable.famalyLimit && isNaN(parseInt(newDeductable.famalyLimit))
          ? (() => {
              reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
              return true;
            })()
          : false,
    });
    props.setShowError({
      planBeginDateError: props.formValues.beginDate ? false : true,
      planEndDateError: props.formValues.endDate ? false : true,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    // let clmExcnDesc = await validateExcCode(newDeductable.exceptionCode);
    // if (!clmExcnDesc && newDeductable.exceptionCode) {
    //   errors["INVALID_EXC_CODE"] = true;
    //   reqFieldArr.push(ErrorConst.INVALID_EXCEPTION_CODE);
    // }
    let clmExcnDesc = "";
    if (newDeductable.exceptionCode) {
      if (isNaN(parseInt(newDeductable.exceptionCode))) {
        errors["INVALID_LMT_MET_EXC_CODE_SPL"] = true;
        reqFieldArr.push(ErrorConst.INVALID_SPL_EXC_CODE);
      } else {
        let clmExcnDesc = await validateExcCode(newDeductable.exceptionCode);
        if (!clmExcnDesc) {
          errors["INVALID_LMT_MET_EXC_CODE"] = true;
          reqFieldArr.push(ErrorConst.DEDUCTABLE_INVALID_EXC_CODE);
        }
      }
    }

    if (reqFieldArr.length) {
      setShowError(errors);
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    const data = {
      auditUserID: "X3434",
      auditTimeStamp: new Date(),
      addedAuditUserID: "JavaUnitTesting",
      addedAuditTimeStamp: new Date(),
      versionNo:
        newDeductable.row && newDeductable.row.versionNo
          ? newDeductable.row.versionNo
          : 0,
      dbRecord: false,
      sortColumn: null,
      auditKeyList: [],
      auditKeyListFiltered: false,
      benefitPlanDeductableID:
        newDeductable.row && newDeductable.row.benefitPlanDeductableID
          ? newDeductable.row.benefitPlanDeductableID
          : null,
      benefitPlanStatusNetworkCode: newDeductable.benefitPlanStatusNetworkCode,
      beginDate: formatDate(newDeductable.beginDate),
      typeCode: newDeductable.typeCode,
      mapSetID: newDeductable.mapSetID,
      applyOopNum: newDeductable.percAppOppMax,
      seqNum: newDeductable.seqNum,
      exceptionCode:
        newDeductable.exceptionCode == "" ? null : newDeductable.exceptionCode,
      endDate: formatDate(newDeductable.endDate),
      indPlusAmt:
        newDeductable.indPlusLimit == "" ? "0.00" : newDeductable.indPlusLimit,
      indAmt: newDeductable.indLimit == "" ? "0.00" : newDeductable.indLimit,
      famAmt:
        newDeductable.famalyLimit == "" ? "0.00" : newDeductable.famalyLimit,
      clmExcnDesc: clmExcnDesc ? clmExcnDesc : "",
      bpNetworkCodeDesc: newDeductable.bpNetworkCodeDesc,
      typeCodeDesc: newDeductable.typeCodeDesc,
    };
    newDeductable.index > -1
      ? (tableData[newDeductable.index] = data)
      : tableData.push(data);
    
    props.setBpDeductableState(tableData);
    setSuccess(true);

    setNewDeductable({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      indLimit: "",
      indPlusLimit: "",
      famalyLimit: "",
      percAppOppMax: "",
      exceptionCode: "",
      seqNum: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    setResetDeductable({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      indLimit: "",
      indPlusLimit: "",
      famalyLimit: "",
      percAppOppMax: "",
      exceptionCode: "",
      seqNum: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    setShowDeductable(false);
    props.setTabChangeValue({ ...props.tabChangeValue, deductibleTab: false })

  };

  const handelResetClick = () => {
    setNewDeductable(resetDeductable);
    setShowError(false);
    props.seterrorMessages([]);
    props.setTabChangeValue({ ...props.tabChangeValue, deductibleTab: false })
  };

  const handelCandelFunction = () => {
    setShowDeductable(false);
    setShowError(false);
    setDialogOpen(false);
    setDialogType("");
    setNewDeductable({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      indLimit: "",
      indPlusLimit: "",
      famalyLimit: "",
      percAppOppMax: "",
      exceptionCode: "",
      seqNum: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    setResetDeductable({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      indLimit: "",
      indPlusLimit: "",
      famalyLimit: "",
      percAppOppMax: "",
      exceptionCode: "",
      seqNum: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    props.seterrorMessages([]);
  };

  const handelDeleteClick = () => {
    props.seterrorMessages([]);
    const tableData = props.bpDeductableState;
    if (newDeductable.row && newDeductable.row.benefitPlanDeductableID) {
      let deleteData = props.deductibleDeleteRow;
      deleteData.push({
        auditUserID: newDeductable.row.auditUserID,
        auditTimeStamp: new Date(),
        addedAuditUserID: newDeductable.row.addedAuditUserID,
        addedAuditTimeStamp: new Date(),
        versionNo:
          newDeductable.row && newDeductable.row.versionNo
            ? newDeductable.row.versionNo
            : 0,
        dbRecord: false,
        sortColumn: null,
        auditKeyList: [],
        auditKeyListFiltered: false,
        benefitPlanDeductableID:
          newDeductable.row && newDeductable.row.benefitPlanDeductableID
            ? newDeductable.row.benefitPlanDeductableID
            : null,
        benefitPlanStatusNetworkCode:
          newDeductable.row.benefitPlanStatusNetworkCode,
        beginDate: newDeductable.row.beginDate,
        typeCode: newDeductable.row.typeCode,
        mapSetID: newDeductable.row.mapSetID,
        applyOopNum: newDeductable.row.applyOopNum,
        seqNum: newDeductable.row.seqNum,
        exceptionCode: newDeductable.row.exceptionCode,
        endDate: newDeductable.row.endDate,
        indPlusAmt: newDeductable.row.indPlusAmt,
        indAmt: newDeductable.row.indAmt,
        famAmt: newDeductable.row.famAmt,
        clmExcnDesc: "",
        bpNetworkCodeDesc: newDeductable.row.bpNetworkCodeDesc,
        typeCodeDesc: newDeductable.row.typeCodeDesc,
      });
      props.setDeductibleDeleteRow(deleteData);
    }
    tableData.splice(newDeductable.index, 1);
    props.setBpDeductableState(tableData);
    setShowError(false);
    setNewDeductable({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      indLimit: "",
      indPlusLimit: "",
      famalyLimit: "",
      percAppOppMax: "",
      exceptionCode: "",
      seqNum: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    setResetDeductable({
      beginDate: "",
      endDate: "12/31/9999",
      mapSetID: "-1",
      benefitPlanStatusNetworkCode: "-1",
      typeCode: "-1",
      indLimit: "",
      indPlusLimit: "",
      famalyLimit: "",
      percAppOppMax: "",
      exceptionCode: "",
      seqNum: "",
      bpNetworkCodeDesc: "",
      typeCodeDesc: "",
    });
    setShowDeductable(false);
    setDialogOpen(false);
    setDialogType("");
    setDeleteSuccess(true);
  };
  const multiDelete = () => {
    setDialogOpen(false); setDialogType('');
    props.seterrorMessages([]);
    setSuccessMessages([]);
    if (selectDeleteArray.length > 0) {
        let CI = props.bpDeductableState;
        selectDeleteArray.map((value, index) => {
          let curIndex = CI.findIndex(i => moment(i.beginDate).isSame(value.beginDate));
          CI.splice(curIndex,1);
        });
        props.setBpDeductableState(CI);
        props.setDeductibleDeleteRow(selectDeleteArray);
        setSelectDeleteArray([]);
        setDeleteSuccess(true);

    }
  }


  useImperativeHandle(ref, () => {
    return { validateFn };
  });

  const validateFn = () => {
    if (props.tabChangeValue.deductibleTab) {
      handelSaveValidationsDeductible();
    } 
    }

    const handelSaveValidationsDeductible = async() => {
      const tableData = props.bpDeductableState;
      let errors = {};
      setSuccess(false);
      setDeleteSuccess(false);
      props.seterrorMessages([]);
      let reqFieldArr = [];
      let overlapArray;
      if (newDeductable.index > -1) {
        overlapArray = tableData.filter(
          (e) =>
            e.beginDate != formatDate(resetDeductable.beginDate) ||
            e.endDate != formatDate(resetDeductable.endDate)
        );
      } else {
        overlapArray = tableData;
      }
      const headerTange = await handelDateRngeWithin(
        formatDate(props.formValues.beginDate),
        formatDate(props.formValues.endDate),
        formatDate(newDeductable.beginDate),
        formatDate(newDeductable.endDate)
      );
      const networkOverlap = await handelDateNetworkArrayOverlap(
        formatDate(newDeductable.beginDate),
        formatDate(newDeductable.endDate),
        newDeductable.mapSetID,
        newDeductable.benefitPlanStatusNetworkCode,
        newDeductable.typeCode,
        overlapArray
      );
      const rankOverlap = await handelDateRankArrayOverlap(
        formatDate(newDeductable.beginDate),
        formatDate(newDeductable.endDate),
        newDeductable.seqNum,
        overlapArray
      );
      setShowError({
        showBeginDateError: newDeductable.beginDate
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.Begin_Date_Error);
              return true;
            })(),
        showEndDateError: newDeductable.endDate
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.End_Date_Error);
              return true;
            })(),
        beginDtInvalidErr:
          formatDate(newDeductable.beginDate).toString() == "Invalid Date"
            ? (() => {
                reqFieldArr.push(ErrorConst.Invalid_Begin_Date_Error);
                return true;
              })()
            : false,
        endDtInvalidErr:
          formatDate(newDeductable.endDate).toString() == "Invalid Date"
            ? (() => {
                reqFieldArr.push(ErrorConst.Invalid_End_Date_Error);
                return true;
              })()
            : false,
        mapIdErr:
          newDeductable.mapSetID && newDeductable.mapSetID != -1
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Map_Id_Error);
                return true;
              })(),
        networkStatusError:
          newDeductable.benefitPlanStatusNetworkCode &&
          newDeductable.benefitPlanStatusNetworkCode != -1
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Network_Status_Error);
                return true;
              })(),
        rankError: newDeductable.seqNum.length < 1
          ? (() => {
            reqFieldArr.push(ErrorConst.Rank_Error);
            return true;
          })()
          : false,
        showRankErrSpe: !isNaN(parseInt(newDeductable.seqNum))
          ? false
          : (() => {
            if (newDeductable.seqNum.length !== 0) {
              reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR);
              return true;
            } else return false;
          })(),
        showRankErrZero: newDeductable.seqNum < 1 && newDeductable.seqNum.length
          ? (() => {
            reqFieldArr.push(ErrorConst.BENEFIT_PLAN_RANKING_ZERO);
            return true;
          })()
          : false,
        showBgdtGTEnddtErr:
          new Date(newDeductable.beginDate) <= new Date(newDeductable.endDate)
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.Bgndt_GT_Enddt_Err);
                return true;
              })(),
      
        // showHeaderDateErr:
        //   !headerTange && newDeductable.beginDate
        //     ? (() => {
        //         reqFieldArr.push(ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk);
        //         return true;
        //       })()
        //     : false,
        showHeaderDateErr:
            !(new Date(newDeductable.beginDate) >= new Date(props.formValues.beginDate) && new Date(newDeductable.beginDate) <= new Date(props.formValues.endDate))
              ? (() => {
                  reqFieldArr.push(
                    ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                  );
                  return true;
                })()
              : false,
            showHeaderEndDateErr:
            !(new Date(newDeductable.endDate) <= new Date(props.formValues.endDate))
              ? (() => {
                  reqFieldArr.push(
                    ErrorConst.Fall_In_Header_End_Date_Err 
                  );
                  return true;
                })()
              : false,
            // End header date error
        showNetworkOverlapErr:
          newDeductable.beginDate &&
          newDeductable.endDate &&
          newDeductable.mapSetID &&
          newDeductable.benefitPlanStatusNetworkCode &&
          newDeductable.typeCode &&
          networkOverlap
            ? (() => {
                reqFieldArr.push(ErrorConst.DEDUCATIBLE_OVERLAP_ERROR);
                return true;
              })()
            : false,
        showRankOverlapErr:
          newDeductable.beginDate &&
          newDeductable.endDate &&
          newDeductable.seqNum &&
          rankOverlap
            ? (() => {
                reqFieldArr.push(ErrorConst.RANK_TABLE_OVERLAP);
                return true;
              })()
            : false,
  
        showPerAppIndErr: !(
          parseFloat(newDeductable.percAppOppMax) <= 100.0 &&
          parseInt(newDeductable.percAppOppMax) >= 0
        )
          ? (() => {
              reqFieldArr.length = 0;
              reqFieldArr.push(ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET);
              return true;
            })()
          : false,
        showPerAppReqErr:
          newDeductable.percAppOppMax.toString().length == 0
            ? (() => {
                reqFieldArr.length = 0;
                reqFieldArr.push(
                  ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
                );
                return true;
              })()
            : false,
        typeCodeErr:
          newDeductable.typeCode && newDeductable.typeCode != -1
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.DEDUCT_TYPE_CODE_ERR);
                return true;
              })(),
        showIndLmtReqErr: newDeductable.indLimit
          ? false
          : (() => {
              reqFieldArr.push(ErrorConst.INDIVIDUAL_LIMIT);
              return true;
            })(),
        showIndLimInvErr:
          newDeductable.indLimit && !isNaN(parseInt(newDeductable.indLimit))
            ? false
            : (() => {
                reqFieldArr.push(ErrorConst.INVALID_IND_LIMIT);
                return true;
              })(),
        showIndPlusInvErr:
          newDeductable.indPlusLimit &&
          isNaN(parseInt(newDeductable.indPlusLimit))
            ? (() => {
                reqFieldArr.push(ErrorConst.INVALID_IND_PLUS_LIMIT);
                return true;
              })()
            : false,
        showFamInvErr:
          newDeductable.famalyLimit && isNaN(parseInt(newDeductable.famalyLimit))
            ? (() => {
                reqFieldArr.push(ErrorConst.INVALID_IND_FAM_LIMIT);
                return true;
              })()
            : false,
      });
      props.setShowError({
        planBeginDateError: props.formValues.beginDate ? false : true,
        planEndDateError: props.formValues.endDate ? false : true,
      });
  
      if (reqFieldArr.length) {
        props.seterrorMessages(reqFieldArr);
        return false;
      }
  
      let clmExcnDesc = "";
      if (newDeductable.exceptionCode) {
        if (isNaN(parseInt(newDeductable.exceptionCode))) {
          errors["INVALID_LMT_MET_EXC_CODE_SPL"] = true;
          reqFieldArr.push(ErrorConst.INVALID_SPL_EXC_CODE);
        } else {
          let clmExcnDesc = await validateExcCode(newDeductable.exceptionCode);
          if (!clmExcnDesc) {
            errors["INVALID_LMT_MET_EXC_CODE"] = true;
            reqFieldArr.push(ErrorConst.DEDUCTABLE_INVALID_EXC_CODE);
          }
        }
      }
  
      if (reqFieldArr.length) {
        setShowError(errors);
        props.seterrorMessages(reqFieldArr);
        return false;
      }
  
    }

    const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
    const BPDDrefdiv1 = useRef(null);
    const BPDDscrolltoViewedit = () => {
      setTimeout(function () {
        scrollToRef(BPDDrefdiv1);
      }.bind(this), 500);
    }; 
    
  
  return (
    <>
      <div className="pos-relative">{/*webninja*/}</div>
      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
      <DialogContent>
        <DialogContentText id="alert-dialog-description">
          {dialogType == "Delete" || dialogType == "multiDelete"
            ? "Are you sure that you want to Delete."
            : dialogType == "Cancel" 
            ? "Changes you made may not be saved." : ""}
        </DialogContentText>
      </DialogContent>
      <DialogActions>
          <Button title="Ok" onClick={() => {
            dialogType == "Delete"
              ? handelDeleteClick() :
            dialogType == "multiDelete"
              ? multiDelete()
            : handelCandelFunction();
          }} color="primary" className="btn btn-success">
              Ok
          </Button>
          <Button title="Cancel"  onClick={() => { setDialogOpen(false); setDialogType(''); }} color="primary" autoFocus>
              Cancel
          </Button>
      </DialogActions>
      </Dialog>
      
      {deleteSuccess ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
        </div>
      ) : null}

      {success ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.SUCCESSFULLY_SAVED_INFORMATION}
        </div>
      ) : null}
      <div className="tab-container mt-3">
          <div className="tab-header">
            <h3 className="tab-heading float-left">Benefit Plan - Deductible</h3>
           
            <div className="float-right th-btnGroup">
            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => {setDialogOpen(true); setDialogType('multiDelete');}}>
                          <i className="fa fa-trash" />

                        </Button>
              <Button
                title="Add Deductible"
                variant="outlined"
                color="primary"
                className="btn btn-secondary btn-icon-only"
                onClick={() => {
                  if( props.majorValidations()){
                  props.setTabChangeValue({ ...props.tabChangeValue, deductibleTab: true })
                  setShowDeductable(true);
                  setSuccess(false);
                  setDeleteSuccess(false);
                  setNewDeductable({
                    beginDate: "",
                    endDate: "12/31/9999",
                    mapSetID: "-1",
                    benefitPlanStatusNetworkCode: "-1",
                    typeCode: "-1",
                    indLimit: "",
                    indPlusLimit: "",
                    famalyLimit: "",
                    percAppOppMax: "",
                    exceptionCode: "",
                    seqNum: "",
                    bpNetworkCodeDesc: "",
                    typeCodeDesc: "",
                  });
                  setResetDeductable({
                    beginDate: "",
                    endDate: "12/31/9999",
                    mapSetID: "-1",
                    benefitPlanStatusNetworkCode: "-1",
                    typeCode: "-1",
                    indLimit: "",
                    indPlusLimit: "",
                    famalyLimit: "",
                    percAppOppMax: "",
                    exceptionCode: "",
                    seqNum: "",
                    bpNetworkCodeDesc: "",
                    typeCodeDesc: "",
                  });
                  BPDDscrolltoViewedit();
                }}}
              >
                <i className="fa fa-plus" />
              </Button>
            </div>
            <div className="clearfix" />
          </div>
        <div className="tab-holder mt-2">
          <DeductableTableComponent
            tabelRowData={props.bpDeductableState}
            setShowDeductable={setShowDeductable}
            setNewDeductable={setNewDeductable}
            setResetDeductable={setResetDeductable}
            setTabChangeValue = {props.setTabChangeValue}
            selectDeleteArray={selectDeleteArray}
            setSelectDeleteArray={setSelectDeleteArray}
            BPDDscrolltoViewedit={BPDDscrolltoViewedit}
          />
        </div>
      </div>

      {showDeductable ? (
        <div
          className="tabs-container tabs-container-inner mt-0"
          ref={BPDDrefdiv1}
        >
          <div className="tab-header">
            <h3 className="tab-heading float-left">
              {newDeductable.index > -1 ? "Edit Deductible" : "New Deductible"}
            </h3>
            <div className="float-right th-btnGroup">
              <Button
                title={newDeductable.index > -1 ? "Update" : "Add"}
                variant="outlined"
                color="primary"
                className=""
                className={newDeductable.index > -1 ? "btn btn-ic btn-update" : "btn btn-ic btn-add"}
                onClick={() => handelClick()}
                disabled={props.privileges && !props.privileges.add? 'disabled':'' }
              >
                {newDeductable.index > -1 ? "Update" : "Add"}
              </Button>
              {newDeductable.index > -1 ? (
                <Link to="MapDefinition" target="_blank" 
                    title="View/Edit Map"
                    className="btn btn-ic btn-view"
                  >
                    View/Edit Map
                 </Link>
              ) : null}
              {newDeductable.index > -1 ? (
                <Button
                  title="Delete"
                  variant="outlined"
                  color="primary"
                  className="btn btn-ic btn-delete"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("Delete");
                  }}
                >
                  Delete
                </Button>
              ) : null}
              <Button
                title="Reset"
                variant="outlined"
                color="primary"
                className="btn btn-ic btn-reset"
                onClick={() => handelResetClick()}
              >
                Reset
              </Button>
              <Button
                title="Cancel"
                variant="outlined"
                color="primary"
                className="btn btn-cancel"
                onClick={() => {
                  setDialogOpen(true);
                  setDialogType("Cancel");
                  props.setTabChangeValue({ ...props.tabChangeValue, deductibleTab: false })
                }}
              >
                Cancel
              </Button>
            </div>
          </div>
          <div className="tab-holder">
          <div className="tab-body-bordered mt-2">
            <div className="form-wrapper">
              {/* <h1 className="tab-heading float-left">Batch Data</h1> */}
              <div className="flex-block">
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                  <div
                    className="mui-custom-form input-md with-select"
                    style={{ marginLeft: "30px" }}
                  >
                    <KeyboardDatePicker
                      id="bgn_date_deductible_cost_share_tab"
                      name="begindate"
                      required
                      label="Begin Date"
                      format="MM/dd/yyyy"
                      InputLabelProps={{
                        shrink: true,
                      }}
                      placeholder="mm/dd/yyyy"
                      value={
                        !newDeductable.beginDate ||
                        newDeductable.beginDate == ""
                          ? null
                          : newDeductable.beginDate
                      }
                      onChange={handelDateChange("beginDate")}
                      helperText={
                        showHeaderDateErr
                          ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                          : showBeginDateError
                          ? ErrorConst.BEGIN_DATE_ERROR
                          : beginDtInvalidErr
                          ? ErrorConst.Invalid_Begin_Date_Error
                          : showBgdtGTEnddtErr
                          ? ErrorConst.DATE_RANGE_ERROR
                          : null
                      }
                      error={
                        showHeaderDateErr
                          ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                          : showBeginDateError
                          ? ErrorConst.BEGIN_DATE_ERROR
                          : beginDtInvalidErr
                          ? ErrorConst.Invalid_Begin_Date_Error
                          : showBgdtGTEnddtErr
                          ? ErrorConst.DATE_RANGE_ERROR
                          : null
                      }
                      KeyboardButtonProps={{
                        "aria-label": "change date",
                      }}
                    />
                  </div>
                </MuiPickersUtilsProvider>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                  <div
                    className="mui-custom-form input-md with-select"
                    style={{ marginLeft: "30px" }}
                  >
                    <KeyboardDatePicker
                      id="end_date_deductible_cost_share_tab"
                      name="endDate"
                      required
                      label="End Date"
                      format="MM/dd/yyyy"
                       
							        maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                      InputLabelProps={{
                        shrink: true,
                      }}
                      placeholder="mm/dd/yyyy"
                      value={
                        !newDeductable.endDate || newDeductable.endDate == ""
                          ? null
                          : newDeductable.endDate
                      }
                      onChange={handelDateChange("endDate")}
                      helperText={
                        showEndDateError
                          ? ErrorConst.END_DATE_ERROR
                          : endDtInvalidErr
                          ? ErrorConst.Invalid_End_Date_Error
                          : showHeaderEndDateErr
                          ? ErrorConst.Fall_In_Header_End_Date_Err
                          : null
                      }
                      error={
                        showEndDateError
                        ? ErrorConst.END_DATE_ERROR
                        : endDtInvalidErr
                        ? ErrorConst.Invalid_End_Date_Error
                        : showHeaderEndDateErr
                        ? ErrorConst.Fall_In_Header_End_Date_Err
                        : null
                      }
                      KeyboardButtonProps={{
                        "aria-label": "change date",
                      }}
                    />
                  </div>
                </MuiPickersUtilsProvider>
              </div>

              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    required
                    id="network_status_deductible_cost_share_tab"
                    select
                    name="benefitPlanStatusNetworkCode"
                    label="Network Status"
                    onChange={(event) => handelInputChange(event)}
                    value={newDeductable.benefitPlanStatusNetworkCode}
                    helperText={
                      networkStatusError
                        ? ErrorConst.Network_Status_Error
                        : null
                    }
                    error={
                      networkStatusError
                        ? ErrorConst.Network_Status_Error
                        : null
                    }
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {/* <MenuItem value="INN">INN-In Network</MenuItem> */}
                    {props.dropdowns &&
                      props.dropdowns["R1#R_BP_NW_STAT_CD"] &&
                      props.dropdowns["R1#R_BP_NW_STAT_CD"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="map_id_deductible_cost_share_tab"
                    select
                    required
                    name="mapSetID"
                    label="Map ID"
                    onChange={(event) => handelInputChange(event)}
                    value={newDeductable.mapSetID}
                    placeholder="Please Select One"
                    InputLabelProps={{
                      shrink: true,
                    }}
                    helperText={mapIdErr ? ErrorConst.Map_Id_Error : null}
                    error={mapIdErr ? ErrorConst.Map_Id_Error : null}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.mapIdDropdown &&
                      props.mapIdDropdown.map((each) => (
                        <MenuItem
                          selected
                          key={each.mapsetId}
                          value={each.mapsetId}
                        >
                          {each.mapsetId}-{each.mapDesc}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>
              </div>
              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="deduct_type_deductible_cost_share_tab"
                    select
                    required
                    name="typeCode"
                    label="Deductible Type Code"
                    onChange={(event) => handelInputChange(event)}
                    value={newDeductable.typeCode}
                    placeholder="Please Select One"
                    helperText={
                      typeCodeErr ? ErrorConst.DEDUCT_TYPE_CODE_ERR : null
                    }
                    error={typeCodeErr}
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem value="-1">Please Select One</MenuItem>
                    {props.dropdowns &&
                      props.dropdowns["R1#R_BP_DED_TY_CD"] &&
                      props.dropdowns["R1#R_BP_DED_TY_CD"].map((each) => (
                        <MenuItem selected key={each.code} value={each.code}>
                          {each.description}
                        </MenuItem>
                      ))}
                  </TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    required
                    name="indLimit"
                    onChange={(event) => handelInputChange(event)}
                    helperText={
                      showIndLmtReqErr
                        ? ErrorConst.INDIVIDUAL_LIMIT
                        : showIndLimInvErr
                        ? ErrorConst.INVALID_IND_LIMIT
                        : null
                    }
                    error={showIndLmtReqErr || showIndLimInvErr}
                    inputProps={{ maxLength: 14 }}
                    value={newDeductable.indLimit}
                    id="individual_limit_deductible_cost_share_tab"
                    label="Individual Limit"
                  ></TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    name="indPlusLimit"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 14 }}
                    value={newDeductable.indPlusLimit}
                    helperText={
                      showIndPlusInvErr
                        ? ErrorConst.INVALID_IND_PLUS_LIMIT
                        : null
                    }
                    error={showIndPlusInvErr}
                    id="indi_plus_deductible_cost_share_tab"
                    label="Individual +1 Limit"
                  ></TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    name="famalyLimit"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 14 }}
                    value={newDeductable.famalyLimit}
                    helperText={
                      showFamInvErr ? ErrorConst.INVALID_IND_FAM_LIMIT : null
                    }
                    error={showFamInvErr}
                    id="family_limit_deductible_cost_share_tab"
                    label="Family Limit"
                  ></TextField>
                </div>
              </div>
              <div className="flex-block">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    required
                    id="oop_max_deductible_cost_share_tab"
                    name="percAppOppMax"
                    label="Percent Applied to OOP Max"
                    inputProps={{ maxLength: 10 }}
                    onChange={(event) => handelInputChange(event)}
                    value={newDeductable.percAppOppMax}
                    helperText={
                      showPerAppReqErr
                        ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
                        : showPerAppIndErr
                        ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
                        : null
                    }
                    error={
                      showPerAppReqErr
                        ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
                        : showPerAppIndErr
                        ? ErrorConst.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
                        : null
                    }
                    InputLabelProps={{
                      shrink: true,
                    }}
                  ></TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="exception_code_deductible_cost_share_tab"
                    name="exceptionCode"
                    label="Deductible Met Exception Code"
                    inputProps={{ maxLength: 4 }}
                    onChange={(event) => handelInputChange(event)}
                    value={newDeductable.exceptionCode}
                    helperText={
                      INVALID_LMT_MET_EXC_CODE
                        ? ErrorConst.DEDUCTABLE_INVALID_EXC_CODE
                        : INVALID_LMT_MET_EXC_CODE_SPL
                        ? ErrorConst.INVALID_SPL_EXC_CODE
                        : null
                    }
                    error={
                      INVALID_LMT_MET_EXC_CODE
                        ? ErrorConst.DEDUCTABLE_INVALID_EXC_CODE
                        : INVALID_LMT_MET_EXC_CODE_SPL
                        ? ErrorConst.INVALID_SPL_EXC_CODE
                        : null
                    }
                    InputLabelProps={{
                      shrink: true,
                    }}
                  ></TextField>
                </div>

                <div className="mui-custom-form with-select input-md">
                  <TextField
                    InputLabelProps={{
                      shrink: true,
                    }}
                    required
                    id="rank_deductible_cost_share_tab"
                    name="seqNum"
                    onChange={(event) => handelInputChange(event)}
                    inputProps={{ maxLength: 6 }}
                    value={newDeductable.seqNum}                    
                    helperText={
                      rankError
                        ? ErrorConst.Rank_Error
                        : showRankErrSpe
                        ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO_ERROR
                        : showRankErrZero
                        ? ErrorConst.BENEFIT_PLAN_RANKING_ZERO
                        : null
                    }
                    error={
                      rankError
                        ? ErrorConst.Rank_Error
                        : RankErr
                        ? ErrorConst.Invalid_Rank_Error
                        : showRankOverlapErr
                        ? ErrorConst.RANK_TABLE_OVERLAP
                        : null
                    }
                    label="Rank"
                  ></TextField>
                </div>
              </div>
            </div>
          </div>
        </div>
        </div>
      ) : null}
    </>
  );
}

export default forwardRef(BenefitPlanDeductible);
