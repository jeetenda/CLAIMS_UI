import React, { useEffect, useState } from "react";
import { withRouter } from "react-router";
import TableComponent from "../../../SharedModules/Table/Table";

function SaReqTableComponent(props) {
    const headCells = [
        {
			id: "bpNWCodeDesc",
			numeric: false,
			disablePadding: false,
			label: "Network Status",
			enableHyperLink: true,
			fontSize: 12
        },
        {
			id: "mapSetID",
			numeric: false,
			disablePadding: false,
			label: "Map ID",
			enableHyperLink: false,
			fontSize: 12
		},
		{
			id: "beginDate",
			numeric: false,
			isDate: true,
			disablePadding: true,
			label: "Begin Date",
			enableHyperLink: false,
			fontSize: 12
		},
		{
			id: "endDate",
			numeric: false,
			isDate: true,
			disablePadding: false,
			label: "End Date",
			enableHyperLink: false,
			fontSize: 12
        },
     
        {
			id: "saMetExceptionCode",
			numeric: false,
			disablePadding: false,
			label: "Limit Met Exception Code",
			enableHyperLink: false,
			fontSize: 12,
			isToolTip:true,
			toolTip: "metExcnDesc"
        },
        {
			id: "saOverExceptionCode",
			numeric: false,
			disablePadding: false,
			label: "SA Over Exception Code",
			enableHyperLink: false,
			fontSize: 12,
			isToolTip:true,
			toolTip: "ovrExcnDesc"
        },
        {
			id: "saRuleCodeDesc",
			numeric: false,
			disablePadding: false,
			label: "SA Rule Code",
			enableHyperLink: false,
			fontSize: 12
		},
		{
			id: "seqNum",
			numeric: true,
			disablePadding: false,
			label: "Rank",
			enableHyperLink: false,
			fontSize: 12
        },
       
	];

	const getTableData = data => {
		if (data && data.length) {
			let tData = JSON.stringify(data); 
			tData = JSON.parse(tData);     
			tData.map((each,index) => {
				each.index = index;
			}); 
      return tData;
		} else {
			return [];
		}
	};

	const editRow = row => event => {
		props.setTabChangeValue({ ...props.tabChangeValue, SaReqTab: false });
		props.SARscrolltoView();
		props.setSaReqBenefitPlan(true);
		props.setnewSaReqPlan({
		beginDate: row.beginDate,
		endDate: row.endDate,
		mapSetID: row.mapSetID,
		benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
        saMetExceptionCode : row.saMetExceptionCode,
        saOverExceptionCode : row.saOverExceptionCode,
        ruleCode : row.ruleCode,
		seqNum : row.seqNum,
		bpNWCodeDesc:row.bpNWCodeDesc,
        saRuleCodeDesc : row.saRuleCodeDesc,
		index: row.index,
		row: row
        });
        
		props.setresetSaReqPlan({
            beginDate: row.beginDate,
            endDate: row.endDate,
            mapSetID: row.mapSetID,
            benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
            saMetExceptionCode : row.saMetExceptionCode,
            saOverExceptionCode : row.saOverExceptionCode,
            ruleCode : row.ruleCode,
			seqNum:row.seqNum,
			bpNWCodeDesc:row.bpNWCodeDesc,
        	saRuleCodeDesc : row.saRuleCodeDesc,
			index: row.index,
            row: row
		});
    };
	return (
		<TableComponent
			headCells={headCells}
			tableData={getTableData(props.tabelRowData)}
			onTableRowClick={editRow}
			defaultSortColumn="seqNum"
			selected={props.selectDeleteArray} setSelected={props.setSelectDeleteArray} multiDelete
		/>
	);
}
export default withRouter(SaReqTableComponent);
