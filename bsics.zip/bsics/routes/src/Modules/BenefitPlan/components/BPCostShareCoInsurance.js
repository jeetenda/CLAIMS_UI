import React, { useState, useRef, useEffect,forwardRef,useImperativeHandle } from "react";
import { withRouter } from "react-router";
import { Button } from "react-bootstrap";
import { makeStyles } from "@material-ui/core/styles";
import TableComponent from "../../../SharedModules/Table/Table";
import isSpecialcharecter from "./validations";

import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import * as moment from "moment";
import "moment-range";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from "@material-ui/core/InputAdornment";
import dateFnsFormat from "date-fns/format";
import * as ErrorMsgConstants from "../../../SharedModules/Messages/ErrorMsgConstants";
import Checkbox from "@material-ui/core/Checkbox";
import { useConfirm } from "../../../SharedModules/MUIConfirm/index";
import axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import Spinner from "../../../SharedModules/Spinner/Spinner";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import { Link } from "react-router-dom";

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}));

function BPCostShareCoInsurance(props,ref) {
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const muiconfirm = useConfirm();
  const classes = useStyles();
  const [canShowForm, setCanShowForm] = useState(false);
  const [deleteSuccess, setDeleteSuccess] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);
  const [
    {
      showNetworkStatusErr,
      showmapSetIDErr,
      showTypeCodErr,
      showCoInsAmtErr,
      ShowPercentErr,
      showApplyOopNumErr,
      EXC_CODE_NOT_MATCH_LOB,
      ShowRankErr,
      ShowRankErrSpe,
      ShowRankErrZero,
      showBeginDate,
      ShowEndDate,
      showNetworkOverlapErr,
      showPercentageAppliedtoEmptyErr,
      percentageErr,
      showHeaderDateErr,
      showHeaderEndDateErr
    },
    setShowError,
  ] = React.useState(false);
  const [tableData, setTableData] = useState([]);
  const voidRef = useRef();
  useEffect(() => {
    setTableData(props.coInsuranceData ? props.coInsuranceData : []);
  }, [props.coInsuranceData]);

  const headCells = [
    {
      id: "bpNetworkCodeDesc",
      numeric: false,
      dateHyperLink: true,
      disablePadding: true,
      label: "Network Status",
      enableHyperLink: true,
      fontSize: 12,
    },
    {
      id: "mapSetID",
      numeric: false,
      disablePadding: false,
      label: "Map ID",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "beginDate",
      numeric: false,
      disablePadding: false,
      label: "Begin Date",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "endDate",
      numeric: false,
      disablePadding: false,
      label: "End Date",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "typeCode",
      numeric: false,
      disablePadding: false,
      label: "Code",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "coInsAmt",
      numeric: false,
      disablePadding: false,
      label: "Amount",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "coInsPCT",
      numeric: false,
      disablePadding: false,
      label: "Percent",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "applyOopNum",
      numeric: false,
      disablePadding: false,
      label: "Percent Applied to OOP MAX",
      enableHyperLink: false,
      fontSize: 12,
    },
    {
      id: "exceptionCode",
      numeric: false,
      disablePadding: false,
      label: "Exc Code",
      enableHyperLink: false,
      fontSize: 12,
      isToolTip: true,
      toolTip: "clmExcnDesc",
    },
    {
      id: "seqNum",
      numeric: false,
      disablePadding: false,
      label: "Rank",
      enableHyperLink: false,
      fontSize: 12,
    },
  ];
  const defaultFormData = {
    benefitPlanStatusNetworkCode: "-1",
    mapSetID: "-1",
    typeCode: "-1",
    coInsAmt: "",
    coInsPCT: "",
    applyOopNum: "",
    beginDate: null,
    endDate: "12/31/9999",
    exceptionCode: "",
    seqNum: "",
  };
  let errors = {
    dtsNotInHdrLvl: false,
    bgDtGTEDtErr: false,
    bgDtReqErr: false,
    endDtReqErr: false,
    lobReqErr: false,
    fcReqErr: false,
    maxAlAmtReqErr: false,
    srcReqErr: false,
    reasonReqErr: false,
    maxUnitsReqErr: false,
    dtsOverlapError: false,
    maxAlAmtIncErr: false,
    maxUnitsIncErr: false,
  };
  const [formData, setFormData] = useState({
    benefitPlanStatusNetworkCode: "-1",
    mapSetID: "-1",
    typeCode: "-1",
    coInsAmt: "",
    coInsPCT: "",
    applyOopNum: "",
    beginDate: null,
    endDate: "12/31/9999",
    exceptionCode: "",
    seqNum: "",
  });
  const [resetformData, setResetFormData] = useState({
    benefitPlanStatusNetworkCode: "-1",
    mapSetID: "-1",
    typeCode: "-1",
    coInsAmt: "",
    coInsPCT: "",
    applyOopNum: "",
    beginDate: null,
    endDate: "12/31/9999",
    exceptionCode: "",
    seqNum: "",
  });
  const [success, setSuccess] = useState(false);
  const [coInsurance, setCoInsurance] = useState({});
  const [selectedEndDate, setSelectedDosEndDate] = React.useState("");
  const [selectedBeginDate, setSelectedDosBeginDate] = React.useState("");

  const handelDateRngeArrayOverlap = (
    initalStartDate,
    initialEndDate,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) =>
        handelDateRngeOverlap(
          initalStartDate,
          initialEndDate,
          each.dateRangeVO.beginDate,
          each.dateRangeVO.endDate
        )
      );
      if (result.filter((e) => e === true).length > 0) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRngeWithin = (
    rangeStartDate,
    rangeEndDate,
    withInStartDate,
    withInEndDate
  ) => {
    if (rangeStartDate && rangeEndDate) {
      const range = moment().range(
        new Date(rangeStartDate),
        new Date(rangeEndDate)
      );
      return (
        range.contains(new Date(withInStartDate)) &&
        range.contains(new Date(withInEndDate))
      );
    }
    return false;

  };

  const multiDelete = () => {
    setDialogOpen(false); setDialogType('');
    props.seterrorMessages([]);
    setSuccessMessages([]);
    if (selectDeleteArray.length > 0) {
        let CI = props.benefitPlanCoInsurance;
        selectDeleteArray.map((value, index) => {
          let curIndex = CI.findIndex(i => moment(i.beginDate).isSame(value.beginDate));
          CI.splice(curIndex,1);
        });
        props.setNewBenefitPlantCoInsurance(CI);
        props.bpCoInsDeleteItems(selectDeleteArray);
        setSelectDeleteArray([]);
        setDeleteSuccess(true);

    }
  }


  useImperativeHandle(ref, () => {
    return { validateFn };
  });

  const validateFn = () => {
    if (props.tabChangeValue.coinsuranceTab) {
      handelSaveValidationsCoins();
    } 
    }

    const handelSaveValidationsCoins = async() => {
      let errors = {},
      reqFieldArr = [],
      clmExcnDesc = "";
    let overlapArray;
    if (formData.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetformData.beginDate) ||
          e.endDate != formatDate(resetformData.endDate) ||
          e.seqNum != resetformData.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(formData.beginDate),
      formatDate(formData.endDate),
      formData.mapSetID,
      formData.benefitPlanStatusNetworkCode,
      formData.typeCode,
      overlapArray
    );
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(formData.beginDate),
      formatDate(formData.endDate)
    );

    setShowError({
      showBeginDate: formData.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorMsgConstants.Begin_Date_Error);
            return true;
          })(),
      ShowEndDate: formData.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorMsgConstants.End_Date_Error);
            return true;
          })(),
      showNetworkStatusErr:
        formData.benefitPlanStatusNetworkCode &&
        formData.benefitPlanStatusNetworkCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorMsgConstants.Network_Status_Error);
              return true;
            })(),
      showmapSetIDErr:
        formData.mapSetID && formData.mapSetID != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorMsgConstants.Map_Id_Error);
              return true;
            })(),
      showTypeCodErr:
        formData.typeCode && formData.typeCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorMsgConstants.CoInsTypeCode);
              return true;
            })(),
      // showCoInsAmtErr: formData.coInsAmt || formData.coInsPCT ? false : (() => { reqFieldArr.push(ErrorMsgConstants.AmountError); return true })(),
      // ShowPercentErr: formData.coInsPCT || formData.coInsAmt ? false : (() => { reqFieldArr.push(ErrorMsgConstants.AmountError); return true })(),

      showApplyOopNumErr: !(
        parseFloat(formData.applyOopNum) <= 100.0 &&
        parseInt(formData.applyOopNum) >= 0
      )
        ? (() => {
            reqFieldArr.length = 0;
            reqFieldArr.push(
              ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
            );
            return true;
          })()
        : false,

      percentageErr:
        formData.coInsPCT &&
        (
          parseInt(formData.coInsPCT) >= 100 || parseInt(formData.coInsPCT) == 0
        )
          ? (() => {
              reqFieldArr.push(ErrorMsgConstants.PERCENTAGE_ERROR);
              return true;
            })()
          : false,
        //   showHeaderDateErr:
        // !headerTange && formData.beginDate
        //   ? (() => {
        //       reqFieldArr.push(
        //         ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
        //       );
        //       return true;
        //     })()
        //   : false,
        showHeaderDateErr:
        !(new Date(formData.beginDate) >= new Date(props.formValues.beginDate) && new Date(formData.beginDate) <= new Date(props.formValues.endDate))
          ? (() => {
              reqFieldArr.push(
                ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
              );
              return true;
            })()
          : false,
          showHeaderEndDateErr:
          !(new Date(formData.endDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_End_Date_Err 
                );
                return true;
              })()
            : false,
          // End header date error

      showPercentageAppliedtoEmptyErr:
        formData.applyOopNum.toString().length == 0
          ? (() => {
             // reqFieldArr.length = 0;
              reqFieldArr.push(
                ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
              );
              return true;
            })()
          : false,
      showNetworkOverlapErr:
        formData.beginDate &&
        formData.endDate &&
        formData.mapSetID &&
        formData.benefitPlanStatusNetworkCode &&
        formData.typeCode &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorMsgConstants.COINSURANCE_OVERLAP_ERROR);
              return true;
            })()
          : false,
      ShowRankErr:  formData.seqNum.length < 1
      ? (() => {
        reqFieldArr.push(ErrorConst.Rank_Error);
        return true;
      })()
    : false,
      ShowRankErrSpe: !isNaN(parseInt(formData.seqNum))
        ? false
        : (() => {
          if (formData.seqNum.length !== 0) {
            reqFieldArr.push(ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO_ERROR);
            return true;
          } else return false;
        })(),
      ShowRankErrZero: formData.seqNum < 1 && formData.seqNum.length
        ? (() => {
          reqFieldArr.push(ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO);
          return true;
        })()
        : false,
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }
    if (formData.exceptionCode && formData.exceptionCode.trim()) {
      clmExcnDesc = await validateExcCode(formData.exceptionCode);
      if (!clmExcnDesc) {
        errors["EXC_CODE_NOT_MATCH_LOB"] = true;
        reqFieldArr.push(ErrorMsgConstants.EXC_CODE_NOT_MATCH_LOB);
      }
      if (reqFieldArr.length) {
        setShowError(errors);
        props.seterrorMessages(reqFieldArr);
        return false;
      }
    }
    
    }

  const minorDelete = () => {
    muiconfirm({
      title: "",
      description: "Are you sure that you want to delete.",
      dialogProps: { fullWidth: false },
    }).then(() => {
      let t = tableData;
      if (tableData.length == 1) {
        props.seterrorMessages([
          "Atleast One Record Should Exist For Co-Insurance",
        ]);
        setCanShowForm(false);
        setSuccess(false);
      } else {
        props.setbpCoInsDeleteItems
          ? props.setbpCoInsDeleteItems([
              ...props.bpCoInsDeleteItems,
              t[formData.index],
            ])
          : null;
        t.splice(formData.index, 1);
        props.setNewBenefitPlantCoInsurance(t);
        setSuccess(false);
        setDeleteSuccess(true);
        setCanShowForm(false);
      }
    });
  };
  const handelInputChangeLimit = (name) => (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: true })
    setFormData({ ...formData, [name]: event.target.value });
  };

  React.useEffect(() => {
    formData.beginDate !== ""
      ? setSelectedDosBeginDate(formData.beginDate)
      : setSelectedDosBeginDate("");
    formData.endDate !== ""
      ? setSelectedDosEndDate(formData.endDate)
      : setSelectedDosEndDate("");
  }, [formData.beginDate, formData.endDate]);

  const handleBeginDateChange = (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: true })
    setSelectedDosBeginDate(date);
    setFormData({ ...formData, ["beginDate"]: formatDate(date) });
  };

  const handleEndDateChange = (date) => {
    props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: true })
    setSelectedDosEndDate(date);
    setFormData({ ...formData, ["endDate"]: formatDate(date) });
  };

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
      });
      return tData;
    } else {
      return [];
    }
  };

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const validateExcCode = (c) => {
    return new Promise((resolve, reject) => {
      setspinnerLoader(true);
      axios
        .get(serviceEndPoint.BENEFIT_PLAN_EXC_CODE_VALIDATION + c)
        .then((response) => {
          if (response.data.data && response.data.data.excCodeDesc) {
            resolve(response.data.data.excCodeDesc);
          } else {
            resolve(false);
          }
        })
        .catch((error) => {
          resolve(false);
        })
        .then(() => {
          setspinnerLoader(false);
        });
    });
  };

  const handelDateNetworkArrayOverlap = (
    initalStartDate,
    initialEndDate,
    networkId,
    networkstatus,
    typeCode,
    inputArray
  ) => {
    if (inputArray.length > 0) {
      const result = inputArray.map((each) => {
        if (
          handelDateRngeOverlap(
            initalStartDate,
            initialEndDate,
            each.beginDate,
            each.endDate
          )
        ) {
          if (
            each.mapSetID == networkId &&
            each.benefitPlanStatusNetworkCode == networkstatus &&
            each.beginDate == initalStartDate &&
            each.typeCode == typeCode
          ) {
            return true;
          }
          return false;
        }
      });
      if (
        result.filter((e) => e === true).length &&
        result.filter((e) => e === true).length > 0
      ) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  };

  const handelDateRngeOverlap = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate
  ) => {
    const range1 = moment().range(
      new Date(initalStartDate),
      new Date(initialEndDate)
    );
    const range2 = moment().range(
      new Date(secondaryStartDate),
      new Date(secondaryEndDate)
    );
    return range1.overlaps(range2);
  };

  const handelClickCoInsurance = async () => {
    console.log(props.formValues);
    let errors = {},
      reqFieldArr = [],
      clmExcnDesc = "";
    let overlapArray;
    if (formData.index > -1) {
      overlapArray = tableData.filter(
        (e) =>
          e.beginDate != formatDate(resetformData.beginDate) ||
          e.endDate != formatDate(resetformData.endDate) ||
          e.seqNum != resetformData.seqNum
      );
    } else {
      overlapArray = tableData;
    }
    const networkOverlap = await handelDateNetworkArrayOverlap(
      formatDate(formData.beginDate),
      formatDate(formData.endDate),
      formData.mapSetID,
      formData.benefitPlanStatusNetworkCode,
      formData.typeCode,
      overlapArray
    );
    const headerTange = await handelDateRngeWithin(
      formatDate(props.formValues.beginDate),
      formatDate(props.formValues.endDate),
      formatDate(formData.beginDate),
      formatDate(formData.endDate)
    );

    setShowError({
      showBeginDate: formData.beginDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorMsgConstants.Begin_Date_Error);
            return true;
          })(),
      ShowEndDate: formData.endDate
        ? false
        : (() => {
            reqFieldArr.push(ErrorMsgConstants.End_Date_Error);
            return true;
          })(),
      showNetworkStatusErr:
        formData.benefitPlanStatusNetworkCode &&
        formData.benefitPlanStatusNetworkCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorMsgConstants.Network_Status_Error);
              return true;
            })(),
      showmapSetIDErr:
        formData.mapSetID && formData.mapSetID != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorMsgConstants.Map_Id_Error);
              return true;
            })(),
      showTypeCodErr:
        formData.typeCode && formData.typeCode != "-1"
          ? false
          : (() => {
              reqFieldArr.push(ErrorMsgConstants.CoInsTypeCode);
              return true;
            })(),
      // showCoInsAmtErr: formData.coInsAmt || formData.coInsPCT ? false : (() => { reqFieldArr.push(ErrorMsgConstants.AmountError); return true })(),
      // ShowPercentErr: formData.coInsPCT || formData.coInsAmt ? false : (() => { reqFieldArr.push(ErrorMsgConstants.AmountError); return true })(),

      showApplyOopNumErr: !(
        parseFloat(formData.applyOopNum) <= 100.0 &&
        parseInt(formData.applyOopNum) >= 0
      )
        ? (() => {
            reqFieldArr.length = 0;
            reqFieldArr.push(
              ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
            );
            return true;
          })()
        : false,

      percentageErr:
        formData.coInsPCT &&
        (
          parseInt(formData.coInsPCT) >= 100 || parseInt(formData.coInsPCT) == 0
        )
          ? (() => {
              reqFieldArr.push(ErrorMsgConstants.PERCENTAGE_ERROR);
              return true;
            })()
          : false,
        //   showHeaderDateErr:
        // !headerTange && formData.beginDate
        //   ? (() => {
        //       reqFieldArr.push(
        //         ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
        //       );
        //       return true;
        //     })()
        //   : false,
        showHeaderDateErr:
        !(new Date(formData.beginDate) >= new Date(props.formValues.beginDate) && new Date(formData.beginDate) <= new Date(props.formValues.endDate))
          ? (() => {
              reqFieldArr.push(
                ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
              );
              return true;
            })()
          : false,
          showHeaderEndDateErr:
          !(new Date(formData.endDate) <= new Date(props.formValues.endDate))
            ? (() => {
                reqFieldArr.push(
                  ErrorConst.Fall_In_Header_End_Date_Err 
                );
                return true;
              })()
            : false,
          // End header date error

      showPercentageAppliedtoEmptyErr:
        formData.applyOopNum.toString().length == 0
          ? (() => {
             // reqFieldArr.length = 0;
              reqFieldArr.push(
                ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
              );
              return true;
            })()
          : false,
      showNetworkOverlapErr:
        formData.beginDate &&
        formData.endDate &&
        formData.mapSetID &&
        formData.benefitPlanStatusNetworkCode &&
        formData.typeCode &&
        networkOverlap
          ? (() => {
              reqFieldArr.push(ErrorMsgConstants.COINSURANCE_OVERLAP_ERROR);
              return true;
            })()
          : false,
      ShowRankErr:  formData.seqNum.length < 1
      ? (() => {
        reqFieldArr.push(ErrorConst.Rank_Error);
        return true;
      })()
    : false,
      ShowRankErrSpe: !isNaN(parseInt(formData.seqNum))
        ? false
        : (() => {
          if (formData.seqNum.length !== 0) {
            reqFieldArr.push(ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO_ERROR);
            return true;
          } else return false;
        })(),
      ShowRankErrZero: formData.seqNum < 1 && formData.seqNum.length
        ? (() => {
          reqFieldArr.push(ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO);
          return true;
        })()
        : false,

        EXC_CODE_NOT_MATCH_LOB:  !isSpecialcharecter(
          formData.exceptionCode
        )
          ? false
          : (() => {
            reqFieldArr.push(ErrorConst.EXC_CODE_NOT_MATCH_LOB);
            reqFieldArr.push(ErrorConst.INVALID_SPL_EXC_CODE);  
              return true;
            })(),
    });

    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }
    if (formData.exceptionCode && formData.exceptionCode.trim()) {
      clmExcnDesc = await validateExcCode(formData.exceptionCode);
      if (!clmExcnDesc) {
        errors["EXC_CODE_NOT_MATCH_LOB"] = true;
        reqFieldArr.push(ErrorMsgConstants.EXC_CODE_NOT_MATCH_LOB);
       // reqFieldArr.push(ErrorConst.INVALID_SPL_EXC_CODE);

      }
      if (reqFieldArr.length) {
        setShowError(errors);
        props.seterrorMessages(reqFieldArr);
        return false;
      }
    }
    let data = {
      auditUserID: formData.auditUserID ? formData.auditUserID : "52123327",
      addedAuditUserID: formData.addedAuditUserID
        ? formData.addedAuditUserID
        : "52123327",
      versionNo: formData.versionNo ? formData.versionNo : 0,
      dbRecord: formData.dbRecord ? formData.dbRecord : false,
      sortColumn: formData.sortColumn ? formData.sortColumn : null,
      auditKeyList: formData.auditKeyList ? formData.auditKeyList : [],
      auditKeyListFiltered: formData.auditKeyListFiltered
        ? formData.auditKeyListFiltered
        : false,
      benefitPlanCoInsID: formData.benefitPlanCoInsID
        ? formData.benefitPlanCoInsID
        : null,
      benefitPlanStatusNetworkCode: formData.benefitPlanStatusNetworkCode
        ? formData.benefitPlanStatusNetworkCode
        : "",
      beginDate: formData.beginDate ? formData.beginDate : "",
      typeCode:
        formData.typeCode && formData.typeCode != "-1" ? formData.typeCode : "",
      mapSetID: formData.mapSetID ? formData.mapSetID : "",
      applyOopNum: formData.applyOopNum ? formData.applyOopNum : "",
      seqNum: formData.seqNum ? formData.seqNum : "",
      coInsPCT: formData.coInsPCT ? formData.coInsPCT : "",
      exceptionCode: formData.exceptionCode ? formData.exceptionCode : null,
      coInsAmt: formData.coInsAmt ? formData.coInsAmt : null,
      endDate: formData.endDate ? formData.endDate : "12/31/9999",
      benefitPlan: formData.benefitPlan ? formData.benefitPlan : null,
      clmExcnDesc: clmExcnDesc ? clmExcnDesc : "",
      bpNetworkCodeDesc: formData.bpNetworkCodeDesc
        ? formData.bpNetworkCodeDesc
        : "",
      typeCodeDesc: formData.typeCodeDesc ? formData.typeCodeDesc : null,
    };
    formData.index > -1
      ? (tableData[formData.index] = data)
      : tableData.push(data);
    setSuccess(true);
    props.seterrorMessages([]);
    props.setNewBenefitPlantCoInsurance(tableData);
    setFormData({
      benefitPlanStatusNetworkCode: "-1",
      mapSetID: "-1",
      typeCode: "-1",
      coInsAmt: "",
      coInsPCT: "",
      applyOopNum: "",
      beginDate: null,
      endDate: "12/31/9999",
      exceptionCode: "",
      seqNum: "",
    });
    setCanShowForm(false);
    setResetFormData({
      benefitPlanStatusNetworkCode: "-1",
      mapSetID: "-1",
      typeCode: "-1",
      coInsAmt: "",
      coInsPCT: "",
      applyOopNum: "",
      beginDate: null,
      endDate: "12/31/9999",
      exceptionCode: "",
      seqNum: "",
    });
    props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: false });

  };

  const editRow = (row) => (event) => {
    props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: false });
    setCanShowForm(true);
    setSuccess(false);
    setDeleteSuccess(false);
    setFormData(row);
    setResetFormData({
      benefitPlanStatusNetworkCode: row.benefitPlanStatusNetworkCode,
      mapSetID: row.mapSetID,
      typeCode: row.typeCode,
      coInsAmt: row.coInsAmt,
      coInsPCT: row.coInsPCT,
      applyOopNum: row.applyOopNum,
      beginDate: row.beginDate,
      endDate: row.endDate,
      exceptionCode: row.exceptionCode,
      seqNum: row.seqNum,
      index: row.index,
      row: row,
    });
    BPCIscrolltoViewedit();
  };

  const copayHandelResetClick = () => {
    props.seterrorMessages([]);
    setFormData(resetformData);
    setShowError({});
    props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: false });
  };

  const handelDeleteClick = () => {};
  const handelCandelFunction = () => {
    setCanShowForm(false);
    setShowError({});
    setDialogOpen(false);
    setDialogType("");
  };
  const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
  const BPCIrefdiv1 = useRef(null);
  const BPCIscrolltoViewedit = () => {
    setTimeout(function () {
      scrollToRef(BPCIrefdiv1);
    }.bind(this), 500);
  };

  return (
    <div className="tab-holder CustomExpansion-panel my-3">
      {spinnerLoader ? <Spinner /> : null}
      {success ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorMsgConstants.SUCCESSFULLY_SAVED_INFORMATION}
        </div>
      ) : null}

      <Dialog
        open={dialogOpen}
        onClose={() => {
          setDialogOpen(false);
          setDialogType("");
        }}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            {dialogType == "Delete" || dialogType == "multiDelete"
              ? "Are you sure that you want to Delete."
              : dialogType == "Cancel" 
              ? "Changes you made may not be saved." : ""}
          </DialogContentText>
        </DialogContent>
        <DialogActions>
            <Button title="Ok" onClick={() => {
              dialogType == "Delete"
                ? handelDeleteClick() :
              dialogType == "multiDelete"
                ? multiDelete()
              : handelCandelFunction();
            }} color="primary" className="btn btn-success">
                Ok
            </Button>
            <Button title="Cancel"  onClick={() => { setDialogOpen(false); setDialogType(''); }} color="primary" autoFocus>
                Cancel
            </Button>
        </DialogActions>
      </Dialog>


      {deleteSuccess ? (
        <div className="alert alert-success custom-alert" role="alert">
          {ErrorConst.BENIFIT_PLAN_DELETE_SUCCESS}
        </div>
      ) : null}
      <div className="tab-header">
        <h3 className="tab-heading float-left">Benefit Plan - Co-Insurance</h3>
        <div className="float-right th-btnGroup mb-2">
        <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => {setDialogOpen(true); setDialogType('multiDelete');}}>
                          <i className="fa fa-trash" />

                        </Button>
          <Button
            title="Add  Co-Insurance"
            color="primary"
            className="btn btn-secondary btn-icon-only"
            onClick={() => {
              if( props.majorValidations()){
              props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: true })
              setCanShowForm(true);
              setSuccess(false);
              setDeleteSuccess(false);
              setFormData({
                benefitPlanStatusNetworkCode: "-1",
                mapSetID: "-1",
                typeCode: "-1",
                coInsAmt: "",
                coInsPCT: "",
                applyOopNum: "",
                beginDate: null,
                endDate: "12/31/9999",
                exceptionCode: "",
                seqNum: "",
              });
              BPCIscrolltoViewedit();
            }}}
          >
            <i className="fa fa-plus" />
          </Button>
        </div>
      </div>
      <div className="tab-holder mt-2">
        <TableComponent
          headCells={headCells}
          multiDelete selected={selectDeleteArray} setSelected={setSelectDeleteArray}
          tableData={getTableData(tableData)}
          onTableRowClick={editRow}
          defaultSortColumn="beginDate"
          setTabChangeValue = {props.setTabChangeValue}
        />
        {canShowForm ? (
          <>
            <div className="tab-header mt-3" ref={BPCIrefdiv1}>
              <h3 className="tab-heading float-left">
                {formData.index > -1 ? "Edit" : "New"} Co-Insurance
              </h3>
              <div className="float-right th-btnGroup">
                <Button
                  title={formData.index > -1 ? "Update" : "Add"}
                  color="primary"
                  className={
                    formData.index > -1
                      ? "btn btn-ic btn-save"
                      : "btn btn-ic btn-add"
                  }
                  onClick={handelClickCoInsurance}
                  disabled={props.privileges && !props.privileges.add? 'disabled':'' }
                >
                  {formData.index > -1 ? "Update" : "Add"}
                </Button>
                {formData.index > -1 ? (
                  <Link to="MapDefinition" target="_blank">
                    <Button
                      title="View/Edit Map"
                      color="primary"
                      className="btn btn-ic btn-view"
                      onClick={() => {}}
                    >
                      View/Edit Map
                    </Button>
                  </Link>
                ) : null}
                <Button
                  title="Reset"
                  color="primary"
                  className="btn btn-ic btn-reset"
                  onClick={() => copayHandelResetClick()}
                >
                  Reset
                </Button>
                {formData.index > -1 ? (
                  <Button
                    title="Delete"
                    variant="outlined"
                    color="primary"
                    className="btn btn-ic btn-delete"
                    onClick={minorDelete}
                  >
                    Delete
                  </Button>
                ) : null}
                <Button
                  title="Cancel"
                  color="primary"
                  className="btn btn-cancel"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("Cancel");
                    props.setTabChangeValue({ ...props.tabChangeValue, coinsuranceTab: false });
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
            <div className="tab-body-bordered mt-2">
              <div className="form-wrapper">
                <div className="flex-block">
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form input-md with-select">
                      <KeyboardDatePicker
                        required
                        id="bgn_date_insurance_cost_share_tab"
                        label="Begin Date"
                        format="MM/dd/yyyy"
                        InputLabelProps={{
                          shrink: true,
                        }}
                        placeholder="mm/dd/yyyy"
                        value={selectedBeginDate}
                        onChange={handleBeginDateChange}
                        helperText={
                          showBeginDate
                            ? ErrorMsgConstants.Begin_Date_Error
                            : showHeaderDateErr ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                            : null
                        }
                        error={
                          showBeginDate
                            ? ErrorMsgConstants.Begin_Date_Error
                            : showHeaderDateErr ? ErrorConst.Fall_In_Header_Dates_Err_provider_ntwrk
                            : null
                        }
                        KeyboardButtonProps={{
                          "aria-label": "change date",
                        }}
                      />
                    </div>
                  </MuiPickersUtilsProvider>
                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form input-md with-select">
                      <KeyboardDatePicker
                        required
                        id="end_date_insurance_cost_share_tab"
                        label="End Date"
                        format="MM/dd/yyyy"
                        InputLabelProps={{
                          shrink: true,
                        }}
                        value={selectedEndDate}
                        maxDate={new Date("9999-12-31T13:00:00.000+0000")}
                        placeholder="mm/dd/yyyy"
                        onChange={handleEndDateChange}
                        helperText={
                          ShowEndDate ? ErrorMsgConstants.End_Date_Error 
                          : showHeaderEndDateErr
                          ? ErrorConst.Fall_In_Header_End_Date_Err
                          : null
                        }
                        error={
                          ShowEndDate ? ErrorMsgConstants.End_Date_Error 
                          : showHeaderEndDateErr
                          ? ErrorConst.Fall_In_Header_End_Date_Err
                          : null
                        }
                        KeyboardButtonProps={{
                          "aria-label": "change date",
                        }}
                      />
                    </div>
                  </MuiPickersUtilsProvider>
                </div>

                <div className="flex-block">
                  <div className="mui-custom-form with-select input-md">
                    <TextField
                      required
                      id="network_status_insurance_cost_share_tab"
                      select
                      label="Network Status"
                      value={formData.benefitPlanStatusNetworkCode}
                      onChange={(event) => {
                        setFormData({
                          ...formData,
                          ["benefitPlanStatusNetworkCode"]: event.target.value,
                          ["bpNetworkCodeDesc"]:
                            event.nativeEvent.target.textContent,
                        });
                      }}
                      helperText={
                        showNetworkStatusErr
                          ? ErrorMsgConstants.Network_Status_Error
                          : null
                      }
                      error={
                        showNetworkStatusErr
                          ? ErrorMsgConstants.Network_Status_Error
                          : null
                      }
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem key="sdfasdfhhhOne" value="-1">
                        {" "}
                        Please Select One
                      </MenuItem>
                      {props.coInsuranceDropdowns &&
                        props.coInsuranceDropdowns["R1#R_BP_NW_STAT_CD"] &&
                        props.coInsuranceDropdowns["R1#R_BP_NW_STAT_CD"].map(
                          (each) => (
                            <MenuItem key={each.code} value={each.code}>
                              {each.description}
                            </MenuItem>
                          )
                        )}
                    </TextField>
                  </div>
                  <div className="mui-custom-form with-select input-md">
                    <TextField
                      required
                      id="map_id_insurance_cost_share_tab"
                      select
                      label="Map ID"
                      value={formData.mapSetID}
                      onChange={handelInputChangeLimit("mapSetID")}
                      helperText={
                        showmapSetIDErr ? ErrorMsgConstants.Map_Id_Error : null
                      }
                      error={
                        showmapSetIDErr ? ErrorMsgConstants.Map_Id_Error : null
                      }
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem key="PleasasdfeSelesdfsaerctOne" value="-1">
                        {" "}
                        Please Select One
                      </MenuItem>
                      {props.mapDropdown &&
                        props.mapDropdown.map((each) => (
                          <MenuItem
                            selected
                            key={each.mapsetId}
                            value={each.mapsetId}
                          >
                            {each.mapsetId}-{each.mapDesc}
                          </MenuItem>
                        ))}
                    </TextField>
                  </div>
                </div>

                <div className="flex-block">
                  <div className="mui-custom-form input-md">
                    <TextField
                      id="amount_insurance_cost_share_tab"
                      label="Amount"
                      placeholder=""
                      type="text"
                      value={formData.coInsAmt}
                      onChange={handelInputChangeLimit("coInsAmt")}
                      // helperText={showCoInsAmtErr ? ErrorMsgConstants.AmountError : null}
                      // error={showCoInsAmtErr ? ErrorMsgConstants.AmountError : null}
                      InputProps={{
                        startAdornment: (
                          <InputAdornment position="start">$</InputAdornment>
                        ),
                      }}
                      inputProps={{ maxLength: 14 }}
                    />
                  </div>
                  <div className="mui-custom-form input-md">
                    <TextField
                      id="percentage_insurance_cost_share_tab"
                      label="Percent"
                      placeholder=""
                      type="text"
                      value={formData.coInsPCT}
                      onChange={handelInputChangeLimit("coInsPCT")}
                      helperText={
                        percentageErr
                          ? ErrorMsgConstants.PERCENTAGE_ERROR
                          : null
                      }
                      error={
                        percentageErr
                          ? ErrorMsgConstants.PERCENTAGE_ERROR
                          : null
                      }
                      InputLabelProps={{
                        shrink: true,
                      }}
                      inputProps={{ maxLength: 10 }}
                    />
                  </div>
                  <div className="mui-custom-form input-md">
                    <TextField
                      required
                      id="pocket_max_insurance_cost_share_tab"
                      label="Percent Applied to out of Pocket Max"
                      placeholder=""
                      value={formData.applyOopNum}
                      onChange={handelInputChangeLimit("applyOopNum")}
                      helperText={
                        showPercentageAppliedtoEmptyErr
                          ? ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
                          : showApplyOopNumErr
                          ? ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
                          : null
                      }
                      error={
                        showPercentageAppliedtoEmptyErr
                          ? ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET_EMPTY
                          : showApplyOopNumErr
                          ? ErrorMsgConstants.PERCENTAGE_APPLIED_TO_OUT_OF_POCKET
                          : null
                      }
                      InputLabelProps={{
                        shrink: true,
                      }}
                      inputProps={{ maxLength: 10 }}
                    />
                  </div>
                </div>

                <div className="flex-block">
                  <div className="mui-custom-form with-select input-md">
                    <TextField
                      required
                      id="insurance_type_insurance_cost_share_tab"
                      select
                      label="Co-Insurance Type Code"
                      value={formData.typeCode}
                      onChange={(event) => {
                        setFormData({
                          ...formData,
                          ["typeCode"]: event.target.value,
                          ["typeCodeDesc"]:
                            event.nativeEvent.target.textContent,
                        });
                      }}
                      helperText={
                        showTypeCodErr ? ErrorMsgConstants.CoInsTypeCode : null
                      }
                      error={
                        showTypeCodErr ? ErrorMsgConstants.CoInsTypeCode : null
                      }
                      placeholder="Please Select One"
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem key="PleasgjfgjOne" value="-1">
                        Please Select One
                      </MenuItem>
                      {props.coInsuranceDropdowns &&
                        props.coInsuranceDropdowns["R1#R_BP_COINS_TY_CD"] &&
                        props.coInsuranceDropdowns["R1#R_BP_COINS_TY_CD"].map(
                          (each) => (
                            <MenuItem key={each.code} value={each.code}>
                              {each.description}
                            </MenuItem>
                          )
                        )}
                    </TextField>
                  </div>
                  <div className="mui-custom-form input-md">
                    <TextField
                      id="exception_code_insurance_cost_share_tab"
                      label="Exception Code"
                      placeholder=""
                      value={formData.exceptionCode}
                      onChange={handelInputChangeLimit("exceptionCode")}
                      helperText={
                        EXC_CODE_NOT_MATCH_LOB
                          ? ErrorMsgConstants.EXC_CODE_NOT_MATCH_LOB
                          : null
                      }
                      error={EXC_CODE_NOT_MATCH_LOB}
                      inputProps={{ maxLength: 4 }}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </div>
                  <div className="mui-custom-form input-md">
                    <TextField
                      id="rank_insurance_cost_share_tab"
                      required
                      label="Rank"
                      name="seqNum"
                      value={formData.seqNum}
                      inputProps={{ maxLength: 6 }}
                      onChange={handelInputChangeLimit("seqNum")}
                      placeholder="Please Enter"
                      helperText={
                        ShowRankErr ? ErrorMsgConstants.Rank_Error : null
                      }
                      helperText={
                        ShowRankErr
                          ? ErrorMsgConstants.Rank_Error
                          : ShowRankErrSpe
                          ? ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO_ERROR
                          : ShowRankErrZero
                          ? ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO
                          : null
                      }
                      error={
                        ShowRankErr
                          ? ErrorMsgConstants.Rank_Error
                          : ShowRankErrSpe
                          ? ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO_ERROR
                          : ShowRankErrZero
                          ? ErrorMsgConstants.BENEFIT_PLAN_RANKING_ZERO
                          : null
                      }
                      InputLabelProps={{
                        shrink: true,
                      }}
                    ></TextField>
                  </div>
                </div>
              </div>
            </div>
          </>
        ) : null}
      </div>
    </div>
  );
}
export default forwardRef(BPCostShareCoInsurance);
