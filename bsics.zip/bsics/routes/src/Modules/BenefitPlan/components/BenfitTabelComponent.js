import React, { useEffect, useState } from "react";
import { withRouter } from "react-router";
import TableComponent from "../../../SharedModules/Table/Table";

function BenfitTableComponent(props) {
	const headCells = [
		{
			id: "beginDate",
			numeric: false,
			dateHyperLink: true,
			disablePadding: true,
			label: "Begin Date",
			enableHyperLink: true,
			fontSize: 12
		},
		{
			id: "nwEndDate",
			numeric: false,
			isDate: true,
			disablePadding: false,
			label: "End Date",
			enableHyperLink: false,
			fontSize: 12
		},
		{
			id: "nwID",
			numeric: false,
			disablePadding: false,
			label: "Network ID",
			enableHyperLink: false,
			fontSize: 12
		},
		{
			id: "nwStatCodeDesc",
			numeric: false,
			disablePadding: false,
			label: "Network Status",
			enableHyperLink: false,
			fontSize: 12
		},
		{
			id: "seqNum",
			numeric: false,
			disablePadding: false,
			label: "Rank",
			enableHyperLink: false,
			fontSize: 12
		}
	];

	const getTableData = data => {
		if (data && data.length) {
			let tData = JSON.stringify(data); 
			tData = JSON.parse(tData);     
			tData.map((each,index) => {
				each.index = index;
			}); 
      return tData;
		} else {
			return [];
		}
	};

	const editRow = row => event => {
		props.setTabChangeValue({ ...props.tabChangeValue, mainTab: false });
		props.MBPscrolltoView();
		props.setSuccess(false);
		props.setbanifitPlan(true);
		props.setnewProviderDate({
			beginDate: row.beginDate,
			endDate: row.nwEndDate,
			netWorkId: row.nwID,
			netWorkStatus: row.nwStatCode,
			rank: row.seqNum,
			netWorkSateDesc: row.nwStatCodeDesc,
			index: row.index,
			row: row
		});
		props.setresetProviderDate({
			beginDate: row.beginDate,
			endDate: row.nwEndDate,
			netWorkId: row.nwID,
			netWorkStatus: row.nwStatCode,
			rank: row.seqNum,
			netWorkSateDesc: row.nwStatCodeDesc,
			index: row.index,
			row: row
		});
	};

	return (
		<TableComponent
			headCells={headCells}
			tableData={getTableData(props.tabelRowData)}
			onTableRowClick={editRow}
			defaultSortColumn="diagnosisCode"
		 selected={props.selectDeleteArray} setSelected={props.setSelectDeleteArray} multiDelete
		/>
	);
}
export default withRouter(BenfitTableComponent);
