/* eslint-disable arrow-parens */
import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';

export const resetSearchBatchControl = () => ({
    type: actionTypes.RESETDATA,
    resetData: []
});

export const dispatchBatchControlSearch = (response) => ({
    type: actionTypes.BATCH_CONTROL_SEARCH_TYPE,
    batchSearchData: response
});

export const dispatchDropdowns = (response) => ({
    type: actionTypes.BATCH_CONTROL_DROPDOWNS,
    dropdowns: response
});


export const batchControlDropdowns = values => dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_GETREFERENCEDATA_ENDPOINT}`, values)
        .then(response => {
            if (Object.keys(response.data.listObj).length > 0) {
                dispatch(dispatchDropdowns(response.data.listObj));
            }
        })
}

export const batchControlSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.BATCH_CONTROL_SEARCH_ENDPOINT}`, values)
        .then(response => {

            //     if (response.status == 200) {
            //         if (response.data.data.isRecordExist) {
            //             dispatch(dispatchBatchControlSearch(response.data));
            //         } else {
            //             dispatch(dispatchBatchControlSearch([]));
            //         }
            //     } else {
            //         dispatch(dispatchBatchControlSearch(response.data));
            //     }

            // })
            if (response.status == 200) {
                if (response.data.isRecordExist) {
                    dispatch(dispatchBatchControlSearch(response.data.data.searchResults));
                } else {
                    dispatch(dispatchBatchControlSearch([]));
                }
            } else {
                dispatch(dispatchBatchControlSearch(response.data.message));
            }

        })
        .catch(error => {
            dispatch(dispatchBatchControlSearch(error.data));
        })
}

export const dispatchbatchControlAdd = (response) => ({
    type: actionTypes.ADD_BATCH_CONTROL,
    addResponse: response
});

export const dispatchbatchControlUpdate = (response) => ({
    type: actionTypes.UPDATE_BATCH_CONTROL,
    updateResponse: response
});

export const dispatchbatchControlDelete = (response) => ({
    type: actionTypes.DELETE_BATCH_CONTROL,
    deleteResponse: response
});

export const batchControlAdd = values => dispatch => {
    return axios.post(`${serviceEndPoint.BATCH_CONTROL_ADD}`, values)
        .then(response => {
            dispatch(dispatchbatchControlAdd(response.data));
        })
        .catch(error => {
            dispatch(dispatchbatchControlAdd(error.response.data));
        })
};

export const batchControlUpdate = values => dispatch => {
    return axios.post(`${serviceEndPoint.BATCH_CONTROL_UPDATE}`, values)
        .then(response => {
            
            dispatch(dispatchbatchControlUpdate(response.data));
        })
        .catch(error => {
            dispatch(dispatchbatchControlUpdate(error.response.data));
        })
};

export const batchControlDelete = values => dispatch => {
    return axios.post(`${serviceEndPoint.BATCH_CONTROL_DELETE}`, values)
        .then(response => {
            dispatch(dispatchbatchControlDelete(response.data));
        })
        .catch(error => {
            dispatch(dispatchbatchControlDelete(error.response.data));
        })
};

export const batchControlDetails = values => ({
    type: actionTypes.BATCH_CONTROL_DETAILS,
    batchControlData: values
});

export const batchControlDetailsAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.BATCH_CONTROL_SEARCH_ENDPOINT}`, values)
        .then(response => {
            dispatch(batchControlDetails(response.data.data.searchResults[0]));
        })
};

