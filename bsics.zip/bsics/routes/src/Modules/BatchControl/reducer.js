import * as actionTypes from './actionTypes';

const axiosPayLoad = {
  payload: null,
  addResponse: null,
  updateResponse: null,
  deleteResponse: null,
  batchControlData: null,
  type: 'Add'
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.RESETDATA:
      return axiosPayLoad;
    case actionTypes.BATCH_CONTROL_DROPDOWNS:
      return { ...state, dropdowns: action.dropdowns }
    case actionTypes.BATCH_CONTROL_SEARCH_TYPE:
      return { ...state, payload: action.batchSearchData}
    case actionTypes.ADD_BATCH_CONTROL:
      return { ...state, addResponse: action.addResponse, updateResponse: null, deleteResponse: null }
    case actionTypes.UPDATE_BATCH_CONTROL:
      return { ...state, updateResponse: action.updateResponse, addResponse: null, deleteResponse: null }
    case actionTypes.DELETE_BATCH_CONTROL:
      return { ...state, deleteResponse: action.deleteResponse, addResponse: null, updateResponse: null }
    case actionTypes.BATCH_CONTROL_DETAILS:
      return { ...state, batchControlData: action.batchControlData, type: 'Edit' }
    default: return state;
  }
};

export default reducer;
