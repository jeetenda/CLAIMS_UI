import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Enzyme, { shallow, mount } from 'enzyme';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import ClaimBatchControlDetails from '../components/ClaimBatchControlDetails';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import thunk from "redux-thunk";
import moxios from 'moxios';
import { batchControlAdd, batchControlUpdate,batchControlDelete } from '../actions';
import * as actionTypes from '../actionTypes'
import 'regenerator-runtime/runtime';

Enzyme.configure({ adapter: new EnzymeAdapter() });

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 9-Sep-2020
   * @author Divya Chauhan
*/
const middlewares = [thunk]
    const mockStore = configureStore(middlewares)
    let store, wrapper;

    const initialState = {
       
    };
    store = mockStore(initialState);
    const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })




describe('Add Batch Control Component API Call test cases', function () {
    const store = mockStore({});
    const reqBody = {
        "auditUserID": "JMAUK72",
        "auditTimeStamp": "2013-04-24T06:24:56.079+0000",
        "addedAuditUserID": "JBANNISTER72",
        "addedAuditTimeStamp": "2013-03-31T11:35:41.969+0000",
        "julianDateNumber": "20112",
        "batchNumber": "8059",
        "mediaSourceCode": "8",
        "batchStatusCode": "A",
        "batchTypeCode": "Y",
        "paymentTypeCode": "0",
        "beginDocumentNumber": "1",
        "endDocumentNumber": "19",
        "documentCountNumber": "19",
        "lastEnteredNumber": 4,
        "highDocumentNumber": 4,
        "documentTypeCode": "A",
        "enteredCountNumber": 19

    }

    const resObject = {
        "status": "200",
        "success": true,
        "message": "System successfully saved the Information.",
        "data": true,
        "isRecordExist": false,
        "errorCode": null,
        "errorList": []
    }

    const reqResponse = {
        data: resObject
    }

    beforeEach(function () {
        // import and pass your custom axios instance to this method
        moxios.install()
    })

    afterEach(function () {
        // import and pass your custom axios instance to this method
        moxios.uninstall()
    })

    it('should be success the api call', () => {
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockSuccess(reqResponse));
        })

        const dispatchbatchControlAdd = {
            type: actionTypes.ADD_BATCH_CONTROL,
            addResponse: resObject
        }
        return store.dispatch(batchControlAdd(reqBody))
            .then(() => {
                const actions = store.getActions()
                expect(actions[0].addResponse.data).toEqual(dispatchbatchControlAdd.addResponse);
            })

        
    })
    it('should be fail the api call', () => {

        const errResponse = {
            error: "no data found"
        }

        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockError(errResponse))
        })

        const dispatchbatchControlAddErr = {
            type: actionTypes.ADD_BATCH_CONTROL,
            addResponse: errResponse
        }
        return store.dispatch(batchControlAdd(reqBody))
            .then(() => {
                const actions = store.getActions();
                expect(actions[1]).toEqual(dispatchbatchControlAddErr);
            })


    })

   
    it('should be success the update api call', () => {
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockSuccess(reqResponse));
        })

        const dispatchbatchControl = {
            type: actionTypes.UPDATE_BATCH_CONTROL,
            updateResponse: resObject
        }
        return store.dispatch(batchControlUpdate(reqBody))
            .then(() => {
                const actions = store.getActions()
                expect(actions[2].updateResponse.data).toEqual(dispatchbatchControl.updateResponse);
            })

    })
    it('should be fail the update api call', () => {
        const errResponse = {
            error: "no data found"
        }

        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockError(errResponse));
        })

        const dispatchbatchControl = {
            type: actionTypes.UPDATE_BATCH_CONTROL,
            updateResponse: errResponse
        }
        return store.dispatch(batchControlUpdate(reqBody))
            .then(() => {
                const actions = store.getActions()
                expect(actions[3]).toEqual(dispatchbatchControl);
            })

    })

    it('should be success the delete api call', () => {
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockSuccess(reqResponse));
        })

        const dispatchbatchControl = {
            type: actionTypes.DELETE_BATCH_CONTROL,
            deleteResponse: resObject
        }
        return store.dispatch(batchControlDelete(reqBody))
            .then(() => {
                const actions = store.getActions()
                expect(actions[4].deleteResponse.data).toEqual(dispatchbatchControl.deleteResponse);
            })

    })
    it('should be fail the delete api call', () => {
        const errResponse = {
            error: "no data found"
        }

        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockError(errResponse));
        })

        const dispatchbatchControl = {
            type: actionTypes.DELETE_BATCH_CONTROL,
            deleteResponse: errResponse
        }
        return store.dispatch(batchControlDelete(reqBody))
            .then(() => {
                const actions = store.getActions()
                expect(actions[5]).toEqual(dispatchbatchControl);
            })

    })
})