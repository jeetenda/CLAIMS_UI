import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import Enzyme, { shallow, mount } from 'enzyme';
import EnzymeAdapter from 'enzyme-adapter-react-16';
import ClaimBatchControlDetails from '../components/ClaimBatchControlDetails';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import thunk from "redux-thunk";
import moxios from 'moxios';
import { batchControlAdd, batchControlUpdate } from '../actions';
import * as actionTypes from '../actionTypes'
import 'regenerator-runtime/runtime';

Enzyme.configure({ adapter: new EnzymeAdapter() });

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 9-Sep-2020
   * @author Divya Chauhan
*/
const middlewares = [thunk]
    const mockStore = configureStore(middlewares)
    let store, wrapper;

    const initialState = {
        batchControl: {
            addResponse: [],
            updateResponse: [],
            deleteResponse: [],
            type: 'Add',
            batchControlData: []
        },
        appDropDowns: {
            printLayout: null,
            appdropdowns: [],
        },
    };
    store = mockStore(initialState);
    const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe("Claim Batch Control Add", () => {
    
    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = mount(<Provider store={store}> <Router>
            <ClaimBatchControlDetails />
        </Router>  </Provider>)
    })

    //expect used for assert the component and match the output with testing condition
    describe('Claim Batch Control Details Component test cases', function () {
        it('should render Claim Batch Control Details Component  without error', () => {
            const component = wrapper.find("[data-test='Add-component']")
            expect(component.length).toBe(1);
        })
    });

    describe('Add/Update  Batch Control Component Buttons test cases', function () {
        it('should render save button without error', () => {
            const component = wrapper.find("[data-test='test-btn-save']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render help button without error', () => {
            const component = wrapper.find("[data-test='test-btn-help']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render audit button without error', () => {
            const component = wrapper.find("[data-test='test-btn-audit']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render reset button without error', () => {
            const component = wrapper.find("[data-test='test-btn-reset']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render print button without error', () => {
            const component = wrapper.find("[data-test='test-btn-print']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render cancel button without error', () => {
            const component = wrapper.find("[data-test='test-btn-cancel']").at(0)
            expect(component.length).toBe(1);
        })
    });

    describe('Add/Update  Batch Control Component Control Key Details test cases', function () {

        it('should render Batch Date without error', () => {
            const component = wrapper.find("[data-test='batch-date']").at(0)
            expect(component.length).toBe(1);
        })

        it('should render Media Source without error', () => {
            const component = wrapper.find("[data-test='media-source']").at(0)
            expect(component.length).toBe(1);
        })

        it('should render Batch Number without error', () => {
            const component = wrapper.find("[data-test='batch-number']").at(0)
            expect(component.length).toBe(1);
        })
    });

    describe('Add/Update  Batch Control Component Document Details test cases', function () {
        it('should render total documents without error', () => {
            const component = wrapper.find("[data-test='total-documents']").at(0)
            expect(component.length).toBe(1);
        })

        it('should render Begin Document without error', () => {
            const component = wrapper.find("[data-test='begin-doc']").at(0)
            expect(component.length).toBe(1);
        })

        it('should render End Document without error', () => {
            const component = wrapper.find("[data-test='end-doc']").at(0)
            expect(component.length).toBe(1);
        })
    });

    describe('Add/Update  Batch Control Component Batch Details test cases', function () {
        it('should render Document Type without error', () => {
            const component = wrapper.find("[data-test='document-type']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render Batch Type without error', () => {
            const component = wrapper.find("[data-test='batch-type']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render Batch Status without error', () => {
            const component = wrapper.find("[data-test='batch-status']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render Batch Status Date without error', () => {
            const component = wrapper.find("[data-test='batch-status-date']").at(0)
            expect(component.length).toBe(1);
        })
        it('should render Payment Type without error', () => {
            const component = wrapper.find("[data-test='payment-type']").at(0)
            expect(component.length).toBe(1);
        })
    })

    //api sucees and error method
  
});



