
import React from "react"
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { batchControlSearchAction } from '../actions'
import * as actionTypes from '../actionTypes'
import BatchControlSearchForm from "../Components/BatchControlSearchForm"


const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 15-Sep-2020
   * @author Jai Arora
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('Batch Control Search Form Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper

    // intitial state for component
    const initialState = {

    }

    // intitial props for component
    const componentProps = {
        handleChanges: jest.fn(),
        searchCheck: jest.fn(),
        resetTable: jest.fn(),
        values: {
            batchDate: '',
            mediaSource: 'Please Select One',
            batchNumber: ''
        },
        errors: {

            showBatchDateError: false,
            showBatchNumberError: false,
            showBatchDateFormatError: false,
        }
    }

    //beforeEach Run before testcases is run 
    //for shallow 

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><BatchControlSearchForm  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
        // console.log(wrapper.debug())
    })



    //expect used for assert the component and match the output with testing condition

    describe('Rendering of Batch Control Search form Component', () => {

        it('should render batch date without error', () => {
            const component = wrapper.find("[data-test='standard-batchDate']")
            expect(component.length).toBe(1);

        })

        it('should render media source without error', () => {
            const component = wrapper.find("[data-test='standard-select-mediaSource']")
            expect(component.length).toBe(1);

        })

        it('should render batch number without error', () => {
            const component = wrapper.find("[data-test='standard-batchNumber']")
            expect(component.length).toBe(1);

        })
        it('should render search button without error', () => {
            const component = wrapper.find("[data-test='search-button']")
            expect(component.length).toBe(1);

        })
        it('should render reset button without error', () => {
            const component = wrapper.find("[data-test='reset-button']")
            expect(component.length).toBe(1);

        })


    })




    describe('Batch Control Search API test cases', function () {

        const reqBody = { "batchDate": "13087", "mediaSource": "8", "batchNumber": "0450" }


        const resObject = {
            data: { searchResults: true, recordCount: 15, indicator: false, uniqueSArecCnt: 0 },
            errorCode: null,
            errorList: [],
            isRecordExist: true,
            message: "Search Result Found",
            status: "200",
            success: true,
        }



        beforeEach(function () {
            // import and pass your custom axios instance to this method
            moxios.install()
        })

        afterEach(function () {
            // import and pass your custom axios instance to this method
            moxios.uninstall()
        })

        it('should be success the api call', () => {
            moxios.wait(() => {
                let request = moxios.requests.mostRecent()
                request.respondWith(mockSuccess(resObject));
            })

            const dispatchBatchControlSearch = {
                type: actionTypes.BATCH_CONTROL_SEARCH_TYPE,
                batchSearchData: resObject
            }
            return store.dispatch(batchControlSearchAction(reqBody))
                .then(() => {
                    const actions = store.getActions()
                    expect(actions[0].batchSearchData).toEqual(dispatchBatchControlSearch.batchSearchData.data.searchResults);


                })

        })

    })


})




