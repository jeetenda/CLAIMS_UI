import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import Checkbox from '@material-ui/core/Checkbox';
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";

export default function BatchControlSearchForm(props) {
  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-batchDate"
            data-test='standard-batchDate'
            label="Batch Date (YYDDD)"
            value={props.values.batchDate}
            inputProps={{ maxLength: 5 }}
            onChange={props.handleChanges('batchDate')}
            placeholder=""
            helperText={props.errors.showBatchDateError ? ErrorConst.BATCH_DATE_ERROR : props.errors.showBatchDateFormatError ? ErrorConst.BATCH_DATE_FORMAT_ERROR : null}
            InputLabelProps={{
              shrink: true,
              required: true
            }}
            error={props.errors.showBatchDateError ? ErrorConst.BATCH_DATE_ERROR : props.errors.showBatchDateFormatError ? ErrorConst.BATCH_DATE_FORMAT_ERROR : null}
          />
        </div>

        <div className="mui-custom-form with-select input-md">
          <TextField
            id="standard-select-mediaSource"
            select
            data-test='standard-select-mediaSource'
            label="Media Source"
            value={props.values.mediaSource}
            inputProps={{ maxLength: 1 }}
            onChange={props.handleChanges('mediaSource')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Claims#1012'].length > 0 && props.dropdowns['Claims#1012'].map(each => (
              <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
            ))}

          </TextField>
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-batchNumber"
            data-test='standard-batchNumber'
            label="Batch Number"
            value={props.values.batchNumber}
            inputProps={{ maxLength: 4 }}
            onChange={props.handleChanges('batchNumber')}
            placeholder=""
            helperText={props.errors.showBatchNumberError ? ErrorConst.BATCH_NUMBER_ERROR : null}
            InputLabelProps={{
              shrink: true,
            }}
            error={props.errors.showBatchNumberError ? ErrorConst.BATCH_NUMBER_ERROR : null}
          />
        </div>
      </div>
      <div className="tab-footer container-space">
        <div className="float-right th-btnGroup">
          <Button
            title="Search"
            data-test='search-button'
            variant="outlined"
            color="primary"
            className="btn btn-ic btn-search"
            onClick={props.searchCheck}
            disabled={props.privileges && !props.privileges.search ? 'disabled' : ''}
          >
            {' '}
            Search
          {' '}

          </Button>
          <Button
            title="Reset"
            data-test='reset-button'
            variant="outlined"
            color="primary"
            className="btn btn-ic btn-reset"
            onClick={props.resetTable}
          >
            {' '}
            Reset
          {' '}

          </Button>

        </div>
      </div>
      <div className="clearfix" />
     
    </form >
  );
}
