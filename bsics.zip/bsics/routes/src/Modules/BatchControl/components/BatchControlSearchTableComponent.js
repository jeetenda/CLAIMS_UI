import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import { batchControlDetails } from '../actions';

const headCells = [
  {
    id: 'controlKey', numeric: false, disablePadding: true, label: 'Control Key', enableHyperLink: true, isConcat: true, fontSize: 12, width: 120
  },
  {
    id: 'batchEntryDate', numeric: false, disablePadding: false, label: 'Date Entered', enableHyperLink: false, isDate: true, fontSize: 12, width: 115
  },
  {
    id: 'documentCountNumber', numeric: false, disablePadding: false, label: 'Total Documents', enableHyperLink: false, fontSize: 12, width: 140
  },
  {
    id: 'documentTypeCodeDesc', numeric: false, disablePadding: false, label: 'Document Type', enableHyperLink: false, fontSize: 12, width: 120
  },
  {
    id: 'batchTypeCodeDesc', numeric: false, disablePadding: false, label: 'Batch Type', enableHyperLink: false, fontSize: 12, width: 120
  },
  {
    id: 'batchStatusCodeDesc', numeric: false, disablePadding: false, label: 'Batch Status', enableHyperLink: false, fontSize: 12, width: 120
  }
];

function BatchControlSearchTableComponent(props) {
  
  const errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(false);

  const dispatch = useDispatch();
  const onBatchControlDetails = (values) => dispatch(batchControlDetails(values));

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data); 
      tData = JSON.parse(tData);     
      tData.map((each,index) => {
        each.julianDateNumber = each.julianDateNumber,
        each.mediaSourceCode = each.mediaSourceCode,
        each.batchNumber = each.batchNumber,
        //Control Key Concatenate the Batch Date, Media Source and Batch Number to create the key value.
        each.controlKey = each.julianDateNumber + ' ' + each.mediaSourceCode + ' ' +each.batchNumber,
        each.index = index;
      }); 
      return tData;           
    }else{
      return [];
    }
  }

  const editRow = row => (event) => {
    onBatchControlDetails(row);
    props.history.push({
      pathname: '/BatchControlDetails'
    });
  };
  return (    
    <TableComponent headCells={headCells}  tableData={getTableData(props.tableData)} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />    
  );
}
export default withRouter(BatchControlSearchTableComponent);
