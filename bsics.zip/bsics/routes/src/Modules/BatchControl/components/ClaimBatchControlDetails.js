import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'react-bootstrap';
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import NavigationPrompt from "react-router-navigation-prompt";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import moment from 'moment';
import Axios from 'axios';
import ReactToPrint from 'react-to-print';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import * as serviceEndPoint from '../../../SharedModules/services/service';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS, setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import { batchControlAdd, batchControlUpdate, batchControlDelete, batchControlDetailsAction } from '../actions';
import Footer from '../../../SharedModules/Layout/footer';

function ClaimBatchControlDetails(props){
	const dispatch = useDispatch();
	const printRef = useRef();
	const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
	const onBatchControlAdd = (values) => dispatch(batchControlAdd(values));
	const onBatchControlUpdate = (values) => dispatch(batchControlUpdate(values));
	const onBatchControlDelete = (values) => dispatch(batchControlDelete(values));
	const onBatchControlDetails = (values) => dispatch(batchControlDetailsAction(values));
	const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
	const batchControlAddResponse = useSelector(state => state.batchControl.addResponse);
	const batchControlUpdateResponse = useSelector(state => state.batchControl.updateResponse);
	const batchControlDeleteResponse = useSelector(state => state.batchControl.deleteResponse);
	const batchControlData = useSelector(state => state.batchControl.batchControlData);
	const type = useSelector(state => state.batchControl.type);
    const [spinnerLoader, setspinnerLoader] = useState(false);
    const [successMessages, setSuccessMessages] = useState([]);
	const [errorMessages, seterrorMessages] = useState([]);
	const [edit, setEdit] = useState(false);
	const [statusValid, setStatusValid] = useState(false);
	const [prompt, setPrompt] = useState(false)
    const [cancelType, setCancelType] = useState(false);
    const [confirm, setConfirm] = useState(false);
    const [{batchDtReqErr, batchDtInvalidErr, batchDtgrtErr, mediaSrcReqErr, mediaSrcPaperErr, batchNumReqErr, batchNumInvalidErr, totalDocReqErr,
        beginDocReqErr, beginDocGrtZeroErr, endDocGrtZeroErr,totalDocGrtZeroErr, beginDocLessMaxErr, endDocReqErr, totalDocGrtErr, totalDocLesErr, docTypeReqErr, totalDocInvalidErr, beginDocInvalidErr, endDocInvalidErr,
        batchTypeReqErr, batchStatusReqErr, paymentTypeReqErr, paymentTypeEncErr, batchTypeRelativeErr, docTypeReleventErr, batchNumAdjErr, batchNumFfsErr}, setShowError] = useState(false);
    const [values, setValues] = useState({
        batchDate: '',
        mediaSource: '-1',
        batchNumber: '',
        totalDoc: '',
        beginDoc: '',
        endDoc: '',
        docType: '-1',
        batchType: '-1',
        batchStatus: 'A',
        batchStatusDate: new Date(),
        paymentType: ''
    });
    const [resetValues, setResetValues] = useState({
        batchDate: '',
        mediaSource: '-1',
        batchNumber: '',
        totalDoc: '',
        beginDoc: '',
        endDoc: '',
        docType: '-1',
        batchType: '-1',
        batchStatus: 'A',
        batchStatusDate: new Date(),
        paymentType: ''
    });

    const handleChanges= (name)=> event => {
        setValues({ ...values, [name]: event.target.value });
	};
	
	useEffect(() => {
		if (type == 'Add') {
			setEdit(false);
		} else {
			setEdit(true);
		}
	}, [type]);

	useEffect(() => {
		if (batchControlData) {
			let data = {
				batchDate: batchControlData.julianDateNumber,
				mediaSource: batchControlData.mediaSourceCode,
				batchNumber: batchControlData.batchNumber,
				totalDoc: batchControlData.documentCountNumber,
				beginDoc: batchControlData.beginDocumentNumber,
				endDoc: batchControlData.endDocumentNumber,
				docType: batchControlData.documentTypeCode,
				batchType: batchControlData.batchTypeCode,
				batchStatus: batchControlData.batchStatusCode,
				batchStatusDate: batchControlData.batchStatusDate ? batchControlData.batchStatusDate : new Date(),
				paymentType: batchControlData.paymentTypeCode
			}
			setValues(data);
			setResetValues(data);
			setStatusValid(batchControlData.batchStatusCode == 'I' || batchControlData.batchStatusCode == 'U');
		}
	}, [batchControlData]);
   
    useEffect(() => {
		onDropdowns([Dropdowns.CLAIMS_INQUIRY_MEDIA, Dropdowns.VV_DOC_TYPE, Dropdowns.VV_BATCH_TYPE, Dropdowns.VV_BATCH_STATUS]);
	}, []);
	
	const julianDateValidation = (date) => {
		let year = date.substring(0, 2);
		let day = date.substring(2);
		let thisYear = moment().year();
		let currentYear = String(thisYear).substring(2);
		let currentDay = moment().dayOfYear();
		if (Number(currentYear) < Number(year)) {
			return true;
		} else if (Number(currentYear) > Number(year)) {
			return false;
		} else if (Number(currentYear) == Number(year)) {
			if (Number(currentDay) >= Number(day)) {
				return false;
			} else if (Number(currentDay) < Number(day)) {
				return true;
			}
		}
	}
	
    const majorSave=()=>{
        seterrorMessages([]); 
        setSuccessMessages([]);
        let reqFieldArr = [];
        setShowError({
            batchDtReqErr: values.batchDate ? false : (()=>{reqFieldArr.push(ErrorConst.BATCH_DATE_REQ);return true;})(),
			batchDtInvalidErr: values.batchDate && (isNaN(values.batchDate) || Number(values.batchDate) < 0) ? (()=>{reqFieldArr.push(ErrorConst.DATCH_DATE_INVALID);return true;})() : false,
			batchDtgrtErr: julianDateValidation(values.batchDate) ? (()=>{reqFieldArr.push(ErrorConst.JULIAN_DATE_INVALID);return true;})() : false,
            mediaSrcReqErr: values.mediaSource && values.mediaSource != '-1' ? false : (()=>{reqFieldArr.push(ErrorConst.Media_Source_Error);return true;})(),
            mediaSrcPaperErr: edit ? false : values.mediaSource == '-1' || values.mediaSource == '8' ? false : (()=>{reqFieldArr.push(ErrorConst.MEDIA_SRC_PAPER);return true;})(),
            batchNumReqErr: values.batchNumber ? false : (()=>{reqFieldArr.push(ErrorConst.Batch_No_Error);return true;})(),
            batchNumInvalidErr: values.batchNumber && (isNaN(values.batchNumber) || Number(values.batchNumber).length < 4) ? (()=>{reqFieldArr.push(ErrorConst.Batch_No_INV_Error);return true;})() : false,
            totalDocReqErr: values.totalDoc ? false : (()=>{reqFieldArr.push(ErrorConst.TOTAL_DOC_REQ);return true;})(),
            totalDocInvalidErr: values.totalDoc && (isNaN(values.totalDoc) || Number(values.totalDoc) < 0) ? (()=>{reqFieldArr.push(ErrorConst.TOTAL_DOC_INVALID);return true;})() : false,
            beginDocReqErr: values.beginDoc ? false : (()=>{reqFieldArr.push(ErrorConst.BEGIN_DOC_REQ);return true;})(),
			beginDocGrtZeroErr: values.beginDoc && Number(values.beginDoc) < 1 ? (()=>{reqFieldArr.push(ErrorConst.BEGIN_DOC_GRT_ZERO);return true;})() : false,
			endDocGrtZeroErr: values.endDoc && Number(values.endDoc) < 1 ? (()=>{reqFieldArr.push(ErrorConst.END_DOC_GRT_ZERO);return true;})() : false,
			totalDocGrtZeroErr: values.totalDoc && Number(values.totalDoc) < 1 ? (()=>{reqFieldArr.push(ErrorConst.TOTAL_DOC_GRT_ZERO);return true;})() : false,
			beginDocLessMaxErr: values.beginDoc && Number(values.beginDoc) > 999999 ? (()=>{reqFieldArr.push(ErrorConst.BEGIN_DOC_LESS_MAX);return true;})() : false,
            endDocReqErr: values.endDoc ? false : (()=>{reqFieldArr.push(ErrorConst.END_DOC_REQ);return true;})(),
            totalDocGrtErr: values.totalDoc && values.beginDoc && values.endDoc && Number(values.beginDoc) >= 1 && Number(values.endDoc) >= 1 && Number(values.totalDoc) >=1 && ((Number(values.endDoc)+1 - Number(values.beginDoc)) > Number(values.totalDoc)) ? (()=>{reqFieldArr.push(ErrorConst.TOTAL_DOC_GRT);return true;})() : false,
            totalDocLesErr: values.totalDoc && values.beginDoc && values.endDoc && ((Number(values.endDoc)+1 - Number(values.beginDoc)) < Number(values.totalDoc)) ? (()=>{reqFieldArr.push(ErrorConst.TOTAL_DOC_LES);return true;})() : false,
            docTypeReqErr: values.docType && values.docType != '-1' ? false : (()=>{reqFieldArr.push(ErrorConst.DOC_TYPE_REQ);return true;})(),
            batchTypeReqErr: values.batchType && values.batchType != '-1' ? false : (()=>{reqFieldArr.push(ErrorConst.BATCH_TYPE_REQ);return true;})(),
            batchStatusReqErr: values.batchStatus && values.batchStatus != '-1' ? false : (()=>{reqFieldArr.push(ErrorConst.BATCH_STATUS_REQ);return true;})(),
            paymentTypeReqErr: values.paymentType ? false : (()=>{reqFieldArr.push(ErrorConst.PAYMENT_TYPE_REQ);return true;})(),
            batchTypeRelativeErr: values.batchType && values.docType && values.docType == 'A' && (values.batchType != 'Y' && values.batchType != 'Z' ) ? (()=>{reqFieldArr.push(ErrorConst.BATCH_TYPE_RELEVENT_ERR);return true;})() : false,
            docTypeReleventErr: values.batchType && values.docType && (values.batchType == 'Y' || values.batchType == 'Z' ) && values.docType != 'A' ? (()=>{reqFieldArr.push(ErrorConst.DOC_TYPE_RELEVENT_ERR);return true;})() : false,
            batchNumAdjErr: values.batchNumber && !isNaN(values.batchNumber) && values.docType && values.docType == 'A' && Number(values.batchNumber) < 8000 ? (()=>{reqFieldArr.push(ErrorConst.BATCH_NUM_BWT_8_9);return true;})() : false,
            batchNumFfsErr: values.batchNumber && !isNaN(values.batchNumber) && values.docType && values.docType == 'C' && Number(values.batchNumber) > 8000 ? (()=>{reqFieldArr.push(ErrorConst.BATCH_NUM_BET_0_7);return true;})() : false,
            beginDocInvalidErr: values.beginDoc && (isNaN(values.beginDoc) || Number(values.beginDoc) < 0) ? (()=>{reqFieldArr.push(ErrorConst.BEGIN_DOC_INVALID);return true;})() : false,
			endDocInvalidErr: values.endDoc && (isNaN(values.endDoc) || Number(values.endDoc) < 0) ? (()=>{reqFieldArr.push(ErrorConst.END_DOC_INVALID);return true;})() : false,
			paymentTypeEncErr: values.docType && values.docType == 'E' && values.paymentType != '0' ? (()=>{reqFieldArr.push(ErrorConst.DOC_TYPE_ENC_MAT);return true;})() : false,
        });
        
		if(reqFieldArr.length){
			seterrorMessages(reqFieldArr);
			return false;
		}
		setspinnerLoader(true);
		if (edit) {
			let data = {
                "auditUserID": batchControlData.auditUserID,
                "auditTimeStamp": batchControlData.auditTimeStamp,
                "addedAuditUserID": batchControlData.addedAuditUserID,
                "addedAuditTimeStamp": batchControlData.addedAuditTimeStamp,
                "versionNo": batchControlData.versionNo,
                "dbRecord": batchControlData.dbRecord,
                "sortColumn": batchControlData.sortColumn,
                "auditKeyList": batchControlData.auditKeyList,
                "auditKeyListFiltered": batchControlData.auditKeyListFiltered,
                "julianDateNumber": values.batchDate,
                "batchNumber": values.batchNumber,
                "mediaSourceCode": values.mediaSource,
                "mediaSourceCodeDesc": batchControlData.mediaSourceCodeDesc,
                "batchEntryDate": batchControlData.batchEntryDate,
                "batchStatusCode": values.batchStatus,
                "batchStatusCodeDesc": batchControlData.batchStatusCodeDesc,
                "batchTypeCode": values.batchType,
                "batchTypeCodeDesc": batchControlData.batchTypeCodeDesc,
                "documentTypeCodeDesc": batchControlData.documentTypeCodeDesc,
                "batchStatusDate": batchControlData.batchStatusDate,
                "paymentTypeCode": values.paymentType,
                "beginDocumentNumber": values.beginDoc,
                "endDocumentNumber": values.endDoc,
                "documentCountNumber": Number(values.totalDoc),
                "lastEnteredNumber": batchControlData.lastEnteredNumber,
                "highDocumentNumber": batchControlData.highDocumentNumber,
                "documentTypeCode": batchControlData.documentTypeCode,
                "enteredCountNumber": batchControlData.enteredCountNumber
            }               
			onBatchControlUpdate(data);
		} else {
			let data = {
				"auditUserID": "JMAUK72",
				"auditTimeStamp": "2013-04-24T06:24:56.079+0000",
				"addedAuditUserID": "JBANNISTER72",
				"addedAuditTimeStamp": "2013-03-31T11:35:41.969+0000",
				"julianDateNumber": values.batchDate,
				"batchNumber": values.batchNumber,
				"mediaSourceCode": values.mediaSource,
				"batchStatusCode": values.batchStatus,
				"batchTypeCode": values.batchType,
				"paymentTypeCode": values.paymentType,
				"beginDocumentNumber": values.beginDoc,
				"endDocumentNumber": values.endDoc,
				"documentCountNumber": values.totalDoc,
				"lastEnteredNumber": Number(values.totalDoc),
				"highDocumentNumber": Number(values.totalDoc),
				"documentTypeCode": values.docType,
				"enteredCountNumber": Number(values.totalDoc)
			}
			onBatchControlAdd(data);
		}
	};

	const majorDelete = () => {
		let r = window.confirm("Are you sure you want to delete the batch control record?");
		if (r) {
			seterrorMessages([]); 
        	setSuccessMessages([]);
			setspinnerLoader(true);
			let data = batchControlData;
			onBatchControlDelete(data);
		}
	}
	
	useEffect(() => {
		if (batchControlAddResponse != null) {
			setspinnerLoader(false);
			if (batchControlAddResponse.status == 500) {
				seterrorMessages([ErrorConst.ERROR_OCCURED_DURING_TRANSACTION]);
			}
			if (batchControlAddResponse.status == 400 && batchControlAddResponse.isRecordExist && !batchControlAddResponse.data) {
				seterrorMessages([ErrorConst.BATCH_CONTROL_DUPLICATE]);
			}
			if (batchControlAddResponse.status == 200 && !batchControlAddResponse.isRecordExist && batchControlAddResponse.data) {
				setSuccessMessages(['Batch Control Added Successfully']);
				onBatchControlDetails({"batchDate":values.batchDate,"mediaSource":values.mediaSource,"batchNumber":values.batchNumber});
			}
			if (batchControlAddResponse.status == 400 && !batchControlAddResponse.isRecordExist) {
				let reqFieldArr = [];
				batchControlAddResponse.errorList.map(each => {
					reqFieldArr.push(each.message)
				});
				seterrorMessages(reqFieldArr);
			}
		}
	}, [batchControlAddResponse]);

	useEffect(() => {
		if (batchControlUpdateResponse != null) {
			setspinnerLoader(false);
			if (batchControlUpdateResponse.status == 500) {
				seterrorMessages([ErrorConst.ERROR_OCCURED_DURING_TRANSACTION]);
			}
			if (batchControlUpdateResponse.status == 200) {
				setSuccessMessages(['Batch Control Updated Successfully']);
				onBatchControlDetails({"batchDate":values.batchDate,"mediaSource":values.mediaSource,"batchNumber":values.batchNumber});
			}
			if (batchControlUpdateResponse.status == 400) {
				let reqFieldArr = [];
				batchControlUpdateResponse.errorList.map(each => {
					reqFieldArr.push(each.message)
				});
				seterrorMessages(reqFieldArr);
			}
		}
	}, [batchControlUpdateResponse]);

	useEffect(() => {
		if (batchControlDeleteResponse != null) {
			setspinnerLoader(false);
			if (batchControlDeleteResponse.status == 500) {
				seterrorMessages([ErrorConst.ERROR_OCCURED_DURING_TRANSACTION]);
			}
			if (batchControlDeleteResponse.status == 400) {
				if (batchControlDeleteResponse.errorList.length > 0) {
					let reqFieldArr = [];
					batchControlDeleteResponse.errorList.map(each => {
						reqFieldArr.push(each.message)
					});
					seterrorMessages(reqFieldArr);
				} else {
					seterrorMessages([ErrorConst.BATCH_CONTROL_DELETE_EXCEPTION]);
				}
			}
			if (batchControlDeleteResponse.status == 200 && batchControlDeleteResponse.data) {
				setSuccessMessages(['Batch Control Deleted Successfully']);
				props.history.push({
					pathname: '/BatchControlSearch'
				});
			}
		}
	}, [batchControlDeleteResponse]);

	const searchProcedureCodeProvider = () => {
		setCancelType(true);
		props.history.push({
		  pathname: '/BatchControlSearch'
		})
	  }
	  const handelPromptSet = (set) => {
        if (set)
            setPrompt(true);
    }

    return(
	<div>
		 <NavigationPrompt
                when={(crntLocation, nextLocation) => { if (confirm) { return false } else { handelPromptSet(nextLocation); return true } }}
            // when={true}
            >
                {({ onConfirm, onCancel }) => (
                    <Dialog
                        open={prompt}
                        aria-labelledby="alert-dialog-title"
                        aria-describedby="alert-dialog-description"
                        className="custom-alert-box"
                    >
                        <DialogContent>
                            <DialogContentText id="alert-dialog-description">
                                {cancelType ? "Are you sure that you want to Cancel?" :
                                    (<>Unsaved changes will be lost. <br />
                                        Are you sure you want to continue?</>)}
                            </DialogContentText>
                        </DialogContent>
                        {cancelType ? (<DialogActions>
                            <Button onClick={onConfirm} color="primary" className="btn btn-success">
                                Ok
                            </Button>
                            <Button onClick={() => { setPrompt(false); setCancelType(false); onCancel() }} color="primary" autoFocus>
                                Cancel
                            </Button>
                        </DialogActions>) : (<DialogActions>
                            <Button onClick={() => { setPrompt(false); setCancelType(false); onCancel() }} color="primary" className="btn btn-transparent">
                                STAY ON THIS PAGE!
                            </Button>
                            <Button onClick={onConfirm} color="primary" className="btn btn-success" autoFocus>
                                CONTINUE <i className="fa fa-arrow-right ml-1"></i>
                            </Button>
                        </DialogActions>)}
                    </Dialog>
                )}
            </NavigationPrompt>
	<div className="mb-2">
				<BreadCrumbs
					parent="Claims"
					child1="Search Batch Control"
					child2={edit ? 'Edit Batch Control' : 'Add Batch Control' }
					path="BatchControlSearch"
				/>
			</div>
        {spinnerLoader ? <Spinner /> : null}
        { errorMessages.length > 0 ? (
			<div className="alert alert-danger custom-alert" role="alert">
				{errorMessages.map(message => <li>{message}</li>)}
			</div>
		) : null}
        { successMessages.length > 0 ? (
            <div className="alert alert-success custom-alert" role="alert">
            {successMessages.map(message => <li>{message}</li>)
            }
            </div>
        ) : null}
    <div className="tabs-container" ref={printRef}>
        <div className="tab-header" >
            <h2 className="page-heading float-left">{edit ? 'Edit' : 'Add' } Batch Control  </h2>
            <div className="float-right th-btnGroup">
             <Button title="Save" variant="outlined" data-test='test-btn-save' color="primary" className="btn btn-ic btn-save" onClick={majorSave}
			 disabled={edit ? (props.privileges && !props.privileges.update? 'disabled':''): (props.privileges && !props.privileges.add? 'disabled':'')}
			 >
             Save
             </Button>
             {edit ? (<Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={majorDelete}  disabled={props.privileges && !props.privileges.update? 'disabled':''}>
              Delete
            </Button>) : null}
             <Button title="Reset" variant="outlined" data-test='test-btn-reset' color="primary" className="btn btn-ic btn-reset" onClick={()=> {setValues(resetValues); seterrorMessages([]); setSuccessMessages([]); setShowError(false)}}>
              Reset
            </Button>
            
			 <Button title="Cancel" variant="outlined" color="primary" data-test='test-btn-cancel' className="btn btn-cancel" onClick={() => searchProcedureCodeProvider()}>
              Cancel
                </Button>
					{edit ? (
					<Button title="Audit Log" variant="outlined" color="primary" data-test='test-btn-audit'
					 className="btn btn-ic btn-audit">
					AUDIT LOG
				</Button>
					) : null}
				<ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (
                <Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
                  Print
                </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
             Help
            </Button>
            </div>
        </div>
        <div className="custom-hr my-1 pb-1">&nbsp;</div>
        <div className="tab-body p-3 mt-3">
        <div className="tabs-container tabs-container-inner mt-0">
				<div className="tab-header">
                    <h2 className="tab-heading float-left pt-0">Control Key</h2>
                    <div className="clearfix" />
                </div>
				<div className="tab-body-bordered m-0">
					<div className="form-wrapper">
							<div className="mui-custom-form with-select input-md">
								<TextField
									id="bc-batch-date"
									data-test='batch-date'
									required
									disabled={edit}
									label="Batch Date (YYDDD)"
									value={values.batchDate}
									inputProps={{ maxLength: 5 }}
									onChange={handleChanges('batchDate')}
									helperText={batchDtReqErr ? ErrorConst.BATCH_DATE_REQ : batchDtInvalidErr ? ErrorConst.DATCH_DATE_INVALID : batchDtgrtErr ? ErrorConst.JULIAN_DATE_INVALID : null}
									error={batchDtReqErr || batchDtInvalidErr || batchDtgrtErr}
									InputLabelProps={{
										shrink: true
									}}
								>
								</TextField>
							</div>

							<div
								className="mui-custom-form with-select input-md"
							>
								<TextField
									id="bc-media-sorce"
									select
									required
									disabled={edit}
									data-test='media-source'
									label="Media Source"
									value={values.mediaSource}
									inputProps={{ maxLength: 2 }}
									onChange={handleChanges('mediaSource')}
									placeholder="Please Select One"
									helperText={mediaSrcReqErr ? ErrorConst.Media_Source_Error : mediaSrcPaperErr ? ErrorConst.MEDIA_SRC_PAPER : null}
									error={mediaSrcReqErr || mediaSrcPaperErr}
									InputLabelProps={{
										shrink: true
									}}
								>
									<MenuItem value="-1">Please Select One</MenuItem>
									{addDropdowns && addDropdowns['Claims#C_BATCH_MEDIA_SRC_CD'] && addDropdowns['Claims#C_BATCH_MEDIA_SRC_CD'].map( each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> 
                                	 ))}
								</TextField>
							</div>
							<div
								className="mui-custom-form with-select input-md"
							>
								<TextField
									id="bc-batch-number"
									required
									disabled={edit}
									label="Batch Number"
									data-test='batch-number'
									value={values.batchNumber}
									inputProps={{ maxLength: 4 }}
									onChange={handleChanges('batchNumber')}
									helperText={batchNumReqErr ? ErrorConst.Batch_No_Error : batchNumInvalidErr ? ErrorConst.Batch_No_INV_Error : batchNumAdjErr ? ErrorConst.BATCH_NUM_BWT_8_9 : batchNumFfsErr ? ErrorConst.BATCH_NUM_BET_0_7 : null}
									error={batchNumReqErr || batchNumInvalidErr || batchNumAdjErr || batchNumFfsErr}
									InputLabelProps={{
										shrink: true
									}}
								>
								</TextField>
							</div>
						</div>
				</div>
			</div>
            <div className="tabs-container tabs-container-inner mt-0">
				<div className="tab-header">
                    <h2 className="tab-heading float-left">Documents</h2>
                    <div className="clearfix" />
                </div>
				<div className="tab-body-bordered m-0">
					<div className="form-wrapper">
							<div className="mui-custom-form with-select input-md">
								<TextField
									id="bc-total-doc"
									required
									label="Total Documents"
									data-test='total-documents'
									value={values.totalDoc}
									inputProps={{ maxLength: 10 }}
									onChange={handleChanges('totalDoc')}
									helperText={totalDocReqErr ? ErrorConst.TOTAL_DOC_REQ : totalDocGrtZeroErr ? ErrorConst.TOTAL_DOC_GRT_ZERO : totalDocInvalidErr ? ErrorConst.TOTAL_DOC_INVALID : totalDocGrtErr ? ErrorConst.TOTAL_DOC_GRT : totalDocLesErr ? ErrorConst.TOTAL_DOC_LES : null}
									error={totalDocReqErr || totalDocGrtZeroErr || totalDocGrtErr || totalDocLesErr || totalDocInvalidErr}
									InputLabelProps={{
										shrink: true
									}}
								>
								</TextField>
							</div>

							<div
								className="mui-custom-form with-select input-md"
							>
								<TextField
									id="bc-begin-doc"
									required
									disabled={edit}
									label="Begin Document"
									data-test='begin-doc'
									value={values.beginDoc}
									inputProps={{ maxLength: 10 }}
									onChange={handleChanges('beginDoc')}
									helperText={beginDocReqErr ? ErrorConst.BEGIN_DOC_REQ : beginDocInvalidErr ? ErrorConst.BEGIN_DOC_INVALID : beginDocGrtZeroErr ? ErrorConst.BEGIN_DOC_GRT_ZERO : beginDocLessMaxErr ? ErrorConst.BEGIN_DOC_LESS_MAX :null}
									error={beginDocReqErr || beginDocGrtZeroErr || beginDocInvalidErr || beginDocLessMaxErr}
									InputLabelProps={{
										shrink: true
									}}
								>
								</TextField>
							</div>
							
							<div
								className="mui-custom-form with-select input-md"
							>
								<TextField
									id="bc-end-doc"
									required
									label="End Document"
									data-test='end-doc'
									value={values.endDoc}
									inputProps={{ maxLength: 10 }}
									onChange={handleChanges('endDoc')}
									helperText={endDocReqErr ? ErrorConst.END_DOC_REQ : endDocInvalidErr ? ErrorConst.END_DOC_INVALID : endDocGrtZeroErr ? ErrorConst.END_DOC_GRT_ZERO : null}
									error={endDocReqErr || endDocGrtZeroErr || endDocInvalidErr}
									InputLabelProps={{
										shrink: true
									}}
								>
								</TextField>
							</div>
						</div>
				</div>
			</div>
            <div className="tabs-container tabs-container-inner mt-0">
				<div className="tab-header">
                    <h2 className="tab-heading float-left">Batch</h2>
                    <div className="clearfix" />
                </div>
				<div className="tab-body-bordered m-0">
					<div className="form-wrapper">
                        <div className="mui-custom-form with-select input-md">
								<TextField
									id="bc-document-type"
									select
									required
									disabled={edit}
									label="Document Type"
									data-test='document-type'
									value={values.docType}
									inputProps={{ maxLength: 2 }}
									onChange={handleChanges('docType')}
									placeholder="Please Select One"
									helperText={docTypeReqErr ? ErrorConst.DOC_TYPE_REQ : docTypeReleventErr ? ErrorConst.DOC_TYPE_RELEVENT_ERR : null}
									error={docTypeReqErr || docTypeReleventErr}
									InputLabelProps={{
										shrink: true
									}}
								>
									<MenuItem value="-1">Please Select One</MenuItem>
									{addDropdowns && addDropdowns['Claims#C_BATCH_DOC_TY_CD'] && addDropdowns['Claims#C_BATCH_DOC_TY_CD'].map( each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> 
                                	 ))}
								</TextField>
							</div>

							<div className="mui-custom-form with-select input-md">
								<TextField
									id="bc-batch-type"
									select
									required
									disabled={edit}
									label="Batch Type"
									data-test='batch-type'
									value={values.batchType}
									inputProps={{ maxLength: 2 }}
									onChange={handleChanges('batchType')}
									placeholder="Please Select One"
									helperText={batchTypeReqErr ? ErrorConst.BATCH_TYPE_REQ : batchTypeRelativeErr ? ErrorConst.BATCH_TYPE_RELEVENT_ERR : null}
									error={batchTypeReqErr || batchTypeRelativeErr}
									InputLabelProps={{
										shrink: true
									}}
								>
									<MenuItem value="-1">Please Select One</MenuItem>
									{addDropdowns && addDropdowns['Claims#C_BATCH_TY_CD'] && addDropdowns['Claims#C_BATCH_TY_CD'].map( each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> 
                                	 ))}
								</TextField>
							</div>
							<div className="mui-custom-form with-select input-md">
								<TextField
									id="bc-batch-status"
									select
                                    required
                                    disabled={edit ? statusValid : true}
									label="Batch Status"
									data-test='batch-status'
									value={values.batchStatus}
									inputProps={{ maxLength: 2 }}
									onChange={handleChanges('batchStatus')}
									placeholder="Please Select One"
									helperText={batchStatusReqErr ? ErrorConst.BATCH_STATUS_REQ : null}
									error={batchStatusReqErr}
									InputLabelProps={{
										shrink: true
									}}
								>
									<MenuItem value="-1">Please Select One</MenuItem>
									{addDropdowns && addDropdowns['Claims#C_BATCH_STAT_CD'] && addDropdowns['Claims#C_BATCH_STAT_CD'].map( each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> 
                                	 ))}
								</TextField>
							</div>
                            <div className="mui-custom-form">
                            	<label className="MuiFormLabel-root MuiInputLabel-shrink" data-test='batch-status-date'> Batch Status Date </label>
                                <div className="mt-3">{moment(values.batchStatusDate).utc().format('MM/DD/YYYY')}</div>
                            </div>
                            <div className="mui-custom-form field-md" data-test='payment-type'>
                            <div className="MuiFormLabel-root MuiInputLabel-shrink"><span className="MuiFormLabel-asterisk MuiInputLabel-asterisk">* </span> Payment Type </div>
                                <label className="sub-radio mt-0 wid-100">
                                <RadioGroup
                                    row
                                    aria-label="paymentType"
									name="paymentType"
                                    value={values.paymentType}
                                    onChange={handleChanges("paymentType")}
                                >
                                    <FormControlLabel
										disabled={edit}
                                        value="0"
                                        control={<Radio color="primary" />}
                                        label="For Payment"
                                    />
                                    <FormControlLabel
										disabled={edit}
                                        value="1"
                                        control={<Radio color="primary" />}
                                        label="History Only"
                                    />
                                </RadioGroup>
                                </label>
								{paymentTypeReqErr ? (<p className="MuiFormHelperText-root Mui-error Mui-required" id="standard-code-helper-text">{ErrorConst.PAYMENT_TYPE_REQ}</p>) : 
									paymentTypeEncErr ? (<p className="MuiFormHelperText-root Mui-error Mui-required" id="standard-code-helper-text">{ErrorConst.DOC_TYPE_ENC_MAT}</p>) : null }
                            </div>
						</div>
				</div>
			</div>
      </div>
		<Footer print />
	 </div>
	 </div>
    );
}

export default ClaimBatchControlDetails;