import React, { useState, useEffect, useRef } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import * as ErrorConst from "../../../SharedModules/Messages/ErrorMsgConstants";
import ReactToPrint from 'react-to-print';
import { resetSearchBatchControl, batchControlSearchAction,batchControlDropdowns, batchControlDetails } from '../actions';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import BatchControlSearchForm from './BatchControlSearchForm';
import BatchControlSearchTableComponent from './BatchControlSearchTableComponent';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_SYSTEMLIST_DROPDOWN, setPrintLayout} from '../../../SharedModules/Dropdowns/actions';
import moment from 'moment';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import Footer from '../../../SharedModules/Layout/footer';


function BatchControlSearch(props) {
  let errorMessagesArray = [];
  const [showNoRecords, setShowNoRecords] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    batchDate: '',
    mediaSource:'Please Select One',
    batchNumber: ''
  });
  const printRef = useRef();
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [{ showBatchDateError, showBatchNumberError, showBatchDateFormatError},
    setShowError] = React.useState(false);
  const [showTable, setShowTable] = useState(false);
  const [redirect, setRedirect] = useState(false);
  const [successMessages, setSuccessMessages] = useState([]);
  
  const paylod = useSelector(state => state.batchControl.payload);
  const onDropdowns = (values) => dispatch(GET_SYSTEMLIST_DROPDOWN(values));
  const searchDropdowns = useSelector(state => state.appDropDowns.sysdropdowns);
  const batchControlDeleteResponse = useSelector(state => state.batchControl.deleteResponse);

  const dispatch = useDispatch();
  const onReset = () => dispatch(resetSearchBatchControl());
  const onSearch = searchvalues => { return dispatch(batchControlSearchAction(searchvalues))};
  const onBatchControlDetails = (values) => dispatch(batchControlDetails(values));

  // values change function
  const handleChanges = name => (event) => {
    if (event.target.type === 'checkbox') {
      setValues({ ...values, [name]: event.target.checked });
    } else {
      setValues({ ...values, [name]: event.target.value });
    }
  };

  const tableErrorFunction = (error) => {
    seterrorMessages(error);
  }

  // reset table
  const resetTable = () => {
    setShowNoRecords(false);
    seterrorMessages([]);
    setShowError({
      showBatchDateError: false, 
      showBatchNumberError: false,
      showBatchDateFormatError: false
    });
    setValues(
      {
        batchDate: '',
        mediaSource:'Please Select One',
        batchNumber:''
      }
    );
    setShowTable(false);
    onReset()
  };

  // search function
  const searchCheck = () => {
    setShowTable(false);
    setSuccessMessages([]);
    setspinnerLoader(false);
    errorMessagesArray = [];
    seterrorMessages([]);
    let showBatchDateError;
    let showBatchNumberError;
    let showBatchDateFormatError;
  
    if(values.batchDate === undefined || values.batchDate === '' || values.batchDate === null){
        showBatchDateError = true;
        errorMessagesArray.push(ErrorConst.BATCH_DATE_ERROR);
        seterrorMessages(errorMessagesArray);
      
    }
    if(!(values.batchNumber === '' || values.batchNumber === undefined || values.batchNumber === null)){
      if (!/^[0-9]+$/.test(values.batchNumber)){
        showBatchNumberError = true;
        errorMessagesArray.push(ErrorConst.BATCH_NUMBER_ERROR);
        seterrorMessages(errorMessagesArray);
      }
    }   

   if (errorMessagesArray.length == 0) {
      setShowTable(true);
      setspinnerLoader(true);
      let searchCriteria = {};
      if (!(values.batchDate === '')) {
        const batchJulian = moment(values.batchDate,'YYDDD').toDate();
          if(isNaN(batchJulian)){
            showBatchDateFormatError =true;
              errorMessagesArray.push(ErrorConst.BATCH_DATE_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
              setspinnerLoader(false);
          }
        else{
          searchCriteria = {
            batchDate: values.batchDate !== '' ? values.batchDate : null,
            mediaSource: values.mediaSource !== 'Please Select One' ? values.mediaSource : null,
            batchNumber: values.batchNumber !== '' ? values.batchNumber : null,
          };
        }
        
      }
      
      onSearch(searchCriteria);
      setRedirect(true);
    }
    setShowError({
      showBatchDateError,
      showBatchNumberError,
      showBatchDateFormatError
    });
  };

  const addBatchControl = () => {
    props.history.push({
      pathname: '/BatchControlDetails'
    })
  }

  // on drg code page load
  
  useEffect(() => {
    setSuccessMessages([]);
    onReset();
    onDropdowns({
      "inputList" : [Dropdowns.MEDIA_SOURCE]
    });
  
    if (paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      setShowTable(true);
      if (paylod.length == 0) {
        setShowNoRecords(true);
      }
    }
    setShowTable(false);
    resetTable();
  }, []);

  // on batch Control page search data
  useEffect(() => {
    if (paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      setspinnerLoader(false);
    }
    if (paylod && paylod.message != null) {
      setspinnerLoader(false);
      errorMessagesArray.push(ErrorConst.ERROR_OCCURED_DURING_TRANSACTION);
      //errorMessagesArray.push(ErrorConst.NO_RECORDS_FOUND);
      seterrorMessages(errorMessagesArray);
    }
    if (paylod != null && paylod.length == 0) {
      setShowNoRecords(true);
    }
    if (paylod != null && paylod.length == 1 && redirect) {
      let data = paylod[0]
      onBatchControlDetails(data);
      props.history.push({
        pathname: '/BatchControlDetails'
      });
    }
  }, [paylod]);

  useEffect(() => {
		if (batchControlDeleteResponse != null) {
			if (batchControlDeleteResponse.status == 200 && batchControlDeleteResponse.data) {
				setSuccessMessages(['Batch Control Deleted Successfully']);
			}
		}
	}, [batchControlDeleteResponse]);

  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}
      { errorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert" role="alert">
          {errorMessages.map(message => <li>{message}</li>)
        }
        </div>
      ) : null
     }
      { errorMessages.length == 0 && paylod && paylod.length == 0 && showNoRecords ? (
        <div className="alert alert-danger custom-alert" role="alert">
          <li>{ErrorConst.NO_RECORDS_FOUND}</li>
        </div>
      ) : null
     }
     { successMessages.length > 0 ? (
            <div className="alert alert-success custom-alert" role="alert">
            {successMessages.map(message => <li>{message}</li>)
            }
            </div>
        ) : null}
        <div className="mb-2">
				 <BreadCrumbs
					parent="Claims"
					child1="Search Batch Control"
					path="BatchControlSearch"
				 />
      </div>
      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="tab-heading page-heading float-left">
            Search Batch Control
          </h1>
          <div className="float-right th-btnGroup">
          <Button title="Add Batch Control" variant="outlined" color="primary" className="btn btn-ic btn-add" onClick={() => addBatchControl()} disabled={props.privileges && !props.privileges.add? 'disabled':''}>
          Add 
            </Button>

            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (
                <Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
                  Print
                </Button>)}
              content={() => printRef.current}
            />
            
            {/* <Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
            Print
            </Button> */}
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
            Help
            </Button>
          </div>
          <div className="clearfix" />
        </div>
        <div className="custom-hr my-1 pb-1">&nbsp;</div>
        <div className="tab-body mt-3 pb-3">
        <BatchControlSearchForm values={values} handleChanges={handleChanges} resetTable={resetTable} searchCheck={searchCheck} dropdowns={searchDropdowns} errors={{ showBatchDateError, showBatchNumberError, showBatchDateFormatError}} privileges={props.privileges}/>

        {
          showTable && paylod && paylod.length > 0 ? (
            <div className="tab-holder container-space">
              <BatchControlSearchTableComponent
                className="mb-1"
                tableData={paylod}
                tableErrorFunction={tableErrorFunction}
                setspinnerLoader={setspinnerLoader}
              />

            </div>
          ) : null
        }
        </div>
        <Footer print />
      </div>
    </div>
  );
}
export default withRouter(BatchControlSearch);
