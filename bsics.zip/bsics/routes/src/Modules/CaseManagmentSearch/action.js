import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';


export const resetCaseSearch = () => ({
    type: actionTypes.RESETDATA,
    resetData: []
});

export const dispatchCaseNumberSearch = (response) => ({
    type: actionTypes.CASE_NUMBER_SEARCH,
    caseNumberData: response,
});
export const dispatchCaseHeadNameSearch = (response) => ({
    type: actionTypes.CASE_HEAD_NAME_SEARCH,
    caseHeadNameData: response,
});

export const dispatchMemberIdSearch = (response) => ({
    type: actionTypes.MEMBER_REP_MEMBERID_SEARCH,
    payload: response,
});

export const dispatchMemberNameSearch = (response) => ({
    type: actionTypes.MEMBER_REP_MEMBERNAME_SEARCH,
    payload: response,
});

export const dispatchRepNameSearch = (response) => ({
    type: actionTypes.MEMBER_REP_REPNAME_SEARCH,
    payload: response,
});

export const caseSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.CASE_SEARCH}`, values)
        .then(response => {
            if (response.data.status === 500 || response.data.status === 400) {
                dispatch(dispatchCaseNumberSearch(response.data));
            } else {
                if(values.searchBy == 'caseHeadName'){
                    dispatch(dispatchCaseHeadNameSearch(response.data))
                }else if(values.searchBy == 'caseNumber'){
                    dispatch(dispatchCaseNumberSearch(response.data));
                }     
            }
        })
        .catch(error => {
            dispatch(dispatchCaseNumberSearch(error.response));
        })
}

export const memberSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.MEMBER_REPRESENTATIVE_SEARCH_ENDPOINT}`, values)
        .then(response => {
            if(values.searchBy == 'Others'){
                dispatch(dispatchMemberIdSearch(response.data))
            }else if(values.searchBy == 'Name'){
                dispatch(dispatchMemberNameSearch(response.data));
            } else if(values.searchBy == 'REP'){
                dispatch(dispatchRepNameSearch(response.data));
            }     
        })
        .catch(error => {
            if(values.searchBy == 'Others'){
                dispatch(dispatchMemberIdSearch(error.data))
            }else if(values.searchBy == 'Name'){
                dispatch(dispatchMemberNameSearch(error.data));
            } else if(values.searchBy == 'REP'){
                dispatch(dispatchRepNameSearch(error.data));
            }
        })
}