import * as actionTypes from './actionTypes';



const axiosPayLoad = {
    caseNumberPayload: null,
    caseHeadNamePayload: null,
    memberIdPayload: null,
    memberNamePayload: null,
    repNamePayload: null,
  };

  const reducer = (state = axiosPayLoad, action) => {
    switch (action.type) {
  
      case actionTypes.RESETDATA:
        return axiosPayLoad;
        
      case actionTypes.CASE_NUMBER_SEARCH:
        return { ...state, caseNumberPayload: action.caseNumberData }
  
      case actionTypes.CASE_HEAD_NAME_SEARCH:
        return { ...state, caseHeadNamePayload: action.caseHeadNameData }

      case actionTypes.MEMBER_REP_MEMBERID_SEARCH:
        return { ...state, memberIdPayload: action.payload }

      case actionTypes.MEMBER_REP_MEMBERNAME_SEARCH:
        return { ...state, memberNamePayload: action.payload }

      case actionTypes.MEMBER_REP_REPNAME_SEARCH:
        return { ...state, repNamePayload: action.payload }

      default: return state;
    }
  };
  
  export default reducer;