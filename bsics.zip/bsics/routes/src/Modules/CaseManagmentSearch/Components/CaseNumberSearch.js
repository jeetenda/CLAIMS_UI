import React from "react"
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import MenuItem from '@material-ui/core/MenuItem';
import * as CaseSearchConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import dateFnsFormat from 'date-fns/format';
import DateFnsUtils from '@date-io/date-fns';

function CaseNumberSearch(props) {
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const [selectedToDate, setSelectedToDate] = React.useState('');
    const [selectedFromDate, setSelectedFromDate] = React.useState('');
    
    
    const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        dt = new Date(dt);
        if (dt.toString() == "Invalid Date") {
            return dt;
        } else {
            return dateFnsFormat(dt, "MM/dd/yyyy");
        }
    };

    const handleFromDateChange = date => {
        // setSelectedFromDate(date);
        props.handleDCDtChange('fromDate', formatDate(date));
    };

    const handleToDateChange = date => {
        // setSelectedToDate(date);
        props.handleDCDtChange('toDate', formatDate(date));
    };

    React.useEffect(() => {
        props.values.fromDate !== '' ? setSelectedFromDate(props.values.fromDate) : setSelectedFromDate('');
    }, []);

    React.useEffect(() => {
         props.values.toDate !== '' ? setSelectedToDate(props.values.toDate) : setSelectedToDate('');
    }, []);
    
    const lobDropDown = props.dropdowns &&  props.dropdowns['Claims#R_LOB_CD'] && props.dropdowns['Claims#R_LOB_CD'].map( each => (
		<MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
     ));
    return (
        < >
        
        <form autoComplete="off">
        {spinnerLoader ? <Spinner /> : null}
            <div className="tab-body mt-2">
                <div className="form-wrapper">
                <div className="mui-custom-form input-md ">
                    <TextField
                        id="case_num_case_num_tab"
                        label="Case Number"
                        className="inline-lable-ttl"
                        value={props.values.caseNumber}
                        inputProps={{ maxLength: 15 }}
                        onChange={props.handleChanges('caseNumber')}
                        placeholder=""
                        helperText={props.errors.showCaseNumberError ? CaseSearchConstants.CASE_NUMBER : props.errors.showCaseNumberErrorEnv ? CaseSearchConstants.CASE_NUMBER_ERROR : null}
                        InputLabelProps={{
                            shrink: true,
                            required: true
                        }}
                        error={props.errors.showCaseNumberError ? CaseSearchConstants.CASE_NUMBER : props.errors.showCaseNumberErrorEnv ? CaseSearchConstants.CASE_NUMBER_ERROR : null}
                        data-test="case-number"
                    />
                </div>
                </div>
                <div className="form-wrapper">
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select">
                                <KeyboardDatePicker
                                    id="from_date_case_num_tab"
                                    label="From Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.fromDate ? props.values.fromDate : null}
                                    onChange={handleFromDateChange}
                                    helperText={props.errors.showfromDateInvError ? CaseSearchConstants.CASE_DATE_INVALID : null}
                                    error={props.errors.showfromDateInvError ? CaseSearchConstants.CASE_DATE_INVALID : null}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                    data-test="from-date"
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select" >
                                <KeyboardDatePicker
                                    id="to_date_case_num_tab"
                                    label="To Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true
                                        
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.toDate ? props.values.toDate : null}
                                    onChange={handleToDateChange}
                                    helperText={props.errors.showtoDateInvError ? CaseSearchConstants.CASE_DATE_INVALID : null}
                                    error={props.errors.showtoDateInvError ? CaseSearchConstants.CASE_DATE_INVALID : null}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                    data-test="to-date"
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="lob_case_num_tab"
                                select
                                label="LOB"
                                value={props.values.lob}
                                inputProps={{ maxLength: 25 }}
                                onChange={props.handleChanges('lob')}
                                placeholder="Please Select One"
                                // helperText={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test="lob"
                                // error={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {lobDropDown}
                            </TextField>
                        </div>
                </div>
            </div>
            <div className="tab-header mb-3">
                    <div className="float-right th-btnGroup">
                        <Button
                            title="Search"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-search"
                            onClick={props.searchCheck}
                            data-test="btn-search"
                        >
                            {' '}
                            Search
          {' '}

                        </Button>
                        <Button
                            title="Reset"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-reset"
                            onClick={props.resetTable}
                            data-test="btn-reset"
                        >
                            {' '}
                            Reset
          {' '}

                        </Button>
                    </div>
                </div>
                <div className="clearfix" />
        </form>
        </>
    )
}


export default CaseNumberSearch;
   