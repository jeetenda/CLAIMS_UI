import React from "react"
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
// import MenuItem from '@material-ui/core/MenuItem';
import * as MemberInquiryConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import MenuItem from '@material-ui/core/MenuItem';
import { useDispatch, useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import dateFnsFormat from 'date-fns/format';
import { resetCaseSearch, caseSearchAction } from '../action';
import * as CaseSearchConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import CaseHeadNameSearchTable from '../Components/CaseHeadNameSearchTable';
function CaseHeadNameSearch(props) {
    let errorMessagesArray = [];
    let nameErrorMessagesArray = [];
    const dispatch = useDispatch();
    const [showNoRecords, setShowNoRecords] = useState(false);
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const [showTable, setShowTable] = useState(false);
    const [showRecords, setShowRecords] = useState([]);
    const onReset = () => dispatch(resetCaseSearch());
    const onSearch = searchvalues => { return dispatch(caseSearchAction(searchvalues)) };
    const [values, setValues] = useState({
        "lastName": "",
        "lastNameStartWithOrPhonetic": "",
        "firstName": "",
        "firstNameStartWithOrPhonetic": "",       
        "fromDate": "",
        "toDate": "",
        "lob": "MED",
    });
    const [errorMessages, seterrorMessages] = React.useState([]);
    const handleChanges = name => (event) => {
        setValues({ ...values, [name]: event.target.value });
    };
    const [lastNameError, setLastNameError] = React.useState(false);
    const [firstNameError, setFirstNameError] = React.useState(false);
    const [{ showlastNameError, showlastNameReqError, showLastNameNumericError, showFirstNameError, showFirstNameReqError, showFirstNameNumericError, 
        showfromDateError,
        showtoDateError,
        showLobError, showtoDateInvError, showfromDateInvError},
        setShowError] = React.useState(false);

    const [selectedDOB, setSelectedDOB] = React.useState('');
    const [selectedToDate, setSelectedToDate] = React.useState('');
    const [selectedFromDate, setSelectedFromDate] = React.useState('');
    const [redirect, setRedirect] = useState(false);
    const payload = useSelector(state => state.caseSearch.caseHeadNamePayload);
    const handleDCDtChange = (name, date) => {
        setValues({ ...values, [name]: date });
    }
    const handleFromDateChange = date => {
        // setSelectedAdjudicationBeginDate(date);
        handleDCDtChange('fromDate', formatDate(date));
    };

    const handleToDateChange = date => {
        // setSelectedAdjudicationEndDate(date);
        handleDCDtChange('toDate', formatDate(date));
    };
    const handleDOBDateChange = date => {
        // setSelectedPaidBeginDate(date);
        handleDCDtChange('dob', formatDate(date));
    };

    const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        dt = new Date(dt);
        if (dt.toString() == "Invalid Date") {
            return dt;
        } else {
            return dateFnsFormat(dt, "MM/dd/yyyy");
        }
    };
    React.useEffect(() => {
        values.fromDate !== '' ? setSelectedFromDate(values.fromDate) : setSelectedFromDate('');

    }, []);
    React.useEffect(() => {
        values.toDate !== '' ? setSelectedToDate(values.toDate) : setSelectedToDate('');
    }, []);
    React.useEffect(() => {
        values.dob !== '' ? setSelectedDOB(values.dob) : setSelectedDOB('');
    }, []);

    const resetTable = () => {
        setShowNoRecords(false);
        props.setNameErrorMessages([]);
        props.setNameTabErrorMessages([]);
        setLastNameError(false)
        setFirstNameError(false)
        setShowRecords([])
        setShowError({
            showlastNameError: false,
            showlastNameReqError: false,
            showFirstNameError: false,
            showFirstNameReqError: false,
           
            showfromDateError: false,
            showtoDateError: false,
            showLobError: false,
            showfromDateInvError: false,
            showtoDateInvError: false,
            
            showLastNameNumericError: false,
            showFirstNameNumericError: false,
        });
        setValues(
            {
                "lastName": "",
                "lastNameStartWithOrPhonetic": "",
                "firstName": "",
                "firstNameStartWithOrPhonetic": "",
                "fromDate": "",
                "toDate": "",
                "lob": "MED",
            }
        );
        setShowTable(false);
        onReset()
    };
    const searchCheck = () => {
        setShowTable(false);
        setspinnerLoader(false);
        errorMessagesArray = [];
        nameErrorMessagesArray = [];
        props.setNameErrorMessages([]);
        setShowError({});
        let showlastNameError;
        let showlastNameReqError;
        let showFirstNameError;
        let showFirstNameReqError;
        let showfromDateError;
        let showtoDateError;
        let showLobError;
        let showfromDateInvError;
        let showtoDateInvError;
        let showLastNameNumericError;
        let showFirstNameNumericError;

        if (values.lastName == '') {
            showlastNameError = true;
            errorMessagesArray.push(CaseSearchConstants.CASE_LAST_NAME);
        }

        if (values.fromDate != '' && values.fromDate.toString() == "Invalid Date") {
            showfromDateInvError = true;
            errorMessagesArray.push(CaseSearchConstants.Invalid_From_Date_Error);
        }
        if (values.toDate != '' && values.toDate.toString() == "Invalid Date") {
            showtoDateInvError = true;
            errorMessagesArray.push(CaseSearchConstants.Invalid_To_Date_Error);
        }

        if(values.lastName != ''){
            var regex = /^[a-zA-Z]+$/;
            if (regex.test(values.lastName)) {
                if (values.lastName && (!values.lastName || values.lastName.length < 2)) {
                    showlastNameReqError = true;
                    errorMessagesArray.push(CaseSearchConstants.LAST_NAME_ENV_Error);
                }
            } else {
                if (values.lastName && (!values.lastName || values.lastName.length < 2)) {
                    showlastNameReqError = true;
                    showLastNameNumericError = true;
                    errorMessagesArray.push(CaseSearchConstants.LASTNAME_INVALID_Error);
                    errorMessagesArray.push(CaseSearchConstants.LAST_NAME_ENV_Error);
                    
                }else{
                    setLastNameError(true);
                    props.nameTabErrorMessages.pop()
                    props.nameTabErrorMessages.push(['Warning-Member last name contains invalid characters. System will continue processing the name as entered.'])
                }
                
            }
        }
        if (values.firstName != '') {
            var regex = /^[a-zA-Z]+$/;
            if (regex.test(values.firstName)) {
                if (values.firstName && (!values.firstName || values.firstName.length < 2)) {
                    showFirstNameReqError = true;
                    errorMessagesArray.push(CaseSearchConstants.FIRST_NAME_ENV_Error);
                }
            } else {
                if (values.firstName && (!values.firstName || values.firstName.length < 2)) {
                    showFirstNameReqError = true;
                    showFirstNameNumericError = true;
                    errorMessagesArray.push(CaseSearchConstants.FIRSTNAME_INVALID_Error);
                    errorMessagesArray.push(CaseSearchConstants.FIRST_NAME_ENV_Error);
                }else{
                    setFirstNameError(true);
                    props.nameTabErrorMessages.push(['Warning-Member first name contains invalid characters. System will continue processing the name as entered.'])
                }
                
                
            }
        }

        if (errorMessagesArray.length == 0) {
            setShowTable(false);
            setspinnerLoader(true);
            props.setRedirect(true);
            let searchCriteria = {};
            if (!(values.lastName === '')) {
                searchCriteria = {
                    "caseHeadLastName": values.lastName,
                    "phoneticCaseHeadLastName": values.lastNameStartWithOrPhonetic === 'Phonetic' ? true : false,
                    "caseHeadLastNameStartwith": values.lastNameStartWithOrPhonetic === 'StartsWith' ? true : false,
                    "caseHeadFirstName": values.firstName ? values.firstName : '',
                    "phoneticCaseHeadFirstName": values.firstNameStartWithOrPhonetic === 'Phonetic' ? true : false,
                    "caseHeadFirstCaseNameStartwith": values.firstNameStartWithOrPhonetic === 'StartsWith' ? true : false,
                    "strFromDate": values.fromDate ? values.fromDate : '',
                    "strToDate": values.toDate ? values.toDate : '',
                    "lob": values.lob !== '-1' ? values.lob : '',
                    "searchBy": "caseHeadName"
                };
                setspinnerLoader(true);
                onSearch(searchCriteria);
            }

        } else {
            props.setNameTabErrorMessages(props.nameTabErrorMessages)
            props.setNameErrorMessages(errorMessagesArray);
            props.seterrorMessages([])
            setShowTable(false);
            
            setShowError({
                showlastNameError,
                showlastNameReqError,
                showFirstNameError,
                showFirstNameReqError,
               
                showfromDateError,
                showtoDateError,
                showLobError,
                showtoDateInvError,
                showfromDateInvError,
                showLastNameNumericError,
                showFirstNameNumericError,
            });
        }
    };
    useEffect(() => {
        if (payload && payload.data == null) {
            setspinnerLoader(false);
            setShowRecords([])
            props.setNameErrorMessages([CaseSearchConstants.CASE_NO_RECORDS]);
            props.seterrorMessages([])
        }
        if (payload && payload.data != null && payload.data.recordCount == 0) {
            setspinnerLoader(false);
            setShowRecords([])
            props.setNameErrorMessages([CaseSearchConstants.CASE_NO_RECORDS]);
            props.seterrorMessages([])
        }
        if (payload && payload.data != null && payload.data.recordCount > 1) {
            setspinnerLoader(false);
            setShowRecords(payload.data.searchResults)
        }
        if (payload && payload.data != null && payload.data.recordCount == 1) {
            // setspinnerLoader(false);
            setspinnerLoader(false);
            setShowRecords([])
            props.history.push({
                pathname: '/caseMemberDetails'                
            });
           
        }
    }, [payload]);
    const lobDropDown = props.dropdowns && props.dropdowns['Claims#R_LOB_CD'] && props.dropdowns['Claims#R_LOB_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));
 
    return (
        < >
            {spinnerLoader ? <Spinner /> : null}
           
            <form autoComplete="off">
                {/* {props.spinnerLoader ? <Spinner /> : null} */}
                <div className="tab-body mt-2">
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md input-md-2-col" data-test="last-name">
                            <TextField
                                id="case_head_lname_case_head_tab"
                                label="Case Head Last Name"
                                className="inline-lable-ttl"
                                value={values.lastName}
                                inputProps={{ maxLength: 35 }}
                                onChange={handleChanges('lastName')}
                                placeholder=""
                                helperText={showlastNameError ? CaseSearchConstants.CASE_LAST_NAME : showLastNameNumericError ? CaseSearchConstants.LASTNAME_INVALID_Error :
                                    showlastNameReqError ? CaseSearchConstants.LAST_NAME_ENV_Error : lastNameError ? CaseSearchConstants.LASTNAME_INVALID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                    required: true
                                }}
                                error={showlastNameError ? CaseSearchConstants.CASE_LAST_NAME : showLastNameNumericError ? CaseSearchConstants.LASTNAME_INVALID_Error :
                                    showlastNameReqError ? CaseSearchConstants.LAST_NAME_ENV_Error : lastNameError ? CaseSearchConstants.LASTNAME_INVALID_Error : null}               
                            />
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="Case Head Last Name"
                                    onChange={handleChanges('lastNameStartWithOrPhonetic')}
                                >
                                    <FormControlLabel
                                        value="StartsWith"
                                        id="start_with_case_head_lname_case_head_tab"
                                        control={<Radio color="primary" />}
                                        label="Starts With"
                                        checked={values.lastNameStartWithOrPhonetic === 'StartsWith'}
                                    />
                                    <FormControlLabel
                                        value="Phonetic"
                                        id="phonetic_case_head_lname_case_head_tab"
                                        control={<Radio color="primary" />}
                                        label="Phonetic"
                                        checked={values.lastNameStartWithOrPhonetic === 'Phonetic'}
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                        <div className="mui-custom-form input-md input-md-2-col" data-test="first-name">
                            <TextField
                                id="case_head_fname_case_head_tab"
                                label="Case Head First Name"
                                className="inline-lable-ttl"
                                value={values.firstName}
                                inputProps={{ maxLength: 25 }}
                                onChange={handleChanges('firstName')}
                                placeholder=""
                                helperText={ showFirstNameNumericError ? CaseSearchConstants.FIRSTNAME_INVALID_Error : showFirstNameReqError ? CaseSearchConstants.FIRST_NAME_ENV_Error
                                    : firstNameError ? CaseSearchConstants.FIRSTNAME_INVALID_Error : null}
                                InputLabelProps={{
                                    shrink: true
                                }}
                                error={ showFirstNameNumericError ? CaseSearchConstants.FIRSTNAME_INVALID_Error : showFirstNameReqError ? CaseSearchConstants.FIRST_NAME_ENV_Error
                                     : firstNameError ? CaseSearchConstants.FIRSTNAME_INVALID_Error : null}
                            />
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="Case Head First Name"
                                    onChange={handleChanges('firstNameStartWithOrPhonetic')}
                                >
                                    <FormControlLabel
                                        value="StartsWith"
                                        id="start_with_case_head_fname_case_head_tab"
                                        control={<Radio color="primary" />}
                                        label="Starts With"
                                        checked={values.firstNameStartWithOrPhonetic === 'StartsWith'}
                                    />
                                    <FormControlLabel
                                        value="Phonetic"
                                        id="phonetic_case_head_fname_case_head_tab"
                                        control={<Radio color="primary" />}
                                        label="Phonetic"
                                        checked={values.firstNameStartWithOrPhonetic === 'Phonetic'}
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                    </div>
                   
                    <div className="form-wrapper">
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select" data-test="from-date">
                                <KeyboardDatePicker
                                    id="from_date_case_head_tab"
                                    label="From Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={values.fromDate ? values.fromDate : null}
                                    onChange={handleFromDateChange}
                                    helperText={showfromDateInvError ? MemberInquiryConstants.Invalid_From_Date_Error : null}
                                    error={showfromDateInvError ? MemberInquiryConstants.Invalid_From_Date_Error : null}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}  
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select" >
                                <KeyboardDatePicker
                                    id="to_date_case_head_tab"
                                    label="To Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true

                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={values.toDate ? values.toDate : null}
                                    onChange={handleToDateChange}
                                    helperText={showtoDateInvError ? MemberInquiryConstants.Invalid_To_Date_Error : null}
                                    error={showtoDateInvError ? MemberInquiryConstants.Invalid_To_Date_Error : null}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="lob_case_head_tab"
                                select
                                label="LOB"
                                value={values.lob}
                                inputProps={{ maxLength: 25 }}
                                onChange={handleChanges('lob')}
                                placeholder="Please Select One"
                                // helperText={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            // error={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {lobDropDown}
                            </TextField>
                        </div>
                    </div>
                </div>
                <div className="tab-header mb-3">
                    <div className="float-right th-btnGroup" data-test="btn-search">
                        <Button
                            title="Search"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-search"
                            onClick={searchCheck} 
                        >
                            {' '}
                            Search
      {' '}

                        </Button>
                        <Button
                            title="Reset"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-reset"
                            onClick={resetTable}
                        >
                            {' '}
                            Reset
      {' '}

                        </Button>
                    </div>
                </div>
                <div className="clearfix" />

            </form>
            {showRecords ? <CaseHeadNameSearchTable tableData={showRecords} /> : null}
        </>
    )
}


export default CaseHeadNameSearch;