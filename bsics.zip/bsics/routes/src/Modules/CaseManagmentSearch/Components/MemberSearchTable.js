import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import * as moment from "moment";

const headCells = [
    {
        id: 'currAltID', numeric: false, disablePadding: true, label: 'Member ID', enableHyperLink: true, width: 110, fontSize: 12
    },
    {
        id: 'currAltIDTypeCode', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, width: 110, fontSize: 12
    },
    {
        id: 'memberName', numeric: false, disablePadding: false, label: 'Full Name', enableHyperLink: false, width: 140, fontSize: 12
    },
    {
        id: 'ssn', numeric: false, disablePadding: false, label: 'SSN', enableHyperLink: false, width: 110, fontSize: 12
    },
    {
        id: 'dateOfBirth', numeric: false, disablePadding: false, label: 'DOB', enableHyperLink: false, isDate: true, width: 110, fontSize: 12
    },
    {
        id: 'genderDesc', numeric: false, disablePadding: false, label: 'Gender', enableHyperLink: false, width: 80, fontSize: 12
    },
    {
        id: 'caseNum', numeric: false, disablePadding: false, label: 'Case Number', enableHyperLink: false, width: 110, fontSize: 12
    }
];
function MemberSearchTable(props) {
    const errorMessagesArray = [];
    const [showTable, setShowTable] = React.useState(false);
    const dispatch = useDispatch();
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const editRow = row => (event) => {
        props.history.push({
            pathname: '/MemberRepresentativeDetails'
        });
      };

    const getFullData = (tableData) => {
        if(tableData && tableData.length) {
          let fData = JSON.stringify(tableData);
          fData = JSON.parse(fData);
          return fData;
        } else {
          return [];
        }
      }
      
    const tableComp = <TableComponent headCells={headCells} tableData={getFullData(props.tableData)} onTableRowClick={editRow} defaultSortColumn="claimType" />;

    return (
        <>
         {spinnerLoader ? <Spinner /> : null}
        <div className="mb-4">
            {props.tableData && props.tableData.length ?
                tableComp : null}
        </div>
</>
    );
}
export default withRouter(MemberSearchTable);