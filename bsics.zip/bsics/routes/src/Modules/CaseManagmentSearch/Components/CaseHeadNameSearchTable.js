import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import * as moment from "moment";

const headCells = [
    {
        id: 'caseNumber', numeric: false, disablePadding: true, label: 'Case Number', enableHyperLink: true, width: 100, fontSize: 12
    },
    {
        id: 'caseHeadName', numeric: false, disablePadding: false, label: 'Case Head Name', enableHyperLink: false, width: 100, fontSize: 12
    },
    {
        id: 'memberSysID', numeric: false, disablePadding: false, label: 'Member ID', enableHyperLink: false, width: 130, fontSize: 12
    },
    {
        id: 'currAltIDTypeCode', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, width: 100, fontSize: 12
    },
    {
        id: 'ssn', numeric: false, disablePadding: false, label: 'SSN', enableHyperLink: false, width: 100, fontSize: 12
    },
    {
        id: 'lineOfBusiness', numeric: false, disablePadding: false, label: 'LOB', enableHyperLink: false, width: 80, fontSize: 12
    }
];
function CaseHeadNameSearchTable(props) {
    const errorMessagesArray = [];
    const [showTable, setShowTable] = React.useState(false);
    const dispatch = useDispatch();
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const editRow = row => (event) => {
        setspinnerLoader(true);
        props.history.push({
            pathname: '/caseMemberDetails'
        });
    };

    const getFullData = (tableData) => {
        if (tableData && tableData.length) {
            let fData = JSON.stringify(tableData);
            fData = JSON.parse(fData);

            fData.map((each, index) => {
                each.index = index;
                // each.dateOfBirth = moment(each.dateOfBirth).format('MM/DD/YYYY');
            });

            return fData;
        } else {
            return [];
        }
    }

    const tableComp = <TableComponent headCells={headCells} tableData={getFullData(props.tableData ? props.tableData : [])} onTableRowClick={editRow} defaultSortColumn="claimType" />;

    return (
        <>
            {spinnerLoader ? <Spinner /> : null}

            <div className="mb-4">
                {props.tableData && props.tableData.length ?
                    <div className="fw-600 mb-2">Search Results</div> : ''}
                {props.tableData && props.tableData.length ?
                    tableComp : null}
            </div>
        </>
    );
}
export default withRouter(CaseHeadNameSearchTable);