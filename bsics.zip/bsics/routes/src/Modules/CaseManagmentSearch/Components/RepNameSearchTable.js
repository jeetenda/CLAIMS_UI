import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import * as moment from "moment";

const headCells = [
    {
        id: 'repFullName', numeric: false, disablePadding: true, label: 'Member Rep Full Name', enableHyperLink: true, width: 140, fontSize: 12
    },
    {
        id: 'organizationName', numeric: false, disablePadding: false, label: 'Organization Name', enableHyperLink: false, width: 140, fontSize: 12
    },
    {
        id: 'currAltID', numeric: false, disablePadding: false, label: 'Member ID', enableHyperLink: false, width: 120, fontSize: 12
    },
    {
        id: 'memberName', numeric: false, disablePadding: false, label: 'Full Name', enableHyperLink: false, width: 140, fontSize: 12
    }
];
function RepNameSearchTable(props) {
    const errorMessagesArray = [];
    const [showTable, setShowTable] = React.useState(false);
    const dispatch = useDispatch();
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const editRow = row => (event) => {
        props.history.push({
            pathname: '/MemberRepresentativeDetails'
        });
      };

    const getFullData = (tableData) => {
        if(tableData && tableData.length) {
          let fData = JSON.stringify(tableData);
          fData = JSON.parse(fData);
          return fData;
        } else {
          return [];
        }
      }
      
    const tableComp = <TableComponent headCells={headCells} tableData={getFullData(props.tableData)} onTableRowClick={editRow} defaultSortColumn="claimType" />;

    return (
        <>
         {spinnerLoader ? <Spinner /> : null}
        <div className="mb-4">
            {props.tableData && props.tableData.length ?
                tableComp : null}
        </div>
</>
    );
}
export default withRouter(RepNameSearchTable);