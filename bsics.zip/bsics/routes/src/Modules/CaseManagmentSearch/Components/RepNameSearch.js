import React from "react"
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import MenuItem from '@material-ui/core/MenuItem';
import * as MemberSearchConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { useDispatch, useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import dateFnsFormat from 'date-fns/format';
function MemberIDSearch(props) {

    return (
        < >

            <form autoComplete="off">
                <div className="tab-body mt-2">
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md ">
                            <TextField
                                data-test='RNS-last-name'
                                id="RNS-last-name"
                                label="Last Name"
                                className="inline-lable-ttl"
                                value={props.values.lastName}
                                inputProps={{ maxLength: 35 }}
                                onChange={props.handleChanges('lastName')}
                                placeholder=""
                                helperText={props.errors.replastNameErr ? MemberSearchConstants.LAST_NAME_ORG_NAME_ERR :
                                    props.errors.replastNameLengthErr ? MemberSearchConstants.LAST_NAME_ENV_Error :
                                        props.errors.replastNameWarningErr ? MemberSearchConstants.LASTNAME_INVALID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                    required: true
                                }}
                                error={props.errors.replastNameErr || props.errors.replastNameLengthErr || props.errors.replastNameWarningErr}
                            />
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="Last Name"
                                    onChange={props.handleChanges('lastNameStartWithOrPhonetic')}
                                >
                                    <FormControlLabel
                                        value="StartsWith"
                                        id="RNS-start-with"
                                        control={<Radio color="primary" />}
                                        label="Starts With"
                                        checked={props.values.lastNameStartWithOrPhonetic === 'StartsWith'}
                                    />
                                    <FormControlLabel
                                        value="Phonetic"
                                        id="RNS-phonetic"
                                        control={<Radio color="primary" />}
                                        label="Phonetic"
                                        checked={props.values.lastNameStartWithOrPhonetic === 'Phonetic'}
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                        <div className="mui-custom-form input-md ">
                            <TextField
                                data-test='RNS-first-name'
                                id="RNS-first-name"
                                label="First Name"
                                className="inline-lable-ttl"
                                value={props.values.firstName}
                                inputProps={{ maxLength: 25 }}
                                onChange={props.handleChanges('firstName')}
                                placeholder=""
                                helperText={props.errors.repfirstNameLengthErr ? MemberSearchConstants.FIRST_NAME_ENV_Error :
                                    props.errors.repfirstNameWarningErr ? MemberSearchConstants.FIRSTNAME_INVALID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                    required: false
                                }}
                                error={props.errors.repfirstNameLengthErr || props.errors.repfirstNameWarningErr}
                            />
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="Last Name"
                                    onChange={props.handleChanges('firstNameStartWithOrPhonetic')}
                                >
                                    <FormControlLabel
                                        value="StartsWith"
                                        id="RNS-start-with-lname-name"
                                        control={<Radio color="primary" />}
                                        label="Starts With"
                                        checked={props.values.firstNameStartWithOrPhonetic === 'StartsWith'}
                                    />
                                    <FormControlLabel
                                        value="Phonetic"
                                        id="RNS-phonetic-1"
                                        control={<Radio color="primary" />}
                                        label="Phonetic"
                                        checked={props.values.firstNameStartWithOrPhonetic === 'Phonetic'}
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                        <div className="mui-custom-form input-md ">
                            <TextField
                                id="RNS-mi"
                                data-test='RNS-mi'
                                label="MI"
                                className="inline-lable-ttl"
                                value={props.values.mi}
                                inputProps={{ maxLength: 1 }}
                                onChange={props.handleChanges('mi')}
                                placeholder=""
                                helperText={props.errors.repmiInvalidErr ? MemberSearchConstants.MEMBER_MI_ERROR : null}
                                InputLabelProps={{
                                    shrink: true
                                }}
                                error={props.errors.repmiInvalidErr}
                            />
                        </div>
                    </div>
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md field-md">
                            <TextField
                                id="RNS-Organization-Name"
                                label="Organization Name"
                                className="inline-lable-ttl"
                                value={props.values.orgName}
                                inputProps={{ maxLength: 40 }}
                                onChange={props.handleChanges('orgName')}
                                placeholder=""
                                InputLabelProps={{
                                    shrink: true
                                }}
                            />
                            <div className="sub-radio">
                                <Checkbox
                                    value={props.values.repNameStartsWith}
                                    color="primary"
                                    inputProps={{ 'aria-label': 'secondary checkbox' }}
                                    id="RNS-StartsWithCheckbox"
                                    checked={props.values.repNameStartsWith}
                                    onChange={props.handleChanges('repNameStartsWith')}
                                />
                                <label for="RNS-StartsWithCheckbox" className="text-black" htmlFor="StartsWithCheckbox">Starts With</label>
                            </div>
                        </div>
                    </div>
                    <div className="form-wrapper">
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select">
                                <KeyboardDatePicker
                                    id="RNS-from-date"
                                    label="From Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.fromDate ? props.values.fromDate : null}
                                    onChange={(dt) => props.handelDateChanges("fromDate", dt)}
                                    helperText={props.errors.repFromDateErr ? MemberSearchConstants.Invalid_From_Date_Error : null}
                                    error={props.errors.repFromDateErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select" >
                                <KeyboardDatePicker
                                    id="RNS-to-date"
                                    label="To Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true

                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.toDate ? props.values.toDate : null}
                                    onChange={(dt) => props.handelDateChanges("toDate", dt)}
                                    helperText={props.errors.repToDateErr ? MemberSearchConstants.Invalid_To_Date_Error : null}
                                    error={props.errors.repToDateErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="RNS-lob"
                                select
                                label="LOB"
                                value={props.values.lob}
                                inputProps={{ maxLength: 25 }}
                                onChange={props.handleChanges('lob')}
                                placeholder="Please Select One"
                                // helperText={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            // error={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {props.dropdowns && props.dropdowns['Claims#R_LOB_CD'] && props.dropdowns['Claims#R_LOB_CD'].map(each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                ))}
                            </TextField>
                        </div>
                    </div>
                </div>
                <div className="tab-header mb-2">
                    <div className="float-right th-btnGroup">
                        <Button
                            title="Search"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-search"
                            onClick={props.searchCheck}
                        >
                            {' '}
                            Search
          {' '}

                        </Button>
                        <Button
                            title="Reset"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-reset"
                            onClick={props.resetTable}
                        >
                            {' '}
                            Reset
          {' '}

                        </Button>
                    </div>
                </div>
                <div className="clearfix" />
            </form>
        </>
    )
}


export default MemberIDSearch;