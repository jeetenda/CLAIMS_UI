import React from "react"
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import MenuItem from '@material-ui/core/MenuItem';
import * as MemberSearchConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { useDispatch, useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import dateFnsFormat from 'date-fns/format';
function MemberIDSearch(props) {

    return (
        < >

            <form autoComplete="off">
                <div className="tab-body mt-2">
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md ">
                            <TextField
                                id="MNS-last-name"
                                data-test='MNS-last-name'
                                label="Last Name"
                                className="inline-lable-ttl"
                                value={props.values.lastName}
                                inputProps={{ maxLength: 35 }}
                                onChange={props.handleChanges('lastName')}
                                placeholder=""
                                helperText={props.errors.lastNameErr ? MemberSearchConstants.LAST_NAME_Error :
                                    props.errors.lastNameLengthErr ? MemberSearchConstants.LAST_NAME_ENV_Error :
                                        props.errors.lastNameWarningErr ? MemberSearchConstants.LASTNAME_INVALID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                    required: true
                                }}
                                error={props.errors.lastNameErr || props.errors.lastNameLengthErr || props.errors.lastNameWarningErr}
                            />
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="Last Name"
                                    onChange={props.handleChanges('lastNameStartWithOrPhonetic')}
                                >
                                    <FormControlLabel
                                        value="StartsWith"
                                        id="MNS-start-with"
                                        control={<Radio color="primary" />}
                                        label="Starts With"
                                        checked={props.values.lastNameStartWithOrPhonetic === 'StartsWith'}
                                    />
                                    <FormControlLabel
                                        value="Phonetic"
                                        id="MNS-phonetic"
                                        control={<Radio color="primary" />}
                                        label="Phonetic"
                                        checked={props.values.lastNameStartWithOrPhonetic === 'Phonetic'}
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                        <div className="mui-custom-form input-md ">
                            <TextField
                                id="MNS-first-name"
                                label="First Name"
                                className="inline-lable-ttl"
                                value={props.values.firstName}
                                inputProps={{ maxLength: 25 }}
                                onChange={props.handleChanges('firstName')}
                                placeholder=""
                                helperText={props.errors.firstNameLengthErr ? MemberSearchConstants.FIRST_NAME_ENV_Error :
                                    props.errors.firstNameWarningErr ? MemberSearchConstants.FIRSTNAME_INVALID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                    required: false
                                }}
                                error={props.errors.firstNameLengthErr || props.errors.firstNameWarningErr}
                            />
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="Last Name"
                                    onChange={props.handleChanges('firstNameStartWithOrPhonetic')}
                                >
                                    <FormControlLabel
                                        value="StartsWith"
                                        id="MNS-start-with-1"
                                        control={<Radio color="primary" />}
                                        label="Starts With"
                                        checked={props.values.firstNameStartWithOrPhonetic === 'StartsWith'}
                                    />
                                    <FormControlLabel
                                        value="Phonetic"
                                        id="MNS-phonetic-1"
                                        control={<Radio color="primary" />}
                                        label="Phonetic"
                                        checked={props.values.firstNameStartWithOrPhonetic === 'Phonetic'}
                                    />
                                </RadioGroup>
                            </div>
                        </div>

                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select">
                                <KeyboardDatePicker
                                    id="MNS-from-date"
                                    label="From Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.fromDate ? props.values.fromDate : null}
                                    onChange={(dt) => props.handelDateChanges("fromDate", dt)}
                                    helperText={props.errors.nameFromDateErr ? MemberSearchConstants.Invalid_From_Date_Error : null}
                                    error={props.errors.nameFromDateErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select" >
                                <KeyboardDatePicker
                                    id="MNS-to-date"
                                    label="To Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true

                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.toDate ? props.values.toDate : null}
                                    onChange={(dt) => props.handelDateChanges("toDate", dt)}
                                    helperText={props.errors.nameToDateErr ? MemberSearchConstants.Invalid_To_Date_Error : null}
                                    error={props.errors.nameToDateErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <div className="mui-custom-form input-md ">
                            <TextField
                                id="MNS-mi"
                                label="MI"
                                className="inline-lable-ttl"
                                value={props.values.mi}
                                inputProps={{ maxLength: 1 }}
                                onChange={props.handleChanges('mi')}
                                placeholder=""
                                helperText={props.errors.miInvalidErr ? MemberSearchConstants.MEMBER_MI_ERROR : null}
                                InputLabelProps={{
                                    shrink: true
                                }}
                                error={props.errors.miInvalidErr}
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="MNS-lob"
                                select
                                label="LOB"
                                value={props.values.lob}
                                inputProps={{ maxLength: 25 }}
                                onChange={props.handleChanges('lob')}
                                placeholder="Please Select One"
                                // helperText={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            // error={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {props.dropdowns && props.dropdowns['Claims#R_LOB_CD'] && props.dropdowns['Claims#R_LOB_CD'].map(each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                ))}
                            </TextField>
                        </div>
                    </div>
                </div>
                <div className="tab-header mb-2">
                    <div className="float-right th-btnGroup">
                        <Button
                            title="Search"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-search"
                            onClick={props.searchCheck}
                        >
                            {' '}
                            Search
          {' '}

                        </Button>
                        <Button
                            title="Reset"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-reset"
                            onClick={props.resetTable}
                        >
                            {' '}
                            Reset
          {' '}

                        </Button>
                    </div>
                </div>
                <div className="clearfix" />
            </form>
        </>
    )
}


export default MemberIDSearch;