import React from "react"
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import MenuItem from '@material-ui/core/MenuItem';
import * as MemberSearchConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import { useDispatch, useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import dateFnsFormat from 'date-fns/format';
function MemberIDSearch(props) {

    return (
        < >

            <form autoComplete="off">
                <div className="tab-body mt-2">
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md ">
                            <TextField
                                id="MIDS-Member-ID"
                                data-test='MIDS-Member-ID'
                                label="Member ID"
                                className="inline-lable-ttl"
                                value={props.values.memberId}
                                inputProps={{ maxLength: 15 }}
                                onChange={props.handleChanges('memberId')}
                                placeholder=""
                                helperText={props.errors.memberIdErr ? MemberSearchConstants.ID_NUMBER_Error :
                                    props.errors.memberIdMIDErr ? MemberSearchConstants.MEMBER_ID_MID_ERROR :
                                        props.errors.memberIdRIDErr ? MemberSearchConstants.MEMBER_ID_RID_ERROR : null}
                                InputLabelProps={{
                                    shrink: true,
                                    required: true
                                }}
                                error={props.errors.memberIdErr || props.errors.memberIdMIDErr || props.errors.memberIdRIDErr}
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="MIDS-ID-type"
                                select
                                label="ID Type"
                                value={props.values.idType}
                                inputProps={{ maxLength: 25 }}
                                onChange={props.handleChanges('idType')}
                                placeholder="Please Select One"
                                helperText={props.errors.idTypeErr ? MemberSearchConstants.ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                    required: true
                                }}
                                error={props.errors.idTypeErr}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {props.dropdowns && props.dropdowns['Claims#B_ALT_ID_TY_CD'] && props.dropdowns['Claims#B_ALT_ID_TY_CD'].map(each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                ))}
                            </TextField>
                        </div>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select">
                                <KeyboardDatePicker
                                    id="MIDS-from-date"
                                    label="From Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.fromDate ? props.values.fromDate : null}
                                    onChange={(dt) => props.handelDateChanges("fromDate", dt)}
                                    helperText={props.errors.fromDateErr ? MemberSearchConstants.Invalid_From_Date_Error : null}
                                    error={props.errors.fromDateErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select" >
                                <KeyboardDatePicker
                                    id="MIDS-to-date"
                                    label="To Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true

                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.toDate ? props.values.toDate : null}
                                    onChange={(dt) => props.handelDateChanges("toDate", dt)}
                                    helperText={props.errors.toDateErr ? MemberSearchConstants.Invalid_To_Date_Error : null}
                                    error={props.errors.toDateErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="MIDS-lob"
                                select
                                label="LOB"
                                value={props.values.lob}
                                inputProps={{ maxLength: 25 }}
                                onChange={props.handleChanges('lob')}
                                placeholder="Please Select One"
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {props.dropdowns && props.dropdowns['Claims#R_LOB_CD'] && props.dropdowns['Claims#R_LOB_CD'].map(each => (
                                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                ))}
                            </TextField>
                        </div>
                    </div>
                </div>
                <div className="tab-header mb-2">
                    <div className="float-right th-btnGroup">
                        <Button
                            title="Search"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-search"
                            onClick={props.searchCheck}
                        >
                            {' '}
                            Search
          {' '}

                        </Button>
                        <Button
                            title="Reset"
                            variant="outlined"
                            color="primary"
                            className="btn btn-ic btn-reset"
                            onClick={props.resetTable}
                        >
                            {' '}
                            Reset
          {' '}

                        </Button>
                    </div>
                </div>
                <div className="clearfix" />
            </form>
        </>
    )
}


export default MemberIDSearch;