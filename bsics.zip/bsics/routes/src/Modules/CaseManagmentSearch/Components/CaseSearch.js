import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import TabPanel from '../../../SharedModules/TabPanel/TabPanel';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import React, { useState, useEffect, useRef } from 'react';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import { Button } from 'react-bootstrap';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';

import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";

import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import CaseNumberSearch from '../Components/CaseNumberSearch';
import CaseHeadNameSearch from '../Components/CaseHeadNameSearch';
import * as CaseSearchConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import { resetCaseSearch, caseSearchAction, memberSearchAction } from '../action';
import CaseNumberSearchTable from '../Components/CaseNumberSearchTable';
import MemberidSearch from './MemberIDSearch';
import MemberNameSearch from './MemberNameSearch';
import RepNameSearch from './RepNameSearch';
import MemberSearchTable from './MemberSearchTable';
import RepNameSearchTable from './RepNameSearchTable';

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

function CaseSearch(props) {
    let errorMessagesArray = [];
    const dispatch = useDispatch();
    let statevar = props && props.location && props.location.search ? true : false;
    const [showNoRecords, setShowNoRecords] = useState(false);
    const [redirect, setRedirect] = useState(false);
    const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
    const onDropdowns1 = (values) => dispatch(GET_APP_DROPDOWNS(values));
    const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
    const [tabValue, setTabValue] = useState(0);
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const [showTable, setShowTable] = useState(false);
    const [showRecords, setShowRecords] = useState([]);
    const printRef = useRef();
    const printLayout = useSelector(state => state.appDropDowns.printLayout);
    const [nameTabErrorMessages, setNameTabErrorMessages] = React.useState([]);
    const onReset = () => dispatch(resetCaseSearch());
    const onSearch = searchvalues => { return dispatch(caseSearchAction(searchvalues)) };
    const onMemberSearch = searchvalues => dispatch(memberSearchAction(searchvalues));
    const [showMemberIdRecords, setShowMemberIdRecords] = useState([]);
    const [showMemberNameRecords, setShowMemberNameRecords] = useState([]);
    const [showRepNameRecords, setShowRepNameRecords] = useState([]);
    const [values, setValues] = useState({
        "caseNumber": "",
        "fromDate": '',
        "toDate": '',
        "lob": "MED",
    });

    const [memberIdValues, setMemberIdValues] = useState({
        memberId: "",
        idType: "-1",
        fromDate: null,
        toDate: null,
        lob: "MED"
    });
    const [memberNameValues, setMemberNameValues] = useState({
        lastName: "",
        lastNameStartWithOrPhonetic: "",
        firstName: "",
        firstNameStartWithOrPhonetic: "",
        mi: "",
        fromDate: null,
        toDate: null,
        lob: "MED"
    });

    const [repNameValues, setRepNameValues] = useState({
        lastName: "",
        lastNameStartWithOrPhonetic: "",
        firstName: "",
        firstNameStartWithOrPhonetic: "",
        mi: "",
        orgName: "",
        repNameStartsWith: "",
        fromDate: null,
        toDate: null,
        lob: "MED"
    });

    const [errorMessages, seterrorMessages] = React.useState([]);
    const [nameErrorMessages, setNameErrorMessages] = React.useState([]);
    const [memberIdHederErrorMsg, setMemberIdHederErrorMsg] = useState([]);
    const [memberNameHederErrorMsg, setMemberNameHederErrorMsg] = useState([]);
    const [repNameHederErrorMsg, setRepNameHederErrorMsg] = useState([]);

    const payload = useSelector(state => state.caseSearch.caseNumberPayload);
    const memberIdPayload = useSelector(state => state.caseSearch.memberIdPayload);
    const memberNamePayload = useSelector(state => state.caseSearch.memberNamePayload);
    const repNamePayload = useSelector(state => state.caseSearch.repNamePayload);

    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
    }
    const handleChanges = name => (event) => {
        setValues({ ...values, [name]: event.target.value });
    };

    const handleDCDtChange = (name, date) => {
        setValues({ ...values, [name]: date });
    };

    const handleMemberIdChanges = name => (event) => {
        setMemberIdValues({ ...memberIdValues, [name]: event.target.value });
    };

    const handleMemberIdDCDtChange = (name, date) => {
        setMemberIdValues({ ...memberIdValues, [name]: date });
    };

    const handleMemberNameChanges = name => (event) => {
        setMemberNameValues({ ...memberNameValues, [name]: event.target.value });
    };

    const handleMemberNameDCDtChange = (name, date) => {
        setMemberNameValues({ ...memberNameValues, [name]: date });
    };

    const handleRepNameChanges = name => (event) => {
        if (event.target.type === 'checkbox') {
            setRepNameValues({ ...repNameValues, [name]: event.target.checked });
        } else {
            setRepNameValues({ ...repNameValues, [name]: event.target.value });
        }
    };

    const handleRepNameDCDtChange = (name, date) => {
        setRepNameValues({ ...repNameValues, [name]: date });
    };

    const [{ showCaseNumberError,
        showfromDateError,
        showtoDateError,
        showLobError, showCaseNumberErrorEnv, showfromDateInvError, showtoDateInvError, showCaseNumberNumericError },
        setShowError] = React.useState(false);

    const [{ memberIdErr, idTypeErr, fromDateErr, toDateErr, memberIdMIDErr, memberIdRIDErr }, setMemberIdErrors] = useState(false);
    const [{ lastNameErr, lastNameLengthErr, firstNameLengthErr, miInvalidErr, nameFromDateErr, nameToDateErr, lastNameWarningErr, firstNameWarningErr }, setMemberNameErrors] = useState(false);
    const [{ replastNameErr, replastNameLengthErr, repfirstNameLengthErr, repmiInvalidErr, repFromDateErr, repToDateErr, replastNameWarningErr, repfirstNameWarningErr }, setRepNameErrors] = useState(false);

    useEffect(() => {
        onDropdowns([
            Dropdowns.REV_LOB,
            Dropdowns.MEMBER_ID_TYPE,
        ]);
    }, []);

    const resetTable = () => {
        setShowNoRecords(false);
        seterrorMessages([]);
        setShowRecords([])
        setShowError({
            showCaseNumberError: false,
            showCaseNumberErrorEnv: false,
            showfromDateError: false,
            showfromDateInvError: false,
            showtoDateError: false,
            showtoDateInvError: false,
            showLobError: false,
            showCaseNumberNumericError: false,
        });
        setValues(
            {
                "caseNumber": "",
                "fromDate": '',
                "toDate": '',
                "lob": "MED",
            }
        );
        setShowTable(false);
        onReset()
    };

    const resetForm = () => {
        setShowNoRecords(false);
        if (tabValue == 2) {
            setMemberIdValues({
                memberId: "",
                idType: "-1",
                fromDate: null,
                toDate: null,
                lob: "MED"
            });
            setMemberIdHederErrorMsg([]);
            setShowMemberIdRecords([]);
            setMemberIdErrors(false);
        }
        if (tabValue == 3) {
            setMemberNameValues({
                lastName: "",
                lastNameStartWithOrPhonetic: "",
                firstName: "",
                firstNameStartWithOrPhonetic: "",
                mi: "",
                fromDate: null,
                toDate: null,
                lob: "MED"
            });
            setShowMemberNameRecords([]);
            setMemberNameErrors(false);
            setMemberNameHederErrorMsg([]);
        }
        if (tabValue == 4) {
            setRepNameValues({
                lastName: "",
                lastNameStartWithOrPhonetic: "",
                firstName: "",
                firstNameStartWithOrPhonetic: "",
                mi: "",
                orgName: "",
                repNameStartsWith: "",
                fromDate: null,
                toDate: null,
                lob: "MED"
            });
            setShowRepNameRecords([]);
            setRepNameErrors(false);
            setRepNameHederErrorMsg([]);
        }
        onReset();
    };

    // search function
    const searchCheck = () => {
        setShowTable(false);
        setspinnerLoader(false);
        errorMessagesArray = [];
        seterrorMessages([]);
        setShowError({});
        let showCaseNumberError;
        let showCaseNumberErrorEnv;
        let showfromDateError;
        let showfromDateInvError;
        let showtoDateError;
        let showtoDateInvError;
        let showLobError;
        let showCaseNumberNumericError;

        if (values.caseNumber == '') {
            showCaseNumberError = true;
            errorMessagesArray.push(CaseSearchConstants.CASE_NUMBER);
        }

        if (values.caseNumber != '') {
            var regex = /^[a-zA-Z0-9.-]+$/;
            if (regex.test(values.caseNumber)) {
                // return true;
            } else {
                showCaseNumberErrorEnv = true;
                errorMessagesArray.push(CaseSearchConstants.CASE_NUMBER_ERROR)
            }
        }

        if (values.fromDate != '' && values.fromDate.toString() == "Invalid Date") {
            showfromDateInvError = true;
            errorMessagesArray.push(CaseSearchConstants.CASE_DATE_INVALID);
        }
        if (values.toDate != '' && values.toDate.toString() == "Invalid Date") {
            showtoDateInvError = true;
            errorMessagesArray.push(CaseSearchConstants.CASE_DATE_INVALID);
        }


        if (errorMessagesArray.length == 0) {
            setShowTable(false);
            setspinnerLoader(true);
            setRedirect(true);
            let searchCriteria = {};
            if (!(values.caseNumber === '')) {
                searchCriteria = {
                    caseNumber: values.caseNumber !== '' ? values.caseNumber : null,
                    "searchBy": "caseNumber",
                    strFromDate: values.fromDate !== '' ? values.fromDate : null,
                    strToDate: values.toDate !== '' ? values.toDate : null,
                    lob: values.lob !== '-1' ? values.lob : null,
                };
                setspinnerLoader(true);
                onSearch(searchCriteria);
            }

        } else {
            seterrorMessages(errorMessagesArray);
            setShowTable(false);
            // setspinnerLoader(true);
            // setShowClaimData(false);
            setShowError({
                showCaseNumberError,
                showfromDateError,
                showfromDateInvError,
                showtoDateError,
                showtoDateInvError,
                showLobError,
                showCaseNumberErrorEnv,
                showCaseNumberNumericError
            });
        }
    };

    const containsSpecialCharacters = (str) => {
        let regex = /[ !@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/g;
        return regex.test(str);
    }

    const isAlpha = (str) => {
        return /^[a-zA-Z]+$/.test(str);
    }

    const memberSearchCheck = () => {
        setspinnerLoader(true);
        if (tabValue == 2) {
            setShowMemberIdRecords([]);
            setMemberIdHederErrorMsg([]);
            let errorMessagesArray = [];
            setMemberIdErrors({
                memberIdErr: memberIdValues.memberId ? false : (() => { errorMessagesArray.push(CaseSearchConstants.ID_NUMBER_Error); return true; })(),
                idTypeErr: memberIdValues.idType == '-1' ? (() => { errorMessagesArray.push(CaseSearchConstants.ID_TYPE_Error); return true; })() : false,
                fromDateErr: memberIdValues.fromDate && memberIdValues.fromDate.toString() == "Invalid Date" ? (() => { errorMessagesArray.push(CaseSearchConstants.Invalid_From_Date_Error); return true; })() : false,
                toDateErr: memberIdValues.toDate && memberIdValues.toDate.toString() == "Invalid Date" ? (() => { errorMessagesArray.push(CaseSearchConstants.Invalid_To_Date_Error); return true; })() : false,
                memberIdMIDErr: memberIdValues.memberId && memberIdValues.idType == "MID" && (memberIdValues.memberId.length != 11 || containsSpecialCharacters(memberIdValues.memberId)) ? (() => { errorMessagesArray.push(CaseSearchConstants.MEMBER_ID_MID_ERROR); return true; })() : false,
                memberIdRIDErr: memberIdValues.memberId && memberIdValues.idType == "RID" && (memberIdValues.memberId.length != 10 || containsSpecialCharacters(memberIdValues.memberId)) ? (() => { errorMessagesArray.push(CaseSearchConstants.MEMBER_ID_RID_ERROR); return true; })() : false,
            });
            if (errorMessagesArray.length > 0) {
                setMemberIdHederErrorMsg(errorMessagesArray);
                setspinnerLoader(false);
                return false;
            }
            let searchCriteria = {
                "searchTypeAltIDValue": memberIdValues.memberId,
                "searchTypeAltID": memberIdValues.idType != '-1' ? memberIdValues.idType : "",
                "strFromDate": memberIdValues.fromDate,
                "strToDate": memberIdValues.toDate,
                "lineOfBusiness": memberIdValues.lob != '-1' ? memberIdValues.lob : "",
                "searchBy": "Others"
            }
            onMemberSearch(searchCriteria);
        }
        if (tabValue == 3) {
            setShowMemberNameRecords([]);
            setMemberNameHederErrorMsg([]);
            let errorMessagesArray = [];
            setMemberNameErrors({
                lastNameErr: memberNameValues.lastName ? false : (() => { errorMessagesArray.push(CaseSearchConstants.LAST_NAME_Error); return true; })(),
                lastNameLengthErr: memberNameValues.lastName && memberNameValues.lastName.length < 2 ? (() => { errorMessagesArray.push(CaseSearchConstants.LAST_NAME_ENV_Error); return true; })() : false,
                firstNameLengthErr: memberNameValues.firstName && memberNameValues.firstName.length < 2 ? (() => { errorMessagesArray.push(CaseSearchConstants.FIRST_NAME_ENV_Error); return true; })() : false,
                miInvalidErr: memberNameValues.mi && !isAlpha(memberNameValues.mi) ? (() => { errorMessagesArray.push(CaseSearchConstants.MEMBER_MI_ERROR); return true; })() : false,
                nameFromDateErr: memberNameValues.fromDate && memberNameValues.fromDate.toString() == "Invalid Date" ? (() => { errorMessagesArray.push(CaseSearchConstants.Invalid_From_Date_Error); return true; })() : false,
                nameToDateErr: memberNameValues.toDate && memberNameValues.toDate.toString() == "Invalid Date" ? (() => { errorMessagesArray.push(CaseSearchConstants.Invalid_To_Date_Error); return true; })() : false,

            });
            if (errorMessagesArray.length > 0) {
                setMemberNameHederErrorMsg(errorMessagesArray);
                setspinnerLoader(false);
                return false;
            }
            setMemberNameErrors({
                lastNameWarningErr: memberNameValues.lastName && containsSpecialCharacters(memberNameValues.lastName) ? (() => { errorMessagesArray.push(CaseSearchConstants.LASTNAME_INVALID_Error); return true; })() : false,
                firstNameWarningErr: memberNameValues.firstName && containsSpecialCharacters(memberNameValues.firstName) ? (() => { errorMessagesArray.push(CaseSearchConstants.FIRSTNAME_INVALID_Error); return true; })() : false
            });
            if (errorMessagesArray.length > 0) {
                setMemberNameHederErrorMsg(errorMessagesArray);
            }
            let searchCriteria = {
                "lastName": memberNameValues.lastName,
                "phoneticSearchLastNameIndicator": memberNameValues.lastNameStartWithOrPhonetic == "Phonetic" ? true : false,
                "lastNameStartwith": memberNameValues.lastNameStartWithOrPhonetic == "StartsWith" ? true : false,
                "firstName": memberNameValues.firstName,
                "phoneticSearchFirstNameIndicator": memberNameValues.firstNameStartWithOrPhonetic == "Phonetic" ? true : false,
                "firstNameStartwith": memberNameValues.firstNameStartWithOrPhonetic == "StartsWith" ? true : false,
                "middleName": memberNameValues.mi,
                "strFromDate": memberNameValues.fromDate,
                "strToDate": memberNameValues.toDate,
                "lineOfBusiness": memberNameValues.lob != '-1' ? memberNameValues.lob : "",
                "searchBy": "Name"
            }
            onMemberSearch(searchCriteria);
        }
        if (tabValue == 4) {
            setShowRepNameRecords([]);
            setRepNameHederErrorMsg([]);
            let errorMessagesArray = [];
            setRepNameErrors({
                replastNameErr: repNameValues.lastName || repNameValues.orgName ? false : (() => { errorMessagesArray.push(CaseSearchConstants.LAST_NAME_ORG_NAME_ERR); return true; })(),
                replastNameLengthErr: repNameValues.lastName && repNameValues.lastName.length < 2 ? (() => { errorMessagesArray.push(CaseSearchConstants.LAST_NAME_ENV_Error); return true; })() : false,
                repfirstNameLengthErr: repNameValues.firstName && repNameValues.firstName.length < 2 ? (() => { errorMessagesArray.push(CaseSearchConstants.FIRST_NAME_ENV_Error); return true; })() : false,
                repmiInvalidErr: repNameValues.mi && !isAlpha(repNameValues.mi) ? (() => { errorMessagesArray.push(CaseSearchConstants.MEMBER_MI_ERROR); return true; })() : false,
                repFromDateErr: repNameValues.fromDate && repNameValues.fromDate.toString() == "Invalid Date" ? (() => { errorMessagesArray.push(CaseSearchConstants.Invalid_From_Date_Error); return true; })() : false,
                repToDateErr: repNameValues.toDate && repNameValues.toDate.toString() == "Invalid Date" ? (() => { errorMessagesArray.push(CaseSearchConstants.Invalid_To_Date_Error); return true; })() : false,

            });
            if (errorMessagesArray.length > 0) {
                setRepNameHederErrorMsg(errorMessagesArray);
                setspinnerLoader(false);
                return false;
            }
            setRepNameErrors({
                replastNameWarningErr: repNameValues.lastName && containsSpecialCharacters(repNameValues.lastName) ? (() => { errorMessagesArray.push(CaseSearchConstants.LASTNAME_INVALID_Error); return true; })() : false,
                repfirstNameWarningErr: repNameValues.firstName && containsSpecialCharacters(repNameValues.firstName) ? (() => { errorMessagesArray.push(CaseSearchConstants.FIRSTNAME_INVALID_Error); return true; })() : false
            });
            if (errorMessagesArray.length > 0) {
                setRepNameHederErrorMsg(errorMessagesArray);
            }
            let searchCriteria = {
                "lastName": repNameValues.lastName,
                "phoneticSearchLastNameIndicator": repNameValues.lastNameStartWithOrPhonetic == "Phonetic" ? true : false,
                "lastNameStartwith": repNameValues.lastNameStartWithOrPhonetic == "StartsWith" ? true : false,
                "firstName": repNameValues.firstName,
                "phoneticSearchFirstNameIndicator": repNameValues.firstNameStartWithOrPhonetic == "Phonetic" ? true : false,
                "firstNameStartwith": repNameValues.firstNameStartWithOrPhonetic == "StartsWith" ? true : false,
                "repOrganizationName": repNameValues.orgName,
                "organizationNameStartsWith": repNameValues.repNameStartsWith,
                "middleName": repNameValues.mi,
                "strFromDate": repNameValues.fromDate,
                "strToDate": repNameValues.toDate,
                "lineOfBusiness": repNameValues.lob != '-1' ? repNameValues.lob : "",
                "searchBy": "REP"
            }
            onMemberSearch(searchCriteria);
        }
    };

    useEffect(() => {

        if (payload && payload.data == null) {
            setspinnerLoader(false);
            setShowRecords([])
            seterrorMessages([CaseSearchConstants.CASE_NUMBER_NO_RECORDS]);
        }

        if (payload && payload.data != null && payload.data.recordCount == 0) {
            setspinnerLoader(false);
            setShowRecords([])
            seterrorMessages([CaseSearchConstants.CASE_NUMBER_NO_RECORDS]);
        }

        if (payload && payload.data != null && payload.data.recordCount > 0) {
            setspinnerLoader(false);
            setShowRecords(payload.data.searchResults)
        }
        // if (payload && payload.data != null && payload.data.recordCount == 1 && redirect) {
        //     setspinnerLoader(true);
        //     setShowRecords([])
        //     // setShowRecords(payload.data.searchResults)
        //     props.history.push({
        //         pathname: '/caseMemberDetails'                
        //     });
        // }
    }, [payload]);

    useEffect(() => {
        if (memberIdPayload != null && memberIdPayload.message != "success") {
            setShowMemberIdRecords([]);
            setspinnerLoader(false);
            setMemberIdHederErrorMsg([CaseSearchConstants.ERROR_OCCURED_DURING_TRANSACTION])
        }
        if (memberIdPayload != null && memberIdPayload.data != null && memberIdPayload.data.recordCount >= 0) {
            setShowMemberIdRecords([]);
            setspinnerLoader(false);
        }
        if (memberIdPayload != null && memberIdPayload.data != null && memberIdPayload.data.recordCount == 0) {
            setShowMemberIdRecords([]);
            setShowNoRecords(true);
            setMemberIdHederErrorMsg([CaseSearchConstants.MEMBER_ID_NO_RECORD])
        }
        if (memberIdPayload != null && memberIdPayload.data != null && memberIdPayload.data.recordCount > 0) {
            setShowMemberIdRecords(memberIdPayload.data.searchResults);
        }

    }, [memberIdPayload]);

    useEffect(() => {
        if (memberNamePayload != null && memberNamePayload.message != "success") {
            setShowMemberNameRecords([]);
            setspinnerLoader(false);
            let errorMessages = memberNameHederErrorMsg;
            errorMessages.push(CaseSearchConstants.ERROR_OCCURED_DURING_TRANSACTION)
            setMemberNameHederErrorMsg(errorMessages);
        }
        if (memberNamePayload != null && memberNamePayload.data != null && memberNamePayload.data.recordCount >= 0) {
            setShowMemberNameRecords([]);
            setspinnerLoader(false);
        }
        if (memberNamePayload != null && memberNamePayload.data != null && memberNamePayload.data.recordCount == 0) {
            setShowMemberNameRecords([]);
            setShowNoRecords(true);
            let errorMessages = memberNameHederErrorMsg;
            errorMessages.push(CaseSearchConstants.NO_RECORDS_WITHSEARCH)
            setMemberNameHederErrorMsg(errorMessages)
        }
        if (memberNamePayload != null && memberNamePayload.data != null && memberNamePayload.data.recordCount > 0) {
            setShowMemberNameRecords(memberNamePayload.data.searchResults);
        }

    }, [memberNamePayload]);

    useEffect(() => {
        if (repNamePayload != null && repNamePayload.message != "success") {
            setShowRepNameRecords([]);
            setspinnerLoader(false);
            let errorMessages = repNameHederErrorMsg;
            errorMessages.push(CaseSearchConstants.ERROR_OCCURED_DURING_TRANSACTION)
            setRepNameHederErrorMsg(errorMessages);
        }
        if (repNamePayload != null && repNamePayload.data != null && repNamePayload.data.recordCount >= 0) {
            setShowRepNameRecords([]);
            setspinnerLoader(false);
        }
        if (repNamePayload != null && repNamePayload.data != null && repNamePayload.data.recordCount == 0) {
            setShowRepNameRecords([]);
            setShowNoRecords(true);
            let errorMessages = repNameHederErrorMsg;
            errorMessages.push(CaseSearchConstants.NO_RECORDS_WITHSEARCH)
            setRepNameHederErrorMsg(errorMessages);
        }
        if (repNamePayload != null && repNamePayload.data != null && repNamePayload.data.recordCount > 0) {
            setShowRepNameRecords(repNamePayload.data.searchResults);
        }

    }, [repNamePayload]);

    return (
        <div className="pos-relative">

            {spinnerLoader ? <Spinner /> : null}
            {tabValue == 0 && errorMessages.length > 0 ? (
                <div className="alert alert-danger custom-alert hide-on-print" role="alert">
                    {errorMessages.map(message => <li>{message}</li>)
                    }
                </div>
            ) : null
            }
            {tabValue == 1 && setNameErrorMessages && nameErrorMessages.length > 0 ? (
                <div className="alert alert-danger custom-alert hide-on-print" role="alert">
                    {nameErrorMessages.map(message => <li>{message}</li>)}
                </div>
            ) : null
            }
            {tabValue == 1 && setNameTabErrorMessages && nameTabErrorMessages.length > 0 ? (
                <div className="alert alert-danger custom-alert hide-on-print" role="alert">
                    {nameTabErrorMessages.map(message => <li>{message}</li>)}
                </div>
            ) : null
            }

            {tabValue == 2 && memberIdHederErrorMsg && memberIdHederErrorMsg.length > 0 ? (
                <div className="alert alert-danger custom-alert hide-on-print" role="alert">
                    {memberIdHederErrorMsg.map(message => <li>{message}</li>)}
                </div>
            ) : null}

            {tabValue == 3 && memberNameHederErrorMsg && memberNameHederErrorMsg.length > 0 ? (
                <div className="alert alert-danger custom-alert hide-on-print" role="alert">
                    {memberNameHederErrorMsg.map(message => <li>{message}</li>)}
                </div>
            ) : null}

            {tabValue == 4 && repNameHederErrorMsg && repNameHederErrorMsg.length > 0 ? (
                <div className="alert alert-danger custom-alert hide-on-print" role="alert">
                    {repNameHederErrorMsg.map(message => <li>{message}</li>)}
                </div>
            ) : null}

            {errorMessages.length == 0 && payload && payload.searchResults && payload.searchResults.length == 0 && showNoRecords ? (
                <div className="alert alert-danger custom-alert hide-on-print" role="alert">
                    <li>{CaseSearchConstants.CASE_NUMBER_NO_RECORDS}</li>
                </div>
            ) : null
            }


            <div className="mb-2">
                <BreadCrumbs
                    parent="Member"
                    child1="Case Assistance Group"
                    path="Case Search"
                />
            </div>
            <div className="tabs-container" ref={printRef}>

                <div className="tab-header">
                    <h1 className="tab-heading page-heading float-left">Case/Member Representative Search</h1>
                    <div className="float-right th-btnGroup">
                        <ReactToPrint
                            onBeforeGetContent={() => {
                                setspinnerLoader(true);
                                dispatch(setPrintLayout(true));
                                return new Promise((resolve) => setTimeout(() => resolve(), 100));
                            }}
                            onAfterPrint={() => {
                                setspinnerLoader(false);
                                dispatch(setPrintLayout(false))
                            }
                            }
                            trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-primary btn-ic btn-print">
                                Print
                            </Button>)}
                            content={() => printRef.current}
                        />
                        <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
                            Help
        </Button>
                    </div>
                </div>
                <div className="tab-body clm-inquiry-panel-1">
                    <div className='tab-holder custom-tabber my-2'>
                        {/* <div className={`${printLayout ? 'hide-on-screen' : ''}`}> */}
                        <AppBar position='static' color="default">
                            <Tabs value={tabValue} onChange={handleTabChange}
                                indicatorColor="primary"
                                textColor="primary"
                                variant="scrollable"
                                scrollButtons="auto"
                                aria-label="scrollable auto tabs example">
                                <Tab title="Case Number" label="Case Number" {...a11yProps(0)} />
                                <Tab title="Case Head Name" label="Case Head Name" {...a11yProps(1)} />
                                <Tab title="Member ID" label="Member ID" {...a11yProps(2)} />
                                <Tab title="Member Name" label="Member Name" {...a11yProps(2)} />
                                <Tab title="Rep Name" label="Rep Name" {...a11yProps(2)} />
                            </Tabs>
                        </AppBar>

                        <TabPanel value={tabValue} index={0}>
                            <CaseNumberSearch values={values}
                                handleChanges={handleChanges} handleDCDtChange={handleDCDtChange}
                                resetTable={resetTable} searchCheck={searchCheck}
                                errors={{
                                    showCaseNumberError,
                                    showfromDateError,
                                    showtoDateError,
                                    showLobError,
                                    showCaseNumberErrorEnv, showtoDateInvError, showfromDateInvError, showCaseNumberNumericError
                                }}
                                dropdowns={addDropdowns} />

                            {showRecords ? <CaseNumberSearchTable tableData={showRecords} /> : null}

                        </TabPanel>

                        <TabPanel value={tabValue} index={1}>
                            <CaseHeadNameSearch dropdowns={addDropdowns} errors={{
                                showfromDateError,
                                showtoDateError
                            }} setRedirect={setRedirect} redirect={redirect} history={props.history} nameTabErrorMessages={nameTabErrorMessages} setNameTabErrorMessages={setNameTabErrorMessages} setNameErrorMessages={setNameErrorMessages} nameErrorMessages={nameErrorMessages} seterrorMessages={seterrorMessages} />
                        </TabPanel>
                        <TabPanel value={tabValue} index={2}>
                            <MemberidSearch values={memberIdValues} handleChanges={handleMemberIdChanges} handelDateChanges={handleMemberIdDCDtChange} dropdowns={addDropdowns}
                                resetTable={resetForm} searchCheck={memberSearchCheck}
                                errors={{ memberIdErr, idTypeErr, fromDateErr, toDateErr, memberIdMIDErr, memberIdRIDErr }} />
                            <MemberSearchTable tableData={showMemberIdRecords} />
                        </TabPanel>
                        <TabPanel value={tabValue} index={3}>
                            <MemberNameSearch values={memberNameValues} handleChanges={handleMemberNameChanges} handelDateChanges={handleMemberNameDCDtChange} dropdowns={addDropdowns}
                                resetTable={resetForm} searchCheck={memberSearchCheck}
                                errors={{
                                    lastNameErr, lastNameLengthErr, firstNameLengthErr, miInvalidErr,
                                    nameFromDateErr, nameToDateErr, lastNameWarningErr, firstNameWarningErr
                                }} />
                            <MemberSearchTable tableData={showMemberNameRecords} />
                        </TabPanel>
                        <TabPanel value={tabValue} index={4}>
                            <RepNameSearch values={repNameValues} handleChanges={handleRepNameChanges} handelDateChanges={handleRepNameDCDtChange} dropdowns={addDropdowns}
                                resetTable={resetForm} searchCheck={memberSearchCheck}
                                errors={{
                                    replastNameErr, replastNameLengthErr, repfirstNameLengthErr, repmiInvalidErr,
                                    repFromDateErr, repToDateErr, replastNameWarningErr, repfirstNameWarningErr
                                }} />
                            <RepNameSearchTable tableData={showRepNameRecords} />
                        </TabPanel>
                        {/* </div> */}
                    </div>
                </div>
                <Footer print />
            </div>
        </div>

    )

}
export default withRouter(CaseSearch);