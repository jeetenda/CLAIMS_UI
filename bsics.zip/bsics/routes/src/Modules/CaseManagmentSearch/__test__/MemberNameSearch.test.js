import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { memberSearchAction } from '../action'
import * as actionTypes from '../actionTypes'
import MemberNameSearch from "../Components/MemberNameSearch"

import rootReducer from "../../../SharedModules/Store/reducers";

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 6-Sep-2020
   * @author Jai Arora
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('MemberNameSearch Form Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper

    // intitial state for component
    const initialState = {

    }

    // intitial props for component
    const componentProps = {
        handleChanges: jest.fn(),
        handelDateChanges: jest.fn(),
        searchCheck: jest.fn(),
        resetTable: jest.fn(),
        values: {
            lastName: "",
            lastNameStartWithOrPhonetic: "",
            firstName: "",
            firstNameStartWithOrPhonetic: "",
            mi: "",
            fromDate: null,
            toDate: null,
            lob: "MED"
        },
        errors: {

            lastNameErr: false, lastNameLengthErr: false, firstNameLengthErr: false, miInvalidErr: false,
            nameFromDateErr: false, nameToDateErr: false, lastNameWarningErr: false, firstNameWarningErr: false
        }
    }

    //beforeEach Run before testcases is run 
    //for shallow 

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><MemberNameSearch  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    })



    //expect used for assert the component and match the output with testing condition

    describe('Rendering of MemberNameSearch form Component', () => {

        it('should render Line of Business without error', () => {
            const component = wrapper.find("[data-test='MNS-last-name']")
            expect(component.length).toBe(1);

        })




    })

    describe('MemberNameSearch  API test cases', function () {


        const reqBody = {
            "lastName": "AarNfaUmv",
            "phoneticSearchLastNameIndicator": false,
            "lastNameStartwith": true,
            "firstName": "",
            "phoneticSearchFirstNameIndicator": false,
            "firstNameStartwith": false,
            "middleName": "",
            "strFromDate": null,
            "strToDate": null,
            "lineOfBusiness": "MED",
            "searchBy": "Name"
        }

        const resObject = {
            "status": "Search Result Found",
            "success": true,
            "message": "success",
            "data": {
                "searchResults": [{
                    "searchResults": null,
                    "recordCount": 0,
                    "indicator": false,
                    "uniqueSArecCnt": 0,
                    "fullName": null,
                    "systemID": 50189982,
                    "phoneticSearchFirstName": null,
                    "phoneticSearchLastName": null,
                    "firstName": "WOCsUfqh",
                    "lastName": "AarNfaUmv",
                    "middleName": "B",
                    "suffixName": null,
                    "titleName": null,
                    "gender": "M",
                    "ssn": "874559580",
                    "medicareID": null,
                    "currAltID": "97859979600",
                    "caseNum": "872217851",
                    "dateOfBirth": "1987-11-04T00:00:00.000+0000",
                    "currAltIDTypeCode": "MID",
                    "lobCode": "MED",
                    "altIDTypeCode": null,
                    "strDateOfBirth": null,
                    "firstNametoUpper": null,
                    "lastNametoUpper": null,
                    "middleNametoUpper": null,
                    "obj": null,
                    "memberName": "AarNfaUmv, WOCsUfqh B",
                    "strFromDate": null,
                    "strToDate": null,
                    "genderDesc": "M-Male",
                    "currAltIDTypeCodeDesc": "MID-MID",
                    "currentMBI": null
                }],
                "recordCount": 1,
                "indicator": false,
                "uniqueSArecCnt": 0
            },
            "isRecordExist": true,
            "errorCode": null,
            "errorList": []

        }


        const reqResponse = {
            data: resObject
        }

        beforeEach(function () {
            // import and pass your custom axios instance to this method
            moxios.install()
        })

        afterEach(function () {
            // import and pass your custom axios instance to this method
            moxios.uninstall()
        })

        it('successfully data fetched from api call', () => {

            moxios.wait(() => {

                let request = moxios.requests.mostRecent()
                request.respondWith(mockSuccess(reqResponse));

            })

            const dispatchMemberNameSearch = {
                type: actionTypes.MEMBER_REP_MEMBERNAME_SEARCH,
                payload: resObject
            }



            return store.dispatch(memberSearchAction(reqBody))
                .then(() => {
                    const actions = store.getActions()

                    expect(actions[0].payload.data).toEqual(dispatchMemberNameSearch.payload);

                })

        })


    })





})








