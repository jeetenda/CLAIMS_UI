import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { caseSearchAction } from '../action'
import * as actionTypes from '../actionTypes'
import CaseNumberSearch from "../Components/CaseNumberSearch"

const middlewares = [thunk]
 
 /**
    * describe() is used to handle rendering Exception Search Component.
    * get element selector from componen using expect method of jest
    * @Date 9-Sep-2020
    * @author Himanshu Joshi
 */

 //api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })
 
describe('Case Number Search Form Component', () => {
  
  const mockStore = configureStore(middlewares)
  let store, wrapper
 
  // intitial state for component
  const initialState = {}
 
  // intitial props for component
  const componentProps = {
    errors: {showCaseNumberError: undefined, showfromDateError: undefined, showtoDateError: undefined, showLobError: undefined, showCaseNumberErrorEnv: undefined},
    handleChanges: jest.fn(),
    handleDCDtChange: jest.fn(),
    resetTable: jest.fn(),
    searchCheck: jest.fn(),
    values: {caseNumber: "", fromDate: "", toDate: "", lob: "MED"}
  }
 
  //beforeEach Run before testcases is run  
 
  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><CaseNumberSearch  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
    //console.log(wrapper.debug())
  })
 
  //expect used for assert the component and match the output with testing condition

   describe('Render Case Number Search Form Component' , ()=>{

    it('should render case number without error', () => {
      const component = wrapper.find("[data-test='case-number']")
      expect(component.length).toBe(1);
      
    })

    it('should render from date without error', () => {
      const component = wrapper.find("[data-test='from-date']")
      expect(component.length).toBe(1);
      
    })

    it('should render to date without error', () => {
      const component = wrapper.find("[data-test='to-date']")
      expect(component.length).toBe(1);
      
    })

    it('should render lob without error', () => {
      const component = wrapper.find("[data-test='lob']")
      expect(component.length).toBe(1);
      
    })

    it('should render search button without error', () => {
      const component = wrapper.find("[data-test='btn-search']")
      expect(component.length).toBe(1);
      
    })

    it('should render reset button without error', () => {
    const component = wrapper.find("[data-test='btn-reset']")
    expect(component.length).toBe(1);
    
  })

  describe('Case Number Search Form validation' , ()=>{
     
    it('should return the validation error', () => {
      const component = wrapper.find("[data-test='case-number']")
      expect(component.length).toBe(1);
      
    })
    
   })

   })

  describe('Member Search API test cases', function () {

    const reqBody = {
      aseNumber: "993519525",
      lob: "MED",
      searchBy: "caseNumber",
      strFromDate: "",
      strToDate: "",
    }

    const resObject = {
        caseHeadFirstName: "GRhpRegK",
        caseHeadLastName: "lZsdqNKLw",
        caseHeadMiddleName: "T",
        caseHeadName: "lZsdqNKLw, GRhpRegK T",
        caseHeadSuffixName: null,
        caseNumber: "993519525",
        currAltID: null,
        currAltIDTypeCode: null,
        lineOfBusiness: "MED",
        memberSysID: null,
        ssn: null
      }

    // const reqResponse = {
    //   data: resObject
    // }

    beforeEach(function () {
      // import and pass your custom axios instance to this method
      moxios.install()
    })
  
    afterEach(function () {
      // import and pass your custom axios instance to this method
      moxios.uninstall()
    })
  
    it('should be success the api call', () => {
  
      moxios.wait(() => {
        let request = moxios.requests.mostRecent()
        request.respondWith(mockSuccess(resObject));

      })
  
      const dispatchCaseNumberSearch = {
        type: actionTypes.CASE_NUMBER_SEARCH,
        caseNumberData: resObject,
    };
  
      return store.dispatch(caseSearchAction(reqBody))
        .then(() => {
          const actions = store.getActions()
          expect(actions[0]).toEqual(dispatchCaseNumberSearch);
        })
  
    })
  
    it('should be fail the api call', () => {
  
      const errResponse = {
       error: "no data found"
      }

      moxios.wait(() => {
        let request = moxios.requests.mostRecent()
        request.respondWith(mockError(errResponse))
      })
  
      return store.dispatch(caseSearchAction(reqBody))
        .then(() => {
          const actions = store.getActions()
          expect(actions[0].caseNumberData.data).toEqual(errResponse);
        })
  
    })
  
  })
 
})

   


  



