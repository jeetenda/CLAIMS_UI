import React from "react"
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import reducers from '../../../SharedModules/Store/reducers';

import { caseSearchAction } from '../action'
import * as actionTypes from '../actionTypes'
import CaseHeadNameSearch from "../Components/CaseHeadNameSearch"

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 11-Sep-2020
   * @author Himanshu Joshi
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('Case Head Name Search Component', () => {

  const initialState = { caseSearch: { caseHeadNamePayload: [] } }
  const mockStore = configureStore(middlewares)
  let store, wrapper

  // default props for component
  const compProps = {
    dropdowns: {},
    errors: { showfromDateError: undefined, showtoDateError: undefined },
    nameErrorMessages: [],
    nameTabErrorMessages: [],
    redirect: false,
    setNameErrorMessages: jest.fn(),
    setNameTabErrorMessages: jest.fn(),
    setRedirect: jest.fn(),
    seterrorMessages: jest.fn()
  }

  //beforeEach Run before testcases is run  
  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = mount(<Provider store={store}><Router><CaseHeadNameSearch  {...compProps} /></Router></Provider>)
    // console.log(wrapper.debug())
  })

  //expect used for assert the component and match the output with testing condition
  it('should render case head last name without error', () => {
    const component = wrapper.find("[data-test='last-name']")
    expect(component.length).toBe(1);
  })

  it('should render case head first name without error', () => {
    const component = wrapper.find("[data-test='first-name']")
    expect(component.length).toBe(1);
  })

  it('should render case head first name without error', () => {
    const component = wrapper.find("[data-test='first-name']")
    expect(component.length).toBe(1);
  })

  it('should render case head first name without error', () => {
    const component = wrapper.find("[data-test='first-name']")
    expect(component.length).toBe(1);
  })

  it('should render case head first name without error', () => {
    const component = wrapper.find("[data-test='from-date']")
    expect(component.length).toBe(1);
  })

  it('should render case head first name without error', () => {
    const component = wrapper.find("[data-test='btn-search']")
    expect(component.length).toBe(1);
  })

  describe('Case Head Name Search Form validation', () => {

    it('should return the validation error', () => {
      const component = wrapper.find("[data-test='last-name']")
      expect(component.length).toBe(1);

    })

  })


  describe('Member Search API test cases', function () {

    const reqBody = {
      caseHeadFirstCaseNameStartwith: false,
      caseHeadFirstName: "",
      caseHeadLastName: "LZWCQV",
      caseHeadLastNameStartwith: false,
      lob: "MED",
      phoneticCaseHeadFirstName: false,
      phoneticCaseHeadLastName: false,
      searchBy: "caseHeadName",
      strFromDate: "",
      strToDate: "",
    }

    const resObject = [{
      caseHeadFirstName: "Enos",
      caseHeadLastName: "LZWCQV",
      caseHeadMiddleName: null,
      caseHeadName: "LZWCQV, Enos",
      caseHeadSuffixName: null,
      caseNumber: "918030092",
      currAltID: null,
      currAltIDTypeCode: null,
      lineOfBusiness: "MED",
      memberSysID: null,
      ssn: null
    }]

    beforeEach(function () {
      // import and pass your custom axios instance to this method
      moxios.install()
    })

    afterEach(function () {
      // import and pass your custom axios instance to this method
      moxios.uninstall()
    })

    it('should be success the api call', () => {

      moxios.wait(() => {
        let request = moxios.requests.mostRecent()
        request.respondWith(mockSuccess(resObject));

      })

      const dispatchCaseHeadNameSearch = {
        type: actionTypes.CASE_HEAD_NAME_SEARCH,
        caseHeadNameData: resObject,
      }

      return store.dispatch(caseSearchAction(reqBody))
        .then(() => {
          const actions = store.getActions()
          expect(actions[0]).toEqual(dispatchCaseHeadNameSearch);
        })

    })

    it('should be fail the api call', () => {

      const errResponse = {
        error: "no data found"
      }

      moxios.wait(() => {
        let request = moxios.requests.mostRecent()
        request.respondWith(mockError(errResponse))
      })

      return store.dispatch(caseSearchAction(reqBody))
        .then(() => {
          const actions = store.getActions()
          expect(actions[0].caseNumberData.data).toEqual(errResponse);
        })

    })

  })

})