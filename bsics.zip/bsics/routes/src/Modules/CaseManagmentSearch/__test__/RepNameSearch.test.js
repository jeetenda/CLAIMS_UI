import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { memberSearchAction } from '../action'
import * as actionTypes from '../actionTypes'
import RepNameSearch from "../Components/RepNameSearch"

import rootReducer from "../../../SharedModules/Store/reducers";

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 6-Sep-2020
   * @author Jai Arora
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('RepNameSearch Form Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper

    // intitial state for component
    const initialState = {

    }

    // intitial props for component
    const componentProps = {
        handleChanges: jest.fn(),
        handelDateChanges: jest.fn(),
        searchCheck: jest.fn(),
        resetTable: jest.fn(),
        values: {
            lastName: "",
            lastNameStartWithOrPhonetic: "",
            firstName: "",
            firstNameStartWithOrPhonetic: "",
            mi: "",
            orgName: "",
            repNameStartsWith: "",
            fromDate: null,
            toDate: null,
            lob: "MED"
        },
        errors: {

            replastNameErr: false, replastNameLengthErr: false, repfirstNameLengthErr: false, repmiInvalidErr: false,
            repFromDateErr: false, repToDateErr: false, replastNameWarningErr: false, repfirstNameWarningErr: false
        }
    }

    //beforeEach Run before testcases is run 
    //for shallow 

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><RepNameSearch  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    })



    //expect used for assert the component and match the output with testing condition

    describe('Rendering of RepNameSearch form Component', () => {

        it('should render Last Name without error', () => {
            const component = wrapper.find("[data-test='RNS-last-name']")
            expect(component.length).toBe(1);

        })
        it('should render first Name without error', () => {
            const component = wrapper.find("[data-test='RNS-first-name']")
            expect(component.length).toBe(1);

        })

        it('should render MI without error', () => {
            const component = wrapper.find("[data-test='RNS-mi']")
            expect(component.length).toBe(1);

        })

    })

    describe('RepName Search API test cases', function () {

        const reqBody = {
            "lastName": "ABCIZB",
            "phoneticSearchLastNameIndicator": false,
            "lastNameStartwith": true,
            "firstName": "",
            "phoneticSearchFirstNameIndicator": false,
            "firstNameStartwith": false,
            "repOrganizationName": "",
            "organizationNameStartsWith": "",
            "middleName": "",
            "strFromDate": null,
            "strToDate": null,
            "lineOfBusiness": "MED",
            "searchBy": "REP"
        }

        const resObject = {
            "status": "Search Result Found",
            "success": true,
            "message": "success",
            "data": {
                "searchResults": [{
                    "systemID": 4451430,
                    "firstName": "Edyth",
                    "lastName": "Jibma",
                    "middleName": "Z",
                    "suffixName": null,
                    "memberName": "Jibma, Edyth Z",
                    "repFullName": "ABCIZB, Arly R",
                    "repFirstName": "Arly",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "R",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "72970792523",
                    "currAltIDTypeCode": "MID"
                }, {
                    "systemID": 4319862,
                    "firstName": "Escarleth",
                    "lastName": "Ilrcbivb",
                    "middleName": "T",
                    "suffixName": null,
                    "memberName": "Ilrcbivb, Escarleth T",
                    "repFullName": "ABCIZB, Avis",
                    "repFirstName": "Avis",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "48342484514",
                    "currAltIDTypeCode": "MID"
                }, {
                    "systemID": 4134983,
                    "firstName": "Annabel",
                    "lastName": "Abcizb",
                    "middleName": "L",
                    "suffixName": null,
                    "memberName": "Abcizb, Annabel L",
                    "repFullName": "ABCIZB, Blane E",
                    "repFirstName": "Blane",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "E",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "90947100018",
                    "currAltIDTypeCode": "MID"
                }, {
                    "systemID": 4134984,
                    "firstName": "Emanuell",
                    "lastName": "Abcizb",
                    "middleName": "M",
                    "suffixName": null,
                    "memberName": "Abcizb, Emanuell M",
                    "repFullName": "ABCIZB, Blane E",
                    "repFirstName": "Blane",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "E",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "90947100974",
                    "currAltIDTypeCode": "MID"
                }, {
                    "systemID": 50026333,
                    "firstName": "Elaine",
                    "lastName": "Abcizb",
                    "middleName": "J",
                    "suffixName": null,
                    "memberName": "Abcizb, Elaine J",
                    "repFullName": "ABCIZB, Davian X",
                    "repFirstName": "Davian",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "X",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "32194714633",
                    "currAltIDTypeCode": "MID"
                }, {
                    "systemID": 50026334,
                    "firstName": "Davian",
                    "lastName": "Abcizb",
                    "middleName": "X",
                    "suffixName": "III",
                    "memberName": "Abcizb, III Davian X",
                    "repFullName": "ABCIZB, Davian X",
                    "repFirstName": "Davian",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "X",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "32194760003",
                    "currAltIDTypeCode": "MID"
                }, {
                    "systemID": 4291573,
                    "firstName": "Cilla",
                    "lastName": "Jcvlg",
                    "middleName": "T",
                    "suffixName": null,
                    "memberName": "Jcvlg, Cilla T",
                    "repFullName": "ABCIZB, Isidore K",
                    "repFirstName": "Isidore",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "K",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "38281956287",
                    "currAltIDTypeCode": "MID"
                }, {
                    "systemID": 4257229,
                    "firstName": "Coral",
                    "lastName": "Abcizb",
                    "middleName": "U",
                    "suffixName": null,
                    "memberName": "Abcizb, Coral U",
                    "repFullName": "ABCIZB, Isidore K",
                    "repFirstName": "Isidore",
                    "repLastName": "ABCIZB",
                    "repMiddleName": "K",
                    "repSuffixName": null,
                    "organizationName": null,
                    "currAltID": "78585987950",
                    "currAltIDTypeCode": "MID"
                }],
                "recordCount": 8,
                "indicator": false,
                "uniqueSArecCnt": 0
            },
            "isRecordExist": true,
            "errorCode": null,
            "errorList": []
        }

        const reqResponse = {
            data: resObject
        }

        beforeEach(function () {
            // import and pass your custom axios instance to this method
            moxios.install()
        })

        afterEach(function () {
            // import and pass your custom axios instance to this method
            moxios.uninstall()
        })

        it('successfully data fetched from api call', () => {

            moxios.wait(() => {

                let request = moxios.requests.mostRecent()
                request.respondWith(mockSuccess(reqResponse));

            })

            const dispatchRepNameSearch = {
                type: actionTypes.MEMBER_REP_REPNAME_SEARCH,
                payload: resObject
            }



            return store.dispatch(memberSearchAction(reqBody))
                .then(() => {
                    const actions = store.getActions()

                    expect(actions[0].payload.data).toEqual(dispatchRepNameSearch.payload);

                })

        })


    })





})








