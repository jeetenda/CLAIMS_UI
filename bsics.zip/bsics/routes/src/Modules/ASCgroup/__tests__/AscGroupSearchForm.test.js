import React from "react"
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { ascCodeSearchAction, ascCodeDetailsAction } from '../actions'
import * as actionTypes from '../actionTypes'
import AscGroupSearchForm from "../Components/AscGroupSearchForm"


const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 4-Sep-2020
   * @author Jai Arora
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('ASC Group / ASC Region Search Form Component', () => {

  const mockStore = configureStore(middlewares)
  let store, wrapper

  // intitial state for component
  const initialState = {

  }

  // intitial props for component
  const componentProps = {
    handleChanges: jest.fn(),
    searchCheck: jest.fn(),
    resetTable: jest.fn(),
    values: {
      lobCodeDesc: "Please Select One",
      ascGroupCodeDesc: "Please Select One",
      ascRegionCodeDesc: "Please Select One",
      lobCode: [],
      ascGroupCode: "",
      ascRegionCode: "",
    },
    errors: {

      showAsclobError: false,
      showAscCodeError: false,
    }
  }

  //beforeEach Run before testcases is run 
  //for shallow 

  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><AscGroupSearchForm  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
    // console.log(wrapper.debug())
  })



  //expect used for assert the component and match the output with testing condition

  describe('Rendering of ASC Search form Component', () => {

    it('should render Line of Business without error', () => {
      const component = wrapper.find("[data-test='lob-id']")
      expect(component.length).toBe(1);

    })

    it('should render ASC Group without error', () => {
      const component = wrapper.find("[data-test='asc-group-id']")
      expect(component.length).toBe(1);

    })

    it('should render ASC Region without error', () => {
      const component = wrapper.find("[data-test='asc-region-id']")
      expect(component.length).toBe(1);

    })


  })

  describe('ASC Search API test cases', function () {

    const reqBody = { "lobCode": ["MED"], "ascGroupCode": "01", "ascRegionCode": "02" }

    const resObject = {

      "status": "Search Result Found",
      "success": true,
      "message": "SUCCESS",
      "data": {
        "searchResults": [{
          "searchResults": null,
          "recordCount": 0,
          "indicator": false,
          "uniqueSArecCnt": 0,
          "lobCode": "MED",
          "ascGroupCode": "01",
          "ascRegionCode": "02",
          "lobCodeDesc": "MED-MEDICAID",
          "ascRegionCodeDesc": "02",
          "ascGroupCodeDesc": "01-Grp01"
        }],
        "recordCount": 1,
        "indicator": false,
        "uniqueSArecCnt": 0
      },
      "isRecordExist": true,
      "errorCode": null,
      "errorList": []

    }

    const reqResponse = {
      data: resObject
    }

    beforeEach(function () {
      // import and pass your custom axios instance to this method
      moxios.install()
    })

    afterEach(function () {
      // import and pass your custom axios instance to this method
      moxios.uninstall()
    })

    it('successfully data fetched from api call', () => {

      moxios.wait(() => {

        let request = moxios.requests.mostRecent()
        request.respondWith(mockSuccess(reqResponse));

      })

      const dispatchAscgroupSearch = {
        type: actionTypes.ASC_CODE_SEARCH_TYPE,
        ascSearchData: resObject
      }

      return store.dispatch(ascCodeSearchAction(reqBody))
        .then(() => {
          const actions = store.getActions()

          expect(actions[0].ascSearchData.data).toEqual(dispatchAscgroupSearch.ascSearchData);

        })

    })

    it('successfully view data fetched from api call', () => {

      moxios.wait(() => {

        let request = moxios.requests.mostRecent()
        request.respondWith(mockSuccess(reqResponse));

      })

      const dispatchascCodeViewDetails = {
        type: actionTypes.ASC_CODE_VIEW_DETAILS_TYPE,
        ascSearchData: resObject
      }

      return store.dispatch(ascCodeDetailsAction(reqBody))
        .then(() => {

          const actions = store.getActions()

          expect(actions[0].ascSearchData.data).toEqual(dispatchascCodeViewDetails.ascSearchData);

        })

      it('should be fail the api call', () => {


        const errResponse = {
          error: "no data found"
        }

        moxios.wait(() => {
          let request = moxios.requests.mostRecent()
          request.respondWith(mockError(errResponse))
        })

        return store.dispatch(ascCodeSearchAction(reqBody))
          .then(() => {
            const actions = store.getActions()

            expect(actions[0].ascSearchData.data).toEqual(errResponse);
          })

      })

    })





  })


})








