import React from "react"
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { ascGroupCreate } from '../actions'
import * as actionTypes from '../actionTypes'
import AddAscForm from "../Components/AddAscForm"


const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 7-Sep-2020
   * @author Jai Arora
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('ASC Group / ASC Region Add Form Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper

    // intitial state for component
    const initialState = {

    }



    // intitial props for component
    const componentProps = {
        values: {
            beginDate: "",
            endDate: "12/31/9999",
            rateAmount: "",
            ratePercent: "",
            rateSourceDesc: "-1",
        },

        handleChanges: jest.fn(),
        handleCIDtChanges: jest.fn(),

        errors: {
            showBeginDateError: false,
            showEndDateError: false,
            endDtInvalidEr: false,
            beginDtInvalidErr: false,
            rateamountformaterr: false,
            ratepercentageformaterr: false,
            rateamountreqerr: false,
            showCIBgdtGTEnddtErr: false,
            rateamountinvaliderr: false,
            ratepercentageinvaliderr: false
        }

    }

    //beforeEach Run before testcases is run 
    //for shallow 

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><AddAscForm  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    })



    //expect used for assert the component and match the output with testing condition

    describe('Rendering of ASC ADD form Component', () => {

        it('should render Begin data without error', () => {
            const component = wrapper.find("[data-test='bgn-date-asc']")
            expect(component.exists()).toBe(true);

        })

        it('should render End date without error', () => {
            const component = wrapper.find("[data-test='end-date-asc']")
            expect(component.length).toBe(1);

        })

        it('should render ASC Amount without error', () => {
            const component = wrapper.find("[data-test='amount-asc']")
            expect(component.length).toBe(1);
        })

        it('should render ASC percentage without error', () => {
            const component = wrapper.find("[data-test='percent-asc']")
            expect(component.length).toBe(1);
        })
        it('should render ASC source without error', () => {
            const component = wrapper.find("[data-test='rate-source-asc']")
            expect(component.length).toBe(1);
        })
        describe('ASC Group Add API test cases', function () {

            const reqBody =
            {
                "auditUserID": "OQTKPZQAB, DANI ",
                "auditTimeStamp": "2020-09-07T10:58:18.064Z",
                "addedAuditUserID": "OQTKPZQAB, DANI ",
                "addedAuditTimeStamp": "2020-09-07T10:58:18.064Z",
                "versionNo": 0,
                "dbRecord": false,
                "sortColumn": null,
                "auditKeyList": [],
                "auditKeyListFiltered": false,
                "beginDate": null,
                "endDate": null,
                "prevBegDate": null,
                "prevEndDate": null,
                "voidDt": null,
                "voidDate": null,
                "tempVoidDate": null,
                "rateSourceCode": null,
                "noteSetVO": null,
                "noteCount": 0,
                "rateAmount": null,
                "ratePercent": null,
                "rateSourceDesc": null,
                "showVoids": false,
                "showVoidRecord": true,
                "rateASCGroupSK": null,
                "ratePCCategoryOfServiceSK": null,
                "rateRCProviderTypeSK": null,
                "providerID": null,
                "providerTypeCode": null,
                "lobCode": "MED",
                "procedureCode": null,
                "networkID": null,
                "benifitPlanID": null,
                "modifierCode1": null,
                "modifierCode2": null,
                "modifierCode3": null,
                "modifierCode4": null,
                "revenueCode": null,
                "revenueTypeCode": null,
                "regionCode": null,
                "ascGroupCode": "05",
                "lobDesc": null,
                "ascRegionDesc": null,
                "rateVOList": [{
                    "auditUserID": "OQTKPZQAB, DANI ",
                    "auditTimeStamp": "2020-09-07T10:58:11.407Z",
                    "addedAuditUserID": "OQTKPZQAB, DANI ",
                    "addedAuditTimeStamp": "2020-09-07T10:58:11.407Z",
                    "versionNo": 0,
                    "dbRecord": false,
                    "sortColumn": null,
                    "auditKeyList": [],
                    "auditKeyListFiltered": false,
                    "beginDate": "09/07/2020",
                    "endDate": "09/25/2020",
                    "prevBegDate": null,
                    "prevEndDate": null,
                    "voidDt": null,
                    "voidDate": null,
                    "tempVoidDate": null,
                    "rateSourceCode": "FP",
                    "noteSetVO": null,
                    "noteCount": 0,
                    "rateAmount": "12",
                    "ratePercent": "11",
                    "rateSourceDesc": "FP",
                    "showVoids": false,
                    "showVoidRecord": true,
                    "rateASCGroupSK": null,
                    "ratePCCategoryOfServiceSK": null,
                    "rateRCProviderTypeSK": null,
                    "providerID": null,
                    "providerTypeCode": null,
                    "lobCode": null,
                    "procedureCode": null,
                    "networkID": null,
                    "benifitPlanID": null,
                    "modifierCode1": null,
                    "modifierCode2": null,
                    "modifierCode3": null,
                    "modifierCode4": null,
                    "revenueCode": null,
                    "revenueTypeCode": null,
                    "regionCode": null
                }],
                "ascRegionCode": "01",
                "deletedRateObjectsList": [],
                "ascGroupCodeDesc": null
            }

            const resObject = {
                status: "success"
            }

            const reqResponse = {
                data: resObject
            }

            beforeEach(function () {
                // import and pass your custom axios instance to this method
                moxios.install()
            })

            afterEach(function () {
                // import and pass your custom axios instance to this method
                moxios.uninstall()
            })

            it('should be success the add api call', () => {


                moxios.wait(() => {

                    let request = moxios.requests.mostRecent()

                    request.respondWith(mockSuccess(reqResponse))
                })
                const dispatchascCodeCreate = {
                    type: actionTypes.ASC_CODE_CREATE,
                    ascCreateData: reqResponse
                };

                return store.dispatch(ascGroupCreate(reqBody))
                    .then(() => {
                        const actions = store.getActions();
                        expect(actions[0].ascCreateData).toEqual(dispatchascCodeCreate.ascCreateData);
                    })

            })



        })





    })






})