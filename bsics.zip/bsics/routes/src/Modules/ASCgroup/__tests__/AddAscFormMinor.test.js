import React from "react"
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { ascGroupUpdate, ascCodeDetailsAction } from '../actions'
import * as actionTypes from '../actionTypes'
import AddAscFormMinor from "../Components/AddAscFormMinor"


const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 7-Sep-2020
   * @author Jai Arora
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('ASC Group / ASC Region Add Form Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper

    // intitial state for component
    const initialState = {

    }



    // intitial props for component
    const componentProps = {
        rateVOList: [],
        handleChanges: jest.fn(),
        handleCIDtChanges: jest.fn(),
        setTableData: jest.fn(),
        setErrorMessages: jest.fn(),
        isEditOp: true,
        deleteList: [],
        setDeleteList: jest.fn(),
        showForm: true


    }

    //beforeEach Run before testcases is run 
    //for shallow 

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><AddAscFormMinor  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive()


    })



    //expect used for assert the component and match the output with testing condition

    describe('Rendering of ASC ADD form Component', () => {

        it('should render the delete button without error', () => {
            const component = wrapper.find("[data-test='test_del_btn']");
            expect(component.length).toBe(1)
        })
        it('should render the add button without error', () => {
            const component = wrapper.find("[data-test='test_add_btn']");
            expect(component.length).toBe(1)
        })
        it('should render the begin date without error', () => {
            const component = wrapper.find("[data-test='test_add_btn']");
            (component).simulate("click");
            const component2 = wrapper.find("[data-test='test_begin_dt']")
            expect(component2.length).toBe(1);
        })
        it('should render the end date without error', () => {
            const component = wrapper.find("[data-test='test_add_btn']");
            (component).simulate("click");
            const component2 = wrapper.find("[data-test='test_end_dt']")
            expect(component2.length).toBe(1);
        })
        it('should render the amount without error', () => {
            const component = wrapper.find("[data-test='test_add_btn']");
            (component).simulate("click");
            const component2 = wrapper.find("[data-test='test_amt']")
            expect(component2.length).toBe(1);
        })
        it('should render the rate source without error', () => {
            const component = wrapper.find("[data-test='test_add_btn']");
            (component).simulate("click");
            const component2 = wrapper.find("[data-test='test_rate']")
            expect(component2.length).toBe(1);
        })
        it('should render the percentage without error', () => {
            const component = wrapper.find("[data-test='test_add_btn']");
            (component).simulate("click");
            const component2 = wrapper.find("[data-test='test_percenatge']")
            expect(component2.length).toBe(1);
        })
        describe('ASC Group Edit and update API test cases', function () {

            const reqBody =
            {
                "auditUserID": "OQTKPZQAB, DANI ",
                "auditTimeStamp": "2020-09-07T10:58:18.064Z",
                "addedAuditUserID": "OQTKPZQAB, DANI ",
                "addedAuditTimeStamp": "2020-09-07T10:58:18.064Z",
                "versionNo": 0,
                "dbRecord": false,
                "sortColumn": null,
                "auditKeyList": [],
                "auditKeyListFiltered": false,
                "beginDate": null,
                "endDate": null,
                "prevBegDate": null,
                "prevEndDate": null,
                "voidDt": null,
                "voidDate": null,
                "tempVoidDate": null,
                "rateSourceCode": null,
                "noteSetVO": null,
                "noteCount": 0,
                "rateAmount": null,
                "ratePercent": null,
                "rateSourceDesc": null,
                "showVoids": false,
                "showVoidRecord": true,
                "rateASCGroupSK": null,
                "ratePCCategoryOfServiceSK": null,
                "rateRCProviderTypeSK": null,
                "providerID": null,
                "providerTypeCode": null,
                "lobCode": "MED",
                "procedureCode": null,
                "networkID": null,
                "benifitPlanID": null,
                "modifierCode1": null,
                "modifierCode2": null,
                "modifierCode3": null,
                "modifierCode4": null,
                "revenueCode": null,
                "revenueTypeCode": null,
                "regionCode": null,
                "ascGroupCode": "05",
                "lobDesc": null,
                "ascRegionDesc": null,
                "rateVOList": [{
                    "auditUserID": "OQTKPZQAB, DANI ",
                    "auditTimeStamp": "2020-09-07T10:58:11.407Z",
                    "addedAuditUserID": "OQTKPZQAB, DANI ",
                    "addedAuditTimeStamp": "2020-09-07T10:58:11.407Z",
                    "versionNo": 0,
                    "dbRecord": false,
                    "sortColumn": null,
                    "auditKeyList": [],
                    "auditKeyListFiltered": false,
                    "beginDate": "09/07/2020",
                    "endDate": "09/25/2020",
                    "prevBegDate": null,
                    "prevEndDate": null,
                    "voidDt": null,
                    "voidDate": null,
                    "tempVoidDate": null,
                    "rateSourceCode": "FP",
                    "noteSetVO": null,
                    "noteCount": 0,
                    "rateAmount": "12",
                    "ratePercent": "11",
                    "rateSourceDesc": "FP",
                    "showVoids": false,
                    "showVoidRecord": true,
                    "rateASCGroupSK": null,
                    "ratePCCategoryOfServiceSK": null,
                    "rateRCProviderTypeSK": null,
                    "providerID": null,
                    "providerTypeCode": null,
                    "lobCode": null,
                    "procedureCode": null,
                    "networkID": null,
                    "benifitPlanID": null,
                    "modifierCode1": null,
                    "modifierCode2": null,
                    "modifierCode3": null,
                    "modifierCode4": null,
                    "revenueCode": null,
                    "revenueTypeCode": null,
                    "regionCode": null
                }],
                "ascRegionCode": "01",
                "deletedRateObjectsList": [],
                "ascGroupCodeDesc": null
            }

            const resObject = {
                status: "success"
            }

            const reqResponse = {
                data: resObject
            }

            beforeEach(function () {
                // import and pass your custom axios instance to this method
                moxios.install()
            })

            afterEach(function () {
                // import and pass your custom axios instance to this method
                moxios.uninstall()
            })



            it('should be success the edit / update api call', () => {


                moxios.wait(() => {

                    let request = moxios.requests.mostRecent()

                    request.respondWith(mockSuccess(reqResponse))
                })
                const dispatchascCodeViewDetails = {
                    type: actionTypes.ASC_CODE_VIEW_DETAILS_TYPE,
                    ascUpdateData: reqResponse
                };

                return store.dispatch(ascGroupUpdate(reqBody))
                    .then(() => {
                        const actions = store.getActions();
                        expect(actions[0].ascUpdateData).toEqual(dispatchascCodeViewDetails.ascUpdateData);
                    })

            })


        })





    })






})