import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import { Button } from "react-bootstrap";
import * as AscGroupConstant from "./AscGroupConstant";

export default function AscGroupSearchForm(props) {
  return (
    <form autoComplete="off">
      <div className="form-wrapper pt-3">
        <div className="mui-custom-form with-select input-md">
          <TextField
            data-test='lob-id'
            id="lob-id"
            select
            label="Line of Business"
            value={props.values.lobCodeDesc}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges("lobCodeDesc")}
            placeholder=""
            helperText={
              props.errors.showAsclobError ? AscGroupConstant.LOB_Error : null
            }
            InputLabelProps={{
              shrink: true,
              required: true,
            }}
            error={
              props.errors.showAsclobError ? AscGroupConstant.LOB_Error : null
            }
          >
            <MenuItem
              selected
              key="Please Select One"
              value="Please Select One"
            >
              Please Select One
            </MenuItem>
            {props.sysdropdowns &&
              Object.keys(props.sysdropdowns).length > 0 &&
              props.sysdropdowns["Reference#1019"] &&
              props.sysdropdowns["Reference#1019"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md">
          <TextField
            data-test='asc-group-id'
            id="asc-group-id"
            select
            label="ASC Group"
            value={props.values.ascGroupCodeDesc}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges("ascGroupCodeDesc")}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem
              selected
              key="Please Select One"
              value="Please Select One"
            >
              Please Select One
            </MenuItem>
            {props.dropdowns &&
              Object.keys(props.dropdowns).length > 0 &&
              props.dropdowns["R1#R_ASC_GRP_CD"] &&
              props.dropdowns["R1#R_ASC_GRP_CD"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>

        <div className="mui-custom-form with-select input-md">
          <TextField
            data-test='asc-region-id'
            id="asc-region-id"
            select
            label="ASC Region"
            value={props.values.ascRegionCodeDesc}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges("ascRegionCodeDesc")}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem
              selected
              key="Please Select One"
              value="Please Select One"
            >
              Please Select One
            </MenuItem>
            {props.dropdowns &&
              Object.keys(props.dropdowns).length > 0 &&
              props.dropdowns["R1#R_RATE_ASC_RGN_CD"] &&
              props.dropdowns["R1#R_RATE_ASC_RGN_CD"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>
      </div>

      <div className="float-right th-btnGroup mr-3 mb-2">
        <Button
          title="Search"
          variant="outlined"
          color="primary"
          className="btn btn-ic btn-search"
          onClick={props.searchCheck}
          disabled={
            props.privileges && !props.privileges.search ? "disabled" : ""
          }
        >
          {" "}
          Search{" "}
        </Button>
        <Button
          title="Reset"
          variant="outlined"
          color="primary"
          className="btn btn-ic btn-reset"
          onClick={props.resetTable}
        >
          {" "}
          Reset{" "}
        </Button>
      </div>
      <div className="clearfix" />
    </form>
  );
}
