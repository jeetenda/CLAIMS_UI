import React, { useState, useEffect, useRef } from "react";
import { withRouter } from "react-router";
import { Button } from "react-bootstrap";
import * as AscGroupConstant from "./AscGroupConstant";
import { makeStyles } from "@material-ui/core/styles";
import Checkbox from "@material-ui/core/Checkbox";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import { getLoginUserDetails } from "../../../SharedModules/utility/utilityFunction";
import * as ErrorMsgConstants from "../../../SharedModules/Messages/ErrorMsgConstants";
import { useConfirm } from "../../../SharedModules/MUIConfirm/index";
import InputAdornment from "@material-ui/core/InputAdornment";
import dateFnsFormat from "date-fns/format";
import * as moment from "moment";
import AscGroupEditTableComponent from "./AscGroupEditTableComponent";
import ErrorComponent from "../../../SharedModules/Errors/TimeOutErrorMsg";
import SuccessComponent from "../../../SharedModules/Errors/TimeOutSuccessMsg";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
} from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";

const useStyles = makeStyles((theme) => ({
  pd0bd0: {
    padding: "0 !important",
    border: "0 !important",
  },
}));

const PCProviderTypeMinorForm = (props, ref) => {
  const [selectedBeginDate, setSelectedBeginDate] = useState("");
  const [selectedEndDate, setSelectedEndDate] = useState("");
  const scrollToRef = (ref) =>
    ref.current.scrollIntoView({ behavior: "smooth" });
  const addProviderType = useRef(null);
  const voidRef = useRef();
  const muiconfirm = useConfirm();
  const [showForm, setShowForm] = useState(false);
  const defaultFormData = {
    beginDate: null,
    endDate: "12/31/9999",
    rateAmount: null,
    rateSourceCode: "-1",
    ratePercent: null,
  };
  let errors = {
    beginDateErr: false,
    beginDateInvalidErr: false,
    endDateErr: false,
    endDateInvalidErr: false,
    amountErr: false,
    amountFormatErr: false,
    amountInvalidErr: false,
    overlapError: false,
    beginDtGtEndDtErr: false,
    amountZeroErr: false,
    duplicateErr: false
  };
  const [formData, setFormData] = useState(defaultFormData);
  const [resetformData, setResetFormData] = useState(defaultFormData);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [success, setSuccess] = useState(false);
  const [multiDelete, setMultiDelete] = useState([]);
  const [deleteMsg, setDeletedMsg] = useState(false);
  const [tableData, setTableData] = useState([]);
  const userDetails = getLoginUserDetails();
  const [isMinorEdit, setIsMinorEdit] = useState(false);
  const [
    {
      beginDateErr,
      beginDateInvalidErr,
      endDateErr,
      endDateInvalidErr,
      overlapError,
      beginDtGtEndDtErr,
      amountFormatErr,
      amountInvalidErr,
      percentageFormatErr,
      percentageInvalidErr,
      rateamountreqerr,
      duplicateErr,
    },
    setFormErrors,
  ] = useState(false);

  useEffect(() => {
    let data = props.rateVOList ? props.rateVOList : [];
    if (props.isEditOp) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
          each.index = index;
      });

      setTableData(
        voidRef.current && voidRef.current.checked
          ? tData
          : tData.filter((a) => {
            return a.voidDate ? false : true;
          })
      );
    } else {
      setTableData(tData);
    }
    props.rateVOList.endDate !== ""
      ? setSelectedEndDate(props.rateVOList.endDate)
      : setSelectedEndDate("");
    props.rateVOList.beginDate !== ""
      ? setSelectedBeginDate(props.rateVOList.beginDate)
      : setSelectedBeginDate("");
  }, [props.rateVOList.beginDate, props.rateVOList.endDate, props.rateVOList]);

  const handleBDateChange = (date) => {
    setSelectedBeginDate(date);
    setFormData({ ...formData, beginDate: formatDate(date) });
  };

  const handleEDateChange = (date) => {
    setSelectedEndDate(date);
    setFormData({ ...formData, endDate: formatDate(date) });
  };

  const handleMinorchange = (name) => (event) => {

    setFormData({ ...formData, [name]: event.target.value });

  };

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };
  const handelDateRngeOverlap = (initalStartDate, initialEndDate, secondaryStartDate, secondaryEndDate) => {
    const range1 = moment().range(new Date(initalStartDate), new Date(initialEndDate));
    const range2 = moment().range(new Date(secondaryStartDate), new Date(secondaryEndDate));
    return range1.overlaps(range2);
  }

  const handelDateRngeArrayOverlap = (initalStartDate, initialEndDate, inputArray) => {
    if (inputArray.length > 0) {
      const result = inputArray.map(each => handelDateRngeOverlap(initalStartDate, initialEndDate, each.beginDate, each.endDate))
      if (result.filter(e => e === true).length > 0) {
        return true
      } else {
        return false;
      }
    } else {
      return false
    }
  }

  const minorValidation = () => {
    setFormErrors(false);
    props.setErrorMessages([]);
    let reqFieldArr = [];
    setFormErrors({
      rateamountreqerr
        : (formData.rateAmount == "" && formData.ratePercent == "") || (formData.rateAmount && formData.ratePercent)
          ? (() => {

            reqFieldArr.push(AscGroupConstant.Asc_Region_Amount);
            return true;
          })()
          : false,

      beginDateErr: formData.beginDate
        ? false
        : (() => {
          reqFieldArr.push(ErrorMsgConstants.Begin_Date_Error);
          return true;
        })(),
      endDateErr: formData.endDate
        ? false
        : (() => {
          reqFieldArr.push(ErrorMsgConstants.End_Date_Error);
          return true;
        })(),

    });
    if (reqFieldArr.length > 0) {
      props.setErrorMessages(reqFieldArr);
      return false;
    }
    setFormErrors({
      beginDateInvalidErr:
        formatDate(formData.beginDate) === "" || formData.beginDate.toString() == "Invalid Date" ||
          moment(formData.beginDate).isBefore("1964-01-01")
          ? (() => {
            reqFieldArr.push(ErrorMsgConstants.Invalid_Begin_Date_Error);
            return true;
          })()
          : false,
      endDateInvalidErr:
        formatDate(formData.endDate) === "" ||
          moment(formData.endDate).isBefore("1964-01-01")
          ? (() => {
            reqFieldArr.push(ErrorMsgConstants.Invalid_End_Date_Error);
            return true;
          })()
          : false,
    });
    if (formData.ratePercent) {
      if (!formData.ratePercent.match(/^[0-9.]*$/g)) {
        reqFieldArr.push(ErrorMsgConstants.INVALID_DESCRIPTION);
        setFormErrors({
          percentageFormatErr: true,
        });
      } else {
        let splitVal = formData.ratePercent.split(".");
        if (splitVal.length === 1) {
          if (splitVal[0].length > 5) {
            reqFieldArr.push(ErrorMsgConstants.PER_AMT_DEC_ERR);
            setFormErrors({
              percentageInvalidErr: true,
            });
          }
        } else if (splitVal.length > 2) {
          reqFieldArr.push(ErrorMsgConstants.INVALID_DESCRIPTION);

          setFormErrors({
            percentageFormatErr: true,
          });
        } else if (
          splitVal.length == 2 &&
          (splitVal[0].length > 5 || splitVal[1].length > 2)
        ) {
          reqFieldArr.push(ErrorMsgConstants.PER_AMT_DEC_ERR);
          setFormErrors({
            percentageInvalidErr: true,
          });
        }
      }
    }
    const duplicate = tableData.length > 0 && !(tableData.length == 1 && formData.index > -1) && tableData.filter((i, index) => {
      if (formData.index === undefined || (formData.index !== index)) {
        return (i.rateSourceCode === formData.rateSourceCode)
      }
    });

    if (duplicate && duplicate.length > 0) {
      setFormErrors({
        duplicateErr: true
      });
      reqFieldArr.push(ErrorMsgConstants.DUB_RATE_SOURCE)
    }
    if (reqFieldArr.length > 0) {
      props.setErrorMessages(reqFieldArr);
      return false;
    }
    if (formData.rateAmount) {
      if (!formData.rateAmount.match(/^[0-9.]*$/g)) {
        reqFieldArr.push(ErrorMsgConstants.INVALID_DESCRIPTION);
        setFormErrors({
          amountFormatErr: true,
        });
      } else {
        let splitVal = formData.rateAmount.split(".");
        if (splitVal.length === 1) {
          if (splitVal[0].length > 7) {
            reqFieldArr.push(ErrorMsgConstants.RATE_AMT_DEC_ERR);
            setFormErrors({
              amountInvalidErr: true,
            });
          }
        } else if (splitVal.length > 2) {
          reqFieldArr.push(ErrorMsgConstants.INVALID_DESCRIPTION);

          setFormErrors({
            amountFormatErr: true,
          });
        } else if (
          splitVal.length == 2 &&
          (splitVal[0].length > 7 || splitVal[1].length > 2)
        ) {
          reqFieldArr.push(ErrorMsgConstants.RATE_AMT_DEC_ERR);
          setFormErrors({
            amountInvalidErr: true,
          });
        }
      }
    }

    let test = JSON.parse(JSON.stringify(tableData));
    let overlapArray;
    if (formData.index > -1) {
      overlapArray = test.filter((e, index) => index != formData.index)
    } else {
      overlapArray = test;
    }

    let overlapValidation = handelDateRngeArrayOverlap(formatDate(formData.beginDate), formatDate(formData.endDate), overlapArray);

    if (overlapValidation) {
      setFormErrors({
        overlapError: true
      });
      reqFieldArr.push(ErrorMsgConstants.Overlaps_Btw_Detail_Rows_Dates);

    }

    if (reqFieldArr.length > 0) {
      props.setErrorMessages(reqFieldArr);
      return false;
    }
    setFormErrors({
      beginDtGtEndDtErr:
        (new Date(formData.beginDate) >= new Date(formData.endDate)) && (formData.beginDate.toString() != "Invalid Date" || formData.endDate.toString() != "Invalid Date")
          ? (() => {
            reqFieldArr.push(ErrorMsgConstants.Bgndt_GT_Enddt_Err);
            return true;
          })()
          : false,
    });
    if (reqFieldArr.length > 0) {
      props.setErrorMessages(reqFieldArr);
      return false;
    }
    if (reqFieldArr.length > 0) {
      props.setErrorMessages(reqFieldArr);
      return false;
    }
    return true;
  };

  const minorSave = () => {
    if (minorValidation()) {
      let tmpTableData = tableData;
      let data = {
        auditUserID: userDetails.loginUserName,
        auditTimeStamp: new Date(),
        addedAuditUserID: userDetails.loginUserName,
        addedAuditTimeStamp: new Date(),
        versionNo: 0,
        dbRecord: false,
        sortColumn: null,
        auditKeyList: [],
        auditKeyListFiltered: false,
        beginDate: formData.beginDate,
        endDate: formData.endDate,
        prevBegDate: null,
        prevEndDate: null,
        voidDt: null,
        voidDate:
          formData.void === "Yes"
            ? formData && formData.voidDate
              ? formData.voidDate
              : formatDate(new Date())
            : null,
        tempVoidDate: null,
        rateSourceCode:
          formData.rateSourceCode !== "-1" ? formData.rateSourceCode : null,
        noteSetVO: null,
        noteCount: 0,
        rateAmount: formData.rateAmount,
        ratePercent: formData.ratePercent
          ? formData.ratePercent
          : null,
        rateSourceDesc: formData.rateSourceDesc
          ? formData.rateSourceDesc
          : null,
        showVoids: false,
        showVoidRecord: true,
        rateASCGroupSK: formData.rateASCGroupSK
          ? formData.rateASCGroupSK
          : null,
        ratePCCategoryOfServiceSK: null,
        rateRCProviderTypeSK: null,
        providerID: null,
        providerTypeCode: null,
        lobCode: null,
        procedureCode: null,
        networkID: null,
        benifitPlanID: null,
        modifierCode1: null,
        modifierCode2: null,
        modifierCode3: null,
        modifierCode4: null,
        revenueCode: null,
        revenueTypeCode: null,
        regionCode: null,
      };

      formData.index > -1
        ? (tmpTableData[formData.index] = data)
        : tmpTableData.push(data);
      setTableData(tmpTableData);
      setSuccessMessages(["System successfully saved the Information."]);
      props.setTableData(tmpTableData);
      setShowForm(false);
    }
  };

  const handleMultiDelete = () => {
    muiconfirm({
      title: "",
      description: "Are you sure that you want to delete.",
      dialogProps: { fullWidth: false },
    }).then(() => {
      let t = tableData;
      let newArray = [];

      multiDelete.map((value) => {
        let curIndex = t.findIndex(
          (i) => i.beginDate === value.beginDate && i.endDate === value.endDate
        );
        if (t[curIndex].rateASCGroupSK) {
          newArray.push(t[curIndex]);
        }

        t.splice(curIndex, 1);
      });

      setTableData(t);
      props.setTableData(t);
      setShowForm(false);
      if (props.isEditOp) {
        props.setDeleteList([...props.deleteList, ...newArray]);
      }
      setSuccessMessages(["System successfully deleted the Information."]);
      setSuccess(false);
      props.setErrorMessages([]);
      setMultiDelete([]);
    });
  };

  const handleRowClick = (row) => {
    setShowForm(true);
    setSuccess(false);
    setFormData({ ...row, void: row.voidDate ? "Yes" : "No" });
    setResetFormData({ ...row, void: row.voidDate ? "Yes" : "No" });
    setSelectedBeginDate(row.beginDate);
    setSelectedEndDate(row.endDate);
    props.setErrorMessages([]);
    setFormErrors(false);
    setIsMinorEdit(true);
  };

  const handelVoidCheck = () => {
    const data = props.rateVOList;
    setTableData(
      voidRef.current.checked
        ? data
        : data.filter((a) => {
          return a.voidDate ? false : true;
        })
    );
    setShowForm(false);
  };

  const minorDelete = () => {
    muiconfirm({
      title: "",
      description: "Are you sure that you want to delete.",
      dialogProps: { fullWidth: false },
    }).then(() => {
      let t = tableData;
      let valueRemoved = t[formData.index];
      if (props.isEditOp && formData.rateASCGroupSK) {
        props.setDeleteList([...props.deleteList, valueRemoved]);
      }
      t.splice(formData.index, 1);
      setTableData(t);
      props.setTableData(t);
      setSuccess(false);
      setShowForm(false);
      props.setErrorMessages([]);
    });
  };

  const addMinorForm = () => {
    setTimeout(
      function () {
        scrollToRef(addProviderType);
      }.bind(this),
      1000
    );
    setShowForm(true);
    setSuccess(false);
    setFormData(defaultFormData);
    setSelectedEndDate("");
    setSelectedBeginDate("");
    setIsMinorEdit(false);
  };

  const minorCancel = () => {
    setShowForm(false);
    props.setErrorMessages([]);
    setSuccess(false);
    setFormErrors(false);
  };



  return (
    <>
      <div className="tab-body p-3">

        {errorMessages.length > 0 ? (
          <ErrorComponent
            errorMessages={errorMessages}
            setErrorMessages={seterrorMessages}
          />
        ) : null}

        {successMessages.length > 0 ? (
          <SuccessComponent
            successMessages={successMessages}
            setSuccessMessages={setSuccessMessages}
          />
        ) : null}

        <div className="tab-header pt-0">
          <h2 className="tab-heading float-left">ASC Group/ASC Region</h2>
          <div className="float-right th-btnGroup">
            <Button
              title="Delete"
              variant="outlined"
              data-test='test_del_btn'
              color="primary"
              disabled={multiDelete.length == 0}
              className="btn btn-transparent btn-icon-only"
              onClick={() => handleMultiDelete()}
            >
              <i className="fa fa-trash" />
            </Button>
            <Button
              title="Add ASC Group/ASC Region"
              color="primary"
              data-test='test_add_btn'
              className="btn btn-secondary btn-icon-only"
              onClick={addMinorForm}
            >
              <i className="fa fa-plus" />
            </Button>
          </div>
        </div>
        {props.isEditOp ? (
          <div className="mui-custom-form m-0">
            <div className="sub-radio m-0">
              <label className="MuiFormControlLabel-root inline-radio-label float-left">
                <Checkbox
                  type="checkbox"
                  value="void"
                  id="fcVoidId"
                  inputRef={voidRef}
                  onChange={handelVoidCheck}
                />
                <span className="MuiFormControlLabel-label">Show Voids</span>
              </label>
              <div className="clearfix" />
            </div>
          </div>
        ) : null}
        <div className="tab-holder pt-2">
          <AscGroupEditTableComponent
            tableData={tableData}
            dropdown={props.dropdowns}
            handleRowClick={handleRowClick}
            multiDelete={multiDelete}
            setMultiDelete={setMultiDelete}
            voidRef={voidRef}
          />
          {showForm ? (
            <>
              <div className="tab-header mt-3" ref={addProviderType}>
                <h2 className="tab-heading float-left">
                  {isMinorEdit ? "Edit " : "Add "}
                  Group Region
                </h2>
                <div className="float-right th-btnGroup">
                  <Button
                    title={
                      isMinorEdit ? "Update Group Region" : "Add Group Region"
                    }
                    disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                    color="primary"
                    className={
                      isMinorEdit ? "btn btn-ic btn-save" : "btn btn-ic btn-add"
                    }
                    onClick={minorSave}
                  >
                    {isMinorEdit ? "Update" : "Add"}
                  </Button>
                  <Button
                    title="Notes"
                    variant="outlined"
                    color="primary"
                    className="btn btn-ic btn-notes"
                  >
                    Notes
                    </Button>
                  {isMinorEdit ? (
                    <Button
                      title="Delete"
                      variant="outlined"
                      color="primary"
                      className="btn btn-ic btn-delete"
                      onClick={minorDelete}
                      disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                    >
                      Delete
                    </Button>
                  ) : null}
                  {formData.index > -1 ? (
                    <Button
                      title="Reset"
                      color="primary"
                      className="btn btn-ic btn-reset"
                      onClick={() => {

                        setFormData(resetformData);
                        setFormErrors(false);
                        props.setErrorMessages([]);
                        setSuccess(false);
                        setSelectedBeginDate(resetformData.beginDate);
                        setSelectedEndDate(resetformData.endDate);
                      }}
                      disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                    >
                      Reset
                    </Button>
                  ) : (
                      <Button
                        title="Reset"
                        color="primary"
                        className="btn btn-ic btn-reset"
                        onClick={() => {
                          setFormData({ ...defaultFormData, "index": formData.index });
                          setFormErrors(false);
                          props.setErrorMessages([]);
                          setSuccess(false);

                        }}
                        disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                      >
                        Reset
                      </Button>
                    )}
                  <Button
                    title="Cancel"
                    color="primary"
                    className="btn btn-cancel"
                    onClick={minorCancel}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
              <div className="tab-body-bordered mt-2">
                <form autoComplete="off">
                  <div className="form-wrapper">
                    {props.isEditOp && formData.index > -1 ? (
                      <div className="mui-custom-form input-md">
                        <label class="MuiFormLabel-root MuiInputLabel-shrink">
                          Void
                        </label>
                        <div className="sub-radio mt-0">
                          <RadioGroup
                            row
                            aria-label="eftactive"
                            name="HideInactiveProviders"
                            value={formData.void}
                            disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                            onChange={(event) => {
                              setFormData({
                                ...formData,
                                void: event.target.value,
                              });
                            }}
                          >
                            <FormControlLabel
                              value="Yes"
                              id="void-yes-asc-edit"
                              control={<Radio id="fcVoidYes" color="primary" />}
                              label="Yes"
                              disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                            />
                            <FormControlLabel
                              value="No"
                              id="void-no-asc-edit"
                              control={<Radio id="fcVoidNo" color="primary" />}
                              label="No"
                              disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                            />
                          </RadioGroup>
                        </div>
                      </div>
                    ) : null}
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          required
                          id="bgn-date-asc-edit"
                          data-test='test_begin_dt'
                          label="Begin Date"
                          format="MM/dd/yyyy"
                          InputLabelProps={{
                            shrink: true,
                          }}
                          placeholder="mm/dd/yyyy"
                          disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                          minDate={new Date("1964-01-01T13:00:00.000+0000")}
                          maxDate={new Date("9999-12-31T13:00:00.000+0000")}
                          value={selectedBeginDate ? selectedBeginDate : null}
                          onChange={handleBDateChange}
                          helperText={
                            beginDateErr
                              ? ErrorMsgConstants.BEGIN_DATE_ERROR
                              : beginDtGtEndDtErr
                                ? ErrorMsgConstants.Bgndt_GT_Enddt_Err
                                : overlapError
                                  ? ErrorMsgConstants.Overlaps_Btw_Detail_Rows_Dates
                                  : beginDateInvalidErr
                                    ? ErrorMsgConstants.Invalid_Begin_Date_Error
                                    : null
                          }
                          error={
                            beginDateErr ||
                            beginDateInvalidErr ||
                            beginDtGtEndDtErr ||
                            overlapError
                          }
                          KeyboardButtonProps={{
                            "aria-label": "change date",
                          }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>
                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      <div className="mui-custom-form input-md with-select">
                        <KeyboardDatePicker
                          required
                          id="end-date-asc-edit"
                          label="End Date"
                          data-test='test_end_dt'
                          format="MM/dd/yyyy"
                          disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                          InputLabelProps={{
                            shrink: true,
                          }}
                          minDate={new Date("1964-01-01T13:00:00.000+0000")}
                          maxDate={new Date("9999-12-31T13:00:00.000+0000")}
                          placeholder="mm/dd/yyyy"
                          value={selectedEndDate ? selectedEndDate : null}
                          onChange={handleEDateChange}
                          helperText={
                            endDateErr
                              ? ErrorMsgConstants.END_DATE_ERROR
                              : endDateInvalidErr
                                ? ErrorMsgConstants.Invalid_End_Date_Error
                                : null
                          }
                          error={endDateErr || endDateInvalidErr}
                          KeyboardButtonProps={{ "aria-label": "change date" }}
                        />
                      </div>
                    </MuiPickersUtilsProvider>
                    <div className="mui-custom-form input-md">
                      <TextField

                        id="amount-asc-edit"
                        label="Amount"
                        data-test='test_amt'
                        placeholder=""
                        type="text"
                        disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                        inputProps={{ maxLength: 10 }}
                        value={formData.rateAmount}
                        onChange={handleMinorchange("rateAmount")}
                        helperText={

                          amountFormatErr
                            ? ErrorMsgConstants.INVALID_DESCRIPTION
                            : amountInvalidErr
                              ? ErrorMsgConstants.RATE_AMT_DEC_ERR
                              : rateamountreqerr
                                ? AscGroupConstant.Asc_Region_Amount
                                : null
                        }
                        error={amountFormatErr || amountInvalidErr || rateamountreqerr}
                        InputLabelProps={{ shrink: true }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">$ </InputAdornment>
                          ),
                        }}
                      />


                    </div>

                    <div className="mui-custom-form input-md">

                      <TextField
                        id="percentage-asc-form-data"
                        label="Percentage"
                        data-test='test_percenatge'
                        placeholder=""
                        type="text"
                        disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                        inputProps={{ maxLength: 8 }}
                        value={formData.ratePercent}
                        onChange={handleMinorchange("ratePercent")}
                        helperText={
                          percentageFormatErr
                            ? ErrorMsgConstants.INVALID_DESCRIPTION
                            : percentageInvalidErr
                              ? ErrorMsgConstants.PER_AMT_DEC_ERR
                              : null
                        }
                        error={percentageInvalidErr || percentageFormatErr}
                        InputLabelProps={{ shrink: true }}
                        InputProps={{
                          startAdornment: (
                            <InputAdornment position="start">% </InputAdornment>
                          ),
                        }}
                      />
                    </div>

                    <div className="mui-custom-form with-select input-md">
                      <TextField
                        id="rate-source-asc-edit"
                        select
                        label="Rate Source"
                        disabled={isMinorEdit && tableData[formData.index]?.voidDate != null && "disabled"}
                        data-test='test_rate'
                        value={formData.rateSourceCode}
                        onChange={handleMinorchange("rateSourceCode")}
                        inputProps={{ maxLength: 2 }}
                        placeholder="Please Select One"
                        helperText={
                          duplicateErr
                            ? ErrorMsgConstants.DUB_RATE_SOURCE
                            : null
                        }
                        error={duplicateErr || null}
                        InputLabelProps={{ shrink: true }}
                      >
                        <MenuItem key="Please Select One" value="-1">
                          Please Select One{" "}
                        </MenuItem>
                        {props.dropdowns &&
                          props.dropdowns["R1#R_RATE_SRC_CD"] &&
                          props.dropdowns["R1#R_RATE_SRC_CD"].map(
                            (each) => (
                              <MenuItem key={each.code} value={each.code}>
                                {each.description}{" "}
                              </MenuItem>
                            )
                          )}
                      </TextField>
                    </div>

                  </div>
                </form>
              </div>
            </>
          ) : (
              ""
            )}
        </div>
      </div>
    </>
  );
};
export default withRouter(PCProviderTypeMinorForm);
