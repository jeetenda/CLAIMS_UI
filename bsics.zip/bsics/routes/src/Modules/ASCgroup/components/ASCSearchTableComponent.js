import React, { useEffect } from "react";
import { withRouter } from "react-router";
// eslint-disable-next-line no-unused-vars
import TableComponent from "../../../SharedModules/Table/Table";
import { useDispatch, useSelector } from "react-redux";
import { ascCodeDetailsAction } from "../actions";
import * as AscGroupConstant from "./AscGroupConstant";

const headCells = [
  {
    id: "ascGroupCodeDesc",
    numeric: false,
    disablePadding: true,
    label: "ASC Group",
    enableHyperLink: true,
    width: "25%",
    fontSize: 12,
  },
  {
    id: "ascRegionCodeDesc",
    numeric: false,
    disablePadding: false,
    label: "ASC Region",
    enableHyperLink: false,
    width: "25%",
    fontSize: 12,
  },
  {
    id: "lobCodeDesc",
    numeric: false,
    disablePadding: false,
    label: "LOB",
    enableHyperLink: false,
    width: "50%",
    fontSize: 12,
  },
];

function ASCSearchTableComponent(props) {
  const errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(true);

  const dispatch = useDispatch();
  const onSearchView = (searchvalues) => {
    dispatch(ascCodeDetailsAction(searchvalues));
  };
  const ascCodeDetails = useSelector(
    (state) => state.ascSearchData.ascCodeDetails
  );
  const ascCodeDetailsTime = useSelector(
    (state) => state.ascSearchData.ascCodeDetailsTime
  );

  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);

  useEffect(() => {
    if (ascCodeDetails != null && props.redirect) {
      props.setRedirect(false);
      props.setspinnerLoader(false);
      if (
        ascCodeDetails.errorCode === null ||
        ascCodeDetails.errorCode === undefined
      ) {
        props.history.push({
          pathname: "/ASCGroupDetails",
          state: { ascCodeDetails },
        });
      } else {
        errorMessagesArray.push(
          AscGroupConstant.ERROR_OCCURED_DURING_TRANSACTION
        );
        props.tableErrorFunction(errorMessagesArray);
      }
    }
  }, [ascCodeDetailsTime]);

  const editRow = (row) => (event) => {
    props.history.push({
      pathname: "/ASCGroupDetails",
    });
    onSearchView({
      ascGroupCode: row.ascGroupCode,
      ascRegionCode: row.ascRegionCode,
      lobCode: row.lobCode,
    });
    props.setspinnerLoader(true);
    props.setRedirect(true);
  };

  const tableComp = (
    <TableComponent
      headCells={headCells}
      tableData={props.tableData ? props.tableData : []}
      onTableRowClick={editRow}
      defaultSortColumn="ascGroupCodeDesc"
    />
  );
  return showTable ? tableComp : null;
}
export default withRouter(ASCSearchTableComponent);
