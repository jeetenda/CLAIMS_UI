export const ERROR_OCCURED_DURING_TRANSACTION =
  "There was an error processing the request. Please retry the transaction.";
export const NO_RECORDS_FOUND =
  "No records found for the search criteria entered.";

export const LOB_Error = "Line of business is required.";
export const Asc_Group_Req = "ASC Group is required.";
export const Asc_Region_Req = "ASC Region is required.";
export const Asc_Region_Amount = "Rate Amount or Percent is required, but not both.";
export const Asc_Amount_frmt = "Rate Amount can have only 7 characters before decimal and 2 characters after decimal.";
export const Asc_Per_frmt = "Rate Percentage can have only 5 characters before decimal and 2 characters after decimal.";
export const Bgndt_GT_Enddt_Err =
  "The begin date must be less than or equal to the end date.";
export const Invalid_Data =
  " Data entered is in the incorrect format.";

export const DUB_RATE_SOURCE = "A rate for the header criteria already exists. Duplicates rates are not allowed.";
export const Invalid_Begin_Date_Error =
  "Begin Date that was entered is invalid.";
export const Invalid_End_Date_Error =
  "The End Date that was entered is invalid.";
export const Begin_Date_Error = "Begin Date is required.";
export const End_Date_Error = "End Date is required.";

export const OneCI_Error =
  "At least one detail row is required.Please enter at least one detail row.";
export const Overlaps_Btw_Detail_Rows_Dates =
  "There cannot be overlaps between date spans across the detail rows.";

