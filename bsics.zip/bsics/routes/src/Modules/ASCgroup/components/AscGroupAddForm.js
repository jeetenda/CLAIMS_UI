import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";

import * as AscGroupConstant from "./AscGroupConstant";

export default function DRGCodeAddForm(props) {
  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        <div className="mui-custom-form with-select input-md">
          <TextField
            id="lob-id"
            select
            label="Line of Business"
            value={props.values.lobCodeDesc}
            onChange={props.handleChanges("lobCodeDesc")}
            helperText={
              props.errors.lobReqError ? AscGroupConstant.LOB_Error : null
            }
            error={props.errors.lobReqError ? AscGroupConstant.LOB_Error : null}
            InputLabelProps={{
              shrink: true,
              required: true,
            }}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns &&
              Object.keys(props.dropdowns).length > 0 &&
              props.dropdowns["Claims#R_LOB_CD"].length > 0 &&
              props.dropdowns["Claims#R_LOB_CD"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md">
          <TextField
            id="standard-select-asc-group"
            select
            label="ASC Group"
            value={props.values.ascGroupCodeDesc}
            onChange={props.handleChanges("ascGroupCodeDesc")}
            helperText={
              props.errors.groupReqErr ? AscGroupConstant.Asc_Group_Req : null
            }
            error={
              props.errors.groupReqErr ? AscGroupConstant.Asc_Group_Req : null
            }
            InputLabelProps={{
              shrink: true,
              required: true,
            }}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns &&
              Object.keys(props.dropdowns).length > 0 &&
              props.dropdowns["R1#R_ASC_GRP_CD"].length > 0 &&
              props.dropdowns["R1#R_ASC_GRP_CD"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>

        <div className="mui-custom-form with-select input-md">
          <TextField
            id="standard-select-asc-region"
            select
            label="ASC Region"
            value={props.values.ascRegionCodeDesc}
            onChange={props.handleChanges("ascRegionCodeDesc")}
            helperText={
              props.errors.regionReqErr ? AscGroupConstant.Asc_Region_Req : null
            }
            error={
              props.errors.regionReqErr ? AscGroupConstant.Asc_Region_Req : null
            }
            InputLabelProps={{
              shrink: true,
              required: true,
            }}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns &&
              Object.keys(props.dropdowns).length > 0 &&
              props.dropdowns["R1#R_RATE_ASC_RGN_CD"].length > 0 &&
              props.dropdowns["R1#R_RATE_ASC_RGN_CD"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>
      </div>
      <div className="clearfix" />
    </form>
  );
}
