import React, { useState, useEffect, useRef } from "react";
import { Button } from "react-bootstrap";
import { withRouter } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import * as AscGroupConstant from "./AscGroupConstant";

import {
  resetSearchascCode,
  ascCodeSearchAction,
  ascCodeDetailsAction

} from "../actions";
import Spinner from "../../../SharedModules/Spinner/Spinner";
import AscGroupSearchForm from "./AscGroupSearchForm";
import ASCSearchTableComponent from "./ASCSearchTableComponent";
import * as Dropdowns from "../../../SharedModules/Dropdowns/dropdowns";
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
// need to get drop down api
import { GET_APP_DROPDOWNS,GET_SYSTEMLIST_DROPDOWN } from "../../../SharedModules/Dropdowns/actions";
import ReactToPrint from "react-to-print";
import { setPrintLayout } from "../../../SharedModules/Dropdowns/actions";
import Footer from "../../../SharedModules/Layout/footer";
function ASCSearch(props) {
  let errorMessagesArray = [];
  const [showNoRecords, setShowNoRecords] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    lobCodeDesc: "Please Select One",
    ascGroupCodeDesc: "Please Select One",
    ascRegionCodeDesc: "Please Select One",
    lobCode: [],
    ascGroupCode: "",
    ascRegionCode: "",
  });
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [{ showAsclobError, showAscCodeError }, setShowError] = React.useState(
    false
  );
  const [showTable, setShowTable] = useState(false);
  const [redirect, setRedirect] = useState(false);

  const paylod = useSelector((state) => state.ascSearchData.payload);
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const onDropdownsSys = (values) => dispatch(GET_SYSTEMLIST_DROPDOWN(values));
  
  const searchDropdowns = useSelector(
    (state) => state.appDropDowns.appdropdowns
  );
  const syssearchDropdowns = useSelector(
    (state) => state.appDropDowns.sysdropdowns
  );

  const dispatch = useDispatch();
  const onReset = () => dispatch(resetSearchascCode());
  const onSearch = (searchvalues) => {
    return dispatch(ascCodeSearchAction(searchvalues));
  };
  const onSearchView = (searchvalues) =>
    dispatch(ascCodeDetailsAction(searchvalues));
  const drgCodeDetails = useSelector(
    (state) => state.ascSearchData.drgCodeDetails
  );
  const printRef = useRef();
  const printLayout = useSelector((state) => state.appDropDowns.printLayout);
  const tableErrorFunction = (error) => {
    seterrorMessages(error);
  };

  const handleChanges = (name) => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };

  // reset table
  const resetTable = () => {
    setShowNoRecords(false);
    seterrorMessages([]);
    setShowError({
      showAsclobError: false,
      showAscCodeError: false,
    });
    setValues({
      lobCodeDesc: "Please Select One",
      ascGroupCodeDesc: "Please Select One",
      ascRegionCodeDesc: "Please Select One",
      lobCode: "",
    });
    setShowTable(false);
    onReset();
  };

  // search function
  const searchCheck = () => {
    setShowTable(false);
    setspinnerLoader(false);
    errorMessagesArray = [];
    seterrorMessages([]);
    let showAsclobError;
    let showAscCodeError;

    if (values.lobCodeDesc == "" || values.lobCodeDesc == "Please Select One") {
      showAsclobError = true;
      errorMessagesArray.push(AscGroupConstant.LOB_Error);
    }

    if (errorMessagesArray.length == 0) {
      setShowTable(true);
      setspinnerLoader(true);
      let searchCriteria = {};

      if (
        !(
          values.lobCodeDesc === "Please Select One" &&
          values.ascGroupCodeDesc === "Please Select One" &&
          values.ascRegionCodeDesc === "Please Select One"
        )
      ) {
        searchCriteria = {
          lobCode:
            values.lobCodeDesc !== "Please Select One"
              ? [values.lobCodeDesc.split("-")[0]]
              : [""],
          ascGroupCode:
            values.ascGroupCodeDesc !== "Please Select One"
              ? values.ascGroupCodeDesc.split("-")[0]
              : "",
          ascRegionCode:
            values.ascRegionCodeDesc !== "Please Select One"
              ? values.ascRegionCodeDesc.split("-")[0]
              : "",
        };
      }

      onSearch(searchCriteria);
      setRedirect(true);
    } else {
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    setShowError({
      showAsclobError,
      showAscCodeError,
    });
  };

  const addDRGCode = () => {
    props.history.push({
      pathname: "/ASCGroupDetails",
    });
  };

  // on asc search page load
  useEffect(() => {
    onDropdownsSys({ "inputList": [Dropdowns.LOB] });
    onDropdowns([
      Dropdowns.REV_LOB,
      Dropdowns.R_ASC_GRP_CD_1,
      Dropdowns.R_RATE_ASC_RGN_CD,
    ]);
    
    
    onReset();
    if (paylod != null && paylod.data != null) {
      setShowTable(true);
      if (paylod.data == null) {
        setShowNoRecords(true);
      }
    }

    if (props.location.deleteCode) {
      errorMessagesArray.push('System successfully deleted the information.');
      seterrorMessages(errorMessagesArray);
    }
  }, []);

  //   // on asc page search data
  useEffect(() => {
    if (paylod != null && paylod.data != null) {
      setspinnerLoader(false);
    }
    // if (paylod && paylod.message != null) {
    //   setspinnerLoader(false);
    //   errorMessagesArray.push(
    //     AscGroupConstant.ERROR_OCCURED_DURING_TRANSACTION
    //   );
    //   seterrorMessages(errorMessagesArray);
    // }
    if (paylod != null && paylod.status == "No record exsits") {
      setspinnerLoader(false);
      setShowNoRecords(true);
    }

    if (paylod != null && paylod.status != "No record exsits" && paylod.data.searchResults.length == 1 && redirect) {
      const ascViewData = paylod.data.searchResults[0];


      onSearchView({
        lobCode: ascViewData.lobCode,
        ascGroupCode: ascViewData.ascGroupCode,
        ascRegionCode: ascViewData.ascRegionCode,
      });
      // setspinnerLoader(true);
    }
  }, [paylod]);


  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}
      {errorMessages.length > 0 ? (
        <div
          className="alert alert-danger custom-alert hide-on-print"
          role="alert"
        >
          {errorMessages.map((message) => (
            <li>{message}</li>
          ))}
        </div>
      ) : null}
      {errorMessages.length == 0 &&
        paylod &&
        paylod.data == null &&
        paylod.status == "No record exsits" ? (
          <div
            className="alert alert-danger custom-alert hide-on-print"
            role="alert"
          >
            <li>{AscGroupConstant.NO_RECORDS_FOUND}</li>
          </div>
        ) : null}
      <div className="mb-2">
        <BreadCrumbs
          parent="Rates"
          child1="ASC Group/ASC Region"
          path="ASCGroupASCRegionPlanID"
        />
      </div>
      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="tab-heading page-heading float-left">
            Search ASC Group/ASC Region
          </h1>
          <div className="float-right th-btnGroup">
            <Button
              title="Add ASC Group/ASC Region"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-add"
              onClick={() => addDRGCode()}
              disabled={
                props.privileges && !props.privileges.add ? "disabled" : ""
              }
            >
              Add
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) =>
                  setTimeout(() => resolve(), 100)
                );
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button
                  title="Print"
                  variant="outlined"
                  color="primary"
                  className="btn btn-primary btn-ic btn-print"
                >
                  Print
                </Button>
              )}
              content={() => printRef.current}
            />
            <Button
              title="Help"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-help"
            >
              Help
            </Button>
          </div>
          <div className="clearfix" />
        </div>
        <div className="tab-body mt-2 pb-3">
          <AscGroupSearchForm
            values={values}
            handleChanges={handleChanges}
            resetTable={resetTable}
            searchCheck={searchCheck}
            dropdowns={searchDropdowns}
           sysdropdowns={syssearchDropdowns}
            errors={{
              showAsclobError,
              showAscCodeError,
            }}
            privileges={props.privileges}
          />

          {showTable && paylod && paylod.data != null ? (
            <div className="tab-holder px-3 mt-3">
              <div className="fw-600 mb-2">Search Results</div>
              <div className={`${printLayout ? "hide-on-screen" : ""}`}>
                <ASCSearchTableComponent
                  print
                  tableData={paylod.data.searchResults}
                  tableErrorFunction={tableErrorFunction}
                  setspinnerLoader={setspinnerLoader}
                  setRedirect={setRedirect}
                  redirect={redirect}
                />
              </div>
            </div>
          ) : null}
          <Footer print />
        </div>
      </div>
    </div>
  );
}
export default withRouter(ASCSearch);
