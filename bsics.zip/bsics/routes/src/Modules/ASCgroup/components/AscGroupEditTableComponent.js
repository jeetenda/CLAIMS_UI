import React, { useEffect } from "react";
import { withRouter } from "react-router";

import TableComponent from "../../../SharedModules/Table/Table";

const headCells = [
  {
    id: "beginDate",
    numeric: false,
    disablePadding: true,
    label: "Begin Date",
    enableHyperLink: true,
    fontSize: 12,
    width: 110,
  },
  {
    id: "endDate",
    numeric: false,
    disablePadding: false,
    label: "End Date",
    enableHyperLink: false,
    fontSize: 12,
    width: 100,
  },
  {
    id: "rateAmount",
    numeric: false,
    disablePadding: false,
    label: "Amount",
    enableHyperLink: false,
    fontSize: 12,
    width: 110,
  },
  {
    id: "ratePercent",
    numeric: false,
    disablePadding: false,
    label: "Percent",
    enableHyperLink: false,
    fontSize: 12,
    width: 135,
  },
  {
    id: "rateSourceDesc",
    numeric: false,
    disablePadding: false,
    label: "Rate Source",
    enableHyperLink: false,
    fontSize: 12,
    width: 135,
  },
  {
    id: "voidDate",
    numeric: false,
    disablePadding: false,
    label: "Void Date",
    enableHyperLink: false,
    fontSize: 12,
    width: 110,
  },
];

function AscAddTableComponent(props) {
  const getTableData = (data) => {

    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        let rateSourceDesc =
          props.dropdown["R1#R_RATE_SRC_CD"] &&
          props.dropdown["R1#R_RATE_SRC_CD"].filter(
            (value) => value.code === each.rateSourceCode
          );

        each.voidDate = each.voidDate;
        each.index = index;
        each.rateSourceDesc =
          rateSourceDesc && rateSourceDesc.length > 0
            ? rateSourceDesc[0].description
            : "";
      });
      if (props.voidRef.current && props.voidRef.current.checked) {
        return tData;
      } else {
        return tData.filter((a) => {
          return a.voidDate ? false : true;
        });
      }
    } else {
      return [];
    }
  };

  const editRow = (row) => (event) => {
    props.handleRowClick(row, event);
  };

  return (
    <TableComponent
      headCells={headCells}
      tableData={getTableData(props.tableData)}
      onTableRowClick={editRow}
      defaultSortColumn="beginDate"
      selected={props.multiDelete}
      multiDelete
      setSelected={props.setMultiDelete}
    />
  );
}
export default withRouter(AscAddTableComponent);
