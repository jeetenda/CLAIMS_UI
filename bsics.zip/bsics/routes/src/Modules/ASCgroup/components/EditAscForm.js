import React, { useEffect } from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import DateFnsUtils from "@date-io/date-fns";
import dateFnsFormat from "date-fns/format";
import InputAdornment from "@material-ui/core/InputAdornment";
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker,
} from "@material-ui/pickers";
import * as AscGroupConstant from "./AscGroupConstant";
import Radio from "@material-ui/core/Radio";
import Checkbox from "@material-ui/core/Checkbox";
export default function EditDRGForm(props) {


  const [selectedEndDate, setSelectedEndDate] = React.useState(
    props.values.endDate == "" ? "" : new Date(props.values.endDate)
  );
  const [selectedBeginDate, setSelectedBeginDate] = React.useState(
    props.values.beginDate == "" ? "" : new Date(props.values.beginDate)
  );
  const [beginDatePress, setBeginDatePress] = React.useState(false);
  const [endDatePress, setEndDatePress] = React.useState(false);

  React.useEffect(() => {
    if (props.reset) {
      props.setReset(false);
    }
  }, [props.reset]);
  React.useEffect(() => {
    props.values.endDate !== ""
      ? setSelectedEndDate(props.values.endDate)
      : setSelectedEndDate("");
    props.values.beginDate !== ""
      ? setSelectedBeginDate(props.values.beginDate)
      : setSelectedBeginDate("");
  });

  const handleBeginDateChange = (date) => {
    setSelectedBeginDate(date);
    setBeginDatePress(false);
  };

  const handleBeginDateText = (beginDateText) => {
    setSelectedBeginDate(beginDateText.target.value);
    setBeginDatePress(true);
  };

  const handleEndDateChange = (date) => {
    setSelectedEndDate(date);
    setEndDatePress(false);
  };

  const handleEndDateText = (endDateText) => {
    setSelectedEndDate(endDateText.target.value);
    setEndDatePress(true);
  };

  const handleBDateChange = (date) => {
    setSelectedBeginDate(date);
    props.handleformCIDtChanges("beginDate", formatDate(date));
  };

  const handleEDateChange = (date) => {
    setSelectedEndDate(date);
    props.handleformCIDtChanges("endDate", formatDate(date));
  };

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  return (
    <form
      autoComplete="off"
      className={
        props.values.row && props.values.row.voidDate ? classes.disabledcls : ""
      }
    >
      <div className="form-wrapper">
        <div className="mui-custom-form input-md no-padd">
          <label className="MuiFormLabel-root MuiInputLabel-shrink">Void</label>
          <div className="sub-radio set-rd-pos ml-0">
            <Radio
              type="radio"
              value="true"
              id="void-yes-group-region"
              checked={props.values.voidFlag.toString() == "true"}
              disabled={props.values.voidFlag === true}
              onChange={props.handleChanges("voidFlag")}
            />
            <label for="voidYes" className="text-black pl-1">
              Yes
            </label>
            <Radio
              type="radio"
              value="false"
              id="void-no-group-region"
              checked={props.values.voidFlag.toString() == "false"}
              onChange={props.handleChanges("voidFlag")}
              disabled={props.values.voidFlag === true}
              className="ml-2"
            />
            <label for="voidNo" className="text-black pl-1">
              No
            </label>
          </div>
        </div>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="bgn-date-group-region"
              label="Begin Date"
              format="MM/dd/yyyy"
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
              minDate={new Date("1964-01-01T13:00:00.000+0000")}
              maxDate={new Date("9999-12-31T13:00:00.000+0000")}
              placeholder="mm/dd/yyyy"
              disabled={props.values.voidFlag === true}
              value={selectedBeginDate ? selectedBeginDate : null}
              onChange={handleBDateChange}
              onKeyUp={handleBeginDateText}
              helperText={
                props.errors.showBeginDateError
                  ? AscGroupConstant.Begin_Date_Error
                  : props.errors.beginDtInvalidErr
                    ? AscGroupConstant.Invalid_Begin_Date_Error
                    : null
              }
              error={
                props.errors.showBeginDateError
                  ? AscGroupConstant.Begin_Date_Error
                  : props.errors.beginDtInvalidErr
                    ? AscGroupConstant.Invalid_Begin_Date_Error
                    : null
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </div>
        </MuiPickersUtilsProvider>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="end-date-group-region"
              label="End Date"
              format="MM/dd/yyyy"
              maxDate={new Date("9999-12-31T13:00:00.000+0000")}
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
              placeholder="mm/dd/yyyy"
              value={selectedEndDate ? selectedEndDate : null}
              onChange={handleEDateChange ? handleEDateChange : null}
              onKeyUp={handleEndDateText}
              disabled={props.values.voidFlag === true}
              helperText={
                props.errors.showEndDateError
                  ? AscGroupConstant.End_Date_Error
                  : props.errors.endDtInvalidErr
                    ? AscGroupConstant.Invalid_End_Date_Error
                    : null
              }
              error={
                props.errors.showEndDateError
                  ? AscGroupConstant.End_Date_Error
                  : props.errors.endDtInvalidErr
                    ? AscGroupConstant.Invalid_End_Date_Error
                    : null
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </div>
        </MuiPickersUtilsProvider>
        <div className="mui-custom-form input-md">
          <TextField
            id="amount-group-region"
            label="Amount"
            value={props.values.rateAmount}
            inputProps={{ maxLength: 10 }}
            onChange={props.handleChanges("rateAmount")}
            placeholder=""
            helperText={
              props.errors.rateamountformaterr
                ? AscGroupConstant.Asc_Amount_frmt
                : null
            }
            error={
              props.errors.rateamountformaterr
                ? AscGroupConstant.Asc_Amount_frmt
                : null
            }
            InputLabelProps={{
              shrink: true,
            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  $
                </InputAdornment>
              ),
            }}
          />
        </div>
      </div>
      <div className="form-wrapper wrap-form-label-sm pt-0">
        <div className="mui-custom-form input-md">
          <TextField
            id="percent-group-region"
            label="Percentage"
            value={props.values.ratePercent}
            inputProps={{ maxLength: 8 }}
            onChange={props.handleChanges("ratePercent")}
            placeholder=""
            helperText={
              props.errors.ratepercentageformaterr
                ? AscGroupConstant.Asc_Per_frmt
                : null
            }
            error={
              props.errors.ratepercentageformaterr
                ? AscGroupConstant.Asc_Per_frmt
                : null
            }
            InputLabelProps={{
              shrink: true,
            }}
          />
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="rate-source-group-region"
            select
            label="Rate Source"
            value={props.values.rateSourceCode}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges("rateSourceCode")}
            placeholder="Please Select One"
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns &&
              Object.keys(props.dropdowns).length > 0 &&
              props.dropdowns["R1#R_RATE_SRC_CD"].length > 0 &&
              props.dropdowns["R1#R_RATE_SRC_CD"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>
      </div>
    </form>
  );
}
