import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import DateFnsUtils from "@date-io/date-fns";
import Radio from "@material-ui/core/Radio";
import dateFnsFormat from "date-fns/format";
import InputAdornment from "@material-ui/core/InputAdornment";

import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider,
  DatePicker,
} from "@material-ui/pickers";
import * as AscGroupConstant from "./AscGroupConstant";

export default function AddDRGForm(props) {
  const [selectedEndDate, setSelectedEndDate] = React.useState(
    new Date("12/31/9999")
  );
  const [selectedBeginDate, setSelectedBeginDate] = React.useState("");
  const [beginDatePress, setBeginDatePress] = React.useState(false);
  const [endDatePress, setEndDatePress] = React.useState(false);


  React.useEffect(() => {
    props.values.endDate !== ""
      ? setSelectedEndDate(props.values.endDate)
      : setSelectedEndDate("");
    props.values.beginDate !== ""
      ? setSelectedBeginDate(props.values.beginDate)
      : setSelectedBeginDate("");
  });

  const handleBeginDateChange = (date) => {
    setSelectedBeginDate(date);
    setBeginDatePress(false);
  };

  const handleBeginDateText = (beginDateText) => {
    setSelectedBeginDate(beginDateText.target.value);
    setBeginDatePress(true);
  };

  const handleEndDateText = (endDateText) => {
    setSelectedEndDate(endDateText.target.value);
    setEndDatePress(true);
  };

  const handleEndDateChange = (date) => {
    setSelectedEndDate(date);
    setEndDatePress(false);
  };

  const handleBDateChange = (date) => {
    setSelectedBeginDate(date);
    props.handleCIDtChanges("beginDate", formatDate(date));
  };

  const handleEDateChange = (date) => {
    setSelectedEndDate(date);
    props.handleCIDtChanges("endDate", formatDate(date));
  };

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };


  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="bgn-date-asc"
              data-test='bgn-date-asc'
              label="Begin Date"
              format="MM/dd/yyyy"
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
              minDate={new Date("1964-01-01T13:00:00.000+0000")}
              maxDate={new Date("9999-12-31T13:00:00.000+0000")}
              placeholder="mm/dd/yyyy"
              value={selectedBeginDate ? selectedBeginDate : null}
              onChange={handleBDateChange}
              helperText={
                props.errors.showBeginDateError
                  ? AscGroupConstant.Begin_Date_Error
                  : props.errors.beginDtInvalidErr
                    ? AscGroupConstant.Invalid_Begin_Date_Error
                    : props.errors.showCIBgdtGTEnddtErr
                      ? AscGroupConstant.Bgndt_GT_Enddt_Err
                      : props.errors.overlapError
                        ? AscGroupConstant.Overlaps_Btw_Detail_Rows_Dates
                        : null
              }
              error={
                props.errors.showBeginDateError
                  ? AscGroupConstant.Begin_Date_Error
                  : props.errors.beginDtInvalidErr
                    ? AscGroupConstant.Invalid_Begin_Date_Error
                    : props.errors.showCIBgdtGTEnddtErr
                      ? AscGroupConstant.Bgndt_GT_Enddt_Err
                      : props.errors.overlapError
                        ? AscGroupConstant.Overlaps_Btw_Detail_Rows_Dates
                        : null
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </div>
        </MuiPickersUtilsProvider>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
            <KeyboardDatePicker
              id="end-date-asc"
              data-test='end-date-asc'
              label="End Date"
              format="MM/dd/yyyy"
              maxDate={new Date("9999-12-31T13:00:00.000+0000")}
              InputLabelProps={{
                shrink: true,
                required: true,
              }}
              placeholder="mm/dd/yyyy"
              value={selectedEndDate ? selectedEndDate : null}
              onChange={handleEDateChange}
              onKeyUp={handleEndDateText}
              helperText={
                props.errors.showEndDateError
                  ? AscGroupConstant.End_Date_Error
                  : props.errors.endDtInvalidErr
                    ? AscGroupConstant.Invalid_End_Date_Error
                    : null
              }
              error={
                props.errors.showEndDateError
                  ? AscGroupConstant.End_Date_Error
                  : props.errors.endDtInvalidErr
                    ? AscGroupConstant.Invalid_End_Date_Error
                    : null
              }
              KeyboardButtonProps={{
                "aria-label": "change date",
              }}
            />
          </div>
        </MuiPickersUtilsProvider>
        <div className="mui-custom-form input-md">
          <TextField
            id="amount-asc"
            data-test='amount-asc'
            label="Amount"
            value={props.values.rateAmount}
            inputProps={{ maxLength: 10 }}
            onChange={props.handleChanges("rateAmount")}
            placeholder=""
            helperText={
              props.errors.rateamountreqerr
                ? AscGroupConstant.Asc_Region_Amount
                : props.errors.rateamountformaterr
                  ? AscGroupConstant.Asc_Amount_frmt
                  : props.errors.rateamountinvaliderr
                    ? AscGroupConstant.Invalid_Data
                    : null
            }
            error={
              props.errors.rateamountreqerr
                ? AscGroupConstant.Asc_Region_Amount
                : props.errors.rateamountformaterr
                  ? AscGroupConstant.Asc_Amount_frmt
                  : props.errors.rateamountinvaliderr
                    ? AscGroupConstant.Invalid_Data
                    : null
            }
            InputLabelProps={{
              shrink: true,

            }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">$</InputAdornment>
              ),
            }}
          />
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="percent-asc"
            data-test='percent-asc'
            label="Percentage"
            value={props.values.ratePercent}
            inputProps={{ maxLength: 8 }}
            onChange={props.handleChanges("ratePercent")}
            placeholder=""
            helperText={
              props.errors.ratepercentageformaterr
                ? AscGroupConstant.Asc_Per_frmt
                : props.errors.ratepercentageinvaliderr
                  ? AscGroupConstant.Invalid_Data
                  : null
            }
            error={
              props.errors.ratepercentageformaterr
                ? AscGroupConstant.Asc_Per_frmt
                : props.errors.ratepercentageinvaliderr
                  ? AscGroupConstant.Invalid_Data
                  : null
            }
            InputLabelProps={{
              shrink: true,

            }}
            InputProps={{
              endAdornment: <InputAdornment position="end"> % </InputAdornment>,
            }}
          />
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="rate-source-asc"
            data-test='rate-source-asc'
            select
            label="Rate Source"
            value={props.values.rateSourceDesc}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges("rateSourceDesc")}
            helperText={
              props.errors.duplicateErr
                ? AscGroupConstant.DUB_RATE_SOURCE
                : null
            }
            error={props.errors.duplicateErr
              ? AscGroupConstant.DUB_RATE_SOURCE
              : null}
            placeholder="Please Select One"
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns &&
              Object.keys(props.dropdowns).length > 0 &&
              props.dropdowns["R1#R_RATE_SRC_CD"].length > 0 &&
              props.dropdowns["R1#R_RATE_SRC_CD"].map((each) => (
                <MenuItem selected key={each.code} value={each.code}>
                  {each.description}
                </MenuItem>
              ))}
          </TextField>
        </div>
      </div>
    </form>
  );
}
