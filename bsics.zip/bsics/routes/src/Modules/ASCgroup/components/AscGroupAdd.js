import React, { useState, useEffect, useRef } from "react";
import { GET_APP_DROPDOWNS } from "../../../SharedModules/Dropdowns/actions";
import { Button } from "react-bootstrap";
import { withRouter } from "react-router";
import { useDispatch, useSelector } from "react-redux";
import * as AscGroupConstant from "./AscGroupConstant";
import { ascCodeDetailsAction } from "../actions";
import Spinner from "../../../SharedModules/Spinner/Spinner";
import AscGroupAddTableComponent from "./AscGroupAddTableComponent";
import AscGroupAddForm from "./AscGroupAddForm";
import AddAscForm from "./AddAscForm";
import { getLoginUserDetails } from "../../../SharedModules/utility/utilityFunction";
import Axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import * as Dropdowns from "../../../SharedModules/Dropdowns/dropdowns";
import NavigationPrompt from "react-router-navigation-prompt";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import dateFnsFormat from "date-fns/format";
import * as moment from "moment";
import "moment-range";
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import ReactToPrint from "react-to-print";
import { setPrintLayout } from "../../../SharedModules/Dropdowns/actions";
import Footer from "../../../SharedModules/Layout/footer";
import ErrorComponent from "../../../SharedModules/Errors/TimeOutErrorMsg";
import SuccessComponent from "../../../SharedModules/Errors/TimeOutSuccessMsg";

function AscGroupAdd(props) {
  let errorMessagesArray = [];
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    lobCodeDesc: "-1",
    ascGroupCodeDesc: "-1",
    ascRegionCodeDesc: "-1",
  });

  const [addCandIVAlue, setAddCandIVAlue] = React.useState({
    beginDate: "",
    endDate: "12/31/9999",
    rateAmount: "",
    ratePercent: "",
    rateSourceDesc: "-1",
  });
  const onSearchView = (searchvalues) =>
    dispatch(ascCodeDetailsAction(searchvalues));
  const [drgTableData, setDrgTableData] = React.useState([]);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [codeIndReset, setCodeIndReset] = useState({});
  const [codeIndType, setCodeIndType] = useState("Add");
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const [deleteCheck, setDeleteCheck] = useState("minorSave");
  const [
    {
      showCIBeginDateError,
      showCIEndDateError,
      beginCIDtInvalidErr,
      dateOverlapError,
      endCIDtInvalidErr,

    },
    setCIShowError,
  ] = React.useState(false);
  const [showIndicators, setShowIndicators] = useState(false);
  const [
    {
      regionReqErr,
      rateamountreqerr,
      overlapError,
      groupReqErr,
      lobReqError,
      showBeginDateError,
      showCIBgdtGTEnddtErr,
      showEndDateError,
      beginDtInvalidErr,
      endDtInvalidErr,
      rateamountformaterr,
      ratepercentageformaterr,
      rateamountinvaliderr,
      ratepercentageinvaliderr,
      duplicateErr
    },
    setShowError,
  ] = React.useState(false);

  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector((state) => state.appDropDowns.appdropdowns);
  const printRef = useRef();
  const printLayout = useSelector((state) => state.appDropDowns.printLayout);
  const [prompt, setPrompt] = useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);
  const [cancelType, setCancelType] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [deleteSuccessUpdate, setDeleteSuccessUpdate] = useState(null);
  let userDetails = getLoginUserDetails();

  // const addAscGroupRate = (dataObj) => dispatch(ascCodeCreateAction(dataObj));

  const handelPromptSet = (set) => {
    if (set) setPrompt(true);
  };

  const dispatch = useDispatch();
  const handleChanges = (name) => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };

  const handelAddChanges = (name) => (event) => {
    if (event.target.type === "checkbox") {
      setAddCandIVAlue({ ...addCandIVAlue, [name]: event.target.checked });
    } else {
      setAddCandIVAlue({ ...addCandIVAlue, [name]: event.target.value });
    }
  };

  const handleCIDtChanges = (name, date) => {
    setAddCandIVAlue({ ...addCandIVAlue, [name]: date });
  };

  const handleDCDtChange = (name, date) => {
    setValues({ ...values, [name]: date });
  };

  // const handelDateRngeOverlap = (
  //   initalStartDate,
  //   initialEndDate,
  //   secondaryStartDate,
  //   secondaryEndDate,
  //   initialGpeer,
  //   gPeers
  // ) => {
  //   const range1 = moment().range(
  //     new Date(initalStartDate),
  //     new Date(initialEndDate)
  //   );
  //   const range2 = moment().range(
  //     new Date(secondaryStartDate),
  //     new Date(secondaryEndDate)
  //   );
  //   if (range1.overlaps(range2)) {
  //     return initialGpeer === gPeers ? true : false;
  //   } else {
  //     return false;
  //   }
  //   //return range1.overlaps(range2);
  // };

  // const handelDateRngeArrayOverlap = (
  //   initalStartDate,
  //   initialEndDate,
  //   inputArray,
  //   initialGpeer
  // ) => {
  //   if (inputArray.length > 0) {
  //     const result = inputArray.map((each) =>
  //       handelDateRngeOverlap(
  //         initalStartDate,
  //         initialEndDate,
  //         each.beginDate,
  //         each.endDate,
  //         initialGpeer,
  //         each.peerGroup
  //       )
  //     );
  //     if (result.filter((e) => e === true).length > 0) {
  //       return true;
  //     } else {
  //       return false;
  //     }
  //   } else {
  //     return false;
  //   }
  // };

  const handelDateGaps = (
    initalStartDate,
    initialEndDate,
    secondaryStartDate,
    secondaryEndDate,
    peerGroup,
    secondaryPeerGroup,
    sortedInputArray
  ) => {
    let lastIndex = sortedInputArray.length - 1;
    // var lastEndDate = moment(new Date(secondaryEndDate));
    var lastEndDate = moment(new Date(sortedInputArray[lastIndex].endDate));
    var newBeginDate = moment(new Date(initalStartDate));
    var duration = moment.duration(newBeginDate.diff(lastEndDate));
    var days = duration.asDays();
    if (days > 1) {
      return true;
    } else {
      return false;
    }
  };

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return dt;
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  useEffect(() => {
    onDropdowns([
      Dropdowns.REV_LOB,
      Dropdowns.R_ASC_GRP_CD_1,
      Dropdowns.R_RATE_ASC_RGN_CD,
      Dropdowns.RATE_SRC_CD,
    ]);
    setValues({
      lobCodeDesc: "-1",
      ascGroupCodeDesc: "-1",
      ascRegionCodeDesc: "-1",
    });
  }, []);

  const scrollToRef = (ref) =>
    ref.current.scrollIntoView({ behavior: "smooth" });
  const addDRGformscroll = useRef(null);
  const adddrgScrolltoview = () => {
    setTimeout(
      function () {
        scrollToRef(addDRGformscroll);
      }.bind(this),
      1000
    );
  };

  const showEdit = () => {
    setShowIndicators(true);
    resetaddForm();

    adddrgScrolltoview();
  };

  const majorSave = () => {

    seterrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    drgTableData.length ? "" : reqFieldArr.push(AscGroupConstant.OneCI_Error);
    setShowError({
      groupReqErr:
        values.ascGroupCodeDesc !== "-1" && values.ascGroupCodeDesc
          ? false
          : (() => {
            reqFieldArr.push(AscGroupConstant.Asc_Group_Req);
            return true;
          })(),
      lobReqError:
        values.lobCodeDesc !== "-1" && values.lobCodeDesc
          ? false
          : (() => {
            reqFieldArr.push(AscGroupConstant.LOB_Error);
            return true;
          })(),
      regionReqErr:
        values.ascRegionCodeDesc !== "-1" && values.ascRegionCodeDesc
          ? false
          : (() => {
            reqFieldArr.push(AscGroupConstant.Asc_Region_Req);
            return true;
          })(),
    });
    if (reqFieldArr.length) {
      seterrorMessages(reqFieldArr);
      return false;
    }

    const data = {
      auditUserID: userDetails.loginUserName,
      auditTimeStamp: new Date(),
      addedAuditUserID: userDetails.loginUserName,
      addedAuditTimeStamp: new Date(),
      versionNo: 0,
      dbRecord: false,
      sortColumn: null,
      auditKeyList: [],
      auditKeyListFiltered: false,
      beginDate: null,
      endDate: null,
      prevBegDate: null,
      prevEndDate: null,
      voidDt: null,
      voidDate: null,
      tempVoidDate: null,
      rateSourceCode: null,
      noteSetVO: null,
      noteCount: 0,
      rateAmount: null,
      ratePercent: null,
      rateSourceDesc: null,
      showVoids: false,
      showVoidRecord: true,
      rateASCGroupSK: null,
      ratePCCategoryOfServiceSK: null,
      rateRCProviderTypeSK: null,
      providerID: null,
      providerTypeCode: null,
      lobCode: values.lobCodeDesc,
      procedureCode: null,
      networkID: null,
      benifitPlanID: null,
      modifierCode1: null,
      modifierCode2: null,
      modifierCode3: null,
      modifierCode4: null,
      revenueCode: null,
      revenueTypeCode: null,
      regionCode: null,
      ascGroupCode: values.ascGroupCodeDesc,
      lobDesc: null,
      ascRegionDesc: null,
      rateVOList: drgTableData,
      ascRegionCode: values.ascRegionCodeDesc,
      deletedRateObjectsList: [],
      ascGroupCodeDesc: null,
    };

    setspinnerLoader(true);
    Axios.post(`${serviceEndPoint.ASC_CODE_CREATE_ENDPOINT + "/" + userDetails.loginUserID}`, data)
      .then((res) => {
        setspinnerLoader(false);
        if (res.data.success === true) {

          setSuccessMessages(["Record added successfully!"]);

          onSearchView({
            ascGroupCode: values.ascGroupCodeDesc,
            ascRegionCode: values.ascRegionCodeDesc,
            lobCode: values.lobCodeDesc,
          });

        } else {
          if (
            res.data.message ===
            "Record already exists with input Asc Group Code, Asc Region Code and Lob Code "
          ) {
            seterrorMessages([
              "Record already exists with input Asc Group Code, Asc Region Code and Lob Code. ",
            ]);
          } else {
            seterrorMessages(["Record not added!"]);
          }
        }
      })
      .catch((e) => {
        setspinnerLoader(false);
        seterrorMessages([e.message]);
      });
    // addAscGroupRate(data);
  };
  const handelDateRngeOverlap = (initalStartDate, initialEndDate, secondaryStartDate, secondaryEndDate) => {
    const range1 = moment().range(new Date(initalStartDate), new Date(initialEndDate));
    const range2 = moment().range(new Date(secondaryStartDate), new Date(secondaryEndDate));
    return range1.overlaps(range2);
  }

  const handelDateRngeArrayOverlap = (initalStartDate, initialEndDate, inputArray) => {
    if (inputArray.length > 0) {
      const result = inputArray.map(each => handelDateRngeOverlap(initalStartDate, initialEndDate, each.beginDate, each.endDate))
      if (result.filter(e => e === true).length > 0) {
        return true
      } else {
        return false;
      }
    } else {
      return false
    }
  }
  const minorSave = () => {
    setSuccessMessages([]);
    seterrorMessages([]);
    let reqFieldArr = [];
    setCIShowError({});

    const checkDecimalValue = (maxAllowAmount, maxlen, dec) => {
      var regex = /^[0-9.]{1,15}$/;
      if (maxAllowAmount != null && maxAllowAmount != "") {
        if (regex.test(maxAllowAmount)) {
          var isDot = maxAllowAmount.indexOf(".");
          if (isDot <= -1) {
            if (maxAllowAmount.length > maxlen) {
              return "MaxAmountErr";
            }
          } else {
            var beforeDot = maxAllowAmount.split(".")[0];
            var afterDot = maxAllowAmount.split(".")[1];
            var afterDotCount = maxAllowAmount
              .split("")
              .filter((val) => val == ".");

            if (afterDot.length > dec || afterDotCount.length > 1) {
              return "IncorrectFormatErr";
            }
            if (beforeDot.length > maxlen) {
              return "IncorrectFormatErr";
            }
          }
        } else {

          return "FloatErr";
        }
      }
    };
    let test1 = JSON.parse(JSON.stringify(drgTableData));
    let overlapArray1;
    if (addCandIVAlue.index > -1) {
      overlapArray1 = test1.filter((e, index) => index != addCandIVAlue.index)
    } else {
      overlapArray1 = test1;
    }

    let overlapValidation = handelDateRngeArrayOverlap(formatDate(addCandIVAlue.beginDate), formatDate(addCandIVAlue.endDate), overlapArray1);

    if (overlapValidation) {
      setShowError({
        overlapError: true
      });
      reqFieldArr.push(AscGroupConstant.Overlaps_Btw_Detail_Rows_Dates);

    }
    if (reqFieldArr.length) {
      seterrorMessages(reqFieldArr);
      return false;
    }
    const duplicate = drgTableData.length > 0 && !(drgTableData.length == 1 && addCandIVAlue.index > -1) && drgTableData.filter((i, index) => {
      if (addCandIVAlue.index === undefined || (addCandIVAlue.index !== index)) {
        return (i.rateSourceDesc === addCandIVAlue.rateSourceDesc)
      }
    });
    if (duplicate && duplicate.length > 0) {
      setShowError({
        duplicateErr: true
      });
      reqFieldArr.push(AscGroupConstant.DUB_RATE_SOURCE)
    }
    if (reqFieldArr.length) {
      seterrorMessages(reqFieldArr);
      return false;
    }
    setShowError({

      rateamountreqerr
        : (addCandIVAlue.rateAmount == "" && addCandIVAlue.ratePercent == "") || (addCandIVAlue.rateAmount && addCandIVAlue.ratePercent)
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Asc_Region_Amount);
            return true;
          })()
          : false,
      showBeginDateError: addCandIVAlue.beginDate
        ? false
        : (() => {
          reqFieldArr.push(AscGroupConstant.Begin_Date_Error);
          return true;
        })(),

      showEndDateError: addCandIVAlue.endDate
        ? false
        : (() => {
          reqFieldArr.push(AscGroupConstant.End_Date_Error);
          return true;
        })(),
      beginDtInvalidErr:
        addCandIVAlue.beginDate.toString() == "Invalid Date" ||
          moment(addCandIVAlue.beginDate).isBefore("1964-01-01")
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Invalid_Begin_Date_Error);
            return true;
          })()
          : false,
      endDtInvalidErr:
        addCandIVAlue.endDate.toString() == "Invalid Date" ||
          moment(addCandIVAlue.endDate).isBefore("1964-01-01")
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Invalid_End_Date_Error);
            return true;
          })()
          : false,

      showCIBgdtGTEnddtErr: addCandIVAlue.beginDate && (new Date(addCandIVAlue.beginDate) >= new Date(addCandIVAlue.endDate)) ? (() => { reqFieldArr.push(AscGroupConstant.Bgndt_GT_Enddt_Err); return true; })() : false,

      rateamountformaterr:
        checkDecimalValue(addCandIVAlue.rateAmount, 7, 2) === "MaxAmountErr" ||
          checkDecimalValue(addCandIVAlue.rateAmount, 7, 2) ===
          "IncorrectFormatErr"
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Asc_Amount_frmt);
            return true;
          })()
          : false,
      rateamountinvaliderr:
        checkDecimalValue(addCandIVAlue.rateAmount, 7, 2) === "FloatErr"
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Invalid_Data);
            return true;
          })()
          : false,
      ratepercentageinvaliderr:
        checkDecimalValue(addCandIVAlue.ratePercent, 5, 2) === "FloatErr"
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Invalid_Data);
            return true;
          })()
          : false,


      ratepercentageformaterr:
        checkDecimalValue(addCandIVAlue.ratePercent, 5, 2) === "MaxAmountErr" ||
          checkDecimalValue(addCandIVAlue.ratePercent, 5, 2) ===
          "IncorrectFormatErr"
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Asc_Per_frmt);
            return true;
          })()
          : false,
    });
    if (reqFieldArr.length) {
      seterrorMessages(reqFieldArr);
      return false;
    }
    setCIShowError({
      beginCIDtInvalidErr:
        addCandIVAlue.beginDate.toString() == "Invalid Date"
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Invalid_Begin_Date_Error);
            return true;
          })()
          : false,
      endCIDtInvalidErr:
        addCandIVAlue.endDate.toString() == "Invalid Date"
          ? (() => {
            reqFieldArr.push(AscGroupConstant.Invalid_End_Date_Error);
            return true;
          })()
          : false,
    });
    if (reqFieldArr.length) {
      seterrorMessages(reqFieldArr);
      return false;
    }

    let test2 = JSON.parse(JSON.stringify(drgTableData));
    let overlapArray;
    if (codeIndType === "Edit") {
      overlapArray = test2.filter(
        (e) =>
          e.beginDate != formatDate(codeIndReset.beginDate) ||
          e.endDate != formatDate(codeIndReset.endDate)
      );
    } else {
      overlapArray = test2;
    }

    if (
      codeIndType === "Add" &&
      (new Date(addCandIVAlue.beginDate) < new Date() ||
        new Date(addCandIVAlue.endDate) < new Date())
    ) {
      let r = window.confirm(
        "This changes retroactive information. Are you sure you want to save?"
      );
      if (r === false) {
        return;
      }
    }

    const table = drgTableData;
    const timeStamp = new Date();
    const data = {
      auditUserID: userDetails.loginUserName,
      auditTimeStamp: new Date(),
      addedAuditUserID: userDetails.loginUserName,
      addedAuditTimeStamp: new Date(),
      versionNo: 0,
      dbRecord: false,
      sortColumn: null,
      auditKeyList: [],
      auditKeyListFiltered: false,
      beginDate: addCandIVAlue.beginDate,
      endDate: addCandIVAlue.endDate,
      prevBegDate: null,
      prevEndDate: null,
      voidDt: null,
      voidDate: null,
      tempVoidDate: null,
      rateSourceCode:
        addCandIVAlue.rateSourceDesc != -1
          ? addCandIVAlue.rateSourceDesc.split("-")[0]
          : null,
      noteSetVO: null,
      noteCount: 0,
      rateAmount: addCandIVAlue.rateAmount,
      ratePercent: addCandIVAlue.ratePercent,
      rateSourceDesc:
        addCandIVAlue.rateSourceDesc != -1
          ? addCandIVAlue.rateSourceDesc
          : null,
      showVoids: false,
      showVoidRecord: true,
      rateASCGroupSK: null,
      ratePCCategoryOfServiceSK: null,
      rateRCProviderTypeSK: null,
      providerID: null,
      providerTypeCode: null,
      lobCode: null,
      procedureCode: null,
      networkID: null,
      benifitPlanID: null,
      modifierCode1: null,
      modifierCode2: null,
      modifierCode3: null,
      modifierCode4: null,
      revenueCode: null,
      revenueTypeCode: null,
      regionCode: null,
    };
    addCandIVAlue.index > -1
      ? (table[addCandIVAlue.index] = data)
      : table.push(data);
    setDrgTableData(table);
    setSuccessMessages(["System successfully saved the Information."]);
    resetaddForm();
    setShowIndicators(false);
  };
  const resetaddForm = () => {
    setAddCandIVAlue({
      beginDate: codeIndReset.beginDate ? codeIndReset.beginDate : "",
      endDate: codeIndReset.endDate ? codeIndReset.endDate : "12/31/9999",
      rateAmount: codeIndReset.rateAmount ? codeIndReset.rateAmount : "",
      ratePercent: codeIndReset.ratePercent ? codeIndReset.ratePercent : "",
      rateSourceDesc: codeIndReset.rateSourceDesc ? codeIndReset.rateSourceDesc : "-1",
    });
    setShowError({
      groupReqErr: false,
      regionReqErr: false,
      showBeginDateError: false,
      showEndDateError: false,
      beginDtInvalidErr: false,
      endDtInvalidErr: false,
      rateamountformaterr: false,
      ratepercentageformaterr: false,
      rateamountreqerr: false,
      overlapError: false,
      showCIBgdtGTEnddtErr: false,
      rateamountinvaliderr: false,
      ratepercentageinvaliderr: false,
      duplicateErr: false,
    });
    seterrorMessages([]);
  };

  const multiDelete = () => {
    setDialogOpen(false);
    setDialogType("");
    seterrorMessages([]);
    setSuccessMessages([]);
    if (selectDeleteArray.length > 0) {
      let CI = drgTableData;
      selectDeleteArray.map((value, index) => {
        let curIndex = CI.findIndex((i) =>
          moment(i.beginDate).isSame(value.beginDate)
        );
        CI.splice(curIndex, 1);
      });
      setDrgTableData(CI);

      setSuccessMessages(["System successfully deleted the Information."]);
      setSelectDeleteArray([]);
    }
  };

  const searchDRGCode = () => {
    props.history.push({
      pathname: "/ASCGroupASCRegionPlanID",
    });
  };



  return (
    <div className="pos-relative">
      <NavigationPrompt
        when={(crntLocation, nextLocation) => {
          if (confirm) {
            return false;
          } else {
            handelPromptSet(nextLocation);
            return true;
          }
        }}
      // when={true}
      >
        {({ onConfirm, onCancel }) => (
          <Dialog
            open={prompt}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            className="custom-alert-box"
          >
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                {cancelType ? (
                  "Are you sure that you want to Cancel?"
                ) : (
                    <>
                      Unsaved changes will be lost. <br />
                    Are you sure you want to continue?
                  </>
                  )}
              </DialogContentText>
            </DialogContent>
            {cancelType ? (
              <DialogActions>
                <Button
                  title="Ok"
                  onClick={onConfirm}
                  color="primary"
                  className="btn btn-success"
                >
                  Ok
                </Button>
                <Button
                  title="Cancel"
                  onClick={() => {
                    setPrompt(false);
                    setCancelType(false);
                    onCancel();
                  }}
                  color="primary"
                  autoFocus
                >
                  Cancel
                </Button>
              </DialogActions>
            ) : (
                <DialogActions>
                  <Button
                    title="Stay on this page"
                    onClick={() => {
                      setPrompt(false);
                      setCancelType(false);
                      onCancel();
                    }}
                    color="primary"
                    className="btn btn-transparent"
                  >
                    STAY ON THIS PAGE!
                </Button>
                  <Button
                    title="Continue"
                    onClick={onConfirm}
                    color="primary"
                    className="btn btn-success"
                    autoFocus
                  >
                    CONTINUE <i className="fa fa-arrow-right ml-1"></i>
                  </Button>
                </DialogActions>
              )}
          </Dialog>
        )}
      </NavigationPrompt>
      {spinnerLoader ? <Spinner /> : null}

      {errorMessages.length > 0 ? (
        <ErrorComponent
          errorMessages={errorMessages}
          setErrorMessages={seterrorMessages}
        />
      ) : null}

      {successMessages.length > 0 ? (
        <SuccessComponent
          successMessages={successMessages}
          setSuccessMessages={setSuccessMessages}
        />
      ) : null}
      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to delete?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            title="Ok"
            onClick={() => {
              dialogType == "multiDelete" ? multiDelete() : null;
            }}
            color="primary"
            className="btn btn-success"
          >
            Ok
          </Button>
          <Button
            title="Cancel"
            onClick={() => {
              setDialogOpen(false);
              setDialogType("");
            }}
            color="primary"
            autoFocus
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      <div className="mb-2">
        <BreadCrumbs
          parent="Rates"
          child1="ASC Group/ASC Region"
          child2="Add ASC Group/ASC Region"
          path="ASCGroupASCRegionPlanID"
        />
      </div>
      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="page-heading float-left">ASC Group/ASC Region</h1>
          <div className="float-right th-btnGroup">
            <Button
              title="Save"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-save"
              onClick={() => majorSave()}
              disabled={
                props.privileges && !props.privileges.add ? "disabled" : ""
              }
            >
              Save
            </Button>

            <Button
              title="Notes"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-notes"
            >
              Notes
            </Button>

            <Button
              title="Cancel"
              variant="outlined"
              color="primary"
              className="btn btn-cancel"
              onClick={() => searchDRGCode()}
            >
              Cancel
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) =>
                  setTimeout(() => resolve(), 100)
                );
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button
                  title="Print"
                  variant="outlined"
                  color="primary"
                  className="btn btn-primary btn-ic btn-print"
                >
                  Print
                </Button>
              )}
              content={() => printRef.current}
            />
            <Button
              title="Help"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-help"
            >
              Help
            </Button>
          </div>
        </div>
        <div className="tab-body mt-3">
          <AscGroupAddForm
            values={values}
            handleChanges={handleChanges}
            handleDCDtChange={handleDCDtChange}
            dropdowns={addDropdowns}
            errors={{ lobReqError, groupReqErr, regionReqErr }}
          />

          <div className="tabs-container mt-3">
            <div className="tab-header px-3">
              <h3 className="tab-heading float-left">ASC Group/ASC Region</h3>
              <div className="float-right th-btnGroup">
                <Button
                  title="Delete ASC Group/ASC Region"
                  variant="outlined"
                  disabled={selectDeleteArray.length == 0}
                  color="primary"
                  className="btn btn-transparent btn-icon-only"
                  onClick={() => {
                    setDialogOpen(true);
                    setDialogType("multiDelete");
                  }}
                >
                  {" "}
                  <span className="hide-elm">Delete ASC Group/ASC Region</span>
                  <i className="fa fa-trash" />
                </Button>

                <Button
                  title="Add ASC Group/ASC Region"
                  variant="outlined"
                  color="primary"
                  className="btn btn-secondary btn-icon-only"
                  onClick={() => {
                    showEdit();
                    setCodeIndType("Add");
                    setCodeIndReset({ endDate: "12/31/9999" });
                  }}
                >
                  {" "}
                  <span className="hide-elm">Add ASC Group/ASC Region</span>
                  <i className="fa fa-plus" />
                </Button>
              </div>
            </div>
            <div className="tab-holder pl-3 pr-3 pb-3 pt-2 DRGtableEdit">
              <AscGroupAddTableComponent
                data-test='lob-id'
                tableData={drgTableData}
                dropdowns={addDropdowns}
                setFormEditCandI={setAddCandIVAlue}
                setCodeIndType={setCodeIndType}
                setCodeIndReset={setCodeIndReset}
                setEditCandI={showEdit}
                selectDeleteArray={selectDeleteArray}
                setSelectDeleteArray={setSelectDeleteArray}
                adddrgScrolltoview={adddrgScrolltoview}
              />
            </div>
            {showIndicators ? (
              <div className="tabs-container pb-2" ref={addDRGformscroll}>
                <div className="tab-header px-3">
                  <h3 className="tab-heading float-left">
                    {addCandIVAlue.index > -1 ? "Edit" : "Add"} ASC Group/ASC
                    Region
                  </h3>
                  <div className="float-right th-btnGroup">
                    <Button
                      title={addCandIVAlue.index > -1 ? "Update" : "Add"}
                      variant="outlined"
                      color="primary"
                      className={
                        addCandIVAlue.index > -1
                          ? "btn btn-ic btn-save"
                          : "btn btn-ic btn-add"
                      }
                      onClick={() => minorSave()}
                    >
                      {addCandIVAlue.index > -1 ? "Update" : "Add"}
                    </Button>
                    <Button
                      title="Notes"
                      variant="outlined"
                      color="primary"
                      className="btn btn-ic btn-notes"
                    >
                      Notes
                    </Button>
                    <Button
                      title="Reset"
                      variant="outlined"
                      color="primary"
                      className="btn btn-ic btn-reset"
                      onClick={() => resetaddForm()}
                    >
                      Reset
                    </Button>
                    <Button
                      title="Cancel"
                      variant="outlined"
                      color="primary"
                      className="btn btn-cancel"
                      onClick={() => setShowIndicators(false)}
                    >
                      Cancel
                    </Button>
                  </div>
                </div>
                <div className="tab-body-bordered m-3">
                  <AddAscForm
                    values={addCandIVAlue}

                    handleChanges={handelAddChanges}
                    handleCIDtChanges={handleCIDtChanges}
                    dropdowns={addDropdowns}
                    errors={{
                      showBeginDateError,
                      showEndDateError,
                      endDtInvalidErr,
                      beginDtInvalidErr,
                      rateamountformaterr,
                      ratepercentageformaterr,
                      rateamountreqerr,
                      showCIBgdtGTEnddtErr,
                      rateamountinvaliderr,
                      ratepercentageinvaliderr,
                      overlapError,
                      duplicateErr
                    }}
                  />
                </div>
              </div>
            ) : null}
          </div>
        </div>
        {/* <Footer print /> */}
      </div>
    </div>
  );
}
export default withRouter(AscGroupAdd);
