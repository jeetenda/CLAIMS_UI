import React, { useState, useEffect, useRef } from "react";
import ReactToPrint from "react-to-print";
import { useDispatch, useSelector } from "react-redux";
import { setPrintLayout } from "../../../SharedModules/Dropdowns/actions";
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import { Button } from "react-bootstrap";
import Axios from "axios";
import * as serviceEndPoint from "../../../SharedModules/services/service";
import * as Dropdowns from "../../../SharedModules/Dropdowns/dropdowns";
import { GET_APP_DROPDOWNS } from "../../../SharedModules/Dropdowns/actions";
import * as ErrorMsgConstants from "../../../SharedModules/Messages/ErrorMsgConstants";
import { getLoginUserDetails } from "../../../SharedModules/utility/utilityFunction";
import ErrorComponent from "../../../SharedModules/Errors/TimeOutErrorMsg";
import SuccessComponent from "../../../SharedModules/Errors/TimeOutSuccessMsg";
import Spinner from "../../../SharedModules/Spinner/Spinner";
import Footer from "../../../SharedModules/Layout/footer";
import Dialog from "@material-ui/core/Dialog";
import DialogActions from "@material-ui/core/DialogActions";
import DialogContent from "@material-ui/core/DialogContent";
import DialogContentText from "@material-ui/core/DialogContentText";
import { ascCodeDetailsAction, ascGroupUpdate } from "../actions";
import AddAscFormMinor from "./AddAscFormMinor";

const providerTypeEdit = (props) => {
  const printRef = useRef();
  const dispatch = useDispatch();
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector((state) => state.appDropDowns.appdropdowns);
  const onSearchView = (searchvalues) =>
    dispatch(ascCodeDetailsAction(searchvalues));
  const updateTypeService = (ID, dataObj) =>
    dispatch(ascGroupUpdate(ID, dataObj));
  // const deleteTypeService = (ID, dataObj) =>
  //   dispatch(providerTypeDelete(ID, dataObj));
  const providerTypeDetails = useSelector(
    (state) => state.ascSearchData.ascCodeDetails
  );
  const providerTypeDetailsTime = useSelector(
    (state) => state.ascSearchData.ascCodeDetailsTime
  );
  const [showAuditLog, setShowAuditLog] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState("");
  const updateServiceResp = useSelector(
    (state) => state.ascSearchData.updateData
  );
  const userDetails = getLoginUserDetails();
  const [values, setValues] = useState(
    providerTypeDetails && providerTypeDetails.data ? providerTypeDetails.data : ""
  );
  const [{ rateReqErr }, setShowError] = React.useState(false);
  const [errorMessages, setErrorMessages] = useState([]);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [rateVOList, setRateVOList] = useState([]);
  const [deleteList, setDeleteList] = React.useState([]);

  useEffect(() => {
    onDropdowns([Dropdowns.RATE_SRC_CD]);

    if (props.showSuccessMessage) {
      setSuccessMessages(["System successfully saved the Information."]);
      props.setShowSuccessMessage(false);
    }

  }, []);

  useEffect(() => {
    if (providerTypeDetails && providerTypeDetails.data) {

      setRateVOList(
        providerTypeDetails.data.rateVOList ? providerTypeDetails.data.rateVOList : []
      );
    }
  }, [providerTypeDetailsTime]);

  useEffect(() => {

    if (updateServiceResp) {
      setspinnerLoader(false);
      if (updateServiceResp.success) {
        serviceSuccessHandel();
      } else {
        setErrorMessages(["Record not added!"]);
      }
    }
  }, [updateServiceResp]);

  const serviceSuccessHandel = () => {
    setSuccessMessages(["System successfully saved the Information."]);
    const detailsData = {

      ascGroupCode: values.ascGroupCode,
      ascRegionCode: values.ascRegionCode,
      lobCode: values.lobCode,
    };
    onSearchView(detailsData);
  };

  const majorValidations = () => {
    setErrorMessages([]);
    setSuccessMessages([]);
    let reqFieldArr = [];
    setShowError({
      rateReqErr:
        rateVOList.length > 0
          ? false
          : (() => {
            reqFieldArr.push(ErrorMsgConstants.RATE_REQ_ERR);
            return true;
          })(),
    });

    if (reqFieldArr.length > 0) {
      setErrorMessages(reqFieldArr);
      return false;
    }
    return true;
  };

  const majorSave = () => {
    if (majorValidations()) {
      let data = {

        "auditUserID": userDetails.loginUserName,
        "auditTimeStamp": new Date(),
        "addedAuditUserID": userDetails.loginUserName,
        "addedAuditTimeStamp": new Date(),
        "dbRecord": false,
        "sortColumn": null,
        "auditKeyList": [],
        "auditKeyListFiltered": false,
        "beginDate": null,
        "endDate": null,
        "prevBegDate": null,
        "prevEndDate": null,
        "voidDt": null,
        "voidDate": null,
        "tempVoidDate": null,
        "rateSourceCode": null,
        "noteSetVO": null,
        "noteCount": 0,
        "rateAmount": null,
        "ratePercent": null,
        "rateSourceDesc": null,
        "showVoids": false,
        "showVoidRecord": true,
        "rateASCGroupSK": null,
        "ratePCCategoryOfServiceSK": null,
        "rateRCProviderTypeSK": null,
        "providerID": null,
        "providerTypeCode": null,
        "lobCode": values.lobCode ? values.lobCode : null,
        "procedureCode": null,
        "networkID": null,
        "benifitPlanID": null,
        "modifierCode1": null,
        "modifierCode2": null,
        "modifierCode3": null,
        "modifierCode4": null,
        "revenueCode": null,
        "revenueTypeCode": null,
        "regionCode": null,
        "ascGroupCode": values.ascGroupCode ? values.ascGroupCode : null,
        "lobDesc": values.lobDesc ? values.lobDesc : null,
        "ascRegionDesc": values.ascRegionDesc ? values.ascRegionDesc : null,
        "rateVOList": rateVOList,
        "ascRegionCode": values.ascRegionCode ? values.ascRegionCode : null,
        "deletedRateObjectsList": deleteList.length > 0 ? deleteList : [],
        "ascGroupCodeDesc": values.ascGroupCodeDesc ? values.ascGroupCodeDesc : null

      };
      setspinnerLoader(true);
      updateTypeService(userDetails.loginUserID, data);
    }
  };

  const cancelAddProviderType = () => {
    props.setCancelType(true);
    props.history.push({
      pathname: "/ASCGroupASCRegionPlanID",
    });
  };

  useEffect(() => {
    if (props.deleteSuccessUpdate) {
      props.history.push({
        pathname: "/ASCGroupASCRegionPlanID",
        deleteCode: true,
      });
    }
  }, [props.deleteSuccessUpdate]);

  const deleteCode = () => {
    setErrorMessages([]);
    setSuccessMessages([]);

    setspinnerLoader(true);
    console.log("values ", values);
    Axios.post(

      `${serviceEndPoint.ASC_CODE_DELETE_ENDPOINT + "/" + userDetails.loginUserID}`,
      values
    )
      .then(res => {
        setspinnerLoader(false);

        if (values) {

          props.setConfirm(true);
          props.setDeleteSuccessUpdate(new Date());
          setSuccessMessages([ErrorMsgConstants.BENIFIT_PLAN_DELETE_SUCCESS]);
        } else {

          setErrorMessages([ErrorMsgConstants.DELETE_FAIL_MSG]);
        }
      })
      .catch((e) => {
        setspinnerLoader(false);


        setErrorMessages([ErrorMsgConstants.ERROR_OCCURED_DURING_TRANSACTION]);
      });

    setDialogOpen(false);
    setDialogType("");
  };


  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}
      {errorMessages.length > 0 ? (
        <ErrorComponent
          errorMessages={errorMessages}
          setErrorMessages={setErrorMessages}
        />
      ) : null}
      {successMessages.length > 0 ? (
        <SuccessComponent
          successMessages={successMessages}
          setSuccessMessages={setSuccessMessages}
        />
      ) : null}

      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to delete?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              deleteCode();
            }}
            color="primary"
            className="btn btn-success"
          >
            Ok
          </Button>
          <Button
            onClick={() => {
              setDialogOpen(false);
              setDialogType("");
            }}
            color="primary"
            autoFocus
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>

      <div className="mb-2">
        <BreadCrumbs
          parent="Rates"
          child1="ASC Group/ASC Region"
          child2="Edit ASC Group/ASC Region"
          path="ASCGroupASCRegionPlanID"
        />
      </div>
      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="page-heading float-left">ASC Group/ASC Region</h1>
          <div className="float-right th-btnGroup">
            <Button
              title="Save"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-save"
              onClick={() => majorSave()}
            >
              Save
            </Button>
            <Button
              title="Delete"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-delete"
              disabled={
                props.privileges && !props.privileges.update ? "disabled" : ""
              }
              onClick={() => {
                setDialogOpen(true);
                setDialogType("majorDelete");
              }}
            >
              Delete
            </Button>
            <Button
              title="Audit Log"
              variant="outlined"
              color="primary"
              className={
                showAuditLog
                  ? "btn btn-ic btn-audit selected"
                  : "btn btn-ic btn-audit"
              }
            // onClick={() => {
            //     onAuditLog(!showAuditLog,true); setShowAuditLog(!showAuditLog);

            // }}
            >
              Audit Log
            </Button>
            <Button
              title="Notes"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-notes"
            >
              Notes
            </Button>
            <Button
              title="Cancel"
              variant="outlined"
              color="primary"
              className="btn btn-cancel"
              onClick={() => cancelAddProviderType()}
            >
              Cancel
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) =>
                  setTimeout(() => resolve(), 100)
                );
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button
                  title="Print"
                  variant="outlined"
                  color="primary"
                  className="btn btn-ic btn-print"
                >
                  Print
                </Button>
              )}
              content={() => printRef.current}
            />
            <Button
              title="Help"
              variant="outlined"
              color="primary"
              className="btn btn-ic btn-help"
            >
              Help
            </Button>
          </div>
        </div>
        <div className="tab-body mt-2 pb-2">
          <div className="flex-block columns-data pt-3 m-3">
            <div className="md-block-3cols mb-3">
              <span className="inline-title text-left">Line of Business</span>
              <div className="fw-600 primary-text py-1 pr-2">
                {values.lobDesc}
              </div>
            </div>
            <div className="md-block-3cols mb-3">
              <span className="inline-title text-left">ASC Group</span>
              <div className="fw-600 primary-text py-1 pr-2">
                {values.ascGroupCodeDesc}
              </div>
            </div>
            <div className="md-block-3cols mb-3">
              <span className="inline-title text-left">ASC Region</span>
              <div className="fw-600 primary-text py-1 pr-2">
                {values.ascRegionDesc}
              </div>
            </div>
          </div>
          <div className="tabs-container">
            <div className="tab-holder pt-1">
              <AddAscFormMinor
                rateVOList={rateVOList}
                dropdowns={addDropdowns}
                setTableData={setRateVOList}
                setErrorMessages={setErrorMessages}
                isEditOp={true}
                deleteList={deleteList}
                setDeleteList={setDeleteList}
              />
            </div>
          </div>

        </div>
        <div className="clearfix" />


        <Footer print></Footer>
      </div>
    </div>
  );
};

export default providerTypeEdit;
