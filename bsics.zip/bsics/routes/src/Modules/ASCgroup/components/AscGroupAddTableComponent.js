import React, { useEffect } from "react";
import { withRouter } from "react-router";

import TableComponent from "../../../SharedModules/Table/Table";

const headCells = [
  {
    id: "beginDate",
    numeric: false,
    disablePadding: true,
    label: "Begin Date",
    enableHyperLink: true,
    fontSize: 12,
    width: 110,
  },
  {
    id: "endDate",
    numeric: false,
    disablePadding: false,
    label: "End Date",
    enableHyperLink: false,
    fontSize: 12,
    width: 100,
  },
  {
    id: "rateAmount",
    numeric: false,
    disablePadding: false,
    label: "Amount",
    enableHyperLink: false,
    fontSize: 12,
    width: 110,
  },
  {
    id: "ratePercent",
    numeric: false,
    disablePadding: false,
    label: "Percent",
    enableHyperLink: false,
    fontSize: 12,
    width: 135,
  },
  {
    id: "rateSourceDesc",
    numeric: false,
    disablePadding: false,
    label: "Rate Source",
    enableHyperLink: false,
    fontSize: 12,
    width: 135,
  },
];

function AscAddTableComponent(props) {
  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {
        each.index = index;
        each.displayDetailForLOB = each.displayDetailForLOB;
        each.lob = each.lob;

        let sourceDesc =
          props.dropdowns["R1#R_RATE_SRC_CD"] &&
          props.dropdowns["R1#R_RATE_SRC_CD"].filter(
            (value) => value.code === each.rateSourceCode
          );
        each.rateSourceDesc =
          sourceDesc && sourceDesc.length > 0
            ? sourceDesc[0].description
            : each.rateSourceDesc;
        each.amountDollar = each.rateAmount ? "$ " + each.rateAmount : "";
        each.voidDate = each.voidDate;
        each.index = index;
      });
      return tData;
    } else {
      return [];
    }
  };

  const editRow = (row) => (event) => {
    props.adddrgScrolltoview();
    props.setEditCandI(true);
    props.setCodeIndType("Edit");
    props.setFormEditCandI({
      index: row.index,
      beginDate: row.beginDate,
      endDate: row.endDate,
      rateAmount: row.rateAmount,
      ratePercent: row.ratePercent,
      rateSourceDesc: row.rateSourceDesc ? row.rateSourceDesc : "-1",
    });

    props.setCodeIndReset({
      index: row.index,
      beginDate: row.beginDate,
      endDate: row.endDate,
      rateAmount: row.rateAmount,
      ratePercent: row.ratePercent,
      rateSourceDesc: row.rateSourceDesc ? row.rateSourceDesc : "-1",

    });
  };

  return (
    <TableComponent
      headCells={headCells}
      selected={props.selectDeleteArray}
      setSelected={props.setSelectDeleteArray}
      multiDelete
      tableData={getTableData(props.tableData)}
      onTableRowClick={editRow}
      defaultSortColumn="beginDate"
    />
  );
}
export default withRouter(AscAddTableComponent);
