/* eslint-disable arrow-parens */
import axios from "axios";
import * as actionTypes from "./actionTypes";
import * as serviceEndPoint from "../../SharedModules/services/service";

export const resetSearchascCode = () => ({
  type: actionTypes.RESETDATA,
  resetData: [],
});

export const dispatchascCodeSearch = (response) => ({
  type: actionTypes.ASC_CODE_SEARCH_TYPE,
  ascSearchData: response,
});

export const dispatchDropdowns = (response) => ({
  type: actionTypes.ASC_CODE_DROPDOWNS,
  dropdowns: response,
});
export const dispatchascCodeViewDetails = (response) => ({
  type: actionTypes.ASC_CODE_VIEW_DETAILS_TYPE,
  ascSearchData: response,
});

export const dispatchascCodeCreate = (response) => ({
  type: actionTypes.ASC_CODE_CREATE,
  ascCreateData: response,
});

export const dispatchascCodeUpdate = (response) => ({
  type: actionTypes.ASC_CODE_UPDATE,
  ascUpdateData: response,
});

export const dispatchDeleteascCode = (response) => ({
  type: actionTypes.ASC_CODE_DELETE,
  deleteStatus: response,
});

export const ascCodeDropdowns = (values) => (dispatch) => {
  return axios
    .post(`${serviceEndPoint.GET_APP_DROPDOWN_ENDPOINT}`, values)
    .then((response) => {
      if (Object.keys(response.data).length > 0) {
        dispatch(dispatchDropdowns(response.data));
      }
    });
};

export const ascCodeSearchAction = (values) => (dispatch) => {
  return axios
    .post(`${serviceEndPoint.ASC_CODE_SEARCH_ENDPOINT}`, values)
    .then((response) => {
      dispatch(dispatchascCodeSearch(response.data));
    })
    .catch((error) => {
      dispatch(dispatchascCodeSearch(error.response));
    });
};

export const ascCodeDetailsAction = (values) => (dispatch) => {
  return axios
    .get(
      serviceEndPoint.ASC_CODE_DETAILS_ENDPOINT +
      "/" +
      values.ascGroupCode +
      "/" +
      values.ascRegionCode +
      "/" +
      values.lobCode
    )
    .then((response) => {
      dispatch(dispatchascCodeViewDetails(response.data));
    })
    .catch((error) => {
      dispatch(dispatchascCodeViewDetails(error.data));
    });
};

export const ascGroupUpdate = (userID, values) => (dispatch) => {
  const body = values;
  return axios
    .post(`${serviceEndPoint.ASC_CODE_UPDATE_ENDPOINT + "/" + userID}`, body)
    .then((response) => {
      dispatch(dispatchascCodeUpdate(response.data));
    })
    .catch((error) => {
      dispatch(dispatchascCodeUpdate(error.data));
    });
};

export const ascGroupCreate = (userID, values) => dispatch => {
  const body = values;
  return axios.post(`${serviceEndPoint.ASC_CODE_CREATE_ENDPOINT + "/" + userID}`, body)
    .then(response => {
      dispatch(dispatchascCodeCreate(response.data));
    })
    .catch(error => {
      dispatch(dispatchascCodeCreate(error.response));
    });
}

export const ascCodeDeleteAction = (values) => (dispatch) => {
  return axios
    .post(`${serviceEndPoint.ASC_CODE_DELETE_ENDPOINT}`, values)
    .then((response) => {
      if (response.status === 200 && !(response.data.status === 500)) {
        dispatch(dispatchDeleteascCode(true));
      } else {
        dispatch(dispatchDeleteascCode(false));
      }
    })
    .catch((error) => {
      dispatch(dispatchDeleteascCode(error.data));
    });
};
