import * as actionTypes from "./actionTypes";

const axiosPayLoad = {
  payload: null,
  searchFields: null,
  ascGroupDetails: null,
  type: "Add",
  auditLog: {},
  pageLevelAuditLog: null,
  codeIndiAuditLog: null,
  updateData: null,
  createData: null,
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.RESETDATA:
      return axiosPayLoad;
    case actionTypes.ASC_CODE_DROPDOWNS:
      return { ...state, dropdowns: action.dropdowns };
    case actionTypes.ASC_CODE_SEARCH_TYPE:
      return { ...state, payload: action.ascSearchData };
    case actionTypes.ASC_CODE_DELETE:
      return {
        ...state,
        deleteStatus: action.deleteStatus,
        deleteStatusTime: new Date(),
      };
    // case actionTypes.ASC_CODE_CREATE:
    //   return { ...state, createData: action.providerTypeCreateData };
    case actionTypes.ASC_CODE_UPDATE:
      return {
        ...state,
        updateData: action.ascUpdateData,
      };

    case actionTypes.ASC_CODE_VIEW_DETAILS_TYPE:
      return {
        ...state,
        ascCodeDetails: action.ascSearchData,
        ascCodeDetailsTime: new Date(),
        type: "Edit"
      };
    default:
      return state;
  }
};

export default reducer;
