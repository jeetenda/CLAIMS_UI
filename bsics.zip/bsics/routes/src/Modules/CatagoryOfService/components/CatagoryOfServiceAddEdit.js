import React, { useState, useEffect } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import * as DiagnosisCodeConstants from './DiagnosisCodeConstants';
import { resetSearchDiagnosisCode, diagnosisCodeSearchAction } from '../actions';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import CatagoryOfServiceAddEditForm from './CatagoryOfServiceAddEditForm';
import CatagoryOfServiceAddEditTableComponent from './CatagoryOfServiceAddEditTableComponent';
// import EditCodeAndIndicatorsForm from './EditCodeAndIndicatorsForm';
import AuditLog from '../../../SharedModules/AuditLog/AuditLog';

function CatagoryOfServiceAddEdit(props) {
  let errorMessagesArray = [];
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    icd_verion: 'Please Select One',
    diagnosisCode: null,
    shortDescription: null,
    longDescription: null,
    startDate: null,
    endDate: null
  });
  const [codesAndIndTableData, setCodesAndIndTableData] = React.useState([])
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [{ showDiagnosisError, showdiagnosisCodeError, showdescriptionError },
    setShowError] = React.useState(false);
  const [showTable, setShowTable] = useState(false);


  const dispatch = useDispatch();

  // values change function
  const handleChanges = name => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };
  const handleDefaultChange = (event) => {
    // if (showVoid) {
    //   setShowVoid(false);
    // } else {
    //   setShowVoid(true);
    // }
  };

  useEffect(() => {
    setValues({
      icd_verion: 'ICD-9',
      diagnosisCode: '000.1',
      shortDescription: 'short description',
      longDescription: 'long description',
      startDate: '1/15/2020',
      endDate: '1/15/2020'
    });
    setCodesAndIndTableData([{
      beginDate: '01/01/2020',
      endDate: '01/01/2021',
      pendControl: 'N - No Control',
      familyPlanning: 'o-NotFlmPlng',
      gender: 'M',
      voidDate: ''
    }])
  }, [])


  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}
      { errorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert" role="alert">
          {errorMessages.map(message => <li>{message}</li>)
        }
        </div>
      ) : null
     }
      <div className="tabs-container">
        <div className="tab-header">
          <h1 className="tab-heading float-left">
             Diagnosis Code
          </h1>
          <div className="float-right mr-2">
            <Button variant="outlined" color="primary" className="btn btn-primary ml-1 mt-2">
              Print
            </Button>
            <Button variant="outlined" color="primary" className="btn btn-primary ml-1 mt-2">
              Help
            </Button>
          </div>
          <div className="clearfix" />
        </div>
        <DiagnosisCodeEditForm values={values} handleChanges={handleChanges} />

            <div className="tab-holder">
              <DiagnosisCodeEditTableComponent
                tableData={codesAndIndTableData}
              />

            </div>

      </div>
      <div className="tabs-container">
        <div className="tab-header">
          <h1 className="tab-heading float-left">
             Edit Codes &amp; Indicators
          </h1>
          <div className="float-right mr-2">
          <Button variant="outlined" color="primary" className="btn btn-primary ml-1 mt-2">
              Save
            </Button>
            <Button variant="outlined" color="primary" className="btn btn-primary ml-1 mt-2">
              Delete
            </Button>
            <Button variant="outlined" color="primary" className="btn btn-primary ml-1 mt-2">
              Reset
            </Button>
            <Button variant="outlined" color="primary" className="btn btn-primary ml-1 mt-2">
              Cancel
            </Button>
          </div>
          <div className="clearfix" />
        </div>
        {/* <EditCodeAndIndicatorsForm values={values} handleChanges={handleChanges} /> */}
      </div>
   
     <AuditLog auditLogData={[]}></AuditLog>
    </div>
  );
}
export default withRouter(DiagnosisCodeEdit);
