import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
import TableComponent from '../../../SharedModules/Table/Table';

const headCells = [
  {
    id: 'dataElementCriteria', numeric: false, disablePadding: true, label: 'Data Element Criteria', enableHyperLink: true, fontSize: 12
  },
  {
    id: 'beginValueData', numeric: false, disablePadding: false, label: 'Begin Value', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'endValueData', numeric: false, disablePadding: false, label: 'End Value', enableHyperLink: false, fontSize: 12
  }
];

function AdditionalCriteriaTable(props) {
  const [showTable, setShowTable] = React.useState(true);
  
  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);

  const editRow = row => (event) => {
    if(props.showAuditLog && props.getAuditData){
      props.getAuditData(row.cosAsgnSeqNumber);
    }
    props.setAdditionalCriteriaShow(true);
    props.setAdditionalEditorAddType('edit');
  
    props.setAdditionalCritiriaResetData({row:row, index:row.index, timeStamp: row.timeStamp, dataElementCriteria: row.dataElementCriteria, providerIdType: row.providerIdType, range: row.range, beginValueData: row.beginValueData, endValueData: row.endValueData,cosAsgnSeqNumber: row.cosAsgnSeqNumber, valueData:row.beginValueData});
    if(row.range==='Value'){
      props.setAdditionalCritiriaFormData({row:row, index:row.index, version:row.version, timeStamp: row.timeStamp, dataElementCriteria: row.dataElementCriteria, providerIdType: row.providerIdType, range: row.range, beginValueData: "", endValueData: row.endValueData, valueData:row.beginValueData,cosAsgnSeqNumber: row.cosAsgnSeqNumber});
    }else{
      props.setAdditionalCritiriaFormData({ row:row, index:row.index, version:row.version, timeStamp: row.timeStamp, dataElementCriteria: row.dataElementCriteria, providerIdType: row.providerIdType, range: row.range, beginValueData: row.beginValueData, endValueData: row.endValueData, valueData:row.beginValueData,cosAsgnSeqNumber: row.cosAsgnSeqNumber});
    }

    
  };
  
  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data); 
      tData = JSON.parse(tData);     
      tData.map((each,index) => {
        each.index = index;
      });    
      return tData;           
    }else{
      return [];
    }
  }
  const tableComp = <TableComponent selected={props.selectDeleteArray} setSelected={props.setSelectDeleteArray} multiDelete headCells={headCells}  tableData={getTableData(props.tableData) ? getTableData(props.tableData) : []} onTableRowClick={editRow} defaultSortColumn="dataElementCriteria" />;
  return (
    showTable ? tableComp : null

  );
}
export default withRouter(AdditionalCriteriaTable);
