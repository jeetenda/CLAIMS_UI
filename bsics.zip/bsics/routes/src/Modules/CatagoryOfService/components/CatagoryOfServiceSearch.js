import React, { useState, useEffect, useRef  } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import * as CatagoryOfServiceConstants from './CatagoryOfServiceConstants';
import { catagoryOfServiceGetAllSearchAction, resetCatagoryOfService, catagoryOfServiceCriteriaSearchAction, cosDeleteAction, createCosAction, editCosAction, cosDropdowns,cosDataElementDropdowns } from '../actions';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import CatagoryOfServiceSearchForm from './CatagoryOfServiceSearchForm';
import CatagoryOfServiceAddForm from './CatagoryOfServiceAddForm';
import CatagoryOfServiceSearchTableComponent from './CatagoryOfServiceSearchTableComponent';
import AdditionalCritiriaTable from './AdditionalCritiriaTable';
import AdditionalCriteriaForm from './AdditionalCriteriaForm';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import dateFnsFormat from "date-fns/format";
import { compareTwoDates } from '../../../SharedModules/DateUtilities/DateUtilities';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';




function CatagoryOfServiceSearch(props) {
  let errorMessagesArray = [];
  const [showNoRecords, setShowNoRecords] = useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    searchClaimType : '-1',
    searchCos :'-1',
    searchLob :'-1'

  });
  const [redirect, setRedirect] = useState(false);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [successMessage, setSuccessMessage] = useState(null);
  const [dialogOpen, setDialogOpen] = useState(false);
  const printRef = useRef();
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
  const [additionalCriteriaShow, setAdditionalCriteriaShow] = useState(false);
  const [additionalEditorAddType, setAdditionalEditorAddType] = useState('add');
  const [additionalCriteriatableData, setAddCritTableData] = useState([]);
  const [additionalCritiriaFormData, setAdditionalCritiriaFormData] = useState({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '',valueData: '' });
  const [additionalCritiriaResetData, setAdditionalCritiriaResetData] = useState({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '',valueData:'' });
  const [{ showAddCritbeginError, showAddCritEndError, showValueError }, setAddCritErrors] = useState(false);

  const [{ lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError,
    showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError,
    beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError,
    beginRenderingProviderTypeError, beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError, renderingProviderTypeValueError,
    beginProcedureCodeError, beginProcedureCodeFormatError, endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError,
    beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
    beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError },
    setShowError] = React.useState(false);

  const [showTable, setShowTable] = useState(false);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editAddValues, setEditAddValues] = useState({})
  const [formEditorAddType, setFormEditorAddType] = useState('add');
  const paylod = useSelector(state => state.catagoryOfSvc.payload);
  const paylodTime = useSelector(state => state.catagoryOfSvc.payloadTime);
  const deleteStatus = useSelector(state => state.catagoryOfSvc.deleteStatus);
  const deleteStatusTime = useSelector(state => state.catagoryOfSvc.deleteStatusTime);
  const createStatus = useSelector(state => state.catagoryOfSvc.createStatus);
  const createStatusTime = useSelector(state => state.catagoryOfSvc.createStatusTime);

  const updateStatus = useSelector(state => state.catagoryOfSvc.updateStatus);
  const updateStatusTime = useSelector(state => state.catagoryOfSvc.updateStatusTime);
  const [resetValues, setResetValues] = useState({});
  const searchDropdowns = useSelector(state => state.catagoryOfSvc.dropdowns);
  const dataElementDropdowns = useSelector(state => state.catagoryOfSvc.deDropdowns);

  const dispatch = useDispatch();
  const getAllSearch = searchvalues => dispatch(catagoryOfServiceGetAllSearchAction(searchvalues));
  const getCriteriaSearch = searchValues => dispatch(catagoryOfServiceCriteriaSearchAction(searchValues));
  const cosDelete = searchValues => { return dispatch(cosDeleteAction(searchValues)) };
  const onCreateCos = searchValues => dispatch(createCosAction(searchValues));
  const onEditCos = searchValues => dispatch(editCosAction(searchValues));
  const onDropdowns = (values) => dispatch(cosDropdowns(values));
  const onDataElementDropdowns = (values) => dispatch(cosDataElementDropdowns(values));
  const onReset = () => dispatch(resetCatagoryOfService());
  

  // values change function
  const handleChanges = name => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };
  const handelEditAddAchanges = name => (event) => {
    if (event.target.type === 'checkbox') {
      setEditAddValues({ ...editAddValues, [name]: event.target.checked });
    } else {
      setEditAddValues({ ...editAddValues, [name]: event.target.value });
    }
  }

  const handleAdditionalcriteriaChanges = name => (event) => {
    // if (event.target.type === 'checkbox') {
    //   setAdditionalCritiriaFormData({ ...additionalCritiriaFormData, [name]: event.target.checked });
    // } else {
    //   setAdditionalCritiriaFormData({ ...additionalCritiriaFormData, [name]: event.target.value });
    // }
    setAdditionalCritiriaFormData({ ...additionalCritiriaFormData, [name]: event.target.value });
  };

  const handelDateChange = (name, date) => {
    setEditAddValues({ ...editAddValues, [name]: formatDate(date)});
  }

  const resetTable = () => {
    seterrorMessages([]);
   
    setValues(
      {
        searchClaimType : '-1',
    searchCos :'-1',
    searchLob :'-1'
      }
    );
    // onReset()
     getAllSearch({ "lobCode": "", "categoryOfServiceCode": "", "claimTypeCode": "" })

  };

  const formatDate = (dt) => {
    if (!dt) {
        return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
        return dt;
    } else {
        return dateFnsFormat(dt, "yyyy-MM-dd");
    }
  };


  const searchCheck = () => {
    setSuccessMessage(null);
    setShowTable(false);
    setspinnerLoader(false);
    setShowTable(true);
    setspinnerLoader(true);
    searchReuse();
  };

  const searchReuse = () => {
    let searchCriteria = {};
    if (!(values.searchLob === '' && values.searchCos === '' && values.searchClaimType === '')) {
      searchCriteria = {
        lobCode: values.searchLob==='-1'?'':values.searchLob,
        categoryOfServiceCode: values.searchCos==='-1'?'':values.searchCos,
        claimTypeCode: values.searchClaimType==='-1'?'':values.searchClaimType
      }
      getCriteriaSearch(searchCriteria);
    } else {
      getAllSearch();
    }
  }
  const saveAdditionalCriteria = () => {
    setAddCritErrors({});
    let showAddCritbeginError;
    let showValueError;
    let showAddCritEndError;
    if (additionalCritiriaFormData.range === 'Range') {
      if (additionalCritiriaFormData.beginValueData === '') {
        showAddCritbeginError = true;
        errorMessagesArray.push(CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR);
        seterrorMessages(errorMessagesArray);
      }
      if (additionalCritiriaFormData.endValueData === '') {
        showAddCritEndError = true;
        errorMessagesArray.push(CatagoryOfServiceConstants.ADD_CRIT_END_ERROR);
        seterrorMessages(errorMessagesArray);
      }
    } else {
      if (additionalCritiriaFormData.valueData === '') {
        showValueError = true;
        errorMessagesArray.push(CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR);
        seterrorMessages(errorMessagesArray);
      }
    }
    if (errorMessagesArray.length === 0) {
      const table = additionalCriteriatableData;
      if(additionalCritiriaFormData.range==='Value'){
        additionalCritiriaFormData.beginValueData=additionalCritiriaFormData.valueData;
        // additionalCritiriaFormData.endValueData=additionalCritiriaFormData.valueData;
      }
      if (additionalEditorAddType === 'add') {
        table.push(additionalCritiriaFormData);
        setAddCritTableData(table);
      } else {//edit
        const change = table.filter(each => each.timeStamp !== additionalCritiriaFormData.timeStamp);
        change.push(additionalCritiriaFormData);
        setAddCritTableData(change);
      }
      setSuccessMessage('system succesfully saved the information');
      setAdditionalCriteriaShow(false);
      setAdditionalCritiriaResetData({ timeStamp: '', dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '', valueData:'' });
      setAdditionalCritiriaFormData({ timeStamp: '', dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '',valueData:'' });      
    } else {
      setAddCritErrors({
        showAddCritbeginError,
        showAddCritEndError,
        showValueError
      });
    }
  }

  const deleteAdditionalCriteria = (deleteTime) => {
    const table = additionalCriteriatableData;
    const deletedata = table.filter(each => String(each.timeStamp) === String(deleteTime));
    const change = table.filter(each => String(each.timeStamp) !== String(deleteTime));
    if (deletedata[0].type === 'old') {
      const deletetable = deleteAddCrit;
      deletetable.push({
        auditUserID: "wf_NH_MC_CLM_TY_ASGNMNTV5",
        addedAuditUserID: "SDRESSLER",
        additionalColName: deletedata[0].dataElementCriteria,
        beginValueData: deletedata[0].beginValueData,
        endValueData: deletedata[0].endValueData
      });
      setDeleteAddCrit(deletetable);
    }
    setAddCritTableData(change);
    setSuccessMessage('system succesfully saved the information');
    setAdditionalCriteriaShow(false);
    setAdditionalCritiriaResetData({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '' });
    setAdditionalCritiriaFormData({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '' });
  }
  const addForm = () => {
    props.history.push({
      pathname: '/CategoryofSvcAdd'
    })
    
  }

  // const addUpdateSave = () => {
  //   const addcittabledata = additionalCriteriatableData;
  //   let transaddcittabledata = [];
  //   if (addcittabledata.length > 0) {
  //     addcittabledata.map(each => {
  //       transaddcittabledata.push({
  //         additionalColName: each.dataElementCriteria,
  //         additionalColNameDesc: "",
  //         beginValueData: each.beginValueData,
  //         endValueData: each.endValueData
  //       });
  //     })
  //   }
  //   setspinnerLoader(false);
  //   errorMessagesArray = [];
  //   seterrorMessages([]);
  //   setSuccessMessage(null);
  //   let lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError, showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError, beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError, beginRenderingProviderTypeError,
  //     beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError,
  //     renderingProviderTypeValueError, beginProcedureCodeError, beginProcedureCodeFormatError,
  //     endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError, beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
  //     beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError;
  //   if (editAddValues.lobCode === "") {
  //     lobCodeError = true;
  //     errorMessagesArray.push(CatagoryOfServiceConstants.LOB_ERROR);
  //     seterrorMessages(errorMessagesArray);
  //   }
  //   if (editAddValues.categoryOfServiceCode === "") {
  //     cosCodeError = true;
  //     errorMessagesArray.push(CatagoryOfServiceConstants.COS_CODE_ERROR);
  //     seterrorMessages(errorMessagesArray);
  //   }
  //   if (editAddValues.headerLineAssignCode === "") {
  //     assignCodeError = true;
  //     errorMessagesArray.push(CatagoryOfServiceConstants.ASSIGN_CODE_ERROR);
  //     seterrorMessages(errorMessagesArray);
  //   }
  //   if (editAddValues.claimFormCode === "") {
  //     claimFormCodeError = true;
  //     errorMessagesArray.push(CatagoryOfServiceConstants.CLAIM_FORM_ERROR);
  //     seterrorMessages(errorMessagesArray);
  //   }
  //   if (editAddValues.claimTypeCode === "") {
  //     claimTypeCodeError = true;
  //     errorMessagesArray.push(CatagoryOfServiceConstants.CLAIM_TYPE_ERROR);
  //     seterrorMessages(errorMessagesArray);
  //   }
  //   if (editAddValues.beginDate === "" || editAddValues.endDate === "") {
  //     if (editAddValues.beginDate === "") {
  //       showBeginDateError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.BEGIN_DATE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     if (editAddValues.endDate === "") {
  //       showEndDateError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.END_DATE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //   } else if (editAddValues.beginDate >= editAddValues.endDate) {
  //     if (editAddValues.beginDate >= editAddValues.endDate) {
  //       showDateError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.DATE_RANGE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //   }
  //   //Billing Provider Type Validations
  //   if (editAddValues.billProviderType === 'Range') {
  //     if (editAddValues.beginBillingProviderTypeCode === '' || editAddValues.beginBillingProviderTypeCode === undefined || editAddValues.beginBillingProviderTypeCode === null) {
  //       beginBillProviderTypeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_BEGIN_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.beginBillingProviderTypeCode)) {
  //       beginBillProviderTypeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     if (editAddValues.endBillingProviderTypeCode === '' || editAddValues.endBillingProviderTypeCode === undefined || editAddValues.endBillingProviderTypeCode === null) {
  //       endBillProviderTypeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_END_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.endBillingProviderTypeCode)) {
  //       endBillProviderTypeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //   }
  //   else if (editAddValues.billProviderType === 'Value') {
  //     if (editAddValues.billProviderTypeValue === '' || editAddValues.billProviderTypeValue === undefined) {
  //       billProviderTypeValueError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_VALUE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     else {
  //       editAddValues.beginBillingProviderTypeCode = editAddValues.billProviderTypeValue;
  //       editAddValues.endBillingProviderTypeCode = editAddValues.billProviderTypeValue;
  //     }
  //   }
  //   //Rendering Provider Type Validations
  //   if (editAddValues.renderingProviderType === 'Range') {
  //     if (editAddValues.beginRenderingProviderTypeCode === '' || editAddValues.beginRenderingProviderTypeCode === undefined || editAddValues.beginRenderingProviderTypeCode === null) {
  //       beginRenderingProviderTypeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_BEGIN_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.beginRenderingProviderTypeCode)) {
  //       beginRenderingProviderTypeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     if (editAddValues.endRenderingProviderTypeCode === '' || editAddValues.endRenderingProviderTypeCode === undefined || editAddValues.endRenderingProviderTypeCode === null) {
  //       endRenderingProviderTypeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_END_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.beginRenderingProviderTypeCode)) {
  //       endRenderingProviderTypeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //   }
  //   else if (editAddValues.renderingProviderType === 'Value') {
  //     if (editAddValues.renderingProviderTypeValue === '' || editAddValues.renderingProviderTypeValue === undefined || editAddValues.renderingProviderTypeValue === null) {
  //       renderingProviderTypeValueError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_VALUE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     else {
  //       editAddValues.beginRenderingProviderTypeCode = editAddValues.renderingProviderTypeValue;
  //       editAddValues.endRenderingProviderTypeCode = editAddValues.renderingProviderTypeValue;
  //     }
  //   }
  //   //Procedure Code Validations
  //   if (editAddValues.procedureCodeType === 'Range') {
  //     if (editAddValues.beginProcedureCode === '' || editAddValues.beginProcedureCode === undefined || editAddValues.beginProcedureCode === null) {
  //       beginProcedureCodeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.PROCEDURE_CODE_BEGIN_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.beginProcedureCode)) {
  //       beginProcedureCodeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     if (editAddValues.endProcedureCode === '' || editAddValues.endProcedureCode === undefined || editAddValues.endProcedureCode === null) {
  //       endProcedureCodeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.PROCEDURE_CODE_END_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.endProcedureCode)) {
  //       endProcedureCodeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //   }
  //   else if (editAddValues.procedureCodeType === 'Value') {
  //     if (editAddValues.procCodeValue === '' || editAddValues.procCodeValue === undefined || editAddValues.procCodeValue === null) {
  //       procCodeValueError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.PROCEDURE_CODE_VALUE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     else {
  //       editAddValues.beginProcedureCode = editAddValues.procCodeValue;
  //       editAddValues.endProcedureCode = editAddValues.procCodeValue;
  //     }
  //   }
  //   //Diagnosis Code Validations
  //   if (editAddValues.diagCodeType === 'Range') {
  //     if (editAddValues.beginDiagnosisCode === '' || editAddValues.beginDiagnosisCode === undefined || editAddValues.beginDiagnosisCode === null) {
  //       beginDiagnosisCodeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.DIAGNOSIS_CODE_BEGIN_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.beginProcedureCode)) {
  //       beginDiagnosisCodeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     if (editAddValues.endDiagnosisCode === '' || editAddValues.endDiagnosisCode === undefined || editAddValues.endDiagnosisCode === null) {
  //       endDiagnosisCodeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.DIAGNOSIS_CODE_END_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.endDiagnosisCode)) {
  //       endDiagnosisCodeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //   }
  //   else if (editAddValues.diagCodeType === 'Value') {
  //     if (editAddValues.diagCodeValue === '' || editAddValues.diagCodeValue === undefined || editAddValues.diagCodeValue === null) {
  //       diagnosisCodeValueError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.DIAGNOSIS_CODE_VALUE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     else {
  //       editAddValues.beginDiagnosisCode = editAddValues.diagCodeValue;
  //       editAddValues.endDiagnosisCode = editAddValues.diagCodeValue;
  //     }
  //   }
  //   //Surgical Procedure Code Validations
  //   if (editAddValues.surgProcCodeType === 'Range') {
  //     if (editAddValues.beginSurgicalProcedureCode === '' || editAddValues.beginSurgicalProcedureCode === undefined || editAddValues.beginSurgicalProcedureCode === null) {
  //       beginSurgProcedureCodeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_BEGIN_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.beginSurgicalProcedureCode)) {
  //       beginSurgProcedureCodeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     if (editAddValues.endSurgicalProcedureCode === '' || editAddValues.endSurgicalProcedureCode === undefined || editAddValues.endSurgicalProcedureCode === null) {
  //       endSurgProcedureCodeError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_END_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     } else if (!/^[0-9]+$/.test(editAddValues.endSurgicalProcedureCode)) {
  //       endSurgProcedureCodeFormatError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //   }
  //   else if (editAddValues.surgProcCodeType === 'Value') {
  //     if (editAddValues.surgProcCodeValue === '' || editAddValues.surgProcCodeValue === undefined || editAddValues.surgProcCodeValue === null) {
  //       surgProcedureCodeValueError = true;
  //       errorMessagesArray.push(CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_VALUE_ERROR);
  //       seterrorMessages(errorMessagesArray);
  //     }
  //     else {
  //       editAddValues.beginSurgicalProcedureCode = editAddValues.surgProcCodeValue;
  //       editAddValues.endSurgicalProcedureCode = editAddValues.surgProcCodeValue;
  //       // delete editAddValues.procedureCode;
  //       // delete editAddValues.procCodeValue;
  //     }
  //   }
  //   if (errorMessagesArray.length === 0) {
  //     let searchCriteria = {
  //       //New Request With Additional criteria
  //       "additionalCriteriaList": transaddcittabledata,
  //       "auditUserID": editAddValues.auditUserID ? editAddValues.auditUserID : "",
  //       "auditTimeStamp": new Date(),
  //       "addedAuditUserID": editAddValues.addedAuditUserID ? editAddValues.addedAuditUserID : "",
  //       "addedAuditTimeStamp": new Date(),
  //       "beginBillingProviderTypeCode": editAddValues.beginBillingProviderTypeCode ? editAddValues.beginBillingProviderTypeCode : "",
  //       "endBillingProviderTypeCode": editAddValues.endBillingProviderTypeCode ? editAddValues.endBillingProviderTypeCode : "",
  //       "beginRenderingProviderTypeCode": editAddValues.beginRenderingProviderTypeCode ? editAddValues.beginRenderingProviderTypeCode : "",
  //       "endRenderingProviderTypeCode": editAddValues.endRenderingProviderTypeCode ? editAddValues.endRenderingProviderTypeCode : "",
  //       "beginProcedureCode": editAddValues.beginProcedureCode ? editAddValues.beginProcedureCode : "",
  //       "endProcedureCode": editAddValues.endProcedureCode ? editAddValues.endProcedureCode : "",
  //       "beginDiagnosisCode": editAddValues.beginDiagnosisCode ? editAddValues.beginDiagnosisCode : "",
  //       "endDiagnosisCode": editAddValues.endDiagnosisCode ? editAddValues.endDiagnosisCode : "",
  //       "beginSurgicalProcedureCode": editAddValues.beginSurgicalProcedureCode ? editAddValues.beginSurgicalProcedureCode : "",
  //       "endSurgicalProcedureCode": editAddValues.endSurgicalProcedureCode ? editAddValues.endSurgicalProcedureCode : "",
  //       "beginDate": new Date(editAddValues.beginDate).toISOString().split('T')[0],
  //       "endDate": new Date(editAddValues.endDate).toISOString().split('T')[0],
  //       "billingProviderType": "",
  //       "categoryOfServiceCode": editAddValues.categoryOfServiceCode,
  //       "claimFormCode": editAddValues.claimFormCode,
  //       "headerLineAssignCode": editAddValues.headerLineAssignCode,
  //       "claimTypeCode": editAddValues.claimTypeCode,
  //       "categoryOfServiceSK": "",
  //       "categoryOfServiceDetailSet": [],
  //       "claimTypeList": [],
  //       "deletedAdditionalCriteriaSet": [],
  //       "defaultIndicator": editAddValues.defaultIndicator,
  //       "diagnosisCode": "",
  //       "loginUserID": "",
  //       "lobCode": editAddValues.lobCode,
  //       "modifiedTimeStamp": "",
  //       "overRideAddedAuditTS": false,
  //       "procedureCode": "",
  //       "procedureModifier1": editAddValues.procedureModifier1 ? editAddValues.procedureModifier1 : "",
  //       "procedureModifier2": editAddValues.procedureModifier2 ? editAddValues.procedureModifier2 : "",
  //       "procedureModifier3": editAddValues.procedureModifier3 ? editAddValues.procedureModifier3 : "",
  //       "procedureModifier4": editAddValues.procedureModifier4 ? editAddValues.procedureModifier4 : "",
  //       "procedureModifierCode1": editAddValues.procedureModifierCode1 ? editAddValues.procedureModifierCode1 : "",
  //       "procedureModifierCode2": editAddValues.procedureModifierCode2 ? editAddValues.procedureModifierCode2 : "",
  //       "procedureModifierCode3": editAddValues.procedureModifierCode3 ? editAddValues.procedureModifierCode3 : "",
  //       "procedureModifierCode4": editAddValues.procedureModifierCode4 ? editAddValues.procedureModifierCode4 : "",
  //       "rankNumber": editAddValues.rankNumber ? editAddValues.rankNumber : 0,
  //       "renderingProviderType": "",
  //       "surgicalProcedureCode": "",
  //       "usedIndicator": true,
  //       "versionNo": editAddValues.versionNo ? editAddValues.versionNo : 1


  //       //End new request with add criteria


  //     }
  //     if (formEditorAddType === 'add') {
  //       setspinnerLoader(true);
  //       onCreateCos(searchCriteria);
  //     } else {
  //       //searchCriteria.additionalCriteriaList = searchCriteria.additionalCriteriaList?searchCriteria.additionalCriteriaList:[];
  //       searchCriteria.categoryOfServiceSK = String(editAddValues.categoryOfServiceSK);
  //       searchCriteria.usedIndicator = true;
  //       searchCriteria.versionNo = Number(editAddValues.versionNo);
  //       setspinnerLoader(true);
  //       onEditCos(searchCriteria);
  //     }
  //     setAddCritTableData([]);
  //     setAdditionalCritiriaFormData([]);

  //   }

  //   setShowError({
  //     lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError, showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError, beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError, beginRenderingProviderTypeError,
  //     beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError,
  //     renderingProviderTypeValueError, beginProcedureCodeError, beginProcedureCodeFormatError,
  //     endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError, beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
  //     beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError
  //   })
  // }
  //on delete cos
  const deletecos = () => {
    cosDelete({ 
      categoryOfServiceSK: editAddValues.categoryOfServiceSK//, 
      //"auditUserID": editAddValues.auditUserID ? editAddValues.auditUserID : "" 
    });
    setDialogOpen(false);
    setspinnerLoader(true);
    setAddCritTableData([]);
    setAdditionalCritiriaFormData([]);
  }
  // on cos page load

  useEffect(() => {
    onDropdowns({
      "inputList" : [Dropdowns.LOB,
        Dropdowns.CATEGORY_OF_SERVICE,
        Dropdowns.CLAIM_FORM,
        Dropdowns.CLAIM_TYPE,
        Dropdowns.ASSIGN_TO,
        Dropdowns.PROVIDER_ID_TYPE,
        Dropdowns.BILLING_PROVIDER_ID_TYPE
      ]
    });
    let searchCriteria = { "lobCode": "", "categoryOfServiceCode":  "", "claimTypeCode": "" };
    onDataElementDropdowns(Dropdowns.DATA_ELEMENT_CRITERIA_COS);
    if(props && props.location && props.location.search){
      var query = new URLSearchParams(props.location.search);
      let id = query.get('id')
      searchCriteria.categoryOfServiceCode =id;
      setValues({...values,searchCos :id});
      setspinnerLoader(true);
      getCriteriaSearch(searchCriteria)
    }else{
      if(props.privileges && props.privileges.search){
        getAllSearch(searchCriteria)
      };
    }
  
    if (paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      setShowTable(true);
      if (paylod.length == 0) {
        setShowNoRecords(true);
      }
    }
    
    
  }, []);

  // on cos page search data
  useEffect(() => {
    if (paylod != null && (paylod.length > 0 || paylod.length == 0)) {
      setspinnerLoader(false);
    }
    if (paylod && paylod.message != null) {
      setspinnerLoader(false);
      errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
      seterrorMessages(errorMessagesArray);
    }
    if (paylod != null && paylod.length == 0) {
      setShowNoRecords(true);
    }
    setspinnerLoader(false);
  }, [paylodTime]);
  // delete
  useEffect(() => {
    setspinnerLoader(false);
    if (deleteStatus && deleteStatus.message != null) {
      errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
      seterrorMessages(errorMessagesArray);
    }
    if (deleteStatus !== null && deleteStatus !== undefined) {
      if (deleteStatus === true) {
        setShowAddForm(false);
        setEditAddValues({});
        setSuccessMessage('Category Of Service deleted succesfully');
        searchReuse();
      } else if (deleteStatus === false) {
        errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
        seterrorMessages(errorMessagesArray);
      }
    }
  }, [deleteStatusTime]);

  useEffect(() => {
    setspinnerLoader(false);
    if (createStatus && createStatus.message != null) {
      errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
      seterrorMessages(errorMessagesArray);
    }
    if (createStatus !== null && createStatus !== undefined) {
      if (createStatus === true) {
        setShowAddForm(false);
        setEditAddValues({});
        setSuccessMessage('Category Of Service created succesfully');
        searchReuse();
      } else if (createStatus === false) {
        errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
        seterrorMessages(errorMessagesArray);
      }
    }
  }, [createStatusTime]);

  useEffect(() => {
    setspinnerLoader(false);
    if (updateStatus && updateStatus.message != null) {
      errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
      seterrorMessages(errorMessagesArray);
    }
    if (updateStatus !== null && updateStatus !== undefined) {
      if (updateStatus === true) {
        setShowAddForm(false);
        setEditAddValues({});
        setSuccessMessage('Category Of Service updated succesfully');
        searchReuse();
      } else if (updateStatus === false) {
        errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
        seterrorMessages(errorMessagesArray);
      }
    }
  }, [updateStatusTime]);


  return (
    // pos-relative div start

    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}
      {errorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert hide-on-print" role="alert">
          {errorMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null
      }
      {/* {!successMessage && errorMessages.length > 0 ? (
        <div className="alert alert-danger custom-alert hide-on-print" role="alert">
          {errorMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null
      }
      {!successMessage && errorMessages.length == 0 && paylod && paylod.length == 0 && showNoRecords ? (
        <div className="alert alert-danger custom-alert hide-on-print" role="alert">
          <li>{CatagoryOfServiceConstants.NO_RECORDS_FOUND}</li>
        </div>
      ) : null
      }
      {(!spinnerLoader && successMessage)
        ? (
          <div className="alert alert-success custom-alert hide-on-print">
            {successMessage}
          </div>
        ) : null} */}
      <Dialog
        open={dialogOpen}
        onClose={() => setDialogOpen(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to Delete
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={deletecos} color="primary">
            Ok
          </Button>
          <Button onClick={() => setDialogOpen(false)} color="primary" autoFocus>
            Cancel
          </Button>
        </DialogActions>
      </Dialog>
      <div className="mb-2">
				<BreadCrumbs
					parent="Claims Configuration"
					child1="Category Of Service"
					path="CategoryofSvcAssignment"
				/>
			</div>
      {/* tabs-container div start */}
      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
        <h1 className="page-heading float-left">
            Category Of Service Assignment
          </h1>
          <div className="float-right">
          <Button title="Add category of service assignments" variant="outlined" color="primary" className="btn btn-ic btn-add" onClick={addForm} disabled={props.privileges && !props.privileges.add? 'disabled':''}>
                Add
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))}
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-primary btn-ic btn-print">
              Print
            </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
              Help
            </Button>
          </div>
          <div className="clearfix" />
        </div>
        {/* <CatagoryOfServiceSearchForm values={values} handleChanges={handleChanges} resetTable={resetTable} searchCheck={searchCheck} errors={{ showDiagnosisError, showdiagnosisCodeError, showdescriptionError }} /> */}

        {/* Display Filter Start */}
        <div className="tab-body mt-2">
          
          <CatagoryOfServiceSearchForm resetTable={resetTable} values={values} handleChanges={handleChanges} searchCheck={searchCheck} dropdowns={searchDropdowns} privileges={props.privileges}/>
          {/* searchCheck={searchCheck} */}
          {/* Catagory Of Service Assignments Start */}
        <div className="px-3 pb-1">
          
          {/* {showTable && paylod && paylod.length > 0?( */}
          <div className="tab-body mt-2">
          <div className={`${printLayout ? 'hide-on-screen' : ''}`}>
            {paylod && paylod.length > 0 ? (<CatagoryOfServiceSearchTableComponent
              tableData={paylod}
              setEditAddValues={setEditAddValues}
              setShowAddForm={setShowAddForm}
              setResetValues={setResetValues}
              setFormEditorAddType={setFormEditorAddType}
              setAdditionalCriteriaShow={setAdditionalCriteriaShow}
              setShowError={setShowError}
              setspinnerLoader={setspinnerLoader}
              setAddCritTableData={setAddCritTableData}
              setAddCritTableData={setAddCritTableData}
              setRedirect={setRedirect}
                redirect={redirect}
                seterrorMessages={seterrorMessages}
            />) : null }
            </div>
          </div>
          {/* ):null} */}
          {/* Edit Assignment Criteria start */}
          {/* Edit Assignment Criteria start */}
          {showAddForm ? (
            <div className="tabs-container">
              <div className="tab-header">
                <h2 className="tab-heading float-left">
                  Edit Assignment Criteria
            </h2>
                <div className="float-right th-btnGroup">
                  <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => addUpdateSave()} disabled={props.privileges && !props.privileges.update? 'disabled':''}>
                    Save
                  </Button>
                  {formEditorAddType !== 'add' ? (<Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => setDialogOpen(true)} disabled={props.privileges && !props.privileges.update? 'disabled':''}>
                    Delete
                  </Button>) : null}
                  <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => { setSuccessMessage(setSuccessMessage); setEditAddValues(resetValues) }}>
                    Reset
                  </Button>
                  <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => { setSuccessMessage(null); setShowAddForm(false); setEditAddValues({}) }}>
                    Cancel
                  </Button>
                </div>

                <div className="clearfix" />
              </div>
              <div className="tab-body-bordered mt-2">
              {/* add form */}
              <CatagoryOfServiceAddForm values={editAddValues} handelDateChange={handelDateChange} handleChanges={handelEditAddAchanges} formEditorAddType={formEditorAddType} dropdowns={searchDropdowns}
                errors={{
                  lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError, showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError, beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError, beginRenderingProviderTypeError,
                  beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError,
                  renderingProviderTypeValueError, beginProcedureCodeError, beginProcedureCodeFormatError,
                  endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError, beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
                  beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError
                }}
              />
              {/* Additional Criteria Start */}
              <div className="tabs-container">
                <div className="tab-header">
                  <h2 className="tab-heading float-left">
                    Additional Criteria
                </h2>
                  <div className="float-right th-btnGroup">
                    <Button title="Add additional criteria" variant="outlined" color="primary" className="btn btn-secondary btn-icon-only" onClick={() => {
                      setAdditionalCriteriaShow(true);
                      setAdditionalEditorAddType('add');
                      setAdditionalCritiriaResetData({ timeStamp: new Date(), dataElementCriteria: 'Please Select One', range: 'Range', beginValueData: '', endValueData: '', Value: '',valueData:'' });
                      setAdditionalCritiriaFormData({ timeStamp: new Date(), dataElementCriteria: 'Please Select One', range: 'Range', beginValueData: '', endValueData: '', Value: '', valueData:'' })
                    }} >
                      <i class="fa fa-plus" />
                    </Button>
                  </div>
                  <div className="clearfix"></div>
                </div>
                <div className="mt-2">
                <AdditionalCritiriaTable
                  tableData={additionalCriteriatableData}
                  setAdditionalCritiriaFormData={setAdditionalCritiriaFormData}
                  setAdditionalCritiriaResetData={setAdditionalCritiriaResetData}
                  setAdditionalCriteriaShow={setAdditionalCriteriaShow}
                  setAdditionalEditorAddType={setAdditionalEditorAddType}
                /></div>
                {additionalCriteriaShow ? (<div className="tabs-container">
                  <div className="tab-header">
                    <div className="tab-heading float-left">
                      {additionalEditorAddType === 'add' ? "Add Additional Criteria" : "Edit Additional Criteria"}
                    </div>
                    <div className="float-right mr-2">
                      <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => saveAdditionalCriteria()}>
                        Save
                      </Button>
                      {additionalEditorAddType !== 'add' ? (<Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => deleteAdditionalCriteria(additionalCritiriaFormData.timeStamp)}>
                        Delete
                      </Button>) : null}
                      <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => { setAdditionalCritiriaFormData(additionalCritiriaResetData) }} >
                        Reset
                      </Button>
                      <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => { setAdditionalCriteriaShow(false) }} >
                        Cancel
                      </Button>
                    </div>
                    <div className="clearfix" />
                  </div>
                  <AdditionalCriteriaForm values={additionalCritiriaFormData} handleChanges={handleAdditionalcriteriaChanges} errors={{ showAddCritbeginError, showAddCritEndError, showValueError }} dropdowns={searchDropdowns} dataElementDropdowns={dataElementDropdowns}/>
                </div>) : null}
              </div>
              {/* Additional Criteria End */}
              </div>
            </div>

          ) : null
          }
           <Footer print />
        </div>
        {/* Catagory Of Service Assignments End */}
        </div>

        {/* Display Filter End */}
        

      </div>
      {/* tab-container div end */}
    </div>
    // pos-relative div start

  );
}
export default withRouter(CatagoryOfServiceSearch);
