import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import { makeStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';
// import Moment from 'react-moment';
// import { KeyboardDatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';
//import DateFnsUtils from '@date-io/date-fns';
const useStyles = makeStyles(theme => ({
  formControl: {
    margin: theme.spacing(3),
  },
}));
export default function CatagoryOfServiceEditForm(props) {
  const [defaultCheck, setDefaultCheck] = React.useState(false);
  const [values, setValues] = React.useState({});
  const [selectedEndDate, setSelectedEndDate] = React.useState('');
  const [selectedBeginDate, setSelectedBeginDate] = React.useState('');
  const [{showBeginDateError, showEndDateError }, setShowError] = React.useState(false);
  const [beginDatePress, setBeginDatePress] = React.useState(false);
  const [endDatePress, setEndDatePress] = React.useState(false);


  const handleBeginDateChange = date => {
    setSelectedBeginDate(date);
    setBeginDatePress(false);
  };

  const handleBeginDateText = thruBeginText => {
    setSelectedBeginDate(beginDateText.target.value);
    setBeginDatePress(true);
  };

  const handleEndDateChange = date => {
    setSelectedEndDate(date);
    setEndDatePress(false);
  };

  const handleEndDateText = lastDateText => {
    setSelectedEndDate(endDateText.target.value);
    setEndDatePress(true);
  };


  const handleDefaultCheckChange = () => {
    setDefaultCheck(!defaultCheck);
  };
  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-lob"
            select
            label="LOB"
            name="editLob"
            value={props.values.editLob}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('editLob')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            <MenuItem selected key="MED-Medicaid" value="MED-Medicaid">MED-Medicaid</MenuItem>
            <MenuItem selected key="MED-Medicaid 2" value="MED-Medicaid 2">MED-Medicaid 2</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-cos"
            select
            name="editCos"
            label="Catagory Of Service"
            value={props.values.editCos}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('editCos')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            <MenuItem selected key="001-InpHspGen" value="001-InpHspGen">001-InpHspGen</MenuItem>
            <MenuItem selected key="003-InpHspMent" value="003-InpHspMent">003-InpHspMent</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-assign-to"
            select
            label="Assign to"
            name="editAssignTo"
            value={props.values.editAssignTo}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('editAssignTo')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            <MenuItem selected key="H-Header" value="H-Header">H-Header</MenuItem>
            <MenuItem selected key="L-Line" value="L-Line">L-Line</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-claim-form"
            select
            label="Claim Form"
            name="editClaimForm"
            value={props.values.editClaimForm}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('editClaimForm')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            <MenuItem selected key="60-Prof" value="60-Prof">60-Prof</MenuItem>
            <MenuItem selected key="61-Inst" value="61-Inst">61-Inst</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-claim-type"
            select
            label="Claim Type"
            name="editClaimType"
            value={props.values.editClaimType}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('editClaimType')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            <MenuItem selected key="C-Capitation" value="C-Capitation">C-Capitation</MenuItem>
            <MenuItem selected key="D-Dental" value="D-Dental">D-Dental</MenuItem>
          </TextField>
        </div>
        {/* MuiPickersUtilsProvider start */}
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
              <KeyboardDatePicker
                  id="bgnDate"
                  label="Begin Date"
                  format="MM/dd/yyy"
                  InputLabelProps={{
                      shrink: true,
                  }}
                  placeholder="mm/dd/yyy"
                  value={selectedBeginDate}
                  onChange={handleBeginDateChange}
                  onKeyUp={handleBeginDateText}
                  helperText={showBeginDateError ? errorMeg : null}
                  error={showBeginDateError ? errorMeg : null}
                  KeyboardButtonProps={{
                      'aria-label': 'change date',
                  }}
              />
          </div>
        </MuiPickersUtilsProvider>
        <MuiPickersUtilsProvider utils={DateFnsUtils}>
          <div className="mui-custom-form input-md with-select">
              <KeyboardDatePicker
                  id="endDate"
                  label="End Date"
                  format="MM/dd/yyy"
                   
							    maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                  InputLabelProps={{
                      shrink: true,
                  }}
                  placeholder="mm/dd/yyy"
                  value={selectedEndDate}
                  onChange={handleEndDateChange}
                  onKeyUp={handleEndDateText}
                  helperText={showEndDateError ? errorMeg : null}
                  error={showEndDateError ? errorMeg : null}
                  KeyboardButtonProps={{
                      'aria-label': 'change date',
                  }}
              />
          </div>
        </MuiPickersUtilsProvider>
        {/* </MuiPickersUtilsProvider>  */}
        <div className="sub-radio">
          <FormControlLabel
            control={<Checkbox color="primary" onClick={handleDefaultCheckChange} checked={defaultCheck} value={defaultCheck} />}
            label="Default"
          />
        </div>

      </div>
      <div className="form-wrapper">
        {/* Billing Provider Type */}
        <div className="flex-wrappers aa">
          <div className="flex-wrapper-item w-50">
            <div className="flex-header">
              Billing Provider Type
            </div>
            <div className="flex-content">
              <div className="sub-radio set-rd-pos">
                <input type="radio"
                  value="Range"
                  name="editBillProviderRadio"
                  checked={props.values.editBillProviderRadio === "Range"}
                  onChange={props.handleChanges('editBillProviderRadio')}
                /><label className="text-black"> Range</label>
                <input type="radio"
                  value="Value"
                  name="editBillProviderRadio"
                  checked={props.values.editBillProviderRadio === "Value"}
                  onChange={props.handleChanges('editBillProviderRadio')}
                /><label className="text-black">Value</label>

                <input type="radio"
                  value="NA"
                  name="editBillProviderRadio"
                  checked={(!props.values.editBillProviderRadio) || (props.values.editBillProviderRadio === 'NA')}
                  onChange={props.handleChanges('editBillProviderRadio')}
                />
                <label className="text-black">NA</label>
              </div>
              {/* div sub radio end */}
              {/* Range div */}

              {(props.values.editBillProviderRadio === 'Range') ? (
                <div>
                  <div>
                    <span className="cndt-label">Billing Provider Type Range</span>
                  </div>
                  <TextField
                    name="editBillProviderRangeStart"
                    label=""
                    value={props.values.editBillProviderRangeStart}
                    onChange={props.handleChanges('editBillProviderRangeStart')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  /><span className="text-black"> - </span>
                  <TextField
                    name="editBillProviderRangeEnd"
                    label=""
                    value={props.values.editBillProviderRangeEnd}
                    onChange={props.handleChanges('editBillProviderRangeEnd')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  />
                </div>
              ) : null
              }
              {/* Range div end*/}
              {(props.values.editBillProviderRadio === 'Value') ? (
                <div>
                  <div>
                    <span className="cndt-label">Billing Provider Type Value</span>
                  </div>
                  <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
                    <TextField
                      id="standard-select-bill-provd-type-value"
                      select
                      label=""
                      name="editBillProvdTypeValue"
                      value={props.values.editBillProvdTypeValue}
                      inputProps={{ maxLength: 2 }}
                      onChange={props.handleChanges('editBillProvdTypeValue')}
                      placeholder=""
                      InputLabelProps={{
                        shrink: true,
                      }}
                    >
                      <MenuItem selected key="Please Select One" value="Please Select One">
                        Please Select One
                    </MenuItem>
                    {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Provider#1448'].length > 0 && props.dropdowns['Provider#1448'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
                    </TextField>
                  </div>
                </div>
              ) : null
              }
              {/* Value div end*/}
            </div>
          </div>
          {/* Redering Provider Type */}
          <div className="flex-wrapper-item w-50">
            <div className="flex-header">
              Redering Provider Type
            </div>
            <div className="flex-content">
              <div className="mui-custom-form radio-box">
                <div className="sub-radio set-rd-pos">
                  <input type="radio"
                    value="Range"
                    name="editRenderingProviderRadio"
                    checked={props.values.editRenderingProviderRadio === "Range"}
                    onChange={props.handleChanges('editRenderingProviderRadio')}
                    className="ml-1"
                  /><label className="text-black"> Range</label>
                  <input type="radio"
                    value="Value"
                    name="editRenderingProviderRadio"
                    checked={props.values.editRenderingProviderRadio === "Value"}
                    onChange={props.handleChanges('editRenderingProviderRadio')}
                    className="ml-1"
                  /><label className="text-black">Value</label>

                  <input type="radio"
                    value="NA"
                    name="editRenderingProviderRadio"
                    checked={(!props.values.editRenderingProviderRadio) || (props.values.editRenderingProviderRadio === 'NA')}
                    onChange={props.handleChanges('editRenderingProviderRadio')}
                    className="ml-1"
                  />
                  <label className="text-black">NA</label>
                </div>
                {/* div sub radio end */}
                {/* Range div */}
                {(props.values.editRenderingProviderRadio === 'Range') ? (
                  <div>
                    <div>
                      <span className="cndt-label">Rendering Provider Type Range</span>
                    </div>
                    <TextField
                      name="editRenderingProviderRangeStart"
                      label=""
                      value={props.values.editRenderingProviderRangeStart}
                      onChange={props.handleChanges('editRenderingProviderRangeStart')}
                      variant="outlined"
                      inputProps={{ maxLength: 4 }}
                    /><span className="text-black"> - </span>
                    <TextField
                      name="editRenderingProviderRangeEnd"
                      label=""
                      value={props.values.editRenderingProviderRangeEnd}
                      onChange={props.handleChanges('editRenderingProviderRangeEnd')}
                      variant="outlined"
                      inputProps={{ maxLength: 4 }}
                    />
                  </div>
                ) : null
                }
                {/* Range div end*/}
                {(props.values.editRenderingProviderRadio === 'Value') ? (
                  <div>
                    <div>
                      <span className="cndt-label">Rendering Provider Type Value</span>
                    </div>
                    <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
                      <TextField
                        id="standard-select-render-provd-type-value"
                        select
                        label=""
                        name="editRenderingProvdTypeValue"
                        value={props.values.editRenderingProvdTypeValue}
                        inputProps={{ maxLength: 2 }}
                        onChange={props.handleChanges('editRenderingProvdTypeValue')}
                        placeholder=""
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem selected key="Please Select One" value="Please Select One">
                          Please Select One
                    </MenuItem>
                    {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Provider#1448'].length > 0 && props.dropdowns['Provider#1448'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
                      </TextField>
                    </div>
                  </div>
                ) : null
                }
                {/* Value div end*/}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Next flex */}
      {/* Procedure Code */}
      <div className="flex-wrappers">
        <div className="flex-wrapper-item w-30">
          <div className="flex-header">Procedure Code</div>
          <div className="flex-content">
            <div className="sub-radio set-rd-pos">
              <input type="radio"
                value="Range"
                name="editProcCodeRadio"
                checked={props.values.editProcCodeRadio === "Range"}
                onChange={props.handleChanges('editProcCodeRadio')}
                className="ml-1"
              /><label className="text-black"> Range</label>
              <input type="radio"
                value="Value"
                name="editProcCodeRadio"
                checked={props.values.editProcCodeRadio === "Value"}
                onChange={props.handleChanges('editProcCodeRadio')}
                className="ml-1"
              /><label className="text-black">Value</label>
              <input type="radio"
                value="NA"
                name="editProcCodeRadio"
                checked={(!props.values.editProcCodeRadio) || (props.values.editProcCodeRadio === 'NA')}
                onChange={props.handleChanges('editProcCodeRadio')}
                className="ml-1"
              />
              <label className="text-black">NA</label>
            </div>
            {/* div sub radio end */}
            {/* Range div */}
            {(props.values.editProcCodeRadio === 'Range') ? (
              <div>
                <div>
                  <div>
                    <span className="cndt-label">Procedure Code Range</span>
                  </div>
                  <TextField
                    name="editProcCodeRangeStart"
                    label=""
                    value={props.values.editProcCodeRangeStart}
                    onChange={props.handleChanges('editProcCodeRangeStart')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  /><span className="text-black"> - </span>
                  <TextField
                    name="editProcCodeRangeEnd"
                    label=""
                    value={props.values.editProcCodeRangeEnd}
                    onChange={props.handleChanges('editProcCodeRangeEnd')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  />
                </div>
                {/* Modifier div start */}
                <div>
                  <span className="cndt-label">Modifier 1</span>
                </div>
                <div>
                  <TextField
                    name="editProcCodeRangeMod1"
                    label=""
                    value={props.values.editProcCodeRangeMod1}
                    onChange={props.handleChanges('editProcCodeRangeMod1')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  />
                </div>
                <div>
                  <span className="cndt-label">Modifier 2</span>
                </div>
                <div>
                  <TextField
                    name="editProcCodeRangeMod2"
                    label=""
                    value={props.values.editProcCodeRangeMod2}
                    onChange={props.handleChanges('editProcCodeRangeMod2')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  />
                </div>
                <div>
                  <span className="cndt-label">Modifier 3</span>
                </div>
                <div>
                  <TextField
                    name="editProcCodeRangeMod3"
                    label=""
                    value={props.values.editProcCodeRangeMod3}
                    onChange={props.handleChanges('editProcCodeRangeMod3')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  />
                </div>
                <div>
                  <span className="cndt-label">Modifier 4</span>
                </div>
                <div>
                  <TextField
                    name="editProcCodeRangeMod4"
                    label=""
                    value={props.values.editProcCodeRangeMod4}
                    onChange={props.handleChanges('editProcCodeRangeMod4')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  />
                </div>
              </div>
            ) : null
            }
            {/* Range div end*/}
            {(props.values.editProcCodeRadio === 'Value') ? (
            <div>
            
            <div>
              <span className="cndt-label">Procedure Code Value</span>
            </div>
            <div>
              <TextField
                name="editProcCodeValue"
                label=""
                value={props.values.editProcCodeValue}
                onChange={props.handleChanges('editProcCodeValue')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Modifier div start */}
            <div>
              <span className="cndt-label">Modifier 1</span>
            </div>
            <div>
              <TextField
                name="editProcCodeValueMod1"
                label=""
                value={props.values.editProcCodeValueMod1}
                onChange={props.handleChanges('editProcCodeValueMod1')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
              <span className="cndt-label">Modifier 2</span>
            </div>
            <div>
              <TextField
                name="editProcCodeValueMod2"
                label=""
                value={props.values.editProcCodeValueMod2}
                onChange={props.handleChanges('editProcCodeValueMod2')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
              <span className="cndt-label">Modifier 3</span>
            </div>
            <div>
              <TextField
                name="editProcCodeValueMod3"
                label=""
                value={props.values.editProcCodeValueMod3}
                onChange={props.handleChanges('editProcCodeValueMod3')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
              <span className="cndt-label">Modifier 4</span>
            </div>
            <div>
              <TextField
                name="editProcCodeValueMod4"
                label=""
                value={props.values.editProcCodeValueMod4}
                onChange={props.handleChanges('editProcCodeValueMod4')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            </div>
            ):null
            }
            {/* Value div end*/}
          </div>
        </div>
        {/* Diagnosis Code */}
        <div className="flex-wrapper-item w-30">
          <div className="flex-header">Diagnosis Code</div>
          <div className="flex-content">
            <div className="sub-radio set-rd-pos">
              <input type="radio"
                value="Range"
                name="editDiagCodeRadio"
                checked={props.values.editDiagCodeRadio === "Range"}
                onChange={props.handleChanges('editDiagCodeRadio')}
                className="ml-1"
              /><label className="text-black"> Range</label>
              <input type="radio"
                value="Value"
                name="editDiagCodeRadio"
                checked={props.values.editDiagCodeRadio === "Value"}
                onChange={props.handleChanges('editDiagCodeRadio')}
                className="ml-1"
              /><label className="text-black">Value</label>

              <input type="radio"
                value="NA"
                name="editDiagCodeRadio"
                checked={(!props.values.editDiagCodeRadio) || (props.values.editDiagCodeRadio === 'NA')}
                onChange={props.handleChanges('editDiagCodeRadio')}
                className="ml-1"
              />
              <label className="text-black">NA</label>
            </div>
            {/* div sub radio end */}
            {/* Range div */}
            {(props.values.editDiagCodeRadio === 'Range') ? (
            <div>
              <div>
                <span className="cndt-label">Diagnosis Code Range</span>
              </div>
              <TextField
                name="editDiagCodeRangeStart"
                label=""
                value={props.values.editDiagCodeRangeStart}
                onChange={props.handleChanges('editDiagCodeRangeStart')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              /><span className="text-black"> - </span>
              <TextField
                name="editDiagCodeRangeEnd"
                label=""
                value={props.values.editDiagCodeRangeEnd}
                onChange={props.handleChanges('editDiagCodeRangeEnd')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            ):null
            }
            {/* Range div end*/}
            {(props.values.editDiagCodeRadio === 'Value') ? (
            <div>
              <span className="cndt-label">Diagnosis Code Value</span>
            
              <TextField
                name="editDiagCodeValue"
                label=""
                value={props.values.editDiagCodeValue}
                onChange={props.handleChanges('editDiagCodeValue')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            ):null
            }
            {/* Value div end*/}
          </div>
        </div>
        {/* Surgical Procedure Code */}
        <div className="flex-wrapper-item w-30">
          <div className="flex-header">Surgical Procedure Code</div>
          <div className="flex-content">
            <div className="sub-radio set-rd-pos">
              <input type="radio"
                value="Range"
                name="editSurgProcCodeRadio"
                checked={props.values.editSurgProcCodeRadio === "Range"}
                onChange={props.handleChanges('editSurgProcCodeRadio')}
                className="ml-1"
              /><label className="text-black"> Range</label>
              <input type="radio"
                value="Value"
                name="editSurgProcCodeRadio"
                checked={props.values.editSurgProcCodeRadio === "Value"}
                onChange={props.handleChanges('editSurgProcCodeRadio')}
                className="ml-1"
              /><label className="text-black">Value</label>
              <input type="radio"
                value="NA"
                name="editSurgProcCodeRadio"
                checked={(!props.values.editSurgProcCodeRadio) || (props.values.editSurgProcCodeRadio === 'NA')}
                onChange={props.handleChanges('editSurgProcCodeRadio')}
                className="ml-1"
              />
              <label className="text-black">NA</label>
            </div>
            {/* div sub radio end */}
            {/* Range div */}
            {(props.values.editSurgProcCodeRadio === 'Range') ? (
            <div>
              <div>
                <span  className="cndt-label">Surgical Procedure Code Range</span>
              </div>
              <TextField
                name="editSurgProcCodeRangeStart"
                label=""
                value={props.values.editSurgProcCodeRangeStart}
                onChange={props.handleChanges('editSurgProcCodeRangeStart')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              /><span className="text-black"> - </span>
              <TextField
                name="editSurgProcCodeRangeEnd"
                label=""
                value={props.values.editSurgProcCodeRangeEnd}
                onChange={props.handleChanges('editSurgProcCodeRangeEnd')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            ):null
            }
            {/* Range div end*/}
            {(props.values.editSurgProcCodeRadio === 'Value') ? (
              <div>
            <div>
              <span className="cndt-label">Surgical Procedure Code Value</span>
            </div>
            <div>
              <TextField
                name="editSurgProcCodeValue"
                label=""
                value={props.values.editSurgProcCodeValue}
                onChange={props.handleChanges('editSurgProcCodeValue')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            </div>
            ):null
            }
            {/* Value div end*/}
          </div>
        </div>
      </div>
    </form >
  );
}
