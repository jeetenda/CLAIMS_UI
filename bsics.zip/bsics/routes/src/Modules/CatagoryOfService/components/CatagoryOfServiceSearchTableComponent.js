import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';
import * as CatagoryOfServiceConstants from './CatagoryOfServiceConstants';
import { useDispatch, useSelector } from 'react-redux';
import { cosCriteriaEachSearchAction } from '../actions';

const headCells = [

  {
    id: 'lobCodeDesc', numeric: false, disablePadding: true, label: 'LOB', enableHyperLink: true, fontSize: 12, width: '150px'
  },
  {
    id: 'categoryOfServiceCodeDesc', numeric: false, disablePadding: false, label: 'COS', enableHyperLink: false, fontSize: 12, width: '150px'
  },
  {
    id: 'claimFormCodeDesc', numeric: false, disablePadding: false, label: 'Claim Form', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'claimTypeCodeDesc', numeric: false, disablePadding: false, label: 'Claim Type', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'headerLineAssignCodeDesc', numeric: false, disablePadding: true, label: 'Assign To', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'beginDate-endDate', numeric: false, isDate: true, disablePadding: true, label: 'Beg Date-End Date', enableHyperLink: false, fontSize: 12
  },
  
  {
    id: 'beginBillingProviderTypeCode', numeric: false, disablePadding: true, label: 'Provider Type', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'beginProcedureCode', numeric: false, disablePadding: true, label: 'Proc Code', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'beginDiagnosisCode', numeric: false, disablePadding: true, label: 'Diag Code', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'beginSurgicalProcedureCode', numeric: false, disablePadding: true, label: 'Surg Proc Code', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'defaultIndicator', numeric: false, disablePadding: true, label: 'Default', enableHyperLink: false, fontSize: 12
  },
  {
    id: 'rankNumber', numeric: false, disablePadding: true, label: 'Rank', enableHyperLink: false, fontSize: 12
  }
];

function CatagoryOfServiceSearchTableComponent(props) {
  const errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(false);

  const eachRecord = useSelector(state => state.catagoryOfSvc.eachRecord);
  const eachTime = useSelector(state => state.catagoryOfSvc.eachTime);

  const dispatch = useDispatch();
  const getEachSearch = (searchValue) => dispatch(cosCriteriaEachSearchAction(searchValue));

  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);

  useEffect(() => {
    console.log(eachRecord);
    if(eachRecord != null && props.redirect ){
      props.setRedirect(false);
      props.setspinnerLoader(false);
      if (eachRecord.message === null || eachRecord.message === undefined) {
        props.history.push({
          pathname: '/CategoryofSvcEdit',
          state: { eachRecord }
        });
      } else {
        errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
        props.seterrorMessages(errorMessagesArray)
      }
    }
    else if(eachRecord == null && props.redirect ){
      props.setspinnerLoader(false);
      errorMessagesArray.push(CatagoryOfServiceConstants.NO_DATA_FOUND);
      props.seterrorMessages(errorMessagesArray)
    }
  },[eachTime]);


  const editRow = row => (event) => {
    // props.setEditAddValues(row);
    // props.setResetValues(row);
    // props.setShowAddForm(true);
    // props.setFormEditorAddType("edit");
    props.setRedirect(true);
    props.setspinnerLoader(true);
    getEachSearch(Number(row.categoryOfServiceSK));
  };

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data);
      tData = JSON.parse(tData);
      tData.map((each, index) => {

        each.lobCodeDesc = each.lobCodeDesc;
        each.categoryOfServiceCodeDesc = each.categoryOfServiceCodeDesc ==null ? "" : each.categoryOfServiceCodeDesc ;
        each.claimFormCodeDesc = each.claimFormCodeDesc==null ? "" :each.claimFormCodeDesc;
        each.claimTypeCodeDesc = each.claimTypeCodeDesc ==null ? "" : each.claimTypeCodeDesc ;
        each.headerLineAssignCodeDesc = each.headerLineAssignCodeDesc ==null ? "" : each.headerLineAssignCodeDesc ;
        each["beginDate-endDate"] = each["beginDate-endDate"]==null ? "" :each.beginDate-endDate;
        each.beginBillingProviderTypeCode = each.beginBillingProviderTypeCode==null ? "" :each.beginBillingProviderTypeCode;
        each.beginProcedureCode = each.beginProcedureCode==null ? "" :each.beginProcedureCode;
        each.beginDiagnosisCode = each.beginDiagnosisCode ==null ? "" : each.beginDiagnosisCode ;
        each.beginSurgicalProcedureCode =  each.beginSurgicalProcedureCode ==null ? "" : each.beginSurgicalProcedureCode;
        each.defaultIndicator = each.defaultIndicator ==null ?"" :each.defaultIndicator;
        each.rankNumber = each.rankNumber ==null ?"":each.rankNumber;
        each.index = index;
      });

      return tData;

    } else {
      return [];
    }
  }

  const tableComp = <TableComponent headCells={headCells} tableData={props.tableData ? getTableData(props.tableData) : []} onTableRowClick={editRow} defaultSortColumn="lobCodeDesc" />;

  return (
    //tableComp
    showTable ? tableComp : null
  );
}
export default withRouter(CatagoryOfServiceSearchTableComponent);
