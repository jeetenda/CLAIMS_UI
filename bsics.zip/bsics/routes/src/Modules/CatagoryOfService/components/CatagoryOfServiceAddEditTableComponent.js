import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';

const headCells = [
    {
      id: 'beginDate', numeric: false, disablePadding: true, label: 'Begin Date', enableHyperLink: true, width: 250, fontSize: 12
    },
    {
      id: 'endDate', numeric: false, disablePadding: false, label: 'End Date', enableHyperLink: false, width: 250, fontSize: 12
    },
    {
      id: 'pendControl', numeric: false, disablePadding: false, label: 'Pend Control', enableHyperLink: false, width: 400, fontSize: 12
    },
    {
      id: 'familyPlanning', numeric: false, disablePadding: false, label: 'Family Planning', enableHyperLink: false, width: 400, fontSize: 12
    },
    {
      id: 'gender', numeric: false, disablePadding: false, label: 'Gender', enableHyperLink: false, width: 250, fontSize: 12
    },
    {
      id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date', enableHyperLink: false, width: 250, fontSize: 12
    }
  ];

function diagnosisCodeEditTableComponent(props) {
  const errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(false);
  
  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);
  


  const editRow = row => (event) => {
    
  };
  const tableComp = <TableComponent headCells={headCells}  tableData={props.tableData ? props.tableData : []} defaultSortColumn="diagnosisCode" />;
  // onTableRowClick={editRow}
  return (
    showTable ? tableComp : null

  );
}
export default withRouter(diagnosisCodeEditTableComponent);
