import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import * as CatagoryOfServiceConstants from './CatagoryOfServiceConstants';

export default function CatagoryOfServiceSearchForm(props) {
  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        <div className="mui-custom-form with-select input-md">
          <TextField
            id="lob-cos"
            select
            label="LOB"
            name="searchLob"
            value={props.values.searchLob}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('searchLob')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Reference#1019'].length > 0 && props.dropdowns['Reference#1019'].map( each => (
               <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
            ))}
            {/* <MenuItem selected key="MED-Medicaid" value="MED">MED-Medicaid</MenuItem> */}
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md">
          <TextField
            id="cos-cos"
            select
            label="Category Of Service"
            name="searchCos"
            value={props.values.searchCos}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('searchCos')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Claims#1020'].length > 0 && props.dropdowns['Claims#1020'].map( each => (
               <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
            ))}
            {/* <MenuItem selected key="001-InpHspGen" value="001">001-InpHspGen</MenuItem>
            <MenuItem selected key="003-InpHspMent" value="003">003-InpHspMent</MenuItem> */}
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md">
          <TextField
            id="claim-type-cos"
            select
            label="Claim Type"
            name="searchClaimType"
            value={props.values.searchClaimType}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('searchClaimType')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Claims#1038'].length > 0 && props.dropdowns['Claims#1038'].map( each => (
               <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
            ))}
            {/* <MenuItem selected key="C-Capitation" value="C">C-Capitation</MenuItem>
            <MenuItem selected key="D-Dental" value="D">D-Dental</MenuItem>
            <MenuItem selected key="F-Fin Tran" value="F">F-Fin Tran</MenuItem>
            <MenuItem selected key="I-Inpatient" value="I">I-Inpatient</MenuItem>
            <MenuItem selected key="M-Medical" value="M">M-Medical</MenuItem>
            <MenuItem selected key="P-Pharmacy" value="P">P-Pharmacy</MenuItem>
            <MenuItem selected key="O-Outpatient" value="O">O-Outpatient</MenuItem>
            <MenuItem selected key="Z-Void Req" value="Z">Z-Void Req</MenuItem> */}
          </TextField>
        </div>

      </div>
      <div className="float-right th-btnGroup mr-3 mb-3">
        <Button
          title="Search"
          variant="outlined"
          color="primary"
          className="btn btn-ic btn-search"
          onClick={props.searchCheck}
          disabled={props.privileges && !props.privileges.update? 'disabled':''}
          
        >
          {' '}
          Search
          {' '}

        </Button>
        <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset"  onClick={props.resetTable}>
              Reset
            </Button>
      </div>
      <div className="clearfix" />
      <div className="tabs-container">

      </div>
    </form>
  );
}
