import React, { useState, useEffect, useRef } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import * as CatagoryOfServiceConstants from './CatagoryOfServiceConstants';
import { catagoryOfServiceGetAllSearchAction, catagoryOfServiceCriteriaSearchAction, cosDeleteAction, createCosAction, editCosAction, cosDropdowns, cosDataElementDropdowns } from '../actions';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import CatagoryOfServiceSearchForm from './CatagoryOfServiceSearchForm';
import CatagoryOfServiceAddForm from './CatagoryOfServiceAddForm';
import CatagoryOfServiceSearchTableComponent from './CatagoryOfServiceSearchTableComponent';
import AdditionalCritiriaTable from './AdditionalCritiriaTable';
import AdditionalCriteriaForm from './AdditionalCriteriaForm';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import dateFnsFormat from "date-fns/format";
import { compareTwoDates } from '../../../SharedModules/DateUtilities/DateUtilities';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import SuccessComponent from "../../../SharedModules/Errors/TimeOutSuccessMsg";
import ErrorComponent from "../../../SharedModules/Errors/TimeOutErrorMsg";
import * as moment from "moment";
import "moment-range";
import AuditLog from "../../../SharedModules/AuditLog/AuditLog";
import AuditLogRow from "../../../SharedModules/AuditLog/AuditLogRow";
import NavigationPrompt from "react-router-navigation-prompt";
import {getAuditLogDataAction } from '../../../SharedModules/AuditLog/actions';
import * as AuditConstant from '../../../SharedModules/AuditLog/AuditLogConstants';
import {getLoginUserDetails} from "../../../SharedModules/utility/utilityFunction";

function CategoryOfServiceEdit(props) {
  const auditRef = useRef();
  const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });

  const editadditionalcriteria = useRef(null);

    let errorMessagesArray = [];
    const [prompt, setPrompt] = useState(false);

    const [cancelType, setCancelType] = useState(false);
    const [confirm, setConfirm] = useState(false);
      const createStatus = useSelector(state => state.catagoryOfSvc.createStatus);
      const createStatusTime = useSelector(state => state.catagoryOfSvc.createStatusTime);
      const [editAddValues, setEditAddValues] = useState(props.location.state.eachRecord);
      const [spinnerLoader, setspinnerLoader] = React.useState(false);
      // const [successMessage, setSuccessMessage] = useState(null);
      const [successMessages, setSuccessMessages] = React.useState([]);
      const [errorMessages, seterrorMessages] = React.useState([]);
      const [dialogOpen, setDialogOpen] = useState(false);
      const [dialogType, setDialogType] = useState("");
      const [formEditorAddType, setFormEditorAddType] = useState('edit');
      const [additionalEditorAddType, setAdditionalEditorAddType] = useState('add');
      const searchDropdowns = useSelector(state => state.catagoryOfSvc.dropdowns);
      const [additionalCriteriaShow, setAdditionalCriteriaShow] = useState(false);
      const onCreateCos = searchValues => dispatch(createCosAction(searchValues));
      const [additionalCriteriatableData, setAddCritTableData] = useState([]);
      const onEditCos = searchValues => dispatch(editCosAction(searchValues));
      const deleteStatus = useSelector(state => state.catagoryOfSvc.deleteStatus);
      const deleteStatusTime = useSelector(state => state.catagoryOfSvc.deleteStatusTime);
      const getAllSearch = searchvalues => dispatch(catagoryOfServiceGetAllSearchAction(searchvalues));
      const getCriteriaSearch = searchValues => dispatch(catagoryOfServiceCriteriaSearchAction(searchValues));
      const updateStatus = useSelector(state => state.catagoryOfSvc.updateStatus);
      const updateStatusTime = useSelector(state => state.catagoryOfSvc.updateStatusTime);
      const [minorsuccessMessage, setMinorSuccessMessage] = useState(null);
      const printRef = useRef();
      const [additionalCritiriaFormData, setAdditionalCritiriaFormData] = useState({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '',valueData: '' });
      const [additionalCritiriaResetData, setAdditionalCritiriaResetData] = useState({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '',valueData:'' });  
      const [{ lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError,
          showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError,
          beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError,
          beginRenderingProviderTypeError, beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError, renderingProviderTypeValueError,
          beginProcedureCodeError, beginProcedureCodeFormatError, endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError,
          beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
          beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError,beginDtInvalidErr, endDtInvalidErr  },
          setShowError] = React.useState(false);
      const [selectDeleteArray, setSelectDeleteArray] = useState([]);
      const [{ showAddCritbeginError, showAddCritEndError, showValueError }, setAddCritErrors] = useState(false);
      const [showAuditLog, setShowAuditLog] = useState(false);
      const auditLogData = useSelector(state => state.AuditLog && state.AuditLog.auditLogData ? state.AuditLog.auditLogData : null);
      const auditLogDetailData = useSelector(state => state.AuditLog && state.AuditLog.auditLogDetailData? state.AuditLog.auditLogDetailData : null);

      const cosDelete = searchValues => { return dispatch(cosDeleteAction(searchValues)) };
      
  const getAuditLogData = (data, type) => dispatch(getAuditLogDataAction(data, type));
  const [auditLogDataList, setAuditLogDataList] = useState([]);
  const [addCritAuditLogDataList, setAddCritAuditLogDataList] = useState([]);

  const [values, setValues] = useState({
    searchClaimType : '-1',
    searchCos :'-1',
    searchLob :'-1'

  });

  useEffect(() => {
    setspinnerLoader(false);
    setAuditLogDataList(auditLogData && auditLogData.responseAuditLogDetails ? auditLogData.responseAuditLogDetails : []);
  }, [auditLogData]);
  useEffect(() => {
    setspinnerLoader(false);
    setAddCritAuditLogDataList(auditLogDetailData && auditLogDetailData.responseAuditLogDetails ? auditLogDetailData.responseAuditLogDetails : []);

  }, [auditLogDetailData]);
  const onAuditLog = (auditLogVal, scroll) => {
    if (auditLogVal) {
      let obj = {
        "tableName": "r_cos_asgn_tb",
        "keyValue": {
          "r_cos_asgn_sk": editAddValues.categoryOfServiceSK
        }
      }
      if (scroll) {
        setTimeout(function () {
          scrollToRef(auditRef);
        }.bind(this), 1000);

      }
      getAuditLogData(obj, AuditConstant.PAGE_LEVEL);
    }
  }
  const additionalCriteriaAuditLog = (seqnum = '') => {

    let obj = {
      "tableName": "r_cos_asgn_dtl_tb",
      "keyValue": {
        "r_cos_asgn_sk": editAddValues.categoryOfServiceSK,
        "r_cos_asgn_dtl_seq_num": seqnum
      }
    }
    getAuditLogData(obj, AuditConstant.TAB_LEVEL);

  }

      const handelPromptSet = (set) => {
        if (set) setPrompt(true);
      };

      const handleAdditionalcriteriaChanges = name => (event) => {
          setAdditionalCritiriaFormData({ ...additionalCritiriaFormData, [name]: event.target.value });
      };
      const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        dt = new Date(dt);
        if (dt.toString() == "Invalid Date") {
            return dt;
        } else {
            return dateFnsFormat(dt, "yyyy-MM-dd");
        }
      };
      const dispatch = useDispatch();
      const onDropdowns = (values) => dispatch(cosDropdowns(values));
      const onDataElementDropdowns = (values) => dispatch(cosDataElementDropdowns(values));
      useEffect(() => {
        onDropdowns({
          "inputList" : [Dropdowns.LOB,
            Dropdowns.CATEGORY_OF_SERVICE,
            Dropdowns.CLAIM_FORM,
            Dropdowns.CLAIM_TYPE,
            Dropdowns.ASSIGN_TO,
            Dropdowns.PROVIDER_ID_TYPE,
            Dropdowns.BILLING_PROVIDER_ID_TYPE
          ]
        });
        onDataElementDropdowns(Dropdowns.DATA_ELEMENT_CRITERIA_COS);
        let temp1 = props.location.state.eachRecord;
        // temp1.map((each, index) => {
        //   each.rowIndex = index;
        // });
        let table = [];
        if (temp1.additionalCriteriaList && temp1.additionalCriteriaList.length > 0) {
          temp1.additionalCriteriaList.map(each => {
            table.push({ timeStamp: new Date(), dataElementCriteria: each.additionalColName, range: 'Range', beginValueData: each.beginValueData, endValueData: each.endValueData,cosAsgnSeqNumber:each.cosAsgnSeqNumber });
          });
        }
        setEditAddValues({
                  ...temp1,
                  billProviderType: temp1.beginBillingProviderTypeCode ? 'Range' : '',
                  renderingProviderType: temp1.beginRenderingProviderTypeCode ? 'Range' : '',
                  procedureCodeType: temp1.beginProcedureCode ? 'Range' : '',
                  diagCodeType: temp1.beginDiagnosisCode ? 'Range' : '',
                  surgProcCodeType: temp1.beginSurgicalProcedureCode ? 'Range' : ''
                });
        setAddCritTableData(table);
      }, []);
      const dataElementDropdowns = useSelector(state => state.catagoryOfSvc.deDropdowns);
    
        const handelDateChange = (name, date) => {
          setEditAddValues({ ...editAddValues, [name]: formatDate(date)});
        }
  
        const handelEditAddAchanges = name => (event) => {
          if (event.target.type === 'checkbox') {
            setEditAddValues({ ...editAddValues, [name]: event.target.checked });
          } else {
            setEditAddValues({ ...editAddValues, [name]: event.target.value });
          }
        }
      
  
        const addUpdateSave = () => {
          const addcittabledata = additionalCriteriatableData;
          let transaddcittabledata = [];
          let userDetails =  getLoginUserDetails();
          if (addcittabledata.length > 0) {
            addcittabledata.map(each => {
              transaddcittabledata.push({
                auditUserID: userDetails.loginUserName,
                auditTimeStamp: new Date(),
                addedAuditUserID:  userDetails.loginUserName,
                addedAuditTimeStamp: new Date(),
                loginUserID:  userDetails.loginUserID,
                providerIdTypeCode: "10",
                versionNo: 0,
                dbRecord: false,
                sortColumn: "",
                additionalColName: each.dataElementCriteria,
                additionalColNameDesc: "",
                beginValueData: each.beginValueData,
                endValueData: each.endValueData
              });
            })
          }
          setShowError(false);
          setspinnerLoader(false);
          errorMessagesArray = [];
          seterrorMessages([]);
          setSuccessMessages([]);
          let lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError, showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError, beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError, beginRenderingProviderTypeError,
            beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError,
            renderingProviderTypeValueError, beginProcedureCodeError, beginProcedureCodeFormatError,
            endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError, beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
            beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError,beginDtInvalidErr, endDtInvalidErr;
          if (editAddValues.lobCode === "") {
            lobCodeError = true;
            errorMessagesArray.push(CatagoryOfServiceConstants.LOB_ERROR);
            seterrorMessages(errorMessagesArray);
          }
          if (editAddValues.categoryOfServiceCode === "-1") {
            cosCodeError = true;
            errorMessagesArray.push(CatagoryOfServiceConstants.COS_CODE_ERROR);
            seterrorMessages(errorMessagesArray);
          }
          if (editAddValues.headerLineAssignCode === "-1") {
            assignCodeError = true;
            errorMessagesArray.push(CatagoryOfServiceConstants.ASSIGN_CODE_ERROR);
            seterrorMessages(errorMessagesArray);
          }
          if (editAddValues.claimFormCode === "-1") {
            claimFormCodeError = true;
            errorMessagesArray.push(CatagoryOfServiceConstants.CLAIM_FORM_ERROR);
            seterrorMessages(errorMessagesArray);
          }
          if (editAddValues.claimTypeCode === "-1") {
            claimTypeCodeError = true;
            errorMessagesArray.push(CatagoryOfServiceConstants.CLAIM_TYPE_ERROR);
            seterrorMessages(errorMessagesArray);
          }
          if (editAddValues.beginDate === "" || editAddValues.endDate === "") {
            if (editAddValues.beginDate === "") {
              showBeginDateError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.BEGIN_DATE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            if (editAddValues.endDate === "") {
              showEndDateError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.END_DATE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          } else if (editAddValues.beginDate >= editAddValues.endDate) {
            if (editAddValues.beginDate >= editAddValues.endDate) {
              showDateError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.DATE_RANGE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          }else{
            beginDtInvalidErr = (editAddValues.beginDate.toString() == "Invalid Date" || moment(editAddValues.beginDate).isBefore('1964-01-01') )?(()=>{errorMessagesArray.push(CatagoryOfServiceConstants.Invalid_Begin_Date_Error);return true;})():false;
           
            endDtInvalidErr = (editAddValues.endDate.toString() == "Invalid Date" || moment(editAddValues.endDate).isBefore('1964-01-01'))?(()=>{errorMessagesArray.push(CatagoryOfServiceConstants.Invalid_End_Date_Error);return true;})():false;
            seterrorMessages(errorMessagesArray);
            
          }
          //Billing Provider Type Validations
          if (editAddValues.billProviderType === 'Range') {
            if (editAddValues.beginBillingProviderTypeCode === '' || editAddValues.beginBillingProviderTypeCode === undefined || editAddValues.beginBillingProviderTypeCode === null) {
              beginBillProviderTypeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_BEGIN_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.beginBillingProviderTypeCode)) {
              beginBillProviderTypeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            if (editAddValues.endBillingProviderTypeCode === '' || editAddValues.endBillingProviderTypeCode === undefined || editAddValues.endBillingProviderTypeCode === null) {
              endBillProviderTypeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_END_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.endBillingProviderTypeCode)) {
              endBillProviderTypeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          }
          else if (editAddValues.billProviderType === 'Value') {
            if (editAddValues.billProviderTypeValue === '' || editAddValues.billProviderTypeValue === undefined) {
              billProviderTypeValueError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_VALUE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            else {
              editAddValues.beginBillingProviderTypeCode = editAddValues.billProviderTypeValue;
              editAddValues.endBillingProviderTypeCode = editAddValues.billProviderTypeValue;
            }
          }
          //Rendering Provider Type Validations
          if (editAddValues.renderingProviderType === 'Range') {
            if (editAddValues.beginRenderingProviderTypeCode === '' || editAddValues.beginRenderingProviderTypeCode === undefined || editAddValues.beginRenderingProviderTypeCode === null) {
              beginRenderingProviderTypeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_BEGIN_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.beginRenderingProviderTypeCode)) {
              beginRenderingProviderTypeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            if (editAddValues.endRenderingProviderTypeCode === '' || editAddValues.endRenderingProviderTypeCode === undefined || editAddValues.endRenderingProviderTypeCode === null) {
              endRenderingProviderTypeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_END_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.beginRenderingProviderTypeCode)) {
              endRenderingProviderTypeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          }
          else if (editAddValues.renderingProviderType === 'Value') {
            if (editAddValues.renderingProviderTypeValue === '' || editAddValues.renderingProviderTypeValue === undefined || editAddValues.renderingProviderTypeValue === null) {
              renderingProviderTypeValueError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_VALUE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            else {
              editAddValues.beginRenderingProviderTypeCode = editAddValues.renderingProviderTypeValue;
              editAddValues.endRenderingProviderTypeCode = editAddValues.renderingProviderTypeValue;
            }
          }
          //Procedure Code Validations
          if (editAddValues.procedureCodeType === 'Range') {
            if (editAddValues.beginProcedureCode === '' || editAddValues.beginProcedureCode === undefined || editAddValues.beginProcedureCode === null) {
              beginProcedureCodeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.PROCEDURE_CODE_BEGIN_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.beginProcedureCode)) {
              beginProcedureCodeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            if (editAddValues.endProcedureCode === '' || editAddValues.endProcedureCode === undefined || editAddValues.endProcedureCode === null) {
              endProcedureCodeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.PROCEDURE_CODE_END_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.endProcedureCode)) {
              endProcedureCodeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          }
          else if (editAddValues.procedureCodeType === 'Value') {
            if (editAddValues.procCodeValue === '' || editAddValues.procCodeValue === undefined || editAddValues.procCodeValue === null) {
              procCodeValueError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.PROCEDURE_CODE_VALUE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            else {
              editAddValues.beginProcedureCode = editAddValues.procCodeValue;
              editAddValues.endProcedureCode = editAddValues.procCodeValue;
            }
          }
          //Diagnosis Code Validations
          if (editAddValues.diagCodeType === 'Range') {
            if (editAddValues.beginDiagnosisCode === '' || editAddValues.beginDiagnosisCode === undefined || editAddValues.beginDiagnosisCode === null) {
              beginDiagnosisCodeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.DIAGNOSIS_CODE_BEGIN_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.beginProcedureCode)) {
              beginDiagnosisCodeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            if (editAddValues.endDiagnosisCode === '' || editAddValues.endDiagnosisCode === undefined || editAddValues.endDiagnosisCode === null) {
              endDiagnosisCodeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.DIAGNOSIS_CODE_END_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.endDiagnosisCode)) {
              endDiagnosisCodeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          }
          else if (editAddValues.diagCodeType === 'Value') {
            if (editAddValues.diagCodeValue === '' || editAddValues.diagCodeValue === undefined || editAddValues.diagCodeValue === null) {
              diagnosisCodeValueError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.DIAGNOSIS_CODE_VALUE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            else {
              editAddValues.beginDiagnosisCode = editAddValues.diagCodeValue;
              editAddValues.endDiagnosisCode = editAddValues.diagCodeValue;
            }
          }
          //Surgical Procedure Code Validations
          if (editAddValues.surgProcCodeType === 'Range') {
            if (editAddValues.beginSurgicalProcedureCode === '' || editAddValues.beginSurgicalProcedureCode === undefined || editAddValues.beginSurgicalProcedureCode === null) {
              beginSurgProcedureCodeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_BEGIN_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.beginSurgicalProcedureCode)) {
              beginSurgProcedureCodeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            if (editAddValues.endSurgicalProcedureCode === '' || editAddValues.endSurgicalProcedureCode === undefined || editAddValues.endSurgicalProcedureCode === null) {
              endSurgProcedureCodeError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_END_ERROR);
              seterrorMessages(errorMessagesArray);
            } else if (!/^[0-9]+$/.test(editAddValues.endSurgicalProcedureCode)) {
              endSurgProcedureCodeFormatError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.INPUT_FORMAT_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          }
          else if (editAddValues.surgProcCodeType === 'Value') {
            if (editAddValues.surgProcCodeValue === '' || editAddValues.surgProcCodeValue === undefined || editAddValues.surgProcCodeValue === null) {
              surgProcedureCodeValueError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_VALUE_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            else {
              editAddValues.beginSurgicalProcedureCode = editAddValues.surgProcCodeValue;
              editAddValues.endSurgicalProcedureCode = editAddValues.surgProcCodeValue;
              // delete editAddValues.procedureCode;
              // delete editAddValues.procCodeValue;
            }
          }
          if (errorMessagesArray.length === 0) {
            let searchCriteria = {
              //New Request With Additional criteria
              "additionalCriteriaList": transaddcittabledata,
              "auditUserID":userDetails.loginUserName,
              "auditTimeStamp": new Date(),
              "addedAuditUserID": userDetails.loginUserName,
              "addedAuditTimeStamp": new Date(),
              "beginBillingProviderTypeCode": editAddValues.beginBillingProviderTypeCode ? editAddValues.beginBillingProviderTypeCode : "",
              "endBillingProviderTypeCode": editAddValues.endBillingProviderTypeCode ? editAddValues.endBillingProviderTypeCode : "",
              "beginRenderingProviderTypeCode": editAddValues.beginRenderingProviderTypeCode ? editAddValues.beginRenderingProviderTypeCode : "",
              "endRenderingProviderTypeCode": editAddValues.endRenderingProviderTypeCode ? editAddValues.endRenderingProviderTypeCode : "",
              "beginProcedureCode": editAddValues.beginProcedureCode ? editAddValues.beginProcedureCode : "",
              "endProcedureCode": editAddValues.endProcedureCode ? editAddValues.endProcedureCode : "",
              "beginDiagnosisCode": editAddValues.beginDiagnosisCode ? editAddValues.beginDiagnosisCode : "",
              "endDiagnosisCode": editAddValues.endDiagnosisCode ? editAddValues.endDiagnosisCode : "",
              "beginSurgicalProcedureCode": editAddValues.beginSurgicalProcedureCode ? editAddValues.beginSurgicalProcedureCode : "",
              "endSurgicalProcedureCode": editAddValues.endSurgicalProcedureCode ? editAddValues.endSurgicalProcedureCode : "",
              "beginDate": new Date(editAddValues.beginDate).toISOString().split('T')[0],
              "endDate": new Date(editAddValues.endDate).toISOString().split('T')[0],
              "billingProviderType": "",
              "categoryOfServiceCode": editAddValues.categoryOfServiceCode,
              "claimFormCode": editAddValues.claimFormCode,
              "headerLineAssignCode": editAddValues.headerLineAssignCode,
              "claimTypeCode": editAddValues.claimTypeCode,
              "categoryOfServiceSK": "",
              "categoryOfServiceDetailSet": [],
              "claimTypeList": [],
              "deletedAdditionalCriteriaSet": [],
              "defaultIndicator": editAddValues.defaultIndicator,
              "diagnosisCode": "",
              "loginUserID": userDetails.loginUserID,
              "lobCode": editAddValues.lobCode,
              "modifiedTimeStamp": "",
              "overRideAddedAuditTS": false,
              "procedureCode": "",
              "procedureModifier1": editAddValues.procedureModifier1 ? editAddValues.procedureModifier1 : "",
              "procedureModifier2": editAddValues.procedureModifier2 ? editAddValues.procedureModifier2 : "",
              "procedureModifier3": editAddValues.procedureModifier3 ? editAddValues.procedureModifier3 : "",
              "procedureModifier4": editAddValues.procedureModifier4 ? editAddValues.procedureModifier4 : "",
              "procedureModifierCode1": editAddValues.procedureModifierCode1 ? editAddValues.procedureModifierCode1 : "",
              "procedureModifierCode2": editAddValues.procedureModifierCode2 ? editAddValues.procedureModifierCode2 : "",
              "procedureModifierCode3": editAddValues.procedureModifierCode3 ? editAddValues.procedureModifierCode3 : "",
              "procedureModifierCode4": editAddValues.procedureModifierCode4 ? editAddValues.procedureModifierCode4 : "",
              "rankNumber": editAddValues.rankNumber ? editAddValues.rankNumber : 0,
              "renderingProviderType": "",
              "surgicalProcedureCode": "",
              "usedIndicator": true,
              "versionNo": editAddValues.versionNo ? editAddValues.versionNo : 1
      
      
              //End new request with add criteria
      
      
            }
            searchCriteria.categoryOfServiceSK = String(editAddValues.categoryOfServiceSK);
            searchCriteria.usedIndicator = true;
            searchCriteria.versionNo = Number(editAddValues.versionNo);
            setspinnerLoader(true);
            onEditCos(searchCriteria);
      
          }
      
          setShowError({
            lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError, showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError, beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError, beginRenderingProviderTypeError,
            beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError,
            renderingProviderTypeValueError, beginProcedureCodeError, beginProcedureCodeFormatError,
            endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError, beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
            beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError,beginDtInvalidErr, endDtInvalidErr
          })
        }
  
        useEffect(() => {
            setspinnerLoader(false);
            if (updateStatus && updateStatus.message != null) {
              errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
              seterrorMessages(errorMessagesArray);
            }
            if (updateStatus !== null && updateStatus !== undefined) {
              if (updateStatus === true) {
                // setShowAddForm(false);
                // setEditAddValues({});
                setSuccessMessages(["Category Of Service Updated succesfully"]);
                searchReuse();
                if(showAuditLog){
                  onAuditLog(showAuditLog,false)
                }
              } else if (updateStatus === false) {
                errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
                seterrorMessages(errorMessagesArray);
              }
            }
          }, [updateStatusTime]);

          const searchReuse = () => {
            let searchCriteria = {};
            if (!(values.searchLob === '' && values.searchCos === '' && values.searchClaimType === '')) {
              searchCriteria = {
                lobCode: values.searchLob==='-1'?'':values.searchLob,
                categoryOfServiceCode: values.searchCos==='-1'?'':values.searchCos,
                claimTypeCode: values.searchClaimType==='-1'?'':values.searchClaimType
              }
              getCriteriaSearch(searchCriteria);
            } else {
              getAllSearch();
            }
          }
  
      const saveAdditionalCriteria = () => {
          setAddCritErrors({});
          let showAddCritbeginError;
          let showValueError;
          let showAddCritEndError;
          if (additionalCritiriaFormData.range === 'Range' && additionalCritiriaFormData.valueData == '') {
            if (additionalCritiriaFormData.beginValueData === '') {
              showAddCritbeginError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR);
              seterrorMessages(errorMessagesArray);
            }
            if (additionalCritiriaFormData.endValueData === '') {
              showAddCritEndError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.ADD_CRIT_END_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          } else {
            if (additionalCritiriaFormData.valueData === '') {
              showValueError = true;
              errorMessagesArray.push(CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR);
              seterrorMessages(errorMessagesArray);
            }
          }
          if (errorMessagesArray.length === 0) {
            const table = additionalCriteriatableData;
            if(additionalCritiriaFormData.range==='Value'  || additionalCritiriaFormData.valueData != ''){
              additionalCritiriaFormData.beginValueData=additionalCritiriaFormData.valueData;
              // additionalCritiriaFormData.endValueData=additionalCritiriaFormData.valueData;
            }
            let data = {
              dataElementCriteria: additionalCritiriaFormData.dataElementCriteria,
              providerIdType: additionalCritiriaFormData.providerIdType,
              range: 'Range', 
              beginValueData: additionalCritiriaFormData.beginValueData,
              endValueData: additionalCritiriaFormData.endValueData, 
              valueData: additionalCritiriaFormData.valueData,
              cosAsgnSeqNumber: additionalCritiriaFormData.cosAsgnSeqNumber,
              timeStamp: additionalCritiriaFormData.timeStamp,
              versionNo: additionalCritiriaFormData.versionNo ? additionalCritiriaFormData.versionNo : 0,
            }
            additionalCritiriaFormData.index > -1
              ? (table[additionalCritiriaFormData.index] = data)
              : table.push(data)
            // if (additionalEditorAddType === 'add') {
            //   table.push(additionalCritiriaFormData);
            //   setAddCritTableData(table);
            // } else {//edit
              
            //   // const change = table.filter(each => each.timeStamp !== additionalCritiriaFormData.timeStamp);
            //   // table.push(additionalCritiriaFormData);
            //   // setAddCritTableData(table);
            // }
            setMinorSuccessMessage(["system succesfully saved the information"]);
            setAdditionalCriteriaShow(false);
            setAdditionalCritiriaResetData({ timeStamp: '', dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '', valueData:'' });
            setAdditionalCritiriaFormData({ timeStamp: '', dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '',valueData:'' });      
          } else {
            setAddCritErrors({
              showAddCritbeginError,
              showAddCritEndError,
              showValueError
            });
          }
        }

        const deleteAdditionalCriteria = (deleteTime) => {
          const table = additionalCriteriatableData;
          const deletedata = table.filter(each => String(each.timeStamp) === String(deleteTime));
          const change = table.filter(each => String(each.timeStamp) !== String(deleteTime));
          if (deletedata[0].type === 'old') {
            const deletetable = deleteAddCrit;
            deletetable.push({
              auditUserID: "wf_NH_MC_CLM_TY_ASGNMNTV5",
              addedAuditUserID: "SDRESSLER",
              additionalColName: deletedata[0].dataElementCriteria,
              beginValueData: deletedata[0].beginValueData,
              endValueData: deletedata[0].endValueData
            });
            setDeleteAddCrit(deletetable);
          }
          setAddCritTableData(change);
          setSuccessMessage('system succesfully saved the information');
          setAdditionalCriteriaShow(false);
          setAdditionalCritiriaResetData({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '' });
          setAdditionalCritiriaFormData({ dataElementCriteria: '', range: 'Range', beginValueData: '', endValueData: '' });
        }
  
        const multiDelete = () => {
          setDialogOpen(false);
          setDialogType("");
          seterrorMessages([]);
          setSuccessMessages([]);
          if (selectDeleteArray.length > 0) {
            let CI = additionalCriteriatableData;
            selectDeleteArray.map((value, index) => {
              let curIndex = CI.findIndex((i) =>
              moment(i.beginValueData).isSame(value.beginValueData)
              );
              CI.splice(curIndex, 1);
            });
            setAddCritTableData(CI);
            setSelectDeleteArray([]);
          }
        };
  
        const searchCategoryOfService = () => {
          
          props.history.push({
            pathname: '/CategoryofSvcAssignment'

          })
        }

        const deletecos = () => {
          cosDelete({ 
            categoryOfServiceSK: editAddValues.categoryOfServiceSK//, 
            //"auditUserID": editAddValues.auditUserID ? editAddValues.auditUserID : "" 
          });
          setDialogOpen(false);
          setspinnerLoader(true);
          setAddCritTableData([]);
          setAdditionalCritiriaFormData([]);
        }

        useEffect(() => {
          setspinnerLoader(false);
          if (deleteStatus && deleteStatus.message != null) {
            errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
            seterrorMessages(errorMessagesArray);
          }
          if (deleteStatus !== null && deleteStatus !== undefined) {
            if (deleteStatus === true) {
              setShowAddForm(false);
              setEditAddValues({});
              setSuccessMessages(['Category Of Service deleted succesfully']);
              searchReuse();
            } else if (deleteStatus === false) {
              errorMessagesArray.push(CatagoryOfServiceConstants.ERROR_OCCURED_DURING_TRANSACTION);
              seterrorMessages(errorMessagesArray);
            }
          }
        }, [deleteStatusTime]);

      
  
        return (
          // pos-relative div start
      
          <div className="pos-relative">
            {spinnerLoader ? <Spinner /> : null}
        {/* {errorMessages.length > 0 ? (
          <div className="alert alert-danger custom-alert hide-on-print" role="alert">
            {errorMessages.map(message => <li>{message}</li>)
            }
          </div>
        ) : null
        } */}
      {errorMessages.length > 0 ? (
        <ErrorComponent
          errorMessages={errorMessages}
          setErrorMessages={seterrorMessages}
        />
      ) : null}
      {/* {successMessages.length > 0 ? (
          <div className="alert alert-success custom-alert hide-on-print" role="alert">
            {successMessages.map(message => <li>{message}</li>)
            }
          </div>
        ) : null
        } */}
      {successMessages.length > 0 ? (
        <SuccessComponent
          successMessages={successMessages}
          setSuccessMessages={setSuccessMessages}
        />
      ) : null}
      
      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to delete?
            </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            title="Ok"
            onClick={() => {
              dialogType == "multiDelete" ? multiDelete() : 
              dialogType == "majorDelete"
              ? deletecos()
              : null;
            }}
           
            color="primary"
            className="btn btn-success"
          >
            Ok
            </Button>
          <Button
            title="Cancel"
            onClick={() => {
              setDialogOpen(false);
              setDialogType("");
            }}
            color="primary"
            autoFocus
          >
            Cancel
            </Button>
        </DialogActions>
      </Dialog>
      <div className="mb-2">
        <BreadCrumbs
          parent="Claims Configuration"
          child1="Category Of Service"
          child2="Edit Category of Service Assignment"
          path="CategoryOfSvcAssignment"
        />
      </div>
      {/* tabs-container div start */}
      <div className="tabs-container" ref={printRef}>

        <div className="tabs-container">
          <div className="tab-header">
            <h1 className="page-heading float-left">
              Category Of Service
                  </h1>
            <div className="float-right th-btnGroup">
              <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => addUpdateSave()} disabled={props.privileges && !props.privileges.update ? 'disabled' : ''}>
                Save
                        </Button>
              <Button title="Notes" variant="outlined" color="primary" className="btn btn-cancel" >
                Notes
              </Button>
              <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => {
                setDialogOpen(true);
                setDialogType("majorDelete");
              }} disabled={props.privileges && !props.privileges.update? 'disabled':''}>
                Delete
            </Button>
            <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => {searchCategoryOfService(); seterrorMessages([]);
          setSuccessMessages([]); }}>
                Cancel
              </Button>
              <Button title="Audit Log" variant="outlined" color="primary" 
              className={showAuditLog ? "btn btn-ic btn-audit selected":"btn btn-ic btn-audit"}
               onClick={() => {onAuditLog(!showAuditLog,true); setShowAuditLog(!showAuditLog); }}>Audit Log</Button>
              
              <ReactToPrint
                onBeforeGetContent={() => {
                  dispatch(setPrintLayout(true));
                  setspinnerLoader(true);
                  return new Promise((resolve) => setTimeout(() => resolve(), 100));
                }}
                onAfterPrint={() => {
                  setspinnerLoader(false);
                  dispatch(setPrintLayout(false))
                }
                }
                trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-primary">
                  <i className="fa fa-print" />
                Print
                </Button>)}
                content={() => printRef.current}
              />
              <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
                Help
              </Button>
            </div>

            <div className="clearfix" />
          </div>
          <div className="tab-body-bordered mt-2">
            {/* add form */}
            <CatagoryOfServiceAddForm values={editAddValues} handelDateChange={handelDateChange} handleChanges={handelEditAddAchanges} formEditorAddType={formEditorAddType} dropdowns={searchDropdowns}
              errors={{
                lobCodeError, cosCodeError, assignCodeError, claimFormCodeError, claimTypeCodeError, showBeginDateError, showEndDateError, showDateError, beginBillProviderTypeError, beginBillProviderTypeFormatError, endBillProviderTypeError, endBillProviderTypeFormatError, billProviderTypeValueError, beginRenderingProviderTypeError,
                beginRenderingProviderTypeFormatError, endRenderingProviderTypeError, endRenderingProviderTypeFormatError,
                renderingProviderTypeValueError, beginProcedureCodeError, beginProcedureCodeFormatError,
                endProcedureCodeError, endProcedureCodeFormatError, procCodeValueError, beginDiagnosisCodeError, beginDiagnosisCodeFormatError, endDiagnosisCodeError, endDiagnosisCodeFormatError, diagnosisCodeValueError,
                beginSurgProcedureCodeError, beginSurgProcedureCodeFormatError, endSurgProcedureCodeError, endSurgProcedureCodeFormatError, surgProcedureCodeValueError,beginDtInvalidErr, endDtInvalidErr
              }}
            />
            {/* Additional Criteria Start */}
            <div className="tabs-container m-3">
            { minorsuccessMessage ? (
        <div className="alert alert-success custom-alert">{minorsuccessMessage}</div>
      ) : null}
              <div className="tab-header">
                <h2 className="tab-heading float-left">
                  Additional Criteria
                      </h2>
                <div className="float-right th-btnGroup">
                  <Button
                    title="Delete"
                    variant="outlined"
                    disabled={selectDeleteArray.length == 0}
                    color="primary"
                    className="btn btn-transparent btn-icon-only"
                    onClick={() => {
                      setDialogOpen(true);
                      setDialogType("multiDelete");
                      setMinorSuccessMessage(false);
                    }}
                  >
                    <i className="fa fa-trash" />
                  </Button>
                  <Button title="Add additional criteria" variant="outlined" color="primary" className="btn btn-secondary btn-icon-only" onClick={() => {
                    setTimeout(function () {
                      scrollToRef(editadditionalcriteria);
                    }.bind(this), 1000);
                    setAdditionalCriteriaShow(true);
                    setAdditionalEditorAddType('add');
                    setMinorSuccessMessage(false);
                    setAdditionalCritiriaResetData({ timeStamp: new Date(), dataElementCriteria: 'Please Select One', range: 'Range', beginValueData: '', endValueData: '', Value: '', valueData: '',providerIdType: 'Please Select One' });
                    setAdditionalCritiriaFormData({ timeStamp: new Date(), dataElementCriteria: 'Please Select One', range: 'Range', beginValueData: '', endValueData: '', Value: '', valueData: '',providerIdType: 'Please Select One' })
                  }} >
                    <i class="fa fa-plus" />
                  </Button>
                </div>
                <div className="clearfix"></div>
              </div>
              <div className="mt-2">
                <AdditionalCritiriaTable
                  tableData={additionalCriteriatableData}
                  setAdditionalCritiriaFormData={setAdditionalCritiriaFormData}
                  setAdditionalCritiriaResetData={setAdditionalCritiriaResetData}
                  setAdditionalCriteriaShow={setAdditionalCriteriaShow}
                  setAdditionalEditorAddType={setAdditionalEditorAddType}
                  setSelectDeleteArray={setSelectDeleteArray}
                  selectDeleteArray={selectDeleteArray}
                  showAuditLog ={showAuditLog}
                  getAuditData ={additionalCriteriaAuditLog}
                /></div>
              {additionalCriteriaShow ? (<div className="tabs-container" ref={editadditionalcriteria}>
                <div className="tab-header">
                  <div className="tab-heading float-left">
                  {additionalEditorAddType !== 'add' ? "Edit" : "Add"} Additional Criteria
                  </div>
                  <div className="float-right mr-2">
                  <Button
                              title={
                                additionalEditorAddType !== 'add' ? "Update" : "Add"
                              }
                              variant="outlined"
                              color="primary"
                              className={
                                additionalEditorAddType !== 'add'
                                  ? "btn btn-ic btn-save"
                                  : "btn btn-ic btn-add"
                              }
                              onClick={() => saveAdditionalCriteria()}
                            >{additionalEditorAddType !== 'add' ? "Update" : "Add"}
                            </Button>
                    {additionalEditorAddType !== 'add' ? (<Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => deleteAdditionalCriteria(additionalCritiriaFormData.timeStamp)}>
                      Delete
                    </Button>) : null}
                    <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => { setAdditionalCritiriaFormData(additionalCritiriaResetData) }} >
                      Reset
                            </Button>
                    <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => { setAdditionalCriteriaShow(false) }} >
                      Cancel
                            </Button>
                  </div>
                  <div className="clearfix" />
                </div>
                <AdditionalCriteriaForm values={additionalCritiriaFormData} handleChanges={handleAdditionalcriteriaChanges} errors={{ showAddCritbeginError, showAddCritEndError, showValueError }} dropdowns={searchDropdowns} dataElementDropdowns={dataElementDropdowns} />
                {showAuditLog && additionalEditorAddType !== 'add' ? 
                <AuditLogRow  auditLogData={addCritAuditLogDataList?addCritAuditLogDataList:[]} />
               : ''}
              </div>
              
              ) : null}
            </div>
            {/* Additional Criteria End */}
          </div>
          <NavigationPrompt
        when={(crntLocation, nextLocation) => {
          if (confirm) {
            return false;
          } else {
            handelPromptSet(nextLocation);
            return true;
          }
        }}
        // when={true}
      >
        {({ onConfirm, onCancel }) => (
          <Dialog
            open={prompt}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
            className="custom-alert-box"
          >
            <DialogContent>
              <DialogContentText id="alert-dialog-description">
                {cancelType ? (
                  "Are you sure that you want to Cancel?"
                ) : (
                  <>
                    Unsaved changes will be lost. <br />
                    Are you sure you want to Continue?
                  </>
                )}
              </DialogContentText>
            </DialogContent>
            {cancelType ? (
              <DialogActions>
                <Button
                  title="Ok"
                  onClick={onConfirm}
                  color="primary"
                  className="btn btn-success"
                >
                  Ok
                </Button>
                <Button
                  title="Cancel"
                  onClick={() => {
                    setPrompt(false);
                    setCancelType(false);
                    onCancel();
                  }}
                  color="primary"
                  autoFocus
                >
                  Cancel
                </Button>
              </DialogActions>
            ) : (
              <DialogActions>
                <Button
                  title="Stay on this page"
                  onClick={() => {
                    setPrompt(false);
                    setCancelType(false);
                    onCancel();
                  }}
                  color="primary"
                  className="btn btn-transparent"
                >
                  STAY ON THIS PAGE!
                </Button>
                <Button
                  title="Continue"
                  onClick={onConfirm}
                  color="primary"
                  className="btn btn-success"
                  autoFocus
                >
                  CONTINUE <i className="fa fa-arrow-right ml-1"></i>
                </Button>
              </DialogActions>
            )}
          </Dialog>
        )}
      </NavigationPrompt>
        </div>
              {showAuditLog ?
                <div ref={auditRef}>
                  <AuditLog auditLogData={auditLogDataList ? auditLogDataList : []} />
                </div>
                : ''}


        <Footer print />
      </div>
      {/* tab-container div end */}
    </div>
    // pos-relative div start

  );
}


export default withRouter(CategoryOfServiceEdit);