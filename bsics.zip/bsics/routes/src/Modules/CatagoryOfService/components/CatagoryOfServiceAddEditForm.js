import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormHelperText from '@material-ui/core/FormHelperText';
import FormControl from '@material-ui/core/FormControl';
import FormLabel from '@material-ui/core/FormLabel';
import { makeStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';

// import Moment from 'react-moment';
// import { KeyboardDatePicker, MuiPickersUtilsProvider } from '@material-ui/pickers';
//import DateFnsUtils from '@date-io/date-fns';
const useStyles = makeStyles(theme => ({
  formControl: {
    margin: theme.spacing(3),
  },
}));
export default function CatagoryOfServiceAddEditForm(props) {
  const [selectedDate, setSelectedDate] = React.useState(null);
  const [selectedEndDate, setSelectedEndDate] = React.useState(null);
  const [defaultCheck, setDefaultCheck] = React.useState(false);
  // const [renderingProviderRadio, setRenderingProviderRadio] = React.useState('NA');
  //const [value, setValue] = React.useState('female');
  const [values, setValues] = React.useState({
    // billProviderRadio: '',
    // renderingProviderRadio:''

  });

  // const handleChanges = name => event => {
  //   console.log(event.target.name);
  //   console.log(event.target.value);
  //   setValues({ ...values, [name]: event.target.value });
  // };
  // const handleChange = name => event => {
  //   console.log(event.target.name);
  //   console.log(event.target.value);
  //   setValues({ ...values, [name]: event.target.value });
  // };
  // const handleRenderingProviderRadioChange = value => {
  //   setRenderingProviderRadio(value);
  // };


  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const handleEndDateChange = date => {
    setSelectedEndDate(date);
  };

  const handleDefaultCheckChange = () => {
    setDefaultCheck(!defaultCheck);
  };
  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-lob"
            select
            label="LOB"
            name="addLob"
            value={props.values.addLob}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('addLob')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            <MenuItem selected key="MED-Medicaid" value="MED-Medicaid">MED-Medicaid</MenuItem>
            <MenuItem selected key="MED-Medicaid 2" value="MED-Medicaid 2">MED-Medicaid 2</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-cos"
            select
            name="addCos"
            label="Catagory Of Service"
            value={props.values.addCos}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('addCos')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            <MenuItem selected key="001-InpHspGen" value="001-InpHspGen">001-InpHspGen</MenuItem>
            <MenuItem selected key="003-InpHspMent" value="003-InpHspMent">003-InpHspMent</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-assign-to"
            select
            label="Assign to"
            name="addAssignTo"
            value={props.values.addAssignTo}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('addAssignTo')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="-1">
              Please Select One
            </MenuItem>
            <MenuItem selected key="H-Header" value="H-Header">H-Header</MenuItem>
            <MenuItem selected key="L-Line" value="L-Line">L-Line</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-claim-form"
            select
            label="Claim Form"
            name="addClaimForm"
            value={props.values.addClaimForm}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('addClaimForm')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            <MenuItem selected key="60-Prof" value="60-Prof">60-Prof</MenuItem>
            <MenuItem selected key="61-Inst" value="61-Inst">61-Inst</MenuItem>
          </TextField>
        </div>
        <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-select-claim-type"
            select
            label="Claim Type"
            name="addClaimType"
            value={props.values.addClaimType}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('addClaimType')}
            placeholder=""
            //helperText={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
            InputLabelProps={{
              shrink: true,
            }}
          //error={props.errors.showCOSError ? CatagoryOfServiceConstants.LOB : null}
          >
            <MenuItem selected key="Please Select One" value="Please Select One">
              Please Select One
            </MenuItem>
            <MenuItem selected key="C-Capitation" value="C-Capitation">C-Capitation</MenuItem>
            <MenuItem selected key="D-Dental" value="D-Dental">D-Dental</MenuItem>
          </TextField>
        </div>
        {/* <div className="mui-custom-form input-md" style={{ marginLeft: '30px' }}> */}
        {/* <Moment format="MM/DD/YYYY" date={''} /> */}
        {/* <TextField
            id="standard-startDate"
            label="Begin Date"
            disabled
            value={props.values.startDate}
            inputProps={{ maxLength: 10 }}
            onChange={props.handleChanges('startDate')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          />
        </div> */}
        {/* <div className="mui-custom-form input-md" style={{ marginLeft: '30px' }}>
          <TextField
            id="standard-endDate"
            label="End Date"
            disabled
            value={props.values.endDate}
            inputProps={{ maxLength: 10 }}
            onChange={props.handleChanges('endDate')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          />
        </div> */}
        {/* <MuiPickersUtilsProvider >
          <div className="mui-custom-form with-date">
            <KeyboardDatePicker
              id="date-picker-inline"
              label="Begin Date"
              name='begin_date'
              InputLabelProps={{
                shrink: true
              }}
              placeholder="mm/dd/yyyy"
              format="MM/dd/yyyy"
              value={selectedDate}
              onChange={handleDateChange}
              KeyboardButtonProps={{
                'aria-label': 'change date'
              }}
            // helperText={showBeginDateError ? showBeginDateErrorMsg : null}
            // error={showBeginDateError ? showBeginDateErrorMsg : null}
            />
          </div>

          <div className="mui-custom-form with-date" >
            <KeyboardDatePicker
              id="date-picker-dialog"
              name='end_date'
              label="End Date"
              format="MM/dd/yyyy"
              InputLabelProps={{
                shrink: true
              }}
              placeholder="mm/dd/yyyy"
              value={selectedEndDate}
              onChange={handleEndDateChange}
              KeyboardButtonProps={{
                'aria-label': 'change date'
              }}
            // helperText={showEndDateError ? showEndDateErrorMsg : null}
            // error={showEndDateError ? showEndDateErrorMsg : null}
            />
          </div>
        </MuiPickersUtilsProvider> */}
        <div className="sub-radio">
          <FormControlLabel
            control={<Checkbox color="primary" onClick={handleDefaultCheckChange} checked={defaultCheck} value={defaultCheck} />}
            label="Default"
          />
        </div>

      </div>
      <div className="form-wrapper">
        {/* Billing Provider Type */}
        <div className="flex-wrappers aa">
          <div className="flex-wrapper-item w-50">
            <div className="flex-header">
              Billing Provider Type
            </div>
            <div className="flex-content">
              <div className="sub-radio">
                <input type="radio"
                  value="Range"
                  name="addBillProviderRadio"
                  checked={props.values.addBillProviderRadio === "Range"}
                  onChange={props.handleChanges('addBillProviderRadio')}
                /><span className="text-black"> Range</span>
                <input type="radio"
                  value="Value"
                  name="addBillProviderRadio"
                  checked={props.values.addBillProviderRadio === "Value"}
                  onChange={props.handleChanges('addBillProviderRadio')}
                /><span className="text-black">Value</span>

                <input type="radio"
                  value="NA"
                  name="addBillProviderRadio"
                  checked={(!props.values.addBillProviderRadio) || (props.values.addBillProviderRadio === 'NA')}
                  onChange={props.handleChanges('addBillProviderRadio')}
                />
                <span className="text-black">NA</span>
              </div>
              {/* div sub radio end */}
              {/* Range div */}
              <div>
                <div>
                  <span className="text-black">Billing Provider Type Range</span>
                </div>
                <TextField
                  name="addBillProviderRangeStart"
                  label=""
                  value={props.values.addBillProviderRangeStart}
                  onChange={props.handleChanges('addBillProviderRangeStart')}
                  variant="outlined"
                  inputProps={{ maxLength: 4 }}
                /><span className="text-black"> - </span>
                <TextField
                  name="addBillProviderRangeEnd"
                  label=""
                  value={props.values.addBillProviderRangeEnd}
                  onChange={props.handleChanges('addBillProviderRangeEnd')}
                  variant="outlined"
                  inputProps={{ maxLength: 4 }}
                />
              </div>
              {/* Range div end*/}
              <div>
                <span className="text-black">Billing Provider Type Value</span>
              </div>
              <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
                <TextField
                  id="standard-select-bill-provd-type-value"
                  select
                  label=""
                  name="addBillProvdTypeValue"
                  value={props.values.addBillProvdTypeValue}
                  inputProps={{ maxLength: 2 }}
                  onChange={props.handleChanges('addBillProvdTypeValue')}
                  placeholder=""
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem selected key="Please Select One" value="Please Select One">
                    Please Select One
                    </MenuItem>
                  <MenuItem selected key="001 - GenHosp" value="001 - GenHosp">001 - GenHosp</MenuItem>
                  <MenuItem selected key="002- MntHlthHosp" value="002- MntHlthHosp">002- MntHlthHosp</MenuItem>
                </TextField>
              </div>

              {/* Value div end*/}
            </div>
          </div>
          {/* Redering Provider Type */}
          <div className="flex-wrapper-item w-50">
            <div className="flex-header">
              Redering Provider Type
            </div>
            <div className="flex-content">
              <div className="mui-custom-form radio-box">
                <div className="sub-radio">
                  <input type="radio"
                    value="Range"
                    name="addRenderingProviderRadio"
                    checked={props.values.addRenderingProviderRadio === "Range"}
                    onChange={props.handleChanges('addRenderingProviderRadio')}
                    className="ml-2"
                  /><span className="text-black"> Range</span>
                  <input type="radio"
                    value="Value"
                    name="addRenderingProviderRadio"
                    checked={props.values.addRenderingProviderRadio === "Value"}
                    onChange={props.handleChanges('addRenderingProviderRadio')}
                    className="ml-2"
                  /><span className="text-black">Value</span>

                  <input type="radio"
                    value="NA"
                    name="addRenderingProviderRadio"
                    checked={(!props.values.addRenderingProviderRadio) || (props.values.addRenderingProviderRadio === 'NA')}
                    onChange={props.handleChanges('addRenderingProviderRadio')}
                    className="ml-2"
                  />
                  <span className="text-black">NA</span>
                </div>
                {/* div sub radio end */}
                {/* Range div */}
                <div>
                  <div>
                    <span className="text-black">Rendering Provider Type Range</span>
                  </div>
                  <TextField
                    name="addRenderingProviderRangeStart"
                    label=""
                    value={props.values.addRenderingProviderRangeStart}
                    onChange={props.handleChanges('addRenderingProviderRangeStart')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  /><span className="text-black"> - </span>
                  <TextField
                    name="addRenderingProviderRangeEnd"
                    label=""
                    value={props.values.addRenderingProviderRangeEnd}
                    onChange={props.handleChanges('addRenderingProviderRangeEnd')}
                    variant="outlined"
                    inputProps={{ maxLength: 4 }}
                  />
                </div>
                {/* Range div end*/}
                <div>
                  <span className="text-black">Rendering Provider Type Value</span>
                </div>
                <div className="mui-custom-form with-select input-md" style={{ marginLeft: '30px' }}>
                  <TextField
                    id="standard-select-render-provd-type-value"
                    select
                    label=""
                    name="addRenderingProvdTypeValue"
                    value={props.values.addRenderingProvdTypeValue}
                    inputProps={{ maxLength: 2 }}
                    onChange={props.handleChanges('addRenderingProvdTypeValue')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem selected key="Please Select One" value="Please Select One">
                      Please Select One
                    </MenuItem>
                    <MenuItem selected key="001 - GenHosp" value="001 - GenHosp">001 - GenHosp</MenuItem>
                    <MenuItem selected key="002- MntHlthHosp" value="002- MntHlthHosp">002- MntHlthHosp</MenuItem>
                  </TextField>
                </div>

                {/* Value div end*/}
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Next flex */}
      {/* Procedure Code */}
      <div className="flex-wrappers">
        <div className="flex-wrapper-item w-30">
          <div className="flex-header">Procedure Code</div>
          <div className="flex-content">
            <div className="sub-radio">
              <input type="radio"
                value="Range"
                name="addProcCodeRadio"
                checked={props.values.addProcCodeRadio === "Range"}
                onChange={props.handleChanges('addProcCodeRadio')}
                className="ml-2"
              /><span className="text-black"> Range</span>
              <input type="radio"
                value="Value"
                name="addProcCodeRadio"
                checked={props.values.addProcCodeRadio === "Value"}
                onChange={props.handleChanges('addProcCodeRadio')}
                className="ml-2"
              /><span className="text-black">Value</span>
              <input type="radio"
                value="NA"
                name="addProcCodeRadio"
                checked={(!props.values.addProcCodeRadio) || (props.values.addProcCodeRadio === 'NA')}
                onChange={props.handleChanges('addProcCodeRadio')}
                className="ml-2"
              />
              <span className="text-black">NA</span>
            </div>
            {/* div sub radio end */}
            {/* Range div */}
            <div>
              <div>
                <span className="text-black">Procedure Code Range</span>
              </div>
              <TextField
                name="addProcCodeRangeStart"
                label=""
                value={props.values.addProcCodeRangeStart}
                onChange={props.handleChanges('addProcCodeRangeStart')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              /><span className="text-black"> - </span>
              <TextField
                name="addProcCodeRangeEnd"
                label=""
                value={props.values.addProcCodeRangeEnd}
                onChange={props.handleChanges('addProcCodeRangeEnd')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Modifier div start */}
            <div>
                <span className="text-black">Modifier 1</span>
            </div>
            <div>
              <TextField
                name="addProcCodeRangeMod1"
                label=""
                value={props.values.addProcCodeRangeMod1}
                onChange={props.handleChanges('addProcCodeRangeMod1')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
                <span className="text-black">Modifier 2</span>
            </div>
            <div>
              <TextField
                name="addProcCodeRangeMod2"
                label=""
                value={props.values.addProcCodeRangeMod2}
                onChange={props.handleChanges('addProcCodeRangeMod2')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
                <span className="text-black">Modifier 3</span>
            </div>
            <div>
              <TextField
                name="addProcCodeRangeMod3"
                label=""
                value={props.values.addProcCodeRangeMod3}
                onChange={props.handleChanges('addProcCodeRangeMod3')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
                <span className="text-black">Modifier 4</span>
            </div>
            <div>
              <TextField
                name="addProcCodeRangeMod4"
                label=""
                value={props.values.addProcCodeRangeMod4}
                onChange={props.handleChanges('addProcCodeRangeMod4')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Range div end*/}
            <div>
              <span className="text-black">Procedure Code Value</span>
            </div>
            <div>
              <TextField
                name="addProcCodeValue"
                label=""
                value={props.values.addProcCodeValue}
                onChange={props.handleChanges('addProcCodeValue')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Modifier div start */}
            <div>
                <span className="text-black">Modifier 1</span>
            </div>
            <div>
              <TextField
                name="addProcCodeValueMod1"
                label=""
                value={props.values.addProcCodeValueMod1}
                onChange={props.handleChanges('addProcCodeValueMod1')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
                <span className="text-black">Modifier 2</span>
            </div>
            <div>
              <TextField
                name="addProcCodeValueMod2"
                label=""
                value={props.values.addProcCodeValueMod2}
                onChange={props.handleChanges('addProcCodeValueMod2')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
                <span className="text-black">Modifier 3</span>
            </div>
            <div>
              <TextField
                name="addProcCodeValueMod3"
                label=""
                value={props.values.addProcCodeValueMod3}
                onChange={props.handleChanges('addProcCodeValueMod3')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            <div>
                <span className="text-black">Modifier 4</span>
            </div>
            <div>
              <TextField
                name="addProcCodeValueMod4"
                label=""
                value={props.values.addProcCodeValueMod4}
                onChange={props.handleChanges('addProcCodeValueMod4')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Value div end*/}
          </div>
        </div>
        {/* Diagnosis Code */}
        <div className="flex-wrapper-item w-30">
          <div className="flex-header">Diagnosis Code</div>
          <div className="flex-content">
            <div className="sub-radio">
              <input type="radio"
                value="Range"
                name="addDiagCodeRadio"
                checked={props.values.addDiagCodeRadio === "Range"}
                onChange={props.handleChanges('addDiagCodeRadio')}
                className="ml-2"
              /><span className="text-black"> Range</span>
              <input type="radio"
                value="Value"
                name="addDiagCodeRadio"
                checked={props.values.addDiagCodeRadio === "Value"}
                onChange={props.handleChanges('addDiagCodeRadio')}
                className="ml-2"
              /><span className="text-black">Value</span>

              <input type="radio"
                value="NA"
                name="addDiagCodeRadio"
                checked={(!props.values.addDiagCodeRadio) || (props.values.addDiagCodeRadio === 'NA')}
                onChange={props.handleChanges('addDiagCodeRadio')}
                className="ml-2"
              />
              <span className="text-black">NA</span>
            </div>
            {/* div sub radio end */}
            {/* Range div */}
            <div>
              <div>
                <span className="text-black">Diagnosis Code Range</span>
              </div>
              <TextField
                name="addDiagCodeRangeStart"
                label=""
                value={props.values.addDiagCodeRangeStart}
                onChange={props.handleChanges('addDiagCodeRangeStart')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              /><span className="text-black"> - </span>
              <TextField
                name="addDiagCodeRangeEnd"
                label=""
                value={props.values.addDiagCodeRangeEnd}
                onChange={props.handleChanges('addDiagCodeRangeEnd')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Range div end*/}
            <div>
              <span className="text-black">Diagnosis Code Value</span>
            </div>
            <div>
              <TextField
                name="addDiagCodeValue"
                label=""
                value={props.values.addDiagCodeValue}
                onChange={props.handleChanges('addDiagCodeValue')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>

            {/* Value div end*/}
          </div>
        </div>
        {/* Surgical Procedure Code */}
        <div className="flex-wrapper-item w-30">
          <div className="flex-header">Surgical Procedure Code</div>
          <div className="flex-content">
            <div className="sub-radio">
              <input type="radio"
                value="Range"
                name="addSurgProcCodeRadio"
                checked={props.values.addSurgProcCodeRadio === "Range"}
                onChange={props.handleChanges('addSurgProcCodeRadio')}
                className="ml-2"
              /><span className="text-black"> Range</span>
              <input type="radio"
                value="Value"
                name="addSurgProcCodeRadio"
                checked={props.values.addSurgProcCodeRadio === "Value"}
                onChange={props.handleChanges('addSurgProcCodeRadio')}
                className="ml-2"
              /><span className="text-black">Value</span>
              <input type="radio"
                value="NA"
                name="addSurgProcCodeRadio"
                checked={(!props.values.addSurgProcCodeRadio) || (props.values.addSurgProcCodeRadio === 'NA')}
                onChange={props.handleChanges('addSurgProcCodeRadio')}
                className="ml-2"
              />
              <span className="text-black">NA</span>
            </div>
            {/* div sub radio end */}
            {/* Range div */}
            <div>
              <div>
                <span className="text-black">Surgical Procedure Code Range</span>
              </div>
              <TextField
                name="addSurgProcCodeRangeStart"
                label=""
                value={props.values.addSurgProcCodeRangeStart}
                onChange={props.handleChanges('addSurgProcCodeRangeStart')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              /><span className="text-black"> - </span>
              <TextField
                name="addSurgProcCodeRangeEnd"
                label=""
                value={props.values.addSurgProcCodeRangeEnd}
                onChange={props.handleChanges('addSurgProcCodeRangeEnd')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Range div end*/}
            <div>
              <span className="text-black">Surgical Procedure Code Value</span>
            </div>
            <div>
              <TextField
                name="addSurgProcCodeValue"
                label=""
                value={props.values.addSurgProcCodeValue}
                onChange={props.handleChanges('addSurgProcCodeValue')}
                variant="outlined"
                inputProps={{ maxLength: 4 }}
              />
            </div>
            {/* Value div end*/}
          </div>
        </div>
      </div>
    </form >
  );
}
