import React from "react";
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import * as CatagoryOfServiceConstants from "./CatagoryOfServiceConstants";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";

export default function AdditionalCriteriaForm(props) {
  return (
    <form autoComplete="off">
      <div className="tab-body-bordered">
        {/* <div className="cndt-row-wrapper columns-data"> */}
          <div className="form-wrapper">
            {/* <!-- col 1 start --> */}
            
              
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-select-lob"
                    select
                    label="Data Element Criteria"
                    value={props.values.dataElementCriteria}
                    inputProps={{ maxLength: 2 }}
                    onChange={props.handleChanges("dataElementCriteria")}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true,
                    }}
                  >
                    <MenuItem
                      selected
                      key="Please Select One"
                      value="Please Select One"
                    >
                      Please Select One
                    </MenuItem>
                    {props.dataElementDropdowns &&
                      Object.keys(props.dataElementDropdowns).length > 0 &&
                      props.dataElementDropdowns &&
                      Object.keys(props.dataElementDropdowns).map((each) => (
                        <MenuItem selected key={each} value={each}>
                          {props.dataElementDropdowns[each]}
                        </MenuItem>
                      ))}
                    {/* {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Reference#5366'].length > 0 && props.dropdowns['Reference#5366'].map( each => (
                      <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                    ))} */}
                    {/* <MenuItem selected key="BillingProviderNumber" value="Billing Provider Number">Billing Provider Number</MenuItem>
                    <MenuItem selected key="RenderingProviderNumber" value="Rendering Provider Number">Rendering Provider Number</MenuItem>
                    <MenuItem selected key="LevelOfCare" value="Level Of Care">Level Of Care</MenuItem> */}
                  </TextField>
                {/* conditional dropdown */}
              {props.values.dataElementCriteria === "P_RNDR_PROV_NUM" ||
                props.values.dataElementCriteria === "P_BLNG_PROV_NUM" ? (
                  <div className="mt-3">
                    {/* <div className="mui-custom-form with-select input-md"> */}
                      <TextField
                        id="standard-select-lob"
                        select
                        label="Provider ID Type"
                        value={props.values.providerIdType}
                        inputProps={{ maxLength: 2 }}
                        onChange={props.handleChanges("providerIdType")}
                        placeholder=""
                        InputLabelProps={{
                          shrink: true,
                        }}
                      >
                        <MenuItem
                          selected
                          key="Please Select One"
                          value="Please Select One"
                        >
                          Please Select One
                      </MenuItem>
                        {props.dropdowns &&
                          Object.keys(props.dropdowns).length > 0 &&
                          props.dropdowns["Provider#1017"].length > 0 &&
                          props.dropdowns["Provider#1017"].map((each) => (
                            <MenuItem selected key={each.code} value={each.code}>
                              {each.description}
                            </MenuItem>
                          ))}
                        {/* <MenuItem selected key="C8_R_PROC_CD" value="Procedure Code">Procedure Code</MenuItem> */}
                      </TextField>
                    {/* </div> */}
                    {/* props.values.dataElementCriteria */}
                  </div>
                ) : null}
              {/* condition end */}
                </div>
                {/* props.values.dataElementCriteria */}
              
              
              {/* end second py2  */}

            
            {/* <!-- col 1 end -->
      <!-- col 2 start --> */}
            <div className="mui-custom-form input-md">
              <div className="p-2">
                <div className="sub-radio">
                <RadioGroup row aria-label="providerRole" name="providerRole">
                    <FormControlLabel
                      value="Range"
                      type="radio"
                      id="range-additional-criteria"
                      control={<Radio color="primary" />}
                      label="Range"
                      checked={
                        props.values.range === "Range" &&
                        !(
                          props.values.dataElementCriteria ===
                          "P_BLNG_PROV_NUM" ||
                          props.values.dataElementCriteria ===
                          "P_RNDR_PROV_NUM"
                        )
                      }
                      onChange={props.handleChanges("range")}
                      disabled={
                        props.values.dataElementCriteria ===
                        "P_BLNG_PROV_NUM" ||
                        props.values.dataElementCriteria ===
                        "P_RNDR_PROV_NUM"
                      }
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                    <FormControlLabel
                      type="radio"
                      value="Value"
                      id="value-additional-criteria"
                      control={<Radio color="primary" />}
                      checked={
                        props.values.range === "Value" ||
                        props.values.dataElementCriteria ===
                        "P_BLNG_PROV_NUM" ||
                        props.values.dataElementCriteria ===
                        "P_RNDR_PROV_NUM"
                      }
                      onChange={props.handleChanges("range")}
                      label="Value"
                      InputLabelProps={{
                        shrink: true,
                      }}
                      selected={true}
                    disabled={
                      props.values.dataElementCriteria ===
                      "P_BLNG_PROV_NUM" ||
                      props.values.dataElementCriteria ===
                      "P_RNDR_PROV_NUM"
                    }
                    />
                  </RadioGroup>
                 
                </div>
              </div>

              {/* //condition start */}
              {props.values.range !== "Value" &&
                !(
                  props.values.dataElementCriteria ===
                  "P_BLNG_PROV_NUM" ||
                  props.values.dataElementCriteria === "P_RNDR_PROV_NUM"
                ) ? (
                  <>
                    <div className="p-2 ml-1">
                      <div className="cndt-row">
                        <div className="cndt-col-5">
                          <TextField
                            id="standard-beginValue"
                            value={props.values.beginValueData}
                            label="Begin value"
                            inputProps={{ maxLength: 5 }}
                            onChange={props.handleChanges("beginValueData")}
                            placeholder=""
                            helperText={
                              props.errors.showAddCritbeginError
                                ? CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR
                                : null
                            }
                            error={
                              props.errors.showAddCritbeginError
                                ? CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR
                                : null
                            }
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                        </div>

                        <div className="cndt-col-5">
                          <TextField
                            id="standard-endValue"
                            value={props.values.endValueData}
                            label="End value"
                            inputProps={{ maxLength: 5 }}
                            onChange={props.handleChanges("endValueData")}
                            placeholder=""
                            helperText={
                              props.errors.showAddCritEndError
                                ? CatagoryOfServiceConstants.ADD_CRIT_END_ERROR
                                : null
                            }
                            error={
                              props.errors.showAddCritEndError
                                ? CatagoryOfServiceConstants.ADD_CRIT_END_ERROR
                                : null
                            }
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                        </div>
                      </div>
                    </div>
                    {/* //end py-2 */}
                  </>
                ) : (
                  //begin py-2
                  <div className="p-2 ml-1  bill-prov-type">
                    {/* <div className="cndt-row">
                      <div className="cndt-col-5"> */}
                        <TextField
                          id="standard-beginValue"
                          value={props.values.valueData}
                          // label="Value"
                          inputProps={{ maxLength: 5 }}
                          onChange={props.handleChanges("valueData")}
                          placeholder=""
                          helperText={
                            props.errors.showValueError
                              ? CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR
                              : null
                          }
                          error={
                            props.errors.showValueError
                              ? CatagoryOfServiceConstants.ADD_CRIT_BEGIN_ERROR
                              : null
                          }
                          InputLabelProps={{
                            shrink: true,
                          }}
                        />
                      {/* </div>
                    </div> */}
                  </div>
                  // end py-2
                )}

            
            {/* <!-- col 2 end --> */}
          </div>
          </div>
        {/* </div> */}
      </div>
    </form>
  );
}
