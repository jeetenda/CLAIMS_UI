import React, { useState, useEffect, useRef  } from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import DateFnsUtils from '@date-io/date-fns';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider
} from '@material-ui/pickers';
import Radio from '@material-ui/core/Radio';
import * as CatagoryOfServiceConstants from './CatagoryOfServiceConstants';

export default function CatagoryOfServiceAddForm(props) {
  const [defaultCheck, setDefaultCheck] = React.useState(false);
  const [values, setValues] = React.useState({});

  const handleDateChange = name => date => {
    props.handelDateChange(name, date);
  };


  return (
    <form autoComplete="off" id="form">
      {/* <div className="tab-body-bordered mt-2"> */}
        <div className="form-wrapper">
          {/* MuiPickersUtilsProvider start */}
          <MuiPickersUtilsProvider utils={DateFnsUtils}>
            <div className="mui-custom-form input-md with-select">
              <KeyboardDatePicker
                required
                id="bgn-date-add-edit"
                label="Begin Date"
                format="MM/dd/yyyy"
                InputLabelProps={{
                  shrink: true,
                }}
                placeholder="mm/dd/yyyy"
                value={props.values.beginDate === "" ? null : props.values.beginDate}
                onChange={handleDateChange('beginDate')}
                helperText={
                  props.errors.showBeginDateError ? CatagoryOfServiceConstants.BEGIN_DATE_ERROR 
                  :props.errors.beginDtInvalidErr ? CatagoryOfServiceConstants.Invalid_Begin_Date_Error
                  : null
                }
                error={
                  props.errors.showBeginDateError ? CatagoryOfServiceConstants.BEGIN_DATE_ERROR 
                  :props.errors.beginDtInvalidErr ? CatagoryOfServiceConstants.Invalid_Begin_Date_Error
                  : null
                }
                KeyboardButtonProps={{
                  'aria-label': 'change date',
                }}
              />
            </div>
          </MuiPickersUtilsProvider>
          <MuiPickersUtilsProvider utils={DateFnsUtils}>
            <div className="mui-custom-form input-md with-select">
              <KeyboardDatePicker
                required
                id="end-date-add-edit"
                label="End Date"
                format="MM/dd/yyyy"

                maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                InputLabelProps={{
                  shrink: true,
                }}
                placeholder="mm/dd/yyyy"
                value={props.values.endDate === "" ? null : props.values.endDate}
                onChange={handleDateChange('endDate')}
                helperText={
                  props.errors.showEndDateError ? CatagoryOfServiceConstants.END_DATE_ERROR 
                  :props.errors.endDtInvalidErr?CatagoryOfServiceConstants.Invalid_End_Date_Error
                  : null}
                error={
                  props.errors.showEndDateError ? CatagoryOfServiceConstants.END_DATE_ERROR 
                  :props.errors.endDtInvalidErr?CatagoryOfServiceConstants.Invalid_End_Date_Error
                  : null}
                KeyboardButtonProps={{
                  'aria-label': 'change date',
                }}
              />
            </div>
          </MuiPickersUtilsProvider>
          {/* </MuiPickersUtilsProvider>  */}
        </div>
        <div className="form-wrapper">
          <div className="mui-custom-form with-select input-md">
            <TextField
              required
              id="lob-add-edit"
              select
              label="LOB"
              value={props.values.lobCode}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('lobCode')}
              placeholder=""
              helperText={props.errors.lobCodeError ? CatagoryOfServiceConstants.LOB_ERROR : null}
              error={props.errors.lobCodeError ? CatagoryOfServiceConstants.LOB_ERROR : null}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
            </MenuItem>
              {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Reference#1019'].length > 0 && props.dropdowns['Reference#1019'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
              {/* <MenuItem selected key="MED-Medicaid" value="MED">MED-Medicaid</MenuItem> */}
            </TextField>
          </div>
          <div className="mui-custom-form with-select input-md">
            <TextField
              required
              id="cos-add-edit"
              select
              label="Category Of Service"
              value={props.values.categoryOfServiceCode}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('categoryOfServiceCode')}
              placeholder=""
              helperText={props.errors.cosCodeError ? CatagoryOfServiceConstants.COS_CODE_ERROR : null}
              error={props.errors.cosCodeError ? CatagoryOfServiceConstants.COS_CODE_ERROR : null}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
            </MenuItem>
              {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Claims#1020'].length > 0 && props.dropdowns['Claims#1020'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
              {/* <MenuItem selected key="001-InpHspGen" value="001">001-InpHspGen</MenuItem>
            <MenuItem selected key="003-InpHspMent" value="003">003-InpHspMent</MenuItem> */}
            </TextField>
          </div>
          <div className="mui-custom-form with-select input-md">
            <TextField
              required
              id="assign-to-add-edit"
              select
              label="Assign to"
              value={props.values.headerLineAssignCode}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('headerLineAssignCode')}
              placeholder=""
              helperText={props.errors.assignCodeError ? CatagoryOfServiceConstants.ASSIGN_CODE_ERROR : null}
              error={props.errors.assignCodeError ? CatagoryOfServiceConstants.ASSIGN_CODE_ERROR : null}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
            </MenuItem>
              {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Claims2#1000'].length > 0 && props.dropdowns['Claims2#1000'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
              {/* <MenuItem selected key="H-Header" value="H">H-Header</MenuItem>
            <MenuItem selected key="L-Line" value="L">L-Line</MenuItem> */}
            </TextField>
          </div>
          <div className="mui-custom-form with-select input-md">
            <TextField
              required
              id="claim-form-add-edit"
              select
              label="Claim Form"
              value={props.values.claimFormCode}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('claimFormCode')}
              placeholder=""
              helperText={props.errors.claimFormCodeError ? CatagoryOfServiceConstants.CLAIM_FORM_ERROR : null}
              error={props.errors.claimFormCodeError ? CatagoryOfServiceConstants.CLAIM_FORM_ERROR : null}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
            </MenuItem>
              {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Claims#1027'].length > 0 && props.dropdowns['Claims#1027'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
              {/* <MenuItem selected key="60-Prof" value="60">60-Prof</MenuItem>
            <MenuItem selected key="61-Inst" value="61">61-Inst</MenuItem> */}
            </TextField>
          </div>
          <div className="mui-custom-form with-select input-md">
            <TextField
              required
              id="claim-type-add-edit"
              select
              label="Claim Type"
              value={props.values.claimTypeCode}
              inputProps={{ maxLength: 2 }}
              onChange={props.handleChanges('claimTypeCode')}
              placeholder=""
              helperText={props.errors.claimTypeCodeError ? CatagoryOfServiceConstants.CLAIM_TYPE_ERROR : null}
              error={props.errors.claimTypeCodeError ? CatagoryOfServiceConstants.CLAIM_TYPE_ERROR : null}
              InputLabelProps={{
                shrink: true,
              }}
            >
              <MenuItem selected key="Please Select One" value="-1">
                Please Select One
            </MenuItem>
              {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Claims#1038'].length > 0 && props.dropdowns['Claims#1038'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
              {/* <MenuItem selected key="C-Capitation" value="C">C-Capitation</MenuItem>
            <MenuItem selected key="D-Dental" value="D">D-Dental</MenuItem>
            <MenuItem selected key="F-Fin Tran" value="F">F-Fin Tran</MenuItem>
            <MenuItem selected key="I-Inpatient" value="I">I-Inpatient</MenuItem>
            <MenuItem selected key="M-Medical" value="M">M-Medical</MenuItem>
            <MenuItem selected key="P-Pharmacy" value="P">P-Pharmacy</MenuItem>
            <MenuItem selected key="O-Outpatient" value="O">O-Outpatient</MenuItem>
            <MenuItem selected key="Z-Void Req" value="Z">Z-Void Req</MenuItem> */}
            </TextField>
          </div>
          {/* Rank textbox */}
          <div className="mui-custom-form input-md">
            <TextField
              id="rank-add-edit"
              label="Rank"
              value={props.values.rankNumber}
              inputProps={{ maxLength: 6 }}
              onChange={props.handleChanges('rankNumber')}
              placeholder=""
              InputLabelProps={{
                shrink: true,
              }}
            />
          </div>
          <div className="mui-custom-form">
            <div className="sub-radio mt-4">
              <FormControlLabel
                id="default-add-edit"
                control={<Checkbox color="primary" checked={props.values.defaultIndicator} onChange={props.handleChanges('defaultIndicator')} value={props.values.defaultIndicator} />}
                label="Default"
              />
            </div>
          </div>

        </div>
        <div className="tab-body-bordered ml-3 mr-3 mb-3 mt-2">
          
            <div className="form-wrapper form-3-column">
              {/* <!-- Billing Provider Type --> */}
              <div className="mui-custom-form input-md">
                <div className="tabs-container">

                  <div className="tabss-wrapper">
                    <div className="my-2">
                      <div className="tab-header p-0">
                        <h2 className="tab-heading float-left p-0">Billing Provider Type</h2>
                        <div className="clearfix"></div>
                      </div>
                      <div className="sub-radio set-rd-pos">
                        <Radio type="radio"
                        id="range-bpt"
                          value="Range"
                          // name="addBillProviderRadio"
                          checked={props.values.billProviderType === "Range"}
                          onChange={props.handleChanges('billProviderType')}

                        /><label className="text-black mr-1">Range</label>
                        <Radio type="radio"
                        id="value-bpt"
                          value="Value"
                          // name="addBillProviderRadio"
                          checked={props.values.billProviderType === "Value"}
                          onChange={props.handleChanges('billProviderType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Value</label>

                        <Radio type="radio"
                        id="na-bpt"
                          value="NA"
                          name="billProviderType"
                          checked={(!props.values.billProviderType) || (props.values.billProviderType === 'NA')}
                          onChange={props.handleChanges('billProviderType')}
                          className="mr-1"
                        />
                        <label className="text-black mr-1">NA</label>
                      </div>
                      {/* div sub radio end */}
                    </div>
                    {(props.values.billProviderType === 'Range') ? (
                      <div className="py-2">
                        <label className="cndt-label"> Billing Provider Type Range </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-5">
                            <TextField
                              id="bptr-r1"
                              label=""
                              value={props.values.beginBillingProviderTypeCode}
                              onChange={props.handleChanges('beginBillingProviderTypeCode')}
                              helperText={props.errors.beginBillProviderTypeError ? CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_BEGIN_ERROR : props.errors.beginBillProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.beginBillProviderTypeError ? CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_BEGIN_ERROR : props.errors.beginBillProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                          {/* <div className="cndt-col-1">  -</div> */}-
                    <div className="cndt-col-5">
                            <TextField
                             id="bptr-r2"
                              label=""
                              value={props.values.endBillingProviderTypeCode}
                              onChange={props.handleChanges('endBillingProviderTypeCode')}
                              helperText={props.errors.endBillProviderTypeError ? CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_END_ERROR : props.errors.endBillProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.endBillProviderTypeError ? CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_END_ERROR : props.errors.endBillProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Range div end*/}
                    {(props.values.billProviderType === 'Value') ? (
                      <div className="py-2">
                        <label className="cndt-label"> Billing Provider Type Value </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-12">
                        <div className="MuiFormControl-root MuiTextField-root with-select">
                              <TextField
                                id="bill-provd-type-value"
                                select
                                label=""
                                value={props.values.billProviderTypeValue}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('billProviderTypeValue')}
                                helperText={props.errors.billProviderTypeValueError ? CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_VALUE_ERROR : props.errors.billProviderTypeValueFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                                error={props.errors.billProviderTypeValueError ? CatagoryOfServiceConstants.BILL_PROVIDER_TYPE_VALUE_ERROR : props.errors.billProviderTypeValueFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                                placeholder=""
                                InputLabelProps={{
                                  shrink: true,
                                }}
                              >
                                <MenuItem selected key="Please Select One" value="-1">
                                  Please Select One
													</MenuItem>
                                {/* <MenuItem selected key="001 - GenHosp" value="001">001 - GenHosp</MenuItem>
                                <MenuItem selected key="002- MntHlthHosp" value="002">002- MntHlthHosp</MenuItem> */}
                                 {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Provider#1448'].length > 0 && props.dropdowns['Provider#1448'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
                              </TextField>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : null
                    }

                  </div>
                </div>
              </div>
              {/* <!-- *** --> */}

              {/* <!-- Rendering Provider Type --> */}
              <div className="mui-custom-form input-md">
                <div className="tabs-container">

                  <div className="tabss-wrapper">
                    <div className="my-2">
                      <div className="tab-header p-0">
                        <h2 className="tab-heading float-left p-0">Rendering Provider Type</h2>
                        <div className="clearfix"></div>
                      </div>
                      <div className="sub-radio set-rd-pos">
                        <Radio type="radio"
                        id="range-rpt"
                          value="Range"
                          checked={props.values.renderingProviderType === "Range"}
                          onChange={props.handleChanges('renderingProviderType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Range</label>
                        <Radio type="radio"
                        id="value-rpt"
                          value="Value"
                          checked={props.values.renderingProviderType === "Value"}
                          onChange={props.handleChanges('renderingProviderType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Value</label>

                        <Radio type="radio"
                        id="na-rpt"
                          value="NA"
                          checked={(!props.values.renderingProviderType) || (props.values.renderingProviderType === 'NA')}
                          onChange={props.handleChanges('renderingProviderType')}
                          className="mr-1"
                        />
                        <label className="text-black mr-1">NA</label>
                      </div>
                      {/* div sub radio end */}
                    </div>
                    {/* Range div */}
                    {(props.values.renderingProviderType === 'Range') ? (
                      <div className="py-2">
                        <label className="cndt-label"> Rendering Provider Type Range </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-5">
                            <TextField
                            id="range1-rptr"
                              label=""
                              value={props.values.beginRenderingProviderTypeCode}
                              onChange={props.handleChanges('beginRenderingProviderTypeCode')}
                              helperText={props.errors.beginRenderingProviderTypeError ? CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_BEGIN_ERROR : props.errors.beginRenderingProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.beginRenderingProviderTypeError ? CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_BEGIN_ERROR : props.errors.beginRenderingProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                          {/* <div className="cndt-col-1">
                      -
                                                </div> */}-
                    <div className="cndt-col-5">
                            <TextField
                            id="range1-rptr"
                              label=""
                              value={props.values.endRenderingProviderTypeCode}
                              onChange={props.handleChanges('endRenderingProviderTypeCode')}
                              helperText={props.errors.endRenderingProviderTypeError ? CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_END_ERROR : props.errors.endRenderingProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.endRenderingProviderTypeError ? CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_END_ERROR : props.errors.endRenderingProviderTypeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Range div end*/}
                    {(props.values.renderingProviderType === 'Value') ? (
                      <div className="py-2">
                        <label className="cndt-label"> Rendering Provider Type Value </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-12">
                            <div className="mui-custom-form with-select input-md input-md-1-col">
                              <TextField
                                id="render-provd-type-value"
                                select
                                label=""
                                value={props.values.renderingProviderTypeValue}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('renderingProviderTypeValue')}
                                helperText={props.errors.renderingProviderTypeValueError ? CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_VALUE_ERROR : null}
                                error={props.errors.renderingProviderTypeValueError ? CatagoryOfServiceConstants.RENDERING_PROVIDER_TYPE_VALUE_ERROR : null}
                                placeholder=""
                                InputLabelProps={{
                                  shrink: true,
                                }}
                              >
                                <MenuItem selected key="Please Select One" value="-1">
                                  Please Select One
                    </MenuItem>
                    {props.dropdowns && Object.keys(props.dropdowns).length > 0 && props.dropdowns['Provider#1448'].length > 0 && props.dropdowns['Provider#1448'].map(each => (
                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
              ))}
                              </TextField>
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                  </div>
                </div>
              </div>
              {/* <!-- *** --> */}
            </div>
         
          {/* Next flex */}
          {/* Procedure Code */}
          <div className="form-wrapper form-3-column">

              {/* <!-- Procedure Code --> */}
              <div className="mui-custom-form input-md">
                <div className="tabs-container">

                  <div className="tabss-wrapper">
                    <div className="my-2">
                      <div className="tab-header p-0">
                        <h2 className="tab-heading float-left p-0">Procedure Code</h2>
                        <div className="clearfix"></div>
                      </div>
                      <div className="sub-radio set-rd-pos">
                        <Radio type="radio"
                          id="range-proc-code"
                          value="Range"
                          checked={props.values.procedureCodeType === "Range"}
                          onChange={props.handleChanges('procedureCodeType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Range</label>
                        <Radio type="radio"
                          id="value-proc-code"
                          value="Value"
                          checked={props.values.procedureCodeType === "Value"}
                          onChange={props.handleChanges('procedureCodeType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Value</label>
                        <Radio type="radio"
                          id="na-proc-code"
                          value="NA"
                          checked={(!props.values.procedureCodeType) || (props.values.procedureCodeType === 'NA')}
                          onChange={props.handleChanges('procedureCodeType')}
                          className="mr-1"
                        />
                        <label className="text-black mr-1">NA</label>
                      </div>
                      {/* div sub radio end */}
                    </div>
                    {/* Range div */}
                    {(props.values.procedureCodeType === 'Range') ? (
                      <div>
                        <div className="py-2">
                          <label className="cndt-label"> Procedure Code Range </label>
                          <div className="cndt-row bill-prov-type">
                            <div className="cndt-col-5">
                              <TextField
                                id="max-range-proc-code"
                                label=""
                                value={props.values.beginProcedureCode}
                                onChange={props.handleChanges('beginProcedureCode')}
                                helperText={props.errors.beginProcedureCodeError ? CatagoryOfServiceConstants.PROCEDURE_CODE_BEGIN_ERROR : props.errors.beginProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                                error={props.errors.beginProcedureCodeError ? CatagoryOfServiceConstants.PROCEDURE_CODE_BEGIN_ERROR : props.errors.beginProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                            {/* <div className="cndt-col-1">
                        -
                                                </div> */}-
                      <div className="cndt-col-5">
                              <TextField
                                id="min-range-proc-code"
                                label=""
                                value={props.values.endProcedureCode}
                                onChange={props.handleChanges('endProcedureCode')}
                                helperText={props.errors.endProcedureCodeError ? CatagoryOfServiceConstants.PROCEDURE_CODE_END_ERROR : props.errors.endProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                                error={props.errors.endProcedureCodeError ? CatagoryOfServiceConstants.PROCEDURE_CODE_END_ERROR : props.errors.endProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                          </div>
                        </div>
                        {/* Modifiers */}
                        <div className="py-2">
                          <div className="cndt-row bill-prov-type">
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-1"> Modifier-1 </label>
                              <TextField
                                id="mod1-proc-code"
                                label=""
                                value={props.values.procedureModifierCode1}
                                onChange={props.handleChanges('procedureModifierCode1')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-1"> Modifier-2 </label>
                              <TextField
                              id="mod2-proc-code"
                                label=""
                                value={props.values.procedureModifierCode2}
                                onChange={props.handleChanges('procedureModifierCode2')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-1"> Modifier-3 </label>
                              <TextField
                              id="mod3-proc-code"
                                label=""
                                value={props.values.procedureModifierCode3}
                                onChange={props.handleChanges('procedureModifierCode3')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-1"> Modifier-4 </label>
                              <TextField
                              id="mod4-proc-code"
                                label=""
                                value={props.values.procedureModifierCode4}
                                onChange={props.handleChanges('procedureModifierCode4')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Range div end*/}
                    {(props.values.procedureCodeType === 'Value') ? (
                      <div>
                        {console.log("props.errors.procCodeValueError", props.errors.procCodeValueError)}
                        <div className="py-2">
                          <label className="cndt-label" for="Procedure-range-Value"> Procedure Code Value </label>
                          <div className="cndt-row bill-prov-type">
                            <div className="cndt-col-12">
                              <TextField
                              id="value-proc-code"
                                label=""
                                value={props.values.procCodeValue}
                                onChange={props.handleChanges('procCodeValue')}
                                helperText={props.errors.procCodeValueError ? CatagoryOfServiceConstants.PROCEDURE_CODE_VALUE_ERROR : null}
                                error={props.errors.procCodeValueError ? CatagoryOfServiceConstants.PROCEDURE_CODE_VALUE_ERROR : null}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                          </div>
                        </div>
                        {/* Modifier div start */}
                        <div className="py-2">
                          <div className="cndt-row bill-prov-type">
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-1"> Modifier-1 </label>
                              <TextField
                              id="mod1-value-proc-code"
                                label=""
                                value={props.values.procedureModifier1}
                                onChange={props.handleChanges('procedureModifier1')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-2"> Modifier-2 </label>
                              <TextField
                              id="mod2-value-proc-code"
                                label=""
                                value={props.values.procedureModifier2}
                                onChange={props.handleChanges('procedureModifier2')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-3"> Modifier-3 </label>
                              <TextField
                              id="mod3-value-proc-code"
                                label=""
                                value={props.values.procedureModifier3}
                                onChange={props.handleChanges('procedureModifier3')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                            <div className="cndt-col-3">
                              <label className="cndt-label" for="Pcr-modifier-4"> Modifier-4 </label>
                              <TextField
                              id="mod4-value-proc-code"
                                label=""
                                value={props.values.procedureModifier4}
                                onChange={props.handleChanges('procedureModifier4')}
                                inputProps={{ maxLength: 5 }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Value div end*/}
                  </div>
                </div>
              </div>
              {/* <!-- *** --> */}

              {/* <!-- Diagnosis Code --> */}
              <div className="mui-custom-form input-md">
                <div className="tabs-container">
                  
                  <div className="tabss-wrapper">
                    <div className="my-2">
                    <div className="tab-header p-0">
                    <h2 className="tab-heading float-left p-0">Diagnosis Code</h2>
                    <div className="clearfix"></div>
                  </div>
                      <div className="sub-radio set-rd-pos">
                        <Radio type="radio"
                        id="range-diag-code"
                          value="Range"
                          checked={props.values.diagCodeType === "Range"}
                          onChange={props.handleChanges('diagCodeType')}
                          className="mr-1"
                        /><label className="text-black mr-1"> Range</label>
                        <Radio type="radio"
                        id="value-diag-code"
                          value="Value"
                          checked={props.values.diagCodeType === "Value"}
                          onChange={props.handleChanges('diagCodeType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Value</label>

                        <Radio type="radio"
                        id="na-diag-code"
                          value="NA"
                          checked={(!props.values.diagCodeType) || (props.values.diagCodeType === 'NA')}
                          onChange={props.handleChanges('diagCodeType')}
                          className="mr-1"
                        />
                        <label className="text-black mr-1">NA</label>
                      </div>
                      {/* div sub radio end */}
                    </div>
                    {/* div sub radio end */}
                    {/* Range div */}
                    {(props.values.diagCodeType === 'Range') ? (
                      <div className="py-2">
                        <label className="cndt-label"> Diagnosis Code Range </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-5">
                            <TextField
                              id="max-range-diag-code"
                              label=""
                              value={props.values.beginDiagnosisCode}
                              onChange={props.handleChanges('beginDiagnosisCode')}
                              helperText={props.errors.beginDiagnosisCodeError ? CatagoryOfServiceConstants.DIAGNOSIS_CODE_BEGIN_ERROR : props.errors.beginDiagnosisCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.beginDiagnosisCodeError ? CatagoryOfServiceConstants.DIAGNOSIS_CODE_BEGIN_ERROR : props.errors.beginDiagnosisCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                          {/* <div className="cndt-col-1">
                      -
                                                </div> */}-
                    <div className="cndt-col-5">
                            <TextField
                            id="min-range-diag-code"
                              label=""
                              value={props.values.endDiagnosisCode}
                              onChange={props.handleChanges('endDiagnosisCode')}
                              helperText={props.errors.endDiagnosisCodeError ? CatagoryOfServiceConstants.DIAGNOSIS_CODE_END_ERROR : props.errors.endDiagnosisCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.endDiagnosisCodeError ? CatagoryOfServiceConstants.DIAGNOSIS_CODE_END_ERROR : props.errors.endDiagnosisCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Range div end*/}
                    {(props.values.diagCodeType === 'Value') ? (
                      <div className="py-2">
                        <label className="cndt-label" for="Diagnosis-code-Value"> Diagnosis Code Value </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-12">
                            <TextField
                            id="value-diag-code"
                              label=""
                              value={props.values.diagCodeValue}
                              onChange={props.handleChanges('diagCodeValue')}
                              helperText={props.errors.diagnosisCodeValueError ? CatagoryOfServiceConstants.DIAGNOSIS_CODE_VALUE_ERROR : null}
                              error={props.errors.diagnosisCodeValueError ? CatagoryOfServiceConstants.DIAGNOSIS_CODE_VALUE_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Value div end*/}

                  </div>
                </div>
              </div>
              {/* <!-- *** --> */}

              {/* <!-- Surgical Procedure Code --> */}
              <div className="mui-custom-form input-md">
                <div className="tabs-container">
                  
                  <div className="tabss-wrapper">
                    <div className="my-2">
                    <div className="tab-header p-0">
                    <h2 className="tab-heading float-left p-0">Surgical Procedure Code</h2>
                    <div className="clearfix"></div>
                  </div>
                      <div className="sub-radio set-rd-pos">
                        <Radio type="radio"
                        id="range-surg-proc-code"
                          value="Range"
                          checked={props.values.surgProcCodeType === "Range"}
                          onChange={props.handleChanges('surgProcCodeType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Range</label>
                        <Radio type="radio"
                        id="value-surg-proc-code"
                          value="Value"
                          checked={props.values.surgProcCodeType === "Value"}
                          onChange={props.handleChanges('surgProcCodeType')}
                          className="mr-1"
                        /><label className="text-black mr-1">Value</label>
                        <Radio type="radio"
                        id="na-surg-proc-code"
                          value="NA"
                          checked={(!props.values.surgProcCodeType) || (props.values.surgProcCodeType === 'NA')}
                          onChange={props.handleChanges('surgProcCodeType')}
                          className="mr-1"
                        />
                        <label className="text-black mr-1">NA</label>
                      </div>
                      {/* div sub radio end */}
                    </div>

                    {/* Range div */}
                    {(props.values.surgProcCodeType === 'Range') ? (
                      <div className="py-2">
                        <label className="cndt-label"> Surgical Procedure Code Range </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-5">
                            <TextField
                            id="min-range-surg-proc-code"
                              label=""
                              value={props.values.beginSurgicalProcedureCode}
                              onChange={props.handleChanges('beginSurgicalProcedureCode')}
                              helperText={props.errors.beginSurgProcedureCodeError ? CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_BEGIN_ERROR : props.errors.beginSurgProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.beginSurgProcedureCodeError ? CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_BEGIN_ERROR : props.errors.beginSurgProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                          {/* <div className="cndt-col-1">
                      -
                                                </div> */}-
                    <div className="cndt-col-5">
                            <TextField
                            id="max-range-surg-proc-code"
                              label=""
                              value={props.values.endSurgicalProcedureCode}
                              onChange={props.handleChanges('endSurgicalProcedureCode')}
                              helperText={props.errors.endSurgProcedureCodeError ? CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_END_ERROR : props.errors.endSurgProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              error={props.errors.endSurgProcedureCodeError ? CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_END_ERROR : props.errors.endSurgProcedureCodeFormatError ? CatagoryOfServiceConstants.INPUT_FORMAT_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Range div end*/}
                    {(props.values.surgProcCodeType === 'Value') ? (
                      <div className="py-2">
                        <label className="cndt-label" for="spc-code-value"> Surgical Procedure Code Value </label>
                        <div className="cndt-row bill-prov-type">
                          <div className="cndt-col-12">
                            <TextField
                            id="value-surg-proc-code"
                              label=""
                              value={props.values.surgProcCodeValue}
                              onChange={props.handleChanges('surgProcCodeValue')}
                              helperText={props.errors.surgProcedureCodeValueError ? CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_VALUE_ERROR : null}
                              error={props.errors.surgProcedureCodeValueError ? CatagoryOfServiceConstants.SURGICAL_PROCEDURE_CODE_VALUE_ERROR : null}
                              inputProps={{ maxLength: 4 }}
                            />
                          </div>
                        </div>
                      </div>
                    ) : null
                    }
                    {/* Value div end*/}
                  </div>
                </div>
              </div>
              {/* <!-- *** --> */}
            </div>
        </div>
      {/* </div> */}
    </form>
  );
}
