import * as actionTypes from './actionTypes';

const axiosPayLoad = {
  payload: null
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.RESETDATA:
      return axiosPayLoad;
    case actionTypes.CATAGORY_OF_SERVICE_SEARCH_TYPE:
      return { ...state, payload: action.cosSearchData,payloadTime: new Date()}
    case actionTypes.CATAGORY_OF_SERVICE_DELETE_RESULT:
    {
      return { ...state, deleteStatus: action.deleteStatus, deleteStatusTime: new Date() }
    }
    case actionTypes.CATEGORY_OF_SERVICE_DROPDOWNS:
      return { ...state, dropdowns: action.dropdowns }
    case actionTypes.CATEGORY_OF_SERVICE_DATA_ELEMENT_DROPDOWNS:
        return { ...state, deDropdowns: action.dropdowns }
    //return { ...state, dropdowns: { ...state, deDropdowns: action.dropdowns } }
    case actionTypes.CATAGORY_OF_SERVICE_CREATE_RESULT:
        return { ...state, createStatus: action.createStatus, createStatusTime: new Date()}
    case actionTypes.CATAGORY_OF_SERVICE_UPDATE_DATA:
        return { ...state, updateStatus: action.updateStatus, updateStatusTime: new Date()}
    case actionTypes.CATEGORY_OF_SERVICE_EACH_SEARCH_DATA:
    return { ...state, eachRecord: action.result, eachTime: new Date() }
    default: return state;
  }
  
};

export default reducer;
