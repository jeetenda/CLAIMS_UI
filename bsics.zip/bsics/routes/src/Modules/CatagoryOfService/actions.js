import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';
//import catagoryOfServiceData from './CatagoryOfServiceData.json';

export const resetCatagoryOfService = () => ({
    type: actionTypes.RESETDATA,
    resetData: []
});

export const dispatchcosSearch = (response) => ({
    type: actionTypes.CATAGORY_OF_SERVICE_SEARCH_TYPE,
    cosSearchData: response
    //dummy data
    // cosSearchData: catagoryOfServiceData
});
export const dispatchDeleteSearch = (response) => ({
    type: actionTypes.CATAGORY_OF_SERVICE_DELETE_RESULT,
    deleteStatus: response
});
export const dispatchUpdateCos = (response) => ({
    type: actionTypes.CATAGORY_OF_SERVICE_UPDATE_DATA,
    updateStatus: response
});

export const dispatchCreateCos = (response) => ({
    type: actionTypes.CATAGORY_OF_SERVICE_CREATE_RESULT,
    createStatus: response
});

export const dispatchCosEachSearch = (response) => ({
    type: actionTypes.CATEGORY_OF_SERVICE_EACH_SEARCH_DATA,
    result: response
});

//dropdowns
export const dispatchDropdowns = (response) => ({
    type: actionTypes.CATEGORY_OF_SERVICE_DROPDOWNS,
    dropdowns: response
})

export const dispatchElementDataDropdowns = (response) => ({
    type: actionTypes.CATEGORY_OF_SERVICE_DATA_ELEMENT_DROPDOWNS,
    dropdowns: response
});

export const cosDropdowns = values => dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_GETREFERENCEDATA_ENDPOINT}`, values)
        .then(response => {
            if (Object.keys(response.data.listObj).length > 0) {
                dispatch(dispatchDropdowns(response.data.listObj));
            }
        })
}

export const cosDataElementDropdowns = values => dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_ALL_SET_ENDPOINT}`, values)
        .then(response => {
            dispatch(dispatchElementDataDropdowns(response.data));
        })
}


export const catagoryOfServiceGetAllSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_ADJUDICATION_COS_LISTFETCH_ENDPOINT}`, values)
        .then(response => {
            if (response.data.status === 500 || response.data.status === 400) {
                dispatch(dispatchcosSearch(response.data));
            } else {
                dispatch(dispatchcosSearch(response.data.searchResults));
            }
        })
        .catch(error => {
            dispatch(dispatchcosSearch(error.data));
        })
};

export const catagoryOfServiceCriteriaSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_ADJUDICATION_COS_SEARCH_ENDPOINT}`, values)
        .then(response => {
            if (response.data.status === 500 || response.data.status === 400) {
                dispatch(dispatchcosSearch(response.data));
            } else if (response.data.searchResults === null) {
                dispatch(dispatchcosSearch([]));
            }else {
                dispatch(dispatchcosSearch(response.data.searchResults));
            }
            
        })
        .catch(error => {
            dispatch(dispatchcosSearch(error.data));
        })
};

export const cosDeleteAction = values => dispatch => {
    return axios.delete(`${serviceEndPoint.CLAIM_ADJUDICATION_COS_DELETE_ENDPOINT}`, values)
    .then(response => {
        if (response.status === 200 ) {
            dispatch(dispatchDeleteSearch(true));
        } else {
            dispatch(dispatchDeleteSearch(false));
        }
    })
    .catch(error => {
        dispatch(dispatchDeleteSearch(error.data));
    })
};

export const editCosAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_ADJUDICATION_COS_UPDATE_ENDPOINT}`, values)
    .then(response => {
        if (response.status === 200) {
            dispatch(dispatchUpdateCos(true));
        } else {
            dispatch(dispatchUpdateCos(false));
        }
    })
    .catch(error => {
        dispatch(dispatchUpdateCos(error.data));
    })
};

export const createCosAction = values => dispatch => {
    return axios.put(`${serviceEndPoint.CLAIM_ADJUDICATION_COS_ADD_ENDPOINT}`, values)
    .then(response => {
        dispatch(dispatchCreateCos(response.data));
    })
    .catch(error => {
        dispatch(dispatchCreateCos(error.data));
    })
};

export const cosCriteriaEachSearchAction = values => dispatch => {
    return axios.get(serviceEndPoint.CLAIM_ADJUDICATION_COS_FETCHDATA_ENDPOINT + values)
        .then(response => {
            console.log(response);
            if (response.data.status === 500 || response.data.status === 400) {
                dispatch(dispatchCosEachSearch(response.data));
            } else {
                dispatch(dispatchCosEachSearch(response.data.searchResults[0]));
            }
        })
        .catch(error => {
            console.log(error)
            dispatch(dispatchCosEachSearch(error.data));
        })
};

