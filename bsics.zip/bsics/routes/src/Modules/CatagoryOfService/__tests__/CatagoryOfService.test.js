import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import "babel-polyfill"

import CatagoryOfServiceAddForm from "../Components/CatagoryOfServiceAddForm"

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 22-Nov-2020
   * @author Himanshu Joshi
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

const reactMock = require("react");

const setHookState = (newState) =>
    jest.fn().mockImplementation(() => [newState, () => { }]);

describe('Coordination Of Benefits Form Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper, wrapper1, wrapper2, wrapper3, wrapper4, wrapper5, wrapper6, wrapper7

    // intitial state for component
    const initialState = {}

    // intitial props for component
    const componentProps = {
        dropdowns: {
            "Reference#1019": [{ code: "MED", description: "MED-MEDICAID", longDescription: null }],
            "Claims#1020": [{ code: "001", description: "001-InpHspGen", longDescription: null }],
            "Claims2#1000": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1027": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1038": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1448": [{ code: "H", description: "H-Header", longDescription: null }],
            "Provider#1448": [{ code: "H", description: "H-Header", longDescription: null }]
        },
        errors: {
            assignCodeError: undefined,
            beginBillProviderTypeError: undefined,
            beginBillProviderTypeFormatError: undefined,
            beginDiagnosisCodeError: undefined,
            beginDiagnosisCodeFormatError: undefined,
            beginDtInvalidErr: undefined,
            beginProcedureCodeError: undefined,
            beginProcedureCodeFormatError: undefined,
            beginRenderingProviderTypeError: undefined,
            beginRenderingProviderTypeFormatError: undefined,
            beginSurgProcedureCodeError: undefined,
            beginSurgProcedureCodeFormatError: undefined,
            billProviderTypeValueError: undefined,
            claimFormCodeError: undefined,
            claimTypeCodeError: undefined,
            cosCodeError: undefined,
            diagnosisCodeValueError: undefined,
            endBillProviderTypeError: undefined,
            endBillProviderTypeFormatError: undefined,
            endDiagnosisCodeError: undefined,
            endDiagnosisCodeFormatError: undefined,
            endDtInvalidErr: undefined,
            endProcedureCodeError: undefined,
            endProcedureCodeFormatError: undefined,
            endRenderingProviderTypeError: undefined,
            endRenderingProviderTypeFormatError: undefined,
            endSurgProcedureCodeError: undefined,
            endSurgProcedureCodeFormatError: undefined,
            lobCodeError: undefined,
            procCodeValueError: undefined,
            renderingProviderTypeValueError: undefined,
            showBeginDateError: undefined,
            showDateError: undefined,
            showEndDateError: undefined,
            surgProcedureCodeValueError: undefined
        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            addedAuditTimeStamp: new Date(),
            addedAuditUserID: null,
            additionalCriteriaList: [{ additionalColName: "", additionalColNameDesc: "", beginValueData: "", endValueData: "", valueData: "" }],
            auditTimeStamp: new Date(),
            auditUserID: null,
            beginBillingProviderTypeCode: null,
            beginDate: "",
            beginDiagnosisCode: null,
            beginProcedureCode: null,
            beginRenderingProviderTypeCode: null,
            beginSurgicalProcedureCode: null,
            billProviderTypeValue: "-1",
            categoryOfServiceCode: "-1",
            categoryOfServiceSK: 0,
            claimFormCode: "-1",
            claimTypeCode: "-1",
            dbRecord: false,
            defaultIndicator: false,
            endBillingProviderTypeCode: null,
            endDate: "",
            endDiagnosisCode: null,
            endProcedureCode: null,
            endRenderingProviderTypeCode: null,
            endSurigicalProcedureCode: null,
            headerLineAssignCode: "-1",
            lobCode: "-1",
            rankNumber: "",
            renderingProviderTypeValue: "-1",
            sortColumn: null,
            versionNo: 0,
            billProviderType: 'Value',
            renderingProviderType: 'Value'
        }
    }

    const componentProps1 = {
        dropdowns: {
            "Reference#1019": [{ code: "MED", description: "MED-MEDICAID", longDescription: null }],
            "Claims#1020": [{ code: "001", description: "001-InpHspGen", longDescription: null }],
            "Claims2#1000": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1027": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1038": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1448": [{ code: "H", description: "H-Header", longDescription: null }],
            "Provider#1448": [{ code: "H", description: "H-Header", longDescription: null }]
        },
        errors: {
            assignCodeError: true,
            beginBillProviderTypeError: true,
            beginBillProviderTypeFormatError: true,
            beginDiagnosisCodeError: true,
            beginDiagnosisCodeFormatError: true,
            beginDtInvalidErr: true,
            beginProcedureCodeError: true,
            beginProcedureCodeFormatError: true,
            beginRenderingProviderTypeError: true,
            beginRenderingProviderTypeFormatError: true,
            beginSurgProcedureCodeError: true,
            beginSurgProcedureCodeFormatError: true,
            billProviderTypeValueError: true,
            claimFormCodeError: true,
            claimTypeCodeError: true,
            cosCodeError: true,
            diagnosisCodeValueError: true,
            endBillProviderTypeError: true,
            endBillProviderTypeFormatError: true,
            endDiagnosisCodeError: true,
            endDiagnosisCodeFormatError: true,
            endDtInvalidErr: true,
            endProcedureCodeError: true,
            endProcedureCodeFormatError: true,
            endRenderingProviderTypeError: true,
            endRenderingProviderTypeFormatError: true,
            endSurgProcedureCodeError: true,
            endSurgProcedureCodeFormatError: true,
            lobCodeError: true,
            procCodeValueError: true,
            renderingProviderTypeValueError: true,
            showBeginDateError: true,
            showDateError: true,
            showEndDateError: true,
            surgProcedureCodeValueError: true
        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            addedAuditTimeStamp: new Date(),
            addedAuditUserID: null,
            additionalCriteriaList: [{ additionalColName: "", additionalColNameDesc: "", beginValueData: "", endValueData: "", valueData: "" }],
            auditTimeStamp: new Date(),
            auditUserID: null,
            beginBillingProviderTypeCode: null,
            beginDate: "12/11/2020",
            beginDiagnosisCode: null,
            beginProcedureCode: null,
            beginRenderingProviderTypeCode: null,
            beginSurgicalProcedureCode: null,
            billProviderTypeValue: "-1",
            categoryOfServiceCode: "-1",
            categoryOfServiceSK: 0,
            claimFormCode: "-1",
            claimTypeCode: "-1",
            dbRecord: false,
            defaultIndicator: false,
            endBillingProviderTypeCode: null,
            endDate: "12/11/2020",
            endDiagnosisCode: null,
            endProcedureCode: null,
            endRenderingProviderTypeCode: null,
            endSurigicalProcedureCode: null,
            headerLineAssignCode: "-1",
            lobCode: "-1",
            rankNumber: "",
            renderingProviderTypeValue: "-1",
            sortColumn: null,
            versionNo: 0,
            billProviderType: 'Value',
            renderingProviderType: 'Value'
        }
    }


    const componentProps2 = {
        dropdowns: {
            "Reference#1019": [{ code: "MED", description: "MED-MEDICAID", longDescription: null }],
            "Claims#1020": [{ code: "001", description: "001-InpHspGen", longDescription: null }],
            "Claims2#1000": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1027": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1038": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1448": [{ code: "H", description: "H-Header", longDescription: null }],
            "Provider#1448": [{ code: "H", description: "H-Header", longDescription: null }]
        },
        errors: {
            beginDtInvalidErr: true,
            endDtInvalidErr: true,
        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            billProviderType: 'Range',
            procedureCodeType: false,
            procedureCodeType: "NA"
        }
    }

    const componentProps3 = {
        dropdowns: {
            "Reference#1019": [{ code: "MED", description: "MED-MEDICAID", longDescription: null }],
            "Claims#1020": [{ code: "001", description: "001-InpHspGen", longDescription: null }],
            "Claims2#1000": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1027": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1038": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1448": [{ code: "H", description: "H-Header", longDescription: null }],
            "Provider#1448": [{ code: "H", description: "H-Header", longDescription: null }]
        },
        errors: {
            beginDtInvalidErr: true,
            endDtInvalidErr: true,
            beginProcedureCodeError: true,
            beginBillProviderTypeError: true,
            endBillProviderTypeError: true
        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            billProviderType: 'Range',
            procedureCodeType: 'Range',
            renderingProviderType: "Range"
        }
    }


    const componentProps4 = {
        dropdowns: {
            "Reference#1019": [{ code: "MED", description: "MED-MEDICAID", longDescription: null }],
            "Claims#1020": [{ code: "001", description: "001-InpHspGen", longDescription: null }],
            "Claims2#1000": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1027": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1038": [{ code: "H", description: "H-Header", longDescription: null }],
            "Claims#1448": [{ code: "H", description: "H-Header", longDescription: null }],
            "Provider#1448": [{ code: "H", description: "H-Header", longDescription: null }]
        },
        errors: {
            beginDtInvalidErr: true,
            endDtInvalidErr: true,
            beginBillProviderTypeFormatError: true,
            endBillProviderTypeFormatError: true,
            billProviderTypeValueError: true
        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            billProviderType: 'Range',
            procedureCodeType: 'Range',
            renderingProviderType: "Range"
        }
    }


    const componentProps5 = {
        dropdowns: {

        },
        errors: {
            beginRenderingProviderTypeError: true,
            endRenderingProviderTypeError: true,
            beginRenderingProviderTypeFormatError: false,
            endRenderingProviderTypeFormatError: false,
            beginProcedureCodeError: true,
            endProcedureCodeError: true

        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            renderingProviderType: 'Range',
            procedureCodeType: 'Range'
        }
    }

    const componentProps6 = {
        dropdowns: {

        },
        errors: {
            beginRenderingProviderTypeFormatError: true,
            beginRenderingProviderTypeError: false,
            endRenderingProviderTypeFormatError: true,
            endRenderingProviderTypeError: false,
            beginProcedureCodeFormatError: true,
            endProcedureCodeFormatError: true
        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            renderingProviderType: 'Range',
            procedureCodeType: 'Range'
        }
    }


    const componentProps7 = {
        dropdowns: {

        },
        errors: {
            procCodeValueError: true

        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            procedureCodeType: 'Value',
            diagCodeType: false
        }
    }


    const componentProps8 = {
        dropdowns: {

        },
        errors: {
            procCodeValueError: false

        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            procedureCodeType: 'Value',
            diagCodeType: "diagCodeType"
        }
    }


    const componentProps9 = {
        dropdowns: {

        },
        errors: {
            beginDiagnosisCodeError: true

        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            diagCodeType: "Range"
        }
    }

    const componentProps10 = {
        dropdowns: {

        },
        errors: {
            beginDiagnosisCodeFormatError: true

        },
        formEditorAddType: "add",
        handelDateChange: jest.fn(),
        handleChanges: jest.fn(name),
        values: {
            diagCodeType: "Range"
        }
    }

    const stateChangeFn = jest.fn();

    //beforeEach Run before testcases is run  

    //   beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
    //console.log(wrapper.debug())
    //   })


    wrapper1 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps1} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    wrapper2 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps2} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    wrapper3 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps3} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    wrapper4 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps4} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    wrapper5 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps5} /></Router></Provider>).dive().dive().dive().dive
        ().dive().dive()

    wrapper6 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps6} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    wrapper7 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps7} /></Router></Provider>).dive().dive().dive().dive().dive().dive()


    wrapper7 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps8} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    wrapper7 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps9} /></Router></Provider>).dive().dive().dive().dive().dive().dive()


    wrapper7 = shallow(<Provider store={store}><Router><CatagoryOfServiceAddForm  {...componentProps10} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    //expect used for assert the component and match the output with testing condition

    describe('Render Other CatagoryOfService Form Component', () => {

        it('should render form without error', () => {
            const component = wrapper.find("#form")
            expect(component.length).toBe(1);

        })

        it('should render bgn-date-add-edit without error', () => {
            const component = wrapper.find("#bgn-date-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render end-date-add-edit without error', () => {
            const component = wrapper.find("#end-date-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render lob-add-edit without error', () => {
            const component = wrapper.find("#lob-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render cos-add-edit without error', () => {
            const component = wrapper.find("#cos-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render assign-to-add-edit without error', () => {
            const component = wrapper.find("#assign-to-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render claim-form-add-edit without error', () => {
            const component = wrapper.find("#claim-form-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render claim-type-add-edit without error', () => {
            const component = wrapper.find("#claim-type-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render rank-add-edit without error', () => {
            const component = wrapper.find("#rank-add-edit")
            expect(component.length).toBe(1);

        })

        it('should render range-bpt without error', () => {
            const component = wrapper.find("#range-bpt")
            expect(component.length).toBe(1);

        })

        it('should render range-rpt without error', () => {
            const component = wrapper.find("#range-rpt")
            expect(component.length).toBe(1);

        })

        it("should render bgn-date-add-edit without error", () => {
            const component = wrapper.find("#bgn-date-add-edit")
            expect(component.length).toBe(1);
        });

        it("should render value-rpt without error", () => {
            const component = wrapper.find("#value-rpt").simulate("change", {});
            expect(component.length).toBe(1);
        });

        it("should render bgn-date-add-edit without error", () => {
            const component = wrapper.find("#bgn-date-add-edit").simulate("change", {});
            expect(component.length).toBe(1);
        });

        
        it("should render na-rpt without error", () => {
            const component = wrapper.find("#na-rpt");
            expect(component.length).toBe(1);
        });

        it("should renderrange-proc-code without error", () => {
            const component = wrapper.find("#range-proc-code");
            expect(component.length).toBe(1);
        });

        it("should render value-proc-code without error", () => {
            const component = wrapper.find("#value-proc-code");
            expect(component.length).toBe(1);
        });

        it("should na-proc-code without error ", () => {
            const component = wrapper.find("#na-proc-code");
            expect(component.length).toBe(1);
        });


        it("should render range-rpt without error", () => {
            const component = wrapper.find("#range-diag-code");
            expect(component.length).toBe(1);
        });

    })

})





