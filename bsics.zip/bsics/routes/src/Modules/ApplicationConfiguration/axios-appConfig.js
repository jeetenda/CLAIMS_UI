import axios from 'axios';

const instance = axios.create({
  baseURL: 'https://react-my-appconfig.firebaseio.com/'
//   timeout: 1000,
//   headers: { 'X-Custom-Header': 'foobar' }
});

export default instance;
