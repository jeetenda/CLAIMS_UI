/* eslint-disable no-unused-vars */
import React, { useEffect, useRef } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import SystemParameterTable from './SystemParameterTable';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import MenuItem from '@material-ui/core/MenuItem';
import {
  searchSystemParameterAction,
  resetSearchSystemParameters
} from '../../Store/Actions/systemParameter/systemParameterActions';
import { useDispatch, useSelector } from 'react-redux';
import {
  ToastsContainer,
  ToastsStore,
  ToastsContainerPosition
} from 'react-toasts';
import * as SystemparameterConstants from './systemParameterConstants';
import { withRouter } from 'react-router';
import { AppConfigDropdownActions } from '../../Store/Actions/AppConfigCommon/AppConfigActions';
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import dropdownCriteria from './SystemParameterSearch.json';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../../SharedModules/Store/Actions/SharedAction';
import Footer from '../../../../SharedModules/Layout/footer';
import * as AppConstants from '../../../../SharedModules/AppConstants';
import "./SystemParameter.css"

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap'
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1)
  },
  dense: {
    marginTop: theme.spacing(2)
  },
  menu: {
    width: 200
  }
}));

function SystemParameter (props) {
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const toPrintRef = useRef();
  const dispatch = useDispatch();
  const onReset = () => dispatch(resetSearchSystemParameters());

  const [useEffectValues, setUseEffectValues] = React.useState([]);
  let errorMessagesArray = [];

  const [redirect, setRedirect] = React.useState(0);
  const [showTable, setShowTable] = React.useState(false);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [showNoRecords, setShowNoRecords] = React.useState(false);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  let paylod = [];

  const onSearch = (values, parameterNumberStartsWith) =>
    dispatch(searchSystemParameterAction(values, parameterNumberStartsWith));
  paylod = useSelector(
    state => state.appConfigState.systemParameterState.payload
  );

  const functionalAreaDataDescriptionMap = functionalArea => {
    const filteredValue = functionalAreaData.filter(
      (fnArea, index) => fnArea.code === functionalArea
    );
    if (filteredValue && filteredValue.length > 0) {
      return filteredValue[0].description;
    }
    return functionalArea;
  };

  if (paylod) {
    paylod.map((data, index) => {
      if (data.functionalArea !== null || data.functionalArea !== '') {
        data.functionalAreaDesc = functionalAreaDataDescriptionMap(
          data.functionalArea
        );
      }
    });
  }
  const dropDownDispatch = dropdownvalues =>
    dispatch(AppConfigDropdownActions(dropdownvalues));

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
  }, []);
  const payloadData = paylod ? paylod[0] : {};
  const dropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.appConfigDropdown
  );

  const systemError = useSelector(
    state => state.appConfigState.systemParameterState.systemError
  );
  useEffect(() => {
    if (systemError) {
      setspinnerLoader(false);
      errorMessagesArray = [];
      errorMessagesArray.push(systemError);
      seterrorMessages(errorMessagesArray);
    }
  }, [systemError]);

  useEffect(() => {
    if (paylod && paylod.systemFailue) {
      const tempArray = [];
      tempArray.push(SystemparameterConstants.GENERIC_SYSTEM_ERROR);
      seterrorMessages(tempArray);
      setspinnerLoader(false);
    }
    if (paylod != null && paylod.length > 1) {
      setShowTable(true);
    }
    if (paylod != null && (paylod.length > 0 || paylod.length === 0)) {
      setspinnerLoader(false);
    }
    if (paylod != null && paylod.length === 0) {
      setShowNoRecords(true);
    }
  }, [paylod]);

  useEffect(() => {
    onReset();
  }, []);

  useEffect(() => {
    if (dropdown && dropdown.listObj && dropdown.listObj['Reference#1017']) {
      setFunctionalAreaData(dropdown.listObj['Reference#1017']);
    }
  }, [dropdown]);

  if (redirect === 1) {
    if (paylod != null) {
      if (paylod.length === 1) {
        props.history.push({
          pathname: '/SystemParametersEdit',
          state: { payloadData }
        });
      }
    }
  }

  const classes = useStyles();
  const [values, setValues] = React.useState({
    parameterNumber: '',
    functionalArea: 'Please Select One',
    description: ''
  });

  const [
    parameterNumberStartsWith,
    setParameterNumberStartsWith
  ] = React.useState(false);
  // const [functionalAreaDropdown, setFunctionalAreaDropdown] = React.useState([]);

  const handleChangeParameter = () => {
    setParameterNumberStartsWith(!parameterNumberStartsWith);
  };

  const [functionalAreaValue, setFunctionalAreaValue] = React.useState('');
  const systemParametercons = SystemparameterConstants;

  const [
    { showParameterNumberError, showDescriptionError },
    setShowError
  ] = React.useState(false);

  const resetTable = () => {
    paylod = [];
    onReset();
    setShowNoRecords(false);
    seterrorMessages([]);
    setParameterNumberStartsWith(false);
    setShowError({
      showParameterNumberError: false,
      showDescriptionError: false
    });
    console.log(parameterNumberStartsWith);
    setValues({
      parameterNumber: '',
      functionalArea: 'Please Select One',
      description: ''
    });
    const valuetoredirect = redirect - 1;
    setRedirect(valuetoredirect);
  };

  const handleChange = name => event => {
    if(name==="description"){
if( event.target.value.length<=30){

  setValues({ ...values, [name]: event.target.value });  
}

    }
else{
  setValues({ ...values, [name]: event.target.value });
}
  };
  const functionalAreachange = value => {
    setFunctionalAreaValue(value.functionalArea);
  };

  const searchSystemParameter = () => {
    setspinnerLoader(false);
    console.log(values);
    errorMessagesArray = [];
    seterrorMessages([]);
    var showDescriptionError;
    var showParameterNumberError = false;
    if (
      values.descriptionSelected &&
      (!values.description || values.description.length < 2)
    ) {
      showDescriptionError = true;
      errorMessagesArray.push(systemParametercons.DESCRIPTION_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (
      parameterNumberStartsWith &&
      (!values.parameterNumber || values.parameterNumber.length < 2)
    ) {
      showParameterNumberError = true;
      errorMessagesArray.push(systemParametercons.PARAMETERNUMBER_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    } else if (errorMessagesArray.length === 0) {
      setShowTable(false);
      setspinnerLoader(true);

      const searchCriteria = {
        parameterNumber:
          values.parameterNumber !== '' ? values.parameterNumber : null,
        paramNumber: null,
        functionalArea:
          values.functionalArea !== 'Please Select One'
            ? values.functionalArea
            : null,
        description: values.description !== '' ? values.description : null,
        parameterNumberStartsWith: parameterNumberStartsWith,
        descriptionStartsOrContains:
          values.descriptionSelected === 'StartsWith'
            ? 0
            : values.descriptionSelected === 'Contains'
              ? 1
              : null,
        withoutNotesDataFlag: false
      };

      console.log(searchCriteria);
      seterrorMessages([]);
      onSearch(searchCriteria, parameterNumberStartsWith);
      let valuetoredirect = 0;
      valuetoredirect = valuetoredirect + 1;
      setRedirect(valuetoredirect);
    }
    setShowError({
      showDescriptionError: showDescriptionError,
      showParameterNumberError: showParameterNumberError
    });
  };

  return (
        <div className="pos-relative pos-relatives">
      {spinnerLoader ? <Spinner /> : null}
      <div className="tabs-container" ref={toPrintRef}>
        {errorMessages.length > 0 ? (
          <div class="alert alert-danger custom-alert" role="alert">
            {errorMessages.map(message => (
              <li>{message}</li>
            ))}
          </div>
        ) : null}
        {errorMessages.length === 0 &&
          paylod &&
          paylod.length === 0 &&
          showNoRecords ? (
            <div class="alert alert-danger custom-alert" role="alert">
              <li>{systemParametercons.NO_RECORD_FOUND}</li>
            </div>
          ) : null}
        <div className="tab-header tab-headers">
          <h1 className="tab-heading float-left">Search System Parameter</h1>
          <div className="float-right mt-1 pt-1 hide-on-print">
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise(resolve => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button className="btn btn-primary ml-1">
                  <i class="fa fa-print" aria-hidden="true"></i>
                  Print
                </Button>
              )}
              content={() => toPrintRef.current}
            />

            <Button color="primary" className="btn btn-secondary ml-1">
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div className="tab-body pb-2">
          <form className={classes.container} noValidate autoComplete="off">
            <div className="mui-custom-form with-select input-md mui-custom-forms">
              <TextField
                id="standard-select-functionalArea"
                fullWidth
                select
                label="Functional Area"
                value={values.functionalArea}
                onChange={handleChange('functionalArea')}
                SelectProps={{
                  MenuProps: {
                    className: classes.menu
                  }
                }}
                placeholder=""
                InputLabelProps={{
                  shrink: true
                }}
              >
                <MenuItem
                  selected
                  key="Please Select One"
                  value="Please Select One"
                >
                  Please Select One
                </MenuItem>
                {functionalAreaData
                  ? functionalAreaData.map((item, index) => (
                    <MenuItem key={index} value={item.code}>
                      {item.description}
                    </MenuItem>
                  ))
                  : null}
              </TextField>
            </div>
            <div className="mui-custom-form input-md mui-custom-forms">
              <TextField
                id="routing-bank"
                fullWidth
                label="Parameter Number"
                value={values.parameterNumber}
                onChange={handleChange('parameterNumber')}
                InputLabelProps={{
                  shrink: true
                }}
                inputProps={{ maxLength: 10 }}
                onInput={e => {
                  e.target.value = e.target.value.replace(
                    AppConstants.NUMBER_ONLY_REGEX,
                    ''
                  );
                }}
                helperText={
                  showParameterNumberError
                    ? systemParametercons.PARAMETERNUMBER_ERROR
                    : null
                }
                error={
                  showParameterNumberError
                    ? systemParametercons.PARAMETERNUMBER_ERROR
                    : null
                }
              />
              <div className="sub-radio sub-radios">
                <FormControlLabel
                  control={
                    <Checkbox
                      color="primary"
                      checked={parameterNumberStartsWith}
                      value={parameterNumberStartsWith}
                      onChange={handleChangeParameter}
                    />
                  }
                  label="Starts With"
                />
              </div>
            </div>
            <div className="mui-custom-form input-xl mui-custom-forms">
              <TextField
                id="lock-box-name"
                fullWidth
                label="Description"
                value={values.description}
                onChange={handleChange('description')}
                InputLabelProps={{
                  shrink: true
                }}
                inputProps={{ maxLength: 30 }}
                helperText={
                  showDescriptionError
                    ? systemParametercons.DESCRIPTION_ERROR
                    : null
                }
                error={
                  showDescriptionError
                    ? systemParametercons.DESCRIPTION_ERROR
                    : null
                }
              />
              <div className="sub-radio sub-radios">
                <input
                  type="radio"
                  value="StartsWith"
                  id="descriptionStartsId"
                  checked={values.descriptionSelected === 'StartsWith'}
                  onChange={handleChange('descriptionSelected')}
                />
                <label className="text-black" for="descriptionStartsId">
                  Starts With
                </label>
                <input
                  type="radio"
                  value="Contains"
                  id="descriptionContainsId"
                  checked={values.descriptionSelected === 'Contains'}
                  onChange={handleChange('descriptionSelected')}
                  className="ml-2"
                />
                <label className="text-black" for="descriptionContainsId">
                  Contains
                </label>
              </div>
            </div>
          </form>
          <div className="float-right mr-3 mt-1 pt-1">
            <Button
              className="btn btn-primary ml-1"
              onClick={() => searchSystemParameter()}
            >
              <i class="fa fa-search" aria-hidden="true"></i>
              Search
            </Button>
            <Button
              className="bt-reset btn-transparent ml-1"
              onClick={() => resetTable()}
            >
              <i class="fa fa-undo" aria-hidden="true"></i>
              Reset
            </Button>
          </div>
          <div className="clearfix"></div>
          {showTable ? (
            <div className="tab-holder pb-2">
              <SystemParameterTable
                tableData={paylod && !paylod.systemFailue ? paylod : []}
              />
            </div>
          ) : null}
          <Footer print />
        </div>
      </div>
    </div>
  );
}
export default withRouter((SystemParameter));
