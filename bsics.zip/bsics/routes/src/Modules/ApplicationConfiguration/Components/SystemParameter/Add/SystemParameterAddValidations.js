import {ToastsContainer, ToastsStore, ToastsContainerPosition} from 'react-toasts';


export default function validate(values) {
    //const errors = {};
    const requiredFields = [
        'lobDetail',
        'dataFormat',
        'description',
        'paramNumber',
        'functionalArea'
    ];
    requiredFields.map(field => {
        if (!values[field] || values[field]=="Please Select One") {
            //errors[field] = 'Required';
            ToastsStore.error(field+" "+"is required");
            return false;
        }
        
    });
    //ToastsStore.success("All fields Added Successfuly");
   
    //return errors;
 };