/* eslint-disable no-unused-vars */
import React, { useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { useDispatch, useSelector } from 'react-redux';
import { withRouter } from 'react-router';

import { systemParameterRowClickAction } from '../../Store/Actions/systemParameter/systemParameterActions';
import TableComponent from '../../../../SharedModules/Table/Table';


const headCells = [
  { id: 'parameterNumber', numeric: false, enableHyperLink: true, disablePadding: true, label: 'Parameter Number', width: 180},
  { id: 'description', numeric: false, disablePadding: false, label: 'Description', width: 350 },
  { id: 'functionalAreaDesc', numeric: false, disablePadding: false, label: 'Functional Area', width: 260 }
];

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing(1)
  },
  paper: {
    width: '100%',
    marginBottom: theme.spacing(2)
  },
  table: {
    minWidth: 750
  },
  tableWrapper: {
    overflowX: 'auto'
  },
  visuallyHidden: {
    border: 0,
    clip: 'rect(0 0 0 0)',
    height: 1,
    margin: -1,
    overflow: 'hidden',
    padding: 0,
    position: 'absolute',
    top: 20,
    width: 1
  }
}));

function SystemParameterTable (props) {
  const classes = useStyles();
  const [spinnerLoader, setspinnerLoader] = React.useState(false);

  const dispatch = useDispatch();

  const [redirect, setRedirect] = React.useState(0);

  const onRowClick = values => dispatch(systemParameterRowClickAction(values));
  const payloadData = useSelector(state => state.appConfigState.systemParameterState.rowSearchSysParam);
  if (redirect === 1) {
    if (payloadData) {
      props.history.push({
        pathname: '/SystemParametersEdit',
        state: { payloadData }
      });
    }
  }
  useEffect(() => {
    if (payloadData != null) {
      setspinnerLoader(false);
    }
  }, [payloadData]);

  const editRow = row => event => {
    onRowClick(row);
    setspinnerLoader(true);
    const valuetoredirect = redirect + 1;
    setRedirect(valuetoredirect);
  };

  return (
    <div className={classes.root}>
      {
        props.tableData.length !== 0
          ? <TableComponent pathTo='/SystemParametersEdit?data=' headCells={headCells} isSearch={true} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} spinnerLoader={spinnerLoader} defaultSortColumn={headCells[0].id} isSearch = {true}/>
          : null}
    </div>
  );
}
export default withRouter((SystemParameterTable));
