export const headCells = [
    {
        id: 'timestamp',
        numeric: false,
        disablePadding: true,
        label: 'Timestamp',
        isDateTime: true,
        width: '25%'
    },
    {
        id: 'user',
        numeric: false,
        disablePadding: false,
        label: 'User',
        width: '15%'
    },
    {
        id: 'activity',
        numeric: false,
        disablePadding: false,
        label: 'Activity',
        isNote: true,
        width: '15%'
    },
    {
        id: 'columnName',
        numeric: false,
        disablePadding: false,
        label: 'Column',
        width: '15%'
    },
    {
        id: 'beforeValue',
        numeric: false,
        disablePadding: false,
        label: 'Before',
        width: '15%'
    },
    {
        id: 'afterValue',
        numeric: false,
        disablePadding: false,
        label: 'After',
        width: '15%'
    }
  ];
  
  export const R_PARAM_TB = 'r_param_tb'
  export const R_PARAM_DTL_TB = 'r_param_dtl_tb'
  export const F_HDR_TB = 'f_hdr_tb'
  export const F_PMT_TB = 'f_pmt_tb'