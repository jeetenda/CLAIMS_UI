/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import DialogContentText from '@material-ui/core/DialogContentText';
import SystemParameterAddValueTable from './SystemParameterAddValueTable';
import DateFnsUtils from '@date-io/date-fns';
import { ToastsContainer, ToastsStore, ToastsContainerPosition } from 'react-toasts';
import * as SystemParameterAddConstants from './SystemParameterAddConstants';
// eslint-disable-next-line import/no-duplicates
import * as DateUtils from '../../../../../SharedModules/DateUtilities/DateUtilities';
import InputAdornment from '@material-ui/core/InputAdornment';
import FormControl from '@material-ui/core/FormControl';
import Input from '@material-ui/core/Input';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import { withRouter } from 'react-router';

import { useDispatch, useSelector } from 'react-redux';
import { addSystemParameter, systemParameterRowClickAction } from '../../../Store/Actions/systemParameter/systemParameterActions';
import ErrorMessages from '../../../../../SharedModules/Errors/ErrorMessages';
import UnsavedChangesMessage from '../../../../../SharedModules/Errors/UnsavedChangesMessage';

// eslint-disable-next-line import/no-duplicates
import { setSelectedDate, validateDateMinimumValue, convertDateTimeToTimestamp } from '../../../../../SharedModules/DateUtilities/DateUtilities';
import * as AppConstants from '../../../../../SharedModules/AppConstants';
import { AppConfigDropdownActions, notesUsageTypeDropdown } from '../../../Store/Actions/AppConfigCommon/AppConfigActions';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider
} from '@material-ui/pickers';
import { DialogTitle, DialogContent, DialogActions } from '../../../../../SharedModules/Dialog/DialogUtilities';
import TabPanel from '../../../../../SharedModules/TabPanel/TabPanel';
import dropdownCriteria from '../SystemParameterAddUpdate.json';
import moment from 'moment';
import Spinner from '../../../../../SharedModules/Spinner/Spinner';
import Notes from '../../../../../SharedModules/Notes/Notes';
import ReactToPrint from "react-to-print";
import { setPrintLayout } from "../../../../../SharedModules/Store/Actions/SharedAction";
import Footer from "../../../../../SharedModules/Layout/footer";
import './add.css'
// let newData = [];
let requestTableData = [];
let requestTableDataEdit = [];

const useStyles = makeStyles(theme => ({
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1)
  },
  dense: {
    marginTop: theme.spacing(2)
  },
  menu: {
    width: 200
  }
}));

function SystemParameterAdd (props) {
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const toPrintRef = useRef();
  let errorMessagesArray = [];
  const [formatError, setFormatError] = React.useState(false);
  const [showForm, setShowForm] = React.useState(false);
  const classes = useStyles();
  const [id, setId] = React.useState(1);
  const [open, setOpen] = React.useState(false);
  const [tableData, setTableData] = React.useState([]);
  const dispatch = useDispatch();
  const [tabValue, setTabValue] = React.useState(0);
  const [errorMeg, setErrorMeg] = React.useState('');
  const [errorMegDate, setErrorMegDate] = React.useState('');
  const [errorMegPercent, setErrorMegPercent] = React.useState('');
  const [errorMegNumeric, setErrorMegNumeric] = React.useState('');
  const [errorMegCurrency, setErrorMegCurrency] = React.useState('');
  const [errorMegAlpha, setErrorMegAlpha] = React.useState('');
  const [errorMegTime, setErrorMegTime] = React.useState('');
  const [previousDataformatValue, setPreviousDataFormatValue] = React.useState('');
  const [editData, setEditData] = React.useState({});
  const [spinnerLoader, setSpinnerLoader] = React.useState(false);
  const [newData, setnewData] = React.useState([]);
  const systemParamAddCons = SystemParameterAddConstants;
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [{
    showBlankRowError, showFunctionalAreaError, showDataFormatError, showParameterNoError, showLOBError, showDescriptionError, showNumericError,
    showPercentError, showAlphaNumericError, showTimestampError, showCurrencyError, showCurrencyInvalidError, showAlphaNumericInvalidError,
    showPercentInvalidError, showNumericInvalidError, showBeginDateError, showDateError, showDateInvalidError
  }
  , setShowError] = React.useState(false);

  const [prompt, setPrompt] = useState(false);
  const [cancelType, setCancelType] = useState(false);
  const [confirm, setConfirm] = useState(false);

  const [begindatePress, setBeginDatePress] = React.useState(false);
  const [formatdatePress, setFormatDatePress] = React.useState(false);
  const [selectedBeginDate, setSelectedBeginDate] = React.useState('');
  const [selectedFormatDate, setSelectedFormatDate] = React.useState('');
  const [redirect, setRedirect] = React.useState(0);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [dataFormatData, setDataFormatData] = React.useState([]);
  const [lobCodeData, setLobCodeData] = React.useState([]);
  const [add, setAdd] = React.useState(true);
  const [formatChange, setFormatChange] = React.useState(true);
  const [beginDateChange, setBeginDateChange] = React.useState(true);
  const [retainEdit, setRetainEdit] = React.useState();
  const [retainBeginDate, setRetainBeginDate] = React.useState();
  const [retainFormatDate, setRetainFormatDate] = React.useState();
  const [allowNavigation, setAllowNavigation] = React.useState(false);
  const [successResponse, setSuccessResponse] = React.useState();
  const [rowSystemParameterData, setRowSystemParameterData] = React.useState([]);
  // notes
  const [notesTableData, setNotesTableData] = React.useState([]);
  const [notesInput, setNotesInput] = React.useState({

    auditUserID: 'BTAYLOR1',
    auditTimeStamp: null,
    addedAuditUserID: 'BTAYLOR1',
    addedAuditTimeStamp: null,
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    tableName: null,
    noteSetSK: null,
    noteSourceName: null,
    notesList: notesTableData,
    globalNotesList: [],
    checkAll: null,
    addNewLinkRender: null,
    filterLinkRender: null,
    printLinkRender: null,
    completeNotesList: []

  });
  const [noteSetListInput, setNoteSetListInput] = React.useState({
    auditUserID: 'BTAYLOR1',
    auditTimeStamp: null,
    addedAuditUserID: 'BTAYLOR1',
    addedAuditTimeStamp: null,
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    noteTextValue: null,
    userIdName: null,
    notesCexAuditUserID: null,
    notesCexAuditTimeStamp: null,
    notesCexAddedAuditUserID: null,
    notesCexAddedAuditTimeStamp: null,
    noteSetSK: null,
    usageTypeDesc: '',
    shortNotes: null,
    checked: false,
    renderNoHistoryMsg: false,
    noteSequenceNumber: 4,
    currentNote: null,
    rowValue: null,
    usageTypeList: null,
    strBeginDate: moment(new Date()).format('MM/DD/YYYY hh:mm:ss'),
    usageTypeCode: 'Please Select One',
    tableName: null,
    noteText: '',
    commonEntityName: null,
    commonEntityTypeCode: null,
    commonEntityId: null,
    entityId: null,
    filterbeginDate: moment(new Date()).format('YYYY-MM-DD'),
    filterEndDate: null,
    userId: '',
    noteCexVersionNum: 0,
    saNoteSequenceNumber: null,
    notesCexnoteTextValue: 0,
    id: DateUtils.generateUUID()
  });
  const [usageTypeCodeInput, setUsageTypeCodeInput] = React.useState([{
    functionalArea: 'General',
    dataElementName: 'G_NOTE_TY_CD',
    businessName: null,
    valueShortDescription: null,
    crossReferenceColumnName: null,
    crossReferenceTableName: null,
    dataEleNameStartsOrContains: null,
    busNameStartsOrContains: null
  }]);
  const [usageTypeCodeData, setUsageTypeCodeData] = React.useState([]);
  const [editNoteData, setEditNoteData] = React.useState({});
  // add notes
  let notesDataArray = [];

  const addNotes = (data) => {
    setAllowNavigation(true);
    console.log(data);
    const noteText = data;
    notesDataArray = notesTableData;

    notesDataArray.push(noteText);
    setNotesTableData(notesDataArray);
    setNotesInput({ ...notesInput, notesList: notesDataArray });
  };
  const dropDownDispatch = dropdownvalues => dispatch(AppConfigDropdownActions(dropdownvalues));
  const usageTypeDropDown = usageTypeCodeInput => dispatch(notesUsageTypeDropdown(usageTypeCodeInput));

  const logInUserID = useSelector(state => state.sharedState.logInUserID);
  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
    usageTypeDropDown(usageTypeCodeInput);
  }, []);
  const dropdown = useSelector(state => state.appConfigState.AppConfigCommonState.appConfigDropdown);
  const usageTypeCodeDropDown = useSelector(state => state.appConfigState.AppConfigCommonState.usageDropDown);

  useEffect(() => {
    console.log(usageTypeCodeDropDown);
    if (usageTypeCodeDropDown) {
      if (usageTypeCodeDropDown.listObj) {
        const usage = usageTypeCodeDropDown.listObj['General#G_NOTE_TY_CD'];
        setUsageTypeCodeData(usage);
      }
    }
  }, [usageTypeCodeDropDown]);

  const [values, setValues] = React.useState({
    lobDetail: 'Please Select One',
    dataFormat: 'Please Select One',
    description: '',
    paramNumber: '',
    functionalArea: 'Please Select One'
  });

  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj['Reference#1017']) {
        setFunctionalAreaData(dropdown.listObj['Reference#1017']);
      }
      if (dropdown.listObj['Reference#1019']) {
        setLobCodeData(dropdown.listObj['Reference#1019']);
      }
      if (dropdown.listObj['Reference#1025']) {
        setDataFormatData(dropdown.listObj['Reference#1025']);
      }
    }
  }, [dropdown]);
  const addResponse = useSelector(state => state.appConfigState.systemParameterState.addSystemParameter);

  useEffect(() => {
    setAllowNavigation(false);
    setSpinnerLoader(false);
    if(addResponse){
      addResponse.data.isUpdate = true
      console.log(addResponse.data, 'Helllooooooo');
    }
    setSuccessResponse(addResponse ? addResponse.data : {});
  }, [addResponse]);
  const onAddSuccess = values => dispatch(systemParameterRowClickAction(values));

  if (addResponse && addResponse.data.respcode === '01') {
    const rowClickValues = {
      functionalArea: values.functionalArea,
      parameterNumber: +values.paramNumber
    };
    onAddSuccess(rowClickValues);
  }

  const payloadData = useSelector(state => state.appConfigState.systemParameterState.rowSearchSysParam);

  useEffect(() => {
    if (redirect === 1) {
      if (payloadData && successResponse) {
        let successResponses = successResponse
        successResponses.isSystemParameterAddSuccess=true 
        props.history.push({
          pathname: '/SystemParametersEdit',
          state: { payloadData, successResponse }
        });
      }
    }
    if (addResponse) {
      if (addResponse.data.respcode === '02') {
        errorMessagesArray.push(addResponse.data.respdesc);
        seterrorMessages(errorMessagesArray);
      } else if (addResponse.data.respcode === '03') {
        errorMessagesArray.push(addResponse.data.respdesc);
        seterrorMessages(errorMessagesArray);
      } else {
        let valuetoredirect = 0;
        valuetoredirect = valuetoredirect + 1;
        setRedirect(valuetoredirect);
      }
    }
  }, [addResponse]);

  const handleDateChange = date => {
    setSelectedBeginDate(date);
    setBeginDatePress(true);
    setBeginDateChange(true);
  };

  const handleFormatDateChange = formatDate => {
    setSelectedFormatDate(formatDate);
    setFormatDatePress(true);
  };

  const [dataElement, setDataElement] = React.useState({
    id: 0,
    beginDateShowInTable: '',
    beginDate: '',
    endDateShowInTable: '',
    endDate: '',
    format: '',
    auditUserID: logInUserID,
    auditTimeStamp: DateUtils.getUTCTimeStamp(),
    addedAuditUserID: logInUserID,
    addedAuditTimeStamp: DateUtils.getUTCTimeStamp(),
    versionNo: '',
    voidDate: '',
    tempValue: '',
    valueDate: '',
    valueTimeStamp: '',
    valueAmt: '',
    valuePCT: '',
    valueNum: '',
    valueData: '',
    lob: '',
    parameterDetails: ''
  });

  const [systemParameterAddHeadCells, setSystemParameterAddHeadCells] = React.useState([
    { id: 'beginDateShowInTable', disablePadding: false, label: 'Begin Date', width: '120', isDate: true },
    { id: 'endDateShowInTable', disablePadding: false, label: 'End Date', width: '120', isDate: true },
    { id: 'format', disablePadding: false, label: 'Format' }
  ]);

  const handleClickOpen = () => {
    errorMessagesArray = [];
    seterrorMessages([]);
    var showFunctionalAreaError; var showParameterNoError; var showDataFormatError; var showLOBError; var showDescriptionError = false;
    setSelectedBeginDate(null);

    if (values.dataFormat === 'D') {
      setSelectedFormatDate(null);
    }

    if ((!(values.lobDetail) || values.lobDetail === 'Please Select One')) {
      showLOBError = true;
      errorMessagesArray.push(systemParamAddCons.LOB_REQUIRED);
      seterrorMessages(errorMessagesArray);
    }

    if (!(values.functionalArea) || values.functionalArea === 'Please Select One') {
      showFunctionalAreaError = true;
      errorMessagesArray.push(systemParamAddCons.FUNCTIONAL_AREA_REQUIRED);
      seterrorMessages(errorMessagesArray);
    }

    if (!values.paramNumber) {
      showParameterNoError = true;
      errorMessagesArray.push(systemParamAddCons.PARAMETER_NUMBER_REQUIRED);
      seterrorMessages(errorMessagesArray);
    }

    if ((!(values.dataFormat) || values.dataFormat === 'Please Select One')) {
      showDataFormatError = true;
      errorMessagesArray.push(systemParamAddCons.DATA_FORMAT_REQUIRED);
      seterrorMessages(errorMessagesArray);
    }

    if (!values.description) {
      showDescriptionError = true;
      errorMessagesArray.push(systemParamAddCons.DESCRIPTION_REQUIRED);
      seterrorMessages(errorMessagesArray);
    }

    if (errorMessagesArray.length > 0) {
      setShowError({
        showFunctionalAreaError: showFunctionalAreaError,
        showParameterNoError: showParameterNoError,
        showDataFormatError: showDataFormatError,
        showLOBError: showLOBError,
        showDescriptionError: showDescriptionError
      });
    } else {
      showDataFormatError = false;
      setShowError(false);

      setOpen(true);
      setDataElement({
        beginDateShowInTable: '',
        endDateShowInTable: '',
        format: ''
      });
    }
  };

  const handleClose = () => {
    if (!add) {
      setAdd(true);
    }
    setOpen(false);
    setDataElement({
      beginDateShowInTable: '',
      endDateShowInTable: '',
      format: ''
    });
  };

  const checkFormatValidations = () => {
    var showBeginDateError; var showDateError; var showPercentError; var showNumericError; var showCurrencyError; var showAlphaNumericError; var showTimestampError;

    if (!selectedBeginDate) {
      showBeginDateError = true;
      setErrorMeg(SystemParameterAddConstants.BEGIN_DATE_REQUIRED);
      setShowError({ showBeginDateError: showBeginDateError });
    } else if (selectedBeginDate.toString() === 'Invalid Date') {
      showBeginDateError = true;
      setErrorMeg(SystemParameterAddConstants.BEGIN_DATE_INVALID);
      setShowError({ showBeginDateError: showBeginDateError });
    } else if (DateUtils.validateDateMinimumValue(selectedBeginDate)) {
      showBeginDateError = true;
      setErrorMeg(AppConstants.DATE_ERROR_1964);
      setShowError({ showBeginDateError: showBeginDateError });
    }
    if (values.dataFormat === 'D' && (!selectedFormatDate)) {
      showDateError = true;
      setErrorMegDate(SystemParameterAddConstants.DATE_REQUIRED);
      setShowError({ showDateError: showDateError });
    } else if (values.dataFormat === 'D' && selectedFormatDate.toString() === 'Invalid Date') {
      showDateError = true;
      setErrorMegDate(SystemParameterAddConstants.DATE_INVALID);
      setShowError({ showDateError: showDateError });
    } else if (values.dataFormat === 'D' && DateUtils.validateDateMinimumValue(selectedFormatDate)) {
      showDateError = true;
      setErrorMegDate(AppConstants.DATE_ERROR_1964);
      setShowError({ showDateError: showDateError });
    }
    if (((selectedBeginDate) && (selectedFormatDate)) && (values.dataFormat === 'D') && !showBeginDateError && !showDateError) {
      const beginDate = moment(new Date(selectedBeginDate)).format('MM/DD/YYYY');
      const formatDate = new Date(selectedFormatDate).getTime();
      return true;
    }
    if (values.dataFormat === 'P') {
      if (!dataElement.format) {
        showPercentError = true;
        setShowError({ showPercentError: showPercentError });
        setErrorMegPercent(SystemParameterAddConstants.PERCENT_REQUIRED);
      } else {
        const regex = /^[0-9]{1}(\.[0-9]{0,4})?$/;
        if (!regex.test(dataElement.format)) {
          showPercentError = true;
          setShowError({ showPercentError: showPercentError });
          setErrorMegPercent(SystemParameterAddConstants.PERCENT_INVALID);
        }
      }
    }
    if (values.dataFormat === 'N') {
      if (!dataElement.format) {
        showNumericError = true;
        setShowError({ showNumericError: showNumericError });
        setErrorMegNumeric(SystemParameterAddConstants.NUMERIC_REQUIRED);
      } else {
        const regex = /^[0-9]+$/;
        if (!regex.test(dataElement.format)) {
          showNumericError = true;
          setShowError({ showNumericError: showNumericError });
          setErrorMegNumeric(SystemParameterAddConstants.NUMERIC_INVALID);
        }
      }
    }
    if (values.dataFormat === 'C') {
      if (!dataElement.format) {
        showCurrencyError = true;
        setShowError({ showCurrencyError: showCurrencyError });
        setErrorMegCurrency(SystemParameterAddConstants.CURRENCY_REQUIRED);
      } else {
        const regex = /^[1-9]\d*(\.\d{1,4})?$/;
        if (!regex.test(dataElement.format)) {
          showCurrencyError = true;
          setShowError({ showCurrencyError: showCurrencyError });
          setErrorMegCurrency(SystemParameterAddConstants.CURRENCY_INVALID);
        }
      }
    }
    if (values.dataFormat === 'T') {
      if (!dataElement.format) {
        showAlphaNumericError = true;
        setShowError({ showAlphaNumericError: showAlphaNumericError });
        setErrorMegAlpha(SystemParameterAddConstants.ALPHA_NUMERIC_REQUIRED);
      } else {
        const regex = /^[a-zA-Z0-9]+$/;
        if (!regex.test(dataElement.format)) {
          showAlphaNumericError = true;
          setShowError({ showAlphaNumericError: showAlphaNumericError });
          setErrorMegAlpha(SystemParameterAddConstants.ALPHA_NUMERIC_INVALID);
        }
      }
    }
    if (values.dataFormat === 'Z') {
      if (!dataElement.format) {
        showTimestampError = true;
        setShowError({ showTimestampError: showTimestampError });
        setErrorMegTime(SystemParameterAddConstants.TIMESTAMP_REQUIRED);
      } else {
        const regex = SystemParameterAddConstants.TIMESTAMP_REGEX;
        if (!regex.test(dataElement.format)) {
          showTimestampError = true;
          setShowError({ showTimestampError: showTimestampError });
          setErrorMegTime(SystemParameterAddConstants.TIMESTAMP_INVALID);
        }
      }
    }
    setShowError({
      showAlphaNumericError: showAlphaNumericError,
      showDateError: showDateError,
      showCurrencyError: showCurrencyError,
      showBeginDateError: showBeginDateError,
      showNumericError: showNumericError,
      showPercentError: showPercentError,
      showTimestampError: showTimestampError
    });
    if (!showTimestampError && !showDateError && !showAlphaNumericError && !showCurrencyError && !showBeginDateError && !showNumericError && !showPercentError) {
      return true;
    } else {
      return false;
    }
  };

  const checkForBeginDateValidValue = (dateString) => {
    // First checking for the pattern
    if (!/^\d{1,2}\/\d{1,2}\/\d{4}$/.test(dateString)) { return false; }

    // Parsing the date parts to integers
    var parts = dateString.split('/');
    var day = parseInt(parts[1], 10);
    var month = parseInt(parts[0], 10);
    var year = parseInt(parts[2], 10);

    // Checking the ranges of month and year
    if (year < 1000 || year > 3000 || month === 0 || month > 12) { return false; }

    var monthLength = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

    // Adjust for leap years
    if (year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0)) { monthLength[1] = 29; }

    // Checking the range of the day
    return day > 0 && day <= monthLength[month - 1];
  };

  const showDataFormatTable = (formatValue) => {
    let addHeadCellsData = [];
    formatValue = (formatValue).toString();
    if (formatValue === 'C') {
      addHeadCellsData = [];
      addHeadCellsData = systemParameterAddHeadCells;
      addHeadCellsData.pop();
      addHeadCellsData.push({ id: 'format', numeric: false, disablePadding: false, label: 'Currency', isSPBalance: true });
      setSystemParameterAddHeadCells(addHeadCellsData);
    } else if (formatValue === 'P') {
      addHeadCellsData = systemParameterAddHeadCells;
      addHeadCellsData.pop();
      addHeadCellsData.push({ id: 'format', numeric: false, disablePadding: false, label: 'Percent', isPercent: true });
      setSystemParameterAddHeadCells(addHeadCellsData);
    } else if (formatValue === 'D') {
      addHeadCellsData = systemParameterAddHeadCells;
      addHeadCellsData.pop();
      addHeadCellsData.push({ id: 'format', numeric: false, disablePadding: false, label: 'Date', isDate: true });
      setSystemParameterAddHeadCells(addHeadCellsData);
    } else if (formatValue === 'N') {
      addHeadCellsData = systemParameterAddHeadCells;
      addHeadCellsData.pop();
      addHeadCellsData.push({ id: 'format', numeric: false, disablePadding: false, label: 'Number' });
      setSystemParameterAddHeadCells(addHeadCellsData);
    } else if (formatValue === 'T') {
      addHeadCellsData = systemParameterAddHeadCells;
      addHeadCellsData.pop();
      addHeadCellsData.push({ id: 'format', numeric: false, disablePadding: false, label: 'Text' });
      setSystemParameterAddHeadCells(addHeadCellsData);
    } else if (formatValue === 'Z') {
      addHeadCellsData = systemParameterAddHeadCells;
      addHeadCellsData.pop();
      addHeadCellsData.push({ id: 'format', numeric: false, disablePadding: false, label: 'Timestamp' });
      setSystemParameterAddHeadCells(addHeadCellsData);
    }

    if (formatValue === 'Please Select One') {
      setShowForm(false);
    } else {
      setShowForm(true);
      setShowError(false);
      errorMessagesArray = [];
      seterrorMessages([]);
      if (previousDataformatValue === formatValue) {

      } else {
        setnewData([]);
        setDataElement({ ...dataElement, beginDateShowInTable: null, beginDate: null, endDate: null, format: null });
      }
    }
  };

  const addParameter = () => {
    var showBeginDateError; var showDateError; var showTimestampError; var showPercentError;
    var showNumericError; var showCurrencyError; var showAlphaNumericError = false;

    if (add) {
      if (!selectedBeginDate) {
        showBeginDateError = true;
        setErrorMeg(SystemParameterAddConstants.BEGIN_DATE_REQUIRED);
      }

      if (values.dataFormat === 'D' && (!selectedFormatDate)) {
        showDateError = true;
        setErrorMegDate(SystemParameterAddConstants.DATE_REQUIRED);
      } else {
        if (checkForBeginDateValidValue(selectedFormatDate)) {
          showDateError = false;
        } else {
          showDateError = true;
          setErrorMegDate(SystemParameterAddConstants.DATE_INVALID);
        }
      }

      if (values.dataFormat === 'P') {
        if (!dataElement.format) {
          showPercentError = true;
          setErrorMegPercent(SystemParameterAddConstants.PERCENT_REQUIRED);
        } else {
          var regex = /^[0-9]{1}\.[0-9]{1,4}$/;
          if (regex.test(dataElement.format)) {
            showPercentError = false;
          } else {
            showPercentError = true;
            setShowError({ showPercentError: showPercentError });
            setErrorMegPercent(SystemParameterAddConstants.PERCENT_INVALID);
          }
        }
      }

      if (values.dataFormat === 'N') {
        if (!dataElement.format) {
          showNumericError = true;
          setErrorMegNumeric(SystemParameterAddConstants.NUMERIC_REQUIRED);
        } else {
          const regex = /^[0-9]+$/;
          if (regex.test(dataElement.format)) {
            showNumericError = false;
          } else {
            showNumericError = true;
            setShowError({ showNumericError: showNumericError });
            setErrorMegNumeric(SystemParameterAddConstants.NUMERIC_INVALID);
          }
        }
      }

      if (values.dataFormat === 'C') {
        if (!dataElement.format) {
          showCurrencyError = true;
          setErrorMegCurrency(SystemParameterAddConstants.CURRENCY_REQUIRED);
        } else {
          const regex = /^[0-9]{1,9}(\.\d{1,4})?%?$/;
          if (regex.test(dataElement.format)) {
            showCurrencyError = false;
          } else {
            showCurrencyError = true;
            setShowError({ showCurrencyError: showCurrencyError });
            setErrorMegCurrency(SystemParameterAddConstants.CURRENCY_INVALID);
          }
        }
      }

      if (values.dataFormat === 'T') {
        if (!dataElement.format) {
          showAlphaNumericError = true;
          setErrorMegAlpha(SystemParameterAddConstants.ALPHA_NUMERIC_REQUIRED);
        } else {
          const regex = /^[a-zA-Z0-9]+$/;
          if (regex.test(dataElement.format)) {
            showAlphaNumericError = false;
          } else {
            showAlphaNumericError = true;
            setShowError({ showAlphaNumericError: showAlphaNumericError });
            setErrorMegAlpha(SystemParameterAddConstants.ALPHA_NUMERIC_INVALID);
          }
        }
      }

      if (values.dataFormat === 'Z') {
        if (!dataElement.format) {
          showTimestampError = true;
          setErrorMegTime(SystemParameterAddConstants.TIMESTAMP_REQUIRED);
        } else {
          const regex = SystemParameterAddConstants.TIMESTAMP_REGEX;
          if (regex.test(dataElement.format)) {
            showTimestampError = false;
          } else {
            showTimestampError = true;
            setShowError({ showTimestampError: showTimestampError });
            setErrorMegTime(SystemParameterAddConstants.TIMESTAMP_INVALID);
          }
        }
      }

      setShowError({
        showBeginDateError: showBeginDateError,
        showDateError: showDateError,
        showPercentError: showPercentError,
        showAlphaNumericError: showAlphaNumericError,
        showTimestampError: showTimestampError,
        showCurrencyError: showCurrencyError,
        showNumericError: showNumericError
      });

      if (checkFormatValidations()) {
        setShowForm(true);
        setOpen(false);
        setId(id + 1);
        dataElement.id = id;

        if (begindatePress) {
          dataElement.beginDateShowInTable = selectedBeginDate;
          dataElement.beginDate = moment(new Date(selectedBeginDate)).format('MM/DD/YYYY');
        } else {
          dataElement.beginDateShowInTable = setSelectedDate(selectedBeginDate);
          dataElement.beginDate = moment(new Date(setSelectedDate(selectedBeginDate))).format('MM/DD/YYYY');
        }

        if (values.dataFormat === 'D') {
          if (formatdatePress) {
            dataElement.format = selectedFormatDate;
          } else {
            dataElement.format = setSelectedDate(selectedFormatDate);
          }
        }

        let count = 0;
        if (newData.length > 0) {
          newData.map((value, index) => {
            if (value.beginDateShowInTable === dataElement.beginDateShowInTable) {
              count = count + 1;
            }
          });
        }

        var showDateOverlappingError = false;
        var showBeginDateInvalidError = false;
        if (count > 0) {
          errorMessagesArray = [];
          seterrorMessages([]);
          showBeginDateInvalidError = false;
          showDateOverlappingError = true;
          errorMessagesArray.push(systemParamAddCons.BEGIN_DATE_OVERLAPPING);
          seterrorMessages(errorMessagesArray);
          setShowError({ showDateOverlappingError: showDateOverlappingError });
        }

        if (newData.length > 0 && count === 0) {
          if (!showDateOverlappingError) {
            adjustEndDates(dataElement);
          }
        } else if (!showDateOverlappingError) {
          errorMessagesArray = [];
          seterrorMessages([]);
          setShowError(false);
          dataElement.endDateShowInTable = moment('9999-12-31T18:30:00.000+0000').utc().format('MM/DD/YYYY');
          dataElement.endDate = new Date('9999-12-31T18:30:00.000+0000').getTime();
          newData.push(dataElement);
        }

        requestTableData = [];

        if (newData.length === 0 || count === 0) {
          newData.map((value, index) => {
            let dataElementToSend = {};
            if (values.dataFormat === 'D') {
              dataElementToSend.valueDate = moment(new Date(value.format)).format('MM/DD/YYYY');
            } else {
              dataElementToSend.valueDate = null;
            }

            if (values.dataFormat === 'T') {
              dataElementToSend.valueData = value.format;
            } else {
              dataElementToSend.valueData = null;
            }

            if (values.dataFormat === 'C') {
              dataElementToSend.valueAmt = value.format;
            } else {
              dataElementToSend.valueAmt = null;
            }

            if (values.dataFormat === 'N') {
              dataElementToSend.valueNum = value.format;
            } else {
              dataElementToSend.valueNum = null;
            }

            if (values.dataFormat === 'P') {
              dataElementToSend.valuePCT = value.format;
            } else {
              dataElementToSend.valuePCT = null;
            }

            if (values.dataFormat === 'Z') {
              dataElementToSend.valueTimeStamp = value.format;
            } else {
              dataElementToSend.valueTimeStamp = null;
            }

            dataElementToSend.auditUserID = logInUserID;
            dataElementToSend.auditTimeStamp = DateUtils.getUTCTimeStamp();
            dataElementToSend.addedAuditUserID = logInUserID;
            dataElementToSend.addedAuditTimeStamp = DateUtils.getUTCTimeStamp();
            dataElementToSend.versionNo = '0';
            dataElementToSend.beginDate = moment(new Date(value.beginDateShowInTable)).format('MM/DD/YYYY');
            dataElementToSend.endDate = moment(new Date(value.endDateShowInTable)).format('MM/DD/YYYY');
            dataElementToSend.voidDate = null;
            dataElementToSend.tempValue = null;
            dataElementToSend.lob = values.lobDetail;
            dataElementToSend.parameterDetails = null;
            const detailIdObject = {};
            detailIdObject.functionalArea = values.functionalArea;
            detailIdObject.parameterNumber = values.paramNumber;
            detailIdObject.parameterDetailSK = null;
            dataElementToSend.systemParameterDetailID = detailIdObject;
            let finalDataElementToSend = {};
            finalDataElementToSend = dataElementToSend;
            requestTableData.push(finalDataElementToSend);
            finalDataElementToSend = {};
            dataElementToSend = {};
          });
        }

        setShowError(false);
      }
    } else {
      if (!selectedBeginDate) {
        showBeginDateError = true;
        setErrorMeg(SystemParameterAddConstants.BEGIN_DATE_REQUIRED);
      }

      if (values.dataFormat === 'D' && (!selectedFormatDate)) {
        showDateError = true;
        setErrorMegDate(SystemParameterAddConstants.DATE_REQUIRED);
      } else {
        if (checkForBeginDateValidValue(selectedFormatDate)) {
          showDateError = false;
        } else {
          showDateError = true;
          setErrorMegDate(SystemParameterAddConstants.DATE_INVALID);
        }
      }

      if (values.dataFormat === 'P') {
        if (!dataElement.format) {
          showPercentError = true;
          setErrorMegPercent(SystemParameterAddConstants.PERCENT_REQUIRED);
        } else {
          const regex = /^[0-9]{1}(\.[0-9]{0,4})?$/;
          if (regex.test(dataElement.format)) {
            showPercentError = false;
          } else {
            showPercentError = true;
            setShowError({ showPercentError: showPercentError });
            setErrorMegPercent(SystemParameterAddConstants.PERCENT_INVALID);
          }
        }
      }

      if (values.dataFormat === 'N') {
        if (!dataElement.format) {
          showNumericError = true;
          setErrorMegNumeric(SystemParameterAddConstants.NUMERIC_REQUIRED);
        } else {
          const regex = /^[0-9]+$/;
          if (regex.test(dataElement.format)) {
            showNumericError = false;
          } else {
            showNumericError = true;
            setShowError({ showNumericError: showNumericError });
            setErrorMegNumeric(SystemParameterAddConstants.NUMERIC_INVALID);
          }
        }
      }

      if (values.dataFormat === 'C') {
        if (!dataElement.format) {
          showCurrencyError = true;
          setErrorMegCurrency(SystemParameterAddConstants.CURRENCY_REQUIRED);
        } else {
          const regex = /^[0-9]{1,9}(\.\d{1,4})?%?$/;
          if (regex.test(dataElement.format)) {
            showCurrencyError = false;
          } else {
            showCurrencyError = true;
            setShowError({ showCurrencyError: showCurrencyError });
            setErrorMegCurrency(SystemParameterAddConstants.CURRENCY_INVALID);
          }
        }
      }

      if (values.dataFormat === 'T') {
        if (!dataElement.format) {
          showAlphaNumericError = true;
          setErrorMegAlpha(SystemParameterAddConstants.ALPHA_NUMERIC_REQUIRED);
        } else {
          const regex = /^[a-zA-Z0-9]+$/;
          if (regex.test(dataElement.format)) {
            showAlphaNumericError = false;
          } else {
            showAlphaNumericError = true;
            setShowError({ showAlphaNumericError: showAlphaNumericError });
            setErrorMegAlpha(SystemParameterAddConstants.ALPHA_NUMERIC_INVALID);
          }
        }
      }

      if (values.dataFormat === 'Z') {
        if (!dataElement.format) {
          showTimestampError = true;
          setErrorMegTime(SystemParameterAddConstants.TIMESTAMP_REQUIRED);
        } else {
          const regex = SystemParameterAddConstants.TIMESTAMP_REGEX;
          if (regex.test(dataElement.format)) {
            showTimestampError = false;
          } else {
            showTimestampError = true;
            setShowError({ showTimestampError: showTimestampError });
            setErrorMegTime(SystemParameterAddConstants.TIMESTAMP_INVALID);
          }
        }
      }

      setShowError({
        showBeginDateError: showBeginDateError,
        showDateError: showDateError,
        showPercentError: showPercentError,
        showAlphaNumericError: showAlphaNumericError,
        showTimestampError: showTimestampError,
        showCurrencyError: showCurrencyError,
        showNumericError: showNumericError
      });

      if (checkFormatValidations()) {
        setAdd(true);
        setOpen(false);
        if (begindatePress) {
          dataElement.beginDateShowInTable = selectedBeginDate;
        } else {
          if (((selectedBeginDate.getMonth() + 1) < 10 && (selectedBeginDate.getMonth() + 1) > 0) && ((selectedBeginDate.getDate()) < 10 && (selectedBeginDate.getDate()) > 0)) {
            dataElement.beginDateShowInTable = '0' + (selectedBeginDate.getMonth() + 1) + '/0' + selectedBeginDate.getDate() + '/' + selectedBeginDate.getFullYear();
          } else if ((selectedBeginDate.getMonth() + 1) < 10 && (selectedBeginDate.getMonth() + 1) > 0) {
            dataElement.beginDateShowInTable = '0' + (selectedBeginDate.getMonth() + 1) + '/' + selectedBeginDate.getDate() + '/' + selectedBeginDate.getFullYear();
          } else if ((selectedBeginDate.getDate()) < 10 && (selectedBeginDate.getDate()) > 0) {
            dataElement.beginDateShowInTable = (selectedBeginDate.getMonth() + 1) + '/0' + selectedBeginDate.getDate() + '/' + selectedBeginDate.getFullYear();
          } else {
            dataElement.beginDateShowInTable = (selectedBeginDate.getMonth() + 1) + '/' + selectedBeginDate.getDate() + '/' + selectedBeginDate.getFullYear();
          }
        }

        if (values.dataFormat === 'D') {
          if (formatdatePress) {
            dataElement.format = selectedFormatDate;
          } else {
            if (((selectedFormatDate.getMonth() + 1) < 10 && (selectedFormatDate.getMonth() + 1) > 0) && ((selectedFormatDate.getDate()) < 10 && (selectedFormatDate.getDate()) > 0)) {
              dataElement.format = '0' + (selectedFormatDate.getMonth() + 1) + '/0' + selectedFormatDate.getDate() + '/' + selectedFormatDate.getFullYear();
            } else if ((selectedFormatDate.getMonth() + 1) < 10 && (selectedFormatDate.getMonth() + 1) > 0) {
              dataElement.format = '0' + (selectedFormatDate.getMonth() + 1) + '/' + selectedFormatDate.getDate() + '/' + selectedFormatDate.getFullYear();
            } else if ((selectedFormatDate.getDate()) < 10 && (selectedFormatDate.getDate()) > 0) {
              dataElement.format = (selectedFormatDate.getMonth() + 1) + '/0' + selectedFormatDate.getDate() + '/' + selectedFormatDate.getFullYear();
            } else {
              dataElement.format = (selectedFormatDate.getMonth() + 1) + '/' + selectedFormatDate.getDate() + '/' + selectedFormatDate.getFullYear();
            }
          }
        }

        let count = 0;
        newData.map((value, index) => {
          if (newData.indexOf(value) !== newData.indexOf(editData)) {
            if (value.beginDateShowInTable === dataElement.beginDateShowInTable) {
              count = count + 1;
            }

            var showDateOverlappingError = false;
            if (count > 0) {
              errorMessagesArray = [];
              seterrorMessages([]);
              showDateOverlappingError = true;
              errorMessagesArray.push(systemParamAddCons.BEGIN_DATE_OVERLAPPING);
              seterrorMessages(errorMessagesArray);
              setShowError({ showDateOverlappingError: showDateOverlappingError });
            }
          } else {
            const selectedDate = new Date(selectedBeginDate);
            const formatDateSelected = new Date(selectedFormatDate);
            if (selectedDate instanceof Date && !isNaN(selectedDate.valueOf())) {
              if (beginDateChange) {
                if (newData[newData.indexOf(editData)].endDate !== new Date('9999-12-31T18:30:00.000+0000').getTime()) {
                  newData[newData.indexOf(editData)].beginDateShowInTable = moment(new Date(selectedBeginDate));
                }
                adjustEndDates(newData[newData.indexOf(editData)]);
              }

              if (values.dataFormat === 'C') {
                newData[newData.indexOf(editData)].format = dataElement.format;
              }

              if (values.dataFormat === 'N') {
                newData[newData.indexOf(editData)].format = dataElement.format;
              }

              if (values.dataFormat === 'P') {
                newData[newData.indexOf(editData)].format = dataElement.format;
              }

              if (values.dataFormat === 'T') {
                newData[newData.indexOf(editData)].format = dataElement.format;
              }

              if (values.dataFormat === 'Z') {
                newData[newData.indexOf(editData)].format = dataElement.format;
              }

              if (values.dataFormat === 'D') {
                if (formatDateSelected instanceof Date && !isNaN(formatDateSelected.valueOf())) {
                  newData[newData.indexOf(editData)].format = moment(new Date(selectedFormatDate));
                } else {
                  errorMessagesArray.push(systemParamAddCons.DATE_INVALID);
                  seterrorMessages(errorMessagesArray);
                }
              }
            } else {
              errorMessagesArray.push(systemParamAddCons.BEGIN_DATE_INVALID);
              seterrorMessages(errorMessagesArray);
            }
          }
        });
        requestTableDataEdit = [];

        if (newData.length === 0 || count === 0) {
          newData.map((value, index) => {
            let dataElementToSendEdit = {};
            if (values.dataFormat === 'D') {
              dataElementToSendEdit.valueDate = moment(new Date(value.format)).format('MM/DD/YYYY');
            } else {
              dataElementToSendEdit.valueDate = null;
            }

            if (values.dataFormat === 'T') {
              dataElementToSendEdit.valueData = value.format;
            } else {
              dataElementToSendEdit.valueData = null;
            }

            if (values.dataFormat === 'C') {
              dataElementToSendEdit.valueAmt = value.format;
            } else {
              dataElementToSendEdit.valueAmt = null;
            }

            if (values.dataFormat === 'N') {
              dataElementToSendEdit.valueNum = value.format;
            } else {
              dataElementToSendEdit.valueNum = null;
            }

            if (values.dataFormat === 'P') {
              dataElementToSendEdit.valuePCT = value.format;
            } else {
              dataElementToSendEdit.valuePCT = null;
            }

            if (values.dataFormat === 'Z') {
              dataElementToSendEdit.valueTimeStamp = value.format;
            } else {
              dataElementToSendEdit.valueTimeStamp = null;
            }

            dataElementToSendEdit.auditUserID = logInUserID;
            dataElementToSendEdit.auditTimeStamp = DateUtils.getUTCTimeStamp();
            dataElementToSendEdit.addedAuditUserID = logInUserID;
            dataElementToSendEdit.addedAuditTimeStamp = DateUtils.getUTCTimeStamp();
            dataElementToSendEdit.versionNo = '0';
            dataElementToSendEdit.beginDate = moment(new Date(value.beginDateShowInTable)).format('MM/DD/YYYY');
            dataElementToSendEdit.endDate = moment(new Date(value.endDateShowInTable)).format('MM/DD/YYYY');
            dataElementToSendEdit.voidDate = null;
            dataElementToSendEdit.tempValue = null;
            dataElementToSendEdit.lob = values.lobDetail;
            dataElementToSendEdit.parameterDetails = null;
            const detailIdObject = {};
            detailIdObject.functionalArea = values.functionalArea;
            detailIdObject.parameterNumber = values.paramNumber;
            detailIdObject.parameterDetailSK = null;
            dataElementToSendEdit.systemParameterDetailID = detailIdObject;
            console.log('dataElementToSendEdit is.........' + JSON.stringify(dataElementToSendEdit));
            let finalDataElementToSendEdit = {};
            finalDataElementToSendEdit = dataElementToSendEdit;
            requestTableDataEdit.push(finalDataElementToSendEdit);
            dataElementToSendEdit = {};
            finalDataElementToSendEdit = {};
          });
        }
        console.log('requestTableDataEdit array is....' + JSON.stringify(requestTableDataEdit));
        setShowError(false);
      }
    }
    setnewData(newData);
  };

  const beginDateSelected = new Date(selectedBeginDate).getTime();
  const adjustEndDates = (value) => {
    const activeEndDate = new Date('9999-12-31T18:30:00.000+0000').getTime();
    var activeBeginDate;
    let activeIndex;
    let activeRecord;
    let isInBetween = false;

    let aDayBefore = new Date(beginDateSelected);

    const beforeDate = aDayBefore.setDate(aDayBefore.getDate() - 1);
    let beforDateLeast = beforeDate;

    newData.map((option, index) => {
      if (new Date(option.endDate).getTime() === activeEndDate) {
        activeIndex = index;
        const beginDate = new Date(option.beginDate).getTime();
        activeBeginDate = beginDate;
        activeRecord = option;
        return true;
      }
    });

    if (beginDateSelected > activeBeginDate) {
      value.endDate = activeRecord.endDate;
      value.endDateShowInTable = moment(new Date(activeRecord.endDate)).utc().format('MM/DD/YYYY');
      newData[activeIndex].endDate = beforeDate;
      newData[activeIndex].endDateShowInTable = new Date(beforeDate);

      if (add) {
        newData.push(value);
      } else {
        if (beginDateChange) {
          newData.map((option, index) => {
            if (new Date(option.endDate).getTime() === new Date(activeBeginDate).setDate(new Date(activeBeginDate).getDate() - 1)) {
              newData[newData.indexOf(editData) - 1].endDate = new Date(beginDateSelected).setDate(new Date(beginDateSelected).getDate() - 1);
              newData[newData.indexOf(editData) - 1].endDateShowInTable = new Date(beginDateSelected).setDate(new Date(beginDateSelected).getDate() - 1);
            }
          });
          newData[newData.indexOf(editData)].beginDate = selectedBeginDate;
          newData[newData.indexOf(editData)].endDate = new Date('9999-12-31T18:30:00.000+0000').getTime();
          newData[newData.indexOf(editData)].beginDateShowInTable = moment(new Date(selectedBeginDate));
          newData[newData.indexOf(editData)].endDateShowInTable = moment(new Date('9999-12-31T18:30:00.000+0000')).utc().format('MM/DD/YYYY');
        }
      }
      return true;
    } else {
      aDayBefore = new Date(activeRecord.beginDate);
      const beforeDateLeastCheck = aDayBefore.setDate(aDayBefore.getDate() - 1);
      beforDateLeast = beforeDateLeastCheck;

      newData.map((option, index) => {
        if (beginDateSelected > new Date(option.beginDate).getTime() && beginDateSelected < new Date(option.endDate)) {
          activeRecord = option;
          activeIndex = index;
          isInBetween = true;
          return true;
        } else if (new Date(option.beginDate).getTime() <= beforeDateLeastCheck && new Date(option.beginDate).getTime() > beginDateSelected) {
          if (new Date(option.beginDate).getTime() <= beforDateLeast) {
            const beforeBeginDate = new Date(option.beginDate);
            beforDateLeast = beforeBeginDate.setDate(beforeBeginDate.getDate() - 1);
            return true;
          }
        }
      });

      if (isInBetween) {
        value.beginDate = beginDateSelected;
        value.endDate = activeRecord.endDate;
        value.endDateShowInTable = new Date(activeRecord.endDate);
        activeRecord.endDate = beforeDate;
        activeRecord.endDateShowInTable = new Date(beforeDate);

        if (add) {
          newData.push(value);
        } else {
          if (beginDateChange) {
            newData[newData.indexOf(editData)].beginDate = beginDateSelected;
            newData[newData.indexOf(editData)].endDate = beforDateLeast;
            newData[newData.indexOf(editData)].beginDateShowInTable = new Date(beginDateSelected);
            newData[newData.indexOf(editData)].endDateShowInTable = new Date(beforDateLeast);
          }
        }
      } else {
        value.beginDate = beginDateSelected;
        value.endDate = beforDateLeast;
        value.endDateShowInTable = new Date(beforDateLeast);
        if (add) {
          newData.push(value);
        } else {
          if (beginDateChange) {
            newData[newData.indexOf(editData)].beginDate = beginDateSelected;
            newData[newData.indexOf(editData)].endDate = beforDateLeast;
            newData[newData.indexOf(editData)].beginDateShowInTable = new Date(beginDateSelected);
            newData[newData.indexOf(editData)].endDateShowInTable = new Date(beforDateLeast);
          }
        }
      }
      return true;
    }
    setnewData(newData);
  };

  const checkFieldValidations = (values) => {
    var showBlankRowError = false;
    var showFunctionalAreaError; var showParameterNoError; var showDataFormatError; var showLOBError; var showDescriptionError = false;
    if (values.functionalArea !== AppConstants.PLEASE_SELECT_ONE && values.paramNumber && values.dataFormat !== AppConstants.PLEASE_SELECT_ONE && values.lobDetail !== AppConstants.PLEASE_SELECT_ONE && values.description) {
      if (newData.length === 0) {
        errorMessagesArray = [];
        seterrorMessages([]);
        showBlankRowError = true;
        errorMessagesArray.push(systemParamAddCons.DETAIL_ROW_REQUIRED);
        seterrorMessages(errorMessagesArray);
        setShowError({ showBlankRowError: showBlankRowError });
      } else {
        setShowError(false);
        seterrorMessages([]);
        setSpinnerLoader(true);

        if (requestTableDataEdit.length > 0) {
          requestTableDataEdit.map((value, index) => {
            value.lob = values.lobDetail;
          });

          const requestDataEdit = {
            auditUserID: logInUserID,
            auditTimeStamp: DateUtils.getUTCTimeStamp(),
            addedAuditUserID: logInUserID,
            addedAuditTimeStamp: DateUtils.getUTCTimeStamp(),
            versionNo: 0,
            parameterTypeCode: values.dataFormat,
            functionalArea: values.functionalArea,
            parameterNumber: values.paramNumber,
            parameterName: values.description,
            systemParamID: {
              functionalArea: values.functionalArea,
              parameterNumber: values.paramNumber
            },
            systemParameterDetail: requestTableDataEdit,
            deletedSysParameterDetails: null,
            noteSetVO: notesInput
          };
          console.log('request data is :....' + JSON.stringify(requestDataEdit));
          dispatch(addSystemParameter(requestDataEdit));
          console.log('Response   ' + Response);
        } else {
          requestTableData.map((value, index) => {
            value.lob = values.lobDetail;
          });

          const requestData = {
            auditUserID: logInUserID,
            auditTimeStamp: DateUtils.getUTCTimeStamp(),
            addedAuditUserID: logInUserID,
            addedAuditTimeStamp: DateUtils.getUTCTimeStamp(),
            versionNo: 0,
            parameterTypeCode: values.dataFormat,
            functionalArea: values.functionalArea,
            parameterNumber: values.paramNumber,
            parameterName: values.description,
            systemParamID: {
              functionalArea: values.functionalArea,
              parameterNumber: values.paramNumber
            },
            systemParameterDetail: requestTableData,
            deletedSysParameterDetails: null,
            noteSetVO: notesInput
          };
          setAllowNavigation(false);
          dispatch(addSystemParameter(requestData));
        }
      }
    } else {
      errorMessagesArray = [];
      seterrorMessages([]);
      if ((!(values.lobDetail) || values.lobDetail === 'Please Select One')) {
        showLOBError = true;
        errorMessagesArray.push(systemParamAddCons.LOB_REQUIRED);
        seterrorMessages(errorMessagesArray);
      }

      if (!(values.functionalArea) || values.functionalArea === 'Please Select One') {
        showFunctionalAreaError = true;
        errorMessagesArray.push(systemParamAddCons.FUNCTIONAL_AREA_REQUIRED);
        seterrorMessages(errorMessagesArray);
      }

      if (!values.paramNumber) {
        showParameterNoError = true;
        errorMessagesArray.push(systemParamAddCons.PARAMETER_NUMBER_REQUIRED);
        seterrorMessages(errorMessagesArray);
      }

      if ((!(values.dataFormat) || values.dataFormat === 'Please Select One')) {
        showDataFormatError = true;
        errorMessagesArray.push(systemParamAddCons.DATA_FORMAT_REQUIRED);
        seterrorMessages(errorMessagesArray);
      }

      if (!values.description) {
        showDescriptionError = true;
        errorMessagesArray.push(systemParamAddCons.DESCRIPTION_REQUIRED);
        seterrorMessages(errorMessagesArray);
      }

      setShowError({
        showFunctionalAreaError: showFunctionalAreaError,
        showParameterNoError: showParameterNoError,
        showDataFormatError: showDataFormatError,
        showLOBError: showLOBError,
        showDescriptionError: showDescriptionError
      });
    }
    setnewData(newData);
  };

  const onClickEditSystemParameter = (data, label) => event => {
    setAdd(false);
    setBeginDateChange(false);
    setFormatChange(false);
    setDataElement({
      format: data.format
    });

    setSelectedBeginDate(new Date(data.beginDateShowInTable));
    setRetainBeginDate(new Date(data.beginDateShowInTable));

    if (label.toString() === 'Date') {
      setSelectedFormatDate(new Date(data.format));
      setRetainFormatDate(new Date(data.format));
    }
    setOpen(true);
    setEditData(data);
    setRetainEdit(data);
  };

  const resetTable = () => {
    if (add) {
      setDataElement({
        beginDate: null,
        format: '',
        beginDateShowInTable: ''

      });

      setSelectedBeginDate(null);
      if (values.dataFormat === 'D') {
        setSelectedFormatDate(null);
      }
    } else {
      setDataElement(retainEdit);
      setSelectedFormatDate(retainFormatDate);
      setSelectedBeginDate(retainBeginDate);
    }
    setShowError(false);
  };

  const handleChangeDataElement = (name,a) => event => {



  setDataElement({ ...dataElement, [name]: event.target.value });
  setFormatChange(true);
 
  if (name === 'format') {
    setFormatError(false);
  }


  };

  const handleChange = name => event => {
    setAllowNavigation(true);
    setValues({ ...values, [name]: event.target.value });
  };

  const handleDataFormatChange = name => event => {
    console.log(name,"d",event.target.value)
    setAllowNavigation(true);
    setValues({ ...values, [name]: event.target.value });
    console.log('handle change....requested' + event.target.value);
    showDataFormatTable(event.target.value);
    setPreviousDataFormatValue(event.target.value);
  };

  const rowDeleteSystemParameterDetails = data => {
    setRowSystemParameterData({ ...rowSystemParameterData, rowSystemParameterData: data });
  };

  function systemParameterRowDeleteClick () {
    let temNewDialogData = [...newData];
    if (rowSystemParameterData.rowSystemParameterData) {
      for (let i = 0; i < rowSystemParameterData.rowSystemParameterData.length; i++) {
        if (rowSystemParameterData.rowSystemParameterData[i] !== undefined) {
          temNewDialogData = temNewDialogData.filter(payment => payment.id !== rowSystemParameterData.rowSystemParameterData[i]);
        }
      }
    };
    // updateTableData(temNewDialogData);
    setnewData(temNewDialogData);
    setRowSystemParameterData([]);
  }

  const handelPromptSet = (set) => {
    if (set)
        setPrompt(true);
  }

  return (
    <div className="systen-parameter-add">
       <UnsavedChangesMessage allowNavigation={allowNavigation} handelPromptSet={handelPromptSet}
        confirm={confirm} cancelType={cancelType} prompt={prompt} setCancelType={setCancelType}
        setPrompt={setPrompt}/>
            
      <ToastsContainer store={ToastsStore} position={ToastsContainerPosition.TOP_RIGHT} />
      {spinnerLoader ? <Spinner /> : null}
      <div className="tabs-container" ref={toPrintRef} >
        <ErrorMessages errorMessages={errorMessages} />
        <div className="tab-header">
          <div className="tab-heading float-left">
            {SystemParameterAddConstants.ADD_SYSTEM_PARAMETER_TEXT}
          </div>
          <div className="float-right mt-2 hide-on-print">
            <Button className='btn btn-success ml-1' onClick={() => checkFieldValidations(values)}>
              <i class="fa fa-check" aria-hidden="true"></i>
              Save
            </Button>
            <ReactToPrint
              onBeforeGetContent={()=>{
                dispatch(setPrintLayout(true));          
                return new Promise((resolve)=>setTimeout(() =>resolve(), 100));
              }}
              onAfterPrint={()=>{
                dispatch(setPrintLayout(false))
              }}
              trigger={() => (<Button className='btn btn-primary ml-1' >
                                <i class="fa fa-print" aria-hidden="true"></i>
                                Print
                              </Button>)}
              content={() => toPrintRef.current}
            />

            <Button color="primary" className='btn btn-secondary ml-1'>
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div className='tab-body'>

          <form noValidate autoComplete="off">
            <div className='form-wrapper'>

              <div className="mui-custom-form input-md with-select">
                <TextField
                  id="lob-detail"
                  required
                  select
                  label="LOB"
                  value={values.lobDetail}
                  onChange={handleChange('lobDetail')}
                  helperText={showLOBError ? SystemParameterAddConstants.LOB_REQUIRED : null}
                  error={showLOBError ? SystemParameterAddConstants.LOB_REQUIRED : null}
                  InputLabelProps={{
                    shrink: true
                  }}
                  SelectProps={{
                    MenuProps: {
                      className: classes.menu
                    }
                  }}
                >

                  <MenuItem selected key="Please Select One" value="Please Select One">
                    Please Select One
                  </MenuItem>
                  {lobCodeData ? lobCodeData.map((option, index) => (
                    <MenuItem key={index} value={option.code}>
                      {option.description}
                    </MenuItem>
                  )) : null}
                </TextField>
              </div>

              <div className="mui-custom-form input-md with-select" // style={{ marginLeft: '30px' }}
              >
                <TextField
                  id="functional-area"
                  fullWidth
                  required
                  select
                  label="Functional Area"
                  value={values.functionalArea}
                  onChange={handleChange('functionalArea')}
                  helperText={showFunctionalAreaError ? SystemParameterAddConstants.FUNCTIONAL_AREA_REQUIRED : null}
                  error={showFunctionalAreaError ? SystemParameterAddConstants.FUNCTIONAL_AREA_REQUIRED : null}
                  InputLabelProps={{
                    shrink: true
                  }}
                  SelectProps={{
                    MenuProps: {
                      className: classes.menu
                    }
                  }}
                >
                  <MenuItem selected key="Please Select One" value="Please Select One">
                    Please Select One
                  </MenuItem>
                  {functionalAreaData ? functionalAreaData.map((option, index) => (

                    <MenuItem key={index} value={option.code}>
                      {option.description}
                    </MenuItem>
                  )) : null}

                </TextField>
              </div>

              <div className="mui-custom-form input-md" // style={{ marginLeft: '30px' }}
              >
                <TextField
                  id="param-number"
                  fullWidth
                  required
                  label="Parameter Number"
                  InputLabelProps={{
                    shrink: true
                  }}
                  value={values.paramNumber}
                  onChange={handleChange('paramNumber')}
                  inputProps={{ maxLength: 10 }}
                  onInput={e => {
                    e.target.value = e.target.value.replace(
                      AppConstants.NUMBER_ONLY_REGEX,
                      ''
                    );
                  }}
                  helperText={showParameterNoError ? SystemParameterAddConstants.PARAMETER_NUMBER_REQUIRED : null}
                  error={showParameterNoError ? SystemParameterAddConstants.PARAMETER_NUMBER_REQUIRED : null}
                />
              </div>

              <div className="mui-custom-form input-md with-select" // style={{ marginLeft: '30px' }}
              >
                <TextField
                  id="data-format"
                  fullWidth
                  required
                  select
                  label="Data Format"
                  value={values.dataFormat}
                  onChange={handleDataFormatChange('dataFormat')}
                  helperText={showDataFormatError ? SystemParameterAddConstants.DATA_FORMAT_REQUIRED : null}
                  error={showDataFormatError ? SystemParameterAddConstants.DATA_FORMAT_REQUIRED : null}
                  InputLabelProps={{
                    shrink: true
                  }}
                  SelectProps={{
                    MenuProps: {
                      className: classes.menu
                    }
                  }}
                >

                  <MenuItem selected key="Please Select One" value="Please Select One">
                    Please Select One
                  </MenuItem>
                  {dataFormatData ? dataFormatData.map((option, index) => (

                    <MenuItem key={index} value={option.code}>
                      {option.description}
                    </MenuItem>
                  )) : null}
                </TextField>
              </div>

              <div className="mui-custom-form input-xl">
                <TextField
                  required
                  id="description"
                  fullWidth
                  label="Description"
                  value={values.description}
                  onChange={handleChange('description')}
                  error={showDescriptionError ? SystemParameterAddConstants.DESCRIPTION_REQUIRED : null}
                  helperText={showDescriptionError ? SystemParameterAddConstants.DESCRIPTION_REQUIRED : null}
                  InputLabelProps={{
                    shrink: true
                  }}
                  inputProps={{ maxLength: 30 }}
                />
              </div>

              <div className="mui-custom-form">

                <div className="clearfix"></div>
              </div>
              <div className="clearfix"></div>
            </div>

          </form>
          <Dialog className="custom-dialog" onClose={handleClose} open={open} disableBackdropClick>
            <DialogTitle id="customized-dialog-title" onClose={handleClose}>
              {SystemParameterAddConstants.ADD_SYSTEM_PARAMETER_TEXT}
            </DialogTitle>
            <DialogContent dividers>

              <form className="form-wrapper" noValidate autoComplete="off">

                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                  <div className="mui-custom-form override-width-45 " style={{width:"200px"}}>
                    <KeyboardDatePicker
                      maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                      required
                      fullWidth
                      id="beginDateShowInTable"
                      fullWidth
                      label="Begin Date"
                      format="MM/dd/yyyy"
                      InputLabelProps={{
                        shrink: true
                      }}
                      placeholder="mm/dd/yyyy"
                      value={selectedBeginDate}
                      onChange={handleDateChange}
                      helperText={showBeginDateError ? errorMeg : null}
                      error={showBeginDateError ? errorMeg : null}
                      KeyboardButtonProps={{
                        'aria-label': 'change date'
                      }}
                    />
                  </div>
                </MuiPickersUtilsProvider>

                {values.dataFormat === 'N'
                  ? <div className="mui-custom-form override-width-45">
                    <TextField
                      id="format"
                      fullWidth
                      required
                      label="Number"
                      InputLabelProps={{
                        shrink: true
                      }}
                      value={dataElement.format}
                      onChange={handleChangeDataElement('format')}
                      inputProps={{ maxLength: 10 }}
                      helperText={showNumericError ? errorMegNumeric : null}
                      error={showNumericError ? errorMegNumeric : null}

                    />
                  </div>
                  : null
                }

                {values.dataFormat === 'C'
                  ? <div className="mui-custom-form override-width-45">

                    <TextField
                      required
                      id="format"
                      label="Currency"
                      value={dataElement.format}
                      InputLabelProps={{
                        shrink: true
                      }}
                      inputProps={{ maxLength: 14 }}
                      onChange={handleChangeDataElement('format')}
                      startAdornment={<InputAdornment position="start">$</InputAdornment>}
                      error={showCurrencyError ? errorMegCurrency : null}
                      type="number"
                    />

                    <p class="MuiFormHelperText-root MuiFormHelperText-filled danger-text">{showCurrencyError ? errorMegCurrency : null}</p>
                  </div>
                  : null
                }

                {values.dataFormat === 'D'
                  ? <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form override-width-45">
                      <KeyboardDatePicker
                        maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                        required
                        id="format"
                        fullWidth
                        label="Date"
                        format="MM/dd/yyyy"
                        InputLabelProps={{
                          shrink: true
                        }}
                        placeholder="mm/dd/yyyy"
                        value={selectedFormatDate}
                        onChange={handleFormatDateChange}
                        helperText={showDateError ? errorMegDate : null}
                        error={showDateError ? errorMegDate : null}
                        KeyboardButtonProps={{
                          'aria-label': 'change date'
                        }}
                      />
                    </div>
                  </MuiPickersUtilsProvider>
                  : null
                }

                {values.dataFormat === 'P'
                  ? <div className="mui-custom-form override-width-45">
                    <TextField
                      id="format"
                      fullWidth
                      required
                      label="Percent"
                      InputLabelProps={{
                        shrink: true
                      }}
                      value={dataElement.format}
                      inputProps={{ maxLength: 6 }}
                      onChange={handleChangeDataElement('format')}
                      helperText={showPercentError ? errorMegPercent : null}
                      error={showPercentError ? errorMegPercent : null}

                    />
                  </div>
                  : null
                }

                {values.dataFormat === 'T'
                  ? <div className="mui-custom-form override-width-45">
                    <TextField
                      id="format"
                      fullWidth
                      required
                      label="Text"
                      InputLabelProps={{
                        shrink: true
                      }}
                      value={dataElement.format}
                      inputProps={{ maxLength: 9 }}
                      onChange={handleChangeDataElement('format')}
                      helperText={showAlphaNumericError ? errorMegAlpha : null}
                      error={showAlphaNumericError ? errorMegAlpha : null}

                    />
                  </div>
                  : null
                }

                {values.dataFormat === 'Z'
                  ? <div className="mui-custom-form override-width-45">
                    <TextField
                      id="format"
                      fullWidth
                      required
                      label="Timestamp"
                      InputLabelProps={{
                        shrink: true
                      }}
                      value={dataElement.format}
                      onChange={handleChangeDataElement('format')}
                      helperText={showTimestampError ? errorMegTime : null}
                      error={showTimestampError ? errorMegTime : null}

                    />
                  </div>
                  : null
                }

              </form>
            </DialogContent>
            <DialogActions>
              <Button onClick={addParameter} className='btn btn-success'>
                <i class="fa fa-plus" aria-hidden="true"></i>
                Add
              </Button>
              <Button className='bt-reset btn-transparent' onClick={resetTable}>
                <i class="fa fa-undo" aria-hidden="true"></i>
                Reset
              </Button>
            </DialogActions>
          </Dialog>
          
          <div className="my-1 tab-holder">
            <div className="float-right my-2 hide-on-print">
              <Button className="btn-textConfig btn-transparent" onClick={systemParameterRowDeleteClick}>
                <i class="fa fa-trash" aria-hidden="true"></i>
                Delete
              </Button>
              <Button className="btn btn-success ml-1" onClick={handleClickOpen}>
                <i class="fa fa-plus" aria-hidden="true"></i>
                {SystemParameterAddConstants.ADD_SYSTEM_PARAMETER_DETAIL}
              </Button>
            </div>
            <div className="clearfix"></div>
            <h4 className="hide-on-screen mt-2"><span class="badge badge-primary">Add System Parameterss</span></h4>

            {
              showForm ? <SystemParameterAddValueTable tableData={newData} systemParameterAddHeadCells={systemParameterAddHeadCells} editSystemVariableTable={onClickEditSystemParameter} rowDeleteSystemParameterDetails={rowDeleteSystemParameterDetails} /> : null
            }
          </div>
          <Footer print />
          <div className='tab-panelbody'>
            <div className="tab-holder my-3">
              <AppBar position="static">
                <Tabs aria-label="simple tabs example" className="tabChange">
                  <Tab label="Notes" />
                </Tabs>
              </AppBar>
              <TabPanel value={tabValue} index={0}>
                <div className="tab-holder tab-holders  my-3">
                  <div className={`button-wrappers ${classes.root}`}>
                    <Notes addNotes = {addNotes}
                      notesTableData = {notesTableData}
                      noteSetListInput = {noteSetListInput}
                      setNoteSetListInput = {setNoteSetListInput}
                      usageTypeCodeData= {usageTypeCodeData}
                      editNoteData = {editNoteData}
                      setEditNoteData = {setEditNoteData}/>
                  </div>
                </div>
              </TabPanel>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default withRouter((SystemParameterAdd));