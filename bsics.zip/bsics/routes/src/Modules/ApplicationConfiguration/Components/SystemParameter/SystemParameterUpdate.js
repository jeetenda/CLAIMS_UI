/* eslint-disable no-unused-vars */
import React, { useEffect, useRef, createRef, useState } from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Bootstrap, { Button } from 'react-bootstrap';
import Dialog from '@material-ui/core/Dialog';
import SystemParameterAddTable from './SystemParameterAddTable';
import DateFnsUtils from '@date-io/date-fns';
import numeral from 'numeral';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import FormControl from '@material-ui/core/FormControl';
import InputAdornment from '@material-ui/core/InputAdornment';
import { useDispatch, useSelector } from 'react-redux';
import * as SystemParameterAddConstants from './systemParameterEditConstants';
import Input from '@material-ui/core/Input';
import { updateSystemParameter, systemParameterRowClickAction } from '../../Store/Actions/systemParameter/systemParameterActions';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import TabPanel from '../../../../SharedModules/TabPanel/TabPanel';
import AppBar from '@material-ui/core/AppBar';
import { Prompt } from 'react-router-dom';
import NoSaveMessage from '../../../../SharedModules/Errors/NoSaveMessage';
import { AppConfigDropdownActions } from '../../Store/Actions/AppConfigCommon/AppConfigActions';
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import * as DateUtils from '../../../../SharedModules/DateUtilities/DateUtilities';
import {
  KeyboardDatePicker,
  MuiPickersUtilsProvider
} from '@material-ui/pickers';
import { DialogTitle, DialogContent, DialogActions } from '../../../../SharedModules/Dialog/DialogUtilities';
import ErrorMessage from '../../../../SharedModules/Errors/ErrorMessages';
import SuccessMessage from '../../../../SharedModules/Errors/SuccessMessage';
import moment from 'moment';
import dropdownCriteria from './SystemParameterAddUpdate.json';
import * as AppConstants from '../../../../SharedModules/AppConstants';
import Notes from '../../../../SharedModules/Notes/Notes';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../../SharedModules/Store/Actions/SharedAction';
import Footer from '../../../../SharedModules/Layout/footer';
import NavHOC from '../../../../SharedModules/Navigation/NavHOC';
import UnsavedChangesMessage from '../../../../SharedModules/Errors/UnsavedChangesMessage';
import Radio from '@material-ui/core/Radio';

import Table from '../../../../SharedModules/Table/Table';
import { headCells } from './AuditLogConstants';
import './SystemParameterUpdate.css';

const voidData = [];
const newDataEdit = [];
const id = 0;
const showArray = [];
const arrayToCompare = [];

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap'
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1)
  },
  dense: {
    marginTop: theme.spacing(2)
  },
  menu: {
    width: 200
  }
}));

const styles = theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(2)
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});

export default NavHOC({
  Wrapped: SysyemParameterAdd,
  url: '/SystemParametersEdit',
  action: systemParameterRowClickAction,
  selector: 'appConfigState.systemParameterState.rowSearchSysParam'
});

function SysyemParameterAdd(props) {
  const toPrintRef = useRef();
  let paramsData;
  let editHeadCellsData = [];
  let errorMessagesArray = [];
  let successMessagesArray = [];
  const systemParameterAlert = useRef(null);
  const [tableRecord, settableRecord] = React.useState(props.location.state.payloadData.systemParameterDetail ? props.location.state.payloadData.systemParameterDetail : []);
  const dispatch = useDispatch();
  const [showForm, setShowForm] = React.useState(true);
  const [color, setColor] = React.useState('');
  const classes = useStyles();
  const [tableData, setTableData] = React.useState(props.location.state.payloadData.systemParameterDetail ? props.location.state.payloadData.systemParameterDetail : []);
  
  const [showLogTable, setShowLogTable] = React.useState(false)

  const [prompt, setPrompt] = useState(false);
  const [cancelType, setCancelType] = useState(false);
  const [confirm, setConfirm] = useState(false);
  
  useEffect(() => {
    if (tableData.length > 0) {
      tableData.map((var1) => {
        if (var1.valueAmt) {
          var1.valueAmt = numeral(Number(var1.valueAmt.replace(/,/g, '')).toFixed(4)).format('0,0.0000');
        }
        if (var1.beginDate) {
          var1.beginDate = moment(var1.beginDate).format('YYYY-MM-DD');
        }
        if (var1.endDate) {
          var1.endDate = moment(var1.endDate).format('YYYY-MM-DD');
        }
        if (var1.valueDate) {
          var1.valueDate = var1.valueDate;
        }
      });
    }
  }, [tableData]);
  const [id, setId] = React.useState(1);
  const [openCrossReference, setOpenCrossReference] = React.useState(false);
  const [value, setValue] = React.useState(0);
  const [open, setOpen] = React.useState(false);
  const [searchData, setSearchData] = React.useState(
    {}
  );
  const [selectedDate, setSelectedDate] = React.useState(null);
  const [selectedAmt, setSelectedAmt] = React.useState('');
  const [selectedNum, setSelectedNum] = React.useState('');
  const [selectedPCT, setSelectedPCT] = React.useState('');
  const [selectedData, setSelectedData] = React.useState('');
  const [selectedDateFormat, setSelectedDateFormat] = React.useState(null);
  const [allowNavigation, setAllowNavigation] = React.useState(false);
  const [tabValue, setTabValue] = React.useState(0);
  const [addEdit, setAddEdit] = React.useState(false);
  const [dataElement, setDataElement] = React.useState({
    voidSelected: 'No',
    valueAmt: '',
    valuePCT: '',
    valueNum: '',
    valueData: '',
    valueTimeStamp: ''
  });
  const [add, setAdd] = React.useState(true);
  const [voidFlag, setVoidFlag] = React.useState(false);
  const [editData, setEditData] = React.useState({});
  const [voidOption, setVoidOption] = React.useState(false);
  const [useEffectValues, setUseEffectValues] = React.useState([]);
  const [retainEdit, setRetainEdit] = React.useState();
  const [retainBeginDate, setRetainBeginDate] = React.useState();
  const [retainFormatDate, setRetainFormatDate] = React.useState('');
  const [values, setValues] = React.useState({
    lobDetail: '',
    dataFormat: '',
    description: '',
    paramNumber: '',
    functionalArea: ''
  });

  const [systemParameterEditHeadCells, setSystemParameterEditHeaddCells] = React.useState([
    { id: 'beginDate', numeric: false, disablePadding: true, label: 'Begin Date', width: '120', isDate: true },
    { id: 'endDate', numeric: false, disablePadding: true, label: 'End Date', width: '120', isDate: true },
    { id: 'lob', numeric: false, disablePadding: false, label: 'LOB' },
    { id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date', width: '120', isDate: true }
  ]);

  const systemErrorFocus = React.createRef();
  const [numericError, setNumericError] = React.useState(false);
  const [{
    showBeginDateErrorText, showDateErrorText, showCurrencyErrorText, showNumericErrorText,
    showAlphaNumericErrorText, showPercentErrorText, showTimeStampErrorText, showDescriptionErrorText
  }, setErrorMeg] = React.useState([]);
  const [selectedBeginDate, setSelectedBeginDate] = React.useState('');
  const [selectedFormatDate, setSelectedFormatDate] = React.useState('');
  const systemParamAddCons = SystemParameterAddConstants;
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [pageCount, setPageCount] = React.useState(tableData.length);
  const [showVoid, setShowVoid] = React.useState(false);
  const [voidYesNo, setVoidYesNo] = React.useState(false);
  const [{
    showFunctionalAreaError, showDataFormatError, showParameterNoError, showLOBError, showDescriptionError, showDateOverlappingError, showNumericError,
    showPercentError, showAlphaNumericError, showCurrencyError, showCurrencyInvalidError, showAlphaNumericInvalidError,
    showPercentInvalidError, showNumericInvalidError, showBeginDateError, showBeginDateInvalidError, showDateError, showDateInvalidError, showTimeStampError
  }
    , setShowError] = React.useState(false);
  const [showVoidArray, setShowVoidArray] = React.useState([]);
  const [voidTable, setVoidTable] = React.useState(props.location.state.payloadData.systemParameterDetail ? props.location.state.payloadData.systemParameterDetail : []);
  const [errorFocus, setErrorFocus] = React.useState(false);
  const [dateOverLapping, setDateOverLapping] = React.useState(false);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [dataFormatData, setDataFormatData] = React.useState([]);
  const [lobCodeData, setLobCodeData] = React.useState([]);
  const [successMessage, setSuccessMessage] = React.useState([]);
  const [voidedData, setVoidedData] = React.useState([]);
  const [nonVoidedData, setNonVoidedData] = React.useState([]);
  const [nonVoidedDatatoSetVoidPop, setNonVoidedDatatoSetVoidPop] = React.useState([]);
  const [concatbothvoidandnonvoid, setConcatbothVoidAndNonVoid] = React.useState([]);
  const [index, setIndex] = React.useState();
  const [currentParameterSK, setcurrentParameterSK] = React.useState();
  const [activeIndex, setActiveIndex] = React.useState();
  const [LoadSpinner, setSpinnerLoader] = React.useState(false);
  const [rowSystemParameterData, setRowSystemParameterData] = React.useState([]);
  const [versionNo, setVersionNo] = React.useState(0);
  const [notesTableData, setNotesTableData] = React.useState([]);
  const logInUserID = useSelector(state => state.sharedState.logInUserID);

  const systemParameterState = useSelector(state => (state && state.appConfigState &&
    state.appConfigState.systemParameterState && state.appConfigState.systemParameterState &&
    state.appConfigState.systemParameterState));
  const [auditDialogRowData, setAuditDialogRowData] = useState([]);
  const [auditRowData, setAuditRowData] = useState([]);

  const { auditDialogData, auditLogData } = systemParameterState;
 
  useEffect(() => {
    if (auditDialogData) {
      setAuditDialogRowData(auditDialogData);
    }
    if (auditLogData) {
      setAuditRowData(auditLogData);
    }
  }, [auditDialogData, auditLogData])

  const [notesInput, setNotesInput] = React.useState({

    auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
    auditTimeStamp: DateUtils.getUTCTimeStamp(),
    addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
    addedAuditTimeStamp: DateUtils.getUTCTimeStamp(),
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    tableName: null,
    noteSetSK: null,
    noteSourceName: null,
    notesList: notesTableData,
    globalNotesList: [],
    checkAll: null,
    addNewLinkRender: null,
    filterLinkRender: null,
    printLinkRender: null,
    completeNotesList: []

  });
  const [noteSetListInput, setNoteSetListInput] = React.useState({

  });
  const [usageTypeCodeData, setUsageTypeCodeData] = React.useState([]);
  const [editNoteData, setEditNoteData] = React.useState({});
  // add notes
  let notesDataArray = [];

  const addNotes = (data) => {
    setAllowNavigation(true);
    const noteText = data;
    notesDataArray = notesTableData;

    notesDataArray.push(noteText);
    setNotesTableData(notesDataArray);
    setNotesInput({ ...notesInput, notesList: notesDataArray });
  };
  const dropDownDispatch = dropdownvalues => dispatch(AppConfigDropdownActions(dropdownvalues));
  const userInquiryPrivileges = true;
  // Update Record
  const onUpdateSuccess = values => dispatch(systemParameterRowClickAction(values));
  const systemParameterUpdatedRecord = useSelector(state => state.appConfigState.systemParameterState.rowSearchSysParam);

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
  }, []);
  const dropdown = useSelector(state => state.appConfigState.AppConfigCommonState.appConfigDropdown);
  let voidDateArray = [];
  let nonVoidDateArray = [];
  const nonVoidArrayPopup = [];

  const updateResponse = useSelector(state => state.appConfigState.systemParameterState.updateSystemParameter);

  const [showLogDialogTable, setShowLogDialogTable] = React.useState(false);
  
  useEffect(() => {
    if (showLogTable)
      document.getElementById('audit-table').scrollIntoView();
  }, [showLogTable]);

  useEffect(() => {
    tableRecord.map((option, index) => {
      if (option.voidDate) {
        voidDateArray.push(option);
        setVoidedData(voidDateArray);
      } else {
        nonVoidDateArray.push(option);
        nonVoidArrayPopup.push(option);
        setNonVoidedData(nonVoidDateArray);
        setNonVoidedDatatoSetVoidPop(nonVoidArrayPopup);
        // setTableData(nonVoidDateArray);
      }
    });
    // setTableData(nonVoidDateArray);
    adjustEdnDates(nonVoidDateArray);
  }, [tableRecord]);

  useEffect(() => {
    if (props.location.state.successResponse) {
      const response = props.location.state.successResponse;
      if (response.respcode === '01') {
        successMessagesArray.push(SystemParameterAddConstants.SAVED_SUCCESSFULLY);
        setSuccessMessage(successMessagesArray);
      } else if (response.respcode === '03') {
        errorMessagesArray.push(response.exc);
        seterrorMessages(errorMessagesArray);
      } else if (response.respcode === '02') {
        errorMessagesArray.push(response.respdesc);
        seterrorMessages(errorMessagesArray);
      }
    }
  }, [props.location.state.successResponse]);

  useEffect(() => {
    if (props.location.state.payloadData) {
      paramsData = props.location.state.payloadData;
      // notes
      if (paramsData.noteSetVO) {
        const noteSetVO = paramsData.noteSetVO;
        const notesTable = paramsData.noteSetVO.notesList;
        setNotesInput({
          auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          auditTimeStamp: DateUtils.getUTCTimeStamp(),
          addedAuditUserID: noteSetVO.addedAuditUserID ? noteSetVO.addedAuditUserID : logInUserID ? logInUserID : 'BTAYLOR1',
          addedAuditTimeStamp: noteSetVO.addedAuditTimeStamp ? noteSetVO.addedAuditTimeStamp : DateUtils.getUTCTimeStamp(),
          versionNo: noteSetVO.versionNo,
          dbRecord: noteSetVO.dbRecord,
          sortColumn: noteSetVO.sortColumn,
          tableName: noteSetVO.tableName,
          noteSetSK: noteSetVO.noteSetSK,
          noteSourceName: noteSetVO.noteSourceName,
          notesList: notesTableData,
          globalNotesList: [],
          checkAll: noteSetVO.checkAll,
          addNewLinkRender: noteSetVO.addNewLinkRender,
          filterLinkRender: noteSetVO.filterLinkRender,
          printLinkRender: noteSetVO.printLinkRender,
          completeNotesList: []
        });
        setNotesTableData(notesTable);
      }
      setAddEdit(true);
      setVersionNo(paramsData.versionNo);
      setValues({
        lobDetail: 'MED',
        dataFormat: paramsData.parameterTypeCode ? paramsData.parameterTypeCode : '',
        description: paramsData.parameterName ? paramsData.parameterName : '',
        paramNumber: paramsData && paramsData.parameterNumber ? paramsData.parameterNumber : 0,
        functionalArea: paramsData && paramsData.functionalArea ? paramsData.functionalArea : ''
      });

      if (paramsData.parameterTypeCode === 'C') {
        editHeadCellsData = systemParameterEditHeadCells;
        editHeadCellsData.splice(2, 0, { id: 'valueAmt', numeric: false, disablePadding: false, label: 'Currency', isSPBalance: true });
        setSystemParameterEditHeaddCells(editHeadCellsData);
      } else if (paramsData.parameterTypeCode === 'P') {
        editHeadCellsData = systemParameterEditHeadCells;
        editHeadCellsData.splice(2, 0, { id: 'valuePCT', numeric: false, disablePadding: false, label: 'Percent', isPercent: true });
        setSystemParameterEditHeaddCells(editHeadCellsData);
      } else if (paramsData.parameterTypeCode === 'D') {
        editHeadCellsData = systemParameterEditHeadCells;
        editHeadCellsData.splice(2, 0, { id: 'valueDate', numeric: false, disablePadding: false, label: 'Date', isSystemParamDate: true });
        setSystemParameterEditHeaddCells(editHeadCellsData);
      } else if (paramsData.parameterTypeCode === 'N') {
        editHeadCellsData = systemParameterEditHeadCells;
        editHeadCellsData.splice(2, 0, { id: 'valueNum', numeric: false, disablePadding: false, label: 'Number' });
        setSystemParameterEditHeaddCells(editHeadCellsData);
      } else if (paramsData.parameterTypeCode === 'T') {
        editHeadCellsData = systemParameterEditHeadCells;
        editHeadCellsData.splice(2, 0, { id: 'valueData', numeric: false, disablePadding: false, label: 'Text' });
        setSystemParameterEditHeaddCells(editHeadCellsData);
      } else if (paramsData.parameterTypeCode === 'Z') {
        editHeadCellsData = systemParameterEditHeadCells;
        editHeadCellsData.splice(2, 0, { id: 'valueTimeStamp', numeric: false, disablePadding: false, label: 'Timestamp' });
        setSystemParameterEditHeaddCells(editHeadCellsData);
      }
    }
  }, []);
  useEffect(() => {
    if (systemParameterUpdatedRecord) {
      settableRecord(systemParameterUpdatedRecord.systemParameterDetail);
      setVersionNo(systemParameterUpdatedRecord.versionNo);
    }
  }, [systemParameterUpdatedRecord]);
  useEffect(() => {
    if (notesInput) {
      setNoteSetListInput({
        auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
        auditTimeStamp: DateUtils.getUTCTimeStamp(),
        addedAuditUserID: notesInput.addedAuditUserID ? notesInput.addedAuditUserID : logInUserID ? logInUserID : 'BTAYLOR1',
        addedAuditTimeStamp: notesInput.addedAuditTimeStamp ? notesInput.addedAuditTimeStamp : DateUtils.getUTCTimeStamp(),
        versionNo: notesInput.versionNo,
        dbRecord: false,
        sortColumn: null,
        noteTextValue: null,
        userIdName: null,
        notesCexAuditUserID: null,
        notesCexAuditTimeStamp: null,
        notesCexAddedAuditUserID: null,
        notesCexAddedAuditTimeStamp: null,
        noteSetSK: notesInput.noteSetSK,
        usageTypeDesc: '',
        shortNotes: null,
        checked: false,
        renderNoHistoryMsg: false,
        noteSequenceNumber: null,
        currentNote: null,
        rowValue: null,
        usageTypeList: null,
        strBeginDate: moment(new Date()).format('MM/DD/YYYY hh:mm:ss'),
        usageTypeCode: 'Please Select One',
        tableName: null,
        noteText: '',
        commonEntityName: null,
        commonEntityTypeCode: null,
        commonEntityId: null,
        entityId: null,
        filterbeginDate: moment(new Date()).format('YYYY-MM-DD'),
        filterEndDate: null,
        userId: notesInput.userId ? notesInput.userId : logInUserID ? logInUserID : 'BTAYLOR1',
        noteCexVersionNum: notesInput.noteCexVersionNum ? notesInput.noteCexVersionNum : 0,
        saNoteSequenceNumber: notesInput.saNoteSequenceNumber ? notesInput.saNoteSequenceNumber : null,
        notesCexnoteTextValue: notesInput.notesCexnoteTextValue ? notesInput.notesCexnoteTextValue : 0,
        id: DateUtils.generateUUID()
      });
    }
  }, [notesInput]);

  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj['Reference#1017']) {
        setFunctionalAreaData(dropdown.listObj['Reference#1017']);
      }
      if (dropdown.listObj['Reference#1019']) {
        setLobCodeData(dropdown.listObj['Reference#1019']);
      }
      if (dropdown.listObj['Reference#1025']) {
        setDataFormatData(dropdown.listObj['Reference#1025']);
      }
      if (dropdown.listObj['General#1012']) {
        setUsageTypeCodeData(dropdown.listObj['General#1012']);
      }
    }
  }, [dropdown]);

  useEffect(() => {
    if (updateResponse) {
      setSpinnerLoader(false);
      if (updateResponse.data && updateResponse.data.respcode && updateResponse.data.respcode === '01') {
        successMessagesArray.push(AppConstants.SAVE_SUCCESS);
        setSuccessMessage(successMessagesArray);
        setSpinnerLoader(false);
        const rowClickValues = {
          functionalArea: values.functionalArea,
          parameterNumber: +values.paramNumber
        };
        onUpdateSuccess(rowClickValues);
        setAllowNavigation(false);
      }
      if (updateResponse.data && updateResponse.data.respcode && updateResponse.data.respcode === '03') {
        errorMessagesArray.push(updateResponse.data.exc);
        seterrorMessages(errorMessagesArray);
      }
      if (updateResponse.data && updateResponse.data.respcode && updateResponse.data.respcode === '02') {
        errorMessagesArray.push(updateResponse.data.respdesc);
        seterrorMessages(errorMessagesArray);
      }
      if (!updateResponse.data && updateResponse.systemError) {
        errorMessagesArray.push([AppConstants.ERR_PROCESSING_REQ]);
        seterrorMessages(errorMessagesArray);
      }
    }
  }, [updateResponse]);

  const handleClickOpen = () => {
    // setAllowNavigation(true);
    var showDescriptionError = false; var showDescriptionErrorText = '';
    if (values.description === '') {
      showDescriptionError = true;
      showDescriptionErrorText = systemParamAddCons.DESCRIPTION_REQUIRED;
      setShowError({ showDescriptionError: showDescriptionError });
      errorMessagesArray = [];
      errorMessagesArray.push(showDescriptionErrorText);
      seterrorMessages(errorMessagesArray);
    } else {
      seterrorMessages([]);
      errorMessagesArray = [];
      successMessagesArray = [];
      setSuccessMessage(successMessagesArray);
      setOpen(true);
      setAdd(true);
      setSelectedFormatDate(null);
      setSelectedBeginDate(null);
      setDataElement({ voidSelected: 'No' });
      setErrorMeg({
        showDescriptionErrorText: null
      });
    }
    setErrorMeg({ showDescriptionErrorText: showDescriptionErrorText });
  };

  const handleClose = () => {
    setOpen(false);
    setDataElement({});
    setSelectedFormatDate(null);
    setSelectedBeginDate(null);
    setErrorMeg({
      showBeginDateErrorText: null,
      showDateErrorText: null,
      showCurrencyErrorText: null,
      showPercentErrorText: null,
      showNumericErrorText: null,
      showAlphaNumericErrorText: null,
      showTimeStampErrorText: null
    });
  };

  const handleShowVoid = () => {
    if (showVoid) {
      setShowVoid(false);
      setTableData(nonVoidedData);
    } else {
      setShowVoid(true);
      const voiddata = voidedData;
      const nonVoidData = nonVoidedData;
      const concatBoth = voiddata.concat(nonVoidData);
      setConcatbothVoidAndNonVoid(concatBoth);
      setTableData(concatBoth);
    }
  };

  const addTableData = () => {
    if (!showVoid) {
      setTableData(nonVoidDateArray);
    } else {
      const voiddata = voidedData;
      const nonVoidData = nonVoidDateArray;
      const concatBoth = voiddata.concat(nonVoidData);
      setConcatbothVoidAndNonVoid(concatBoth);
      setTableData(concatBoth);
    }
  };
  const [voidUpdate, setVoidUpdate] = React.useState(false);
  const onClickeditSystemParaMeter = (data, index) => event => {

     // audit log dispatch
     setShowLogDialogTable(false);

    var showDescriptionError, showDescriptionErrorText;
    if (values.description === '') {
      showDescriptionError = true;
      showDescriptionErrorText = systemParamAddCons.DESCRIPTION_REQUIRED;
      setShowError({ showDescriptionError: showDescriptionError });
      errorMessagesArray = [];
      errorMessagesArray.push(showDescriptionErrorText);
      seterrorMessages(errorMessagesArray);
      setErrorMeg({ showDescriptionErrorText: showDescriptionErrorText });
    } else {
      setErrorMeg({
        showDescriptionErrorText: null
      });
      setIndex(index);
      setcurrentParameterSK(data.parameterDetailSK);
      successMessagesArray = [];
      seterrorMessages([]);
      setSuccessMessage(successMessagesArray);
      setSelectedDate(data.beginDate);
      setSelectedData(data.valueData);
      setSelectedNum(data.valueNum);
      setSelectedPCT(data.valuePCT);
      setSelectedAmt(data.valueAmt);
      setSelectedDateFormat(data.valueDate);
      setSelectedFormatDate(data.valueDate);

      let SetData;
      if (data.voidDate) {
        SetData = {
          valueNum: data.valueNum,
          valueAmt: numeral(Number(data.valueAmt ? data.valueAmt.replace(/,/g, '') : data.valueAmt).toFixed(4)).format('0,0.0000'),
          valueData: data.valueData,
          valuePCT: data.valuePCT,
          voidSelected: 'Yes',
          voidDate: data.voidDate
        };
        setVoidUpdate(true);
      } else {
        SetData = {
          valueNum: data.valueNum,
          valueAmt: numeral(Number(data.valueAmt ? data.valueAmt.replace(/,/g, '') : data.valueAmt).toFixed(4)).format('0,0.0000'),
          valueData: data.valueData,
          valuePCT: data.valuePCT,
          valueTimeStamp: data.valueTimeStamp,
          voidSelected: 'No',
          voidDate: null
        };
        setVoidUpdate(false);
      }
      if (data.id) {
        setVoidFlag(true);
      } else {
        setVoidFlag(false);
      }
      setDataElement(SetData);

      if (data.valueDate) {
        var formatDate = data.valueDate;
        var dateVal = formatDate.split('/');
        setSelectedFormatDate(dateVal[2]+'-'+dateVal[0]+'-'+dateVal[1]);
        setRetainFormatDate(dateVal[2]+'-'+dateVal[0]+'-'+dateVal[1]);
      }

      let beginDate = data.beginDate;
      beginDate = new Date(beginDate);
      setSelectedBeginDate(beginDate);
      setRetainBeginDate(beginDate);
      setAdd(false);
      setOpen(true);
      setEditData(data);
      setRetainEdit(data);
    }
  };

  const resetEdit = () => {
    setShowLogDialogTable(false);
    setAuditDialogRowData([]);
    if (add) {
      setSelectedBeginDate(null);
      setSelectedFormatDate(null);
      setDataElement({
        valueNum: '',
        valueAmt: '',
        valueData: '',
        valuePCT: '',
        valueTimeStamp: '',
        voidSelected: 'No'
      });
      setErrorMeg({
        showBeginDateErrorText: null,
        showDateErrorText: null,
        showCurrencyErrorText: null,
        showPercentErrorText: null,
        showNumericErrorText: null,
        showAlphaNumericErrorText: null,
        showTimeStampErrorText: null
      });
      seterrorMessages([]);
    } else {
      setSelectedFormatDate(retainFormatDate);
      setSelectedBeginDate(retainBeginDate);
      setDataElement({
        valueData: retainEdit.valueData,
        valueNum: retainEdit.valueNum,
        valuePCT: retainEdit.valuePCT,
        valueAmt: retainEdit.valueAmt,
        valueTimeStamp: retainEdit.valueTimeStamp,
        voidSelected: 'No'
      });
      setErrorMeg({
        showBeginDateErrorText: null,
        showDateErrorText: null,
        showCurrencyErrorText: null,
        showPercentErrorText: null,
        showNumericErrorText: null,
        showAlphaNumericErrorText: null,
        showTimeStampErrorText: null
      });
      seterrorMessages([]);
    }
  };

  const checkFormatValidations = () => {
    var showBeginDateError; var showDateError; var showPercentError; var showNumericError; var showCurrencyError; var showAlphaNumericError; var showTimeStampError = false;
    var showBeginDateErrorText; var showDateErrorText; var showPercentErrorText; var showNumericErrorText; var showCurrencyErrorText; var showAlphaNumericErrorText; var showTimeStampErrorText = '';
    setErrorMeg({
      showBeginDateErrorText: null,
      showDateErrorText: null,
      showCurrencyErrorText: null,
      showPercentErrorText: null,
      showNumericErrorText: null,
      showAlphaNumericErrorText: null,
      showTimeStampErrorText: null
    });
    if (!selectedBeginDate) {
      showBeginDateError = true;
      showBeginDateErrorText = SystemParameterAddConstants.BEGIN_DATE_REQUIRED;
    } else if (selectedBeginDate.toString() === 'Invalid Date') {
      showBeginDateError = true;
      showBeginDateErrorText = SystemParameterAddConstants.BEGIN_DATE_INVALID;
    } else if (DateUtils.validateDateMinimumValue(selectedBeginDate)) {
      showBeginDateError = true;
      showBeginDateErrorText = AppConstants.DATE_ERROR_1964;
    }
    if (values.dataFormat === 'D' && (!selectedFormatDate)) {
      showDateError = true;
      showDateErrorText = SystemParameterAddConstants.DATE_REQUIRED;
    } else if (values.dataFormat === 'D' && selectedFormatDate.toString() === 'Invalid Date') {
      showDateError = true;
      showDateErrorText = SystemParameterAddConstants.DATE_INVALID;
    } else if (values.dataFormat === 'D' && DateUtils.validateDateMinimumValue(selectedFormatDate)) {
      showDateError = true;
      showDateErrorText = AppConstants.DATE_ERROR_1964;
    }
    if (((selectedBeginDate) && (selectedFormatDate)) && (values.dataFormat === 'D') && !showBeginDateError && !showDateError) {
      const beginDate = new Date(selectedBeginDate).getTime();
      const formatDate = new Date(selectedFormatDate).getTime();
      return true;
    }

    if (values.dataFormat === 'P') {
      if (!dataElement.valuePCT) {
        showPercentError = true;
        showPercentErrorText = SystemParameterAddConstants.PERCENT_REQUIRED;
      } else {
        const regex = /^[0-9]{1}(\.[0-9]{0,4})?$/;
        if (!regex.test(dataElement.valuePCT)) {
          showPercentError = true;
          showPercentErrorText = SystemParameterAddConstants.PERCENT_INVALID;
        }
      }
    }

    if (values.dataFormat === 'N') {
      if (!dataElement.valueNum) {
        showNumericError = true;
        showNumericErrorText = SystemParameterAddConstants.NUMERIC_REQUIRED;
      } else {
        const regex = /^[0-9]+$/;
        if (!regex.test(dataElement.valueNum)) {
          showNumericError = true;
          showNumericErrorText = SystemParameterAddConstants.NUMERIC_INVALID;
        }
      }
    }

    if (values.dataFormat === 'C') {
      if (!dataElement.valueAmt) {
        showCurrencyError = true;
        showCurrencyErrorText = SystemParameterAddConstants.CURRENCY_REQUIRED;
      } else {
        if (dataElement.valueAmt.toString().replace(/,/g, '').match(/^[-]?[0-9]{0,9}\.?[0-9]{0,4}$/) === null) {
          showCurrencyError = true;
          showCurrencyErrorText = SystemParameterAddConstants.CURRENCY_INVALID;
        } else {
          if (!(dataElement.valueAmt.toString().replace(/,/g, '').match(/^[-]?[0-9]{10,15}\.?[0-9]{0,2}?$/) === null)) {
            showCurrencyError = true;
            showCurrencyErrorText = SystemParameterAddConstants.CURRENCY_INVALID;
          }
        }
      }
    }

    if (values.dataFormat === 'T') {
      if (!dataElement.valueData) {
        showAlphaNumericError = true;
        showAlphaNumericErrorText = SystemParameterAddConstants.ALPHA_NUMERIC_REQUIRED;
      } else {
        const regex = /^[a-zA-Z0-9]+$/;
        if (!regex.test(dataElement.valueData)) {
          showAlphaNumericError = true;
          showAlphaNumericErrorText = SystemParameterAddConstants.ALPHA_NUMERIC_INVALID;
        }
      }
    }
    if (values.dataFormat === 'Z') {
      if (!dataElement.valueTimeStamp) {
        showTimeStampError = true;
        showTimeStampErrorText = SystemParameterAddConstants.TIMESTAMP_REQUIRED;
      } else {
        const regex = SystemParameterAddConstants.TIMESTAMP_REGEX;
        if (!regex.test(dataElement.valueTimeStamp)) {
          showTimeStampError = true;
          showTimeStampErrorText = SystemParameterAddConstants.TIMESTAMP_INVALID;
        }
      }
    }
    setShowError({
      showAlphaNumericError: showAlphaNumericError,
      showDateError: showDateError,
      showCurrencyError: showCurrencyError,
      showBeginDateError: showBeginDateError,
      showNumericError: showNumericError,
      showPercentError: showPercentError,
      showTimeStampError: showTimeStampError
    });

    setErrorMeg({
      showBeginDateErrorText: showBeginDateErrorText,
      showDateErrorText: showDateErrorText,
      showCurrencyErrorText: showCurrencyErrorText,
      showPercentErrorText: showPercentErrorText,
      showNumericErrorText: showNumericErrorText,
      showAlphaNumericErrorText: showAlphaNumericErrorText,
      showTimeStampErrorText: showTimeStampErrorText
    });
    if (!showTimeStampError && !showDateError && !showAlphaNumericError && !showCurrencyError && !showBeginDateError && !showNumericError && !showPercentError && !showTimeStampError) {
      return true;
    } else {
      return false;
    }
  };

  const changeSelectedBeginDateTimeStamp = (inputdate) => {
    return DateUtils.getDateInMMDDYYYYFormatWithApendZero(inputdate);
  };

  const changeDataBeginDateTimeStamp = (date) => {
    return DateUtils.getDateInMMDDYYYYFormatWithApendZero(date);
  };
  const beginDateSelected = new Date(selectedBeginDate).getTime();
  const adjustEdnDates = (nonVoidedDatatemp) => {
    const tempArray = JSON.parse(JSON.stringify(nonVoidedDatatemp.sort((a, b) => Date.parse(a.beginDate) < Date.parse(b.beginDate) ? -1 : 1)));
    tempArray.map((option, index) => {
      if (index === tempArray.length - 1) {
        option.endDate = moment(new Date('9999-12-31')).format('L');
      } else {
        option.endDate = moment(new Date(tempArray[index + 1].beginDate).getTime() - 86400000).format('L');
      }
    });
    nonVoidDateArray = tempArray;
    setNonVoidedData(tempArray);
    addTableData();
  };

  const addParameter = () => {
    setAllowNavigation(true);
    setErrorFocus(!errorFocus);
    const newData = tableData;
    if (add) {
      // setShowVoid(false);
      if (checkFormatValidations()) {
        setShowForm(true);
        setOpen(false);
        setShowError({
          showAlphaNumericError: false,
          showCurrencyError: false,
          showBeginDateError: false,
          showNumericError: false,
          showPercentError: false,
          showTimeStampError: false
        });
        dataElement.id = DateUtils.generateUUID();
        dataElement.beginDate = changeSelectedBeginDateTimeStamp(selectedBeginDate);

        dataElement.endDate = new Date('9999-12-30T19:00:00.000+0000');

        let count = 0;
        if (nonVoidedData.length > 0) {
          nonVoidedData.map((value) => {
            const beginDateToCompareOverlap = changeDataBeginDateTimeStamp(value.beginDate);
            if (beginDateToCompareOverlap === changeDataBeginDateTimeStamp(selectedBeginDate)) {
              count = count + 1;
            }
          });
        }

        var showDateOverlappingError = false;

        if (count > 0) {
          errorMessagesArray = [];
          seterrorMessages([]);
          showDateOverlappingError = true;
          errorMessagesArray.push(systemParamAddCons.BEGIN_DATE_OVERLAPPING);
          seterrorMessages(errorMessagesArray);
          setShowError({ showDateOverlappingError: showDateOverlappingError });
          window.scrollTo(0, 0);

          return showDateOverlappingError;
        }

        const value = {
          auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          auditTimeStamp: DateUtils.getUTCTimeStamp(),
          addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          addedAuditTimeStamp: DateUtils.getUTCTimeStamp(),
          versionNo: tableRecord.versionNo,
          voidDate: null,
          tempValue: tableRecord.tempValue,
          // beginDate:new Date(selectedBeginDate).getTime(),
          beginDate: moment(new Date(selectedBeginDate)).format('MM/DD/YYYY'),
          endDate: moment(new Date(dataElement.endDate)).format('MM/DD/YYYY'),
          // endDate: dataElement.endDate,
          valueDate: null,
          valueTimeStamp: null,
          valueAmt: null,
          valuePCT: null,
          valueNum: null,
          valueData: null,
          lob: values.lobDetail,
          parameterDetails: tableRecord.parameterDetails,
          id: DateUtils.generateUUID()
        };

        dataElement.beginDate = selectedBeginDate;

        if (values.dataFormat === 'D') {
          dataElement.valueDate = moment(selectedFormatDate).format('MM/DD/YYYY');
          if (dataElement.voidSelected === 'Yes') {
            value.voidDate = new Date().getTime();
            value.valueDate = dataElement.valueDate;
          } else {
            value.voidDate = null;
            value.valueDate = dataElement.valueDate;
          }
        }
        if (values.dataFormat === 'C') {
          dataElement.valueAmt = dataElement.valueAmt;
          if (dataElement.voidSelected === 'Yes') {
            value.voideDate = new Date().getTime();
            value.valueAmt = dataElement.valueAmt;
          } else {
            value.voideDate = null;
            value.valueAmt = dataElement.valueAmt;
          }
        }
        if (values.dataFormat === 'N') {
          dataElement.valueNum = dataElement.valueNum;
          if (dataElement.voidSelected === 'Yes') {
            value.valueNum = dataElement.valueNum;
            value.voidDate = new Date().getTime();
          } else {
            value.valueNum = dataElement.valueNum;
            value.voidDate = null;
          }
        }
        if (values.dataFormat === 'P') {
          dataElement.valuePct = dataElement.valuePCT;
          if (dataElement.voidSelected === 'Yes') {
            value.valuePCT = dataElement.valuePCT;
            value.voidDate = new Date().getTime();
          } else {
            value.valuePCT = dataElement.valuePCT;
            value.voidDate = null;
          }
        }
        if (values.dataFormat === 'T') {
          dataElement.valueData = dataElement.valueData;
          if (dataElement.voidSelected === 'Yes') {
            value.valueData = dataElement.valueData;
            value.voidDate = new Date().getTime();
          } else {
            value.valueData = dataElement.valueData;
            value.voidDate = null;
          }
        }

        if (values.dataFormat === 'Z') {
          dataElement.valueTimeStamp = dataElement.valueTimeStamp;
          if (dataElement.voidSelected === 'Yes') {
            let tempFormat = dataElement.valueTimeStamp;
            if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 10) {
              tempFormat = tempFormat + ' 00:00:00.000000';
            } else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 19) {
              tempFormat = tempFormat + '.000000';
            } else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 29) {
              tempFormat = tempFormat ? tempFormat.slice(0, -3) : tempFormat;
            }
            // else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 26) {
            //   tempFormat = tempFormat + '-00';
            // }
            value.valueTimeStamp = tempFormat;
            // value.valueTimeStamp = dataElement.valueTimeStamp;
            value.voidDate = new Date().getTime();
          } else {
            let tempFormat = dataElement.valueTimeStamp;
            if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 10) {
              tempFormat = tempFormat + ' 00:00:00.000000';
            } else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 19) {
              tempFormat = tempFormat + '.000000';
            } else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 29) {
              tempFormat = tempFormat ? tempFormat.slice(0, -3) : tempFormat;
            }
            // else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 26) {
            //   tempFormat = tempFormat + '-00';
            // }
            value.valueTimeStamp = tempFormat;
            // value.valueTimeStamp = dataElement.valueTimeStamp;
            value.voidDate = null;
          }
        }
        if (value.voidDate) {
          if (!showDateOverlappingError) {
            // nonVoidDateArray = adjustEdnDates(nonVoidDateArray);
            setNonVoidedData(nonVoidDateArray);
          }
        } else {
          if (!showDateOverlappingError) {
            nonVoidDateArray = JSON.parse(JSON.stringify(nonVoidedData));
            nonVoidDateArray.push(value);
            adjustEdnDates(nonVoidDateArray);
          }
        }
      }
    } else {
      let count = 0;
      var showBeginDateInvalidErrorText; var showFormatDateErrorText = '';
      if (selectedBeginDate) {
        dataElement.beginDate = moment(changeSelectedBeginDateTimeStamp(selectedBeginDate)).format('MM/DD/YYYY');
      }
      if (checkFormatValidations()) {
        setAdd(true);
        setOpen(false);
        setShowError({
          showAlphaNumericError: false,
          showCurrencyError: false,
          showBeginDateError: false,
          showNumericError: false,
          showPercentError: false,
          showTimeStampError: false
        });
        nonVoidedData.map((value, indexNumber) => {
          if (value.parameterDetailSK !== currentParameterSK) {
            const beginDateToCompareOverlap = changeDataBeginDateTimeStamp(value.beginDate);
            if (beginDateToCompareOverlap === dataElement.beginDate) {
              count = count + 1;
            }
            var showDateOverlappingError = false;
            if (count > 0) {
              errorMessagesArray = [];
              seterrorMessages([]);
              showDateOverlappingError = true;
              errorMessagesArray.push(systemParamAddCons.BEGIN_DATE_OVERLAPPING);
              seterrorMessages(errorMessagesArray);
              setShowError({ showDateOverlappingError: showDateOverlappingError });
              window.scrollTo(0, 0);
              return showDateOverlappingError;
            }
          } else {
            const selectedDate = new Date(selectedBeginDate);
            const formatDateSelected = new Date(selectedFormatDate);
            if (selectedDate instanceof Date && !isNaN(selectedDate.valueOf())) {
              value.auditUserID = logInUserID ? logInUserID : 'BTAYLOR1';
              value.auditTimeStamp = DateUtils.getUTCTimeStamp();
              if (value.endDate !== '9999-12-30T19:00:00.000+0000') {
                value.beginDate = moment(new Date(selectedBeginDate)).format('MM/DD/YYYY');
              }
              if (values.dataFormat === 'C') {
                value.valueAmt = dataElement.valueAmt;
              }

              if (values.dataFormat === 'N') {
                value.valueNum = dataElement.valueNum;
              }

              if (values.dataFormat === 'P') {
                value.valuePCT = dataElement.valuePCT;
              }

              if (values.dataFormat === 'T') {
                value.valueData = dataElement.valueData;
              }

              if (values.dataFormat === 'Z') {
                let tempFormat = dataElement.valueTimeStamp;
                if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 10) {
                  tempFormat = tempFormat + ' 00:00:00.000000';
                } else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 19) {
                  tempFormat = tempFormat + '.000000';
                } else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 29) {
                  tempFormat = tempFormat ? tempFormat.slice(0, -3) : tempFormat;
                }
                // else if (dataElement.valueTimeStamp && dataElement.valueTimeStamp.length === 26) {
                //   tempFormat = tempFormat + '-00';
                // }
                value.valueTimeStamp = tempFormat;
              }

              if (values.dataFormat === 'D') {
                if (formatDateSelected instanceof Date && !isNaN(formatDateSelected.valueOf())) {
                  value.valueDate = moment(new Date(selectedFormatDate)).format('MM/DD/YYYY');
                } else {
                  errorMessagesArray.push(systemParamAddCons.DATE_INVALID);
                  seterrorMessages(errorMessagesArray);
                }
              }
            } else {
              errorMessagesArray.push(systemParamAddCons.BEGIN_DATE_INVALID);
              seterrorMessages(errorMessagesArray);
            }
            value.auditUserID = logInUserID ? logInUserID : 'BTAYLOR1';
            value.auditTimeStamp = DateUtils.getUTCTimeStamp();

            nonVoidDateArray = JSON.parse(JSON.stringify(nonVoidedData));
            if (dataElement.voidSelected === 'Yes') {
              const sliceData = [];
              value.voidDate = new Date().getTime();
              // value.endDate = new Date('9999-12-31');
              voidDateArray = voidedData;
              voidDateArray.push(value);
              setVoidedData(voidDateArray);
              nonVoidDateArray.splice(indexNumber, 1);
            }
          }
        });
        adjustEdnDates(nonVoidDateArray);
        setIndex(-1);
        setcurrentParameterSK('');
      }
    };
  };

  const handleChangeDataElement = name => event => {
    setDataElement({ ...dataElement, [name]: event.target.value });
  };

  const handleChange = name => event => {
    setAllowNavigation(true);
    setValues({ ...values, [name]: event.target.value });
  };

  const handleChangeDataFormat = name => event => {
    setAllowNavigation(true);
    setValues({ ...values, [name]: event.target.value });

    if (event.target.value === 'Currency') {
      editHeadCellsData = systemParameterEditHeadCells;
      editHeadCellsData.pop();
      editHeadCellsData.push({ id: 'valueAmt', numeric: false, disablePadding: false, label: 'Currency', isSPBalance: true, width: '34%' });
      setSystemParameterEditHeaddCells(editHeadCellsData);
    } else if (event.target.value === 'Percent') {
      editHeadCellsData = systemParameterEditHeadCells;
      editHeadCellsData.pop();
      editHeadCellsData.push({ id: 'percent', numeric: false, disablePadding: false, label: 'Percent' });
      setSystemParameterEditHeaddCells(editHeadCellsData);
    } else if (paramsData.parameterTypeCode === 'D') {
      editHeadCellsData = systemParameterEditHeadCells;
      editHeadCellsData.splice(2, 0, { id: 'date', numeric: false, disablePadding: false, label: 'Date'});
      setSystemParameterEditHeaddCells(editHeadCellsData);
    } else if (event.target.value === 'Numeric') {
      editHeadCellsData = systemParameterEditHeadCells;
      editHeadCellsData.pop();
      editHeadCellsData.push({ id: 'numeric', numeric: false, disablePadding: false, label: 'Number' });
      setSystemParameterEditHeaddCells(editHeadCellsData);
    } else if (event.target.value === 'Text') {
      editHeadCellsData = systemParameterEditHeadCells;
      editHeadCellsData.pop();
      editHeadCellsData.push({ id: 'alpha numeric', numeric: false, disablePadding: false, label: 'Text' });
      setSystemParameterEditHeaddCells(editHeadCellsData);
    }
  };
  const handleDateChange = date => {
    setSelectedBeginDate(date);
  };

  const handleFormatDateChange = formatDate => {
    setSelectedFormatDate(formatDate);
  };

  const checkFormatValidation = value => {
    if (value !== '') {
      if (values.dataFormat === 'Numeric') {
        const reg = /^\d+$/;
        if (reg.test(value)) {
          return false;
        } else {
          return true;
        }
      } else if (values.dataFormat === 'Text') {
        const reg = /^[a-z0-9]+$/i;
        if (reg.test(value)) {
          return false;
        } else {
          return true;
        }
      }
    }
  };

  const saveSystemParameter = () => {
    setSuccessMessage([]);
    seterrorMessages([]);
    if (allowNavigation === false) {
      NoSaveMessage();
    } else {
      var showDescriptionError; var showLobCodeError = false;
      var showDescriptionErrorText; var showLobCodeErrorText = '';
      if (values.description === '') {
        showDescriptionError = true;
        showDescriptionErrorText = systemParamAddCons.DESCRIPTION_REQUIRED;
        setShowError({ showDescriptionError: showDescriptionError });
        errorMessagesArray = [];
        errorMessagesArray.push(showDescriptionErrorText);
        seterrorMessages(errorMessagesArray);
        setErrorMeg({ showDescriptionErrorText: showDescriptionErrorText });
      } else {
        const voidSet = voidedData;
        const nonVoidSet = nonVoidedData;
        voidSet.map((var1) => {
          var1.voidDate = moment(new Date(var1.voidDate)).format('MM/DD/YYYY');
        });
        const concatBoth = voidSet.concat(nonVoidSet);
        if (showVoid) {
          setTableData(concatBoth);
        } else {
          setTableData(nonVoidSet);
        }
        concatBoth.map((var1) => {
          var1.endDate = moment(new Date(var1.endDate)).format('MM/DD/YYYY');
        });
        const data = props.location.state.payloadData;
        errorMessagesArray = [];
        setErrorMeg([]);
        setShowError(false);
        seterrorMessages(errorMessagesArray);
        const detailIdObject = {};
        detailIdObject.functionalArea = values.functionalArea;
        detailIdObject.parameterNumber = values.paramNumber;
        detailIdObject.parameterDetailSK = null;
        concatBoth.systemParameterDetailID = detailIdObject;
        for (let i = 0; i < concatBoth.length; i++) {
          if (concatBoth[i].systemParameterDetailID == null) {
            concatBoth[i].systemParameterDetailID = detailIdObject;
            if (concatBoth[i].valueAmt) {
              concatBoth[i].valueAmt = concatBoth[i].valueAmt.replace(/,/g, '');
            }
            if (concatBoth[i].beginDate) {
              concatBoth[i].beginDate = moment(concatBoth[i].beginDate).format('MM/DD/YYYY');
            }
            if (concatBoth[i].endDate) {
              concatBoth[i].endDate = moment(concatBoth[i].endDate).format('MM/DD/YYYY');
            }
            if (concatBoth[i].valueDate) {
              concatBoth[i].valueDate = concatBoth[i].valueDate;
            }
          }
        }
        const requestData = {
          auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          auditTimeStamp: DateUtils.getUTCTimeStamp(),
          addedAuditUserID: data.addedAuditUserID ? data.addedAuditUserID : logInUserID ? logInUserID : 'BTAYLOR1',
          addedAuditTimeStamp: data.addedAuditTimeStamp ? data.addedAuditTimeStamp : DateUtils.getUTCTimeStamp(),
          versionNo: versionNo,
          parameterTypeCode: values.dataFormat,
          functionalArea: values.functionalArea,
          parameterNumber: values.paramNumber,
          parameterName: values.description,
          systemParamID: {
            functionalArea: values.functionalArea,
            parameterNumber: values.paramNumber
          },
          systemParameterDetail: concatBoth,
          deletedSysParameterDetails: null,
          noteSetVO: notesInput

        };
        setAllowNavigation(false);
        setSpinnerLoader(true);
        requestData.systemParameterDetail.map((value) => {
          if (value.systemParameterDetailID && value.systemParameterDetailID.valueDate) {
            moment(value.systemParameterDetailID.valueDate).format('L');
          }
        });
        dispatch(updateSystemParameter(requestData));
      }
    }
  };

  const rowDeleteSystemParameterDetails = data => {
    setRowSystemParameterData({ ...rowSystemParameterData, rowSystemParameterData: data });
  };

  function systemParameterRowDeleteClick() {
    let temNewDialogData = [...tableData];
    if (rowSystemParameterData.rowSystemParameterData) {
      for (let i = 0; i < rowSystemParameterData.rowSystemParameterData.length; i++) {
        if (rowSystemParameterData.rowSystemParameterData[i] !== undefined) {
          temNewDialogData = temNewDialogData.filter(payment => payment.id !== rowSystemParameterData.rowSystemParameterData[i]);
        }
      }
    };
    // updateTableData(temNewDialogData);
    settableRecord(temNewDialogData);
    // setTableData(temNewDialogData);
    setRowSystemParameterData([]);
  }
  const formatCurrency = () => {
    if (dataElement.valueAmt && values.dataFormat === 'C') {
      setDataElement({
        ...dataElement,
        valueAmt: numeral(dataElement.valueAmt)
          .format('0,0.00')
      });
    }
  };
  const [disableNotes, setDisableNotes] = React.useState(true);
  const validateParentForm = () => {
    // setSuccessMessage([]);
    if (
      (!(values.lobDetail) || values.lobDetail === 'Please Select One') ||
      (!(values.description) || values.description === '')
    ) {
      return true;
    } else {
      return false;
    }
  };
  useEffect(() => {
    setDisableNotes(validateParentForm());
  }, [values]);

  // clear out success/error msgs on click of add notes
  const clearSuccessErrorMsgs = () => {
    setSuccessMessage([]);
    seterrorMessages([]);
    setShowError(false);
  };
  let sharedPropsDialog = showLogDialogTable && !add ? { maxWidth: 'xl', fullWidth: true } : null;
  
  const handelPromptSet = (set) => {
    if (set)
        setPrompt(true);
  }

  return (
    <div className="system-parameter-update">
      <UnsavedChangesMessage allowNavigation={allowNavigation} handelPromptSet={handelPromptSet}
        confirm={confirm} cancelType={cancelType} prompt={prompt} setCancelType={setCancelType}
        setPrompt={setPrompt}/>
      {LoadSpinner ? <Spinner /> : null}
      <div className="tabs-container" ref={toPrintRef} >
        <ErrorMessage errorMessages={errorMessages} />
        {errorMessages.length === 0 ? <SuccessMessage successMessages={successMessage} /> : null}
        <div className="tab-header">
          <h1 className="tab-heading float-left">
            Edit System Parameter
          </h1>
          <div className="float-right  mt-1 pt-1 hide-on-print">

            <Button variant="outlined" color="primary" className='btn btn-success' onClick={() => saveSystemParameter()} disabled={!userInquiryPrivileges}
            >
              <i class="fa fa-check" aria-hidden="true"></i>
              Save
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                // setspinnerLoader(true);  //in some components it may have different name
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                // setspinnerLoader(false); //in some components it may have different name
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (<Button className='btn btn-primary ml-1' >
                <i class="fa fa-print" aria-hidden="true"></i>
                Print
              </Button>)}
              content={() => toPrintRef.current}
            />

            <Button color="primary" className='btn btn-secondary ml-1'
            >
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div className='tab-body'>
          <div className="pb-2">

            <form className={(classes.container)} noValidate autoComplete="off">
              <div className="mui-custom-form with-select input-md" style={{marginLeft: '30px'}}>
                <TextField
                  id="lob-detail"
                  fullWidth
                  required
                  disabled={!userInquiryPrivileges}
                  select
                  label="LOB"
                  value={values.lobDetail}
                  onChange={handleChange('lobDetail')}
                  SelectProps={{
                    MenuProps: {
                      className: classes.menu
                    }
                  }}
                  placeholder=""
                  InputLabelProps={{
                    shrink: true
                  }}
                >
                  {lobCodeData ? lobCodeData.map((option, index) => (
                    <MenuItem key={index} value={option.code}>
                      {option.description}
                    </MenuItem>
                  )) : null}
                </TextField>
              </div>
              <div className="mui-custom-form with-select input-md">
                <TextField
                  disabled={true}
                  id="functional-area"
                  fullWidth
                  select
                  label="Functional Area"
                  value={values.functionalArea}
                  onChange={handleChange('functionalArea')}
                  SelectProps={{
                    MenuProps: {
                      className: classes.menu
                    }
                  }}
                  placeholder=""
                  InputLabelProps={{
                    shrink: true
                  }}
                >
                  {functionalAreaData ? functionalAreaData.map((option, index) => (

                    <MenuItem key={index} value={option.code}>
                      {option.description}
                      {/* {Object.values(option)[0]} */}
                      {/* {option.value.key} */}
                    </MenuItem>
                  )) : null}
                </TextField>
              </div>
              <div className="mui-custom-form input-md">
                <TextField
                  // disabled={true}
                  InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                  id="routing-bank"
                  fullWidth
                  label="Parameter Number"
                  value={values.paramNumber}
                  onChange={handleChange('paramNumber')}
                  onInput={e => {
                    e.target.value = e.target.value.replace(
                      AppConstants.NUMBER_ONLY_REGEX,
                      ''
                    );
                  }}
                  InputLabelProps={{
                    shrink: true
                  }}
                  inputProps={{ maxLength: 10 }}
                />
              </div>
              <div className="mui-custom-form with-select input-md">
                <TextField
                  id="data-format"
                  fullWidth
                  disabled={true}
                  select
                  label="Data Format"
                  value={values.dataFormat}
                  onChange={handleChangeDataFormat('dataFormat')}
                  SelectProps={{
                    MenuProps: {
                      className: classes.menu
                    }
                  }}
                  placeholder=""
                  InputLabelProps={{
                    shrink: true
                  }}

                >
                  {dataFormatData ? dataFormatData.map((option, index) => (
                    <MenuItem key={index} value={option.code}>
                      {option.description}
                    </MenuItem>
                  )) : null}
                </TextField>
              </div>
              <div className="mui-custom-form input-xxl" style={{marginTop: '15px', marginLeft: '30px'}}>
                <TextField
                  id="description"
                  fullWidth
                  label="Description"
                  // disabled={!userInquiryPrivileges}
                  InputProps={{ readOnly: !userInquiryPrivileges, className: !userInquiryPrivileges ? 'Mui-disabled' : '' }}
                  value={values.description}
                  onChange={handleChange('description')}
                  inputProps={{ maxLength: 30 }}
                  InputLabelProps={{
                    shrink: true
                  }}
                  required
                  helperText={showDescriptionError ? showDescriptionErrorText : null}
                  error={showDescriptionError ? showDescriptionErrorText : null}

                />
              </div>
            </form>

            <div className="my-3 tab-holder" style={{ marginRight: '10px'}}>
              <div className="mui-custom-form no-margin dib show-voids mt-1">
                <div className="sub-radio no-margin">
                  <FormControlLabel
                    control={
                      <Checkbox color="primary" checked={showVoid} value={showVoid} onChange={handleShowVoid} />
                    }
                    label="Show Voids"
                  />
                </div>
              </div>
              <div className="float-right my-3 hide-on-print" style={{ marginRight: '14px' }}>
                <Button className="btn-textConfig btn-transparent" onClick={systemParameterRowDeleteClick}>
                  <i class="fa fa-trash" aria-hidden="true"></i>
                  Delete
                </Button>

                <Button className="btn btn-success ml-1" onClick={handleClickOpen} disabled={!userInquiryPrivileges}>
                  <i class="fa fa-plus" aria-hidden="true"></i>
                  Add System Parameter Detail
                </Button>

              </div>
            </div>
            <div className="clearfix"></div>

            <Dialog className={showLogDialogTable && !add ? "custom-dialog margin-left-250" : "custom-dialog"}
              onClose={handleClose}
              open={open} disableBackdropClick {...sharedPropsDialog}>
              <DialogTitle id="customized-dialog-title" onClose={handleClose}>
                {
                  add ? 'Add System Parameter Detail' : 'Edit System Parameter Detail'
                }
              </DialogTitle>
              <DialogContent dividers>

                <form className="form-wrapper" noValidate autoComplete="off">

                  <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form override-width-45">
                      {
                        dataElement.voidDate
                          ? <KeyboardDatePicker
                            maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                            disabled={true}
                            InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                            required
                            id="beginDate"
                            fullWidth
                            label="Begin Date"
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                              shrink: true
                            }}
                            placeholder="mm/dd/yyyy"
                            value={selectedBeginDate}
                            onChange={handleDateChange}
                            helperText={showBeginDateError ? showBeginDateErrorText : null}
                            error={showBeginDateError ? showBeginDateErrorText : null}
                            KeyboardButtonProps={{
                              'aria-label': 'change date'
                            }}
                          />
                          : <KeyboardDatePicker
                            maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                            required
                            disabled={!userInquiryPrivileges}
                            id="beginDate"
                            fullWidth
                            label="Begin Date"
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                              shrink: true
                            }}
                            placeholder="mm/dd/yyyy"
                            value={selectedBeginDate}
                            onChange={handleDateChange}
                            helperText={showBeginDateError ? showBeginDateErrorText : null}
                            error={showBeginDateError ? showBeginDateErrorText : null}
                            KeyboardButtonProps={{
                              'aria-label': 'change date'
                            }}
                          />

                      }

                    </div>
                  </MuiPickersUtilsProvider>

                  {values.dataFormat === 'N'
                    ? <div className="mui-custom-form override-width-45">
                      {
                        dataElement.voidDate
                          ? <TextField
                            required
                            // disabled={true}
                            InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                            id="format"
                            fullWidth
                            label="Number"
                            InputLabelProps={{
                              shrink: true
                            }}
                            value={dataElement.valueNum}
                            onChange={handleChangeDataElement('valueNum')}
                            inputProps={{ maxLength: 10 }}
                            helperText={showNumericError ? showNumericErrorText : null}
                            error={showNumericError ? showNumericErrorText : null}

                          />
                          : <TextField
                            required
                            id="format"
                            label="Number"
                            fullWidth
                            // disabled={!userInquiryPrivileges}
                            InputProps={{ readOnly: !userInquiryPrivileges, className: !userInquiryPrivileges ? 'Mui-disabled' : '' }}
                            InputLabelProps={{
                              shrink: true
                            }}
                            value={dataElement.valueNum}
                            onChange={handleChangeDataElement('valueNum')}
                            inputProps={{ maxLength: 10 }}
                            helperText={showNumericError ? showNumericErrorText : null}
                            error={showNumericError ? showNumericErrorText : null}

                          />

                      }

                    </div>
                    : null
                  }

                  {values.dataFormat === 'C'
                    ? <div>
                      {
                        dataElement.voidDate
                          ? <div className="mui-custom-form override-width-95">

                            <TextField
                              label="Currency"
                              id="format"
                              fullWidth
                              onBlur={formatCurrency}
                              value={dataElement.valueAmt}
                              inputProps={{ maxLength: 14 }}
                              onChange={handleChangeDataElement('valueAmt')}
                              startAdornment={<InputAdornment position="start">$</InputAdornment>}
                              error={showCurrencyError ? showCurrencyErrorText : null}
                              // disabled
                              InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                            />

                            <p class="MuiFormHelperText-root MuiFormHelperText-filled danger-text">{showCurrencyError ? showCurrencyErrorText : null}</p>
                          </div>
                          : <div className="mui-custom-form override-width-95">

                            <TextField
                              id="format"
                              label="Currency"
                              fullWidth
                              // disabled={!userInquiryPrivileges}
                              onBlur={formatCurrency}
                              InputProps={{ readOnly: !userInquiryPrivileges, className: !userInquiryPrivileges ? 'Mui-disabled' : '' }}
                              value={dataElement.valueAmt}
                              InputLabelProps={{
                                shrink: true
                              }}
                              inputProps={{ maxLength: 14 }}
                              onChange={handleChangeDataElement('valueAmt')}
                              startAdornment={<InputAdornment position="start">$</InputAdornment>}
                              error={showCurrencyError ? showCurrencyErrorText : null}
                            />

                            <p class="MuiFormHelperText-root MuiFormHelperText-filled danger-text">{showCurrencyError ? showCurrencyErrorText : null}</p>
                          </div>
                      }

                    </div>
                    : null
                  }

                  {values.dataFormat === 'D'
                    ? <MuiPickersUtilsProvider utils={DateFnsUtils}>
                      {
                        dataElement.voidDate
                          ? <div className="mui-custom-form override-width-45">
                            <KeyboardDatePicker
                              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                              disabled={true}
                              InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                              required
                              fullWidth
                              id="format"
                              label="Date"
                              format="MM/dd/yyyy"
                              InputLabelProps={{
                                shrink: true
                              }}
                              placeholder="mm/dd/yyyy"
                              value={selectedFormatDate}
                              onChange={handleFormatDateChange}
                              helperText={showDateError ? showDateErrorText : null}
                              error={showDateError ? showDateErrorText : null}
                              KeyboardButtonProps={{
                                'aria-label': 'change date'
                              }}
                            />
                          </div>
                          : <div className="mui-custom-form override-width-45">
                            <KeyboardDatePicker
                              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                              required
                              fullWidth
                              disabled={!userInquiryPrivileges}
                              InputProps={{ readOnly: !userInquiryPrivileges, className: !userInquiryPrivileges ? 'Mui-disabled' : '' }}
                              id="format"
                              label="Date"
                              format="MM/dd/yyyy"
                              InputLabelProps={{
                                shrink: true
                              }}
                              placeholder="mm/dd/yyyy"
                              value={selectedFormatDate}
                              onChange={handleFormatDateChange}
                              helperText={showDateError ? showDateErrorText : null}
                              error={showDateError ? showDateErrorText : null}
                              KeyboardButtonProps={{
                                'aria-label': 'change date'
                              }}
                            />
                          </div>
                      }

                    </MuiPickersUtilsProvider>
                    : null
                  }

                  {values.dataFormat === 'P'
                    ? <div className="mui-custom-form override-width-45">
                      {
                        dataElement.voidDate
                          ? <TextField
                            required
                            fullWidth
                            // disabled={true}
                            InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                            id="format"
                            label="Percent"
                            InputLabelProps={{
                              shrink: true
                            }}
                            value={dataElement.valuePCT}
                            inputProps={{ maxLength: 6 }}
                            onChange={handleChangeDataElement('valuePCT')}
                            helperText={showPercentError ? showPercentErrorText : null}
                            error={showPercentError ? showPercentErrorText : null}

                          />
                          : <TextField
                            required
                            fullWidth
                            id="format"
                            label="Percent"
                            // disabled={!userInquiryPrivileges}
                            InputProps={{ readOnly: !userInquiryPrivileges, className: !userInquiryPrivileges ? 'Mui-disabled' : '' }}
                            InputLabelProps={{
                              shrink: true
                            }}
                            value={dataElement.valuePCT}
                            inputProps={{ maxLength: 6 }}
                            onChange={handleChangeDataElement('valuePCT')}
                            helperText={showPercentError ? showPercentErrorText : null}
                            error={showPercentError ? showPercentErrorText : null}

                          />

                      }

                    </div>
                    : null
                  }

                  {values.dataFormat === 'T'
                    ? <div className="mui-custom-form override-width-45">
                      {
                        dataElement.voidDate
                          ? <TextField
                            required
                            fullWidth
                            // disabled={true}
                            InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                            id="format"
                            label="Text"
                            InputLabelProps={{
                              shrink: true
                            }}
                            value={dataElement.valueData}
                            inputProps={{ maxLength: 9 }}
                            onChange={handleChangeDataElement('valueData')}
                            helperText={showAlphaNumericError ? showAlphaNumericErrorText : null}
                            error={showAlphaNumericError ? showAlphaNumericErrorText : null}

                          />
                          : <TextField
                            required
                            // disabled={!userInquiryPrivileges}
                            InputProps={{ readOnly: !userInquiryPrivileges, className: !userInquiryPrivileges ? 'Mui-disabled' : '' }}
                            fullWidth
                            id="format"
                            label="Text"
                            InputLabelProps={{
                              shrink: true
                            }}
                            value={dataElement.valueData}
                            inputProps={{ maxLength: 9 }}
                            onChange={handleChangeDataElement('valueData')}
                            helperText={showAlphaNumericError ? showAlphaNumericErrorText : null}
                            error={showAlphaNumericError ? showAlphaNumericErrorText : null}

                          />
                      }

                    </div>
                    : null
                  }
                  {
                    values.dataFormat === 'Z'
                      ? <div className="mui-custom-form override-width-45">
                        {dataElement.voidDate
                          ? <TextField
                            // disabled
                            InputProps={{ readOnly: true, className: 'Mui-disabled' }}
                            fullWidth
                            id="format"
                            required
                            label="Timestamp"
                            InputLabelProps={{
                              shrink: true
                            }}
                            inputProps={{ maxLength: 29 }}
                            value={dataElement.valueTimeStamp}
                            onChange={handleChangeDataElement('valueTimeStamp')}
                            helperText={showTimeStampError ? showTimeStampErrorText : null}
                            error={showTimeStampError ? showTimeStampErrorText : null}

                          />
                          : <TextField
                            id="format"
                            required
                            disabled={!userInquiryPrivileges}
                            InputProps={{ readOnly: !userInquiryPrivileges, className: !userInquiryPrivileges ? 'Mui-disabled' : '' }}
                            fullWidth
                            label="Timestamp"
                            InputLabelProps={{
                              shrink: true
                            }}
                            inputProps={{ maxLength: 29 }}
                            value={dataElement.valueTimeStamp}
                            onChange={handleChangeDataElement('valueTimeStamp')}
                            helperText={showTimeStampError ? showTimeStampErrorText : null}
                            error={showTimeStampError ? showTimeStampErrorText : null}

                          />
                        }
                      </div>
                      : null
                  }

                  {
                    add || voidFlag ? null

                      : <div className="mui-custom-form">

                        {
                          dataElement.voidDate
                            ? <div>
                              <span className="MuiFormLabel-root small-label no-margin">Void</span>
                              <div className="sub-radio" style={{ paddingTop: '10px', marginLeft: '0px' }}>
                                <Radio
                                  name="voidSelection"
                                  value="Yes"
                                  id="voidYesId"
                                  checked={dataElement.voidSelected === 'Yes'}
                                  onChange={handleChangeDataElement('voidSelected')}
                                  disabled
                                /><label className="text-black" for="voidYesId">Yes</label>
                                <Radio
                                  name="voidSelection"
                                  value="No"
                                  id="voidNoId"
                                  checked={dataElement.voidSelected === 'No'}
                                  onChange={handleChangeDataElement('voidSelected')}
                                  disabled
                                  className="ml-2"
                                /><label className="text-black" for="voidNoId">No</label>
                              </div>
                            </div>
                            : <div>
                              <span className="MuiFormLabel-root small-label no-margin">Void</span>
                              <div className="sub-radio" style={{ paddingTop: '10px', marginLeft: '0px' }}>
                                <Radio
                                  name="voidSelection"
                                  value="Yes"
                                  id="voidSelectionYesId"
                                  disabled={!userInquiryPrivileges}
                                  checked={dataElement.voidSelected === 'Yes'}
                                  onChange={handleChangeDataElement('voidSelected')}
                                /><label for="voidSelectionYesId" className="text-black">Yes</label>
                                <Radio
                                  name="voidSelection"
                                  value="No"
                                  id="voidSelectionNoId"
                                  disabled={!userInquiryPrivileges}
                                  checked={dataElement.voidSelected === 'No'}
                                  onChange={handleChangeDataElement('voidSelected')}
                                  className="ml-2"
                                /><label for="voidSelectionNoId" className="text-black">No</label>
                              </div>
                            </div>

                        }

                      </div>
                  }

                </form>
              </DialogContent>
              <DialogActions>
                <div>
                  {
                    add
                      ? <div>
                        <Button variant="outlined" color="primary" onClick={addParameter} disabled={!userInquiryPrivileges} className='btn btn-success'>
                          <i class="fa fa-plus" aria-hidden="true"></i>
                          Add
                        </Button>
                        <Button variant="outlined" color="primary" className='bt-reset btn-transparent ml-1' onClick={resetEdit} disabled={!userInquiryPrivileges}>
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset
                        </Button>
                      </div>
                      : <div>
                        <Button variant="outlined" color="primary" onClick={addParameter} disabled={!userInquiryPrivileges || voidUpdate} className='btn btn-primary'>
                          Update
                        </Button>
                        <Button variant="outlined" color="primary" className='bt-reset btn-transparent ml-1' onClick={resetEdit} disabled={!userInquiryPrivileges || voidUpdate}>
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset
                        </Button>
                      </div>
                  }
                </div>

              </DialogActions>

              <DialogContent>
                {
                  (showLogDialogTable && !add)
                    ?
                    (<div className='tab-panelbody'  >
                      <div className="tab-holder form-control-text">Audit Details</div>
                      <div className="tab-holder table-no-wrap table-p-5">
                        <Table
                          print={props.print}
                          headCells={headCells}
                          isSearch={true}
                          tableData={auditDialogRowData}
                          onTableRowClick={null}
                          defaultSortColumnDesc={true}
                          defaultSortColumn={'timestamp'}
                        />
                      </div>
                    </div>)
                    : null
                }

              </DialogContent>

            </Dialog>
            <div className="clearfix"></div>
            <div className="tab-holder" style={{ marginLeft: '10px', marginRight: '10px' }}>
              <div className="tab-holder pb-1 hide-on-print">

                <SystemParameterAddTable
                  tableData={tableData}
                  addEdit={addEdit}
                  editSystemVariableTable={onClickeditSystemParaMeter}
                  systemParameterEditHeadCells={systemParameterEditHeadCells}
                  dataFormat={tableRecord.parameterTypeCode}
                  pageCount={pageCount}
                  voidYesNo={voidYesNo}
                  showVoid={showVoid}
                  voidTableData={concatbothvoidandnonvoid}
                  nonVoidTableData={nonVoidedData}
                  rowDeleteSystemParameterDetails={rowDeleteSystemParameterDetails}
                />
              </div>

              <div className="tab-holder pb-1 hide-on-screen" style={{ marginLeft: '10px', marginRight: '10px' }}>
                <h4 className="hide-on-screen mt-2"><span class="badge badge-primary">Edit System Parameter</span></h4>

                <SystemParameterAddTable
                  print
                  tableData={tableData}
                  addEdit={addEdit}
                  editSystemVariableTable={onClickeditSystemParaMeter}
                  systemParameterEditHeadCells={systemParameterEditHeadCells}
                  dataFormat={tableRecord.parameterTypeCode}
                  pageCount={pageCount}
                  voidYesNo={voidYesNo}
                  showVoid={showVoid}
                  voidTableData={concatbothvoidandnonvoid}
                  nonVoidTableData={nonVoidedData}
                  rowDeleteSystemParameterDetails={rowDeleteSystemParameterDetails}
                />
              </div>
            </div>
          </div>
          <div className='tab-panelbody'>
            <div className="tab-holder my-3">
              <AppBar position="static">
                <Tabs value={value} aria-label="simple tabs example" className="tabChange">
                  <Tab label="Notes" />
                </Tabs>
              </AppBar>
              <TabPanel value={tabValue} index={0}>
                <div className="tab-holder  p-0 hide-on-print">
                  <div className={classes.root}>
                    <Notes addNotes={addNotes}
                      notesTableData={notesTableData}
                      noteSetListInput={noteSetListInput}
                      setNoteSetListInput={setNoteSetListInput}
                      usageTypeCodeData={usageTypeCodeData}
                      editNoteData={editNoteData}
                      setEditNoteData={setEditNoteData}
                      setSuccessMessages={clearSuccessErrorMsgs}
                      disableNotes={disableNotes} />
                  </div>
                </div>
                <div className="tab-holder my-3 p-0 hide-on-screen">
                  <h4 className="hide-on-screen mt-2"><span class="badge badge-primary">Notes</span></h4>
                  <div className={classes.root} className="tab-holder pb-1 hide-on-screen">
                    <Notes addNotes={addNotes}
                      print
                      notesTableData={notesTableData}
                      noteSetListInput={noteSetListInput}
                      setNoteSetListInput={setNoteSetListInput}
                      usageTypeCodeData={usageTypeCodeData}
                      editNoteData={editNoteData}
                      setEditNoteData={setEditNoteData}
                      setSuccessMessages={clearSuccessErrorMsgs}
                      disableNotes={disableNotes} />
                  </div>
                </div>
              </TabPanel>
            </div>
          </div>
          {
            showLogTable ?
              (<div className='tab-panelbody' id='audit-table' >
                <div className="tab-holder form-control-text">Audit Details</div>
                <div className="tab-holder table-no-wrap table-p-5">
                  <Table
                    print={props.print}
                    headCells={headCells}
                    isSearch={true}
                    tableData={auditRowData}
                    onTableRowClick={null}
                    defaultSortColumnDesc={true}
                    defaultSortColumn={'timestamp'}
                  />
                </div>
              </div>) : null
          }
          <Footer print />
        </div>

      </div>
    </div>
  );
}
