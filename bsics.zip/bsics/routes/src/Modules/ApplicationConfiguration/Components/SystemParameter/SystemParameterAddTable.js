/* eslint-disable no-unused-vars */
import React, { useEffect } from 'react';
import TableComponent from '../../../../SharedModules/Table/Table';


export default function SystemParameterAddTable (props) {
  return (
    <TableComponent isSearch={false}
      tableData={props.tableData}
      headCells={props.systemParameterEditHeadCells}
      onTableRowClick={props.editSystemVariableTable}
      defaultSortColumn={props.systemParameterEditHeadCells[0].id}
      onTableRowDelete = {props.rowDeleteSystemParameterDetails}
    ></TableComponent>
  );
};
