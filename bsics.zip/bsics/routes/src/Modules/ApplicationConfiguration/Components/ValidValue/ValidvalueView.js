/* eslint-disable no-unused-vars */
import React, { useEffect, useRef } from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import CrossReferenceTableComponent from './CrossReferenceTableComponent';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Box from '@material-ui/core/Box';
import { withStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import moment from 'moment';
import AssociatedValuesTableComponent from './AssociatedValueTableComponent';
import * as ValidValueConstants from './ValidValueConstants';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import { validValueAction, ValidValueUpdateAction, validValueViewAction } from '../../Store/Actions/validValue/validValueActions';
import { useDispatch, useSelector } from 'react-redux';
import { Prompt } from 'react-router-dom';
import NoSaveMessage from '../../../../SharedModules/Errors/NoSaveMessage';
import { AppConfigDropdownActions, notesUsageTypeDropdown } from '../../Store/Actions/AppConfigCommon/AppConfigActions';
import ErrorMessages from '../../../../SharedModules/Errors/ErrorMessages';
import dropdownCriteria from './ValidValueView.json';
import { generateUUID } from '../../../../SharedModules/DateUtilities/DateUtilities';
import Notes from '../../../../SharedModules/Notes/Notes';
import ReactToPrint from "react-to-print";
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import { setPrintLayout } from "../../../../SharedModules/store/Actions/SharedAction";
import SuccessMessage from '../../../../SharedModules/Errors/SuccessMessage';
import Footer from "../../../../SharedModules/Layout/footer";
import { getUTCTimeStamp } from '../../../../SharedModules/DateUtilities/DateUtilities';
import PropsInit from "../../../../SharedModules/Navigation/NavHOC";


let newData = [];
const styles = theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(2)
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});

const DialogTitle = withStyles(styles)(props => {
  const { children, classes, onClose } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root}>
      <Typography variant='h6'>{children}</Typography>
      {onClose
        ? <IconButton aria-label='close' className={classes.closeButton} onClick={onClose}>
          <CloseIcon />
        </IconButton>
        : null}
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles(theme => ({
  root: {
    padding: theme.spacing(2)
  }
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(1)
  }
}))(MuiDialogActions);

function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <Typography
      component='div'
      role='tabpanel'
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      {...other}
    >
      <Box p={3}>{children}</Box>
    </Typography>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.any.isRequired,
  value: PropTypes.any.isRequired
};
export default PropsInit({Wrapped:ValidValueAdd, url:'/ValidvalueView',
 action:validValueViewAction, selector:'appConfigState.validValueState.validValue'});

function ValidValueAdd (props) {
console.log("valid value view")
  const logInUserID = useSelector(state => state.sharedState.logInUserID);
  const toPrintRef = useRef();
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [spinnerLoader, setSpinnerLoader] = React.useState(false);
  const [dataFormat, setDataFormat] = React.useState([]);
  const [tableData, setTableData] = React.useState(
    props.location.state ? (props.location.state.paylod ? props.location.state.paylod.associatedValidValues : props.location.state.payloadData.associatedValidValues) : null
  );
  const filterData = tableData.filter((value, index) => {
    return value.voidDate == null;
  });
  const [filteredData, setFilteredData] = React.useState(filterData);
  const [tableDataCrossReference, setTableDataCrossReference] = React.useState(
    props.location.state ? (props.location.state.paylod ? props.location.state.paylod.crossReference : props.location.state.payloadData.crossReference) : null
  );

  const [searchData, setSearchData] = React.useState(
    props.location.state ? (props.location.state.paylod ? props.location.state.paylod : props.location.state.payloadData) : null
  );
  
  const validvaluecons = ValidValueConstants;
  let errorMessagesArray = [];
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [{ showCodeError, showConstanttError, showShortDescriptionError, showLongDescriptionError, showDateOverlappingError, showSourceTableError, showFunctionalAreaError }
    , setShowError] = React.useState(false);
  const [{
    showCodeErrorText,
    showConstanttErrorText,
    showShortDescriptionErrorText,
    showLongDescriptionErrorText,
    showSourceTableErrorText,
    showFunctionalAreaErrorText
  }, setShowErrorText] = React.useState('');
  const [allowNavigation, setAllowNavigation] = React.useState(false);
  const [rowAssociatedValidValueData, setRowAssociatedValidValueData] = React.useState([]);

  const [value, setValue] = React.useState(0);
  const [showVoid, setShowVoid] = React.useState(false);
  const [open, setOpen] = React.useState(false);
  const [showTable, setShowTable] = React.useState(false);
  // Notes
  const [notesTableData, setNotesTableData] = React.useState([]);
  const [notesInput, setNotesInput] = React.useState({
    auditUserID: logInUserID,
    auditTimeStamp: getUTCTimeStamp(),
    addedAuditUserID: logInUserID,
    addedAuditTimeStamp: getUTCTimeStamp(),
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    tableName: null,
    noteSetSK: null,
    noteSourceName: null,
    notesList: notesTableData,
    globalNotesList: [],
    checkAll: null,
    addNewLinkRender: null,
    filterLinkRender: null,
    printLinkRender: null,
    completeNotesList: []

  });
  const [noteSetListInput, setNoteSetListInput] = React.useState({

  });
  const [usageTypeCodeInput, setUsageTypeCodeInput] = React.useState([{
    functionalArea: 'General',
    dataElementName: 'G_NOTE_TY_CD',
    businessName: null,
    valueShortDescription: null,
    crossReferenceColumnName: null,
    crossReferenceTableName: null,
    dataEleNameStartsOrContains: null,
    busNameStartsOrContains: null
  }]);
  const [usageTypeCodeData, setUsageTypeCodeData] = React.useState([]);
  const [editNoteData, setEditNoteData] = React.useState({});

  const dispatch = useDispatch();
  const [useEffectValues, setUseEffectValues] = React.useState([]);
  const dropDownDispatch = (dropdownvalues) => dispatch(AppConfigDropdownActions(dropdownvalues));
  let dropdown = [];
  // notes usage type  dropdown
  const usageTypeDropDown = usageTypeCodeInput => dispatch(notesUsageTypeDropdown(usageTypeCodeInput));

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
    usageTypeDropDown(usageTypeCodeInput);
  }, [useEffectValues]);

  const onSave = (values) => dispatch(ValidValueUpdateAction(values));
  const getSearchRecord = (values) => dispatch(validValueAction(values));
  dropdown = useSelector(state => state.appConfigState.AppConfigCommonState.appConfigDropdown);
  const backendMsg = useSelector(state => state.appConfigState.validValueState.validValueUpdate);
  const updatedRecord = useSelector(state => state.appConfigState.validValueState.validValue);
  const usageTypeCodeDropDown = useSelector(state => state.appConfigState.AppConfigCommonState.usageDropDown);

  useEffect(() => {
    console.log(usageTypeCodeDropDown);
    if (usageTypeCodeDropDown) {
      if (usageTypeCodeDropDown.listObj) {
        const usage = usageTypeCodeDropDown.listObj['General#G_NOTE_TY_CD'];
        setUsageTypeCodeData(usage);
      }
    }
  }, [usageTypeCodeDropDown]);
  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj['Reference#1017']) {
        setFunctionalAreaData(dropdown.listObj['Reference#1017']);
      }
      if (dropdown.listObj['Reference#1050']) {
        setDataFormat(dropdown.listObj['Reference#1050']);
      }
    }
  }, [dropdown]);

  const [values, setValues] = React.useState({
    code: '',
    dataBusinessName: searchData.dataBusinessName,
    domainName: searchData.domainName,
    description: searchData.description,
    dataformat: searchData.dataFormat,
    dataSize: searchData.dataSize,
    functionalAreas: searchData.functionalArea !== null ? searchData.functionalArea : 'Please Select One',
    shortDescription: '',
    longDescription: '',
    constantText: '',
    sourceTable: searchData.sourceTableName,
    sourceCodeDescription: searchData.sourceCodeDescription,
    sourceCode: searchData.sourceCode,
    associatedselectedOption: '',
    selectedOption: false,
    versionNo: searchData.versionNo,
    validValueUpdate: searchData.endUserUpdate || searchData.endUserUpdate === 'true' ? 'Yes' : 'No'
  });

  const [dataElement, setDataElement] = React.useState({
    associatedselectedOption: 'No',
    addedAuditTimeStamp: new Date(),
    addedAuditUserID: 'SYSADMIN',
    auditKeyListFiltered: false,
    auditTimeStamp: new Date(),
    auditUserID: 'SYSADMIN',
    code: values.functionalAreas && values.functionalAreas !== 'Please Select One' ? values.functionalAreas.substring(0, 2) : null,
    constantText: '',
    dbRecord: false,
    longDescription: '',
    shortDescription: '',
    showVoidRecord: false,
    showVoids: false,
    sortColumn: null,
    valueStatus: true,
    versionNo: 0,
    voidDate: null,
    voidIndicator: false
  });
  const userInquiryPrivileges = useSelector(state => state.sharedState.userInquiryPrivileges && state.sharedState.userInquiryPrivileges.applicationUser);
  useEffect(() => {
    setValues({
      code: '',
      dataBusinessName: searchData.dataBusinessName,
      domainName: searchData.domainName,
      description: searchData.description,
      dataformat: searchData.dataFormat,
      dataSize: searchData.dataSize,
      functionalAreas: searchData.functionalArea !== null ? searchData.functionalArea : 'Please Select One',
      shortDescription: '',
      longDescription: '',
      constantText: '',
      sourceTable: searchData.sourceTableName,
      sourceCodeDescription: searchData.sourceCodeDescription,
      sourceCode: searchData.sourceCode,
      associatedselectedOption: '',
      selectedOption: false,
      versionNo: searchData.versionNo,
      validValueUpdate: searchData.endUserUpdate || searchData.endUserUpdate === 'true' ? 'Yes' : 'No'
    });
    if (searchData.noteSetVO) {
      const noteSetVO = searchData.noteSetVO;
      const notesTable = searchData.noteSetVO.notesList;
      setNotesInput({
        auditUserID: logInUserID,
        auditTimeStamp: getUTCTimeStamp(),
        addedAuditUserID: searchData && searchData !== undefined ? (searchData.noteSetVO.addedAuditUserID ? searchData.noteSetVO.addedAuditUserID : logInUserID) : logInUserID,
        addedAuditTimeStamp: searchData && searchData !== undefined ? (searchData.noteSetVO.addedAuditTimeStamp ? searchData.noteSetVO.addedAuditTimeStamp : getUTCTimeStamp()) : getUTCTimeStamp(),
        versionNo: noteSetVO.versionNo,
        dbRecord: noteSetVO.dbRecord,
        sortColumn: noteSetVO.sortColumn,
        tableName: noteSetVO.tableName,
        noteSetSK: noteSetVO.noteSetSK,
        noteSourceName: noteSetVO.noteSourceName,
        notesList: notesTableData,
        globalNotesList: [],
        checkAll: noteSetVO.checkAll,
        addNewLinkRender: noteSetVO.addNewLinkRender,
        filterLinkRender: noteSetVO.filterLinkRender,
        printLinkRender: noteSetVO.printLinkRender,
        completeNotesList: []
      });
      console.log(notesTable);
      setNotesTableData(notesTable);
    }
  }, [searchData, dropdown]);

  useEffect(() => {
    if (notesInput) {
      setNoteSetListInput({
        auditUserID: logInUserID,
        auditTimeStamp: getUTCTimeStamp(),
        addedAuditUserID: notesInput && notesInput !== undefined ? (notesInput.addedAuditUserID ? notesInput.addedAuditUserID : logInUserID) : logInUserID,
        addedAuditTimeStamp: notesInput && notesInput !== undefined ? (notesInput.addedAuditTimeStamp ? notesInput.addedAuditTimeStamp : getUTCTimeStamp()) : getUTCTimeStamp(),
        versionNo: notesInput.versionNo,
        dbRecord: false,
        sortColumn: null,
        noteTextValue: null,
        userIdName: null,
        notesCexAuditUserID: null,
        notesCexAuditTimeStamp: null,
        notesCexAddedAuditUserID: null,
        notesCexAddedAuditTimeStamp: null,
        noteSetSK: notesInput.noteSetSK,
        usageTypeDesc: '',
        shortNotes: null,
        checked: false,
        renderNoHistoryMsg: false,
        noteSequenceNumber: null,
        currentNote: null,
        rowValue: null,
        usageTypeList: null,
        strBeginDate: moment(new Date()).format('MM/DD/YYYY hh:mm:ss'),
        usageTypeCode: 'Please Select One',
        tableName: null,
        noteText: '',
        commonEntityName: null,
        commonEntityTypeCode: null,
        commonEntityId: null,
        entityId: null,
        filterbeginDate: moment(new Date()).format('YYYY-MM-DD'),
        filterEndDate: null,
        userId: notesInput.userId ? notesInput.userId : '',
        noteCexVersionNum: notesInput.noteCexVersionNum ? notesInput.noteCexVersionNum : 0,
        saNoteSequenceNumber: notesInput.saNoteSequenceNumber ? notesInput.saNoteSequenceNumber : null,
        notesCexnoteTextValue: notesInput.notesCexnoteTextValue ? notesInput.notesCexnoteTextValue : 0,
        id: generateUUID()
      });
    }
  }, [notesInput]);

  const handleClickOpen = () => {
    seterrorMessages([]);
    setSuccessMessages([]);
    setShowErrorText({
      showCodeErrorText: '',
      showConstanttErrorText: '',
      showShortDescriptionErrorText: '',
      showLongDescriptionErrorText: '',
      showSourceTableErrorText: '',
      showFunctionalAreaErrorText: ''
    });
    setShowError({
      showCodeError: false,
      showConstanttError: false,
      showShortDescriptionError: false,
      showLongDescriptionError: false,
      showDateOverlappingError: false,
      showSourceTableError: false,
      showFunctionalAreaError: false
    });
    setOpen(true);
    setDataElement({
      code: '',
      longDescription: '',
      description: ''
    });
  };

  const handleClose = () => {
    seterrorMessages([]);
    setSuccessMessages([]);
    setShowErrorText({
      showCodeErrorText: '',
      showConstanttErrorText: '',
      showShortDescriptionErrorText: '',
      showLongDescriptionErrorText: '',
      showSourceTableErrorText: '',
      showFunctionalAreaErrorText: ''
    });
    setShowError({
      showCodeError: false,
      showConstanttError: false,
      showShortDescriptionError: false,
      showLongDescriptionError: false,
      showDateOverlappingError: false,
      showSourceTableError: false,
      showFunctionalAreaError: false
    });
    setOpen(false);
  };

  const handleChangeTabs = (event, newValue) => {
    setAllowNavigation(true);
    setValue(newValue);
  };
  const handleChange = name => event => {
    setAllowNavigation(true);
    setValues({ ...values, [name]: event.target.value });
  };

  const handleChangeDataElement = name => event => {
    setAllowNavigation(true);
    if (name === 'code') {
      setDataElement({ ...dataElement, [name]: (event.target.value).toUpperCase() });
    } else {
      setDataElement({ ...dataElement, [name]: event.target.value });
    }
  };

  const handleReset = (row) => {
    errorMessagesArray = [];
    seterrorMessages([]);
    setSuccessMessages([]);
    setShowErrorText({
      showCodeErrorText: '',
      showConstanttErrorText: '',
      showShortDescriptionErrorText: '',
      showLongDescriptionErrorText: '',
      showSourceTableErrorText: '',
      showFunctionalAreaErrorText: ''
    });
    setShowError({
      showCodeError: false,
      showConstanttError: false,
      showShortDescriptionError: false,
      showLongDescriptionError: false,
      showDateOverlappingError: false,
      showSourceTableError: false,
      showFunctionalAreaError: false
    });
    setDataElement({
      associatedselectedOption: '',
      addedAuditTimeStamp: '',
      addedAuditUserID: '',
      auditKeyListFiltered: '',
      auditTimeStamp: '',
      auditUserID: '',
      code: '',
      constantText: '',
      dbRecord: '',
      longDescription: '',
      shortDescription: '',
      showVoidRecord: '',
      showVoids: '',
      sortColumn: '',
      valueStatus: '',
      versionNo: 0,
      voidDate: null,
      voidIndicator: ''
    });
  };

  const [newRecord, setNewRecord] = React.useState(
    {
      associatedselectedOption: '',
      addedAuditTimeStamp: '',
      addedAuditUserID: '',
      auditKeyListFiltered: '',
      auditTimeStamp: '',
      auditUserID: '',
      code: '',
      constantText: '',
      dbRecord: '',
      longDescription: '',
      shortDescription: '',
      showVoidRecord: '',
      showVoids: '',
      sortColumn: '',
      valueStatus: '',
      versionNo: 0,
      voidDate: null,
      voidIndicator: ''
    }
  );
  const handleAdd = () => {
    setAllowNavigation(true);
    errorMessagesArray = [];
    seterrorMessages([]);
    setSuccessMessages([]);
    let count = 0;
    var showCodeError; var showConstanttError; var showShortDescriptionError; var showLongDescriptionError; var showDateOverlappingError = false;
    var showCodeErrorText; var showConstanttErrorText; var showShortDescriptionErrorText; var showLongDescriptionErrorText = '';

    if (!dataElement.code) {
      showCodeError = true;
      showCodeErrorText = validvaluecons.CODE_DATASIZE_REQUIRED;
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (dataElement.code && dataElement.code.length > searchData.dataSize) {
      showCodeError = true;
      showCodeErrorText = validvaluecons.CODE_DATASIZE_ERROR;
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (dataElement.code && tableData.length > 0) {
      tableData.map((value, index) => {
        if (value.code === dataElement.code && value.voidDate === null) {
          count = count + 1;
          return false;
        }
      });
      if (count > 0) {
        showCodeError = true;
        showCodeErrorText = validvaluecons.VALID_VALUE_CODE_OVERLAPPING;
        seterrorMessages(errorMessagesArray);
        setShowTable(false);
      }
    }

    if (dataElement.constantText === undefined || dataElement.constantText === '') {
      if (dataElement.shortDescription !== undefined && dataElement.shortDescription !== '') {
        dataElement.constantText = 'VV_' + dataElement.shortDescription.replace(/[^A-Z0-9]/ig, '_');
        if (dataElement.constantText.replace(/[^A-Z0-9]/ig, '_') !== dataElement.constantText) {
          showConstanttError = true;
          showConstanttErrorText = ValidValueConstants.TEXT_INVALID_FORMAT;
        } else {
          dataElement.constantText = dataElement.constantText.replace(/[^A-Z0-9]/ig, '_');
        }
      } else {
        showConstanttError = true;
        showConstanttErrorText = validvaluecons.CONSTANT_TEXT_REQUIRED;
        seterrorMessages(errorMessagesArray);
        setShowTable(false);
      }
    } else {
      if (dataElement.constantText.replace(/[^A-Z0-9]/ig, '_') !== dataElement.constantText) {
        showConstanttError = true;
        showConstanttErrorText = ValidValueConstants.TEXT_INVALID_FORMAT;
      } else {
        if (!dataElement.constantText.startsWith('VV_')) {
          dataElement.constantText = 'VV_' + dataElement.constantText;
        }
        dataElement.constantText = dataElement.constantText.replace(/[^A-Z0-9]/ig, '_');
      }
    }
    let dupConstantText = false;
    if (dataElement.constantText !== undefined && dataElement.constantText !== '') {
      for (let i = 0; i < tableData.length; i++) {
        if (tableData[i].constantText === dataElement.constantText && tableData[i].voidDate === null) {
          dupConstantText = true;
          break;
        }
      }
      if (dupConstantText) {
        showConstanttError = true;
        showConstanttErrorText = validvaluecons.CONSTANT_TEXT_UNIQUE_ERROR;
        seterrorMessages(errorMessagesArray);
        setShowTable(false);
      }
    }

    if (!dataElement.shortDescription) {
      showShortDescriptionError = true;
      showShortDescriptionErrorText = validvaluecons.SHORT_DESCRIPTION_REQUIRED;
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (!dataElement.longDescription) {
      showLongDescriptionError = true;
      showLongDescriptionErrorText = validvaluecons.LONG_DESCRIPTION_REQUIRED;
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    } else if ((errorMessagesArray.length === 0) &&
      (!showCodeError && !showConstanttError && !showShortDescriptionError &&
        !showLongDescriptionError && !showDateOverlappingError)) {
      const dataElementdata = {
        auditUserID: logInUserID,
        auditTimeStamp: getUTCTimeStamp(),
        addedAuditUserID: logInUserID,
        addedAuditTimeStamp: getUTCTimeStamp(),
        code: dataElement.code,
        shortDescription: dataElement.shortDescription,
        longDescription: dataElement.longDescription,
        voidDate: null,
        auditKeyList: [],
        constantText: dataElement.constantText,
        auditKeyListFiltered: '',
        dbRecord: false,
        showVoidRecord: false,
        showVoids: false,
        sortColumn: '',
        valueStatus: null,
        versionNo: 0,
        voidIndicator: false,
        isNewRow: true,
        id: generateUUID()
      };
      setDataElement(dataElementdata);
      setNewRecord(dataElement);
      newData = tableData;
      newData.unshift(dataElementdata);
      setTableData(newData);
      const filterData = newData.filter((value, index) => {
        return value.voidDate == null;
      });
      setFilteredData(filterData);
      setOpen(false);
    }
    setShowError({
      showCodeError: showCodeError,
      showConstanttError: showConstanttError,
      showShortDescriptionError: showShortDescriptionError,
      showLongDescriptionError: showLongDescriptionError,
      showDateOverlappingError: showDateOverlappingError
    });

    setShowErrorText({
      showCodeErrorText: showCodeErrorText,
      showConstanttErrorText: showConstanttErrorText,
      showShortDescriptionErrorText: showShortDescriptionErrorText,
      showLongDescriptionErrorText: showLongDescriptionErrorText
    });
  };
  const [flag, setFlag] = React.useState(false);
  useEffect(() => {
    setSpinnerLoader(false);
    if (updatedRecord && updatedRecord.length === 1) {
      setValues({
        code: updatedRecord[0].sourceCode,
        dataBusinessName: updatedRecord[0].dataBusinessName,
        domainName: updatedRecord[0].domainName,
        description: updatedRecord[0].description,
        dataformat: updatedRecord[0].dataFormat,
        dataSize: updatedRecord[0].dataSize,
        functionalAreas: updatedRecord[0].functionalArea,
        shortDescription: '',
        longDescription: '',
        constantText: '',
        sourceTable: updatedRecord[0].sourceTableName,
        sourceCodeDescription: updatedRecord[0].sourceCodeDescription,
        sourceCode: updatedRecord[0].sourceCode,
        associatedselectedOption: '',
        selectedOption: false,
        versionNo: updatedRecord[0].versionNo,
        validValueUpdate: updatedRecord[0].endUserUpdate === true || updatedRecord[0].endUserUpdate === 'true' ? 'Yes' : 'No'
      });
      setTableDataCrossReference(updatedRecord[0].crossReference);
      setTableData(updatedRecord[0].associatedValidValues);
      const filterData = updatedRecord[0].associatedValidValues.filter((value, index) => {
        return value.voidDate == null;
      });
      setFilteredData(filterData);
      setFlag(!flag);
    }
  }, [updatedRecord]);

  React.useEffect(() => {
    setSpinnerLoader(false);
    if (backendMsg && backendMsg.respcode && backendMsg.respcode === '01') {
      getSearchRecord({
        businessName: searchData.dataBusinessName !== '' ? searchData.dataBusinessName : null,
        functionalArea: values.functionalAreas !== 'Please Select One' ? values.functionalAreas : null,
        dataElementName: searchData.domainName !== '' ? searchData.domainName : null
      });
      setSuccessMessages([backendMsg.respdesc]);
    } else if (backendMsg && backendMsg.respcode && backendMsg.respcode !== '01') {
      setSuccessMessages([]);
      seterrorMessages([backendMsg.respdesc]);
    } else if (backendMsg && backendMsg.systemError) {
      setSuccessMessages([]);
      seterrorMessages([ValidValueConstants.ERROR_PROCESSING_REQUEST]);
    }
  }, [backendMsg]);
  // Updated table data from associated valid value
  const updateTableData = (tableDataUpdated) => {
    seterrorMessages([]);
    setSuccessMessages([]);
    setAllowNavigation(true);
    setTableData(tableDataUpdated);
    const filteredData = tableDataUpdated.filter((value, index) => {
      return value.voidDate == null;
    });
    setFilteredData(filteredData);
  };
  React.useEffect(() => {
  }, [filteredData]);

  const handleShowVoidsChange = event => {
    if (showVoid) {
      setShowVoid(false);
    } else {
      setShowVoid(true);
    }
  };
  const masterSaveDataElement = () => {
    seterrorMessages([]);
    setSuccessMessages([]);
    setShowError([]);
    setShowErrorText([]);
    var showSourceTableError = false; var showFunctionalAreaError = false;
    var showSourceTableErrorText = ''; var showFunctionalAreaErrorText = '';
    if (!allowNavigation) {
      NoSaveMessage();
    } else {
      setAllowNavigation(false);
      if (values.sourceTable === '') {
        showSourceTableError = true;
        showSourceTableErrorText = validvaluecons.SOURCE_TABLE_REQUIRED;
        errorMessagesArray.push(showSourceTableErrorText);
        seterrorMessages(errorMessagesArray);
      }
      if (values.functionalAreas === 'Please Select One') {
        showFunctionalAreaError = true;
        showFunctionalAreaErrorText = validvaluecons.FUNCTIONAL_AREA_FIELD_REQUIRED;
        errorMessagesArray.push(showFunctionalAreaErrorText);
        seterrorMessages(errorMessagesArray);
      }
      let nonVoidCount = 0;
      for (var tabVal in tableData) {
        if (tableData[tabVal].voidDate === null) {
          nonVoidCount = nonVoidCount + 1;
        }
      }
      if (nonVoidCount === 0 && searchData.sourceTableName === 'R_VV_TB') {
        errorMessagesArray.push(validvaluecons.ASSOCIATED_VALID_VALUE_REQUIRED);
        seterrorMessages(errorMessagesArray);
      }
      if (errorMessagesArray.length === 0) {
        for (var tabVal in tableData) {
          if (tableData[tabVal].voidDate !== null) {
            tableData[tabVal].voidDate = tableData[tabVal].voidDate.split(' ')[0];
          }
        }
        // API Integration
        const editCriteria =
            {
              auditUserID: logInUserID,
              auditTimeStamp: getUTCTimeStamp(),
              addedAuditUserID: searchData && searchData !== undefined ? (searchData.addedAuditUserID ? searchData.addedAuditUserID : logInUserID) : logInUserID,
              addedAuditTimeStamp: searchData && searchData !== undefined ? (searchData.addedAuditTimeStamp ? searchData.addedAuditTimeStamp : getUTCTimeStamp()) : getUTCTimeStamp(),
              versionNo: values.versionNo,
              dbRecord: searchData.dbRecord,
              sortColumn: searchData.sortColumn,
              auditKeyList: searchData.auditKeyList,
              auditKeyListFiltered: searchData.auditKeyListFiltered,
              domainName: searchData.domainName,
              showSourceField: searchData.showSourceField,
              showAssociativeActive: searchData.showAssociativeActive,
              sourceCode: searchData.sourceCode,
              sourceCodeDescription: searchData.sourceCodeDescription,
              dataBusinessName: searchData.dataBusinessName,
              dataFormat: searchData.dataFormat,
              dataSize: searchData.dataSize,
              description: searchData.description,
              functionalArea: values.functionalAreas !== 'Please Select One' ? values.functionalAreas : null,
              sourceTableName: values.sourceTable,
              crossReference: searchData.crossReference,
              associatedValidValues: tableData,
              endUserUpdate: 'true',
              noteSetVO: notesInput
            };

        onSave(editCriteria);
        setSpinnerLoader(true);
      }
    }
    setShowError({
      showSourceTableError: true,
      showFunctionalAreaError: true
    });
    setShowErrorText({
      showSourceTableErrorText: showSourceTableErrorText,
      showFunctionalAreaErrorText: showFunctionalAreaErrorText
    });
  };

  const rowDeleteAssociatedValidValue = data => {
    setRowAssociatedValidValueData({ ...rowAssociatedValidValueData, rowAssociatedValidValueData: data });
  };

  function associatedValidValueRowDeleteClick() {
    let temNewDialogData = [...tableData];
    if (rowAssociatedValidValueData.rowAssociatedValidValueData) {
      for (let i = 0; i < rowAssociatedValidValueData.rowAssociatedValidValueData.length; i++) {
        if (rowAssociatedValidValueData.rowAssociatedValidValueData[i] !== undefined) {
          temNewDialogData = temNewDialogData.filter(payment => payment.id !== rowAssociatedValidValueData.rowAssociatedValidValueData[i]);
        }
      }
    };
    updateTableData(temNewDialogData);
    setRowAssociatedValidValueData([]);
  }
  // add Notes
  let notesDataArray = [];

  const addNotes = (data) => {
    setAllowNavigation(true);
    console.log(data);
    data.usageTypeCode = data.usageTypeCode==='Please Select One' ? '': data.usageTypeCode;
    const noteText = data;
    notesDataArray = notesTableData;
    notesDataArray.push(noteText);
    setNotesTableData(notesDataArray);
    setNotesInput({ ...notesInput, notesList: notesDataArray });
  };

  return (

    <div>
      <Prompt
        when={allowNavigation}
        message={location => `Are you sure you want to go to ${location.pathname}`}
      />
      {spinnerLoader ? <Spinner /> : null}
      {/* {(backendMsg !== undefined && backendMsg.respcode === '01')
        ? <div className="alert alert-success custom-alert" >
          {backendMsg.respdesc
          }
        </div> : backendMsg !== undefined ? <div className="alert alert-danger custom-alert" >
          {backendMsg.respdesc ? backendMsg.respdesc : ValidValueConstants.ERROR_PROCESSING_REQUEST
          }</div> : null

      } */}
      <div className="tabs-container" ref={toPrintRef}>
        <SuccessMessage successMessages={successMessages} />
        <ErrorMessages errorMessages={errorMessages} />

        <div className="tab-header">
          <h1 className="tab-heading float-left">
            Edit Valid Value
          </h1>
          <div className="float-right mt-2 hide-on-print">
            <Button variant="outlined" color="primary" className='btn btn-success' onClick={masterSaveDataElement} disabled={!userInquiryPrivileges}>
              <i className="fa fa-check" aria-hidden="true"></i>
              Save
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setSpinnerLoader(true);  //in some components it may have different name
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setSpinnerLoader(false); //in some components it may have different name
                dispatch(setPrintLayout(false))
              }}
              trigger={() => (<Button className='btn btn-primary ml-1' >
                <i className="fa fa-print" aria-hidden="true"></i>
                Print
                              </Button>)}
              content={() => toPrintRef.current}
            />

            <Button variant="outlined" color="primary" className='btn btn-secondary ml-1'>
              <i className="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>

          </div>
          <div className="clearfix"></div>
        </div>
        <div className="tab-body">
          <div className='pb-2'>
            <form autoComplete='off'>
              <div className="form-wrapper">
                <div className='mui-custom-form input-md'>
                  <TextField
                    id="standard-dataelement"
                    required
                    label="Data Element Name"
                    disabled={true}
                    inputProps={{ maxLength: 30 }}
                    value={values.domainName}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </div>
                <div className="mui-custom-form input-md">
                  <TextField
                    id="standard-business-name"
                    fullWidth
                    required
                    label="Business Name"
                    disabled={true}
                    inputProps={{ maxLength: 40 }}
                    value={values.dataBusinessName}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </div>
                <div className='mui-custom-form override-width-45'>
                  <TextField
                    id='standard-descriptioon'
                    fullWidth
                    required
                    inputProps={{ maxLength: 320 }}
                    label='Description'
                    disabled={true}
                    value={values.description}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </div>
              </div>
              <div className="form-wrapper">
                <div className='mui-custom-form input-md'>
                  <TextField
                    id='standard-sourceTable'
                    fullWidth
                    label='Source Table'
                    required
                    disabled={!userInquiryPrivileges}
                    inputProps={{ maxLength: 30 }}
                    value={values.sourceTable}
                    onChange={handleChange('sourceTable')}
                    placeholder=""
                    error={showSourceTableError ? showSourceTableErrorText : null}
                    helperText={showSourceTableError ? showSourceTableErrorText : null}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </div>
                <div className='mui-custom-form with-select input-md '>
                  <TextField
                    id='standard-select-functionalAreas'
                    fullWidth
                    select
                    required
                    disabled={!userInquiryPrivileges}
                    label='Functional Area'
                    inputProps={{ maxLength: 5 }}
                    value={values.functionalAreas}
                    placeholder=""
                    error={showFunctionalAreaError ? showFunctionalAreaErrorText : null}
                    helperText={showFunctionalAreaError ? showFunctionalAreaErrorText : null}
                    InputLabelProps={{
                      shrink: true
                    }}
                    onChange={handleChange('functionalAreas')}
                  >
                    <MenuItem selected key="Please Select One" value="Please Select One">
                      Please Select One
                    </MenuItem>
                    {functionalAreaData.map((item, index) => (
                      <MenuItem key={index} value={item.code}>
                        {item.description}
                      </MenuItem>
                    ))}
                  </TextField>
                </div>
                <div className='mui-custom-form input-md'>
                  <TextField
                    id='standard-dataFormate'
                    fullWidth
                    required
                    label='Data Format'
                    select
                    disabled={true}
                    value={values.dataformat}
                    inputProps={{ maxLength: 2 }}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  >
                    {dataFormat ? dataFormat.map((item, index) => (
                      <MenuItem key={index} value={item.code}>
                        {item.description}
                      </MenuItem>
                    )) : null}
                  </TextField>
                </div>
                <div className='mui-custom-form input-md'>
                  <TextField
                    id='standard-datasize'
                    fullWidth
                    required
                    label='Data Size'
                    disabled={true}
                    inputProps={{ maxLength: 5 }}
                    value={values.dataSize}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </div>
              </div>
            </form>
            <div className='tab-panelbody'>
              <div className='tab-holder mb-3 mt-4'>
                <AppBar position='static' className="hide-on-print">
                  <Tabs value={value} onChange={handleChangeTabs} aria-label='simple tabs example'>
                    <Tab label='Cross-Reference' />
                    <Tab label='Associated Valid values' />
                    <Tab label='Notes' />
                  </Tabs>
                </AppBar>
                <TabPanel className={printLayout ? 'hide-on-screen' : ''} value={printLayout ? 0 : value} index={0}>
                  <div className="tab-holder mt-3">
                    <h4 className="hide-on-screen mt-2"><span className="badge badge-primary">Cross-Reference</span></h4>
                    <CrossReferenceTableComponent tableData={tableDataCrossReference} />
                  </div>
                </TabPanel>
                <TabPanel className={printLayout ? 'hide-on-screen' : ''} value={printLayout ? 1 : value} index={1}>
                  <div className="tab-holder" >
                    <div className="mui-custom-form no-margin dib show-voids mt-3">
                      <div className="sub-radio">
                        <FormControlLabel
                          control={<Checkbox color="primary" checked={showVoid} value={showVoid} onChange={handleShowVoidsChange} />}
                          label='Show Voids'
                        />
                      </div>
                    </div>
                    <div className="float-right my-3 hide-on-print">
                      <Button className="btn-text btn-transparent btn-padding-transparent" onClick={associatedValidValueRowDeleteClick}>
                        <i className="fa fa-trash" aria-hidden="true"></i>
                        Delete
                      </Button>
                      <Button variant='outlined' color='primary' className='float-right btn  btn-success ml-1' disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(values.sourceTable !== 'R_VV_TB' || values.validValueUpdate === 'No')} onClick={handleClickOpen}>
                        <i className="fa fa-plus" aria-hidden='true'></i>
                        Add Associated Valid Values
                      </Button>
                    </div>
                    <div className="clearfix"></div>
                    <Dialog className='custom-dialog dialog-520'
                      open={open}>
                      <DialogTitle id='customized-dialog-title' onClose={handleClose}>
                        Add Associated Valid Values
                      </DialogTitle>
                      <DialogContent dividers>
                        <form autoComplete='off'>
                          <div className="form-wrapper">
                            <div className='mui-custom-form input-md override-width-28'>
                              <TextField
                                id='standard-code'
                                fullWidth
                                label='Code'
                                required
                                disabled={!userInquiryPrivileges}
                                value={dataElement.code}
                                inputProps={{ maxLength: 15 }}
                                onChange={handleChangeDataElement('code')}
                                placeholder=""
                                helperText={showCodeError ? showCodeErrorText : null}
                                error={showCodeError ? showCodeErrorText : null}
                                InputLabelProps={{
                                  shrink: true
                                }}
                              />
                            </div>
                            <div className='mui-custom-form input-md override-width-28'>
                              <TextField
                                id='standard-constantText'
                                label='Constant Text'
                                required
                                disabled={!userInquiryPrivileges}
                                inputProps={{ maxLength: 50 }}
                                value={dataElement.constantText}
                                onChange={handleChangeDataElement('constantText')}
                                placeholder=""
                                helperText={showConstanttError ? showConstanttErrorText : null}
                                error={showConstanttError ? showConstanttErrorText : null}
                                InputLabelProps={{
                                  shrink: true
                                }}
                              />
                            </div>
                            <div className='mui-custom-form input-md override-width-28'>
                              <TextField
                                id='standard-shortDescription'
                                label='Short Description'
                                inputProps={{ maxLength: 10 }}
                                helperText={showShortDescriptionError ? showShortDescriptionErrorText : null}
                                error={showShortDescriptionError ? showShortDescriptionErrorText : null}
                                required
                                disabled={!userInquiryPrivileges}
                                value={dataElement.shortDescription}
                                onChange={handleChangeDataElement('shortDescription')}
                                placeholder=""
                                InputLabelProps={{
                                  shrink: true
                                }}
                              />
                            </div>
                          </div>

                          <div className="form-wrapper">
                            <div className='mui-custom-form input-md override-width-95'>
                              <TextField
                                id='standard-longDescription'
                                label='Long Description'
                                value={dataElement.longDescription}
                                helperText={showLongDescriptionError ? showLongDescriptionErrorText : null}
                                error={showLongDescriptionError ? showLongDescriptionErrorText : null}
                                required
                                disabled={!userInquiryPrivileges}
                                inputProps={{ maxLength: 40 }}
                                onChange={handleChangeDataElement('longDescription')}
                                placeholder=""
                                InputLabelProps={{
                                  shrink: true
                                }}
                              />
                            </div>
                          </div>
                        </form>
                      </DialogContent>
                      <DialogActions>
                        <Button variant='outlined' color='primary' className='btn btn-success ml-1'
                          onClick={() => handleAdd()} disabled={!userInquiryPrivileges}>
                          <i className="fa fa-plus" aria-hidden="true"></i>Add
                        </Button>
                        <Button variant='outlined' color='primary' className='bt-reset btn-transparent'
                          onClick={() => handleReset(dataElement)} disabled={!userInquiryPrivileges}>
                          <i className="fa fa-undo" aria-hidden="true"></i>        Reset
                        </Button>
                      </DialogActions>
                    </Dialog>
                    <div className="table-no-wrap">
                      <h4 className="hide-on-screen mt-2"><span className="badge badge-primary">Associated valid Values</span></h4>

                      <AssociatedValuesTableComponent
                        fixedTable
                        flag={flag}
                        tableData={tableData}
                        filteredData={filteredData}
                        newRecord={newRecord}
                        searchData={searchData}
                        updateTableData={updateTableData}
                        values={values}
                        showVoid={showVoid}
                        rowDeleteAssociatedValidValue={rowDeleteAssociatedValidValue} />
                    </div>
                  </div>
                </TabPanel>
                <TabPanel className={printLayout ? 'hide-on-screen' : ''} value={printLayout ? 2 : value} index={2}>
                  <div className="tab-holder my-3">
                    <Notes addNotes = {addNotes}
                      notesTableData = {notesTableData}
                      noteSetListInput = {noteSetListInput}
                      setNoteSetListInput = {setNoteSetListInput}
                      usageTypeCodeData= {usageTypeCodeData}
                      editNoteData = {editNoteData}
                      setEditNoteData = {setEditNoteData}/>
                  </div>
                </TabPanel>
              </div>
              <Footer print />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
