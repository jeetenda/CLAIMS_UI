/* eslint-disable no-unused-vars */
import React from 'react';
import TextField from '@material-ui/core/TextField';
import Bootstrap, { Button } from 'react-bootstrap';
import * as ValidValueConstants from './ValidValueConstants';
import Dialog from '@material-ui/core/Dialog';
import moment from 'moment';
import TableComponent from '../../../../SharedModules/Table/Table';
import {
  DialogTitle,
  DialogContent,
  DialogActions
} from '../../../../SharedModules/Dialog/DialogUtilities';
import { useSelector } from 'react-redux';
import { getUTCTimeStamp } from '../../../../SharedModules/DateUtilities/DateUtilities';

const headCells = [
  {
    id: 'code',
    numeric: false,
    disablePadding: true,
    label: 'Code',
     width: "12%",
    // width: 50,
    enableHyperLink: true
  },
  {
    id: 'shortDescription',
    numeric: false,
    disablePadding: false,
    label: 'Short Description',
     width: "14%",
    // width: 70
  },
  {
    id: 'longDescription',
    numeric: false,
    disablePadding: false,
    label: 'Long Description',
     width: "25%"
     // width: 90
    
  },
  {
    id: 'constantText',
    numeric: false,
    disablePadding: false,
    label: 'Constant Text',
    //width: 110,
       width: "34%",
      //isText: true
  },
  {
    id: 'voidDate',
    numeric: false,
    disablePadding: false,
    label: 'Void Date',
    isDate: true,
    //width: 80
     width: "15%"
  }
];

export default function AssociatedValueTableComponent (props) {
  const logInUserID = useSelector(state => state.sharedState.logInUserID);
  const [rowData, setRowData] = React.useState(0);
  const validvaluecons = ValidValueConstants;
  let errorMessagesArray = [];
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [
    {
      showCodeError,
      showConstanttError,
      showShortDescriptionError,
      showLongDescriptionError,
      showDateOverlappingError
    },
    setShowError
  ] = React.useState(false);
  const [
    {
      showCodeErrorText,
      showConstanttErrorText,
      showShortDescriptionErrorText,
      showLongDescriptionErrorText
    },
    setShowErrorText
  ] = React.useState('');
  const [associatedTableData1, setassociatedTableData] = React.useState(
    props.tableData
  );
  const userInquiryPrivileges = useSelector(
    state => state.sharedState.userInquiryPrivileges.applicationUser
  );
  console.log(props);
  const [currentRow, setCurrentRow] = React.useState({
    code: '',
    shortDescription: '',
    longDescription: '',
    voidDate: null,
    constantText: '',
    associatedselectedOption: 'No'
  });
  React.useEffect(() => {
    console.log(currentRow);
  }, [currentRow]);
  const [open, setOpen] = React.useState(false);
  const handleClickOpen = row => event => {
    console.log('handleClickOpen');
    if (props.values.sourceTable === 'R_VV_TB') {
      setRowData(row);
      setOpen(true);
      setDataElement({
        id: row.id,
        code: row.code,
        shortDescription: row.shortDescription,
        longDescription: row.longDescription,
        voidDate: row.voidDate,
        constantText: row.constantText,
        associatedselectedOption: row.voidDate != null ? 'Yes' : 'No'
      });
      setCurrentRow({ ...row });
    }
    seterrorMessages([]);
    setShowErrorText({
      showCodeErrorText: '',
      showConstanttErrorText: '',
      showShortDescriptionErrorText: '',
      showLongDescriptionErrorText: ''
    });
    setShowError({
      showCodeError: false,
      showConstanttError: false,
      showShortDescriptionError: false,
      showLongDescriptionError: false,
      showDateOverlappingError: false
    });
  };

  const handleReset = row => {
    errorMessagesArray = [];
    seterrorMessages([]);
    setShowErrorText({
      showCodeErrorText: '',
      showConstanttErrorText: '',
      showShortDescriptionErrorText: '',
      showLongDescriptionErrorText: ''
    });
    setShowError({
      showCodeError: false,
      showConstanttError: false,
      showShortDescriptionError: false,
      showLongDescriptionError: false,
      showDateOverlappingError: false
    });
    setDataElement({
      code: row.code ? row.code : '',
      shortDescription: row.shortDescription,
      longDescription: row.longDescription,
      voidDate: row.voidDate,
      associatedselectedOption: row.voidDate != null ? 'Yes' : 'No'
    });
    // setOpen(false);
  };
  const handleClose = () => {
    setOpen(false);
  };

  const handleOpen = row => {
    setDataElement({
      id: row.id,
      code: row.code,
      shortDescription: row.shortDescription,
      longDescription: row.longDescription,
      voidDate: row.voidDate
    });
    setOpen(true);
  };

  const [dataElement, setDataElement] = React.useState({
    code: '',
    shortDescription: '',
    longDescription: '',
    voidDate: '',
    constantText: '',
    associatedselectedOption: 'No',
    addedAuditTimeStamp: '',
    addedAuditUserID: '',
    auditKeyListFiltered: '',
    auditTimeStamp: '',
    auditUserID: '',
    dbRecord: '',
    showVoidRecord: '',
    showVoids: '',
    sortColumn: '',
    valueStatus: '',
    versionNo: '',
    voidIndicator: ''
  });

  React.useEffect(() => {
    const newRecord = props.newRecord;
    // if (newRecord !== {
    //   associatedselectedOption: "",
    //   addedAuditTimeStamp: "",
    //   addedAuditUserID: "",
    //   auditKeyListFiltered: "",
    //   auditTimeStamp: "",
    //   auditUserID: "",
    //   code: "",
    //   constantText: "",
    //   dbRecord: "",
    //   longDescription: "",
    //   shortDescription: "",
    //   showVoidRecord: "",
    //   showVoids: "",
    //   sortColumn: "",
    //   valueStatus: "",
    //   versionNo: 0,
    //   voidDate: null,
    //   voidIndicator: ""
    // }) {
    // setFilteredData([...filteredData, newRecord])
    console.log('new', newRecord);
    // }
  }, [props.newRecord]);

  const handleEditAssociated = () => {
    errorMessagesArray = [];
    seterrorMessages([]);
    let count = 0;
    var showCodeError;
    var showConstanttError;
    var showShortDescriptionError;
    var showLongDescriptionError;
    var showDateOverlappingError = false;
    var showCodeErrorText;
    var showConstanttErrorText;
    var showShortDescriptionErrorText;
    var showLongDescriptionErrorText = '';

    if (!dataElement.code.trim()) {
      showCodeError = true;
      errorMessagesArray.push(validvaluecons.CODE_DATASIZE_REQUIRED);
      showCodeErrorText = validvaluecons.CODE_DATASIZE_REQUIRED;
      seterrorMessages(errorMessagesArray);
      setOpen(true);
    }
    if (
      dataElement.code.trim() &&
      dataElement.code.trim().length > props.searchData.dataSize
    ) {
      showCodeError = true;
      errorMessagesArray.push(validvaluecons.CODE_DATASIZE_ERROR);
      showCodeErrorText = validvaluecons.CODE_DATASIZE_ERROR;
      seterrorMessages(errorMessagesArray);
      setOpen(true);
    }
    const associatedTableData = props.tableData;
    if (dataElement.code.trim() && associatedTableData.length > 0) {
      associatedTableData.map((value, index) => {
        if (
          value.constantText === dataElement.constantText &&
          value.constantText !== rowData.constantText
        ) {
          count = count + 1;
          return false;
        }
      });
      if (count > 0) {
        showCodeError = true;
        errorMessagesArray.push(validvaluecons.VALID_VALUE_CODE_OVERLAPPING);
        showCodeErrorText = validvaluecons.VALID_VALUE_CODE_OVERLAPPING;
        seterrorMessages(errorMessagesArray);
        setOpen(true);
      }
    }
    console.log(dataElement.code);
    if (!dataElement.shortDescription) {
      showShortDescriptionError = true;
      errorMessagesArray.push(validvaluecons.SHORT_DESCRIPTION_REQUIRED);
      showShortDescriptionErrorText = validvaluecons.SHORT_DESCRIPTION_REQUIRED;
      seterrorMessages(errorMessagesArray);
      setOpen(true);
    }
    if (!dataElement.longDescription) {
      showLongDescriptionError = true;
      errorMessagesArray.push(validvaluecons.LONG_DESCRIPTION_REQUIRED);
      showLongDescriptionErrorText = validvaluecons.LONG_DESCRIPTION_REQUIRED;
      seterrorMessages(errorMessagesArray);
      setOpen(true);
    } else if (errorMessagesArray.length === 0) {
      console.log(currentRow);
      const dataElementdata = {
        auditUserID: logInUserID,
        auditTimeStamp: getUTCTimeStamp(),
        addedAuditUserID: currentRow ? (currentRow.addedAuditUserID ? currentRow.addedAuditUserID : logInUserID) : logInUserID,
        addedAuditTimeStamp: currentRow ? (currentRow.addedAuditTimeStamp ? currentRow.addedAuditTimeStamp : getUTCTimeStamp()) : getUTCTimeStamp(),

        code: dataElement.code,
        shortDescription: dataElement.shortDescription,
        longDescription: dataElement.longDescription,
        voidDate: currentRow.voidDate,
        constantText: currentRow.constantText,
        // associatedselectedOption: "No",
        auditKeyList: [],
        auditKeyListFiltered: currentRow.auditKeyListFiltered,
        dbRecord: currentRow.dbRecord,
        showVoidRecord: currentRow.showVoidRecord,
        showVoids: dataElement.associatedselectedOption === 'Yes',
        sortColumn: currentRow.sortColumn,
        valueStatus: currentRow.valueStatus,
        versionNo: currentRow.versionNo,
        voidIndicator: currentRow.voidIndicator
      };
      setDataElement(dataElementdata);
      console.log(dataElement, 'Dta', dataElementdata);
      for (var i in associatedTableData) {
        if (
          associatedTableData[i].constantText === dataElementdata.constantText
        ) {
          associatedTableData[i] = dataElementdata;
          if (dataElementdata.showVoids) {
            associatedTableData[i].voidDate = moment(new Date()).format('MM/DD/YYYY');
          }
          break; // Stop this loop, we found it!
        }
      }

      console.log(associatedTableData);
      props.updateTableData(associatedTableData);
      setOpen(false);
    }
    setShowError({
      showCodeError: showCodeError,
      showConstanttError: showConstanttError,
      showShortDescriptionError: showShortDescriptionError,
      showLongDescriptionError: showLongDescriptionError,
      showDateOverlappingError: showDateOverlappingError
    });

    setShowErrorText({
      showCodeErrorText: showCodeErrorText,
      showConstanttErrorText: showConstanttErrorText,
      showShortDescriptionErrorText: showShortDescriptionErrorText,
      showLongDescriptionErrorText: showLongDescriptionErrorText
    });
  };
  const handleChangeDataElement = name => event => {
    if (name === 'code') {
      setDataElement({
        ...dataElement,
        [name]: event.target.value.toUpperCase()
      });
    } else {
      setDataElement({ ...dataElement, [name]: event.target.value });
    }
  };

  return (
    <div>
      {props.showVoid ? (
        <TableComponent
          fixedTable
          headCells={headCells}
          tableData={props.tableData ? props.tableData : []}
          onTableRowClick={handleClickOpen}
          defaultSortColumn={headCells[0].id}
          isSearch={false}
          onTableRowDelete={props.rowDeleteAssociatedValidValue}
        />
      ) : (
        <TableComponent
           fixedTable
          headCells={headCells}
          tableData={props.filteredData ? props.filteredData : []}
          onTableRowClick={handleClickOpen}
          defaultSortColumn={headCells[0].id}
          isSearch={false}
          onTableRowDelete={props.rowDeleteAssociatedValidValue}
        />
      )}
      <Dialog className="custom-dialog dialog-520" open={open}>
        <DialogTitle id="customized-dialog-title" onClose={handleClose}>
          Edit Associated Valid Values
        </DialogTitle>
        <DialogContent dividers>
          <form autoComplete="off">
            <div className="form-wrapper">
              <div className="mui-custom-form input-md override-width-45">
                <TextField
                  id="standard-code"
                  fullWidth
                  label="Code"
                  inputProps={{ maxLength: 15 }}
                  required
                  value={dataElement.code}
                  helperText={showCodeError ? showCodeErrorText : null}
                  error={showCodeError ? showCodeErrorText : null}
                  onChange={handleChangeDataElement('code')}
                  InputLabelProps={{
                    shrink: true
                  }}
                  disabled={
                    !userInquiryPrivileges
                      ? !userInquiryPrivileges
                      : currentRow.voidDate != null
                  }
                />
              </div>
              {currentRow.isNewRow !== undefined &&
              currentRow.isNewRow ? null : (
                  <div className="mui-custom-form">
                    <label className="MuiFormLabel-root small-label">Void</label>
                    <div className="sub-radio">
                      <input
                        type="radio"
                        disabled={
                          !userInquiryPrivileges
                            ? !userInquiryPrivileges
                            : currentRow.voidDate != null
                        }
                        name="associatedselectedOption"
                        value="Yes"
                        id="associatedselectedOptionId"
                        checked={dataElement.associatedselectedOption === 'Yes'}
                        onChange={handleChangeDataElement(
                          'associatedselectedOption'
                        )}
                      />
                      <label
                        className="text-black"
                        for="associatedselectedOptionId"
                      >
                      Yes
                      </label>
                      <input
                        type="radio"
                        disabled={
                          !userInquiryPrivileges
                            ? !userInquiryPrivileges
                            : currentRow.voidDate != null
                        }
                        name="associatedselectedOption"
                        value="No"
                        id="associatedselectedNoId"
                        checked={dataElement.associatedselectedOption === 'No'}
                        onChange={handleChangeDataElement(
                          'associatedselectedOption'
                        )}
                        className="ml-2"
                      />
                      <label className="text-black" for="associatedselectedNoId">
                      No
                      </label>
                    </div>
                  </div>
                )}
            </div>
            <div className="form-wrapper">
              <div className="mui-custom-form input-md override-width-45">
                <TextField
                  disabled={currentRow.voidDate != null}
                  id="standard-constantText"
                  fullWidth
                  label="Constant Text"
                  disabled={true}
                  value={dataElement.constantText}
                  inputProps={{ maxLength: 50 }}
                  // error={!dataElement.constantText}
                  onChange={handleChangeDataElement('constantText')}
                  placeholder=""
                  InputLabelProps={{
                    shrink: true
                  }}
                />
              </div>
              <div className="mui-custom-form input-md override-width-45">
                <TextField
                  disabled={
                    !userInquiryPrivileges
                      ? !userInquiryPrivileges
                      : currentRow.voidDate != null
                  }
                  id="standard-shortDescription"
                  fullWidth
                  label="Short Description"
                  inputProps={{ maxLength: 10 }}
                  value={dataElement.shortDescription}
                  helperText={
                    showShortDescriptionError
                      ? showShortDescriptionErrorText
                      : null
                  }
                  error={
                    showShortDescriptionError
                      ? showShortDescriptionErrorText
                      : null
                  }
                  required
                  onChange={handleChangeDataElement('shortDescription')}
                  placeholder=""
                  InputLabelProps={{
                    shrink: true
                  }}
                />
              </div>
            </div>
            <div className="form-wrapper">
              <div className="mui-custom-form input-md override-width-95">
                <TextField
                  disabled={
                    !userInquiryPrivileges
                      ? !userInquiryPrivileges
                      : currentRow.voidDate != null
                  }
                  id="standard-longDescription"
                  label="Long Description"
                  value={dataElement.longDescription}
                  inputProps={{ maxLength: 40 }}
                  helperText={
                    showLongDescriptionError
                      ? showLongDescriptionErrorText
                      : null
                  }
                  error={
                    showLongDescriptionError
                      ? showLongDescriptionErrorText
                      : null
                  }
                  required
                  onChange={handleChangeDataElement('longDescription')}
                  placeholder=""
                  InputLabelProps={{
                    shrink: true
                  }}
                />
              </div>
            </div>
          </form>
        </DialogContent>
        <DialogActions>
          <Button
            variant="outlined"
            color="primary"
            className="btn btn-primary ml-1"
            onClick={() => handleEditAssociated(dataElement, rowData)}
            disabled={
              !userInquiryPrivileges
                ? !userInquiryPrivileges
                : currentRow.voidDate != null
            }
          >
            Update
          </Button>
          <Button
            variant="outlined"
            color="primary"
            className="bt-reset btn-transparent ml-1"
            onClick={() => handleReset(rowData)}
            disabled={
              !userInquiryPrivileges
                ? !userInquiryPrivileges
                : currentRow.voidDate != null
            }
          >
            <i class="fa fa-undo" aria-hidden="true"></i>
            Reset
          </Button>
        </DialogActions>
      </Dialog>
    </div>
  );
}
