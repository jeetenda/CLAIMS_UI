/* eslint-disable no-unused-vars */
import React from 'react';
import * as ValidValueConstants from './ValidValueConstants';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import "./ValidValueSearchForm.css"

export default function ValidValueSearchForm (props) {
  return (
    <form autoComplete="off">
      <div className="form-wrapper">
        {/*<div className="mui-custom-form ">
          <TextField
            id="standard-code"
            label="Code"
            fullWidth
            value={props.values.code || ""}
            onChange={props.handleChanges('code')}
            placeholder=""
            inputProps={{ maxLength: 15 }}
            InputLabelProps={{
              shrink: true
            }} />
          </div>*/}
        <div className="mui-custom-form with-select" // style={{ marginLeft: '30px' }}
        >
          <TextField
            id="standard-select-functionalArea"
            // fullWidth
            select
            required = {!!props.values.code}
            label="Functional Area"
            value={props.values.functionalArea || ""}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('functionalArea')}
            placeholder=""
            helperText={props.errors.showFunctionalAreaError ? ValidValueConstants.FUNCTIONAL_AREA_REQUIRED : null}
            InputLabelProps={{
              shrink: true
            }}
            error={props.errors.showFunctionalAreaError ? ValidValueConstants.FUNCTIONAL_AREA_REQUIRED : null}>
            <MenuItem selected key="Please Select One" value="Please Select One">
          Please Select One 
            </MenuItem>
            {props.functionalArea ? props.functionalArea.map((item, index) => (
              <MenuItem key={index} value={item.code}>
                {item.description}
              </MenuItem>
            )) : null}
          </TextField>
        </div>
        <div className="mui-custom-form" // style={{ marginLeft: '30px' }}
        >
          <TextField
            id="standard-businessName"
            fullWidth
            label="Business Name"
            value={props.values.businessName || ""}
            inputProps={{ maxLength: 40 }}
            onChange={props.handleChanges('businessName')}
            placeholder=""
            helperText={props.errors.showbusinessNameError ? ValidValueConstants.BUSINESS_NAME_ERROR : null}
            InputLabelProps={{
              shrink: true
            }}
            error={props.errors.showbusinessNameError ? ValidValueConstants.BUSINESS_NAME_ERROR : null}
          />
        
          <div className="sub-radio sub-radios">
            <input type="radio"
              value="StartsWith"
              id="businessNameStartId"
              checked={props.values.busNameStartsOrContains === 'StartsWith'}
              // inputProps={{ maxLength: 1 }}
              onChange={props.handleChanges('busNameStartsOrContains')}
            /><label className="text-black" htmlFor="businessNameStartId">Starts With</label>
            <input type="radio"
              value="Contains"
              id="businessNameContainsId"
              // inputProps={{ maxLength: 1 }}
              checked={props.values.busNameStartsOrContains === 'Contains'}
              onChange={props.handleChanges('busNameStartsOrContains')}
              className="ml-2"
            /><label htmlFor="businessNameContainsId" className="text-black">Contains</label>
          </div>
        </div>
        <div className="mui-custom-form" // style={{ marginLeft: '26px' }}
        >
          <TextField
            id="standard-dataElementName"
            fullWidth
            label="Data Element Name"
            value={props.values.dataElementName || ""}
            inputProps={{ maxLength: 15 }}
            onChange={props.handleChanges('dataElementName')}
            placeholder=""
            helperText={props.errors.showdataElementNameError ? ValidValueConstants.DATA_ELEMENT_NAME_ERROR : null}
            InputLabelProps={{
              shrink: true
            }}
            error={props.errors.showdataElementNameError ? ValidValueConstants.DATA_ELEMENT_NAME_ERROR : null}
          />
          <div className="sub-radio sub-radios">
            
            <input type="radio"
              value="StartsWith"
              id="dataElementNameStartsId"
              // inputProps={{ maxLength: 1 }}
              checked={props.values.dataEleNameStartsOrContains === 'StartsWith'}
              onChange={props.handleChanges('dataEleNameStartsOrContains')}
            /><label className="text-black" htmlFor="dataElementNameStartsId">Starts With</label>
            <input type="radio"
              value="Contains"
              id="dataElementNameContainsId"
              // inputProps={{ maxLength: 1 }}
              checked={props.values.dataEleNameStartsOrContains === 'Contains'}
              onChange={props.handleChanges('dataEleNameStartsOrContains')}
              className="ml-2"
            /><label className="text-black" htmlFor="dataElementNameContainsId">Contains</label>
          </div>
        </div>
      </div>
      <div className="form-wrapper">
        <div className="mui-custom-form">
          <TextField
            id="standard-valueShortDescription"
            fullWidth
            label="Value Short Description"
            value={props.values.valueShortDescription || ""}
            inputProps={{ maxLength: 20 }}
            onChange={props.handleChanges('valueShortDescription')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}/>
        </div>
        <div className="mui-custom-form" // style={{ marginLeft: '30px' }}
        >
          <TextField
            id="standard-tableName"
            fullWidth
            label="Cross-Reference Table Name"
            value={props.values.crossReferenceTableName || ""}
            inputProps={{ maxLength: 1}}
            onChange={props.handleChanges('crossReferenceTableName')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}/>
        </div>
        <div className="mui-custom-form"
        >
          <TextField
            id="standard-columnName"
            fullWidth
            label="Cross-Reference Column Name"
            value={props.values.crossReferenceColumnName || ""}
            inputProps={{ maxLength: 10 }}
            onChange={props.handleChanges('crossReferenceColumnName')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}/>
        </div>

      </div>
      <div className="float-right mr-3 mb-2">
        <Button className='btn btn-primary'
          onClick={props.searchCheck}>
          <i className="fa fa-search" aria-hidden="true"></i>
             Search </Button>
        <Button className='bt-reset btn-transparent  ml-1'
          onClick={props.resetTable}>
          <i className="fa fa-undo" aria-hidden="true"></i>
           Reset </Button>

      </div>
      <div className="clearfix"></div>
    </form>
  );
};
