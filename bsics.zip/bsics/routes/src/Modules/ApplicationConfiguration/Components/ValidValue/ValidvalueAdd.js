import React, { Component, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Bootstrap, { Button } from 'react-bootstrap'
import ValidValueAddTableComponent from './ValidValueAddTableComponent';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Box from '@material-ui/core/Box';
import { withStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import ValidValidAssociatedValuesTable from './ValidValidAssociatedValuesTable';


let newData = [];
let id = 0;
const systemPayee = [
    {
        value: '',
        label: 'Select',
    },
    {
        value: 'Saab',
        label: 'Saab',
    },
    {
        value: 'Opel',
        label: 'Opel',
    },
    {
        value: 'Audi',
        label: 'Audi',
    },
];
const lobs = [
    {
        value: '',
        label: 'Select',
    },
    {
        value: 'MED',
        label: 'MED',
    },
    {
        value: 'Saab',
        label: 'Saab',
    },
    {
        value: 'Opel',
        label: 'Opel',
    },
    {
        value: 'Audi',
        label: 'Audi',
    },
];
const payee = [
    {
        value: '',
        label: 'Select',
    },
    {
        value: 'Provider',
        label: 'Provider',
    },
    {
        value: 'Saab',
        label: 'Saab',
    },
    {
        value: 'Opel',
        label: 'Opel',
    },
    {
        value: 'Audi',
        label: 'Audi',
    },
];
const payeeIdCode = [
    {
        value: '',
        label: 'Select',
    },
    {
        value: 'NPI',
        label: 'NPI',
    },
    {
        value: 'Saab',
        label: 'Saab',
    },
    {
        value: 'Opel',
        label: 'Opel',
    },
    {
        value: 'Audi',
        label: 'Audi',
    },
];
const useStyles = makeStyles(theme => ({
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    textField: {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
        width: 200,
        textAlign: "left"
    },
    dense: {
        marginTop: 19,
    },
    menu: {
        width: 200,
    },
}));

const styles = theme => ({
    root: {
        margin: 0,
        padding: theme.spacing(2),
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: theme.palette.grey[500],
    },
});

const DialogTitle = withStyles(styles)(props => {
    const { children, classes, onClose } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles(theme => ({
    root: {
        padding: theme.spacing(2),
    },
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
    root: {
        margin: 0,
        padding: theme.spacing(1),
    },
}))(MuiDialogActions);


function TabPanel(props) {
    const { children, value, index, ...other } = props;

    return (
        <Typography
            component="div"
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}
            
            {...other}
        >
            <Box p={3}>{children}</Box>
        </Typography>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};
export default function ValidValueAdd(props) {

    const [data, setData] = React.useState(
        [{ id: 1, businessName: 'Tejaswi', dataElementName: 'Chava', valueShortDescription: 'C5102896', columnName: '3', functionalArea: 'React' },
        { id: 2, businessName: 'Sai Purnima', dataElementName: 'Kandikattu', valueShortDescription: 'C5104422', columnName: '2.9', functionalArea: 'React' },
        { id: 3, businessName: 'Kirti', dataElementName: 'Saraogi', valueShortDescription: 'C5104415', columnName: '6', functionalArea: 'Angular' },
        { id: 4, businessName: 'Alfia', dataElementName: 'sadia', valueShortDescription: 'C5102897', columnName: '1', functionalArea: 'Angular' },
        { id: 5, businessName: 'Priti', dataElementName: 'Tripathy', valueShortDescription: 'C5081726', columnName: '7.5', functionalArea: 'React' },
        { id: 6, businessName: 'Krishna Vinay', dataElementName: 'Kalaga', valueShortDescription: 'C5102897', columnName: '5', functionalArea: 'React' },
        { id: 7, businessName: 'Bharat', dataElementName: 'Reddy', valueShortDescription: 'C5081728', columnName: '7.5', functionalArea: 'React' }
        ]
      )
    const [showForm, setShowForm] = React.useState(true);
    const [color, setColor] = React.useState('');
    const classes = useStyles();
    const [tableData, setTableData] = React.useState();
    const [id, setId] = React.useState(0);
    
    const [openCrossReference, setOpenCrossReference] = React.useState(false);

    const [inputValues, setInputValues] = React.useState({
        code: '',
        shortDescription: '',
        longDescription: '',
        constantText: ''

    });

    const handleCloseCrossReference = () => {
        setOpenCrossReference(false)


    }


    const [values, setValues] = React.useState({
        lob: '',
        payee: '',
        payeeIdCode: '',
        id: '',
        name: '',
        systemPayeeId: '',
        multiline: 'Controlled',
        systemPayee: '',
        memberName: '',
    });
    const [value, setValue] = React.useState(0);
    const [open, setOpen] = React.useState(false);
    const [dataElement, setDataElement] = React.useState({
        id: 0,
        dataElementName: '',
        businessName: '',
        description: ''

    })
    const columns = [
        {
            name: 'Column Name',
            selector: 'dataElementName',
            sortable: true,
            // cell: row => <div><div style={{ fontWeight: "bold" ,color:"black"}}>{row.title}</div>{row.summary}</div>,

        },
        {
            name: 'Column Business Name',
            selector: 'businessName',
            sortable: true,
        },
        {
            name: 'Description',
            selector: 'description',
            sortable: true,
        },
    ]


  
    const handleClose = () => {
        setOpen(false);
        setId(id + 1)
        dataElement.id = id
        newData.push(dataElement);
        setTableData(newData);
        console.log(tableData)
    };




    const handleChangeTabs = (event, newValue) => {
        setValue(newValue);
    };
    const handleChange = name => event => {
        setValues({ [name]: event.target.value });
    };

    const handleChangeDataElement = name => event => {
        setDataElement({ ...dataElement, [name]: event.target.value });
    }
    const handleChangeInputValues = name => event => {
        setInputValues({ [name]: event.target.value });
    };
    const handleOpenCrossReferenceDialog = () => {
        setOpen(true);
        setDataElement({
            dataElementName: '',
            businessName: '',
            description: ''

        })
    }
    const handleClickOpen = () => {

        setAllowNavigation(true);
        setOpenCrossReference(true);
        setInputValues({
            code: '',
            shortDescription: '',
            longDescription: '',
            constatntText: ''

        })
    };



    const resetTable = () => {
        setValues(
            {
                lob: '',
                payee: '',
                payeeIdCode: '',
                id: '',
                name: '',
                systemPayeeId: '',
                multiline: 'Controlled',
                systemPayee: '',
                memberName: '',
            }
        )
    }

    return (
        <div>


            <div className="tabs-container">
                <div className="tab-header">
                    <div className="tab-heading float-left">
                        Data Element/Valid Values
                    </div>
                    <div className="float-right mr-3 mt-1 pt-1">
                        {/* <Button variant="outlined" color="primary" className='btn btn-primary ml-1'
                        //   onClick={() => resetTable()}
                        >
                            Reset
                </Button>
                        <Button variant="outlined" color="primary" className='btn btn-primary'
                        //   onClick={() => setShowTable(!showTable)}
                        >
                            Save
                </Button> */}
                    </div>
                    <div className="clearfix"></div>
                </div>
               <div className="tab-holder my-3">

                    <AppBar position="static">
                        <Tabs value={value} onChange={handleChangeTabs} aria-label="simple tabs example">
                            <Tab label="Cross-Reference" />
                            <Tab label="Associated Valid values" />
                            {/* <Tab label="Refund Information" />
                            <Tab label="History" /> */}
                        </Tabs>
                    </AppBar>
                    {/* <TabPanel index={-1} value={value}></TabPanel> */}

                    <TabPanel value={value} index={0}>
                        <Button variant="outlined" color="primary" className='btn mb-2 btn-primary ml-1'>Delete</Button>
                        <Button variant="outlined" color="primary" className='btn mb-2 btn-primary'
                            onClick={handleOpenCrossReferenceDialog}
                        >Add</Button>
                        <div className="clearfix"></div>
                        <ValidValueAddTableComponent crossReftableData = {data}/>
                    </TabPanel>
                    <TabPanel value={value} index={1}>
                            <Button variant="outlined" color="primary" className="btn mb-2 btn-primary ml-1" onClick={handleClickOpen }>
                                Add Associated Valid Values
                            </Button>
                        <div className="clearfix"></div>
                       
                        <ValidValidAssociatedValuesTable crossReftableData = {data}/>

                        {/* <DataTable
                            title=""
                            columns={columns}
                            data={tableData}
                            className
                            ="pt-2"
                        // pagination = {true}
                        // paginationPerPage = {5}
                        // paginationRowsPerPageOptions = {[5,10, 15, 20, 25, 30]}
                        /> */}

                    </TabPanel>
                    <Dialog className="custom-dialog" onClose={handleClose} open={open}>
                            <DialogTitle id="customized-dialog-title" onClose={handleClose}>
                                Data Element
                            </DialogTitle>
                            <DialogContent dividers>
                                <TextField
                                    id="data-element-name"
                                    label="Data Element Name"
                                    className={classes.textField}
                                    value={dataElement.dataElementName}
                                    onChange={handleChangeDataElement('dataElementName')}
                                />
                                <TextField
                                    id="business-name"
                                    label="Business Name"
                                    className={classes.textField}
                                    value={dataElement.businessName}
                                    onChange={handleChangeDataElement('businessName')}
                                />
                                <TextField
                                    id="Description"
                                    label="Description"
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={dataElement.description}
                                    onChange={handleChangeDataElement('description')} />
                            </DialogContent>
                            <DialogActions>
                                <Button variant="outlined" color="primary" className='btn btn-primary'>
                                    Reset
                </Button>
                            </DialogActions>
                        </Dialog>

                        <Dialog className="custom-dialog" onClose={handleCloseCrossReference} open={openCrossReference}>
                            <DialogTitle id="customized-dialog-title" onClose={handleCloseCrossReference}>
                                Cross Reference
                            </DialogTitle>
                            <DialogContent dividers>
                                <TextField
                                    id="code"
                                    label="Code"
                                    className={classes.textField}
                                    value={inputValues.code}
                                    onChange={handleChangeInputValues('code')}
                                />
                                <TextField
                                    id="short-description"
                                    label="Short Description"
                                    className={classes.textField}
                                    value={inputValues.shortDescription}
                                    onChange={handleChangeInputValues('shortDescription')}
                                />
                                <TextField
                                    id="constant-text"
                                    label="Constant Text"
                                    className={classes.textField}
                                    value={inputValues.constantText}
                                    onChange={handleChangeInputValues('constantText')}
                                />
                                <TextField
                                    id="long-description"
                                    label="Long Description"
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={inputValues.longDescription}
                                    onChange={handleChangeInputValues('longDescription')} />
                            </DialogContent>

                            <DialogActions>

                                <Button variant="outlined" color="primary" className='btn btn-primary'>
                                    Reset
                </Button>

                            </DialogActions>
                        </Dialog>

                </div>
            </div>
        </div>
    )
}