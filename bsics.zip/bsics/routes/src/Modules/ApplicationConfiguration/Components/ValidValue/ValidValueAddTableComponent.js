import React, {Component, useEffect} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import TextField from '@material-ui/core/TextField';
import Edit from '@material-ui/icons/Edit';
import { withStyles } from '@material-ui/core/styles';
import Bootstrap, { Button } from 'react-bootstrap'
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import PropTypes from 'prop-types';
import { useTheme } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableHead from '@material-ui/core/TableHead';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import Paper from '@material-ui/core/Paper';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import clsx from 'clsx';


const useStyles1 = makeStyles(theme => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props) {
  const classes = useStyles1();
  const theme = useTheme();
  const { count, page, rowsPerPage, onChangePage } = props;

  const handleFirstPageButtonClick = event => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = event => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = event => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = event => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}

TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onChangePage: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
};

function createData(name, calories, fat) {
  return { name, calories, fat };
}


const useStyles2 = makeStyles(theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing(3),
  },
  table: {
    minWidth: 500,
  },
  tableWrapper: {
    overflowX: 'auto',
  },
}));

 
const data = [{ id: 1, firstname: 'Tejaswi', lastname: 'Chava', cid:'C5102896', yearsofexp:'3',technology:'React' },
                { id: 2, firstname: 'Sai Purnima', lastname: 'Kandikattu', cid:'C5104422', yearsofexp:'2.9',technology:'React' },
                { id: 3,firstname: 'Kirti', lastname: 'Saraogi', cid:'C5104415', yearsofexp:'6',technology:'React' },
                { id: 4, firstname: 'Alfia', lastname: 'sadia', cid:'C5102897', yearsofexp:'1',technology:'React' },
                { id: 5,firstname: 'Priti', lastname: 'Tripathy', cid:'C5081726', yearsofexp:'7.5',technology:'React'},
                { id: 6, firstname: 'Krishna Vinay', lastname: 'Kalaga', cid:'C5102897', yearsofexp:'5',technology:'React' },
                { id: 7,firstname: 'Bharat', lastname: 'Reddy', cid:'C5081728', yearsofexp:'7.5',technology:'React' }


            ];


function rand() {
  return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
  const top = 50 + rand();
  const left = 50 + rand();

  return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`,
  };
}

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 200,
    textAlign: "left"
  },
  dense: {
    marginTop: 19,
  },
  menu: {
    width: 200,
  },
  paper: {
    position: 'absolute',
    width: 400,
    backgroundColor: theme.palette.background.paper,
    border: '2px solid #000',
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
  },
}));
 
const styles = theme => ({
  root: {
      margin: 0,
      padding: theme.spacing(2),
  },
  closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500],
  },
});

const DialogTitle = withStyles(styles)(props => {
  const { children, classes, onClose } = props;
  return (
      <MuiDialogTitle disableTypography className={classes.root}>
          <Typography variant="h6">{children}</Typography>
          {onClose ? (
              <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                  <CloseIcon />
              </IconButton>
          ) : null}
      </MuiDialogTitle>
  );
});

const DialogContent = withStyles(theme => ({
  root: {
      padding: theme.spacing(2),
  },
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
  root: {
      margin: 0,
      padding: theme.spacing(1),
  },
}))(MuiDialogActions);



export default function TableComponent(props) {

  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  useEffect(()=>{
    console.log(props.crossReftableData.length)
  })
  const emptyRows = rowsPerPage - Math.min(rowsPerPage, props.crossReftableData.length - page * rowsPerPage);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const columns = [
    {
      name: 'First Name',
      selector: 'firstname',
      sortable: true,
      // cell: row => <div><div style={{ fontWeight: "bold" ,color:"black"}}>{row.title}</div>{row.summary}</div>,
    
    },
    {
      name: 'Last Name',
      selector: 'lastname',
      sortable: true,
    },
    {
      name: 'CID',
      selector: 'cid',
      sortable: true,
    },
    {
      name: 'Years Of Exp',
      selector: 'yearsofexp',
      sortable: true,
    },
    {
      name: 'Technology',
      selector: 'technology',
      sortable: true,
    },
    {
      name: 'Edit',
      // selector: 'edit',
      cell : row => <div  onClick={() => handleOpen(row)} id={row.id}><Edit></Edit></div>
    }
  ];

  const [modalStyle] = React.useState(getModalStyle);
  const [open, setOpen] = React.useState(false);

  const handleOpen = (row) => {
    setDataElement({ 
      id : row.id,
      firstname: row.firstname,
      lastname: row.lastname,
      cid: row.cid,
      yearsofexp: row.yearsofexp,
      technology: row.technology,
    });
    setOpen(true);
  };

  const handleClose = (row) => {
    console.log(row.id);
    data.map(d => {
      if (d.id == row.id) {
        return d;
      }
    })
    setOpen(false);
  };

  const [dataElement, setDataElement] = React.useState({
    id : "",
   firstname : "",
   lastname : "",
   cid : "",
   yearsofexp : "",
   technology : "",
})
  
  const handleChangeDataElement = name => event => {
    setDataElement({ ...dataElement, [name]: event.target.value });
}

  // render() {
    const classes = useStyles();
    const [values, setValues] = React.useState({
        name: '',
    });
    const handleChange = name => event => {
    setValues({  [name]: event.target.value });
    };
    return (
    <div>    
      {/* <DataTable
        title=""
        columns={columns}
        data={data}
        pagination = {true}
        highlightOnHover = {true}
        paginationPerPage = {5}
        paginationRowsPerPageOptions = {[5,10, 15, 20, 25, 30]}
        selectableRows // add for checkbox selection
        onRowSelected={handleChange}
      /> */}
 <Paper className={classes.root}>
      <div className={classes.tableWrapper}>
        <Table className={clsx(classes.table, 'customDataTable', 'with-link')} aria-label="custom pagination table">
        <TableHead>
          <TableRow>
           
            <TableCell ><TableSortLabel>Column Name</TableSortLabel></TableCell>
            
            
            <TableCell><TableSortLabel>Column Business Name</TableSortLabel></TableCell>
            
            <TableCell><TableSortLabel>Table Name</TableSortLabel></TableCell>

            <TableCell><TableSortLabel>Tabe Business Name</TableSortLabel></TableCell>
            

            {/* <TableCell><TableSortLabel>Edit</TableSortLabel></TableCell> */}
    
          </TableRow>
        </TableHead>
          <TableBody>
            {props.crossReftableData.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage).map(row => (
              <TableRow hover key={row.dataElementName} > 
                <TableCell component="th" scope="row" style={{color: "#007bff",  cursor: "pointer", textDecoration: "underline"}}>
                  {row.dataElementName}

                </TableCell>

                <TableCell >{row.functionalArea}</TableCell>
                <TableCell >{row.businessName}</TableCell>
                <TableCell >{row.columnName}</TableCell>
                {/* <TableCell><CreateIcon onClick={() => {
                  props.editValidValueTable(row)
                }}></CreateIcon></TableCell> */}

              </TableRow>
              
            ))}

            {/* {emptyRows > 0 && (
              <TableRow style={{ height: 53 * emptyRows }}>
                <TableCell colSpan={6} />
              </TableRow>
            )} */}
          </TableBody>
          <TableFooter>
            <TableRow>
            <TableCell className="table-pagination">Page: <span>{page+1}</span></TableCell>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                colSpan={3}
                count={props.crossReftableData.length}
                rowsPerPage={rowsPerPage}
                page={page}
                SelectProps={{
                  inputProps: { 'aria-label': 'rows per page' },
                  native: true,
                }}
                onChangePage={handleChangePage}
                onChangeRowsPerPage={handleChangeRowsPerPage}
                ActionsComponent={TablePaginationActions}
              />
            </TableRow>
          </TableFooter>
        </Table>
      </div>
    </Paper>
 
      <Dialog className="custom-dialog" onClose={() =>handleClose(dataElement)} open={open}>
                            <DialogTitle id="customized-dialog-title" onClose={() =>handleClose(dataElement)}>
                                Edit 
                            </DialogTitle>
                            <DialogContent dividers>
                                <TextField
                                    id="data-element-name"
                                    label="First Name"
                                    className={classes.textField}
                                    value={dataElement.firstname}
                                    onChange={handleChangeDataElement('firstname')}
                                />
                                <TextField
                                    id="business-name"
                                    label="Last Name"
                                    className={classes.textField}
                                    value={dataElement.lastname}
                                    onChange={handleChangeDataElement('lastname')}
                                />
                                <TextField
                                    id="Description"
                                    label="CID"
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={dataElement.cid}
                                    onChange={handleChangeDataElement('cid')} />
                                <TextField
                                    id="Description"
                                    label="Years of Experience"
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={dataElement.yearsofexp}
                                    onChange={handleChangeDataElement('yearsofexp')} />
                                <TextField
                                    id="Description"
                                    label="Technology"
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={dataElement.technology}
                                    onChange={handleChangeDataElement('technology')} />        
                            </DialogContent>
                            <DialogActions>
                            <Button variant="outlined" color="primary" className='btn btn-primary'>
              Reset
                </Button>
                            </DialogActions>
                        </Dialog>

    
      </div>
    )
  // }
}