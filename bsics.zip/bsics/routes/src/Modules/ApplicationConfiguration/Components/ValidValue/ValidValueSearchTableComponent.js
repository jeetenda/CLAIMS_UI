import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { withRouter } from 'react-router';

import { validValueViewAction } from '../../Store/Actions/validValue/validValueActions';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../../SharedModules/Table/Table';


const headCells = [
  { id: 'dataElementName', numeric: false, disablePadding: true, label: 'Data Element Name', enableHyperLink: true, width: '30%' },
  { id: 'functionalAreaDesc', numeric: false, disablePadding: false, label: 'Functional Area', enableHyperLink: false, width: '20%' },
  { id: 'businessName', numeric: false, disablePadding: false, label: 'Business Name', enableHyperLink: false, width: '30%' },
  { id: 'dataSize', numeric: false, disablePadding: false, label: 'Data Size', enableHyperLink: false, width: '20%' }
];

function ValidValueSearchTableComponent (props) {
  const dispatch = useDispatch();
  const [showTable, setShowTable] = React.useState(false);

  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);
  const [redirect, setRedirect] = React.useState(0);
  const onSearchView = searchviewvalues => dispatch(validValueViewAction(searchviewvalues));
  const payloadViewData = useSelector(state => state.appConfigState.validValueState.validValueView);
  if (redirect === 1) {
    if (payloadViewData) {
      props.history.push({
        pathname: '/ValidvalueView',
        state: { payloadViewData }
      });
    }
  }
  // Spinner Functionality
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (payloadViewData != null) {
      setspinnerLoader(false);
    }
  }, [payloadViewData]);
  // Spinner Functionality
  const formatSearchCriteria = (rowData)=>{
    let searchCriteria = {
      code: rowData.code !== '' && rowData.code !== undefined ? rowData.code : null,
      businessName: rowData.businessName !== '' ? rowData.businessName : null,
      functionalArea: rowData.functionalArea !== 'Please Select One' ? rowData.functionalArea : null,
      dataElementName: rowData.dataElementName !== '' ? rowData.dataElementName : null,
      dataEleNameStartsOrContains: rowData.dataEleNameStartsOrContains === 'StartsWith' || rowData.dataEleNameStartsOrContains !== undefined ? 0 : rowData.dataEleNameStartsOrContains === 'Contains' ? 1 : null,
      busNameStartsOrContains: rowData.busNameStartsOrContains === 'StartsWith' || rowData.busNameStartsOrContains !== undefined ? 0 : rowData.busNameStartsOrContains === 'Contains' ? 1 : null,
      valueShortDescription: rowData.valueShortDescription !== '' && rowData.valueShortDescription !== undefined ? rowData.valueShortDescription : null,
      crossReferenceColumnName: rowData.crossReferenceColumnName !== '' && rowData.crossReferenceColumnName !== undefined ? rowData.crossReferenceColumnName : null,
      crossReferenceTableName: rowData.crossReferenceTableName !== '' && rowData.crossReferenceTableName !== undefined ? rowData.crossReferenceTableName : null
    };
    return searchCriteria;
  }
  const editRow = row => event => {
    let searchCriteria = formatSearchCriteria(row);
    onSearchView(searchCriteria);
    setspinnerLoader(true);
    setRedirect(1);
  };
  const tableComp = <TableComponent pathTo='/ValidvalueView?data=' formatSearchCriteria={formatSearchCriteria} headCells={headCells} functionalArea={props.functionalArea}
    tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow}
    spinnerLoader={spinnerLoader} defaultSortColumn={'dataElementName'} isSearch={true} />;
  return (
    showTable ? tableComp : null

  );
}
export default withRouter(ValidValueSearchTableComponent);
