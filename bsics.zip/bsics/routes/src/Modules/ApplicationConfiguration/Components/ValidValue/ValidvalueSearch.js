/* eslint-disable no-unused-vars */
import React, { useRef, useEffect } from 'react';
import ValidValueSearchTableComponent from './ValidValueSearchTableComponent';
import Bootstrap, { Button } from 'react-bootstrap';
import * as ValidValueConstants from './ValidValueConstants';
import {
  validValueAction,
  resetSearchValidValue,
  functionalAreaDropDown
} from '../../Store/Actions/validValue/validValueActions';
import { withRouter } from 'react-router';

import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import ValidValueSearchForm from './ValidValueSearchForm';
import { AppConfigDropdownActions } from '../../Store/Actions/AppConfigCommon/AppConfigActions';
import dropdownCriteria from './ValidValueSearch.json';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../../SharedModules/Store/Actions/SharedAction';
import Footer from '../../../../SharedModules/Layout/footer';

function ValidValueSearch (props) {
  const toPrintRef = useRef();
  const printLayout = useSelector(state => state.sharedState.printLayout);
  let errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(false);
  const [showNoRecords, setShowNoRecords] = React.useState(false);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [values, setValues] = React.useState({
    code: null,
    functionalArea: 'Please Select One',
    dataElementName: null,
    businessName: null,
    valueShortDescription: null,
    crossReferenceColumnName: null,
    crossReferenceTableName: null,
    dataEleNameStartsOrContains: null,
    busNameStartsOrContains: null
  });
  const validvaluecons = ValidValueConstants;
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [
    {
      showFunctionalAreaError,
      showdataElementNameError,
      showbusinessNameError
    },
    setShowError
  ] = React.useState(false);

  const handleChanges = name => event => {
    if(name==="businessName" ){
      if(event.target.value.length<=30){
       

   setValues({ ...values, [name]: event.target.value }) 
      };
    }
  
    else{

      setValues({ ...values, [name]: event.target.value });
  
    }
  };

  const resetTable = () => {
    paylod = [];
    setShowTable(false);
    setShowNoRecords(false);
    seterrorMessages([]);
    setShowError(false);
    setValues({
      code: '',
      functionalArea: 'Please Select One',
      dataElementName: '',
      businessName: '',
      valueShortDescription: '',
      crossReferenceColumnName: '',
      crossReferenceTableName: '',
      dataEleNameStartsOrContains: '',
      busNameStartsOrContains: ''
    });
    const valuetoredirect = redirect - 1;
    setRedirect(valuetoredirect);
  };
  /// INTEGRATION PART
  const dispatch = useDispatch();
  const [useEffectValues, setUseEffectValues] = React.useState([]);

  const onReset = () => dispatch(resetSearchValidValue());
  const dropDownDispatch = dropdownvalues =>
    dispatch(AppConfigDropdownActions(dropdownvalues));

  let paylod = [];
  let dropdown = [];
  useEffect(() => {
    onReset();
    dropDownDispatch(dropdownCriteria);
  }, [useEffectValues]);

  const [redirect, setRedirect] = React.useState(0);

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
  }, []);

  const onSearch = searchvalues => dispatch(validValueAction(searchvalues));
  paylod = useSelector(
    state => state.appConfigState.validValueState.validValue
  );
  dropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.appConfigDropdown
  );

  useEffect(() => {
    if (dropdown && dropdown.listObj && dropdown.listObj['Reference#1017']) {
      setFunctionalAreaData(dropdown.listObj['Reference#1017']);
    }
  }, [dropdown]);

  const payloadData = paylod ? paylod[0] : {};

  const functionalAreaDataDescriptionMap = functionalArea => {
    const filteredValue = functionalAreaData.filter(
      (fnArea, index) => fnArea.code === functionalArea
    );
    if (filteredValue && filteredValue.length > 0) {
      return filteredValue[0].description;
    }
    return functionalArea;
  };

  if (paylod && paylod.length > 0) {
    paylod.map((data, index) => {
      data.functionalAreaDesc = functionalAreaDataDescriptionMap(
        data.functionalArea
      );
    });
  }

  if (redirect === 1) {
    if (paylod != null) {
      if (paylod.length === 1) {
        props.history.push({
          pathname: '/ValidvalueView',
          state: { payloadData }
        });
      }
    }
  }
  // INTEGRATION PART
  // Spinner Functionality
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (paylod != null && (paylod.length > 0 || paylod.length === 0)) {
      setShowTable(true);
      setspinnerLoader(false);
    }
    if (paylod === null || (paylod && paylod.message != null)) {
      setspinnerLoader(false);
      errorMessagesArray.push(validvaluecons.ERROR_OCCURED_DURING_TRANSACTION);
      seterrorMessages(errorMessagesArray);
    }
    if (paylod != null && paylod.length === 0) {
      setspinnerLoader(false);
      setShowNoRecords(true);
    }
  }, [paylod]);
  // Spinner Functionality
  const searchCheck = () => {
    paylod = [];
    setShowTable(false);
    setspinnerLoader(false);
    errorMessagesArray = [];
    seterrorMessages([]);
    var showFunctionalAreaError;
    var showbusinessNameError;
    var showdataElementNameError = false;
    if (
      values.code &&
      (!values.functionalArea || values.functionalArea === 'Please Select One')
    ) {
      if (
        !values.functionalArea ||
        values.functionalArea === 'Please Select One'
      ) {
        showFunctionalAreaError = true;
        errorMessagesArray.push(validvaluecons.FUNCTIONAL_AREA_REQUIRED);
        seterrorMessages(errorMessagesArray);
        setShowTable(false);
      }
    }
    if (
      values.busNameStartsOrContains &&
      (!values.businessName || values.businessName.trim().length < 2)
    ) {
      showbusinessNameError = true;
      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (
      values.dataEleNameStartsOrContains &&
      (!values.dataElementName || values.dataElementName.trim().length < 2)
    ) {
      showdataElementNameError = true;
      errorMessagesArray.push(validvaluecons.DATA_ELEMENT_NAME_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    } else if (errorMessagesArray.length === 0) {
      setspinnerLoader(true);
      let searchCriteria = {};
      searchCriteria = {
        code: values.code !== '' ? values.code : null,
        businessName: values.businessName !== '' ? values.businessName : null,
        functionalArea:
          values.functionalArea !== 'Please Select One'
            ? values.functionalArea
            : null,
        dataElementName:
          values.dataElementName !== '' ? values.dataElementName : null,
        dataEleNameStartsOrContains:
          values.dataEleNameStartsOrContains === 'StartsWith'
            ? 0
            : values.dataEleNameStartsOrContains === 'Contains'
              ? 1
              : null,
        busNameStartsOrContains:
          values.busNameStartsOrContains === 'StartsWith'
            ? 0
            : values.busNameStartsOrContains === 'Contains'
              ? 1
              : null,
        valueShortDescription:
          values.valueShortDescription !== ''
            ? values.valueShortDescription
            : null,
        crossReferenceColumnName:
          values.crossReferenceColumnName !== ''
            ? values.crossReferenceColumnName
            : null,
        crossReferenceTableName:
          values.crossReferenceTableName !== ''
            ? values.crossReferenceTableName
            : null
      };
      onSearch(searchCriteria);
      let valuetoredirect = 0;
      valuetoredirect = valuetoredirect + 1;
      setRedirect(valuetoredirect);
    }
    setShowError({
      showFunctionalAreaError: showFunctionalAreaError,
      showbusinessNameError: showbusinessNameError,
      showdataElementNameError: showdataElementNameError
    });
  };
  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}

      <div className="tabs-container" ref={toPrintRef}>
        {errorMessages.length > 0 ? (
          <div
            className="alert alert-danger custom-alert hide-on-print"
            role="alert"
          >
            {errorMessages.map(message => (
              <li>{message}</li>
            ))}
          </div>
        ) : null}
        {errorMessages.length === 0 &&
        paylod &&
        paylod.length === 0 &&
        showNoRecords ? (
            <div
              className="alert alert-danger custom-alert hide-on-print"
              role="alert"
            >
              <li>{ValidValueConstants.NO_RECORDS_FOUND}</li>
            </div>
          ) : null}
        <div className="tab-header">
          <div className="tab-heading float-left">Search Valid Value</div>
          <div className="float-right mt-2 hide-on-print">
            <ReactToPrint
              onBeforeGetContent={() => {
                setspinnerLoader(true);
                dispatch(setPrintLayout(true));
                return new Promise(resolve => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button className="btn btn-primary">
                  <i className="fa fa-print" aria-hidden="true"></i>
                  Print
                </Button>
              )}
              content={() => toPrintRef.current}
            />

            <Button className="btn btn-secondary ml-1">
              <i className="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div className="tab-body">
          <ValidValueSearchForm
            values={values}
            functionalArea={functionalAreaData}
            handleChanges={handleChanges}
            resetTable={resetTable}
            searchCheck={searchCheck}
            errors={{
              showFunctionalAreaError: showFunctionalAreaError,
              showdataElementNameError: showdataElementNameError,
              showbusinessNameError: showbusinessNameError
            }}
          />
          {showTable && paylod && paylod.length > 0 ? (
            <div
              className={`tab-holder pb-1 ${
                printLayout ? 'hide-on-screen' : ''
              }`}
            >
              <ValidValueSearchTableComponent tableData={paylod} />
            </div>
          ) : null}
          <Footer print />
        </div>
      </div>
    </div>
  );
}
export default withRouter(ValidValueSearch);
