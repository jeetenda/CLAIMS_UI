/* eslint-disable no-unused-vars */
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { withRouter } from 'react-router';

import TableComponent from '../../../../../SharedModules/Table/Table';

/*
const headCells = [
  { id: 'listNumber', numeric: false, disablePadding: true, label: 'List Number', width: 100, enableHyperLink: true },
  { id: 'description', numeric: false, disablePadding: false, label: 'Description', isDescription: true, width: 120 },
  { id: 'listType', numeric: false, disablePadding: false, label: 'List Type', width: 120 },
  { id: 'dataElementName', numeric: false, disablePadding: false, label: 'Data Element Name', width: 170 },
  { id: 'functionalAreaDesc', numeric: false, disablePadding: false, label: 'Functional Area', width: 140 }
];
*/
const headCells = [
  { id: 'listNumber', numeric: false, disablePadding: true, label: 'List Number', width: "100px", enableHyperLink: true },
  { id: 'description', numeric: false, disablePadding:false, label: 'Description',  width: '20%' },
  { id: 'listType', numeric: false, disablePadding: false, label: 'List Type', width: "120px" },
  { id: 'dataElementName', numeric: false, disablePadding: false, label: 'Data Element Name', width: "170px" },
  { id: 'functionalAreaDesc', numeric: false, disablePadding: false, label: 'Functional Area', width: "140px" }
];
function SystemListTable (props) {
  // const classes = useStyles();
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('parameterNumber');
  const [selected, setSelected] = React.useState([]);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [values, setValues] = React.useState({});
  const dispatch = useDispatch();
  const [useEffectValues, setUseEffectValues] = React.useState([]);

  useEffect(() => {
    console.log('in useEffect');
  }, [useEffectValues]);

  const [redirect, setRedirect] = React.useState(0);
  let paylod;

  const isSelected = name => selected.indexOf(name) !== -1;

  const emptyRows = rowsPerPage - Math.min(rowsPerPage, props.tableData.length - page * rowsPerPage);

  // const onRowClick = values => dispatch(systemListViewAction(values));
  // let payloadData = useSelector(state =>state.appConfigState.systemListState.systemListViewData);
  // console.log(payloadData);
  // if(redirect == 1) {
  //   if(values){
  //     props.history.push({
  //       pathname:'/SystemListAddUpdate',
  //       state: { values }
  //     });
  //   }
  // }
  const formatSearchCriteria = (_row)=>({
    listNumber: _row.listNumber,
    functionalArea: _row.functionalArea,
    dataElementName: _row.dataElementName,
    description: _row.description,
    listType: _row.listType,
    listBusinessName: _row.listBusinessName,
    funcAreaDesc: _row.funcAreaDesc
  });

  const editRow = row => event => {
    const searchSwapJson = formatSearchCriteria(row);
    const valuetoredirect = redirect + 1;
    setRedirect(valuetoredirect);
    props.history.push({
      pathname: '/SystemListAddUpdate',
      state: { searchSwapJson }
    });
  };


  const tableComp = <TableComponent pathTo='/SystemListAddUpdate?data=' formatSearchCriteria={formatSearchCriteria} headCells={headCells} isSearch={true} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={'listNumber'} />;
  return (
    tableComp

  );
}
export default withRouter((SystemListTable));
