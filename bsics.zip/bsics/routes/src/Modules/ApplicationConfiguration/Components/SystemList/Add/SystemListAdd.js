/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from 'react';
import { makeStyles, withStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import PropTypes from 'prop-types';
import AppBar from '@material-ui/core/AppBar';
import Box from '@material-ui/core/Box';
import { useDispatch, useSelector } from 'react-redux';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import 'date-fns';
import SystemListAddTable from './SystemListAddTable';
import * as SystemListSearchConstants from '../Search/SystemListSearchConstants';
import * as SystemListConstants from '../systemListConstants';
import { addSystemListAction, getSubDropdownDataAction,systemListActions,systemListViewAction } from '../../../Store/Actions/systemList/systemListActions';
import moment from 'moment';
import { generateUUID, validateDateMinimumValue, compareTwoDatesGreaterThanOrEqual, getUTCTimeStamp } from '../../../../../SharedModules/DateUtilities/DateUtilities';
import { Prompt } from 'react-router-dom';
import ReactToPrint from 'react-to-print';
import TabPanel from '../../../../../SharedModules/TabPanel/TabPanel';
import { AppConfigDropdownActions, DataElementDropdownActions } from '../../../Store/Actions/AppConfigCommon/AppConfigActions';
import dropdownCriteria from '../Search/SystemListAddUpdate.json';
import * as AppConstants from '../../../../../SharedModules/AppConstants';
import NotesComponent from '../../../../../SharedModules/Notes/Notes';

import { setPrintLayout } from '../../../../../SharedModules/Store/Actions/SharedAction';
import Footer from '../../../../../SharedModules/Layout/footer';
import ErrorMessages from '../../../../../SharedModules/Errors/ErrorMessages';
import UnsavedChangesMessage from '../../../../../SharedModules/Errors/UnsavedChangesMessage';
import "./SystemListAdd.css"


const newData = [];
const id = 0;

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap'
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 200,
    textAlign: 'left'
  },
  dense: {
    marginTop: 19
  },
  menu: {
    // width: 200
  }
}));

const styles = theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(2)
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});

const DialogTitle = withStyles(styles)(props => {
  const { children, classes, onClose } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root}>
      <Typography variant="h6">{children}</Typography>
      {onClose ? (
        <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});
const DialogContent = withStyles(theme => ({
  root: {
    padding: theme.spacing(2)
  }
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(1)
  }
}))(MuiDialogActions);

export default function SearchListAdd(props) {
  let errorMessagesArray = [];
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const toPrintRef = useRef();
  const dispatch = useDispatch();
  const onAddSystemList = (value, logInId) => dispatch(addSystemListAction(value, logInId));
  const successMessageArray = [];

  const [systemListAddTableData, setSystemListAddTableData] = React.useState([]);
  
  const classes = useStyles();
  const [tableData, setTableData] = React.useState([]);
  const [id, setId] = React.useState(0);
  const [allowNavigation, setAllowNavigation] = React.useState(false);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [dataElementNameData, setDataElementData] = React.useState([]);
  const [listTypeData, setListTypeData] = React.useState([]);
  const [lobCodeData, setLobCodeData] = React.useState([]);
  const [errorMessages, setErrorMessages] = React.useState([]);

  const [prompt, setPrompt] = useState(false);
  const [cancelType, setCancelType] = useState(false);
  const [confirm, setConfirm] = useState(false);

  const [values, setValues] = React.useState({
    functionalArea: 'Please Select One',
    listNumber: '',
    businessName: '',
    dataElementName: 'Please Select One',
    listType: 'Please Select One',
    usedInMapSet: 'No Data',
    description: ''
  });
  const [retainEdit, setRetainEdit] = React.useState({});
  const [dataElementNameValue, setDataElementNameValue] = React.useState('');
  const [successMessage, setSuccessMessages] = React.useState([]);
  const [rowSystemListDetailData, setRowSystemListDetailData] = React.useState([]);
  // notes

  const [notesTableData, setNotesTableData] = React.useState([]);
  const [notesInput, setNotesInput] = React.useState({

    auditUserID: 'BTAYLOR1',
    auditTimeStamp: null,
    addedAuditUserID: 'BTAYLOR1',
    addedAuditTimeStamp: null,
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    tableName: null,
    noteSetSK: null,
    noteSourceName: null,
    notesList: notesTableData,
    globalNotesList: [],
    checkAll: null,
    addNewLinkRender: null,
    filterLinkRender: null,
    printLinkRender: null,
    completeNotesList: []

  });
  const [noteSetListInput, setNoteSetListInput] = React.useState({
    auditUserID: 'BTAYLOR1',
    auditTimeStamp: null,
    addedAuditUserID: 'BTAYLOR1',
    addedAuditTimeStamp: null,
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    noteTextValue: null,
    userIdName: null,
    notesCexAuditUserID: null,
    notesCexAuditTimeStamp: null,
    notesCexAddedAuditUserID: null,
    notesCexAddedAuditTimeStamp: null,
    noteSetSK: null,
    usageTypeDesc: '',
    shortNotes: null,
    checked: false,
    renderNoHistoryMsg: false,
    noteSequenceNumber: 4,
    currentNote: null,
    rowValue: null,
    usageTypeList: null,
    strBeginDate: moment(new Date()).format('MM/DD/YYYY hh:mm:ss'),
    usageTypeCode: 'Please Select One',
    tableName: null,
    noteText: '',
    commonEntityName: null,
    commonEntityTypeCode: null,
    commonEntityId: null,
    entityId: null,
    filterbeginDate: moment(new Date()).format('YYYY-MM-DD'),
    filterEndDate: null,
    userId: '',
    noteCexVersionNum: 0,
    saNoteSequenceNumber: null,
    notesCexnoteTextValue: 0,
    id: generateUUID()
  });
  const [usageTypeCodeInput, setUsageTypeCodeInput] = React.useState([{
    functionalArea: 'General',
    dataElementName: 'G_NOTE_TY_CD',
    businessName: null,
    valueShortDescription: null,
    crossReferenceColumnName: null,
    crossReferenceTableName: null,
    dataEleNameStartsOrContains: null,
    busNameStartsOrContains: null
  }]);
  const [usageTypeCodeData, setUsageTypeCodeData] = React.useState([]);
  const [editNoteData, setEditNoteData] = React.useState({});

  const dropDownDispatch = dropdownvalues => dispatch(AppConfigDropdownActions(dropdownvalues));
  const dataElemDropDownDispatch = () => dispatch(DataElementDropdownActions());
  const usageTypeDropDown = usageTypeCodeInput => dispatch(getSubDropdownDataAction(usageTypeCodeInput));

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
    dataElemDropDownDispatch();
    setErrorMessages([]);
    usageTypeDropDown(usageTypeCodeInput);
  }, []);
  const dropdown = useSelector(state => state.appConfigState.AppConfigCommonState.appConfigDropdown);
  const datElemDropdown = useSelector(state => state.appConfigState.AppConfigCommonState.dataElementNameDropdown);
  const usageTypeCodeDropDown = useSelector(state => state.appConfigState.systemListState.usageDropDown);
  const logInUserID = useSelector(state => state.sharedState.logInUserID);

  let loginUserDetails= localStorage.getItem("loginState")
  loginUserDetails=JSON.parse(loginUserDetails)
  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj['Reference#1017']) {
        setFunctionalAreaData(dropdown.listObj['Reference#1017']);
      }
      if (dropdown.listObj['Reference#2']) {
        setListTypeData(dropdown.listObj['Reference#2']);
      }
      if (dropdown.listObj['Reference#1019']) {
        setLobCodeData(dropdown.listObj['Reference#1019']);
      }
    }
  }, [dropdown]);



  useEffect(() => {
    console.log(usageTypeCodeDropDown);
    if (usageTypeCodeDropDown) {
      if (usageTypeCodeDropDown.listObj) {
        const usage = usageTypeCodeDropDown.listObj['General#G_NOTE_TY_CD'];
        setUsageTypeCodeData(usage);
      }
    }
  }, [usageTypeCodeDropDown]);

  useEffect(() => {
    if (datElemDropdown && datElemDropdown.listDataElements) {
      setDataElementData(datElemDropdown.listDataElements);
    }
  }, [datElemDropdown]);

  const handleChanges = name => event => {
    setAllowNavigation(true);
    setValues({ ...values, [name]: event.target.value });
    if (name === 'dataElementName') {
      setDataElementNameValue(event.target.value);
    }
  };

  const addResponse = useSelector(state => state.appConfigState.systemListState.systemListAddResponse);
const isErrorSavingData=useSelector(state=>{
return state.appConfigState.systemListState.isErrorSavingData
})

  console.log(addResponse);

  /*
    successMessageArray.push(SystemListSearchConstants.SAVED_SUCCESSFULLY);
  listNumber: values.listNumber,
        functionalArea: values.functionalArea,
        dataElementName: values.dataElementName,
        description: values.description,
        listType: values.listType,
        listBusinessName: values.businessName,
        SuccessMessages: successMessageArray
        */

  useEffect(() => {
    if (addResponse && addResponse.flag === 'success') {
      //

    
      successMessageArray.push(SystemListSearchConstants.SAVED_SUCCESSFULLY);
      const searchSwapJson = {
        listNumber: values.listNumber,
        functionalArea: values.functionalArea,
        dataElementName: values.dataElementName,
        description: values.description,
        listType: values.listType,
        listBusinessName: values.businessName,
        SuccessMessages: successMessageArray,
        isTryingTosaveFromSystemListAdd:true
      };
      props.history.push({
        pathname: '/SystemListAddUpdate',
        state: { searchSwapJson }
      });
    } else if (addResponse && addResponse.flag !== undefined && addResponse.flag !== 'success') {
      // const duplicateErrorMessage = addResponse.flag;
   
      errorMessagesArray.push(addResponse.flag)
    
      setErrorMessages(errorMessagesArray);
      // duplicateErrorMessage.map((errMsg) => {
      //   errorMessagesArray.push(errMsg);
      // });
    } else if (addResponse !== undefined && addResponse.flag === undefined) {
      errorMessagesArray.push(SystemListSearchConstants.SOMETHING_WENT_WRONG);
      if (errorMessages.length === 0) {
        setErrorMessages(errorMessagesArray);
      }
    }
  }, [addResponse]);

  const [openCrossReference, setOpenCrossReference] = React.useState(false);

  const [inputValues, setInputValues] = React.useState({
    beginValue: '',
    endValue: '',
    longDescription: '',
    sortOrder: ''

  });

  const handleCloseCrossReference = () => {
    setOpenCrossReference(false);
  };

  const [add, setAdd] = React.useState(true);
  const [{
    showFunctionalAreaError, showListNumberError, showDataElementNameError, showListTypeError,
    showDescriptionError, showBusinessNameError,
    showLobCodeError, showBeginValueError,
    showEndValueError, showBeginDateError,
    showEndDateError, showEndDateValidError,
    showOverLappingError, showTableDataError,
    showRevenueCodeBeginValueError,
    showRevenueCodeEndValueError,
    showBeginValueInvalidError,
    showDiagNumericBeginValueError,
    showDiagNumericEndValueError
  }, setShowError] = React.useState(false);

  const [showSystemlistValueTable, setShowSystemlistValueTable] = React.useState(false);
  const [value, setValue] = React.useState(0);
  const [open, setOpen] = React.useState(false);
  const [dataElement, setDataElement] = React.useState({
    id: 0,
    dataElementName: '',
    businessName: '',
    description: ''

  });

  const [{
    showDescriptionErrorText,
    showListtypeErrorText,
    showListNumberErrorText,
    showFunctionalAreaErrorText,
    showDataElementNameErrorText,
    showBusinessNameErrorText,
    showLobCodeErrorText,
    showBeginValueErrorText,
    showEndValueErrorText,
    showBeginDateErrorText,
    showEndDateErrorText,
    showRevenueCodeBeginValueErrorText,
    showRevenueCodeEndValueErrorText,
    showDiagNumericBeginValueErrorText,
    showDiagNumericEndValueErrorText,
    showTableDataText
  }, setShowErrorText] = React.useState('');

  const [editData, setEditData] = React.useState({});

  const handleChangeTabs = (event, newValue) => {
    setValue(newValue);
  };

  const handleClickOpen = () => {
    let showFunctionalAreaError; let showListTypeError; let showDataElementNameError; let showListNumberError;
    let showBusinessNameError; let showDescriptionError = false;
    let showFunctionalAreaErrorText; let showListtypeErrorText; let showDataElementNameErrorText;
    let showListNumberErrorText; let showBusinessNameErrorText; let showDescriptionErrorText = '';

    if (values.functionalArea === 'Please Select One') {
      showFunctionalAreaError = true;
      setShowError({ showFunctionalAreaError: showFunctionalAreaError });
      errorMessagesArray.push(SystemListSearchConstants.FUNCTIONALAREA_REQUIRED);
      showFunctionalAreaErrorText = SystemListSearchConstants.FUNCTIONALAREA_REQUIRED;
    }
    if (values.listType === 'Please Select One') {
      showListTypeError = true;
      setShowError({ showListTypeError: showListTypeError });
      errorMessagesArray.push(SystemListSearchConstants.LIST_TYPE_REQUIRED);
      showListtypeErrorText = SystemListSearchConstants.LIST_TYPE_REQUIRED;
    }
    if (values.dataElementName === 'Please Select One') {
      showDataElementNameError = true;
      setShowError({ showDataElementNameError: showDataElementNameError });
      errorMessagesArray.push(SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED);
      showDataElementNameErrorText = SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED;
    }
    if (values.listNumber === '') {
      showListNumberError = true;
      setShowError({ showListNumberError: showListNumberError });
      errorMessagesArray.push(SystemListSearchConstants.LISTNUMBER_REQUIRED);
      showListNumberErrorText = SystemListSearchConstants.LISTNUMBER_REQUIRED;
    }
    if (values.businessName === '') {
      showBusinessNameError = true;
      showBusinessNameErrorText = SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR;
      errorMessagesArray.push(SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR);
    }
    if (values.description === '') {
      showDescriptionError = true;
      showDescriptionErrorText = SystemListSearchConstants.DESCRIPTION_REQUIRED;
      errorMessagesArray.push(SystemListSearchConstants.DESCRIPTION_REQUIRED);
    }

    setShowError({
      showFunctionalAreaError: showFunctionalAreaError,
      showListTypeError: showListTypeError,
      showDataElementNameError: showDataElementNameError,
      showListNumberError: showListNumberError,
      showBusinessNameError: showBusinessNameError,
      showDescriptionError: showDescriptionError
    });
    setShowErrorText({
      showFunctionalAreaErrorText: showFunctionalAreaErrorText,
      showListtypeErrorText: showListtypeErrorText,
      showDataElementNameErrorText: showDataElementNameErrorText,
      showListNumberErrorText: showListNumberErrorText,
      showBusinessNameErrorText: showBusinessNameErrorText,
      showDescriptionErrorText: showDescriptionErrorText
    });

    if (errorMessagesArray.length === 0) {
      setErrorMessages([]);
      setSelectedBeginDate(null);
      setSelectedEndDate(new Date('9999-12-31T13:00:00.000+0000'));
      setOpenCrossReference(true);
      setSystemListValues({
        lob: 'Please Select One',
        beginValue: '',
        endValue: ''
      });
      setAdd(true);
    } else {
      setErrorMessages(errorMessagesArray);
    }
  };

  const [systemListValues, setSystemListValues] = React.useState({
    lob: 'Please Select One',
    beginDate: null,
    endDate: null,
    beginValue: '',
    endValue: '',
    sortOrder: ''
  });

  const resetSystemListValues = () => {
    if (add) {
      setSystemListValues({
        lob: 'Please Select One',
        beginDate: null,
        endDate: null,
        beginValue: '',
        endValue: '',
        sortOrder: ''
      });
      setSelectedBeginDate(null);
      setSelectedEndDate(new Date('9999-12-31T13:00:00.000+0000'));
    } else {
      setSystemListValues({
        lob: retainEdit.lineofbusiness,
        beginValue: retainEdit.startingValue,
        endValue: retainEdit.endingValue,
        sortOrder: retainEdit.sortOrder ? retainEdit.sortOrder : (retainEdit.sortNum ? retainEdit.sortNum : '')

      });
      setSelectedBeginDate(retainEdit.beginDate);
      setSelectedEndDate(retainEdit.endDate);
    }

    setShowError(false);
    setShowErrorText(false);
  };

  let systemListData = [];
  const addSystemListValuesToTable = () => {
    if (add) {
      if (checkPopupFormValidations()) {
        let count = 0;
        if (tableData.length > 0) {
          tableData.map((value, index) => {
            if ((value.startingValue).toString() === systemListValues.beginValue) {
              if (moment(value.beginDate).format('MM/DD/YYYY') === moment(selectedBeginDate).format('MM/DD/YYYY')) {
                count = count + 1;
              } else if ((moment(value.beginDate).format('MM/DD/YYYY') < moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(value.endDate).format('MM/DD/YYYY') >= moment(selectedEndDate).format('MM/DD/YYYY'))) {
                count = count + 1;
              } else if ((moment(value.beginDate).format('MM/DD/YYYY') > moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(selectedEndDate).format('MM/DD/YYYY') >= moment(value.beginDate).format('MM/DD/YYYY'))) {
                count = count + 1;
              }
            }
          });
        }
        let showDateOverlappingError = false;
        if (count > 0) {
          errorMessagesArray = [];
          setErrorMessages([]);
          showDateOverlappingError = true;
          errorMessagesArray.push(SystemListSearchConstants.OVERLAPPING_ERROR);
          setErrorMessages(errorMessagesArray);
          setShowError({ showOverLappingError: showDateOverlappingError });
          window.scrollTo(0, 0);
        }
        //sortNum: systemListValues.sortOrder,
        if (!showDateOverlappingError) {
          const value = {
           
            deletedSystemListRanges: [],
           
            lineofbusiness: systemListValues.lob,
            "addedAuditUserID":  loginUserDetails.logInUserId,
            "auditUserID":  loginUserDetails.logInUserId,
            "auditTimeStamp": getUTCTimeStamp(),
            "addedAuditTimeStamp": getUTCTimeStamp(),  
            voidIndicator: '',
            disableVoidIndCode: false,
            beginDate: moment(selectedBeginDate).format('MM/DD/YYYY'),
            endDate: moment(selectedEndDate).format('MM/DD/YYYY'),
            ranges: null,
            voidDate: null,
            tempVoidDate: null,
            showVoidRecord: true,
            listDetail: null,
            endingValue: systemListValues.endValue !== '' ? systemListValues.endValue : systemListValues.beginValue,
            startingValue: systemListValues.beginValue,
            
            filterEndingValue: null,
            filterStartingValue: null,
            filterBeginDate: null,
            filterEndDate: null,
            filterLineofbusiness: null,
            lineofbusiness1: null,
            id: generateUUID(),
            auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            auditTimeStamp: getUTCTimeStamp(),
            addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            addedAuditTimeStamp: getUTCTimeStamp(),
          };
          systemListData = tableData;
          systemListData.push(value);
          setTableData(systemListData);
        }

        handleCloseCrossReference();
      }
    } else {
      if (checkPopupFormValidations()) {
        let count = 0;

        tableData.map(value => {
          if (tableData.indexOf(value) !== tableData.indexOf(editData)) {
            if (tableData.length > 0) {
              tableData.map((value, index) => {
                if ((value.startingValue).toString() === systemListValues.beginValue) {
                  if (moment(value.beginDate).format('MM/DD/YYYY') === moment(selectedBeginDate).format('MM/DD/YYYY')) {
                    count = count + 1;
                  } else if ((moment(value.beginDate).format('MM/DD/YYYY') < moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(value.endDate).format('MM/DD/YYYY') >= moment(selectedEndDate).format('MM/DD/YYYY'))) {
                    count = count + 1;
                  } else if ((moment(value.beginDate).format('MM/DD/YYYY') > moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(selectedEndDate).format('MM/DD/YYYY') >= moment(value.beginDate).format('MM/DD/YYYY'))) {
                    count = count + 1;
                  }
                }
              });
            }
          }
        });
        let showDateOverlappingError = false;
        if (count > 0) {
          errorMessagesArray = [];
          setErrorMessages([]);
          showDateOverlappingError = true;
          errorMessagesArray.push(SystemListSearchConstants.OVERLAPPING_ERROR);
          setErrorMessages(errorMessagesArray);
          setShowError({ showOverLappingError: showDateOverlappingError });
          window.scrollTo(0, 0);
        } else {
          tableData[tableData.indexOf(editData)].startingValue = systemListValues.beginValue;
          tableData[tableData.indexOf(editData)].endingValue = values.listType === 'UIS' ? systemListValues.beginValue : systemListValues.endValue;
          tableData[tableData.indexOf(editData)].lineofbusiness = systemListValues.lob;
          tableData[tableData.indexOf(editData)].beginDate = moment(selectedBeginDate).format('MM/DD/YYYY');
          tableData[tableData.indexOf(editData)].endDate = moment(selectedEndDate).format('MM/DD/YYYY');
          tableData[tableData.indexOf(editData)].sortNum = systemListValues.sortOrder;
          console.log(tableData, 'tableData........');
        }

        handleCloseCrossReference();
        setAdd(true);
      }
    }
  };

  const handleSystemListChanges = name => event => {
    if (name === 'beginValue') {
      console.log('beginValue');
      console.log(event.target.value);
    }
    setSystemListValues({ ...systemListValues, [name]: event.target.value });
  };
  const [selectedBeginDate, setSelectedBeginDate] = React.useState(null);
  const [selectedEndDate, setSelectedEndDate] = React.useState(new Date('9999-12-31T13:00:00.000+0000'));

  const checkFormValidations = () => {
    const errorMessagesArray = [];
    var showDescriptionError = false; var showListNumberError = false; var showListTypeError = false; var showBusinessNameError = false;
    var showFunctionalAreaError = false; var showDataElementNameError = false; var showLobCodeError; var showBeginDateError;
    var showEndDateError; var showEndDateValidError; var showBeginValueError; var showEndValueError;
    var showTableDataError = false;
    var tableErrorMsg = true;
    var showBusinessNameErrorText; var showDescriptionErrorText; var showListNumberErrorText; var showListtypeErrorText;
    var showFunctionalAreaErrorText; var showDataElementNameErrorText;
    var showBeginValueErrorText; var showEndValueErrorText; var showBeginDateErrorText;
    var showEndDateErrorText; var showTableDataText = '';
    setErrorMessages([]);

    if (values.businessName === '') {
      showBusinessNameError = true;
      showBusinessNameErrorText = SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR;
      errorMessagesArray.push(SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR);
      setErrorMessages(errorMessagesArray);
      tableErrorMsg = false;
    }

    if (values.description === '') {
      showDescriptionError = true;
      showDescriptionErrorText = SystemListSearchConstants.DESCRIPTION_REQUIRED;
      errorMessagesArray.push(SystemListSearchConstants.DESCRIPTION_REQUIRED);
      setErrorMessages(errorMessagesArray);
      tableErrorMsg = false;
    }

    if (values.listType === 'Please Select One') {
      showListTypeError = true;
      setShowError({ showListTypeError: showListTypeError });
      errorMessagesArray.push(SystemListSearchConstants.LIST_TYPE_REQUIRED);
      showListtypeErrorText = SystemListSearchConstants.LIST_TYPE_REQUIRED;
      setErrorMessages(errorMessagesArray);
      tableErrorMsg = false;
    }
    if (values.dataElementName === 'Please Select One') {
      showDataElementNameError = true;
      setShowError({ showDataElementNameError: showDataElementNameError });
      errorMessagesArray.push(SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED);
      showDataElementNameErrorText = SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED;
      setErrorMessages(errorMessagesArray);
      tableErrorMsg = false;
    }
    if (values.functionalArea === 'Please Select One') {
      showFunctionalAreaError = true;
      setShowError({ showFunctionalAreaError: showFunctionalAreaError });
      errorMessagesArray.push(SystemListSearchConstants.FUNCTIONALAREA_REQUIRED);
      showFunctionalAreaErrorText = SystemListSearchConstants.FUNCTIONALAREA_REQUIRED;
      setErrorMessages(errorMessagesArray);
      tableErrorMsg = false;
    }
    if (values.listNumber === '') {
      showListNumberError = true;
      setShowError({ showListNumberError: showListNumberError });
      errorMessagesArray.push(SystemListSearchConstants.LISTNUMBER_REQUIRED);
      showListNumberErrorText = SystemListSearchConstants.LISTNUMBER_REQUIRED;
      setErrorMessages(errorMessagesArray);
      tableErrorMsg = false;
    }
    if (tableData.length === 0 && tableErrorMsg) {
      showTableDataError = true;
      setShowError({ showListNumberError: showListNumberError });
      errorMessagesArray.push(SystemListSearchConstants.DETAIL_ROW_REQUIRED);
      setErrorMessages(errorMessagesArray);
      setShowErrorText(errorMessagesArray);
    }

    setShowError({
      showDescriptionError: showDescriptionError,
      showListTypeError: showListTypeError,
      showListNumberError: showListNumberError,
      showBusinessNameError: showBusinessNameError,
      showFunctionalAreaError: showFunctionalAreaError,
      showDataElementNameError: showDataElementNameError,
      showEndDateValidError: showEndDateValidError,
      showTableDataError: showTableDataError
    });

    setShowErrorText({
      showDescriptionErrorText: showDescriptionErrorText,
      showListNumberErrorText: showListNumberErrorText,
      showListtypeErrorText: showListtypeErrorText,
      showDataElementNameErrorText: showDataElementNameErrorText,
      showFunctionalAreaErrorText: showFunctionalAreaErrorText,
      showBusinessNameErrorText: showBusinessNameErrorText,
      showTableDataText: showTableDataText
    });

    if (showTableDataError || showBusinessNameError || showDescriptionError || showListNumberError || showDataElementNameError || showListTypeError || showDescriptionError || showBusinessNameError) {
      return false;
    } else {
      return true;
    }
  };

  const checkPopupFormValidations = () => {
    console.log(selectedBeginDate);
    console.log(selectedEndDate);
    var showLobCodeError; var showBeginDateError; var showEndDateError; var showEndDateValidError; var showBeginValueError;
    var showDiagNumericBeginValueError; var showDiagNumericEndValueError; var showEndValueError;
    var showRevenueCodeBeginValueError; var showRevenueCodeEndValueError = false;

    var showLobCodeErrorText; var showBeginValueErrorText; var showEndValueErrorText; var showBeginDateErrorText;
    var showDiagNumericBeginValueErrorText; var showEndDateErrorText;
    var showDiagNumericEndValueErrorText = '';

    if (systemListValues.lob === 'Please Select One') {
      showLobCodeError = true;
      setShowError({ showLobCodeError: showLobCodeError });
      showLobCodeErrorText = SystemListSearchConstants.LOB_REQUIRED;
      // return true;
    } else {
      showLobCodeError = false;
    }

    if (systemListValues.beginValue === '') {
      showBeginValueError = true;
      setShowError({ showBeginValueError: showBeginValueError });
      showBeginValueErrorText = SystemListSearchConstants.BEGINVALUE_REQUIRED;
    } else {
      console.log(dataElementNameValue);
      if (dataElementNameValue === 'R_REV_CD') {
        const numbers = /^[0-9]+$/;
        if (systemListValues.beginValue.length === 4) {
          showRevenueCodeBeginValueError = false;
          if (systemListValues.beginValue.match(numbers)) {
            showRevenueCodeBeginValueError = false;
            setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
          } else {
            showRevenueCodeBeginValueError = true;
            setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
            showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE;
          }
        } else {
          showRevenueCodeBeginValueError = true;
          setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
          showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE;
        }
      }
      if (dataElementNameValue === 'R_DIAG_CD') {
        const test = SystemListConstants.ADDVALUE_REGEX;
        console.log(!systemListValues.beginValue.substring(0, 1).match(/^[0-9]/));
        console.log(systemListValues.beginValue.match(test));
        if ((!isNaN(systemListValues.beginValue))) {
          if (systemListValues.beginValue.match(test)) {
            showDiagNumericBeginValueError = false;
            setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
            showDiagNumericBeginValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
          } else {
            showDiagNumericBeginValueError = true;
            setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
            showDiagNumericBeginValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
          }
        }
      }

      if (dataElementNameValue === 'R_SURG_PROC_CD') {
        const test = SystemListConstants.SURGICAL_REGEX;
        const ICD10 = SystemListConstants.SURGICAL_REGEX_ICD;
        if (systemListValues.beginValue.match(ICD10)) {
          showDiagNumericBeginValueError = false;
          setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
          showDiagNumericBeginValueErrorText = SystemListSearchConstants.INVALID_SURG_PROC_CODE;
        } else {
          showDiagNumericBeginValueError = true;
          setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
          showDiagNumericBeginValueErrorText = SystemListSearchConstants.INVALID_SURG_PROC_CODE;
        }
      }
      showBeginValueError = false;
    }

    if (systemListValues.endValue === '') {
      if (values.listType === 'UIS' || values.listType === 'XWK') {
        showEndValueError = false;
        setShowError({ showEndValueError: showEndValueError });
      } else {
        showEndValueError = true;
        setShowError({ showEndValueError: showEndValueError });
        showEndValueErrorText = SystemListSearchConstants.ENDVALUE_REQUIRED;
      }
    } else {
      if (dataElementNameValue === 'R_REV_CD') {
        const numbers = /^[0-9]+$/;
        // BEGIN VALUE CHECK
        if (systemListValues.beginValue.length === 4) {
          showRevenueCodeEndValueError = false;
          if (systemListValues.endValue.match(numbers)) {
            showRevenueCodeBeginValueError = false;
            setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
          } else {
            showRevenueCodeEndValueError = true;
            setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
            showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE;
          }
        } else {
          showRevenueCodeEndValueError = true;
          setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
          showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE;
        }

        if (systemListValues.endValue.length === 4) {
          showRevenueCodeEndValueError = false;
          if (systemListValues.endValue.match(numbers)) {
            showRevenueCodeBeginValueError = false;
            setShowError({ showRevenueCodeEndValueError: showRevenueCodeEndValueError });
          } else {
            showRevenueCodeEndValueError = true;
            setShowError({ showRevenueCodeEndValueError: showRevenueCodeEndValueError });
            showEndValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_ENDVALUE;
          }
        } else {
          showRevenueCodeEndValueError = true;
          setShowError({ showRevenueCodeEndValueError: showRevenueCodeEndValueError });
          showEndValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_ENDVALUE;
        }
      }
      if (dataElementNameValue === 'R_DIAG_CD') {
        const test = SystemListConstants.ADDVALUE_REGEX;
        if (!(isNaN(systemListValues.endValue))) {
          if (systemListValues.endValue.match(test)) {
            showDiagNumericEndValueError = false;
            setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
            showDiagNumericEndValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
          } else {
            showDiagNumericEndValueError = true;
            setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
            showDiagNumericEndValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
          }
        }
      }

      if (dataElementNameValue === 'R_SURG_PROC_CD') {
        const test = SystemListConstants.SURGICAL_REGEX;
        const ICD10 = SystemListConstants.SURGICAL_REGEX_ICD;
        if (systemListValues.endValue.match(ICD10)) {
          showDiagNumericEndValueError = false;
          setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
          showDiagNumericEndValueErrorText = SystemListSearchConstants.INVALID_SURG_PROC_CODE;
        } else {
          showDiagNumericEndValueError = true;
          setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
          showDiagNumericEndValueErrorText = SystemListSearchConstants.INVALID_SURG_PROC_CODE;
        }
      }
      showEndValueError = false;
    }

    // Begin Value validation
    if (systemListValues.beginValue !== '' && systemListValues.endValue !== '' && !isNaN(systemListValues.beginValue) &&
      !isNaN(systemListValues.endValue) && +systemListValues.beginValue > +systemListValues.endValue && !showRevenueCodeBeginValueError &&
      !showDiagNumericBeginValueError && !showBeginValueError && values.listType !== 'UIS') {
      showBeginValueError = true;
      setShowError({ showBeginValueError: showBeginValueError });
      showBeginValueErrorText = SystemListSearchConstants.BEGINVALUE_INVALID_TEXT;
    }

    // date validations
    if (selectedBeginDate) {
      if (selectedBeginDate.toString() !== 'Invalid Date') {
        if (validateDateMinimumValue(selectedBeginDate)) {
          showBeginDateError = true;
          setShowError({ showBeginDateError: showBeginDateError });
          showBeginDateErrorText = AppConstants.DATE_ERROR_1964;
        }
      } else {
        showBeginDateError = true;
        setShowError({ showBeginDateError: showBeginDateError });
        showBeginDateErrorText = SystemListSearchConstants.BEGIN_DATE_INVALID;
      }
    } else {
      showBeginDateError = true;
      setShowError({ showBeginDateError: showBeginDateError });
      showBeginDateErrorText = SystemListSearchConstants.BEGIN_DATE_REQUIRED;
    }
    if (selectedEndDate) {
      if (selectedEndDate.toString() !== 'Invalid Date') {
        if (validateDateMinimumValue(selectedEndDate)) {
          showEndDateError = true;
          setShowError({ showEndDateError: showEndDateError });
          showEndDateErrorText = AppConstants.DATE_ERROR_1964;
        }
      } else {
        showEndDateError = true;
        setShowError({ showEndDateError: showEndDateError });
        showEndDateErrorText = SystemListSearchConstants.END_DATE_INVALID;
      }
    } else {
      showEndDateError = true;
      setShowError({ showEndDateError: showEndDateError });
      showEndDateErrorText = SystemListSearchConstants.END_DATE_REQUIRED;
    }
    if (
      selectedBeginDate &&
      selectedEndDate &&
      !showBeginDateError &&
      !showEndDateError &&
      compareTwoDatesGreaterThanOrEqual(selectedEndDate, selectedBeginDate)
    ) {
      showBeginDateError = true;
      setShowError({ showBeginDateError: showBeginDateError });
      showBeginDateErrorText = SystemListSearchConstants.BEGIN_DATE_LESS;
    }
    setShowError({
      showEndDateValidError: showEndDateValidError,
      showLobCodeError: showLobCodeError,
      showBeginValueError: showBeginValueError,
      showEndValueError: showEndValueError,
      showBeginDateError: showBeginDateError,
      showEndDateError: showEndDateError,
      showRevenueCodeBeginValueError: showRevenueCodeBeginValueError,
      showRevenueCodeEndValueError: showRevenueCodeEndValueError,
      showDiagNumericBeginValueError: showDiagNumericBeginValueError,
      showDiagNumericEndValueError: showDiagNumericEndValueError

    });

    setShowErrorText({
      showLobCodeErrorText: showLobCodeErrorText,
      showBeginValueErrorText: showBeginValueErrorText,
      showEndValueErrorText: showEndValueErrorText,
      showBeginDateErrorText: showBeginDateErrorText,
      showEndDateErrorText: showEndDateErrorText,
      showRevenueCodeBeginValueErrorText: showRevenueCodeBeginValueErrorText,
      showRevenueCodeEndValueErrorText: showRevenueCodeEndValueErrorText,
      showDiagNumericBeginValueErrorText: showDiagNumericBeginValueErrorText,
      showDiagNumericEndValueErrorText: showDiagNumericEndValueErrorText
    });

    if (showLobCodeError && showBeginValueError && showEndValueError && showBeginDateError && showEndDateError) {
      return false;
    } else {
      if (showLobCodeError) {
        return false;
      }
      if (showBeginValueError) {
        return false;
      }
      if (showRevenueCodeBeginValueError && showRevenueCodeEndValueError) {
        return false;
      }
      if (showRevenueCodeBeginValueError) {
        return false;
      }
      if (showRevenueCodeEndValueError) {
        return false;
      }
      if (showDiagNumericBeginValueError) {
        return false;
      }
      if (showDiagNumericEndValueError) {
        return false;
      }
      if (showDiagNumericEndValueError && showDiagNumericBeginValueError) {
        return false;
      }
      if (showEndValueError) {
        return false;
      }
      if (showBeginDateError) {
        return false;
      }
      if (showEndDateError) {
        return false;
      } else {
        return true;
      }
    }
  };

  


  const saveAddSystemList = () => {
  console.log("loginuserid","984",loginUserDetails.loginUserName)
  notesInput.auditUserID=loginUserDetails.loginUserName
  notesInput. addedAuditUserID=loginUserDetails.loginUserName
  //tableData[0].lineofbusiness="MED"
  //tableData[0].addedAuditUserID= "RSHANK"
  //tableData[0].auditTimeStamp= getUTCTimeStamp()
  //tableData[0].addedAuditTimeStamp=getUTCTimeStamp()
  //console.log(tableData,"tableDate")


    if (checkFormValidations()) {
      setErrorMessages([]);
      setSuccessMessages([]);
      if (tableData.length > 0) {
        const value = {
          auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          auditTimeStamp: getUTCTimeStamp(),
          addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          addedAuditTimeStamp: getUTCTimeStamp(),
          dbRecord: false,
          sortColumn: null,
          auditKeyList: [],
          auditKeyListFiltered: false,
          listNumber: values.listNumber,
          deletedSystemListDetails: [],
          description: values.description,
          functionalArea: values.functionalArea,
          listBusinessName: values.businessName,
          listType: values.listType,
          systemListDetails:  tableData,
          dataElementName: values.dataElementName,
          groupAssignmentList: null,
          mapSetIds: [],
          noteSet: null,
          length: 0,
          format: null,
          columnName: null,
          sourceTableName: null,
          nameChange: null,
          columnScaleNumber: null,
          noteSetVO:/*notesInputses*/ notesInput
        };
        
        setAllowNavigation(false);
        onAddSystemList(value, logInUserID ? logInUserID : 'BTAYLOR1');
      }
  }};
 

  const onClickeditSystemList = data => event => {
    console.log(data);
    setEditData(data);
    setRetainEdit(data);
    setOpenCrossReference(true);
    setSystemListValues({
      lob: data.lineofbusiness,
      beginValue: data.startingValue,
      endValue: data.endingValue,
      sortOrder: data.sortNum
    });
    setSelectedEndDate(data.endDate);
    setSelectedBeginDate(data.beginDate);
    setShowError(false);
    setAdd(false);
  };

  const rowDeleteSystemListDetails = data => {
    setRowSystemListDetailData({ ...rowSystemListDetailData, rowSystemListDetailData: data });
  };

  function systemListDetailRowDeleteClick() {
    let temNewDialogData = [...tableData];
    if (rowSystemListDetailData.rowSystemListDetailData) {
      for (let i = 0; i < rowSystemListDetailData.rowSystemListDetailData.length; i++) {
        if (rowSystemListDetailData.rowSystemListDetailData[i] !== undefined) {
          temNewDialogData = temNewDialogData.filter(payment => payment.id !== rowSystemListDetailData.rowSystemListDetailData[i]);
        }
      }
    };
    // updateTableData(temNewDialogData);
    setTableData(temNewDialogData);
    setRowSystemListDetailData([]);
  }

  // notes
  let notesDataArray = [];
  const addNotes = (data) => {
    setAllowNavigation(true);
    console.log(data);
    const noteText = data;
    notesDataArray = notesTableData;
    notesDataArray.push(noteText);
    setNotesTableData(notesDataArray);
    setNotesInput({ ...notesInput, notesList: notesDataArray });
  };
  console.log(isErrorSavingData,"state","systemListState")

  const handelPromptSet = (set) => {
    if (set)
        setPrompt(true);
  }

  return (
    <div>
       <UnsavedChangesMessage allowNavigation={allowNavigation} handelPromptSet={handelPromptSet}
        confirm={confirm} cancelType={cancelType} prompt={prompt} setCancelType={setCancelType}
        setPrompt={setPrompt}/>
     {isErrorSavingData===true && "unable to save recodes"}
      
      <div className="tabs-container" ref={toPrintRef}>
      <ErrorMessages errorMessages={errorMessages} />
        <div className="tab-header">
          <div className="tab-heading float-left">
            Add System List
          </div>
          <div className="float-right  mt-2 hide-on-print">
            <Button variant="outlined" color="primary" className='btn btn-success' onClick={saveAddSystemList}
            >
              <i class="fa fa-check" aria-hidden="true"></i>
              Save

            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (<Button className='btn btn-primary ml-1' >
                <i class="fa fa-print" aria-hidden="true"></i>
                Print
              </Button>)}
              content={() => toPrintRef.current}
            />

            <Button color="primary" className='btn btn-secondary ml-1'
            >
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div className="tab-body">
          <div className="MuiCollapse-container MuiCollapse-entered">
            <div className="MuiCollapse-wrapper">
              <form autoComplete="off" className="form-wrapper">
                <div className="form-wrapper">
                  <div className="mui-custom-form with-select with-select input-md">
                    <TextField
                      id="standard-select-functionalArea"
                      fullWidth
                      required
                      select
                      label="Functional Area"
                      value={values.functionalArea}
                      SelectProps={{
                        MenuProps: {
                          className: classes.menu
                        }
                      }}
                      onChange={handleChanges('functionalArea')}
                      placeholder=""

                      InputLabelProps={{
                        shrink: true
                      }}
                      helperText={showFunctionalAreaError ? showFunctionalAreaErrorText : null}
                      error={showFunctionalAreaError ? showFunctionalAreaErrorText : null}
                    >
                      <MenuItem selected key="Please Select One" value="Please Select One">
                        Please Select One
                      </MenuItem>
                      {functionalAreaData ? functionalAreaData.map((option, index) => (
                        <MenuItem key={index} value={option.code}>
                          {option.description}
                        </MenuItem>
                      )) : null}

                    </TextField>
                  </div>
                  <div className="mui-custom-form input-md" // style={{ marginLeft: '54px' }}
                  >
                    <TextField
                      id="standard-listNumber"
                      fullWidth
                      required
                      label="List Number"
                      type="number"
                      value={values.listNumber}
                      onChange={handleChanges('listNumber')}
                      placeholder=""
                      InputLabelProps={{
                        shrink: true
                      }}
                      onInput={(e) => {
                        e.target.value = Math.max(0, parseInt(e.target.value)).toString().slice(0, 10);
                      }}
                      onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                      inputProps={{ maxLength: 10 }}
                      helperText={showListNumberError ? showListNumberErrorText : null}
                      error={showListNumberError ? showListNumberErrorText : null}
                    />
                  </div>

                  <div className="mui-custom-form with-select input-xl" // style={{ marginLeft: '45px' }}
                  >
                    <TextField
                      id="standard-select-functionalArea"
                      fullWidth
                      select
                      required
                      label="Data Element Name"
                      value={values.dataElementName}
                      onChange={handleChanges('dataElementName')}
                      SelectProps={{
                        MenuProps: {
                          className: classes.menu
                        }
                      }}
                      placeholder=""

                      InputLabelProps={{
                        shrink: true
                      }}
                      helperText={showDataElementNameError ? showDataElementNameErrorText : null}
                      error={showDataElementNameError ? showDataElementNameErrorText : null}
                    >
                      <MenuItem selected key="Please Select One" value="Please Select One">
                        Please Select One
                      </MenuItem>
                      {dataElementNameData ? dataElementNameData.map((option, index) => (
                        <MenuItem key={index} value={option}>
                          {option}
                        </MenuItem>
                      )) : null}
                    </TextField>
                  </div>
                  <div className="mui-custom-form with-select input-md" // style={{ marginLeft: '39px' }}
                  >
                    <TextField
                      id="standard-select-functionalArea"
                      fullWidth
                      required
                      select
                      label="List Type"
                      value={values.listType}
                      onChange={handleChanges('listType')}
                      SelectProps={{
                        MenuProps: {
                          className: classes.menu
                        }
                      }}
                      placeholder=""

                      InputLabelProps={{
                        shrink: true
                      }}
                      helperText={showListTypeError ? showListtypeErrorText : null}
                      error={showListTypeError ? showListtypeErrorText : null}
                    >
                      <MenuItem selected key="Please Select One" value="Please Select One">
                        Please Select One
                      </MenuItem>
                      {listTypeData ? listTypeData.map((option, index) => (
                        <MenuItem key={index} value={option.code}>
                          {option.description}
                        </MenuItem>
                      )) : null}
                    </TextField>
                  </div>
                </div>
                <div className="form-wrapper">
                  <div className="mui-custom-form input-md">
                    <TextField
                      id="standard-Description"
                      fullWidth
                      required
                      label="Description"
                      value={values.description}
                      onChange={handleChanges('description')}
                      placeholder=""
                      InputLabelProps={{
                        shrink: true
                      }}
                      inputProps={{ maxLength: 320 }}
                      helperText={showDescriptionError ? showDescriptionErrorText : null}
                      error={showDescriptionError ? showDescriptionErrorText : null}
                    />
                  </div>
                  <div className="mui-custom-form input-xl" // style={{ marginLeft: '30px' }}
                  >
                    <TextField
                      id="standard-businessName"
                      fullWidth
                      required
                      label="Business Name"
                      value={values.businessName}
                      onChange={handleChanges('businessName')}
                      placeholder=""
                      InputLabelProps={{
                        shrink: true
                      }}
                      inputProps={{ maxLength: 50 }}
                      helperText={showBusinessNameError ? showBusinessNameErrorText : null}
                      error={showBusinessNameError ? showBusinessNameErrorText : null}

                    />
                  </div>
                  <div className="mui-custom-form input-sm" // style={{ marginLeft: '216px' }}
                  >
                    <TextField
                      disabled
                      id="standard-usedin-mapset"
                      fullWidth
                      label="Used in Mapset"
                      value='Map ID'
                      // onChange={handleChanges('businessName')}
                      placeholder=""
                      InputLabelProps={{
                        shrink: true
                      }}
                    />
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div>
          </div>
          <div className='tab-panelbody m-0'>
            <div className="tab-holder tab-holders">

              <AppBar position="static">
                <Tabs value={value} onChange={handleChangeTabs} aria-label="simple tabs example">
                  <Tab label="System List Detail" />
                  <Tab label="Notes" />
                </Tabs>
              </AppBar>
              <TabPanel className={printLayout ? 'hide-on-screen' : ''} value={printLayout ? 0 : value} index={0}>
                <div className="my-3 tab-holder  ">
                  <div className="float-right mb-3 hide-on-print">
                    <Button className="btn-text btn-transparent" onClick={systemListDetailRowDeleteClick}>
                      <i class="fa fa-trash" aria-hidden="true"></i>
                      Delete
                    </Button>
                    <Button variant="outlined" color="primary" className="btn btn-success ml-1"
                      onClick={() => handleClickOpen()}
                    >
                      <i class="fa fa-plus" aria-hidden="true"></i>
                      Add System List Detail</Button>
                  </div>
                  <div className="clearfix"></div>
                  <h4 className="hide-on-screen mt-2"><span class="badge badge-primary">Add System List Detail</span></h4>
                  <SystemListAddTable tableData={tableData} onEditSystemlistDetail={onClickeditSystemList} rowDeleteSystemListDetails={rowDeleteSystemListDetails} />
                </div>
              </TabPanel>
              <TabPanel className={printLayout ? 'hide-on-screen' : ''} value={printLayout ? 1 : value} index={1}>
                <NotesComponent
                  addNotes = {addNotes}
                  notesTableData = {notesTableData}
                  noteSetListInput = {noteSetListInput}
                  setNoteSetListInput = {setNoteSetListInput}
                  usageTypeCodeData= {usageTypeCodeData}
                  editNoteData = {editNoteData}
                  setEditNoteData = {setEditNoteData}
                />
              </TabPanel>
              {
                showSystemlistValueTable

                  ? <div>
                    <div className="tabs-container">
                      <div className="tab-header">
                        <div className="tab-heading float-left">
                          Add List Value
                        </div>
                        <form autoComplete="off">

                          <div className="clearfix"></div>

                        </form>
                      </div>
                    </div>
                  </div> : null
              }
              <Footer print />
              <Dialog className="custom-dialog"

                open={openCrossReference} fullWidth={'xxl'}>
                <DialogTitle id="customized-dialog-title" onClose={handleCloseCrossReference}>
                  {
                    add ? 'Add System List Details' : 'Edit System List Details'
                  }
                </DialogTitle>
                <DialogContent dividers>
                  <form>
                    <div className="form-wrapper">
                      <div className="mui-custom-form with-select override-width-31 m-2" style={{width:'168px'}}>
                        <TextField
                          id="standard-select-functionalArea"
                          fullWidth
                          select
                          required
                          label="LOB"
                          value={systemListValues.lob}
                          onChange={handleSystemListChanges('lob')}
                          placeholder=""
                          InputLabelProps={{
                            shrink: true
                          }}
                          helperText={showLobCodeError ? showLobCodeErrorText : null}
                          error={showLobCodeError ? showLobCodeErrorText : null}
                        >
                          <MenuItem selected key="Please Select One" value="Please Select One">
                            Please Select One
                          </MenuItem>
                          {lobCodeData ? lobCodeData.map((option, index) => (
                            <MenuItem key={index} value={option.code}>
                              {option.description}
                            </MenuItem>
                          )) : null}
                        </TextField>
                      </div>

                      {
                        values.listType === 'UIS'
                          ? <div className="mui-custom-form override-width-30 m-2" style={{width:'168px'}}>
                            <TextField
                              id="constant-text"
                              fullWidth
                              label="Sort Order"
                              value={systemListValues.sortOrder}
                              onChange={handleSystemListChanges('sortOrder')}
                              InputLabelProps={{
                                shrink: true
                              }}
                              inputProps={{ maxLength: 10 }}
                              onInput={e => {
                                e.target.value = e.target.value.replace(
                                  AppConstants.NUMBER_ONLY_REGEX,
                                  ''
                                );
                              }}
                            />
                          </div> : null
                      }

                      <div className="mui-custom-form override-width-30 m-2" style={{width:'168px'}}>
                        <TextField
                          id="beginValue"
                          fullWidth
                          label="Begin Value"
                          required
                          inputProps={{ maxLength: 30 }}
                          value={systemListValues.beginValue}
                          onChange={handleSystemListChanges('beginValue')}
                          InputLabelProps={{
                            shrink: true
                          }}
                          helperText={(showBeginValueError || showRevenueCodeBeginValueError) ? showBeginValueErrorText : (showDiagNumericBeginValueError ? showDiagNumericBeginValueErrorText : null)}
                          error={(showBeginValueError || showRevenueCodeBeginValueError) ? showBeginValueErrorText : (showDiagNumericBeginValueError ? showDiagNumericBeginValueErrorText : null)}
                        />
                      </div>
                      {
                        values.listType === 'PRC'
                          ? <div className="mui-custom-form override-width-31 m-2" style={{width:'168px'}}>
                            <TextField
                              key="sl_u_begv"
                              id="endValue"
                              fullWidth
                              required
                              label="End Value"
                              value={systemListValues.endValue}
                              inputProps={{ maxLength: 30 }}
                              onChange={handleSystemListChanges('endValue')}
                              InputLabelProps={{
                                shrink: true
                              }}
                              helperText={(showEndValueError || showRevenueCodeEndValueError) ? showEndValueErrorText : (showDiagNumericEndValueError ? showDiagNumericEndValueErrorText : null)}
                              error={(showEndValueError || showRevenueCodeEndValueError) ? showEndValueErrorText : (showDiagNumericEndValueError ? showDiagNumericEndValueErrorText : null)}
                            />
                          </div> : null
                      }
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <div className="mui-custom-form with-date override-width-31 m-2" style={{width:'168px'}}>
                          <KeyboardDatePicker
                            maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                            id="date-picker-dialog-begindate"
                            fullWidth
                            label="Begin Date"
                            required
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                              shrink: true
                            }}
                            placeholder="mm/dd/yyyy"
                            value={selectedBeginDate}
                            onChange={setSelectedBeginDate}

                            helperText={showBeginDateError ? showBeginDateErrorText : null}
                            error={showBeginDateError ? showBeginDateErrorText : null}
                            KeyboardButtonProps={{
                              'aria-label': 'change date'
                            }}
                          />
                        </div>
                        {values.listType === 'PRC'
                          ? <div className="mui-custom-form with-date override-width-28 m-2" style={{width:'168px'}}>
                            <KeyboardDatePicker
                              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                              id="date-picker-dialog-enddate"
                              fullWidth
                              label="End Date"
                              required
                              helperText={null}
                              format="MM/dd/yyyy"
                              InputLabelProps={{
                                shrink: true
                              }}
                              maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                              error={false}
                              placeholder="mm/dd/yyyy"
                              value={selectedEndDate}
                              onChange={setSelectedEndDate}
                              KeyboardButtonProps={{
                                'aria-label': 'change date'
                              }}

                              helperText={showEndDateError ? showEndDateErrorText : null}
                              error={showEndDateError ? showEndDateErrorText : null}
                            />
                          </div>
                          : <div className="mui-custom-form with-date override-width-28 m-2" style={{width:'168px'}}>
                            <KeyboardDatePicker
                              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                              id="date-picker-dialog-enddate"
                              fullWidth
                              label="End Date"
                              required
                              helperText={null}
                              format="MM/dd/yyyy"
                              InputLabelProps={{
                                shrink: true
                              }}
                              maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                              error={false}
                              placeholder="mm/dd/yyyy"
                              value={selectedEndDate}
                              onChange={setSelectedEndDate}
                              KeyboardButtonProps={{
                                'aria-label': 'change date'
                              }}

                              helperText={showEndDateError ? showEndDateErrorText : null}
                              error={showEndDateError ? showEndDateErrorText : null}
                            />
                          </div>
                        }

                      </MuiPickersUtilsProvider>

                      {/* {
                        values.listType === 'PRC'
                          ? <div className="mui-custom-form override-width-28">
                            <TextField
                              key="sl_u_begv"
                              id="endValue"
                              fullWidth
                              required
                              label="End Value"
                              value={systemListValues.endValue}
                              inputProps={{ maxLength: 30 }}
                              onChange={handleSystemListChanges('endValue')}
                              InputLabelProps={{
                                shrink: true
                              }}
                              helperText={(showEndValueError || showRevenueCodeEndValueError) ? showEndValueErrorText : (showDiagNumericEndValueError ? showDiagNumericEndValueErrorText : null)}
                              error={(showEndValueError || showRevenueCodeEndValueError) ? showEndValueErrorText : (showDiagNumericEndValueError ? showDiagNumericEndValueErrorText : null)}
                            />
                          </div> : null
                      } */}

                      
                    </div>
                  </form>
                </DialogContent>

                <DialogActions>
                  {
                    add
                      ? <div>
                        <Button variant="outlined" color="primary" className="btn btn-success ml-1" onClick={addSystemListValuesToTable}>
                          <i class="fa fa-plus" aria-hidden="true"></i>
                          Add </Button>

                        <Button variant="outlined" color="primary" className='bt-reset btn-transparent  ml-1' onClick={resetSystemListValues}>
                          <i class="fa fa-undo" aria-hidden="true"></i> Reset </Button>
                      </div>
                      : <div>
                        <Button variant="outlined" color="primary" className='btn btn-primary mr-1' onClick={addSystemListValuesToTable}>
                          Update </Button>

                        <Button variant="outlined" color="primary" className='bt-reset btn-transparent  ml-1' onClick={resetSystemListValues}>
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset </Button>
                      </div>
                  }
                </DialogActions>
              </Dialog>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}