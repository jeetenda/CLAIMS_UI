/* eslint-disable no-unused-vars */
import React, { Component, useState, useEffect, useRef } from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import { useDispatch, useSelector } from 'react-redux';
import Dialog from '@material-ui/core/Dialog';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import { systemListViewAction, updateSystemList, getSubDropdownDataAction } from '../../../Store/Actions/systemList/systemListActions';
import * as moment from 'moment';
import * as SystemListConstants from '../systemListConstants';
import { generateUUID, validateDateMinimumValue, compareTwoDatesGreaterThanOrEqual, getUTCTimeStamp } from '../../../../../SharedModules/DateUtilities/DateUtilities';
import NoSaveMessage from '../../../../../SharedModules/Errors/NoSaveMessage';
import { AppConfigDropdownActions, DataElementDropdownActions } from '../../../Store/Actions/AppConfigCommon/AppConfigActions';
import {
  MuiPickersUtilsProvider,
  KeyboardDatePicker
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import 'date-fns';
import SystemListAddTable from './SystemListAddTable';
import MapsetIdTable from './MapsetIdTable';
import * as SystemListSearchConstants from './SystemListSearchConstants';
import { Prompt } from 'react-router-dom';
import Spinner from '../../../../../SharedModules/Spinner/Spinner';
import dropdownCriteria from './SystemListAddUpdate.json';
import TabPanel from '../../../../../SharedModules/TabPanel/TabPanel';
import { DialogTitle, DialogActions, DialogContent } from '../../../../../SharedModules/Dialog/DialogUtilities';
import ErrorMessages from '../../../../../SharedModules/Errors/ErrorMessages';
import SuccessMessages from '../../../../../SharedModules/Errors/SuccessMessage';
import * as AppConstants from '../../../../../SharedModules/AppConstants';
import Notes from '../../../../../SharedModules/Notes/Notes';

import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../../../SharedModules/Store/Actions/SharedAction';
import Footer from '../../../../../SharedModules/Layout/footer';
import PropsInit from '../../../../../SharedModules/Navigation/NavHOC';
import UnsavedChangesMessage from '../../../../../SharedModules/Errors/UnsavedChangesMessage';
import './SystemListAddUpdate.css'
const newData = [];

// {Wrapped, url, action=null, selector="", historyStateName=""}
export default PropsInit({ Wrapped: SearchListAdd, url: '/SystemListAddUpdate' });

function SearchListAdd (props) {
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const toPrintRef = useRef();

  console.log(props.history.location.state.searchSwapJson);
  const dispatch = useDispatch();
  const dropDownDispatch = dropdownvalues => dispatch(AppConfigDropdownActions(dropdownvalues));
  const dataElemDropDownDispatch = () => dispatch(DataElementDropdownActions());
  const usageTypeDropDown = usageTypeCodeInput => dispatch(getSubDropdownDataAction(usageTypeCodeInput));

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
    dataElemDropDownDispatch();
    usageTypeDropDown(usageTypeCodeInput);
  }, []);
  const usageTypeCodeDropDown = useSelector(state => state.appConfigState.systemListState.usageDropDown);
  const [searchCriteriarowClick, setSearchCriteriarowClick] = React.useState(props.history.location.state.searchSwapJson);
  const onRowClick = () => dispatch(systemListViewAction(searchCriteriarowClick));
  const onUpdateSystemList = (value) => dispatch(updateSystemList(value));
  const [systemListAddTableData, setSystemListAddTableData] = React.useState([]);
  const [add, setAdd] = React.useState(true);
  const [allowNavigation, setAllowNavigation] = React.useState(false);
  const [LoadSpinner, setSpinnerLoader] = React.useState(false);
  const logInUserID = useSelector(state => state.sharedState.logInUserID);

  useEffect(() => {
    console.log(usageTypeCodeDropDown);
    if (usageTypeCodeDropDown) {
      if (usageTypeCodeDropDown.listObj) {
        const usage = usageTypeCodeDropDown.listObj['General#G_NOTE_TY_CD'];
        setUsageTypeCodeData(usage);
      }
    }
  }, [usageTypeCodeDropDown]);

  let dropdown = [];
  useEffect(() => {
    onRowClick();
  }, []);
  useEffect(() => {
    onRowClick();
  }, [props.history.location.state]);
  let errorMessagesArray = [];
  const successMessagesArray = [];
  const [redirectToMapset, setRedirectToMapset] = React.useState(false);
  const [openMapsetDialog, setOpenMapsetDialog] = React.useState(false);
  // const [closeMapsetPopUpDialog, setCloseMapsetPopUpDialog] = React.useState(false);
  const redirectPageToMapsetAdd = event => {
    setRedirectToMapset(true);
  };
  const openMapsetPopUpDialog = event => {
    setOpenMapsetDialog(true);
  };
  const closeMapsetPopUpDialog = event => {
    setOpenMapsetDialog(false);
  };
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [listTypeData, setListTypeData] = React.useState([]);
  const [dataElementNameData, setDataElementNameData] = React.useState([]);
  const [lobCodeData, setLobCodeData] = React.useState([]);

  const [voidedData, setVoidedData] = React.useState([]);
  const [nonVoidedData, setNonVoidedData] = React.useState([]);
  const [retainEdit, setRetainEdit] = React.useState({});

  const [tempNonVolatile, setTempNonVolatile] = React.useState([]);
  const [tempConcat, setTempConcat] = React.useState([]);
  const [isFilterEnable, setIsFilterEnable] = React.useState(false);
  const [rowSystemListDetailData, setRowSystemListDetailData] = React.useState([]);
  const [tableData, setTableData] = React.useState([]);
  const [MapIdList, setMapIdList] = React.useState([]);

  const [prompt, setPrompt] = useState(false);
  const [cancelType, setCancelType] = useState(false);
  const [confirm, setConfirm] = useState(false);

  const payloadData = useSelector(state => state.appConfigState.systemListState.systemListViewData);
  console.log(payloadData);
  // let tableData = [];

  let voidDateArray = [];
  let nonVoidDateArray = [];

  const userInquiryPrivileges = true;
  useEffect(() => {
    console.log('useEffect add system list payload');
    console.log(props.history.location.state.searchSwapJson.SuccessMessages);
    if (payloadData !== undefined) {
      setSystemListAddTableData([]);
      setValues({
        functionalArea: payloadData ? payloadData[0].functionalArea : null,
        listNumber: payloadData ? payloadData[0].listNumber : null,
        businessName: payloadData ? payloadData[0].listBusinessName : null,
        dataElementName: payloadData ? payloadData[0].dataElementName : null,
        listType: payloadData ? payloadData[0].listType : null,
        usedInMapSet: 'No Data',
        description: payloadData ? payloadData[0].description : null
      });
      setMapIdList(payloadData ? payloadData[0].mapSetIds : []);
      if (props.history.location.state.searchSwapJson.SuccessMessages) {
        setSuccessMessages(props.history.location.state.searchSwapJson.SuccessMessages);
      }
      if (payloadData[0].noteSetVO) {
        const noteSetVO = payloadData[0].noteSetVO;
        const notesTable = payloadData[0].noteSetVO.notesList;
        setNotesInput({
          auditUserID: payloadData[0].noteSetVO.auditUserID ? payloadData[0].noteSetVO.auditUserID : 'BTAYLOR1',
          auditTimeStamp: noteSetVO.auditTimeStamp ? noteSetVO.auditTimeStamp : null,
          addedAuditUserID: noteSetVO.addedAuditUserID ? noteSetVO.addedAuditUserID : 'BTAYLOR1',
          addedAuditTimeStamp: noteSetVO.addedAuditTimeStamp ? noteSetVO.addedAuditTimeStamp : null,
          versionNo: noteSetVO.versionNo,
          dbRecord: noteSetVO.dbRecord,
          sortColumn: noteSetVO.sortColumn,
          tableName: noteSetVO.tableName,
          noteSetSK: noteSetVO.noteSetSK,
          noteSourceName: noteSetVO.noteSourceName,
          notesList: notesTableData,
          globalNotesList: [],
          checkAll: noteSetVO.checkAll,
          addNewLinkRender: noteSetVO.addNewLinkRender,
          filterLinkRender: noteSetVO.filterLinkRender,
          printLinkRender: noteSetVO.printLinkRender,
          completeNotesList: []
        });
        console.log(notesTable);
        setNotesTableData(notesTable);
      }
      //setSuccessMessages(props.history.location.state.searchSwapJson.SuccessMessages ? props.history.location.state.searchSwapJson.SuccessMessages : []);
      if (payloadData && payloadData.length > 0 && payloadData[0].systemListDetails) {
        nonVoidDateArray = [];
        voidDateArray = [];

        payloadData[0].systemListDetails.map((option, index) => {
          if (option.voidDate) {
            voidDateArray.push(option);
            setVoidedData(voidDateArray);
          } else {
            nonVoidDateArray.push(option);
            setNonVoidedData(nonVoidDateArray);
          }
        });
      }
      setSystemListAddTableData(payloadData ? nonVoidDateArray : []);
      setTableData(payloadData ? payloadData[0].systemListDetails : []);
    }
  }, [payloadData]);

  useEffect(() => {
    const nonVoidDateArray = [];
    const voidDateArray = [];
    tableData.map((option, index) => {
      if (option.voidDate) {
        voidDateArray.push(option);
        setVoidedData(voidDateArray);
      } else {
        nonVoidDateArray.push(option);
        setNonVoidedData(nonVoidDateArray);
      }
    });
  }, [tableData]);

  dropdown = useSelector(state => state.appConfigState.AppConfigCommonState.appConfigDropdown);
  const datElemDropdown = useSelector(state => state.appConfigState.AppConfigCommonState.dataElementNameDropdown);

  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj['Reference#1017']) {
        setFunctionalAreaData(dropdown.listObj['Reference#1017']);
      }
      if (dropdown.listObj['Reference#2']) {
        setListTypeData(dropdown.listObj['Reference#2']);
      }
      if (dropdown.listObj['Reference#1019']) {
        setLobCodeData(dropdown.listObj['Reference#1019']);
      }
    }
  }, [dropdown]);

  useEffect(() => {
    if (datElemDropdown && datElemDropdown.listDataElements) {
      setDataElementNameData(datElemDropdown.listDataElements);
    }
  }, [datElemDropdown]);

  const handleChanges = name => event => {
    setAllowNavigation(true);
    console.log('handleChanges');
    console.log(name, event);
    setValues({ ...values, [name]: event.target.value });
    if (name === 'dataElementName') {
      setDataElementNameValue(event.target.value);
    }
  };
  const [openCrossReference, setOpenCrossReference] = React.useState(false);

  const [{
    showFunctionalAreaError, showListNumberError, showDataElementNameError, showListTypeError,
    showDescriptionError, showBusinessNameError,
    showLobCodeError, showBeginValueError,
    showEndValueError, showBeginDateError,
    showEndDateError,
    showRevenueCodeBeginValueError, showRevenueCodeEndValueError, showDiagNumericEndValueError, showDiagNumericBeginValueError
  }, setShowError] = React.useState(false);
  const [dataElementNameValue, setDataElementNameValue] = React.useState('');

  const [{
    showDescriptionErrorText,
    showListtypeErrorText,
    showListNumberErrorText,
    showFunctionalAreaErrorText,
    showDataElementNameErrorText,
    showBusinessNameErrorText,
    showLobCodeErrorText,
    showBeginValueErrorText,
    showEndValueErrorText,
    showBeginDateErrorText,
    showEndDateErrorText,
    showRevenueCodeBeginValueErrorText,
    showDiagNumericBeginValueErrorText,
    showDiagNumericEndValueErrorText
  }, setShowErrorText] = React.useState('');

  const handleCloseCrossReference = () => {
    setOpenCrossReference(false);
    setShowErrorText('');
    setBeginValueValidation(false)
    setEndValueValidation(false)
  };

  const [values, setValues] = React.useState({
    functionalArea: 'Please Select One',
    listNumber: '',
    businessName: '',
    dataElementName: 'Please Select One',
    listType: 'Please Select One',
    usedInMapSet: 'No Data',
    description: ''
  });
  const [showSystemlistValueTable, setShowSystemlistValueTable] = React.useState(false);
  const [showAdditionalDetails1, setShowAdditionalDetails1] = React.useState(false);
  const [value, setValue] = React.useState(0);
  const [open, setOpen] = React.useState(false);
  const [dataElement, setDataElement] = React.useState({
    id: 0,
    dataElementName: '',
    businessName: '',
    description: ''

  });

  const [addSystemlistValues, setAddSystemListValues] = React.useState({});
  const [successMessages, setSuccessMessages] = React.useState([]);

React.useEffect(()=>{
  console.log(successMessages,"sucessMessages")
})

  const [concatbothvoidandnonvoid, setConcatbothVoidAndNonVoid] = React.useState([]);

  // notes

  const [notesTableData, setNotesTableData] = React.useState([]);
  const [notesInput, setNotesInput] = React.useState({

    auditUserID: 'BTAYLOR1',
    auditTimeStamp: null,
    addedAuditUserID: 'BTAYLOR1',
    addedAuditTimeStamp: null,
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    tableName: null,
    noteSetSK: null,
    noteSourceName: null,
    notesList: notesTableData,
    globalNotesList: [],
    checkAll: null,
    addNewLinkRender: null,
    filterLinkRender: null,
    printLinkRender: null,
    completeNotesList: []

  });
  const [noteSetListInput, setNoteSetListInput] = React.useState({
    auditUserID: 'BTAYLOR1',
    auditTimeStamp: null,
    addedAuditUserID: 'BTAYLOR1',
    addedAuditTimeStamp: null,
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    noteTextValue: null,
    userIdName: null,
    notesCexAuditUserID: null,
    notesCexAuditTimeStamp: null,
    notesCexAddedAuditUserID: null,
    notesCexAddedAuditTimeStamp: null,
    noteSetSK: null,
    usageTypeDesc: '',
    shortNotes: null,
    checked: false,
    renderNoHistoryMsg: false,
    noteSequenceNumber: 4,
    currentNote: null,
    rowValue: null,
    usageTypeList: null,
    strBeginDate: moment(new Date()).format('MM/DD/YYYY hh:mm:ss'),
    usageTypeCode: 'Please Select One',
    tableName: null,
    noteText: '',
    commonEntityName: null,
    commonEntityTypeCode: null,
    commonEntityId: null,
    entityId: null,
    filterbeginDate: moment(new Date()).format('YYYY-MM-DD'),
    filterEndDate: null,
    userId: '',
    noteCexVersionNum: 0,
    saNoteSequenceNumber: null,
    notesCexnoteTextValue: 0,
    id: generateUUID()
  });
  const [usageTypeCodeInput, setUsageTypeCodeInput] = React.useState([{
    functionalArea: 'General',
    dataElementName: 'G_NOTE_TY_CD',
    businessName: null,
    valueShortDescription: null,
    crossReferenceColumnName: null,
    crossReferenceTableName: null,
    dataEleNameStartsOrContains: null,
    busNameStartsOrContains: null
  }]);
  const [beginValueValidation,setBeginValueValidation]=React.useState(false)
  const [endValueValidation,setEndValueValidation]=React.useState(false)
  
  const [usageTypeCodeData, setUsageTypeCodeData] = React.useState([]);
  const [editNoteData, setEditNoteData] = React.useState({});

  const addSystemListDetails = () => {
    setCurrentRow(undefined);

    let showFunctionalAreaError; let showListTypeError; let showDataElementNameError; let showListNumberError;
    let showBusinessNameError; let showDescriptionError = false;
    let showFunctionalAreaErrorText; let showListtypeErrorText; let showDataElementNameErrorText;
    let showListNumberErrorText; let showBusinessNameErrorText; let showDescriptionErrorText = '';

    if (values.listType === 'Please Select One') {
      showListTypeError = true;
      setShowError({ showListTypeError: showListTypeError });
      errorMessagesArray.push(SystemListSearchConstants.LIST_TYPE_REQUIRED);
      showListtypeErrorText = SystemListSearchConstants.LIST_TYPE_REQUIRED;
      setErrorMessages(errorMessagesArray);
    }
    if (values.dataElementName === 'Please Select One') {
      showDataElementNameError = true;
      setShowError({ showDataElementNameError: showDataElementNameError });
      errorMessagesArray.push(SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED);
      showDataElementNameErrorText = SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED;
      setErrorMessages(errorMessagesArray);
    }
    if (values.listNumber === '') {
      showListNumberError = true;
      setShowError({ showListNumberError: showListNumberError });
      errorMessagesArray.push(SystemListSearchConstants.LISTNUMBER_REQUIRED);
      showListNumberErrorText = SystemListSearchConstants.LISTNUMBER_REQUIRED;
      setErrorMessages(errorMessagesArray);
    }
    if (values.businessName === '') {
      showBusinessNameError = true;
      showBusinessNameErrorText = SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR;
      errorMessagesArray.push(SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR);
      setErrorMessages(errorMessagesArray);
    }
    if (values.description === '') {
      showDescriptionError = true;
      showDescriptionErrorText = SystemListSearchConstants.DESCRIPTION_REQUIRED;
      errorMessagesArray.push(SystemListSearchConstants.DESCRIPTION_REQUIRED);
      setErrorMessages(errorMessagesArray);
    }

    setShowError({
      showFunctionalAreaError: showFunctionalAreaError,
      showListTypeError: showListTypeError,
      showDataElementNameError: showDataElementNameError,
      showListNumberError: showListNumberError,
      showBusinessNameError: showBusinessNameError,
      showDescriptionError: showDescriptionError
    });
    setShowErrorText({
      showFunctionalAreaErrorText: showFunctionalAreaErrorText,
      showListtypeErrorText: showListtypeErrorText,
      showDataElementNameErrorText: showDataElementNameErrorText,
      showListNumberErrorText: showListNumberErrorText,
      showBusinessNameErrorText: showBusinessNameErrorText,
      showDescriptionErrorText: showDescriptionErrorText
    });

    if (errorMessagesArray.length === 0) {
      setErrorMessages([]);
      setOpenCrossReference(true);
      setAdd(true);
      setSystemListValues({
        lob: 'Please Select One',
        beginValue: '',
        endValue: '',
        sortNum: ''
      });
      setSelectedEndDate(new Date('9999-12-31T13:00:00.000+0000'));
      setSelectedBeginDate(null);
    }
  };

  const [errorMessages, setErrorMessages] = React.useState([]);
  const checkFormValidations = () => {
    var showDescriptionError; var showListNumberError; var showListTypeError; var showBusinessNameError; var showFunctionalAreaError; var showDataElementNameError
      ; var showLobCodeError; var showBeginDateError; var showEndDateError; var showBeginValueError; var showEndValueError; var showBusinessNameErrorText; var showDescriptionErrorText; var showListNumberErrorText; var showListtypeErrorText;
    var showFunctionalAreaErrorText; var showDataElementNameErrorText;
    var showBeginValueErrorText; var showEndValueErrorText; var showBeginDateErrorText;
    var showEndDateErrorText;
    setErrorMessages([]);
    if (values.businessName === '') {
      showBusinessNameError = true;
      showBusinessNameErrorText = SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR;
      errorMessagesArray.push(SystemListSearchConstants.BUSINESS_NAME_REQUIRED_ERROR);
      setErrorMessages(errorMessagesArray);
    }

    if (values.description === '') {
      showDescriptionError = true;
      showDescriptionErrorText = SystemListSearchConstants.DESCRIPTION_REQUIRED;
      errorMessagesArray.push(SystemListSearchConstants.DESCRIPTION_REQUIRED);
      setErrorMessages(errorMessagesArray);
    }

    if (values.listType === 'Please Select One') {
      showListTypeError = true;
      setShowError({ showListTypeError: showListTypeError });
      errorMessagesArray.push(SystemListSearchConstants.LIST_TYPE_REQUIRED);
      showListtypeErrorText = SystemListSearchConstants.LIST_TYPE_REQUIRED;
      setErrorMessages(errorMessagesArray);
    }
    if (values.dataElementName === 'Please Select One') {
      showDataElementNameError = true;
      setShowError({ showDataElementNameError: showDataElementNameError });
      errorMessagesArray.push(SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED);
      showDataElementNameErrorText = SystemListSearchConstants.DATAELEMENT_NAME_REQUIRED;
      setErrorMessages(errorMessagesArray);
    }
    if (values.functionalArea === 'Please Select One') {
      showFunctionalAreaError = true;
      setShowError({ showFunctionalAreaError: showFunctionalAreaError });
      errorMessagesArray.push(SystemListSearchConstants.FUNCTIONALAREA_REQUIRED);
      showFunctionalAreaErrorText = SystemListSearchConstants.FUNCTIONALAREA_REQUIRED;
      setErrorMessages(errorMessagesArray);
    }
    if (values.listNumber === '') {
      showListNumberError = true;
      setShowError({ showListNumberError: showListNumberError });
      errorMessagesArray.push(SystemListSearchConstants.LISTNUMBER_REQUIRED);
      showListNumberErrorText = SystemListSearchConstants.LISTNUMBER_REQUIRED;
      setErrorMessages(errorMessagesArray);
    }

    setShowError({
      showDescriptionError: showDescriptionError,
      showListTypeError: showListTypeError,
      showListNumberError: showListNumberError,
      showBusinessNameError: showBusinessNameError,
      showFunctionalAreaError: showFunctionalAreaError,
      showDataElementNameError: showDataElementNameError

    });

    setShowErrorText({
      showDescriptionErrorText: showDescriptionErrorText,
      showListNumberErrorText: showListNumberErrorText,
      showListtypeErrorText: showListtypeErrorText,
      showDataElementNameErrorText: showDataElementNameErrorText,
      showFunctionalAreaErrorText: showFunctionalAreaErrorText,
      showBusinessNameErrorText: showBusinessNameErrorText
    });

    if (showBusinessNameError || showDescriptionError || showListNumberError || showDataElementNameError || showListTypeError || showDescriptionError || showBusinessNameError) {
      return false;
    } else {
      return true;
    }
  };

  const checkPopupFormValidations = () => {
    var showLobCodeError; var showBeginDateError; var showEndDateError;
    var showBeginValueError; var showEndValueError;

    var showDiagNumericBeginValueError; var showRevenueCodeBeginValueError; var showRevenueCodeEndValueError; var showDiagNumericEndValueError = false;
    var showLobCodeErrorText;
    var showBeginValueErrorText; var showEndValueErrorText; var showBeginDateErrorText;
    var showEndDateErrorText; var showDiagNumericBeginValueErrorText; var showDiagNumericEndValueErrorText = '';

    if (systemListValues.lob === 'Please Select One') {
      showLobCodeError = true;
      setShowError({ showLobCodeError: showLobCodeError });
      showLobCodeErrorText = SystemListSearchConstants.LOB_REQUIRED;
      // return true;
    } else {
      showLobCodeError = false;
    }

    if (systemListValues.beginValue === '') {
      showBeginValueError = true;
      setShowError({ showBeginValueError: showBeginValueError });
      showBeginValueErrorText = SystemListSearchConstants.BEGINVALUE_REQUIRED;
    } else {
      console.log(dataElementNameValue);
      if (dataElementNameValue === 'R_REV_CD') {
        var numbers = /^[0-9]+$/;
        if (systemListValues.beginValue.length === 4) {
          showRevenueCodeBeginValueError = false;
          if (systemListValues.beginValue.match(numbers)) {
            showRevenueCodeBeginValueError = false;
            setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
          } else {
            showRevenueCodeBeginValueError = true;
            setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
            showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE;
          }
        } else {
          showRevenueCodeBeginValueError = true;
          setShowError({ showRevenueCodeBeginValueError: showRevenueCodeBeginValueError });
          showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE;
        }
      }
      if (dataElementNameValue === 'R_DIAG_CD') {
        var test = SystemListConstants.ADDVALUE_REGEX;
        if (systemListValues.beginValue.match(test)) {
          showDiagNumericBeginValueError = false;
          setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
          showDiagNumericBeginValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
        } else {
          showDiagNumericBeginValueError = true;
          setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
          showDiagNumericBeginValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
        }
      }
      if (dataElementNameValue === 'R_SURG_PROC_CD') {
        const test = SystemListConstants.SURGICAL_REGEX;
        if (systemListValues.beginValue.match(test)) {
          showDiagNumericBeginValueError = false;
          setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
          showDiagNumericBeginValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_INVALID_ERROR;
        } else {
          showDiagNumericBeginValueError = true;
          setShowError({ showDiagNumericBeginValueError: showDiagNumericBeginValueError });
          showDiagNumericBeginValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_INVALID_ERROR;
        }
      }
      showBeginValueError = false;
    }

    if (systemListValues.endValue === '') {
      if (values.listType === 'UIS') {
        showEndValueError = false;
        setShowError({ showEndValueError: showEndValueError });
        // showEndValueErrorText = SystemListSearchConstants.ENDVALUE_REQUIRED;
      } else {
        showEndValueError = true;
        setShowError({ showEndValueError: showEndValueError });
        showEndValueErrorText = SystemListSearchConstants.ENDVALUE_REQUIRED;
      }
    } else {
      if (dataElementNameValue === 'R_REV_CD') {
        const numbers = /^[0-9]+$/;
        if (systemListValues.endValue.length === 4) {
          showRevenueCodeEndValueError = false;
          if (systemListValues.endValue.match(numbers)) {
            showRevenueCodeBeginValueError = false;
            setShowError({ showRevenueCodeEndValueError: showRevenueCodeEndValueError });
          } else {
            showRevenueCodeEndValueError = true;
            setShowError({ showRevenueCodeEndValueError: showRevenueCodeEndValueError });
            showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_ENDVALUE;
          }
        } else {
          showRevenueCodeEndValueError = true;
          setShowError({ showRevenueCodeEndValueError: showRevenueCodeEndValueError });
          showBeginValueErrorText = SystemListSearchConstants.REVENUE_CODE_TEXT_ENDVALUE;
        }
      }
      if (dataElementNameValue === 'R_DIAG_CD') {
        const test = SystemListConstants.ADDVALUE_REGEX;
        if (systemListValues.endValue.match(test)) {
          showDiagNumericEndValueError = false;
          setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
          showDiagNumericEndValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
        } else {
          showDiagNumericEndValueError = true;
          setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
          showDiagNumericEndValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
        }
      }
      if (dataElementNameValue === 'R_SURG_PROC_CD') {
        const test = SystemListConstants.SURGICAL_REGEX;
        if (systemListValues.endValue.match(test)) {
          showDiagNumericEndValueError = false;
          setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
          showDiagNumericEndValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
        } else {
          showDiagNumericEndValueError = true;
          setShowError({ showDiagNumericEndValueError: showDiagNumericEndValueError });
          showDiagNumericEndValueErrorText = SystemListSearchConstants.DIAG_BEGINVALUE_ERROR;
        }
      }
      showEndValueError = false;
    }

    // Begin Value validation
    if (systemListValues.beginValue !== '' && systemListValues.endValue !== '' && !isNaN(systemListValues.beginValue) &&
      !isNaN(systemListValues.endValue) && Number(systemListValues.beginValue) > Number(systemListValues.endValue) && !showRevenueCodeBeginValueError &&
      !showDiagNumericBeginValueError && !showBeginValueError && values.listType !== 'UIS') {
      showBeginValueError = true;
      setShowError({ showBeginValueError: showBeginValueError });
      showBeginValueErrorText = SystemListSearchConstants.BEGINVALUE_INVALID_TEXT;
    }

    // date validations
    if (selectedBeginDate) {
      if (selectedBeginDate.toString() !== 'Invalid Date') {
        if (validateDateMinimumValue(selectedBeginDate)) {
          showBeginDateError = true;
          setShowError({ showBeginDateError: showBeginDateError });
          showBeginDateErrorText = AppConstants.DATE_ERROR_1964;
        }
      } else {
        showBeginDateError = true;
        setShowError({ showBeginDateError: showBeginDateError });
        showBeginDateErrorText = SystemListSearchConstants.BEGIN_DATE_INVALID;
      }
    } else {
      showBeginDateError = true;
      setShowError({ showBeginDateError: showBeginDateError });
      showBeginDateErrorText = SystemListSearchConstants.BEGIN_DATE_REQUIRED;
    }
    if (selectedEndDate) {
      if (selectedEndDate.toString() !== 'Invalid Date') {
        if (validateDateMinimumValue(selectedEndDate)) {
          showEndDateError = true;
          setShowError({ showEndDateError: showEndDateError });
          showEndDateErrorText = AppConstants.DATE_ERROR_1964;
        }
      } else {
        showEndDateError = true;
        setShowError({ showEndDateError: showEndDateError });
        showEndDateErrorText = SystemListSearchConstants.END_DATE_INVALID;
      }
    } else {
      showEndDateError = true;
      setShowError({ showEndDateError: showEndDateError });
      showEndDateErrorText = SystemListSearchConstants.END_DATE_REQUIRED;
    }
    if (
      selectedBeginDate &&
      selectedEndDate &&
      !showBeginDateError &&
      !showEndDateError &&
      compareTwoDatesGreaterThanOrEqual(selectedEndDate, selectedBeginDate)
    ) {
      showBeginDateError = true;
      setShowError({ showBeginDateError: showBeginDateError });
      showBeginDateErrorText = SystemListSearchConstants.BEGIN_DATE_LESS;
    }

    setShowError({
      showLobCodeError: showLobCodeError,
      showBeginValueError: showBeginValueError,
      showEndValueError: showEndValueError,
      showBeginDateError: showBeginDateError,
      showEndDateError: showEndDateError,
      showRevenueCodeBeginValueError: showRevenueCodeBeginValueError,
      showDiagNumericBeginValueError: showDiagNumericBeginValueError,
      showRevenueCodeEndValueError: showRevenueCodeEndValueError,
      showDiagNumericEndValueError: showDiagNumericEndValueError

    });

    setShowErrorText({
      showLobCodeErrorText: showLobCodeErrorText,
      showBeginValueErrorText: showBeginValueErrorText,
      showEndValueErrorText: showEndValueErrorText,
      showBeginDateErrorText: showBeginDateErrorText,
      showEndDateErrorText: showEndDateErrorText,
      showDiagNumericBeginValueErrorText: showDiagNumericBeginValueErrorText,
      showDiagNumericEndValueErrorText: showDiagNumericEndValueErrorText
    });
    var isErrorInBeginValue,isErrorInEndValue=false;
    if(isNumericValue(systemListValues.endValue)===false){
      setEndValueValidation(true)
isErrorInEndValue=true
     

  }
    if(isNumericValue(systemListValues.beginValue)===false){
       
      setBeginValueValidation(true)
      isErrorInBeginValue=true

   
    }
    if (isErrorInEndValue &&isErrorInBeginValue &&  showLobCodeError && showBeginValueError && showEndValueError && showBeginDateError && showEndDateError) {
      return false;
    } else {
      if (showLobCodeError) {
        return false;
      }
      if(isErrorInBeginValue){
       
        setBeginValueValidation(true)
      return false
      }
      if(isErrorInEndValue){
       
        setEndValueValidation(true)
      return false
      }
      if (showBeginValueError) {
        return false;
      }
      if (showEndValueError) {
        return false;
      }
      if (showBeginDateError) {
        return false;
      }
      if (showEndDateError) {
        return false;
      }
      if (showRevenueCodeBeginValueError && showRevenueCodeEndValueError) {
        return false;
      }
      if (showRevenueCodeBeginValueError) {
        return false;
      }
      if (showRevenueCodeEndValueError) {
        return false;
      }
      if (showDiagNumericBeginValueError) {
        return false;
      }
      if (showDiagNumericEndValueError) {
        return false;
      }
      return true;
    }
  };

  const handleClose = () => {
    setOpen(false);
    newData.push(dataElement);
  };
  const handleChangeTabs = (event, newValue) => {
    setValue(newValue);
  };
  const handleChange = name => event => {
    setAllowNavigation(false);
    setValues({ [name]: event.target.value });
  };

  const handleChangeDataElement = name => event => {
    setDataElement({ ...dataElement, [name]: event.target.value });
  };

  const handleOpenCrossReferenceDialog = () => {
    setOpen(true);
    setDataElement({
      dataElementName: '',
      businessName: '',
      description: ''
    });
  };
  const handleClickOpen = () => {
    setOpenCrossReference(true);
  };

  const showValueTable = () => {
    setShowSystemlistValueTable(true);
  };

  const resetTable = () => {
    setValues(
      {
        lob: '',
        payee: '',
        payeeIdCode: '',
        id: '',
        name: '',
        systemPayeeId: '',
        multiline: 'Controlled',
        systemPayee: '',
        memberName: ''
      }
    );
  };
  const [currentRow, setCurrentRow] = React.useState();
  const [systemListValues, setSystemListValues] = React.useState({
    lob: 'Please Select One',
    beginValue: '',
    endValue: '',
    sortNum: '',
    voidSelected: 'No'
  });
  const [systemListFilterValues, setSystemListFilterValues] = React.useState({
    lob: 'Please Select One',
    beginValue: '',
    endValue: ''
  });

  const [editData, setEditData] = React.useState({});
  const [showVoid, setShowVoid] = React.useState(false);

  const resetSystemListValues = () => {
    if (add) {
      setSystemListValues({
        lob: 'Please Select One',
        beginValue: '',
        endValue: '',
        sortNum: ''
      });
      setSelectedBeginDate(null);
      setSelectedEndDate(new Date('9999-12-31T13:00:00.000+0000'));
    } else {
      setSystemListValues({
        lob: retainEdit.lineofbusiness,
        beginValue: retainEdit.startingValue ? retainEdit.startingValue : (retainEdit.beginValue ? retainEdit.beginValue : ''),
        endValue: retainEdit.endingValue ? retainEdit.endingValue : (retainEdit.endValue ? retainEdit.endValue : ''),
        voidSelected: 'No',
        sortNum: retainEdit.sortNum
      });
      setSelectedBeginDate(retainEdit.beginDate);
      setSelectedEndDate(retainEdit.endDate);
    }
    setShowError({
      showLobCodeError: false,
      showEndValueError: false,
      showBeginDateError: false,
      showEndDateError: false,
      showOverLappingError: false,
      showBeginValueError: false,
      showRevenueCodeBeginValueError: false,
      showRevenueCodeEndValueError: false,
      showBeginValueInvalidError: false,
      showDiagNumericBeginValueError: false,
      showDiagNumericEndValueError: false
    });
  };

  const uuidv4 = () => {
    return ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, c =>
      (c ^ crypto.getRandomValues(new Uint8Array(1))[0] & 15 >> c / 4).toString(16)
    );
  };
  const systemListData = [];

  const updateResponse = useSelector(state => state.appConfigState.systemListState.systemListUpdateResponse);

  useEffect(() => {
    if (updateResponse) {
      setSpinnerLoader(false);
    }
    if (updateResponse && updateResponse.flag === 'success') {
      successMessagesArray.push(SystemListSearchConstants.UPDATED_SUCCESSFULLY);
      // successMessagesArray.push(updateResponse.flag);
      // call fect api here to reload
      setAllowNavigation(false);
      if (successMessages.length === 0) {
        setSuccessMessages(successMessagesArray);
      }
      console.log(values);
      const searchSwapJson = {
        listNumber: values.listNumber,
        functionalArea: values.functionalArea,
        dataElementName: values.dataElementName,
        description: values.description,
        listType: values.listType,
        listBusinessName: values.listBusinessName,
        funcAreaDesc: values.funcAreaDesc,
        SuccessMessages: successMessagesArray
      };
      dispatch(systemListViewAction(searchSwapJson));
      setSystemListAddTableData(systemListAddTableData);
    } else if (updateResponse && updateResponse.flag !== undefined && updateResponse.flag !== 'success') {
      setErrorMessages(updateResponse.flag);
    } else if (updateResponse !== undefined && updateResponse.flag === undefined) {
      errorMessagesArray.push(SystemListSearchConstants.ERR_PROCESSING_REQ);
      if (errorMessages.length === 0) {
        setErrorMessages(errorMessagesArray);
      }
    }
  }, [updateResponse]);

  function isNumericValue(inputValue){
    const numberArray=[0,1,2,3,4,5,6,7,8,9]
    inputValue=inputValue.trim()
     let shouldBreakMainLoop=false  
  if(inputValue.length===0){
    return 0
  }
  else{
    for(var i=0;i<inputValue.length;i++){
      if(inputValue[i]===" "){
        return false
      }
      else{
        if(shouldBreakMainLoop===true){
        break
      }
   for(var j=0;j<numberArray.length;j++){
   if(inputValue[i]==numberArray[j]){
   
     break
   }
   else if(j==numberArray.length-1 &&inputValue[i]!==numberArray[j] ){
     shouldBreakMainLoop=true
   return false
   }
   
   }
      }
   
    }
  }
  
   return true 
  
      }

  const addSystemListValuesToTable = () => {
   
    
    setSuccessMessages([]);
    setAllowNavigation(true);
    setErrorMessages([]);
    setAllowNavigation(true);
    if (add) {
      if (checkPopupFormValidations()) {
        let count = 0;
        let showDateOverlappingError = false;
       
        
       
        if (nonVoidedData.length > 0) {
          nonVoidedData.map((value, index) => {
            if ((value.startingValue).toString() === systemListValues.beginValue && systemListValues.voidSelected === 'No') {
              if (moment(value.beginDate).format('MM/DD/YYYY') === moment(selectedBeginDate).format('MM/DD/YYYY')) {
                count = count + 1;
              } else if ((moment(value.beginDate).format('MM/DD/YYYY') < moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(value.endDate).format('MM/DD/YYYY') >= moment(selectedEndDate).format('MM/DD/YYYY'))) {
                count = count + 1;
              } else if ((moment(value.beginDate).format('MM/DD/YYYY') > moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(selectedEndDate).format('MM/DD/YYYY') >= moment(value.beginDate).format('MM/DD/YYYY'))) {
                count = count + 1;
              }
            }
          });
        }
        
        if (count > 0) {
          errorMessagesArray = [];
          setErrorMessages([]);
          showDateOverlappingError = true;
          errorMessagesArray.push(SystemListSearchConstants.OVERLAPPING_ERROR);
          setErrorMessages(errorMessagesArray);
          setShowError({ showOverLappingError: showDateOverlappingError });
          window.scrollTo(0, 0);
        }
        if (!showDateOverlappingError) {
          const value = {
            auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            auditTimeStamp: getUTCTimeStamp(),
            addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            addedAuditTimeStamp: getUTCTimeStamp(),
            deletedSystemListRanges: [],
            lineofbusiness: systemListValues.lob,
            voidIndicator: '',
            disableVoidIndCode: false,
            beginDate: moment(selectedBeginDate).format('MM/DD/YYYY'),
            endDate: moment(selectedEndDate).format('MM/DD/YYYY'),
            ranges: null,
            voidDate: null,
            tempVoidDate: null,
            showVoidRecord: true,
            listDetail: null,
            endingValue: values.listType === 'UIS' ? systemListValues.beginValue : systemListValues.endValue,
            startingValue: systemListValues.beginValue,
            sortNum: systemListValues.sortNum,
            filterEndingValue: null,
            filterStartingValue: null,
            filterBeginDate: null,
            filterEndDate: null,
            filterLineofbusiness: null,
            lineofbusiness1: null,
            isNewRow: true,
            id: generateUUID()
          };
          nonVoidDateArray = nonVoidedData;
          nonVoidDateArray.push(value);
          setNonVoidedData(nonVoidDateArray);
        }
        const voiddata = voidedData;
        const nonVoidData = nonVoidedData;
        const concatBoth = voiddata.concat(nonVoidData);
        setConcatbothVoidAndNonVoid(concatBoth);

        if (showVoid) {
          setSystemListAddTableData(concatBoth);
        } else {
          setSystemListAddTableData(nonVoidData);
        }

        handleCloseCrossReference();
      }
    } else {
      
      if ( checkPopupFormValidations()) {
        // debugger
        // console.log(editData);
        // nonVoidedData[nonVoidedData.indexOf(editData)].startingValue = systemListValues.beginValue;
        // nonVoidedData[nonVoidedData.indexOf(editData)].endingValue = systemListValues.endValue;
        // nonVoidedData[nonVoidedData.indexOf(editData)].lineofbusiness = systemListValues.lob;
        // nonVoidedData[nonVoidedData.indexOf(editData)].beginDate =  moment(selectedBeginDate).format('MM/DD/YYYY');
        // nonVoidedData[nonVoidedData.indexOf(editData)].endDate =  moment(selectedEndDate).format('MM/DD/YYYY');
        // nonVoidedData[nonVoidedData.indexOf(editData)].sortNum = systemListValues.sortOrder;

        let count = 0;

        nonVoidedData.map(value => {
          if (nonVoidedData.indexOf(value) !== nonVoidedData.indexOf(editData)) {
            if (nonVoidedData.length > 0) {
              nonVoidedData.map((value, index) => {
                if ((value.startingValue).toString() === systemListValues.beginValue && systemListValues.voidSelected === 'No') {
                  if (moment(value.beginDate).format('MM/DD/YYYY') === moment(selectedBeginDate).format('MM/DD/YYYY')) {
                    count = count + 1;
                  } else if ((moment(value.beginDate).format('MM/DD/YYYY') < moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(value.endDate).format('MM/DD/YYYY') >= moment(selectedEndDate).format('MM/DD/YYYY'))) {
                    count = count + 1;
                  } else if ((moment(value.beginDate).format('MM/DD/YYYY') > moment(selectedBeginDate).format('MM/DD/YYYY')) && (moment(selectedEndDate).format('MM/DD/YYYY') >= moment(value.beginDate).format('MM/DD/YYYY'))) {
                    count = count + 1;
                  }
                }
              });
            }
          }
        });

        let showDateOverlappingError = false;
        if (count > 0) {
          errorMessagesArray = [];
          setErrorMessages([]);
          // showBeginDateInvalidError = false;
          showDateOverlappingError = true;
          errorMessagesArray.push(SystemListSearchConstants.OVERLAPPING_ERROR);
          setErrorMessages(errorMessagesArray);
          setShowError({ showOverLappingError: showDateOverlappingError });
          window.scrollTo(0, 0);
        } else {
          nonVoidedData[nonVoidedData.indexOf(editData)].startingValue = systemListValues.beginValue;
          nonVoidedData[nonVoidedData.indexOf(editData)].endingValue = values.listType === 'UIS' ? systemListValues.beginValue : systemListValues.endValue;
          nonVoidedData[nonVoidedData.indexOf(editData)].lineofbusiness = systemListValues.lob;
          nonVoidedData[nonVoidedData.indexOf(editData)].beginDate = moment(selectedBeginDate).format('MM/DD/YYYY');
          nonVoidedData[nonVoidedData.indexOf(editData)].endDate = moment(selectedEndDate).format('MM/DD/YYYY');
          nonVoidedData[nonVoidedData.indexOf(editData)].sortNum = systemListValues.sortNum;
          if (systemListValues.voidSelected === 'Yes') {
            nonVoidedData[nonVoidedData.indexOf(editData)].voidDate = moment(new Date()).format('MM/DD/YYYY');
            nonVoidedData.map((value) => {
              if (value.voidDate) {
                voidDateArray = voidedData;
                voidDateArray.push(value);
                setVoidedData(voidDateArray);
              } else if (!value.voidDate) {
                nonVoidDateArray.push(value);
                setNonVoidedData(nonVoidDateArray);
              }

              if (nonVoidedData.length === 1) {
                setNonVoidedData([]);
              }
            });
          }
        }
        const voiddata = voidDateArray;
        const nonVoidData = systemListValues.voidSelected === 'Yes' ? nonVoidDateArray : nonVoidedData;
        const concatBoth = voiddata.concat(nonVoidData);
        setConcatbothVoidAndNonVoid(concatBoth);
        if (showVoid) {
          setSystemListAddTableData(concatBoth);
        } else {
          setSystemListAddTableData(nonVoidData);
        }

        handleCloseCrossReference();
        setAdd(true);
      }
    }
  };

  const handleShowVoid = () => {
    if (showVoid) {
      setShowVoid(false);
      setSystemListAddTableData(nonVoidedData);
    } else {
      setShowVoid(true);
      const voiddata = voidedData;
      const nonVoidData = nonVoidedData;
      const concatBoth = voiddata.concat(nonVoidData);
      setConcatbothVoidAndNonVoid(concatBoth);
      setSystemListAddTableData(concatBoth);
    }
  };

  const updateSelectedSystemList = (updatedObj) => {
    const tempOriginal = systemListAddTableData.slice();
    tempOriginal.map((value, index) => {
      if (value.id === updatedObj.id) {
        console.log('there is a match', value);
        value.beginDate = updatedObj.beginDate;
        value.endDate = updatedObj.endDate;
        value.lob = updatedObj.lob;
        value.beginValue = updatedObj.beginValue;
        value.endValue = updatedObj.endValue;
      }
    });
    setSystemListAddTableData(tempOriginal);
  };
  const handleSystemListChanges = name => event => {
    if (name === 'beginValue') {
      setBeginValueValidation(false)
    }
    if (name === 'endValue') {
      setBeginValueValidation(false)
    }
    setSystemListValues({ ...systemListValues, [name]: event.target.value });
  };
  const handleSystemListFilterChanges = name => event => {
    setSystemListFilterValues({ ...systemListFilterValues, [name]: event.target.value });
  };
  const [selectedBeginDate, setSelectedBeginDate] = React.useState('');
  const [selectedFilterBeginDate, setSelectedFilterBeginDate] = React.useState(null);
  const handleBeginDateChange = date => {
    setSelectedBeginDate(date);
    setSystemListValues({ ...systemListValues, beginDate: date });
  };
  const handleFilterBeginDateChange = date => {
    setSelectedFilterBeginDate(date);
  };
  const [selectedEndDate, setSelectedEndDate] = React.useState('');
  const [selectedFilterEndDate, setSelectedFilterEndDate] = React.useState(null);

  const handleEndDateChange = date => {
    setSelectedEndDate(date);
    setSystemListValues({ ...systemListValues, endDate: date });
  };
  const handleFilterEndDateChange = date => {
    setSelectedFilterEndDate(date);
  };

  const saveAddSystemList = () => {
    setSuccessMessages([]);

    if (allowNavigation === false) {
      NoSaveMessage();
    } else {
      if (checkFormValidations()) {
        const voidSet = voidedData;
        const nonVoidSet = nonVoidedData;
        if (nonVoidedData.length > 0) {
          const concatBoth = voidSet.concat(nonVoidSet);
          console.log(voidSet);
          setSystemListAddTableData(concatBoth);
          const value = {
            auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            auditTimeStamp: getUTCTimeStamp(),
            addedAuditUserID: payloadData && payloadData[0] && payloadData[0].addedAuditUserID ? payloadData[0].addedAuditUserID : logInUserID ? logInUserID : 'BTAYLOR1',
            addedAuditTimeStamp: payloadData && payloadData[0] && payloadData[0].addedAuditTimeStamp ? payloadData[0].addedAuditTimeStamp : getUTCTimeStamp(),
            versionNo: payloadData ? payloadData[0].versionNo : null,
            dbRecord: false,
            sortColumn: null,
            auditKeyList: [],
            auditKeyListFiltered: false,
            listNumber: values.listNumber,
            deletedSystemListDetails: [],
            description: values.description,
            functionalArea: values.functionalArea,
            listBusinessName: values.businessName,
            listType: values.listType,
            systemListDetails: concatBoth,
            dataElementName: values.dataElementName,
            groupAssignmentList: null,
            mapSetIds: [],
            noteSet: null,
            length: 0,
            format: null,
            columnName: null,
            sourceTableName: null,
            nameChange: null,
            columnScaleNumber: null,
            noteSetVO: notesInput
          };
          console.log(value);
          setErrorMessages([]);
          setSpinnerLoader(true);
          onUpdateSystemList(value);
          setAllowNavigation(false);
        } else {
          setErrorMessages([SystemListSearchConstants.DETAIL_ROW_REQUIRED]);
        }
      }
    }
  };

  const onClickeditSystemList = data => event => {
    console.log(data);
    setEditData(data);
    setRetainEdit(data);
    setSuccessMessages([]);
    setErrorMessages([]);
    setOpenCrossReference(true);
    setSystemListValues({
      lob: data.lineofbusiness,
      beginValue: data.startingValue,
      endValue: data.endingValue,
      sortNum: data.sortNum,
      voidSelected: data.voidDate != null ? 'Yes' : 'No'
    });
    setCurrentRow(data);
    setSelectedEndDate(data.endDate);
    setSelectedBeginDate(data.beginDate);
    setAdd(false);
  };
  const applyFilter = () => {
    setIsFilterEnable(true);
    console.log('applyFilter');
    console.log(systemListFilterValues);
    console.log(selectedBeginDate);
    console.log(selectedEndDate);
    const filterObject = {};
    if (systemListFilterValues.lob !== 'Please Select One') {
      filterObject.lineofbusiness = systemListFilterValues.lob;
    }
    if (systemListFilterValues.beginValue !== '') {
      filterObject.startingValue = systemListFilterValues.beginValue;
    }
    if (systemListFilterValues.endValue !== '') {
      filterObject.endingValue = systemListFilterValues.endValue;
    }
    if (selectedFilterBeginDate && selectedFilterBeginDate !== '' && selectedFilterBeginDate.toString() !== 'Invalid Date') {
      filterObject.beginDate = moment(selectedFilterBeginDate).format('MM/DD/YYYY');
    }
    if (selectedFilterEndDate && selectedFilterEndDate !== '' && selectedFilterEndDate.toString() !== 'Invalid Date') {
      filterObject.endDate = moment(selectedFilterEndDate).format('MM/DD/YYYY');
    }
    console.log(filterObject);
    console.log('filterObject');
    console.log(nonVoidedData);
    console.log(concatbothvoidandnonvoid);
    if (systemListFilterValues.lob === 'Please Select One' && systemListFilterValues.beginValue === '' &&
      systemListFilterValues.endValue === '' && selectedFilterBeginDate === '' && selectedFilterEndDate === '') {
      setIsFilterEnable(false);
      console.log('setIsFilterEnable = false');
    } else {
      const filterKeys = Object.keys(filterObject);
      if (nonVoidedData && nonVoidedData.length > 0) {
        const tempFilterData = nonVoidedData.filter((value, index) => {
          return filterKeys.every(key => {
            if (filterObject[key] !== undefined && !filterObject[key].length) { return true; }
            return value[key] === filterObject[key];
          });
        });
        setTempNonVolatile(tempFilterData);
        setSystemListAddTableData(tempFilterData);
      }
      if (concatbothvoidandnonvoid && concatbothvoidandnonvoid.length > 0) {
        const tempFilterData = concatbothvoidandnonvoid.filter((value, index) => {
          return filterKeys.every(key => {
            if (filterObject[key] !== undefined && !filterObject[key].length) { return true; }
            return value[key] === filterObject[key];
          });
        });
        setTempConcat(tempFilterData);
        setSystemListAddTableData(tempFilterData);
      }
    }
  };

  const rowDeleteSystemListDetails = data => {
    setRowSystemListDetailData({ ...rowSystemListDetailData, rowSystemListDetailData: data });
  };

  function systemListDetailRowDeleteClick () {
    let temNewDialogData = [...systemListAddTableData];
    if (rowSystemListDetailData.rowSystemListDetailData) {
      for (let i = 0; i < rowSystemListDetailData.rowSystemListDetailData.length; i++) {
        if (rowSystemListDetailData.rowSystemListDetailData[i] !== undefined) {
          temNewDialogData = temNewDialogData.filter(payment => payment.id !== rowSystemListDetailData.rowSystemListDetailData[i]);
        }
      }
    };
    // updateTableData(temNewDialogData);
    setTableData(temNewDialogData);
    setSystemListAddTableData(temNewDialogData);
    setRowSystemListDetailData([]);
  }
  let notesDataArray = [];
  const addNotes = (data) => {
    setAllowNavigation(true);
    console.log(data);
    const noteText = data;
    notesDataArray = notesTableData;
    notesDataArray.push(noteText);
    setNotesTableData(notesDataArray);
    setNotesInput({ ...notesInput, notesList: notesDataArray });
  };
  
  const handelPromptSet = (set) => {
    if (set)
        setPrompt(true);
  }

  return (
    <div className="system-list-add-update">
   
   <UnsavedChangesMessage allowNavigation={allowNavigation} handelPromptSet={handelPromptSet}
        confirm={confirm} cancelType={cancelType} prompt={prompt} setCancelType={setCancelType}
        setPrompt={setPrompt}/>
      {LoadSpinner ? <Spinner /> : null}
      {/* {errorMessages.length > 0 ? <div class="alert alert-danger custom-alert" role="alert" >
        {errorMessages.map(message =>
          <li>{message}</li>
        )
        }
      </div> : null
      }
      { successMessages.length > 0
        ? <div class="alert alert-success custom-alert" role="alert">
          {successMessages.map(message =>
            <li>{message}</li>
          )
          }
        </div> : null
      } */}
      <div className="tabs-container" ref={toPrintRef}>
        <ErrorMessages errorMessages={errorMessages} />

        {successMessages.length > 0
          ? <SuccessMessages successMessages={successMessages} /> : null
        }
        <div className="tab-header">
          <div className="tab-heading float-left">
            Edit System List
          </div>
          <div className="float-right  mt-1 pt-1 hide-on-print">

            <Button variant="outlined" color="primary" className='btn btn-success' onClick={saveAddSystemList} disabled={!userInquiryPrivileges}
            >
              <i class="fa fa-check" aria-hidden="true"></i>
              Save
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                // setspinnerLoader(true);  //in some components it may have different name
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                // setspinnerLoader(false); //in some components it may have different name
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (<Button className='btn btn-primary ml-1' >
                <i class="fa fa-print" aria-hidden="true"></i>
                Print
              </Button>)}
              content={() => toPrintRef.current}
            />

            <Button color="primary" className='btn btn-secondary ml-1'
            >
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div className="tab-body">
          <div className="MuiCollapse-container MuiCollapse-entered">
            <div className="MuiCollapse-wrapper">
              <div className="w-100">
                <form autoComplete="off">
                  <div className="form-wrapper">
                    <div className="mui-custom-form with-select with-select input-md">
                      <TextField
                        id="standard-select-functionalArea"
                        // disabled = {true}
                        fullWidth
                        required
                        disabled
                        select
                        label="Functional Area"
                        value={values.functionalArea}
                        placeholder=""
                        onChange={handleChanges('functionalArea')}
                        InputLabelProps={{
                          shrink: true
                        }}
                        helperText={showFunctionalAreaError ? showFunctionalAreaErrorText : null}
                        error={showFunctionalAreaError ? showFunctionalAreaErrorText : null}
                      >
                        <MenuItem selected key="Please Select One" value="Please Select One">
                          Please Select One
                        </MenuItem>
                        {functionalAreaData ? functionalAreaData.map((option, index) => (
                          <MenuItem key={index} value={option.code}>
                            {option.description}
                          </MenuItem>
                        )) : null}

                      </TextField>
                    </div>
                    <div className="mui-custom-form with-select with-select override-width-28" // style={{ marginLeft: '54px' }}
                    >
                      <TextField
                        id="standard-listNumber"
                        fullWidth
                        required
                        disabled
                        label="List Number"
                        type="number"
                        value={values.listNumber}
                        onChange={handleChanges('listNumber')}
                        placeholder=""
                        InputLabelProps={{
                          shrink: true
                        }}
                        onInput={(e) => {
                          e.target.value = Math.max(0, parseInt(e.target.value)).toString().slice(0, 10);
                        }}
                        onKeyDown={(evt) => evt.key === 'e' && evt.preventDefault()}
                        helperText={showListNumberError ? showListNumberErrorText : null}
                        error={showListNumberError ? showListNumberErrorText : null}
                      />

                    </div>

                    <div className="mui-custom-form with-select with-select override-width-28" // style={{ marginLeft: '39px' }}
                    >
                      <TextField
                        id="standard-select-dataelementname"
                        fullWidth
                        select
                        required
                        disabled={!userInquiryPrivileges}
                        label="Data Element Name"
                        value={values.dataElementName}
                        onChange={handleChanges('dataElementName')}
                        placeholder=""

                        InputLabelProps={{
                          shrink: true
                        }}

                        helperText={showDataElementNameError ? showDataElementNameErrorText : null}
                        error={showDataElementNameError ? showDataElementNameErrorText : null}
                      >
                        <MenuItem selected key="Please Select One" value="Please Select One">
                          Please Select One
                        </MenuItem>
                        {dataElementNameData ? dataElementNameData.map((option, index) => (
                          <MenuItem key={index} value={option}>
                            {option}
                          </MenuItem>
                        )) : null}
                      </TextField>
                    </div>
                    {/* <div className="mui-custom-form with-select with-select input-md" // style={{ marginLeft: '46px' }}
                  >
                    <TextField
                      disabled
                      id="standard-mapid"
                      fullWidth
                      label="Used in Mapset"
                      value='Map ID'
                      // onChange={handleChanges('businessName')}
                      placeholder=""
                      InputLabelProps={{
                        shrink: true
                      }}
                    />
                    {MapIdList.length > 0 ? <MapsetIdTable MapIdList={MapIdList} redirectToMapset={redirectToMapset} openMapsetPopUpDialog={openMapsetPopUpDialog} /> : null}
                  </div> */}
                    <div className="mui-custom-form with-select with-select input-md">
                    <TextField
                            // disabled
                            InputProps={{
                              readOnly: true,
                              className: "Mui-disabled"
                            }}
                            id="standard-mapid"
                            fullWidth
                            label="Used in Mapset"
                            value="Map ID"
                            // onChange={handleChanges('businessName')}
                            placeholder=""
                            InputLabelProps={{
                              shrink: true
                            }}
                          />
                          {MapIdList.length > 0 ? (
                            <MapsetIdTable
                              MapIdList={MapIdList}
                              redirectToMapset={redirectToMapset}
                              openMapsetPopUpDialog={openMapsetPopUpDialog}
                            />
                          ) : null}
                    </div>
                  </div>
                  <div className="form-wrapper">
                    <div className="mui-custom-form with-select override-width-28">
                      <TextField
                        id="standard-description"
                        fullWidth
                        label="Description"
                        required
                        disabled={!userInquiryPrivileges}
                        value={values.description}
                        onChange={handleChanges('description')}
                        placeholder=""
                        InputLabelProps={{
                          shrink: true
                        }}
                        inputProps={{ maxLength: 50 }}
                        helperText={showDescriptionError ? showDescriptionErrorText : null}
                        error={showDescriptionError ? showDescriptionErrorText : null}
                      />
                    </div>
                    <div className="mui-custom-form with-select with-select override-width-28">
                      <TextField
                        id="standard-businessName"
                        fullWidth
                        required
                        disabled={!userInquiryPrivileges}
                        label="Business Name"
                        value={values.businessName}
                        onChange={handleChanges('businessName')}
                        placeholder=""
                        InputLabelProps={{
                          shrink: true
                        }}
                        inputProps={{ maxLength: 50 }}
                        helperText={showBusinessNameError ? showBusinessNameErrorText : null}
                        error={showBusinessNameError ? showBusinessNameErrorText : null}
                      />
                    </div>
                    <div className="mui-custom-form with-select with-select override-width-28" // style={{ marginLeft: '216px' }}
                    >
                      <TextField
                        id="standard-select-listtype"
                        fullWidth
                        select
                        required
                        disabled={!userInquiryPrivileges}
                        label="List Type"
                        value={values.listType}
                        onChange={handleChanges('listType')}
                        placeholder=""

                        InputLabelProps={{
                          shrink: true
                        }}
                        helperText={showListTypeError ? showListtypeErrorText : null}
                        error={showListTypeError ? showListtypeErrorText : null}
                      >
                        <MenuItem selected key="Please Select One" value="Please Select One">
                          Please Select One
                        </MenuItem>
                        {listTypeData ? listTypeData.map((option, index) => (
                          <MenuItem key={index} value={option.code}>
                            {option.description}
                          </MenuItem>
                        )) : null}
                      </TextField>
                    </div>
                    <div className="ShowoidCheckBox">
                      <div className="mui-custom-form hide-on-print">
                        <div className="sub-radio ">
                          <FormControlLabel
                            control={
                              <Checkbox color="primary" onChange={handleChange('antoine')} value="antoine" />
                            }
                            label="Show Voids"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>

          </div>
          <div>
          </div>
          <div className='tab-panelbody m-0'>
            <div className="tab-holder">

              <AppBar position="static">
                <Tabs value={value} onChange={handleChangeTabs} aria-label="simple tabs example">
                  <Tab label="System List Detail" />
                  <Tab label="Notes" />
                  {/* <Tab label="Add List Value" /> */}
                </Tabs>
              </AppBar>
              {/* <TabPanel index={-1} value={value}></TabPanel> */}
              <TabPanel className={printLayout ? 'hide-on-screen' : ''} value={printLayout ? 0 : value} index={0}>
                <div className="tab-holder p-0">
                  <div className="rounded-top" onClick={() => setShowAdditionalDetails1(!showAdditionalDetails1)}
                    style={{ backgroundColor: '#274463', color: '#fff', padding: '10px', margin: '10px 0px', fontWeight: '500', fontSize: '14px' }}>
                    Display Filters
                    <div className="pull-right">
                      {
                        showAdditionalDetails1 ? <span><i class="fa fa-angle-up" aria-hidden="true"></i>

                        </span> : <span><i class="fa fa-angle-down" aria-hidden="true"></i>

                        </span>
                      }
                    </div>
                  </div>
                  {(() => {
                    if (showAdditionalDetails1) {
                      return (
                        <form autoComplete="off">
                          <div className="form-wrapper">
                            <div className="mui-custom-form with-select with-select input-md">
                              <TextField
                                id="standard-select-functionalArea"
                                fullWidth
                                select
                                label="LOB"
                                value={systemListFilterValues.lob}
                                onChange={handleSystemListFilterChanges('lob')}
                                placeholder=""
                                InputLabelProps={{
                                  shrink: true
                                }}
                              >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                  Please Select One
                                </MenuItem>
                                {lobCodeData ? lobCodeData.map(option => (
                                  <MenuItem key={option.code} value={option.code}>
                                    {option.description}
                                  </MenuItem>
                                )) : null}
                              </TextField>
                            </div>
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                              <div className="mui-custom-form with-select with-select input-md">
                                <KeyboardDatePicker
                                  maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                  id="date-picker-dialog3"
                                  fullWidth
                                  label="Begin Date"
                                  format="MM/dd/yyyy"
                                  InputLabelProps={{
                                    shrink: true
                                  }}
                                  placeholder="mm/dd/yyyy"
                                  value={selectedFilterBeginDate}
                                  onChange={setSelectedFilterBeginDate}
                                  error={showBeginDateError ? showBeginDateErrorText : null}
                                  helperText={showBeginDateError ? showBeginDateErrorText : null}
                                  KeyboardButtonProps={{
                                    'aria-label': 'change date'
                                  }}
                                />
                              </div>

                              <div className="mui-custom-form with-select with-select input-md">
                                <KeyboardDatePicker
                                  maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                  id="date-picker-dialog4"
                                  fullWidth
                                  label="End Date"
                                  // required
                                  helperText={null}
                                  format="MM/dd/yyyy"
                                  InputLabelProps={{
                                    shrink: true
                                  }}
                                  error={false}
                                  maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                                  placeholder="mm/dd/yyyy"
                                  value={selectedFilterEndDate}
                                  onChange={setSelectedFilterEndDate}
                                  KeyboardButtonProps={{
                                    'aria-label': 'change date'
                                  }}
                                />
                              </div>
                            </MuiPickersUtilsProvider>
                            <div className="mui-custom-form with-select with-select input-md">
                              <TextField
                                id="beginValue"
                                label="Begin Value"
                                value={systemListFilterValues.beginValue}
                                // inputProps={{ maxLength: 30 }}
                                onChange={handleSystemListFilterChanges('beginValue')}
                                InputLabelProps={{
                                  shrink: true
                                }}

                              />
                            </div>
                            <div className="mui-custom-form with-select with-select input-md">
                              <TextField
                                id="endValue"
                                fullWidth
                                label="End Value"
                                value={systemListFilterValues.endValue}
                                // inputProps={{ maxLength: 30 }}
                                onChange={handleSystemListFilterChanges('endValue')}
                                InputLabelProps={{
                                  shrink: true
                                }}

                              />
                            </div>
                            <div className="mui-custom-form with-select with-select input-md" style={{ marginTop: '34px' }}>
                              <Button variant="outlined" color="primary" className='btn btn-primary'
                                onClick={() => { applyFilter(); }}
                              >
                                Filter
                              </Button>
                            </div>
                          </div>

                        </form>

                      );
                    }
                  })()}
                  <div style={{ marginBottom: '19px' }}>
                    <div className="mui-custom-form no-margin dib show-voids mt-3 mt-1">
                      <div className="sub-radio no-margin">
                        <FormControlLabel
                          control={
                            <Checkbox color="primary" checked={showVoid} value={showVoid} onChange={handleShowVoid} />
                          }
                          label="Show Voids"
                        />
                      </div>

                    </div>
                    <div className="float-right mb-3 mt-2 hide-on-print">
                      <Button className="btn-text btn-transparent btn-padding-transparent" onClick={systemListDetailRowDeleteClick}>
                        <i class="fa fa-trash" aria-hidden="true"></i>
                        Delete
                      </Button>

                      <Button variant="outlined" color="primary" className="float-right btn btn-success ml-1"
                        onClick={() => addSystemListDetails()} disabled={!userInquiryPrivileges}
                      >
                        <i class="fa fa-plus" aria-hidden="true"></i> Add System List Detail</Button>
                    </div>
                  </div>

                  {/* <Button variant="outlined" color="primary" className='btn mb-2 btn-primary ml-1'>Delete</Button> */}

                  <div className="clearfix"></div>
                  <h4 className="hide-on-screen mt-2"><span class="badge badge-primary">System List Detail</span></h4>
                  <SystemListAddTable
                    tableData={systemListAddTableData || []}
                    showVoid={showVoid}
                    voidTableData={isFilterEnable ? setTempConcat : concatbothvoidandnonvoid}
                    nonVoidTableData={isFilterEnable ? tempNonVolatile : nonVoidedData}
                    updateSystemList={updateSelectedSystemList}
                    editSystemListTable={onClickeditSystemList}
                    rowDeleteSystemListDetails={rowDeleteSystemListDetails}
                  />
                  {/* </div> */}
                </div>
              </TabPanel>
              <TabPanel className={printLayout ? 'hide-on-screen' : ''} value={printLayout ? 1 : value} index={1}>
                <Notes addNotes={addNotes}
                  notesTableData={notesTableData}
                  noteSetListInput={noteSetListInput}
                  setNoteSetListInput={setNoteSetListInput}
                  usageTypeCodeData={usageTypeCodeData}
                  editNoteData={editNoteData}
                  setEditNoteData={setEditNoteData} />
              </TabPanel>
              {
                showSystemlistValueTable

                  ? <div>
                    <div className="tabs-container">
                      <div className="tab-header">
                        <div className="tab-heading float-left">
                          Edit List Value
                        </div>
                        <form autoComplete="off">

                          <div className="clearfix"></div>

                        </form>
                      </div>
                    </div>
                  </div> : null
              }
              <Footer print />
              <Dialog
                className="custom-dialog"
                open={openCrossReference}
                fullWidth={'xxl'}>
                <DialogTitle id="customized-dialog-title" onClose={handleCloseCrossReference}>{
                  add ? 'Add System List Details' : 'Edit System List Details'
                }

                </DialogTitle>
                <DialogContent dividers>
                  <form autoComplete="off">
                    <div className="form-wrapper">
                      <div className="mui-custom-form with-select override-width-31 m-2" style={{width:'168px'}}>
                        <TextField
                          id="standard-select-functionalArea"
                          fullWidth
                          select
                          disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                          required
                          label="LOB"
                          value={systemListValues.lob}
                          onChange={handleSystemListChanges('lob')}
                          placeholder=""
                          InputLabelProps={{
                            shrink: true
                          }}

                          helperText={showLobCodeError ? showLobCodeErrorText : null}
                          error={showLobCodeError ? showLobCodeErrorText : null}
                        >
                          <MenuItem selected key="Please Select One" value="Please Select One">
                            Please Select One
                          </MenuItem>
                          {lobCodeData ? lobCodeData.map((option, index) => (
                            <MenuItem key={index} value={option.code}>
                              {option.description}
                            </MenuItem>
                          )) : null}
                        </TextField>
                      </div>
                      {
                        values.listType === 'UIS'
                          ? <div className="mui-custom-form override-width-30 m-2" style={{width:'168px'}}>
                            <TextField
                              disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                              id="constant-text"
                              fullWidth
                              label="Sort Order"
                              value={systemListValues.sortNum}
                              onChange={handleSystemListChanges('sortNum')}
                              InputLabelProps={{
                                shrink: true
                              }}
                              inputProps={{ maxLength: 10 }}
                              onInput={e => {
                                e.target.value = e.target.value.replace(
                                  AppConstants.NUMBER_ONLY_REGEX,
                                  ''
                                );
                              }}
                            />
                          </div>
                          : null
                      }

                      <div className="mui-custom-form override-width-30 m-2" style={{width:'168px'}}>
                        <TextField
                          id="beginValue"
                          fullWidth
                          label="Begin Value"
                          required
                          inputProps={{ maxLength: 30 }}
                          disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                          value={systemListValues.beginValue}
                          onChange={handleSystemListChanges('beginValue')}
                          InputLabelProps={{
                            shrink: true
                          }}
                          helperText={(showBeginValueError || showRevenueCodeBeginValueError) ? showBeginValueErrorText : beginValueValidation ? SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE : null}
                          
                          error={(showBeginValueError || showRevenueCodeBeginValueError) ? showBeginValueErrorText : beginValueValidation ? SystemListSearchConstants.REVENUE_CODE_TEXT_BEGINVALUE : null }
                        />
                      </div>

                      {
                        values.listType === 'PRC'
                          ? <div className="mui-custom-form override-width-31 m-2" style={{width:'168px'}}>
                            <TextField
                              id="endValue"
                              fullWidth
                              label="End Value"
                              required
                              inputProps={{ maxLength: 30 }}
                              disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                              value={systemListValues.endValue}
                              onChange={handleSystemListChanges('endValue')}
                              InputLabelProps={{
                                shrink: true
                              }}
                              helperText={(showEndValueError || showRevenueCodeEndValueError) ? showEndValueErrorText : (showDiagNumericEndValueError||endValueValidation ? SystemListSearchConstants.REVENUE_CODE_TEXT_ENDVALUE : null)}
                              error={(showEndValueError || showRevenueCodeEndValueError) ? showEndValueErrorText : (showDiagNumericEndValueError || endValueValidation? SystemListSearchConstants.REVENUE_CODE_TEXT_ENDVALUE : null)}
                            />
                          </div> : null
                      }
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <div className="mui-custom-form with-date override-width-31 m-2" style={{width:'168px'}}>
                          <KeyboardDatePicker
                            maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                            id="date-picker-dialog1"
                            fullWidth
                            label="Begin Date"
                            required
                            disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                              shrink: true
                            }}
                            placeholder="mm/dd/yyyy"
                            value={selectedBeginDate}
                            onChange={setSelectedBeginDate}
                            error={false}
                            helperText={null}
                            KeyboardButtonProps={{
                              'aria-label': 'change date'
                            }}

                            helperText={showBeginDateError ? showBeginDateErrorText : null}
                            error={showBeginDateError ? showBeginDateErrorText : null}
                          />
                        </div>
                        {values.listType === 'PRC'
                          ? <div className="mui-custom-form with-date override-width-31 m-2" style={{width:'168px'}}>
                            <KeyboardDatePicker
                              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                              id="date-picker-dialog2"
                              fullWidth
                              label="End Date"
                              required
                              disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                              helperText={null}
                              format="MM/dd/yyyy"
                              InputLabelProps={{
                                shrink: true
                              }}
                              maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                              error={false}
                              placeholder="mm/dd/yyyy"
                              value={selectedEndDate}
                              onChange={setSelectedEndDate}
                              KeyboardButtonProps={{
                                'aria-label': 'change date'
                              }}
                              helperText={showEndDateError ? showEndDateErrorText : null}
                              error={showEndDateError ? showEndDateErrorText : null}
                            />
                          </div>
                          : <div className="mui-custom-form with-date override-width-28 m-2" style={{width:'168px'}}>
                            <KeyboardDatePicker
                              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                              id="date-picker-dialog2"
                              fullWidth
                              label="End Date"
                              required
                              disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                              helperText={null}
                              format="MM/dd/yyyy"
                              InputLabelProps={{
                                shrink: true
                              }}
                              maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                              error={false}
                              placeholder="mm/dd/yyyy"
                              value={selectedEndDate}
                              onChange={setSelectedEndDate}
                              KeyboardButtonProps={{
                                'aria-label': 'change date'
                              }}
                              helperText={showEndDateError ? showEndDateErrorText : null}
                              error={showEndDateError ? showEndDateErrorText : null}
                            />
                          </div>}
                      </MuiPickersUtilsProvider>
                      {
                        add || currentRow.isNewRow ? null
                          : <div className="mui-custom-form">
                            <span className="MuiFormLabel-root small-label no-margin">Void</span>
                            <div style={{ paddingTop: '10px', marginLeft: '0px' }}>
                              <input type="radio"
                                name="voidSelection"
                                value="Yes"
                                id="voidYesId"
                                disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                                checked={systemListValues.voidSelected === 'Yes'}
                                onChange={handleSystemListChanges('voidSelected')}
                              /><label className="text-black" for="voidYesId">Yes</label>
                              <input type="radio"
                                name="voidSelection"
                                value="No"
                                id="voidNoId"
                                disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}
                                checked={systemListValues.voidSelected === 'No'}
                                onChange={handleSystemListChanges('voidSelected')}
                                className="ml-2"
                              /><label className="text-black" for="voidNoId">No</label>
                            </div>
                          </div>
                      }
                    </div>
                  </form>
                </DialogContent>

                <DialogActions>
                  {
                    add
                      ? <Button variant="outlined" color="primary" className="btn btn-success ml-1" onClick={addSystemListValuesToTable} disabled={!userInquiryPrivileges}>
                        <i class="fa fa-plus" aria-hidden="true"></i>Add
                      </Button>
                      : <Button variant="outlined" color="primary" className='btn btn-primary' onClick={addSystemListValuesToTable} disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}>
                        Update
                      </Button>
                  }

                  <Button variant="outlined" color="primary" className='bt-reset btn-transparent  ml-1' onClick={resetSystemListValues} disabled={!userInquiryPrivileges ? !userInquiryPrivileges : !!(currentRow !== undefined && currentRow.voidDate != null)}>
                    <i class="fa fa-undo" aria-hidden="true"></i>Reset
                  </Button>

                </DialogActions>
              </Dialog>
              <Dialog className="custom-dialog dialog-500 with-padding" fullWidth={true} maxWidth={'sm'} open={openMapsetDialog}>
                <DialogContent dividers>
                  <div>Are you sure you want go to Mapset Edit Page?</div>
                </DialogContent>

                <DialogActions>
                  <Button className="btn btn-primary ml-1" onClick={() => redirectPageToMapsetAdd()}
                  // disabled={!props.userInquiryPrivileges}
                  >
                    OK
                  </Button>
                  <Button className="btn btn-primary ml-1" onClick={closeMapsetPopUpDialog}
                  // disabled={!props.userInquiryPrivileges}
                  >
                    Cancel
                  </Button>
                </DialogActions>
              </Dialog>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
