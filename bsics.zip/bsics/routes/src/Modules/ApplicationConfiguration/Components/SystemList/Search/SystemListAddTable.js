/* eslint-disable no-unused-vars */
import React from 'react';
import TableComponent from '../../../../../SharedModules/Table/Table';


const headCells = [
  { id: 'beginDate', numeric: false, disablePadding: true, label: 'Begin Date' , width:'120', isDate:true},
  { id: 'endDate', numeric: false, disablePadding: false, label: 'End Date' , width:'120', isDate:true},
  { id: 'lineofbusiness', numeric: false, disablePadding: false, label: 'LOB' },
  { id: 'startingValue', numeric: false, disablePadding: false, label: 'Begin Value' },
  { id: 'endingValue', numeric: false, disablePadding: false, label: 'End Value' },
  { id: 'sortNum', numeric: false, disablePadding: false, label: 'Sort Order', width:'20%', isVarChar: true},
  { id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date' , width:'120', isDate:true}
];

export default function SystemListAddTable (props) {



const tableComp = <TableComponent headCells={headCells} isSearch={false} tableData={props.tableData ? props.tableData : []} onTableRowClick={props.editSystemListTable} defaultSortColumn="startingValue" onTableRowDelete = {props.rowDeleteSystemListDetails}/>;

//  const tableComp = <TableComponent headCells={headCells} isSearch={false} tableData={props.tableData ? props.tableData : []} onTableRowClick={props.editSystemListTable} defaultSortColumn={headCells[0].id} onTableRowDelete = {props.rowDeleteSystemListDetails}/>;
  return (
    tableComp
  );
}
