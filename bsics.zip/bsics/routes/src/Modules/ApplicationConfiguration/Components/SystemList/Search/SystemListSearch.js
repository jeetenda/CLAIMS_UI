/* eslint-disable no-unused-vars */
import React, { useEffect, useRef } from 'react';
import SystemListSearchTableComponent from './SystemListSearchTableComponent';
import { Button } from 'react-bootstrap';
import TextField from '@material-ui/core/TextField';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import MenuItem from '@material-ui/core/MenuItem';
import { useDispatch, useSelector } from 'react-redux';
import {
  systemListActions,
  resetSystemList
} from '../../../Store/Actions/systemList/systemListActions';
import * as SystemListConstants from '../Search/SystemListSearchConstants';
import Spinner from '../../../../../SharedModules/Spinner/Spinner';
import { withRouter } from 'react-router';

import {
  AppConfigDropdownActions,
  DataElementDropdownActions
} from '../../../Store/Actions/AppConfigCommon/AppConfigActions';
import dropdownCriteria from './SystemListSearch.json';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../../../SharedModules/Store/Actions/SharedAction';
import Footer from '../../../../../SharedModules/Layout/footer';


function SystemListSearch (props) {
  const dispatch = useDispatch();
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const toPrintRef = useRef();
  const onReset = () => dispatch(resetSystemList());
  const dropDownDispatch = dropdownvalues =>
    dispatch(AppConfigDropdownActions(dropdownvalues));
  const dataElemDropDownDispatch = () => dispatch(DataElementDropdownActions());

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
    dataElemDropDownDispatch();
  }, []);
  const [showTable, setShowTable] = React.useState(false);

  let errorMessagesArray = [];
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [
    { showListNumberError, showBusinessNameError, showDescriptionError, showDataElementNameError },
    setShowError
  ] = React.useState(false);

  const [listNumberStartsWith, setListNumberStartsWith] = React.useState(false);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [listTypeData, setListTypeData] = React.useState([]);
  const [dataElementNameData, setDataElementNameData] = React.useState([]);
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [showNoRecords, setShowNoRecords] = React.useState(false);

  const handleChangeList = () => {
    setListNumberStartsWith(!listNumberStartsWith);
  };
  const dropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.appConfigDropdown
  );
  const datElemDropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.dataElementNameDropdown
  );

  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj['Reference#1017']) {
        setFunctionalAreaData(dropdown.listObj['Reference#1017']);
      }
      if (dropdown.listObj['Reference#2']) {
        setListTypeData(dropdown.listObj['Reference#2']);
      }
    }
  }, [dropdown]);

  useEffect(() => {
    if (datElemDropdown && datElemDropdown.listDataElements) {
      setDataElementNameData(datElemDropdown.listDataElements);
    }
  }, [datElemDropdown]);

  const [values, setValues] = React.useState({
    functionalArea: 'Please Select One',
    listNumber: '',
    businessName: '',
    dataElementName: 'Please Select One',
    description: '',
    listType: 'Please Select One',
    value: '',
    columnName: '',
    tableName: ''
  });

  const handleChanges = name => event => {
    setValues({ ...values, [name]: event.target.value });
  };

  const resetTable = () => {
    onReset();
    setShowNoRecords(false);
    seterrorMessages([]);
    setListNumberStartsWith(false);
    setShowError({
      showListNumberError: false,
      showBusinessNameError: false,
      showDescriptionError: false
    });
    setValues({
      value: '',
      functionalArea: 'Please Select One',
      listNumber: '',
      businessName: '',
      dataElementName: 'Please Select One',
      description: '',
      listType: 'Please Select One',
      columnName: '',
      tableName: ''
    });
    setShowTable(false);
  };

  const [redirect, setRedirect] = React.useState(0);
  let paylod = null;
  const onSearch = values => {
    setspinnerLoader(true);
    dispatch(systemListActions(values));
  };
  paylod = useSelector(state => state.appConfigState.systemListState.payload);
  useEffect(() => {
    onReset();
  }, []);

  useEffect(() => {
    if (paylod != null && paylod.length === 0) {
      setShowNoRecords(true);
    }
    if (paylod && paylod === null) {
      setShowNoRecords(true);
    }
    setspinnerLoader(false);
  }, [paylod]);

  const payloadData = paylod ? paylod[0] : {};

  const functionalAreaDesc = data => {
    const filteredValue = functionalAreaData.filter(
      (prv, index) => prv.code === data
    );
    if (filteredValue && filteredValue.length > 0) {
      return filteredValue[0].description;
    }
    return data;
  };

  if (paylod != null) {
    paylod.map((data, index) => {
      if (data.functionalArea !== '') {
        data.functionalAreaDesc = functionalAreaDesc(data.functionalArea);
      }
    });
  }

  if (redirect === 1) {
    if (paylod != null) {
      if (paylod.length === 1) {
        const searchSwapJson = {
          listNumber: payloadData.listNumber,
          functionalArea: payloadData.functionalArea,
          dataElementName: payloadData.dataElementName,
          description: payloadData.description,
          listType: payloadData.listType,
          listBusinessName: payloadData.listBusinessName,
          funcAreaDesc: payloadData.funcAreaDesc
        };
        console.log('payloadData');
        console.log(payloadData);
        props.history.push({
          pathname: '/SystemListAddUpdate',
          state: { searchSwapJson }
        });
      }
    }
  }

  const searchCheck = values => {
    setRedirect(0);
    errorMessagesArray = [];
    seterrorMessages([]);
    setShowNoRecords(false);
    var showListNumberError;
    var showBusinessNameError;
    var showDescriptionError = false;
    var showDataElementNameError = false;
    if (
      listNumberStartsWith &&
      (!values.listNumber || values.listNumber.length < 2)
    ) {
      showListNumberError = true;
      errorMessagesArray.push(SystemListConstants.LIST_NUMBER_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (
      values.businessNameSelected &&
      (!values.businessName || values.businessName.length < 2)
    ) {
      showBusinessNameError = true;
      errorMessagesArray.push(SystemListConstants.BUSINESS_NAME_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (values.value && values.value.trim() && values.dataElementName === 'Please Select One') {
      showDataElementNameError = true;
      errorMessagesArray.push(SystemListConstants.DATAELEMENT_NAME_REQUIRED);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (
      values.descriptionSelected &&
      (!values.description || values.description.length < 2)
    ) {
      showDescriptionError = true;
      errorMessagesArray.push(SystemListConstants.DESCRIPTION_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    } else if (errorMessagesArray.length === 0) {
      // setUpdateData(data)
      setShowTable(true);
      /// /
      const searchCriteria = {
        listNumber: values.listNumber !== '' ? +values.listNumber : null,
        businessName: values.businessName !== '' ? values.businessName : null,
        functionalArea:
          values.functionalArea !== 'Please Select One'
            ? values.functionalArea
            : null,
        dataElementName:
          values.dataElementName !== 'Please Select One'
            ? values.dataElementName
            : null,
        description:
          values.descriptionescription !== '' ? values.description : null,
        value: values.value !== '' ? values.value : null,
        listType:
          values.listType !== 'Please Select One' ? values.listType : null,
        descriptionStartsOrContains:
          values.descriptionSelected === 'StartsWith'
            ? 0
            : values.descriptionSelected === 'Contains'
              ? 1
              : null,
        businessNameStartsOrContains:
          values.businessNameSelected === 'StartsWith'
            ? 0
            : values.businessNameSelected === 'Contains'
              ? 1
              : null,
        listNumberStartsWith: listNumberStartsWith
      };
      onSearch(searchCriteria);
      let valuetoredirect = 0;
      valuetoredirect = valuetoredirect + 1;
      setRedirect(valuetoredirect);
    }
    setShowError({
      showListNumberError: showListNumberError,
      showBusinessNameError: showBusinessNameError,
      showDescriptionError: showDescriptionError,
      showDataElementNameError: showDataElementNameError
    });
    // dispatch(searchCheck(values));
  };
  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}

      <div className="tabs-container" ref={toPrintRef}>
        {errorMessages.length > 0 ? (
          <div class="alert alert-danger custom-alert" role="alert">
            {errorMessages.map(message => (
              <li>{message}</li>
            ))}
          </div>
        ) : null}
        {errorMessages.length === 0 && paylod !== undefined && showNoRecords ? (
          <div class="alert alert-danger custom-alert" role="alert">
            <li>{SystemListConstants.NO_RECORDS_FOUND}</li>
          </div>
        ) : null}
        {errorMessages.length === 0 && paylod === null ? (
          <div class="alert alert-danger custom-alert" role="alert">
            <li>{SystemListConstants.ERROR_OCCURED_DURING_TRANSACTION}</li>
          </div>
        ) : null}
        <div className="tab-header">
          <div className="tab-heading float-left">Search System List</div>
          <div className="float-right mt-2 hide-on-print">
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true); // in some components it may have different name
                return new Promise(resolve => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false); // in some components it may have different name
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button className="btn btn-primary ml-1">
                  <i class="fa fa-print" aria-hidden="true"></i>
                  Print
                </Button>
              )}
              content={() => toPrintRef.current}
            />

            <Button color="primary" className="btn btn-secondary ml-1">
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div className="collapsable-panel"></div>
        <div>
          <div className="tab-body">
            <form autoComplete="off">
              <div className="form-wrapper">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-select-functionalArea"
                    fullWidth
                    select
                    label="Functional Area"
                    value={values.functionalArea}
                    onChange={handleChanges('functionalArea')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  >
                    <MenuItem
                      selected
                      key="Please Select One"
                      value="Please Select One"
                    >
                      Please Select One
                    </MenuItem>
                    {functionalAreaData
                      ? functionalAreaData.map((option, index) => (
                        <MenuItem key={index} value={option.code}>
                          {option.description}
                        </MenuItem>
                      ))
                      : null}
                  </TextField>
                </div>

                <div className="mui-custom-form">
                  <TextField
                    id="standard-listNumber"
                    fullWidth
                    label="List Number"
                    type="number"
                    value={values.listNumber}
                    onChange={handleChanges('listNumber')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                    onInput={e => {
                      e.target.value = Math.max(0, parseInt(e.target.value))
                        .toString()
                        .slice(0, 10);
                    }}
                    onKeyDown={evt =>
                      (evt.key === '.' || evt.key === 'e') &&
                      evt.preventDefault()
                    }
                    inputProps={{ maxLength: 10 }}
                    helperText={
                      showListNumberError
                        ? SystemListConstants.LIST_NUMBER_ERROR
                        : null
                    }
                    error={
                      showListNumberError
                        ? SystemListConstants.LIST_NUMBER_ERROR
                        : null
                    }
                  />
                  <div className="sub-radio sub-radios">
                    <FormControlLabel
                      control={
                        <Checkbox
                          color="primary"
                          checked={listNumberStartsWith}
                          value={listNumberStartsWith}
                          onChange={handleChangeList}
                        />
                      }
                      label="Starts With"
                    />
                  </div>
                </div>

                <div
                  className="mui-custom-form with-select" // style={{ marginLeft: '0px' }}
                >
                  {/* disableFocusListener */}
                  <TextField
                    id="standard-select-functionalArea"
                    fullWidth
                    select
                    label="Data Element Name"
                    value={values.dataElementName}
                    onChange={handleChanges('dataElementName')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                    helperText={
                      showDataElementNameError
                        ? SystemListConstants.DATAELEMENT_NAME_REQUIRED
                        : null
                    }
                    error={
                      showDataElementNameError
                        ? SystemListConstants.DATAELEMENT_NAME_REQUIRED
                        : null
                    }
                  >
                    <MenuItem
                      selected
                      key="Please Select One"
                      value="Please Select One"
                    >
                      Please Select One
                    </MenuItem>
                    {dataElementNameData
                      ? dataElementNameData.map((option, index) => (
                        <MenuItem key={index} value={option}>
                          {option}
                        </MenuItem>
                      ))
                      : null}
                  </TextField>
                </div>
                <div className="mui-custom-form input-xl">
                  <TextField
                    id="standard-value"
                    fullWidth
                    label="Value"
                    value={values.value}
                    onChange={handleChanges('value')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                    inputProps={{ maxLength: 30 }}
                  />
                </div>
              </div>
              <div className="form-wrapper">
                <div className="mui-custom-form input-md">
                  <TextField
                    id="standard-description"
                    fullWidth
                    label="Description"
                    value={values.description}
                    onChange={handleChanges('description')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                    inputProps={{ maxLength: 30 }}
                    helperText={
                      showDescriptionError
                        ? SystemListConstants.DESCRIPTION_ERROR
                        : null
                    }
                    error={
                      showDescriptionError
                        ? SystemListConstants.DESCRIPTION_ERROR
                        : null
                    }
                  />
                  <div className="sub-radio sub-radios">
                    <input
                      type="radio"
                      id="standard-radio-desc-startswith"
                      value="StartsWith"
                      name="descriptionSelected"
                      checked={values.descriptionSelected === 'StartsWith'}
                      onChange={handleChanges('descriptionSelected')}
                    />
                    <label
                      for="standard-radio-desc-startswith"
                      className="text-black"
                    >
                      Starts With
                    </label>
                    <input
                      type="radio"
                      id="standard-radio-desc-contains"
                      value="Contains"
                      name="descriptionSelected"
                      checked={values.descriptionSelected === 'Contains'}
                      onChange={handleChanges('descriptionSelected')}
                      className="ml-2"
                    />
                    <label
                      for="standard-radio-desc-contains"
                      className="text-black"
                    >
                      Contains
                    </label>
                  </div>
                </div>
                <div
                  className="mui-custom-form input-md" // style ={ { marginLeft: '0px' } }
                >
                  <TextField
                    id="standard-businessName"
                    fullWidth
                    label="Business Name"
                    value={values.businessName}
                    onChange={handleChanges('businessName')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                    inputProps={{ maxLength: 50 }}
                    helperText={
                      showBusinessNameError
                        ? SystemListConstants.BUSINESS_NAME_ERROR
                        : null
                    }
                    error={
                      showBusinessNameError
                        ? SystemListConstants.BUSINESS_NAME_ERROR
                        : null
                    }
                  />
                  <div className="sub-radio sub-radios">
                    <input
                      type="radio"
                      id="standard-radio-bname-startswith"
                      value="StartsWith"
                      name="businessNameSelected"
                      checked={values.businessNameSelected === 'StartsWith'}
                      onChange={handleChanges('businessNameSelected')}
                    />
                    <label
                      for="standard-radio-bname-startswith"
                      className="text-black"
                    >
                      Starts With
                    </label>
                    <input
                      type="radio"
                      id="standard-radio-bname-contains"
                      value="Contains"
                      name="businessNameSelected"
                      checked={values.businessNameSelected === 'Contains'}
                      onChange={handleChanges('businessNameSelected')}
                      className="ml-2"
                    />
                    <label
                      for="standard-radio-bname-contains"
                      className="text-black"
                    >
                      Contains
                    </label>
                  </div>
                </div>
                <div
                  className="mui-custom-form with-select input-md" // style={{ marginLeft: '0px' }}
                >
                  <TextField
                    id="standard-select-functionalArea"
                    fullWidth
                    select
                    label="List Type"
                    value={values.listType}
                    onChange={handleChanges('listType')}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  >
                    <MenuItem
                      selected
                      key="Please Select One"
                      value="Please Select One"
                    >
                      Please Select One
                    </MenuItem>
                    {listTypeData
                      ? listTypeData.map((option, index) => (
                        <MenuItem key={index} value={option.code}>
                          {option.description}
                        </MenuItem>
                      ))
                      : null}
                  </TextField>
                </div>
              </div>
              <div className="float-right mr-3 mb-2 ">
                <Button
                  variant="outlined"
                  color="primary"
                  className="btn btn-primary"
                  onClick={() => searchCheck(values)}
                >
                  <i class="fa fa-search" aria-hidden="true"></i>
                  Search
                </Button>
                <Button
                  variant="outlined"
                  color="primary"
                  className="bt-reset btn-transparent  ml-1"
                  onClick={() => resetTable()}
                >
                  <i class="fa fa-undo" aria-hidden="true"></i>
                  Reset
                </Button>
              </div>
              <div className="clearfix"></div>
            </form>

            {showTable && paylod && paylod.length > 0 ? (
              <div className="tab-holder">
                <SystemListSearchTableComponent tableData={paylod} />
              </div>
            ) : null}
            <Footer print />
          </div>
        </div>
      </div>
    </div>
  );
}
export default withRouter((SystemListSearch));
