/* eslint-disable no-unused-vars */
import React from 'react';
import TableComponent from '../../../../../SharedModules/Table/Table';

const headCells = [
  { id: 'beginDate', numeric: false, disablePadding: true, label: 'Begin Date', width:'20%', isDate:true,},
  { id: 'endDate', numeric: false, disablePadding: false, label: 'End Date', width:'20%', isDate:true},
  { id: 'lineofbusiness', numeric: false, disablePadding: false, label: 'LOB', width:'20%'},
  { id: 'startingValue', numeric: false, disablePadding: false, label: 'Begin Value', width:'20%' },
  { id: 'endingValue', numeric: false, disablePadding: false, label: 'End Value', width:'20%'}
];

export default function SystemListAddTable (props) {
  const tableComp = <TableComponent fixedTable headCells={headCells}
    tableData={props.tableData ? props.tableData : []}
    onTableRowClick={props.onEditSystemlistDetail}
    defaultSortColumn={headCells[0].id} isSearch={false} onTableRowDelete = {props.rowDeleteSystemListDetails}/>;
  return (
    tableComp
  );
}
