/* eslint-disable no-unused-vars */
import React from 'react';
import PropTypes from 'prop-types';
import clsx from 'clsx';
import TextField from '@material-ui/core/TextField';
import CloseIcon from '@material-ui/icons/Close';
import Bootstrap, { Button } from 'react-bootstrap';
import { lighten, makeStyles, useTheme, withStyles } from '@material-ui/core/styles';
import Table from '@material-ui/core/Table';
import TableBody from '@material-ui/core/TableBody';
import TableCell from '@material-ui/core/TableCell';
import TableHead from '@material-ui/core/TableHead';
import TableFooter from '@material-ui/core/TableFooter';
import TablePagination from '@material-ui/core/TablePagination';
import TableRow from '@material-ui/core/TableRow';
import TableSortLabel from '@material-ui/core/TableSortLabel';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import Paper from '@material-ui/core/Paper';
import Checkbox from '@material-ui/core/Checkbox';
import IconButton from '@material-ui/core/IconButton';
import Tooltip from '@material-ui/core/Tooltip';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Switch from '@material-ui/core/Switch';
import DeleteIcon from '@material-ui/icons/Delete';
import FilterListIcon from '@material-ui/icons/FilterList';
import { Link } from 'react-router-dom';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import MapSetAddDialogTable from './MapSetUpdateDefinitionData';
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import 'date-fns';
import Grid from '@material-ui/core/Grid';
import Radio from '@material-ui/core/Radio';

function desc (a, b, orderBy) {
  if (b[orderBy] < a[orderBy]) {
    return -1;
  }
  if (b[orderBy] > a[orderBy]) {
    return 1;
  }
  return 0;
}

function stableSort (array, cmp) {
  const stabilizedThis = array.map((el, index) => [el, index]);
  stabilizedThis.sort((a, b) => {
    const order = cmp(a[0], b[0]);
    if (order !== 0) return order;
    return a[1] - b[1];
  });
  return stabilizedThis.map(el => el[0]);
}

function getSorting (order, orderBy) {
  return order === 'desc' ? (a, b) => desc(a, b, orderBy) : (a, b) => -desc(a, b, orderBy);
}

const useStyles1 = makeStyles(theme => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5)
  }

}));

function TablePaginationActions (props) {
  const classes = useStyles1();
  const theme = useTheme();
  const { count, page, rowsPerPage, onChangePage } = props;

  const handleFirstPageButtonClick = event => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = event => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = event => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = event => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  };

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}

TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onChangePage: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired
};

const headCells = [
  { id: 'beginDate', numeric: false, disablePadding: true, label: '---Begin Date', width: 80 },
  { id: 'endDate', numeric: false, disablePadding: false, label: 'End Date', width: 80 },
  { id: 'exclude', numeric: false, disablePadding: false, label: 'Exclude', width: 90 },
  { id: 'dataElementCriteria', numeric: false, disablePadding: false, label: 'Data Element Criteria', width: 120 },
  { id: 'functionalArea', numeric: false, disablePadding: false, label: 'Functional Area', width: 80 },
  { id: 'value', numeric: false, disablePadding: false, label: 'Value', width: 80 },
  { id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date', width: 80 }
];

function EnhancedTableHead (props) {
  const { classes, onSelectAllClick, order, orderBy, numSelected, rowCount, onRequestSort } = props;
  const createSortHandler = property => event => {
    onRequestSort(event, property);
  };

  return (
    <TableHead>
      <TableRow>
        {/* <TableCell padding="checkbox">
          <Checkbox
            indeterminate={numSelected > 0 && numSelected < rowCount}
            checked={numSelected === rowCount}
            onChange={onSelectAllClick}
            inputProps={{ 'aria-label': 'select all desserts' }}
          />
        </TableCell> */}
        {headCells.map(headCell => (
          <TableCell
            key={headCell.id}
            align={headCell.numeric ? 'right' : 'left'}
            padding='default'
            sortDirection={orderBy === headCell.id ? order : false}
          >
            <TableSortLabel
              active={orderBy === headCell.id}
              direction={order}
              onClick={createSortHandler(headCell.id)}
            >
              {headCell.label}
              {orderBy === headCell.id ? (
                <span className={classes.visuallyHidden}>
                  {order === 'desc' ? 'sorted descending' : 'sorted ascending'}
                </span>
              ) : null}
            </TableSortLabel>
          </TableCell>
        ))}
      </TableRow>
    </TableHead>
  );
}

EnhancedTableHead.propTypes = {
  classes: PropTypes.object.isRequired,
  numSelected: PropTypes.number.isRequired,
  onRequestSort: PropTypes.func.isRequired,
  onSelectAllClick: PropTypes.func.isRequired,
  order: PropTypes.oneOf(['asc', 'desc']).isRequired,
  orderBy: PropTypes.string.isRequired,
  rowCount: PropTypes.number.isRequired
};

const useToolbarStyles = makeStyles(theme => ({
  root: {
    paddingLeft: theme.spacing(2),
    paddingRight: theme.spacing(1)
  },
  highlight:
    theme.palette.type === 'light'
      ? {
        color: theme.palette.secondary.main,
        backgroundColor: lighten(theme.palette.secondary.light, 0.85)
      }
      : {
        color: theme.palette.text.primary,
        backgroundColor: theme.palette.secondary.dark
      },
  title: {
    flex: '1 1 100%'
  }
}));

const EnhancedTableToolbar = props => {
  const classes = useToolbarStyles();
  const { numSelected } = props;

  return (
    <Toolbar
      className={clsx(classes.root, {
        [classes.highlight]: numSelected > 0
      })}
    >
      {numSelected > 0 ? (
        <Typography className={classes.title} color="inherit" variant="subtitle1">
          {numSelected} selected
        </Typography>
      ) : null}

      {numSelected > 0 ? (
        <Tooltip title="Delete">
          <IconButton aria-label="delete">
            <DeleteIcon />
          </IconButton>
        </Tooltip>
      ) : null}
    </Toolbar>
  );
};

EnhancedTableToolbar.propTypes = {
  numSelected: PropTypes.number.isRequired
};

const useStyles = makeStyles(theme => ({
  root: {
    width: '100%',
    marginTop: theme.spacing(3)
  },
  paper: {
    width: '100%',
    marginBottom: theme.spacing(2)
  },
  table: {
    minWidth: 750
  },
  tableWrapper: {
    overflowX: 'auto'
  },
  visuallyHidden: {
    border: 0,
    clip: 'rect(0 0 0 0)',
    height: 1,
    margin: -1,
    overflow: 'hidden',
    padding: 0,
    position: 'absolute',
    top: 20,
    width: 1
  }
}));

const styles = theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(2)
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});

const DialogTitle = withStyles(styles)(props => {
  const { children, classes, onClose } = props;
  return (
    <MuiDialogTitle disableTypography className={classes.root}>
      <Typography variant="h6">{children}</Typography>
      {onClose ? (
        <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
          <CloseIcon />
        </IconButton>
      ) : null}
    </MuiDialogTitle>
  );
});

const DialogContent = withStyles(theme => ({
  root: {
    padding: theme.spacing(2)
  }
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(1)
  }
}))(MuiDialogActions);

export default function SystemParameterTable (props) {
  const classes = useStyles();
  const [order, setOrder] = React.useState('asc');
  const [orderBy, setOrderBy] = React.useState('parameterNumber');
  const [selected, setSelected] = React.useState([]);
  // const [page, setPage] = React.useState(0);
  // const [dense, setDense] = React.useState(false);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const newDialogData1 = [];
  // const classes = useStyles2();
  const [page, setPage] = React.useState(0);
  // const [rowsPerPage, setRowsPerPage] = React.useState(5);
  // const [open, setOpen] = React.useState(false);
  const [selectedDate, setSelectedDate] = React.useState(new Date('2014-08-18T21:11:54'));

  const handleDateChange = date => {
    setSelectedDate(date);
  };

  const [dataElement, setDataElement] = React.useState({
    id: 0,
    dataElementCriteria: '',
    functionalArea: '',
    value: ''
  });
  const [openDialog, setOpenDialog] = React.useState(false);
  const emptyRows = rowsPerPage - Math.min(rowsPerPage, props.tableData.length - page * rowsPerPage);
  const [showDialog, setShowDialog] = React.useState(false);
  const [fullWidth, setFullWidth] = React.useState(true);
  const [maxWidth, setMaxWidth] = React.useState('md');
  const [values, setValues] = React.useState(0);
  const [id, setId] = React.useState(0);

  const [newDialogData, setnewDialogData] = React.useState([
    {
      exclude: 'No',
      dataElementCriteria: 'PQS-PlaceofSvc',
      type: 'List',
      functionalArea: 'C1-Claims Ent',
      value: 'Omni Clinic'
    }
  ]);
  const handleChangeDataElement = name => event => {
    setDataElement({ ...dataElement, [name]: event.target.value });
  };

  const handleChange = name => event => {
    setValues({ ...values, [name]: event.target.value });
  };
  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleClickOpen = (row) => {
    setOpen(true);
    setDataElement({
      beginDate: row.beginDate,
      endDate: row.endDate,
      format: ''
    });
  };

  const handleClose = () => {
    setOpen(false);
    setDataElement({
      beginDate: '',
      endDate: '',
      format: ''
    });
  };

  const handleClickOpenNewDialog = () => {
    // setOpen(false);
    setOpenDialog(true);
    setShowDialog(true);
    setDataElement({
      dataElementCriteria: '',
      functionalArea: '',
      value: ''
    });
  };
  const [open, setOpen] = React.useState(false);

  const handleReset = (row) => {
    setDataElement({
      id: row.id,
      code: '',
      shortDescription: '',
      longDescription: '',
      voidDate: ''

    });
    // setOpen(false);
  };
  const handleOpen = (row) => {
    setDataElement({
      id: row.id,
      code: row.code,
      shortDescription: row.shortDescription,
      longDescription: row.longDescription,
      voidDate: row.voidDate
      // constantText : row.constantText

    });
    setOpen(true);
  };

  const handleRequestSort = (event, property) => {
    const isDesc = orderBy === property && order === 'desc';
    setOrder(isDesc ? 'asc' : 'desc');
    setOrderBy(property);
  };

  const handleSelectAllClick = event => {
    if (event.target.checked) {
      const newSelecteds = props.tableData.map(n => n.name);
      setSelected(newSelecteds);
      return;
    }
    setSelected([]);
  };

  const handleClick = (event, name) => {
    const selectedIndex = selected.indexOf(name);
    let newSelected = [];

    if (selectedIndex === -1) {
      newSelected = newSelected.concat(selected, name);
    } else if (selectedIndex === 0) {
      newSelected = newSelected.concat(selected.slice(1));
    } else if (selectedIndex === selected.length - 1) {
      newSelected = newSelected.concat(selected.slice(0, -1));
    } else if (selectedIndex > 0) {
      newSelected = newSelected.concat(
        selected.slice(0, selectedIndex),
        selected.slice(selectedIndex + 1)
      );
    }

    setSelected(newSelected);
  };

  const handleChangeRowsPerPage = event => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const isSelected = name => selected.indexOf(name) !== -1;

  return (
    <div className={classes.root}>
      <Paper className={classes.paper}>
        {/* <EnhancedTableToolbar numSelected={selected.length} /> */}
        <div className={classes.tableWrapper}>
          <Table
            className={clsx(classes.table, 'customDataTable', 'with-link')}
            aria-labelledby="tableTitle"
            // size={dense ? 'small' : 'medium'}
            aria-label="enhanced table"
          >
            <EnhancedTableHead
              classes={classes}
              numSelected={selected.length}
              order={order}
              orderBy={orderBy}
              onSelectAllClick={handleSelectAllClick}
              onRequestSort={handleRequestSort}
              rowCount={props.tableData.length}
            />
            <TableBody>
              {stableSort(props.tableData, getSorting(order, orderBy))
                .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                .map((row, index) => {
                  const isItemSelected = isSelected(row.parameterNumber);
                  const labelId = `enhanced-table-checkbox-${index}`;

                  return (
                    <TableRow
                      hover
                      onClick={() => handleClickOpen(row)}
                      role="checkbox"
                      aria-checked={isItemSelected}
                      tabIndex={-1}
                      key={row.id}
                      selected={isItemSelected}
                    >
                      <TableCell component="th" id={labelId} scope="row" padding="default" style={{ color: '#007bff', cursor: 'pointer', textDecoration: 'underline' }} onClick={() => handleClickOpen(row)}>
                        {row.beginDate}
                      </TableCell>
                      <TableCell > {row.endDate} </TableCell>
                      <TableCell >{row.exclude}</TableCell>
                      <TableCell >{row.dataElementCriteria}</TableCell>
                      <TableCell >{row.functionalArea}</TableCell>
                      <TableCell >{row.value}</TableCell>
                      <TableCell >{row.voidDate}</TableCell>
                      {/* <TableCell align="right">{row.carbs}</TableCell>
                      <TableCell align="right">{row.protein}</TableCell> */}

                    </TableRow>
                  );
                })}
              {emptyRows > 0 && (
                <TableRow>
                  <TableCell colSpan={6} />
                </TableRow>
              )}
            </TableBody>
            <TableFooter>
              <TableRow>
                <TablePagination
                  rowsPerPageOptions={[5, 10, 25]}
                  colSpan={4}
                  count={props.tableData.length}
                  rowsPerPage={rowsPerPage}
                  page={page}
                  SelectProps={{
                    inputProps: { 'aria-label': 'rows per page' },
                    native: true
                  }}
                  onChangePage={handleChangePage}
                  onChangeRowsPerPage={handleChangeRowsPerPage}
                  ActionsComponent={TablePaginationActions}
                />
              </TableRow>
            </TableFooter>
          </Table>
        </div>
      </Paper>
      <div className="clearfix"></div>
      <Dialog className="custom-dialog" fullWidth={fullWidth} maxWidth={maxWidth} onClose={handleClose} open={open} disableBackdropClick>
        <DialogTitle id="customized-dialog-title" onClose={handleClose}>
          Edit Map Definition
        </DialogTitle>
        <DialogContent dividers>
          <div className="hide-on-print">
            <Button variant="outlined" color="primary" className="btn btn-primary ml-1" onClick={handleClickOpenNewDialog}>
              Add Definition Data
            </Button>
          </div>
          <div>
            <form style={{ display: 'flex', flexWrap: 'wrap' }} autoComplete="off">
              {/* <form className={clsx(classes.container, 'form-170')} autoComplete="off"> */}

              {/* <div className={classes.container}> */}
              <div className="mui-custom-form">

                <label className="MuiFormLabel-root small-label no-margin">Void</label>
                <div className="sub-radio no-margin">
                  <Radio
                    value="Yes"
                    id="voidyeslabel"
                    checked={dataElement.associatedselectedOption}
                    onChange={handleChangeDataElement('associatedselectedOption')}
                  /><label className="text-black" for="voidyeslabel">Yes</label>
                  <Radio
                    value="No"
                    id="voidnolabel"
                    checked={!dataElement.associatedselectedOption}
                    onChange={handleChangeDataElement('associatedselectedOption')}
                    className="ml-2"
                  /><label className="text-black" for="voidnolabel">No</label>
                </div>
              </div>
              {/* <div className="mui-custom-form">
                  <TextField
                    id="begindate-picker-dialog"
                    label="Begin Date"
                    format="MM/dd/yyyy"
                    value={dataElement.beginDate}
                    onChange={handleChange('beginDate')}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    // disabled= {true}
                  />
                </div>
                <div className="mui-custom-form">
                  <TextField
                    id="enddate-picker-dialog"
                    label="End Date"
                    format="MM/dd/yyyy"
                    value={dataElement.endDate}
                    onChange={handleChange('beginDate')}
                    InputLabelProps={{
                      shrink: true,
                    }}
                    // disabled= {true}
                  />

                </div> */}
              <MuiPickersUtilsProvider utils={DateFnsUtils}>
                <Grid container >
                  <div className="mui-custom-form">
                    <KeyboardDatePicker
                      maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                      id="begindate-picker-dialog"
                      label="Begin Date"
                      format="MM/dd/yyyy"
                      value={selectedDate}
                      // value={dataElement.beginDate}
                      onChange={handleDateChange}
                      KeyboardButtonProps={{
                        'aria-label': 'change date'
                      }}
                    />
                  </div>
                  <div className="mui-custom-form">
                    <KeyboardDatePicker
                      maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                      id="enddate-picker-dialog"
                      label="End Date"
                      format="MM/dd/yyyy"
                      value={selectedDate}
                      // value={dataElement.endDate}
                      onChange={handleDateChange}
                      KeyboardButtonProps={{
                        'aria-label': 'change date'
                      }}
                    />
                  </div>

                </Grid>

              </MuiPickersUtilsProvider>
              {/* </div> */}
            </form>
          </div>
          <div className="mt-3 tab-holder">
            <MapSetAddDialogTable tableData={newDialogData} />
          </div>
        </DialogContent>

      </Dialog>

    </div>
  );
}
