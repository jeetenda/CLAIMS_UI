/* eslint-disable no-unused-vars */
import React, { useState, useEffect, useRef } from "react";
import MapSetSearchTableComponent from "./MapSetSearchTableComponent";
import MenuItem from "@material-ui/core/MenuItem";
import { Button } from "react-bootstrap";
import TextField from "@material-ui/core/TextField";
import { makeStyles } from "@material-ui/core/styles";
import * as MapSetConstants from "./MapSetConstants";
import {
  mapSetAction,
  resetSearchMapSet
} from "../../Store/Actions/MapSet/mapSetActions";
import { useDispatch, useSelector } from "react-redux";
import { withRouter } from "react-router";

import Spinner from "../../../../SharedModules/Spinner/Spinner";
import { generateUUID } from "../../../../SharedModules/DateUtilities/DateUtilities";
import dropdownCriteria from "./MapSetSearch.json";
import {
  AppConfigDropdownActions,
  DataElementMapDropdownActions
} from "../../Store/Actions/AppConfigCommon/AppConfigActions";
import ReactToPrint from "react-to-print";
import { setPrintLayout } from "../../../../SharedModules/Store/Actions/SharedAction";
import Footer from "../../../../SharedModules/Layout/footer";
import "./MapSetSearch.css";

const useStyles = makeStyles(theme => ({
  container: {
    display: "flex",
    flexWrap: "wrap"
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1)
  },
  dense: {
    marginTop: theme.spacing(2)
  },
  menu: {
    width: 400
  },
  paper: {
    maxWidth: "max-content"
  }
}));

function MapSetSearch(props) {
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const toPrintRef = useRef();
  const classes = useStyles();
  const [showTable, setShowTable] = React.useState(false);
  let errorMessagesArray = [];
  const dropDownDispatch = dropdownvalues =>
    dispatch(AppConfigDropdownActions(dropdownvalues));
  const dataElemDropDownDispatch = () => dispatch(DataElementMapDropdownActions());

  useEffect(() => {
    dropDownDispatch(dropdownCriteria);
    dataElemDropDownDispatch();
  }, []);

  const [values, setValues] = React.useState({
    lineOfBusiness: "Please Select One",
    mapType: "Please Select One",
    mapSetID: "",
    mapDescription: "",
    fieldValue: null,
    mapSetIDStartsOrContains: null,
    mapDescStartsOrContains: null,
    dataElementName: "Please Select One"
  });

  const [errorMessages, seterrorMessages] = React.useState([]);
  const [
    { showMapIDError, showMapDescError },
    setShowError,
    showMapDesError
  ] = React.useState(false);
  const handleChanges = name => event => {
    setValues({ ...values, [name]: event.target.value });
  };
  const [errorMsg, setErrorMsg] = React.useState(false);
  const [lobData, setLobData] = React.useState([]);
  const [mapType, setMapType] = React.useState([]);
  const [dataElement, setDataElement] = React.useState([]);
  const resetTable = () => {
    seterrorMessages([]);
    setShowError({
      showMapIDError: false,
      showMapDescError: false
    });
    setValues({
      lineOfBusiness: "Please Select One",
      mapType: "Please Select One",
      mapSetID: "",
      mapDescription: "",
      dataElementName: "Please Select One",
      fieldValue: "",
      columnName: "",
      tableName: ""
    });
    setShowTable(false);
    setErrorMsg(false);

    const valuetoredirect = redirect - 1;
    setRedirect(valuetoredirect);
  };

  /// INTEGRATION PART BEGIN
  const dispatch = useDispatch();
  const [spinnerLoader, setSpinnerLoader] = React.useState(false);
  const onReset = () => dispatch(resetSearchMapSet());

  useEffect(() => {
    onReset();
  }, []);

  let paylod = [];
  const [redirect, setRedirect] = React.useState(0);
  const onSearch = values => dispatch(mapSetAction(values));
  const [functionalAreaReference, setfunctionalAreaReference] = useState([]);
  paylod = useSelector(state => state.appConfigState.mapSetState.payload);
  const dropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.appConfigDropdown
  );
  const datElemDropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.dataElementMapDropdown
  );

  const [LOBReference, setLOBReference] = useState([]);
  const [MapTypeReference, setMapTypeReference] = useState([]);

  const [dataElementReference, setdataElementReference] = useState([]);

  useEffect(()=>{
    if(props && props.location && props.location.search){
      var query = new URLSearchParams(props.location.search);
      let id = query.get('id')
      let searchCriteria={
        lineOfBusiness: null,
        mapType: null,
        mapSetID:id,
        mapDescription: null,
        dataElementName: null,
        fieldValue: null,
        columnName: null,
        tableName: null
      }
      setSpinnerLoader(true);
      setValues({...values,mapSetID :id});
       let valuetoredirect = 0;
      valuetoredirect = valuetoredirect + 1;
      setRedirect(valuetoredirect);
      onSearch(searchCriteria);
    }
  },[])

  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj["Reference#1019"]) {
        setLOBReference(dropdown.listObj["Reference#1019"]);
      }
      if (dropdown.listObj["Reference#1022"]) {
        setMapTypeReference(dropdown.listObj["Reference#1022"]);
      }
    }
  }, [dropdown]);

  useEffect(() => {
    if (datElemDropdown && !datElemDropdown.systemFailure) {
      setdataElementReference(datElemDropdown.sort());
    }
  }, [datElemDropdown]);

  useEffect(() => {
    if (paylod && paylod.systemFailue) {
      const tempArray = [];
      tempArray.push(MapSetConstants.GENERIC_SYSTEM_ERROR);
      seterrorMessages(tempArray);
    }
    if (paylod) {
      setSpinnerLoader(false);
    }
    if (paylod && paylod.length === 0) {
      setErrorMsg(true);
    }
    if (paylod === "") {
      setErrorMsg(true);
      setSpinnerLoader(false);
    }
    // setErrorMsg(true);
  }, [paylod]);

  const payloadData = paylod ? paylod[0] : {};

  const lobDescriptionMap = lobCode => {
    const filteredValue = LOBReference.filter(
      (lob, index) => lob.code === lobCode
    );
    if (filteredValue && filteredValue.length > 0) {
      return filteredValue[0].description;
    }
    return lobCode;
  };

  const mapTypeDescriptionMap = mapTypeCode => {
    const filteredValue = MapTypeReference.filter(
      (mapType, index) => mapType.code === mapTypeCode
    );
    if (filteredValue && filteredValue.length > 0) {
      return filteredValue[0].description;
    }
    return mapTypeCode;
  };

  if (paylod && paylod.length > 0) {
    paylod.map((data, index) => {
      data.lobDesc = lobDescriptionMap(data.lobCode);
      data.mapTypeDesc = mapTypeDescriptionMap(data.mapTypeCode);
    });
  }

  if (redirect === 1) {
    if (paylod != null) {
      if (paylod.length === 1 && payloadData !== {}) {
        payloadData.mapDefDetail.map(var1 => {
          //var1.id = generateUUID();
        });
        functionalAreaReference.map(fDesc => {
          if (payloadData.functionalArea === fDesc.code) {
            payloadData.functionalAreaDesc = fDesc.description;
          }
        });
        props.history.push({
          pathname: "/MapSetEdit",
          state: { payloadData }
        });
      }
    }
  }

  // INTEGRATION PART END

  const searchCheck = values => {
    console.log(values,"values search")
    // setErrorMsg(true);
    setShowTable(false);
    errorMessagesArray = [];
    seterrorMessages([]);
    var showMapIDError;
    var showMapDescError = false;
    if (
      values.mapSetIDStartsOrContains &&
      (!values.mapSetID || values.mapSetID.trim().length < 2)
    ) {
      showMapIDError = true;
      errorMessagesArray.push(MapSetConstants.MAP_SET_ID_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    if (
      values.mapDescStartsOrContains &&
      (!values.mapDescription || values.mapDescription.trim().length < 2)
    ) {
      showMapDescError = true;
      errorMessagesArray.push(MapSetConstants.MAP_SET_ID_ERROR);
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    } else if (errorMessagesArray.length === 0) {
      // setUpdateData(data);
      setErrorMsg(false);
      setShowTable(true);
      setSpinnerLoader(true);
      const lobArray = [];
      lobArray.push(values.lineOfBusiness);
      const searchCriteria = {
        lineOfBusiness:
          values.lineOfBusiness !== "Please Select One" ? lobArray : null,
        mapType: values.mapType !== "Please Select One" ? values.mapType : null,
        mapSetID: values.mapSetID !== "" ? values.mapSetID : null,
        mapDescription:
          values.mapDescription !== "" ? values.mapDescription : null,
        fieldValue: values.fieldValue !== "" ? values.fieldValue : null,
        mapSetIDStartsOrContains:
          values.mapSetIDStartsOrContains === "StartsWith"
            ? 0
            : values.mapSetIDStartsOrContains === "Contains"
            ? 1
            : null,
        mapDescStartsOrContains:
          values.mapDescStartsOrContains === "StartsWith"
            ? 0
            : values.mapDescStartsOrContains === "Contains"
            ? 1
            : null,
        dataElementName:
          values.dataElementName !== "Please Select One"
            ? values.dataElementName
            : null
      };
      onSearch(searchCriteria);
      let valuetoredirect = 0;
      valuetoredirect = valuetoredirect + 1;
      setRedirect(valuetoredirect);
    }
    setShowError({
      showMapIDError: showMapIDError,
      showMapDesError: showMapDesError,
      showMapDescError: showMapDescError
    });
  };

  return (
    <div className="search-map-definition">
      {spinnerLoader ? <Spinner /> : null}
      <div className="tabs-container" ref={toPrintRef}>
        {(errorMessages.length === 0 &&
          paylod &&
          paylod.length === 0 &&
          errorMsg) ||
        (paylod === "" && errorMsg) ? (
          <div class="alert alert-danger custom-alert" role="alert">
            <li>{MapSetConstants.NO_RECORDS_FOUND}</li>
          </div>
        ) : null}
        {errorMessages.length > 0 ? (
          <div class="alert alert-danger custom-alert" role="alert">
            {errorMessages.map(message => (
              <li>{message}</li>
            ))}
          </div>
        ) : null}
        <div className="tab-header">
          <div className="tab-heading float-left">
            {MapSetConstants.MAPSET_HEADER}
          </div>
          <div className="float-right hide-on-print mt-2">
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                return new Promise(resolve => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button className="btn btn-primary ml-1">
                  <i class="fa fa-print" aria-hidden="true"></i>
                  Print
                </Button>
              )}
              content={() => toPrintRef.current}
            />

            <Button
              variant="outlined"
              color="primary"
              className="btn btn-secondary ml-1"
            >
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div>
          <div className="tab-body">
            <form autoComplete="off">
              <div className="form-wrapper">
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-select-lob"
                    select
                    label={MapSetConstants.LINE_OF_BUSINESS}
                    value={values.lineOfBusiness}
                    onChange={handleChanges("lineOfBusiness")}
                    SelectProps={{
                      MenuProps: {
                        className: classes.menu
                      }
                    }}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  >
                    <MenuItem
                      selected
                      key="Please Select One"
                      value="Please Select One"
                    >
                      Please Select One
                    </MenuItem>
                    {LOBReference
                      ? LOBReference.map((item, index) => (
                          <MenuItem key={index} value={item.code}>
                            {item.description}
                          </MenuItem>
                        ))
                      : null}
                  </TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-mapSetID"
                    label={MapSetConstants.MAP_ID}
                    value={values.mapSetID}
                    onChange={handleChanges("mapSetID")}
                    placeholder=""
                    helperText={
                      showMapIDError ? MapSetConstants.MAP_SET_ID_ERROR : null
                    }
                    inputProps={{ maxLength: 6 }}
                    InputLabelProps={{
                      shrink: true
                    }}
                    error={
                      showMapIDError ? MapSetConstants.MAP_SET_ID_ERROR : null
                    }
                  />
                  <div className="sub-radio sub-radios">
                    <input
                      type="radio"
                      value="StartsWith"
                      id="startmap"
                      checked={values.mapSetIDStartsOrContains === "StartsWith"}
                      onChange={handleChanges("mapSetIDStartsOrContains")}
                    />
                    <span className="text-black">
                      <label for="startmap">Starts With</label>
                    </span>
                    <input
                      type="radio"
                      value="Contains"
                      id="containmap"
                      checked={values.mapSetIDStartsOrContains === "Contains"}
                      onChange={handleChanges("mapSetIDStartsOrContains")}
                      className="ml-2"
                    />
                    <span className="text-black">
                      <label for="containmap">Contains</label>
                    </span>
                  </div>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-mapDesc"
                    label={MapSetConstants.MAP_DESCRIPTION}
                    value={values.mapDescription}
                    onChange={handleChanges("mapDescription")}
                    placeholder=""
                    inputProps={{ maxLength: 30 }}
                    helperText={
                      showMapDescError ? MapSetConstants.MAP_SET_ID_ERROR : null
                    }
                    InputLabelProps={{
                      shrink: true
                    }}
                    error={
                      showMapDescError ? MapSetConstants.MAP_SET_ID_ERROR : null
                    }
                  />
                  <div className="sub-radio sub-radios">
                    <input
                      type="radio"
                      value="StartsWith"
                      id="startdescription"
                      checked={values.mapDescStartsOrContains === "StartsWith"}
                      onChange={handleChanges("mapDescStartsOrContains")}
                    />
                    <span className="text-black">
                      <label for="startdescription">Starts With </label>
                    </span>
                    <input
                      type="radio"
                      value="Contains"
                      id="containsdescription"
                      checked={values.mapDescStartsOrContains === "Contains"}
                      onChange={handleChanges("mapDescStartsOrContains")}
                      className="ml-2"
                    />
                    <span className="text-black">
                      <label for="containsdescription">Contains </label>
                    </span>
                  </div>
                </div>
                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-select-mapType"
                    select
                    label={MapSetConstants.MAP_TYPE}
                    value={values.mapType}
                    onChange={handleChanges("mapType")}
                    SelectProps={{
                      MenuProps: {
                        // className: classes.menu,
                      }
                    }}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  >
                    <MenuItem
                      selected
                      key="Please Select One"
                      value="Please Select One"
                    >
                      Please Select One
                    </MenuItem>
                    {MapTypeReference
                      ? MapTypeReference.map((item, index) => (
                          <MenuItem key={index} value={item.code}>
                            {item.description}
                          </MenuItem>
                        ))
                      : null}
                  </TextField>
                </div>

                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-select-dataElementName"
                    select
                    fullWidth
                    label={MapSetConstants.DATA_ELEMENT_NAME}
                    value={values.dataElementName}
                    onChange={handleChanges("dataElementName")}
                    SelectProps={{
                      MenuProps: {
                        className: classes.menu
                      }
                    }}
                    placeholder=""
                    InputLabelProps={{
                      shrink: true
                    }}
                  >
                    <MenuItem
                      selected
                      key="Please Select One"
                      value="Please Select One" 
                    >
                      Please Select One
                    </MenuItem>
                    {dataElementReference
                      ? dataElementReference.map((item, index) => (
                          <MenuItem
                            key={index}
                            value={item}
                            style={{ width: "350px" }}
                          >
                            {item}
                          </MenuItem>
                        ))
                      : null}
                  </TextField>
                </div>

                <div className="mui-custom-form with-select input-md">
                  <TextField
                    id="standard-fieldValue"
                    label={MapSetConstants.FIELD_VALUE}
                    value={values.fieldValue}
                    onChange={handleChanges("fieldValue")}
                    placeholder=""
                    inputProps={{ maxLength: 30 }}
                    InputLabelProps={{
                      shrink: true
                    }}
                  />
                </div>
              </div>
            </form>

            <div className="float-right m-3">
              <Button
                variant="outlined"
                color="primary"
                className="btn btn-primary"
                onClick={() => searchCheck(values)}
              >
                {" "}
                <i class="fa fa-search" aria-hidden="true"></i>
                Search
              </Button>
              <Button
                variant="outlined"
                color="primary"
                className="bt-reset btn-transparent  ml-1"
                onClick={() => resetTable()}
              >
                <i class="fa fa-undo" aria-hidden="true"></i>
                Reset
              </Button>
            </div>
            <div className="clearfix"></div>
            <div></div>

            {/* </div> */}

            {showTable &&
            paylod &&
            !paylod.systemFailue &&
            paylod.length > 0 ? (
              <div className="tab-holder">
                <MapSetSearchTableComponent
                  tableData={paylod}
                  functionalAreaReference={functionalAreaReference}
                />
              </div>
            ) : null}
            <Footer print />
          </div>
        </div>
      </div>
    </div>
  );
}
export default withRouter((MapSetSearch));
