import React, { Component, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Bootstrap, { Button } from 'react-bootstrap';
import { withStyles } from '@material-ui/core/styles';
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';
import MapSetAddData from './MapSetAddData.json';
import MapSetAddValueTable from './MapSetUpdateMapDefinition';
import MapSetAddDialogTable from './MapSetUpdateMapDefinition';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import NoSaveMessage from '../../../../SharedModules/Errors/NoSaveMessage';


// import {
//     MuiPickersUtilsProvider,
//     KeyboardTimePicker,
//     KeyboardDatePicker,
//   } from '@material-ui/pickers';
//   import DateFnsUtils from '@date-io/date-fns';
//   import 'date-fns';
import Grid from '@material-ui/core/Grid';

let newDialogData1 = [];
let newData = [
    {
        beginDate: "25/10/2019", endDate: "25/10/2019", exclude: 'No', dataElementCriteria: "MBR_MCO_TRADING_PARTNER_ID",
        functionalArea: 'R2-BP', value: '8233', voidDate: ''
    }
];
let id = 0;

const useStyles = makeStyles(theme => ({
    container: {
        display: 'flex',
        flexWrap: 'wrap',
    },
    textField: {
        marginLeft: theme.spacing(1),
        marginRight: theme.spacing(1),
    },
    dense: {
        marginTop: theme.spacing(2),
    },
    menu: {
        // width: 200,
    },
}));

const styles = theme => ({
    root: {
        margin: 0,
        padding: theme.spacing(2),
    },
    closeButton: {
        position: 'absolute',
        right: theme.spacing(1),
        top: theme.spacing(1),
        color: theme.palette.grey[500],
    },
});

const DialogTitle = withStyles(styles)(props => {
    const { children, classes, onClose } = props;
    return (
        <MuiDialogTitle disableTypography className={classes.root}>
            <Typography variant="h6">{children}</Typography>
            {onClose ? (
                <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                    <CloseIcon />
                </IconButton>
            ) : null}
        </MuiDialogTitle>
    );
});

const DialogContent = withStyles(theme => ({
    root: {
        padding: theme.spacing(2),
    },
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
    root: {
        margin: 0,
        padding: theme.spacing(1),
    },
}))(MuiDialogActions);

export default function ValidValueAdd(props) {
    console.log('ValidValueAdd');
    console.log(props);
    const [showForm, setShowForm] = React.useState(true);
    const [color, setColor] = React.useState('');
    const classes = useStyles();
    //const [showDialog, setShowDialog] = React.useState(false);
    //const [id, setId] = React.useState(0);
    const [openCrossReference, setOpenCrossReference] = React.useState(false);
    const [value, setValue] = React.useState(0);
    const [open, setOpen] = React.useState(false);
    const [searchData, setSearchData] = React.useState(
        JSON.parse(props.match.params.data)
    );
    const [selectedDate, setSelectedDate] = React.useState(new Date('2014-08-18T21:11:54'));
    const [allowNavigation, setAllowNavigation] = React.useState(false);

    const handleDateChange = date => {
        setSelectedDate(date);
    };
    const [values, setValues] = React.useState({
        lobDetail: 'LOB1',
        dataFormat: 'AB',
        description: '',
        paramNumber: '12',
        LOB: 'React',
    });

    const handleClickOpen = () => {
        setAllowNavigation(true);
        setOpen(true);
        setDataElement({
            beginDate: '',
            endDate: '',
            format: ''
        })
    };

    const handleClose = () => {
        setOpen(false);
        setDataElement({
            beginDate: '',
            endDate: '',
            format: ''
        })
    };

    // const OpenNewDialog  = () => {
    //     setOpen(false);
    //     setShowDialog(true);
    // };

    // const resetTable = () => {
    //     setDataElement({
    //         beginDate: '',
    //         endDate:'',
    //         format: ''
    //     })
    // };
    const [id, setId] = React.useState(0);
    const [dataElement, setDataElement] = React.useState({
        id: 0,
        dataElementCriteria: '',
        functionalArea: '',
        value: ''
    })
    const [newDialogData, setnewDialogData] = React.useState([

    ])
    const saveMapDefinitionData = () => {
        setId(id + 1)
        dataElement.id = id
        newDialogData1.push(dataElement);
        setnewDialogData(newDialogData1)
        setOpenDialog(false)
        setAllowNavigation(false);

    };

    const handleChangeDataElement = name => event => {
        setAllowNavigation(true);
        setDataElement({ ...dataElement, [name]: event.target.value });
    }

    const handleChange = name => event => {
        setValues({ ...values, [name]: event.target.value });
    };

    const [fullWidth, setFullWidth] = React.useState(true);
    const [maxWidth, setMaxWidth] = React.useState('md');
    const handleMaxWidthChange = event => {
        setMaxWidth(event.target.value);
    };

    const handleFullWidthChange = event => {
        setFullWidth(event.target.checked);
    };
    //second dialog
    const [showDialog, setShowDialog] = React.useState(false);

    const [openDialog, setOpenDialog] = React.useState(false);

    const handleClickOpenNewDialog = () => {
        //setOpen(false);
        setOpenDialog(true);
        setShowDialog(true);
        setDataElement({
            dataElementCriteria: '',
            functionalArea: '',
            value: ''
        })

    };
    const handleCloseNewDialog = () => {
        setOpenDialog(false);
        setDataElement({
            dataElementCriteria: '',
            functionalArea: '',
            value: ''
        })
    };
    return (
        <div>
            <Prompt
                when={allowNavigation}
                message={location => location.pathname.match('/MapSetEdit') ? false : `Are sure you want to go to ${location.pathname}?`}
            />
            <div className="tabs-container">
                <div className="tab-header">
                    <div className="tab-heading float-left">
                        Map Definition
                    </div>
                    <div className="clearfix"></div>
                </div>
                <div className="tab-holder">
                    <form noValidate autoComplete="off">
                        <div className={classes.container}>
                            <div className="mui-custom-form with-select">
                                <TextField
                                    id="lob"
                                    select
                                    label="LOB*"
                                    value={searchData.lob}
                                    // disabled= {true}
                                    // onChange={handleChange('LOB')}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    SelectProps={{
                                        MenuProps: {
                                            className: classes.menu,
                                        },
                                    }}
                                >
                                    {/* {MapSetAddData.LOB.map(option => ( */}
                                    <MenuItem key={searchData.lob} value={searchData.lob}>
                                        {searchData.lob}
                                    </MenuItem>
                                    {/* ))}  */}
                                </TextField>
                            </div>

                            <div className="mui-custom-form with-select">
                                <TextField
                                    id="map-type"
                                    select
                                    label="Map Type*"
                                    value={searchData.mapType}
                                    // disabled= {true}
                                    // onChange={handleChange('mapType')}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    SelectProps={{
                                        MenuProps: {
                                            className: classes.menu,
                                        },
                                    }}
                                >
                                    {/* {MapSetAddData.MAP.map(option => ( */}
                                    <MenuItem key={searchData.mapType} value={searchData.mapType}>
                                        {searchData.mapType}
                                    </MenuItem>
                                    {/* ))} */}
                                </TextField>
                            </div>

                            <div className="mui-custom-form">
                                <TextField
                                    id="map-id"
                                    label="Map ID"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    // disabled= {true}
                                    value={searchData.mapID}
                                // onChange={handleChange('mapId')}
                                />

                            </div>
                            <div className="mui-custom-form">
                                <TextField
                                    id="description"
                                    label="Description*"
                                    multiline
                                    rows="1"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    // disabled= {true}
                                    value={searchData.mapDescription}
                                // onChange={handleChange('description')}
                                />
                            </div>
                        </div>
                        {/* <div className="mui-custom-form input-mx">
                                <TextField
                                    id="map-id"
                                    label="Map MX"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    // value={values.mailId}
                                    onChange={handleChange('mapId')}
                                    />
                                    
                            </div> */}
                        <div className="mui-custom-form">
                            <div className="sub-radio">
                                <FormControlLabel
                                    control={
                                        <Checkbox color="primary" onChange={handleChange('antoine')} value="antoine" />
                                    }
                                    label="Show Voids"
                                />

                            </div>

                        </div>
                    </form>

                    <div>
                        <Button variant="outlined" color="primary" className="btn btn-primary ml-1" onClick={handleClickOpen}>
                            Add Map definition
                        </Button>
                    </div>
                    <div className="clearfix"></div>

                    <Dialog className="custom-dialog" onClose={handleClose} fullWidth={fullWidth} maxWidth={maxWidth} open={open}>
                        <DialogTitle id="customized-dialog-title" onClose={handleClose}>
                            System Parameter
                        </DialogTitle>
                        <DialogContent dividers>
                            {/* <form noValidate autoComplete="off">
                        
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <Grid container >
                            <div className="mui-custom-form">
                             <KeyboardDatePicker
              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                id="date-picker-dialog"
                                label="Begin Date"
                                format="MM/dd/yyyy"
                                value={selectedDate}
                                onChange={handleDateChange}
                                KeyboardButtonProps={{
                               'aria-label': 'change date',
                                }}
                             />
                             </div>
                             <div className="mui-custom-form">
                             <KeyboardDatePicker
              maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                id="date-picker-dialog"
                                label="End Date"
                                format="MM/dd/yyyy"
                                value={selectedDate}
                                onChange={handleDateChange}
                                KeyboardButtonProps={{
                               'aria-label': 'change date',
                                }}
                             />
                             </div>
                             
                            </Grid>
                            
    </MuiPickersUtilsProvider>
   
    </form>
                         */}
                            <div className="mui-custom-form">
                                <Button variant="outlined" color="primary" className="btn btn-primary ml-1" onClick={handleClickOpenNewDialog}>
                                    Add Definition Data
                        </Button>
                                <div className="clearfix"></div>
                            </div>

                            <div className="mt-3 tab-holder">
                                <MapSetAddDialogTable tableData={newDialogData} />
                            </div>
                        </DialogContent>


                    </Dialog>


                    <div className="mt-3">

                        <MapSetAddValueTable tableData={newData} />

                    </div>
                    <Dialog className="custom-dialog" onClose={handleCloseNewDialog} fullWidth={fullWidth} maxWidth={maxWidth} open={openDialog}>
                        <DialogTitle id="customized-dialog-title" onClose={handleCloseNewDialog}>Add Map Definition</DialogTitle>
                        <DialogContent dividers>
                            <form noValidate autoComplete="off">
                                <div className={classes.container}>
                                    <div className="mui-custom-form">

                                        <div className="sub-radio">
                                            <FormControlLabel
                                                control={
                                                    <Checkbox color="primary" onChange={handleChange('antoine')} value="antoine" />
                                                }
                                                label="Exclude"
                                            />
                                        </div>
                                    </div>
                                    <div className="mui-custom-form with-select input-325">
                                        <TextField
                                            id="data-element-criteria"
                                            select
                                            label="Data Element Criteria*"
                                            value={dataElement.dataElementCriteria}
                                            onChange={handleChangeDataElement('dataElementCriteria')}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            SelectProps={{
                                                MenuProps: {
                                                    className: classes.menu,
                                                },
                                            }}
                                        >
                                            {MapSetAddData.DATA_ELEMENT_CRITERIA.map(option => (
                                                <MenuItem key={option} value={option}>
                                                    {option}
                                                </MenuItem>
                                            ))}
                                        </TextField>
                                    </div>
                                    <div className="mui-custom-form with-select">
                                        <TextField
                                            id="functional-area"
                                            select
                                            label="Functional Area*"
                                            value={dataElement.functionalArea}
                                            onChange={handleChangeDataElement('functionalArea')}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            SelectProps={{
                                                MenuProps: {
                                                    className: classes.menu,
                                                },
                                            }}
                                        >
                                            {MapSetAddData.FUNCTIONAL_AREA.map(option => (
                                                <MenuItem key={option} value={option}>
                                                    {option}
                                                </MenuItem>
                                            ))}
                                        </TextField>
                                    </div>
                                    <div className="mui-custom-form with-select">
                                        <TextField
                                            id="value"
                                            select
                                            label="Value*"
                                            value={dataElement.value}
                                            onChange={handleChangeDataElement('value')}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            SelectProps={{
                                                MenuProps: {
                                                    className: classes.menu,
                                                },
                                            }}
                                        >
                                            {MapSetAddData.VALUE.map(option => (
                                                <MenuItem key={option} value={option}>
                                                    {option}
                                                </MenuItem>
                                            ))}
                                        </TextField>
                                    </div>
                                </div>

                            </form>
                            <div>
                                <Button variant="outlined" color="primary" className="btn btn-primary ml-1" onClick={saveMapDefinitionData}>
                                    Save
                        </Button>
                            </div>
                            <div className="clearfix"></div>
                        </DialogContent>


                    </Dialog>



                </div>
            </div>
        </div>
    )
}
