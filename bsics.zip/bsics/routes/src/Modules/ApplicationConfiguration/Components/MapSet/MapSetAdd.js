/* eslint-disable no-unused-vars */
import React, { Component, useEffect, useState, useRef } from 'react';
import TextField from '@material-ui/core/TextField';
import Bootstrap, { Button } from 'react-bootstrap';
import {
  lighten,
  makeStyles,
  useTheme,
  withStyles
} from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import Checkbox from '@material-ui/core/Checkbox';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Dialog from '@material-ui/core/Dialog';
import MapSetUpdateDefinitionData from './MapSetUpdateDefinitionData';
import * as MapSetConstants from './MapSetConstants';
import {
  MuiPickersUtilsProvider,
  KeyboardTimePicker,
  KeyboardDatePicker
} from '@material-ui/pickers';
import {
  generateUUID,
  compareTwoDatesGreaterThanOrEqual,
  getDateInMMDDYYYYFormat,
  validateDateMinimumValue,
  getUTCTimeStamp
} from '../../../../SharedModules/DateUtilities/DateUtilities';
import DateFnsUtils from '@date-io/date-fns';
import 'date-fns';
import Grid from '@material-ui/core/Grid';
import {
  AppConfigDropdownActions,
  DataElementMapDropdownActions
} from '../../Store/Actions/AppConfigCommon/AppConfigActions';
import { useDispatch, useSelector } from 'react-redux';
import { Prompt } from 'react-router-dom';
import { withRouter } from 'react-router';

import {
  mapDefinitionAdd,
  mapDefinitionUpdate,
  mapSetActionView,
  systemListActions,
  resetSearchMapSet,
  getSubDropdownDataAction,
  resetAddMapSet
} from "../../Store/Actions/MapSet/mapSetActions";
import NoSaveMessage from "../../../../SharedModules/Errors/NoSaveMessage";
import {
  DialogTitle,
  DialogContent,
  DialogActions
} from '../../../../SharedModules/Dialog/DialogUtilities';
import TableComponent from '../../../../SharedModules/Table/Table';
import SuccessMessage from '../../../../SharedModules/Errors/SuccessMessage';
import ErrorMessage from '../../../../SharedModules/Errors/ErrorMessages';
import dropdownCriteria from './MapSetAddUpdate.json';
import * as AppConstants from '../../../../SharedModules/AppConstants';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import TabPanel from '../../../../SharedModules/TabPanel/TabPanel';
import AppBar from '@material-ui/core/AppBar';
import Notes from '../../../../SharedModules/Notes/Notes';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../../SharedModules/Store/Actions/SharedAction';
import Footer from '../../../../SharedModules/Layout/footer';
import moment from 'moment';
import PropsInit from "../../../../SharedModules/Navigation/NavHOC";
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import UnsavedChangesMessage from '../../../../SharedModules/Errors/UnsavedChangesMessage';
import "./MapSetAdd.css";
import Radio from '@material-ui/core/Radio';

const useStyles1 = makeStyles(theme => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5)
  }
}));

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap'
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1)
  },
  dense: {
    marginTop: theme.spacing(2)
  },
  menu: {
    // width: 200
  },
  root: {
    width: '100%'
  },
  paper: {
    width: '100%',
    marginBottom: theme.spacing(2)
  },
  table: {
    minWidth: 750
  },
  tableWrapper: {
    overflowX: 'auto'
  },
  visuallyHidden: {
    border: 0,
    clip: 'rect(0 0 0 0)',
    height: 1,
    margin: -1,
    overflow: 'hidden',
    padding: 0,
    position: 'absolute',
    top: 20,
    width: 1
  }
}));

const styles = theme => ({
  root: {
    margin: 0,
    padding: theme.spacing(2)
  },
  closeButton: {
    position: 'absolute',
    right: theme.spacing(1),
    top: theme.spacing(1),
    color: theme.palette.grey[500]
  }
});


function MapSetAdd(props) {
  const [value, setValue] = React.useState(0);
  const [tabOne, setTabOne] = React.useState(true);
  const [prompt, setPrompt] = useState(false);
  const [cancelType, setCancelType] = useState(false);
  const [confirm, setConfirm] = useState(false);

  const handleChangeTabs = (event, newValue) => {
    setValue(newValue);
    if (newValue === 0) {
      setTabOne(true);
    }
  };

  const renderSwitch = eombType => {
    switch (eombType) {
      case 'Range':
        return (
          <div className="form-wrapper">
            <div className="mui-custom-form input-xs">
              <label className="MuiFormLabel-root small-label">
                Value<span>*</span>
              </label>
            </div>
            <div className="mui-custom-form input-sm from-thru">
              <TextField
                id="value1"
                // type="number"
                label="From"
                // disabled={!userInquiryPrivileges || showEditField}
                InputProps={{
                  readOnly: !userInquiryPrivileges || showEditField,
                  className:
                    !userInquiryPrivileges || showEditField
                      ? "Mui-disabled"
                      : ""
                }}
                InputLabelProps={{
                  shrink: true
                }}
                inputProps={{ maxLength: 30 }}
                helperText={
                  showFromError
                    ? MapSetConstants.ADD_FROM_VALUE
                    : showFromThruError
                      ? MapSetConstants.FROM_THRU_VALUE
                      : null
                }
                error={
                  showFromError
                    ? MapSetConstants.ADD_FROM_VALUE
                    : showFromThruError
                      ? MapSetConstants.FROM_THRU_VALUE
                      : null
                }
                value={dataElement.value1}
                onChange={handleChangeDataElement("value1")}
                onInput={e => {
                  e.target.value = e.target.value.replace(
                    /[!@#$%^&*()_+=[\]{};':"\\|,<>/?~.`\- ]/,
                    ""
                  );
                }}
              />
            </div>
            <div className="mui-custom-form input-sm from-thru">
              <TextField
                id="value2"
                label="Thru"
                // type="number"
                disabled={!userInquiryPrivileges || showEditField}
                InputLabelProps={{
                  shrink: true
                }}
                inputProps={{ maxLength: 30 }}
                helperText={
                  showThruError ? MapSetConstants.ADD_THRU_VALUE : null
                }
                error={showThruError ? MapSetConstants.ADD_THRU_VALUE : null}
                value={dataElement.value2}
                onChange={handleChangeDataElement("value2")}
                onInput={e => {
                  e.target.value = e.target.value.replace(
                    /[!@#$%^&*()_+=[\]{};':"\\|,<>/?~.`\- ]/,
                    ""
                  );
                }}
              />
            </div>
          </div>
        );
      case 'List':
        return (
          <div className="form-wrapper justify-space-ar">
            <div className="mui-custom-form with-select" style={{width : '200px'}}>
              <TextField
                id="functional-area"
                fullWidth
                select
                label="Functional Area"
                required
                value={dataElement.functionalArea}
                disabled={
                  !userInquiryPrivileges
                    ? !userInquiryPrivileges
                    : rowData.voidDate != null
                }
                onChange={handleChangeDataElement('functionalArea')}
                InputLabelProps={{
                  shrink: true
                }}
                SelectProps={{
                  MenuProps: {
                    className: classes.menu
                  }
                }}
                helperText={
                  showFunctionalError
                    ? MapSetConstants.ADD_FUNCTIONAL_AREA
                    : null
                }
                error={
                  showFunctionalError
                    ? MapSetConstants.ADD_FUNCTIONAL_AREA
                    : null
                }
              >
                <MenuItem selected value="Please Select One">
                  Please Select One
                </MenuItem>
                {functionalAreaReference
                  ? functionalAreaReference.map((option, index) => (
                    <MenuItem value={option.code}>
                      {option.description}
                    </MenuItem>
                  ))
                  : null}
              </TextField>
            </div>
            <div className="mui-custom-form with-select override-width-40" style={{width : '200px'}}>
              <TextField
                id="value"
                fullWidth
                select
                label="Value"
                required
                value={dataElement.value}
                onChange={handleChangeDataElement('value')}
                InputLabelProps={{
                  shrink: true
                }}
                disabled={
                  !userInquiryPrivileges
                    ? !userInquiryPrivileges
                    : rowData.voidDate != null
                }
                helperText={
                  showValueError ? MapSetConstants.ADD_VALUE_ERROR : null
                }
                error={showValueError ? MapSetConstants.ADD_VALUE_ERROR : null}
                SelectProps={{
                  MenuProps: {
                    className: classes.menu
                  }
                }}
              >
                <MenuItem selected value="Please Select One">
                  Please Select One
                </MenuItem>
                {valuesListDropdown
                  ? valuesListDropdown.map(option => (
                    <MenuItem value={option}>{option}</MenuItem>
                  ))
                  : null}
              </TextField>
            </div>
          </div>
        );
      default:
        return null;
    }
  };
  // radio button
  let newDialogData1 = [];
  let errorMessagesArray = [];
  const successMessagesArray = [];
  let loopData = [];
  let defDataObj = {};
  let mapDefinitionDataArray = [];
  let addOutputResponse = [];
  let updateOutputResponse = [];
  let systemLists = [];
  let payloadViewDataOnAdd = [];
  let checkBeginDate = false;
  const addheadCells = [
    {
      id: 'beginDate',
      numeric: false,
      disablePadding: true,
      label: 'Begin Date',
      isDate: true,
      enableHyperLink: true,
      width: '15%'
    },
    {
      id: 'endDate',
      numeric: false,
      disablePadding: false,
      label: 'End Date',
      isDate: true,
      width: '15%'
    },
    {
      id: 'exclude',
      numeric: false,
      disablePadding: false,
      label: 'Exclude',
      isBoolean: true,
      width: '11%'
    },
    {
      id: 'dataElementCriteria',
      numeric: false,
      disablePadding: false,
      label: 'Data Element Criteria',
      width: '24%'
    },
    {
      id: 'functionalAreaDesc',
      numeric: false,
      disablePadding: false,
      label: 'Functional Area',
      width: '20%'
    },
    {
      id: 'value',
      numeric: false,
      disablePadding: false,
      label: 'Value',
      width: '15%'
    }
  ];
  const editheadCells = [
    {
      id: 'beginDate',
      numeric: false,
      disablePadding: true,
      label: 'Begin Date',
      isDate: true,
      enableHyperLink: true,
      width: '15%'
    },
    {
      id: 'endDate',
      numeric: false,
      disablePadding: false,
      width: '15%',
      isDate: true,
      label: 'End Date'
    },
    {
      id: 'exclude',
      numeric: false,
      disablePadding: false,
      label: 'Exclude',
      isBoolean: true,
      width: '11%'
    },
    {
      id: 'dataElementCriteria',
      numeric: false,
      disablePadding: false,
      label: 'Data Element Criteria',
      width: '24%'
    },
    {
      id: 'functionalAreaDesc',
      numeric: false,
      disablePadding: false,
      label: 'Functional Area',
      width: '20%'
    },
    {
      id: 'value',
      numeric: false,
      disablePadding: false,
      label: 'Value',
      width: '15%'
    },
    {
      id: 'voidDate',
      numeric: false,
      disablePadding: false,
      label: 'Void Date',
      isDate: true,
      width: '15%'
    }
  ];

  const classes = useStyles();
  const [open, setOpen] = React.useState(false);
  const [editMapDefinitionVoid, seteditMapDefinitionVoid] = React.useState(
    false
  );
  const [mapDefinitionTableData, setmapDefinitionTableData] = React.useState(
    []
  );
  const [newData, setnewData] = React.useState(
    props.location.state
      ? props.location.state.paylod
        ? props.location.state.paylod
        : props.location.state.payloadData
          ? props.location.state.payloadData.mapDefDetail
          : props.location.state.payloadViewData
            ? props.location.state.payloadViewData[0].mapDefDetail
            : props.location.state.payloadViewDataOnAdd[0].mapDefDetail
      : []
  );

  const [searchData, setSearchData] = React.useState(
    props.location.state
      ? props.location.state.paylod
        ? props.location.state.paylod
        : props.location.state.payloadData
          ? props.location.state.payloadData
          : props.location.state.payloadViewData &&
            props.location.state.payloadViewData.length > 0
            ? props.location.state.payloadViewData[0]
            : props.location.state.payloadViewDataOnAdd[0]
      : {}
  );
  const [order, setOrder] = React.useState('desc');
  const [orderBy, setOrderBy] = React.useState('');
  const [selected, setSelected] = React.useState([]);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [successMessage, setSuccessMessage] = React.useState([]);
  const [LoadSpinner, setSpinnerLoader] = React.useState(false);
  const [
    {
      showMapIDError,
      showMapDescError,
      showMapTypeError,
      showLOBError,
      showDataElementCriteriaError,
      showFunctionalError,
      showDateOverlappingError,
      showValueError,
      showFromError,
      showThruError,
      showBeginDateError,
      showEndDateError,
      showFromThruError
    },
    setShowError
  ] = React.useState(false);
  const [page, setPage] = React.useState(0);
  const [openDialog, setOpenDialog] = React.useState(false);
  const [showEditField, setshowEditField] = React.useState(false);
  const [showEditScreen, setshowEditScreen] = React.useState(false);
  const [
    showMapDefinitionAddForm,
    setshowMapDefinitionAddForm
  ] = React.useState(false);
  const [fullWidth, setFullWidth] = React.useState(true);
  const [maxWidth, setMaxWidth] = React.useState('sm');
  const [id, setId] = React.useState(0);
  const [selectedDate, setSelectedDateEdit] = React.useState('');
  const [beginDate, setSelectedDate] = React.useState(null);
  const [endDate, setSelectedDate1] = React.useState("12/31/9999");
  const [allowNavigation, setAllowNavigation] = React.useState(false);
  const [
    {
      beginDateerrorText,
      endDateerrorText,
      showMapIDErrorText,
      showMapDescriptionErrorText
    },
    setShowErrorText
  ] = React.useState('');
  const [rowData, setRowData] = React.useState({});
  const [definitionrowData, setdefinitionrowData] = React.useState({});
  const [editAddDefinitionData, setEditAddDefinitionData] = React.useState(
    false
  );
  const [values, setValues] = React.useState({
    LOB: 'Please Select One',
    mapType: 'Please Select One',
    mapId: '',
    description: ''
  });
  const [showResults, setshowResults] = React.useState(true);
  const [showEditResults, setshowEditResults] = React.useState(false);
  const [dataElement, setDataElement] = React.useState({
    id: 0,
    dataElementCriteria: 'Please Select One',
    functionalArea: 'Please Select One',
    value: 'Please Select One',
    value1: null,
    value2: null,
    associatedselectedOption: '',
    exclude: false
  });
  const [check, setcheck] = React.useState('YES');
  const [newDialogData, setnewDialogData] = React.useState([]);
  const [newDialogDataAdd, setnewDialogDataAdd] = React.useState([]);
  const [eombType, setEombtype] = useState('List');
  const dispatch = useDispatch();
  const toPrintRef = useRef();
  const printLayout = useSelector(state => state.sharedState.printLayout);
  const [LOBReference, setLOBReference] = useState([]);
  const [MapTypeReference, setMapTypeReference] = useState([]);
  const [dataElementReference, setdataElementReference] = useState([]);
  const [functionalAreaReference, setfunctionalAreaReference] = useState([]);
  const [mapDefinitionDataArrayState, setmapDefinitionDataArray] = useState([]);
  const [searchViewOnAdd, setsearchViewOnAdd] = useState({});
  const [redirect, setRedirect] = React.useState(0);
  const [useEffectValues, setUseEffectValues] = React.useState([]);
  const [valuesListDropdown, setvaluesListDropdown] = React.useState([]);
  const [openDialogEdit, setOpenDialogEdit] = React.useState(false);
  const [showDialog, setShowDialog] = React.useState(false);
  const [dataindex, setDataIndex] = React.useState(0);
  const [showVoids, setshowVoids] = React.useState(false);
  const [gridData, setgridData] = React.useState([]);
  const [updateShowVoids, setupdateShowVoids] = React.useState(0);
  const [openErrorPopUp, setOpenErrorPopUp] = React.useState(false);
  const [uuid, setUUID] = React.useState('');
  const [MapSetSeqNo, setMapSetSeqNo] = React.useState("");
  const [selectedDateRetained, setSelectedDateRetained] = React.useState(null);
  const [selectedDate1Retained, setSelectedDate1Retained] = React.useState(
    null
  );
  const [beginDateChangeFlag, setBeginDateChangeFlag] = React.useState(false);
  const [endDateChangeFlag, setEndDateChangeFlag] = React.useState(false);
  const [rowmapDefDetailData, setRowMapDefDetailData] = React.useState([]);
  const [rowMasterDataDetails, setRowMasterDataDetails] = React.useState([]);

  const logInUserID = useSelector(state => state.sharedState.logInUserID);

  const [tabValue, setTabValue] = React.useState(0);
  const [notesTableData, setNotesTableData] = React.useState([]);
  const [notesInput, setNotesInput] = React.useState({
    auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
    auditTimeStamp: getUTCTimeStamp(),
    addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
    addedAuditTimeStamp: getUTCTimeStamp(),
    versionNo: 0,
    dbRecord: false,
    sortColumn: null,
    tableName: null,
    noteSetSK: null,
    noteSourceName: null,
    notesList: notesTableData,
    globalNotesList: [],
    checkAll: null,
    addNewLinkRender: null,
    filterLinkRender: null,
    printLinkRender: null,
    completeNotesList: []
  });
  const [noteSetListInput, setNoteSetListInput] = React.useState({});
  const [usageTypeCodeData, setUsageTypeCodeData] = React.useState([]);
  const [noteaddFlag, setNoteAddFlag] = React.useState(false);
  const [editNoteData, setEditNoteData] = React.useState({});
  const onReset = () => dispatch(resetSearchMapSet());
  const onAddSuccess = rowClickValues =>
    dispatch(systemListActions(rowClickValues));
  systemLists = useSelector(
    state => state.appConfigState.mapSetState.systemLists
  );
  const dropDownDispatch = dropdownvalues =>
    dispatch(AppConfigDropdownActions(dropdownvalues));
  const dataElemDropDownDispatch = () =>
    dispatch(DataElementMapDropdownActions());

  useEffect(() => {
    addOutputResponse = [];
    dropDownDispatch(dropdownCriteria);
    dataElemDropDownDispatch();
    dispatch(resetAddMapSet());
  }, []);

  const dropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.appConfigDropdown
  );
  const datElemDropdown = useSelector(
    state => state.appConfigState.AppConfigCommonState.dataElementMapDropdown
  );

  const onMasterSaveMapDefinition = inputValues =>
    dispatch(mapDefinitionAdd(inputValues));
  addOutputResponse = useSelector(
    state => state.appConfigState.mapSetState.addResponse
  );

  const onMasterUpdateMapDefinition = searchData =>
    dispatch(mapDefinitionUpdate(searchData));
  updateOutputResponse = useSelector(
    state => state.appConfigState.mapSetState.updateResponse
  );

  const onMapDefinitionAddSuccess = searchViewOnAdd =>
    dispatch(mapSetActionView(searchViewOnAdd));
  payloadViewDataOnAdd = useSelector(
    state => state.appConfigState.mapSetState.mapSetView
  );
  const userInquiryPrivileges = true;

  const [versionNo, setVersionNo] = React.useState("");
  useEffect(() => {
    if (redirect === 1) {
      setSpinnerLoader(false);
      if (
        payloadViewDataOnAdd &&
        payloadViewDataOnAdd.length === 1 &&
        props.history.pathname !== "/MapSetEdit"
      ) {
        payloadViewDataOnAdd[0].mapDefDetail.map(var1 => {
          var1.mapDefData.map(var2 => {
            functionalAreaReference.map(fDesc => {
              if (var2.functionalArea === fDesc.code) {
                var2.functionalAreaDesc = fDesc.description;
              }
            });
          });
        });
        payloadViewDataOnAdd.AddSuccessMessage = AppConstants.SAVE_SUCCESS;
        props.history.push({
          pathname: "/MapSetEdit",
          state: { payloadViewDataOnAdd }
        });
      }
    } else if (payloadViewDataOnAdd && !payloadViewDataOnAdd.systemFailure) {
      setSpinnerLoader(false);
      // setmapDefinitionTableData(payloadViewDataOnAdd[0].mapDefDetail);
      loopData = [];
      const newData = payloadViewDataOnAdd[0].mapDefDetail;
      if (newData && typeof newData === "object") {
        newData.map((newd, i) => {
          newd.mapDefData.map((newdchild, cindex) => {
            const data = {};
            if (cindex === 0) {
              data.beginDate = newd.beginDate;
              data.endDate = newd.endDate;
              data.voidDate = newd.voidDate;
              // data.id = newd.id;
            } else {
              data.beginDate = "";
              data.endDate = "";
              data.voidDate = newd.voidDate;
            }
            data.voidIndicator = newd.voidIndicator;
            data.exclude = newdchild.excludeIndicator;
            data.functionalArea = newdchild.functionalArea;
            const tempArea = newdchild.functionalArea;
            functionalAreaReference.map(fDesc => {
              if (tempArea === fDesc.code) {
                data.functionalAreaDesc = fDesc.description;
              }
            });
            data.mapSetSeq = newd.mapSetSeq;
            data.dataElementCriteria = newdchild.dataElementCriteria;
            data.definitionData = newd.mapDefData;

            if (newdchild.type === "List") {
              data.value = newdchild.fromValue;
            } else {
              data.value = newdchild.fromValue + " to " + newdchild.thruValue;
            }
            loopData.push(data);
          });
        });
        setgridData(loopData);
        setmapDefinitionTableData(loopData);
        updateGridData(loopData);
      }
      // updateGridData(payloadViewDataOnAdd[0].mapDefDetail)
      setVersionNo(payloadViewDataOnAdd[0].versionNo);
    } else {
      setSpinnerLoader(false);
    }
  }, [payloadViewDataOnAdd]);

  const [masterSaveDefDataType, setMasterSaveDefDataType] = useState('');

  const updateGridData = data => {
    let updatedShowVoidsData = [];
    if (showVoids) {
      updatedShowVoidsData = data;
      setgridData(updatedShowVoidsData);
    } else {
      updatedShowVoidsData = data.filter(tableobj => {
        if (tableobj.voidDate == null) {
          return tableobj;
        }
      });
      gridData.map((option, index) => {
        if (option.beginDate !== data) {
        }
      });
      setgridData(updatedShowVoidsData);
    }
  };

  useEffect(() => {
    if (
      addOutputResponse !== undefined &&
      addOutputResponse.data !== undefined &&
      addOutputResponse.data.respcode === "01"
    ) {
      successMessagesArray.push(MapSetConstants.ADD_SUCCESSFULLY);
      setSuccessMessage(successMessagesArray);
      onMapDefinitionAddSuccess(searchViewOnAdd);
      // setSpinnerLoader(false);
      let valuetoredirect = 0;
      valuetoredirect = valuetoredirect + 1;
      setRedirect(valuetoredirect);
    } else if (
      addOutputResponse !== undefined &&
      addOutputResponse.data !== undefined &&
      addOutputResponse.data.respcode === "02"
    ) {
      errorMessagesArray.push(addOutputResponse.data.respdesc);
      seterrorMessages(errorMessagesArray);
      setSpinnerLoader(false);
    } else if (
      (addOutputResponse && addOutputResponse.systemError) ||
      (addOutputResponse && addOutputResponse.data === "") ||
      (addOutputResponse !== undefined &&
        addOutputResponse.data !== undefined &&
        addOutputResponse.data.respcode === "")
    ) {
      errorMessagesArray.push(MapSetConstants.GENERIC_SYSTEM_ERROR);
      seterrorMessages(errorMessagesArray);
      setSpinnerLoader(false);
    }
  }, [addOutputResponse]);
  useEffect(() => {
    if (
      updateOutputResponse !== undefined &&
      updateOutputResponse.data !== undefined &&
      updateOutputResponse.data.respcode === "01"
    ) {
      successMessagesArray.push(MapSetConstants.ADD_SUCCESSFULLY);
      setshowEditScreen(true);
      setSuccessMessage(successMessagesArray);
      const searchView = {
        lineOfBusiness: values.LOB ? values.LOB : null,
        mapType: values.mapType ? values.mapType : null,
        mapSetID: values.mapId ? values.mapId : null,
        mapDescription: values.description ? values.description : null,
        fieldValue: null,
        mapSetIDStartsOrContains: 1,
        mapDescStartsOrContains: 1,
        dataElementName: null
      };
      onMapDefinitionAddSuccess(searchViewOnAdd);
      setSpinnerLoader(false);
    } else if (
      updateOutputResponse !== undefined &&
      updateOutputResponse.data !== undefined &&
      updateOutputResponse.data.respcode === "02"
    ) {
      errorMessagesArray.push(updateOutputResponse.data.respdesc);
      seterrorMessages(errorMessagesArray);
      setSpinnerLoader(false);
      setshowEditScreen(false);
    } else if (
      (updateOutputResponse !== undefined &&
        updateOutputResponse.data === undefined) ||
      (updateOutputResponse !== undefined &&
        updateOutputResponse.data !== undefined &&
        updateOutputResponse.data.respcode === "")
    ) {
      errorMessagesArray.push(MapSetConstants.GENERIC_SYSTEM_ERROR);
      seterrorMessages(errorMessagesArray);
      setSpinnerLoader(false);
      setshowEditScreen(false);
    }
  }, [updateOutputResponse]);

  useEffect(() => {
    if (Object.keys(searchData).length != 0) {
      setshowEditScreen(true);
      setmapDefinitionDataArray(searchData.mapDefDetail);
      if (loopData.length > 0 || loopData.length === 0) {
        loopData.map(var1 => {
          functionalAreaReference.map(fDesc => {
            if (var1.functionalArea === fDesc.code) {
              var1.functionalAreaDesc = fDesc.description;
            }
          });
        });
        setmapDefinitionTableData(loopData);
      }
    } else {
      setshowEditScreen(false);
      setSuccessMessage([]);
      setmapDefinitionTableData([]);
      setnewDialogData([]);
      setnewDialogDataAdd([]);
      setgridData([]);
    }
  }, []);

  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj['Reference#1019']) {
        setLOBReference(dropdown.listObj['Reference#1019']);
      }
      if (dropdown.listObj['Reference#1022']) {
        setMapTypeReference(dropdown.listObj['Reference#1022']);
      }
      if (dropdown.listObj['Reference#1017']) {
        setfunctionalAreaReference(dropdown.listObj['Reference#1017']);
      }
      if (dropdown.listObj["General#1012"]) {
        setUsageTypeCodeData(dropdown.listObj["General#1012"]);
      }
    }
  }, [dropdown]);
  // use effect for edit page .. on finding search data setting values to edit description
  useEffect(() => {
    if (searchData) {
      setValues({
        ...values,
        description: searchData.mapDesc
          ? searchData.mapDesc
          : searchData.mapDescription
      });
      if (searchData.noteSetVO) {
        const noteSetVO = searchData.noteSetVO;
        const notesTable = searchData.noteSetVO.notesList;
        setNotesInput({
          auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          auditTimeStamp: getUTCTimeStamp(),
          addedAuditUserID: noteSetVO.addedAuditUserID
            ? noteSetVO.addedAuditUserID
            : logInUserID ? logInUserID : 'BTAYLOR1',
          addedAuditTimeStamp: noteSetVO.addedAuditTimeStamp
            ? noteSetVO.addedAuditTimeStamp
            : getUTCTimeStamp(),
          versionNo: noteSetVO.versionNo,
          dbRecord: noteSetVO.dbRecord,
          sortColumn: noteSetVO.sortColumn,
          tableName: noteSetVO.tableName,
          noteSetSK: noteSetVO.noteSetSK,
          noteSourceName: noteSetVO.noteSourceName,
          notesList: notesTableData,
          globalNotesList: [],
          checkAll: noteSetVO.checkAll,
          addNewLinkRender: noteSetVO.addNewLinkRender,
          filterLinkRender: noteSetVO.filterLinkRender,
          printLinkRender: noteSetVO.printLinkRender,
          completeNotesList: []
        });
        setNotesTableData(notesTable);
      }
    }
  }, [searchData]);

  useEffect(() => {
    if (notesInput) {
      setNoteSetListInput({
        auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
        auditTimeStamp: getUTCTimeStamp(),
        addedAuditUserID: notesInput.addedAuditUserID
          ? notesInput.addedAuditUserID
          : logInUserID ? logInUserID : 'BTAYLOR1',
        addedAuditTimeStamp: notesInput.addedAuditTimeStamp
          ? notesInput.addedAuditTimeStamp
          : getUTCTimeStamp(),
        versionNo: notesInput.versionNo,
        dbRecord: false,
        sortColumn: null,
        noteTextValue: null,
        userIdName: null,
        notesCexAuditUserID: null,
        notesCexAuditTimeStamp: null,
        notesCexAddedAuditUserID: null,
        notesCexAddedAuditTimeStamp: null,
        noteSetSK: notesInput.noteSetSK,
        usageTypeDesc: '',
        shortNotes: null,
        checked: false,
        renderNoHistoryMsg: false,
        noteSequenceNumber: null,
        currentNote: null,
        rowValue: null,
        usageTypeList: null,
        strBeginDate: moment(new Date()).format('MM/DD/YYYY hh:mm:ss'),
        usageTypeCode: 'Please Select One',
        tableName: null,
        noteText: '',
        commonEntityName: null,
        commonEntityTypeCode: null,
        commonEntityId: null,
        entityId: null,
        filterbeginDate: moment(new Date()).format('YYYY-MM-DD'),
        filterEndDate: null,
        userId: notesInput.userId ? notesInput.userId : logInUserID ? logInUserID : 'BTAYLOR1',
        noteCexVersionNum: notesInput.noteCexVersionNum
          ? notesInput.noteCexVersionNum
          : 0,
        saNoteSequenceNumber: notesInput.saNoteSequenceNumber
          ? notesInput.saNoteSequenceNumber
          : null,
        notesCexnoteTextValue: notesInput.notesCexnoteTextValue
          ? notesInput.notesCexnoteTextValue
          : 0,
        id: generateUUID()
      });
    }
  }, [notesInput]);

  useEffect(() => {
    if (datElemDropdown && !datElemDropdown.systemFailure) {
      setdataElementReference(datElemDropdown);
    }
  }, [datElemDropdown]);

  useEffect(() => {
    onReset();
    loopData = [];
    if (
      props.location.state &&
      props.location.state.payloadViewDataOnAdd &&
      props.location.state.payloadViewDataOnAdd.AddSuccessMessage
    ) {
      setSuccessMessage([
        props.location.state.payloadViewDataOnAdd.AddSuccessMessage
      ]);
    }
    if (props.location.state && props.location.state.payloadData) {
      setValues({
        LOB: props.location.state.payloadData.lineOfBusiness
          ? props.location.state.payloadData.lineOfBusiness
          : "Please Select One",
        mapType: props.location.state.payloadData.mapType
          ? props.location.state.payloadData.mapType
          : "Please Select One",
        mapId: props.location.state.payloadData.mapID
          ? props.location.state.payloadData.mapID
          : "",
        description: props.location.state.payloadData.mapDescription
          ? props.location.state.payloadData.mapDescription
          : ""
      });
    }
    if (newData && newData.length) {
      newData.map((newd, i) => {
        newd.mapDefData.map((newdchild, cindex) => {
          const data = {};
          if (cindex === 0) {
            data.beginDate = newd.beginDate;
            data.endDate = newd.endDate;
            data.voidDate = newd.voidDate;
            // data.id = newd.id;
          } else {
            data.beginDate = "";
            data.endDate = "";
            data.voidDate = newd.voidDate;
          }
          data.voidIndicator = newd.voidIndicator;
          data.exclude = newdchild.excludeIndicator;
          data.functionalArea = newdchild.functionalArea;
          const tempArea = newdchild.functionalArea;
          functionalAreaReference.map(fDesc => {
            if (tempArea === fDesc.code) {
              data.functionalAreaDesc = fDesc.description;
            }
          });

          data.dataElementCriteria = newdchild.dataElementCriteria;
          data.definitionData = newd.mapDefData;
          data.mapSetSeq = newd.mapSetSeq;
          if (newdchild.type === "List") {
            data.value = newdchild.fromValue;
          } else {
            data.value = newdchild.fromValue + " to " + newdchild.thruValue;
          }
          loopData.push(data);
        });
      });
      setgridData(loopData);
      setmapDefinitionTableData(loopData);
      updateGridData(loopData);
    }
  }, [functionalAreaReference]);
  useEffect(() => {
    if (updateShowVoids === 1) {
      updateGridData(mapDefinitionTableData);
      setupdateShowVoids(0);
    }
  }, [showVoids]);
  useEffect(() => {
    if (
      definitionrowData.functionalArea !== dataElement.functionalArea ||
      (rowData.functionalArea &&
        rowData.functionalArea !== dataElement.functionalArea)
    ) {
      setDataElement({ ...dataElement, value: "Please Select One" });
    } else {
      setDataElement({ ...dataElement, value: parseInt(dataElement.value) });
    }
    // debugger;
    if (
      dataElement.functionalArea &&
      dataElement.functionalArea !== "Please Select One" &&
      dataElement.dataElementCriteria &&
      dataElement.dataElementCriteria !== "Please Select One"
    ) {
      const rowClickValues = {
        functionalArea: dataElement.functionalArea,
        dataElementName: dataElement.dataElementCriteria
      };
      onAddSuccess(rowClickValues);
    }
  }, [dataElement.functionalArea, dataElement.dataElementCriteria]);
  useEffect(() => {
    const valuesList = [];
    if (systemLists && systemLists.length > 0) {
      systemLists.reverse().map(list => {
        valuesList.push(list.listNumber);
      });
      setvaluesListDropdown(valuesList);
      // setDataElement({ ...dataElement, value: parseInt(dataElement.value) });
    }
    if (systemLists && systemLists.length === 0) {
      setvaluesListDropdown([]);
      // setDataElement({ ...dataElement, value: parseInt(dataElement.value) });
    }
  }, [systemLists]);
  const emptyRows =
    rowsPerPage - Math.min(rowsPerPage, gridData.length - page * rowsPerPage);

  const handleChange = name => event => {
    setAllowNavigation(true);
    if (name === "mapId" || name === "description") {
      setValues({ ...values, [name]: event.target.value.toUpperCase() });
    } else {
      setValues({ ...values, [name]: event.target.value });
    }
  };

  const handleChangeshowVoids = name => event => {
    setAllowNavigation(true);
    setupdateShowVoids(1);
    setshowVoids(!showVoids);
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleeditMapDefinitionVoid = () => {
    setAllowNavigation(true);
    seteditMapDefinitionVoid(!editMapDefinitionVoid);
  };
  const resetMapDefinitionData = () => {
    setShowError(false)

    setShowErrorText({
      showMapIDErrorText: "",
      showMapDescriptionErrorText: ""
    });
    setDataElement({
      dataElementCriteria: definitionrowData.dataElementCriteria,
      functionalArea: definitionrowData.functionalArea,
      value: definitionrowData.fromValue,
      exclude: definitionrowData.excludeIndicator,
      value1: definitionrowData.fromValue,
      value2: definitionrowData.thruValue,
      selectedOption: definitionrowData.type,
      definitionData: definitionrowData.definitionData
    });
    setEombtype(definitionrowData.type);
  };

  const handleCloseNewDialog = () => {
    setOpenDialogEdit(false);
    setDataElement({
      id: 0,
      dataElementCriteria: '',
      functionalArea: 'Please Select One',
      value: 'Please Select One',
      exclude: false,
      value1: null,
      value2: null,
      selectedOption: 'List'
    });
  };

  const saveMapDefinitionData = () => {
    let defDataEditCount = 0;
    let saveData = [];
    let functionalAreaDesc = null;
    errorMessagesArray = [];
    seterrorMessages([]);
    setShowError(false);
    setShowErrorText('');
    if (validateDefinitionData()) {
      if (Object.keys(searchData).length !== 0) {
        saveData = newDialogData;
      } else {
        saveData = newDialogDataAdd;
      }
      saveData.map((mapDef1, i) => {
        if (
          mapDef1.dataElementCriteria == dataElement.dataElementCriteria &&
          ((mapDef1.type == 'List' &&
            mapDef1.functionalArea == dataElement.functionalArea &&
            mapDef1.fromValue == dataElement.value) ||
            (mapDef1.type == 'Range' &&
              mapDef1.fromValue == dataElement.value1 &&
              mapDef1.thruValue == dataElement.value2)) &&
          ((mapDef1.excludeIndicator == false &&
            (dataElement.exclude == 'No' || !dataElement.exclude)) ||
            mapDef1.excludeIndicator == dataElement.exclude ||
            (mapDef1.excludeIndicator == true &&
              (dataElement.exclude == 'Yes' || dataElement.exclude)) ||
            mapDef1.excludeIndicator == dataElement.exclude) &&
          i != dataindex
        ) {
          defDataEditCount = defDataEditCount + 1;
          return true;
        }
      });
      /* To fetch description on the basis of functional area code */
      functionalAreaDesc = functionalAreaReference.filter(
        data => data.code === dataElement.functionalArea
      );

      dataElement.functionalAreaDesc = functionalAreaDataDescriptionMap(
        dataElement.functionalArea
      );

      if (defDataEditCount === 0) {
        for (var i = 0; i <= saveData.length; i++) {
          if (i === dataindex) {
            let updatedDefinitionData = {};
            const functionAreaDescription = functionalAreaReference.filter(
              fDesc => {
                if (dataElement.functionalArea == fDesc.code) {
                  return fDesc.description;
                }
              }
            );
            updatedDefinitionData = {
              auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
              auditTimeStamp: getUTCTimeStamp(),
              addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
              addedAuditTimeStamp: getUTCTimeStamp(),
              versionNo: 0,
              dbRecord: false,
              sortColumn: null,
              auditKeyList: [],
              auditKeyListFiltered: false,
              excludeIndicator:
                dataElement.exclude == 'NO' || !dataElement.exclude
                  ? false
                  : !!(dataElement.exclude == 'YES' || dataElement.exclude),
              dataElementCriteria: dataElement.dataElementCriteria,
              type: dataElement.selectedOption,
              functionalArea:
                dataElement.selectedOption == 'List' &&
                  dataElement.functionalArea &&
                  dataElement.functionalArea != 'Please Select One'
                  ? dataElement.functionalArea
                  : null,
              value:
                dataElement.selectedOption === "List"
                  ? dataElement.value
                  : dataElement.value1 + " to " + dataElement.value2,
              fromValue: dataElement.value1
                ? dataElement.value1
                : dataElement.value,
              thruValue: dataElement.value2 ? dataElement.value2 : null,
              hiddenListNum: null,
              domain: dataElement.dataElementCriteria,
              functionalAreaDesc: dataElement.functionalArea
                ? functionAreaDescription && functionAreaDescription.length > 0
                  ? functionAreaDescription[0].description
                  : null
                : null,
              nullRecord: false,
              systemListDesc: null,
              colSeqNumber: 1,
              auditFilterList: [
                {
                  fieldName: null,
                  domainAttributeName: null,
                  displayInfo: 0,
                  duplicatePrimaryKey: false
                }
              ]
            };
            updatedDefinitionData.colSeqNumber = saveData[i].colSeqNumber;
            saveData[i] = updatedDefinitionData;
            break;
          }
        }
        setnewDialogDataAdd(saveData);
        setAllowNavigation(true);
      } else {
        errorMessagesArray.push(MapSetConstants.DEFINITION_DATA_OVERLAPPING);
        seterrorMessages(errorMessagesArray);
      }
      setOpenDialogEdit(false);
    }
  };

  const handleClickOpenEdit = row => event => {
    setUUID(row.id);
    setMapSetSeqNo(row.mapSetSeq);
    if (open === true) {
      window.scrollTo(0, document.body.scrollHeight);
    }
    seterrorMessages([]);
    setShowError(false);
    setShowErrorText('');
    const arrayTemp = row.definitionData;
    arrayTemp.map(tempvar =>
      functionalAreaReference.map(fDesc => {
        if (tempvar.functionalArea == fDesc.code) {
          tempvar.functionalAreaDesc = fDesc.description;
        }
      })
    );
    row.definitionData = arrayTemp;
    if (row.beginDate !== '') {
      setRowData({
        beginDate: row.beginDate,
        endDate: row.endDate,
        definitionData: row.definitionData,
        voidIndicator: !!(row.voidDate && row.voidDate != null),
        voidDate: row.voidDate
      });
      if (row.definitionData) {
        const defData = [];
        row.definitionData.map((option, index) => {
          if (option.type === "List") {
            option.value = option.fromValue;
          } else {
            option.value =
              option.fromValue && option.thruValue
                ? option.fromValue + " to " + option.thruValue
                : option.value;
          }
          defData.push(option);
        });
        setnewDialogData(defData);
        setnewDialogDataAdd(defData);
      } else {
        setnewDialogData(newDialogDataAdd);
        setnewDialogDataAdd([]);
      }
      if (row.voidIndicator) {
        seteditMapDefinitionVoid(row.voidIndicator);
      }
      if (row.voidDate && row.voidDate != null) {
        seteditMapDefinitionVoid(true);
      } else {
        seteditMapDefinitionVoid(false);
      }
      setSelectedDate(row.beginDate);
      setSelectedDate1(row.endDate);
      setSelectedDateRetained(row.beginDate);
      setSelectedDate1Retained(row.endDate);
      setshowEditResults(true);
      setOpen(true);

      setEombtype(row.selectedOption);
      setDataElement({
        beginDate: row.beginDate,
        endDate: row.endDate,
        format: ''
      });
    }
  };
  useEffect(() => {
    if (open === true) {
      window.scrollTo(0, document.body.scrollHeight);
    }
  }, [open]);
  const cancelEdit = () => {
    seteditMapDefinitionVoid(false)
    setShowError(false);
    setShowErrorText({
      showMapIDErrorText: '',
      showMapDescriptionErrorText: ''
    });
    setmapDefinitionDataArray(mapDefinitionDataArray);
    setnewDialogData(
      rowData.definitionData && rowData.definitionData.length > 0
        ? rowData.definitionData
        : newDialogData
    );
    setSelectedDate(rowData.beginDate);
    setSelectedDate1(rowData.endDate);
    
    setOpen(true);
  };

  const handleDateChange = date => {
    setAllowNavigation(true);
    var beginDateerrorText = '';
    const defaultEndDate = new Date('12-31-9999');
    var showBeginDateError = false;
    setSelectedDate(date);
    if (selectedDateRetained !== date) {
      setBeginDateChangeFlag(true);
    } else {
      setBeginDateChangeFlag(false);
    }
    setShowError({
      ...showEndDateError,
      showBeginDateError: showBeginDateError
    });
    setShowErrorText({
      ...endDateerrorText,
      beginDateerrorText: beginDateerrorText
    });
  };

  const handleDateChange1 = date => {
    setAllowNavigation(true);
    var endDateerrorText = '';
    var showEndDateError = false;
    setSelectedDate1(date);
    if (selectedDate1Retained !== date) {
      setEndDateChangeFlag(true);
    } else {
      setEndDateChangeFlag(false);
    }
    setShowError({
      ...showBeginDateError,
      showEndDateError: showEndDateError
    });
    setShowErrorText({
      ...beginDateerrorText,
      endDateerrorText: endDateerrorText
    });
  };
  const closeErrorPopUpDialog = () => {
    setOpenErrorPopUp(false);
  };
  const handleChangeDataElement = name => event => {
    setAllowNavigation(true);
    setDataElement({ ...dataElement, [name]: event.target.value });
    if (name == "selectedOption") {
      setEombtype(event.target.value);
      if (event.target.value === "Range") {
        setDataElement({
          ...dataElement,
          selectedOption: event.target.value,
          value: "",
          value1: ""
        });
      }
    }
    if (name === "value") {
      setDataElement({
        ...dataElement,
        value: event.target.value,
        value1: event.target.value
      });
    }
    if (name == "exclude") {
      setDataElement({ ...dataElement, exclude: !dataElement.exclude });
    }
  };

  const handleCloseAddDefinitionDataDialog = () => {
    setOpenDialog(false);
    setDataElement({
      dataElementCriteria: "Please Select One",
      functionalArea: "Please Select One",
      value: "Please Select One"
    });
  };

  const handleClickOpenNewDialog = (row, index) => event => {
    // setRowData(row);
    errorMessagesArray = [];
    seterrorMessages([]);
    setShowError(false);
    setShowErrorText('');
    setDataElement({
      dataElementCriteria: row.dataElementCriteria,
      functionalArea: row.functionalArea,
      value: row.fromValue,
      exclude: row.excludeIndicator,
      value1: row.fromValue,
      value2: row.thruValue,
      selectedOption: row.type,
      definitionData: row.definitionData
    });
    setdefinitionrowData(row);
    setDataIndex(index);
    setOpenDialogEdit(true);
    seteditMapDefinitionVoid(
      row.voidIndicator ? row.voidIndicator : editMapDefinitionVoid
    );
    setShowDialog(true);
    setEombtype(row.type);
  };

  const addMapDefinitionButton = values => {
    setSelectedDate(null);
    setSelectedDate1("12/31/9999");
    setnewDialogDataAdd([]);
    setEditAddDefinitionData(true);

    if (!showEditScreen) {
      validateHeaderFields();
    }

    if (errorMessagesArray.length == 0) {
      window.scrollTo(0, document.body.scrollHeight);
      seterrorMessages([]);
      setShowError(false);
      setshowMapDefinitionAddForm(true);
      setshowResults(false);
      setshowEditResults(false);
      setOpen(false);
    }
  };

  const addDefinitionDataButton = type => {
    setAllowNavigation(true);
    setRowData([]);
    errorMessagesArray = [];
    seterrorMessages([]);
    setSuccessMessage([]);
    const defaultEndDate = new Date("12-31-9999");
    var EditForm = false;
    if (type == 'edit') {
      EditForm = true;
    } else if (type == 'add') {
      EditForm = false;
    }
    var beginDateerrorText = '';
    var endDateerrorText = '';
    var showBeginDateError;
    var showEndDateError;
    var showDateOverlappingError = false;

    // date validations
    if (!beginDate) {
      showBeginDateError = true;
      beginDateerrorText = MapSetConstants.BEGINDATE_REQUIRED;
      errorMessagesArray.push(MapSetConstants.BEGINDATE_REQUIRED);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (beginDate.toString() === 'Invalid Date') {
      showBeginDateError = true;
      beginDateerrorText = MapSetConstants.BEGINDATE_ERROR;
      errorMessagesArray.push(MapSetConstants.BEGINDATE_ERROR);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (validateDateMinimumValue(getDateInMMDDYYYYFormat(beginDate))) {
      showBeginDateError = true;
      beginDateerrorText = AppConstants.DATE_ERROR_1964;
      errorMessagesArray.push(AppConstants.DATE_ERROR_1964);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    }
    let tempEndDate = endDate;
    if (
      getDateInMMDDYYYYFormat(new Date(beginDate)) ===
      getDateInMMDDYYYYFormat(new Date()) &&
      endDate == null
    ) {
      setSelectedDate1(defaultEndDate);
      tempEndDate = defaultEndDate;
      checkBeginDate = true;
    }
    if (!tempEndDate && !checkBeginDate) {
      showEndDateError = true;
      endDateerrorText = MapSetConstants.ENDDATE_REQUIRED;
      errorMessagesArray.push(MapSetConstants.ENDDATE_REQUIRED);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (tempEndDate.toString() === 'Invalid Date') {
      showEndDateError = true;
      endDateerrorText = MapSetConstants.ENDDATE_ERROR;
      errorMessagesArray.push(MapSetConstants.ENDDATE_ERROR);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (validateDateMinimumValue(getDateInMMDDYYYYFormat(tempEndDate))) {
      showEndDateError = true;
      endDateerrorText = AppConstants.DATE_ERROR_1964;
      errorMessagesArray.push(AppConstants.DATE_ERROR_1964);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    }
    if (
      beginDate &&
      endDate &&
      !showBeginDateError &&
      !showEndDateError &&
      compareTwoDatesGreaterThanOrEqual(new Date(endDate), new Date(beginDate))
    ) {
      showBeginDateError = true;
      beginDateerrorText = MapSetConstants.BEGINDATE_ENDDATE_MATCH;
      errorMessagesArray.push(MapSetConstants.BEGINDATE_ENDDATE_MATCH);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    }

    if (errorMessagesArray.length == 0) {
      if (type == 'edit') {
        setEditAddDefinitionData(true);
      } else if (type == 'add') {
        setEditAddDefinitionData(false);
      }
      setShowError(false);

      if (open && showEditResults) {
        setshowEditField(true);
      } else {
        setshowEditField(false);
      }

      setEombtype('List');
      setOpenDialog(true);
      setDataElement({
        dataElementCriteria: 'Please Select One',
        functionalArea: 'Please Select One',
        value: 'Please Select One',
        exclude: false,
        selectedOption: 'List'
      });
    }
    setShowError({
      showBeginDateError: showBeginDateError,
      showEndDateError: showEndDateError,
      showDateOverlappingError: showDateOverlappingError
    });
    setShowErrorText({
      beginDateerrorText: beginDateerrorText,
      endDateerrorText: endDateerrorText
    });
  };
  // Validate Map Definition Data for Add and Update functionality
  const validateDefinitionData = () => {
    var showDataElementCriteriaError;
    var showFunctionalError;
    var showValueError;
    var showFromError = false;
    var showThruError = false;
    var showFromThruError = false;
    if (
      dataElement.selectedOption == "List" &&
      (!dataElement.value || dataElement.value == "Please Select One")
    ) {
      showValueError = true;
    }
    if (
      dataElement.selectedOption == 'List' &&
      (!dataElement.functionalArea ||
        dataElement.functionalArea == 'Please Select One')
    ) {
      showFunctionalError = true;
    }
    if (
      !dataElement.dataElementCriteria ||
      dataElement.dataElementCriteria == 'Please Select One'
    ) {
      showDataElementCriteriaError = true;
    }
    if (dataElement.selectedOption == 'Range' && !dataElement.value1) {
      showFromError = true;
    }
    if (dataElement.selectedOption == 'Range' && !dataElement.value2) {
      showThruError = true;
    }
    if (!showFromError && !showThruError) {
      const value1 = dataElement.value1;
      if (
        dataElement.value1 &&
        dataElement.value2 &&
        dataElement.selectedOption == "Range" &&
        dataElement.value1.localeCompare(dataElement.value2) === 1
      ) {
        showFromThruError = true;
      }
      if (
        typeof parseFloat(dataElement.value1) === "number" &&
        typeof parseFloat(dataElement.value2) === "number" &&
        !isNaN(parseFloat(dataElement.value1)) &&
        !isNaN(parseFloat(dataElement.value2)) &&
        dataElement.selectedOption == "Range"
      ) {
        if (Number(dataElement.value1) > Number(dataElement.value2)) {
          showFromThruError = true;
        }
      }
    }
    setShowError({
      showDataElementCriteriaError: showDataElementCriteriaError,
      showFunctionalError: showFunctionalError,
      showValueError: showValueError,
      showFromError: showFromError,
      showThruError: showThruError,
      showFromThruError: showFromThruError
    });
    if (
      !showDataElementCriteriaError &&
      !showFunctionalError &&
      !showValueError &&
      !showFromError &&
      !showThruError &&
      !showFromThruError
    ) {
      return true;
    } else {
      return false;
    }
  };

  const functionalAreaDataDescriptionMap = functionalArea => {
    const filteredValue = functionalAreaReference.filter(
      (fnArea, index) => fnArea.code === functionalArea
    );
    if (filteredValue && filteredValue.length > 0) {
      return filteredValue[0].description;
    }
    return functionalArea;
  };

  const addDefinitionDataToList = dataElement => {
    errorMessagesArray = [];
    seterrorMessages([]);
    setAllowNavigation(true);
    setShowError(false);
    setShowErrorText("");
    let functionalAreaDesc = null;
    if (validateDefinitionData()) {
      if (dataElement.value1 && dataElement.value2) {
        dataElement.value = dataElement.value1 + " to " + dataElement.value2;
      }
      newDialogData1 =
        Object.keys(newDialogDataAdd).length == 0 ? [] : newDialogDataAdd;
      if (newDialogData1.length < 15) {
        let defDataCount = 0;
        functionalAreaReference.filter(mapDef1 => {
          if (
            (mapDef1.dataElementCriteria == dataElement.dataElementCriteria &&
              mapDef1.type == "List" &&
              mapDef1.functionalArea == dataElement.functionalArea &&
              mapDef1.fromValue == dataElement.value) ||
            (mapDef1.type == "Range" &&
              mapDef1.fromValue == dataElement.value1 &&
              mapDef1.thruValue == dataElement.value2 &&
              mapDef1.excludeIndicator == false &&
              (dataElement.exclude == "No" || !dataElement.exclude)) ||
            (mapDef1.excludeIndicator == true &&
              (dataElement.exclude || dataElement.exclude == "Yes"))
          ) {
            defDataCount = defDataCount + 1;
            return true;
          }
        });

        /* To fetch description on the basis of functional area code */
        functionalAreaDesc = functionalAreaReference.filter(
          data => data.code === dataElement.functionalArea
        );

        dataElement.functionalAreaDesc = functionalAreaDataDescriptionMap(
          dataElement.functionalArea
        );

        newDialogData1.map(mapDef1 => {
          if (
            (mapDef1.dataElementCriteria == dataElement.dataElementCriteria &&
              mapDef1.type == "List" &&
              mapDef1.functionalArea == dataElement.functionalArea &&
              mapDef1.fromValue == dataElement.value) ||
            (mapDef1.type == "Range" &&
              mapDef1.fromValue == dataElement.value1 &&
              mapDef1.thruValue == dataElement.value2 &&
              mapDef1.excludeIndicator == false &&
              (dataElement.exclude == "No" || !dataElement.exclude)) ||
            (mapDef1.excludeIndicator == true &&
              (dataElement.exclude || dataElement.exclude == "Yes"))
          ) {
            defDataCount = defDataCount + 1;
            return true;
          }
        });
        if (defDataCount == 0) {
          const functionAreaDescription = functionalAreaReference.filter(
            fDesc => {
              if (dataElement.functionalArea == fDesc.code) {
                return fDesc.description;
              }
            }
          );
          defDataObj = {};
          defDataObj = {
            auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            auditTimeStamp: getUTCTimeStamp(),
            addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            addedAuditTimeStamp: getUTCTimeStamp(),
            versionNo: 0,
            dbRecord: false,
            sortColumn: null,
            auditKeyList: [],
            auditKeyListFiltered: false,
            excludeIndicator:
              dataElement.exclude == "NO" || !dataElement.exclude
                ? false
                : !!(dataElement.exclude == "YES" || dataElement.exclude),
            dataElementCriteria: dataElement.dataElementCriteria,
            type: dataElement.selectedOption,
            functionalArea:
              dataElement.selectedOption == "List" &&
                dataElement.functionalArea &&
                dataElement.functionalArea != "Please Select One"
                ? dataElement.functionalArea
                : null,
            fromValue: dataElement.value1
              ? dataElement.value1
              : dataElement.value,
            thruValue: dataElement.value2 ? dataElement.value2 : null,
            value: dataElement.value,
            hiddenListNum: null,
            domain: dataElement.dataElementCriteria,
            functionalAreaDesc: dataElement.functionalArea
              ? functionAreaDescription && functionAreaDescription.length > 0
                ? functionAreaDescription[0].description
                : null
              : null,
            nullRecord: false,
            systemListDesc: null,
            colSeqNumber: 1,
            auditFilterList: [
              {
                fieldName: null,
                domainAttributeName: null,
                displayInfo: 0,
                duplicatePrimaryKey: false
              }
            ],
            id: generateUUID()
          };
          if(newDialogData1.length === 0) {
            defDataObj.colSeqNumber = 1
          } else {
            let seq = newDialogData1.length;
            defDataObj.colSeqNumber = defDataObj.colSeqNumber + seq;
          }
          newDialogData1.push(defDataObj);
          setnewDialogDataAdd(newDialogData1);
          setnewDialogData(newDialogData1);
          setAllowNavigation(true);
        } else {
          errorMessagesArray.push(MapSetConstants.DEFINITION_DATA_OVERLAPPING);
          seterrorMessages(errorMessagesArray);
        }
      } else {
        errorMessagesArray.push(MapSetConstants.DEFINITIONS_LENGTH_ERROR);
        seterrorMessages(errorMessagesArray);
      }

      setOpenDialog(false);
    }
  };
  function checkDateFormat(date) {
    date = new Date(date);
    var updatedDate = new Date(date);
    if (
      date.getMonth() + 1 < 10 &&
      date.getMonth() + 1 > 0 &&
      date.getDate() < 10 &&
      date.getDate() > 0
    ) {
      updatedDate =
        "0" +
        (date.getMonth() + 1) +
        "/0" +
        date.getDate() +
        "/" +
        date.getFullYear();
    } else if (date.getMonth() + 1 < 10 && date.getMonth() + 1 > 0) {
      updatedDate =
        "0" +
        (date.getMonth() + 1) +
        "/" +
        date.getDate() +
        "/" +
        date.getFullYear();
    } else if (date.getDate() < 10 && date.getDate() > 0) {
      updatedDate =
        date.getMonth() + 1 + "/0" + date.getDate() + "/" + date.getFullYear();
    } else {
      updatedDate =
        date.getMonth() + 1 + "/" + date.getDate() + "/" + date.getFullYear();
    }
    return updatedDate;
  }
  function onConfirm(masterSaveDefData) {
    let temp = masterSaveDefData;
    if (temp === null) {
      temp = masterSaveDefDataType;
    }
    let newArrayObj = {};
    var updatedBeginDate = new Date(null);
    var updatedEndDate = new Date(null);

    const defaultEndDate = new Date("12-31-9999");
    setSelectedDate(new Date(beginDate));
    if (checkBeginDate) {
      setSelectedDate1(defaultEndDate);
    } else {
      setSelectedDate1(endDate);
    }
    updatedBeginDate = checkDateFormat(beginDate);
    if (checkBeginDate) {
      updatedEndDate = checkDateFormat(defaultEndDate);
    } else {
      updatedEndDate = checkDateFormat(endDate);
    }
    setSelectedDate(new Date(updatedBeginDate));
    setSelectedDate1(updatedEndDate);
    var currentDate = new Date();
    var dd = currentDate.getDate();
    var mm = currentDate.getMonth() + 1;

    var yyyy = currentDate.getFullYear();
    if (dd < 10) {
      dd = "0" + dd;
    }
    if (mm < 10) {
      mm = "0" + mm;
    }
    currentDate = yyyy + "-" + mm + "-" + dd;
    if (temp === "add") {
      setnewDialogData([]);
      if (
        beginDate != null &&
        ((checkBeginDate && defaultEndDate != null) || endDate != null) &&
        newDialogDataAdd &&
        newDialogDataAdd.length > 0
      ) {
        let mapDefinitionDataObj = {};
        const uniqueuuid = generateUUID();
        let seqnum = 1;
        mapDefinitionDataArray =
          mapDefinitionDataArrayState ||
          (searchData && searchData.mapDefDetail
            ? searchData.mapDefDetail
            : []);
        if (mapDefinitionDataArray === []) {
          seqnum = 1;
        } else {
          if (mapDefinitionDataArray && mapDefinitionDataArray.length > 0) {
            if (
              mapDefinitionDataArray[mapDefinitionDataArray.length - 1] &&
              mapDefinitionDataArray[mapDefinitionDataArray.length - 1]
                .mapSetSeq
            ) {
              seqnum =
                mapDefinitionDataArray[mapDefinitionDataArray.length - 1]
                  .mapSetSeq;
            }
            seqnum = seqnum + 1;
          }
        }
        mapDefinitionDataObj = {
          auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          auditTimeStamp: getUTCTimeStamp(),
          addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
          addedAuditTimeStamp: getUTCTimeStamp(),
          versionNo: 0,
          dbRecord: false,
          sortColumn: null,
          auditKeyList: [],
          auditKeyListFiltered: false,
          beginDate: updatedBeginDate || beginDate.toLocaleDateString(),
          endDate: updatedEndDate || endDate.toLocaleDateString(),
          voidIndicator: false,
          voidStatus: "1",
          mapDefData: newDialogDataAdd || [],
          benefitPlan: null,
          voidDate: null,
          voidMapStatus: false,
          mapSetSeq: seqnum,
          colSeq: 0,
          id: uniqueuuid
        };
        let pushCount = 0;
        if (mapDefinitionDataArray.length > 0) {
          mapDefinitionDataArray.map((option, inde) => {
            if (option.mapSetSeq !== mapDefinitionDataObj.mapSetSeq) {
              if (option.beginDate === mapDefinitionDataObj.beginDate) {
                pushCount = 1;
              }
            }
          });
          if (pushCount === 1) {
            errorMessagesArray.push(MapSetConstants.BEGIN_DATE_OVERLAPPING);
          } else {
            mapDefinitionDataArray.push(mapDefinitionDataObj);
          }
        } else {
          mapDefinitionDataArray.push(mapDefinitionDataObj);
        }

        setmapDefinitionDataArray(mapDefinitionDataArray);
        const mapDefinitionTableDataTemp = [];
        mapDefinitionDataArray.map((mapDefState, i) => {
          mapDefState.mapDefData.map((definitionData, j) => {
            newArrayObj = {};
            if (j == 0) {
              newArrayObj.beginDate = mapDefState.beginDate
                ? mapDefState.beginDate
                : updatedBeginDate;
              newArrayObj.endDate = mapDefState.endDate
                ? mapDefState.endDate
                : updatedEndDate;
              newArrayObj.id = mapDefState.id;
              newArrayObj.mapSetSeq = mapDefState.mapSetSeq;
            } else {
              newArrayObj.beginDate = "";
              newArrayObj.endDate = "";
              newArrayObj.isChild = true;
            }
            newArrayObj.exclude =
              definitionData.excludeIndicator == false
                ? "No"
                : definitionData.excludeIndicator == true
                  ? "Yes"
                  : "No";
            newArrayObj.dataElementCriteria =
              definitionData.dataElementCriteria;
            newArrayObj.functionalArea = definitionData.functionalArea;
            functionalAreaReference.map(fDesc => {
              if (definitionData.functionalArea == fDesc.code) {
                newArrayObj.functionalAreaDesc = fDesc.description;
              }
            });

            newArrayObj.value =
              definitionData.fromValue &&
                definitionData.thruValue &&
                definitionData.type === "Range"
                ? definitionData.fromValue + " to " + definitionData.thruValue
                : definitionData.value
                  ? definitionData.value
                  : definitionData.fromValue;
            newArrayObj.voidDate = mapDefState.voidDate ? mapDefState.voidDate : null;
            newArrayObj.definitionData = mapDefState.mapDefData;
            mapDefinitionTableDataTemp.push(newArrayObj);
          });
        });
        setmapDefinitionTableData(mapDefinitionTableDataTemp);
        updateGridData(mapDefinitionTableDataTemp);
        resetDefinitionData(true);
        setshowMapDefinitionAddForm(false);
        setshowEditResults(false);
      } else if (
        beginDate != null &&
        ((checkBeginDate && defaultEndDate != null) || endDate != null) &&
        newDialogDataAdd &&
        newDialogDataAdd.length == 0
      ) {
        errorMessagesArray.push(MapSetConstants.DEFINITION_DATA_LENGTH);
        seterrorMessages(errorMessagesArray);
      }
    } else if (temp === "edit") {
      let updatedMapDefArray = [];
      let dataToUpdate = [];
      let pushCount = 0;
      dataToUpdate =
        mapDefinitionDataArrayState && mapDefinitionDataArrayState.length > 0
          ? mapDefinitionDataArrayState
          : searchData.mapDefDetail
            ? searchData.mapDefDetail
            : [];
      if (
        beginDate != null &&
        ((checkBeginDate && defaultEndDate != null) || endDate != null) &&
        dataToUpdate &&
        dataToUpdate.length > 0
      ) {
        dataToUpdate.map(mapDef => {
          if (mapDef.id !== uuid) {
            if (mapDef.beginDate === moment(beginDate).format("L")) {
              pushCount = 1;
            }
          }
          // else if (mapDef.id === uuid && pushCount === 0) {
          //   mapDef.beginDate =
          //     updatedBeginDate || beginDate.toLocaleDateString();
          //   mapDef.endDate = updatedEndDate || endDate.toLocaleDateString();
          //   mapDef.voidIndicator = editMapDefinitionVoid;
          //   mapDef.mapDefData =
          //     Object.keys(dataToUpdate).length != 0 ? newDialogData : [];
          //   mapDef.voidDate =
          //     editMapDefinitionVoid == true ? currentDate : null;
          // }
        });
        dataToUpdate.map(mapDef => {
          if (mapDef.id && mapDef.id === uuid && pushCount === 0) {
            mapDef.beginDate =
              updatedBeginDate || beginDate.toLocaleDateString();
            mapDef.endDate = updatedEndDate || endDate.toLocaleDateString();
            mapDef.voidIndicator = editMapDefinitionVoid;
            mapDef.mapDefData =
              Object.keys(dataToUpdate).length != 0 ? newDialogData : [];
            mapDef.voidDate =
              editMapDefinitionVoid == true ? currentDate : null;
            mapDef.auditTimeStamp =  getUTCTimeStamp();
            mapDef.auditUserID = logInUserID ? logInUserID : 'BTAYLOR1';
            mapDef.mapDefData.map(data => {
              data.auditTimeStamp = getUTCTimeStamp();
              data.auditUserID = logInUserID ? logInUserID : 'BTAYLOR1';
            })
          } else if (mapDef.mapSetSeq === MapSetSeqNo && pushCount === 0) {
            mapDef.beginDate =
              updatedBeginDate || beginDate.toLocaleDateString();
            mapDef.endDate = updatedEndDate || endDate.toLocaleDateString();
            mapDef.voidIndicator = editMapDefinitionVoid;
            mapDef.mapDefData =
              Object.keys(dataToUpdate).length != 0
                ? newDialogData || newDialogDataAdd
                : [];
            mapDef.voidDate =
              editMapDefinitionVoid == true ? currentDate : null;
            mapDef.auditTimeStamp =  getUTCTimeStamp();
            mapDef.auditUserID = logInUserID ? logInUserID : 'BTAYLOR1';
            mapDef.mapDefData.map(data => {
              data.auditTimeStamp = getUTCTimeStamp();
              data.auditUserID = logInUserID ? logInUserID : 'BTAYLOR1';
            })
          }
        });
        if (pushCount === 1) {
          errorMessagesArray.push(MapSetConstants.BEGIN_DATE_OVERLAPPING);
        }
        setnewDialogData([]);
        updatedMapDefArray = dataToUpdate;
        setmapDefinitionDataArray(updatedMapDefArray);
        const updatedMapDefTableData = [];
        if (
          endDateChangeFlag &&
          selectedDate1Retained <= endDate &&
          (values.mapType === "MCT-Member Cnt" || values.mapType === "MCT")
        ) {
          errorMessagesArray.push(MapSetConstants.MCT_BEGIN_END_DATE_FIX);
        } else {
          updatedMapDefArray.map((mapDefState, i) => {
            mapDefState.mapDefData.map((definitionData, i) => {
              newArrayObj = {};
              if (i === 0) {
                newArrayObj.beginDate = mapDefState.beginDate;
                newArrayObj.endDate = mapDefState.endDate;
                newArrayObj.mapSetSeq = mapDefState.mapSetSeq;
              } else {
                newArrayObj.beginDate = "";
                newArrayObj.endDate = "";
              }
              newArrayObj.exclude =
                definitionData.excludeIndicator == false
                  ? "No"
                  : definitionData.excludeIndicator == true
                    ? "Yes"
                    : "No";
              newArrayObj.dataElementCriteria =
                definitionData.dataElementCriteria;
              newArrayObj.functionalArea = definitionData.functionalArea;
              functionalAreaReference.map(fDesc => {
                if (definitionData.functionalArea == fDesc.code) {
                  newArrayObj.functionalAreaDesc = fDesc.description;
                }
              });
              newArrayObj.value =
                definitionData.fromValue &&
                  definitionData.thruValue &&
                  definitionData.type === "Range"
                  ? definitionData.fromValue + " to " + definitionData.thruValue
                  : definitionData.fromValue;
              newArrayObj.voidDate = mapDefState.voidDate;
              newArrayObj.definitionData = mapDefState.mapDefData;
              newArrayObj.id = mapDefState.id;
              updatedMapDefTableData.push(newArrayObj);
            });
          });
          setmapDefinitionTableData(updatedMapDefTableData);
          updateGridData(updatedMapDefTableData);
        }
        setshowEditResults(false);
      } else if (
        beginDate != null &&
        ((checkBeginDate && defaultEndDate != null) || endDate != null) &&
        dataToUpdate &&
        dataToUpdate.length === 0
      ) {
        errorMessagesArray.push(MapSetConstants.DEFINITION_DATA_LENGTH);
        seterrorMessages(errorMessagesArray);
      }
    }
    setOpenErrorPopUp(false);
  }

  const masterAddDefinitionData = masterSaveDefData => {
    // if (endDateChangeFlag && masterSaveDefData === 'edit') {
    //   alert(MapSetConstants.CHANGE_MAY_IMPACT);
    // }
    setEndDateChangeFlag(false);
    setMasterSaveDefDataType(masterSaveDefData);
    errorMessagesArray = [];
    seterrorMessages([]);
    setSuccessMessage([]);

    const defaultEndDate = new Date("12-31-9999");
    var EditForm = false;
    if (masterSaveDefDataType == "edit") {
      EditForm = true;
    } else if (masterSaveDefDataType == "add") {
      EditForm = false;
    }
    var beginDateerrorText = "";
    var endDateerrorText = "";
    var showBeginDateError;
    var showEndDateError;
    var showDateOverlappingError = false;
    // date validations for master Add/Update
    if (!beginDate) {
      showBeginDateError = true;
      beginDateerrorText = MapSetConstants.BEGINDATE_REQUIRED;
      errorMessagesArray.push(MapSetConstants.BEGINDATE_REQUIRED);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (beginDate.toString() === "Invalid Date") {
      showBeginDateError = true;
      beginDateerrorText = MapSetConstants.BEGINDATE_ERROR;
      errorMessagesArray.push(MapSetConstants.BEGINDATE_ERROR);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (validateDateMinimumValue(getDateInMMDDYYYYFormat(beginDate))) {
      showBeginDateError = true;
      beginDateerrorText = AppConstants.DATE_ERROR_1964;
      errorMessagesArray.push(AppConstants.DATE_ERROR_1964);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    }
    let tempEndDate = endDate;
    if (
      getDateInMMDDYYYYFormat(new Date(beginDate)) ===
      getDateInMMDDYYYYFormat(new Date()) &&
      endDate == null
    ) {
      setSelectedDate1(defaultEndDate);
      tempEndDate = defaultEndDate;
      checkBeginDate = true;
    }
    if (!tempEndDate && !checkBeginDate) {
      showEndDateError = true;
      endDateerrorText = MapSetConstants.ENDDATE_REQUIRED;
      errorMessagesArray.push(MapSetConstants.ENDDATE_REQUIRED);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (tempEndDate.toString() === "Invalid Date") {
      showEndDateError = true;
      endDateerrorText = MapSetConstants.ENDDATE_ERROR;
      errorMessagesArray.push(MapSetConstants.ENDDATE_ERROR);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    } else if (validateDateMinimumValue(getDateInMMDDYYYYFormat(tempEndDate))) {
      showEndDateError = true;
      endDateerrorText = AppConstants.DATE_ERROR_1964;
      errorMessagesArray.push(AppConstants.DATE_ERROR_1964);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    }
    if (
      beginDate &&
      endDate &&
      !showBeginDateError &&
      !showEndDateError &&
      compareTwoDatesGreaterThanOrEqual(new Date(endDate), new Date(beginDate))
    ) {
      showBeginDateError = true;
      beginDateerrorText = MapSetConstants.BEGINDATE_ENDDATE_MATCH;
      errorMessagesArray.push(MapSetConstants.BEGINDATE_ENDDATE_MATCH);
      seterrorMessages(errorMessagesArray);
      setshowEditResults(EditForm);
      setOpen(EditForm);
    }
    // -------------------------

    if (errorMessagesArray.length === 0) {
      const newArrayObj = {};
      var updatedBeginDate = new Date(null);
      var updatedEndDate = new Date(null);
      var updatedDate = new Date(null);
      setShowError(false);

      if (
        checkBeginDate ||
        (defaultEndDate !== null &&
          endDate !== null &&
          !compareTwoDatesGreaterThanOrEqual(new Date(), new Date(endDate)))
      ) {
        setOpenErrorPopUp(true);
      } else {
        onConfirm(masterSaveDefData);
      }
    }
    setShowError({
      showBeginDateError: showBeginDateError,
      showEndDateError: showEndDateError,
      showDateOverlappingError: showDateOverlappingError
    });
    setShowErrorText({
      beginDateerrorText: beginDateerrorText,
      endDateerrorText: endDateerrorText
    });
    seterrorMessages(errorMessagesArray);
  };
  const checkEdit = () => {
    if (endDateChangeFlag && beginDateChangeFlag) {
      masterAddDefinitionData("add");
    } else {
      masterAddDefinitionData("edit");
    }
  };
  const masterSave = () => {
    if (!allowNavigation && showEditScreen) {
      NoSaveMessage();
    } else {
      errorMessagesArray = [];
      seterrorMessages([]);
      setSuccessMessage([]);
      if (!showEditScreen) {
        validateHeaderFields();
        if (errorMessagesArray.length === 0) {
          setShowError(false);
          const setInputValues = {
            auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            auditTimeStamp: getUTCTimeStamp(),
            addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
            addedAuditTimeStamp: getUTCTimeStamp(),
            versionNo: 0,
            dbRecord: false,
            sortColumn: null,
            auditKeyList: [],
            auditKeyListFiltered: false,
            lineOfBusiness: values.LOB,
            mapType: values.mapType,
            mapID: values.mapId,
            mapDescription: values.description,
            mapDefDetail:
              mapDefinitionDataArrayState &&
                Object.keys(mapDefinitionDataArrayState).length > 0
                ? mapDefinitionDataArrayState
                : [],
            mapDefDefinition: [
              {
                auditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
                auditTimeStamp: getUTCTimeStamp(),
                addedAuditUserID: logInUserID ? logInUserID : 'BTAYLOR1',
                addedAuditTimeStamp: getUTCTimeStamp(),
                versionNo: 0,
                dbRecord: false,
                sortColumn: null,
                auditKeyList: [],
                auditKeyListFiltered: false,
                colSeqNumber: 1,
                dataElementCriteriaList: [],
                currentDepth: 2
              }
            ],
            noteSetVO: notesInput
          };
          const lobArray = [];
          lobArray.push(values.LOB);
          const searchView = {
            lineOfBusiness: values.LOB ? lobArray : null,
            mapType: values.mapType ? values.mapType : null,
            mapSetID: values.mapId ? values.mapId : null,
            mapDescription: values.description ? values.description : null,
            fieldValue: null,
            mapSetIDStartsOrContains: 1,
            mapDescStartsOrContains: 1,
            dataElementName: null
          };
          setsearchViewOnAdd(searchView);
          setSpinnerLoader(true);
          onMasterSaveMapDefinition(setInputValues);
          setAllowNavigation(false);
        }
      } else if (showEditScreen) {
        if (allowNavigation === false) {
          NoSaveMessage();
        } else {
          errorMessagesArray = [];
          var showMapDescError = false;
          var showMapDescriptionErrorText;
          if (
            (values.description && !values.description.trim()) ||
            !values.description
          ) {
            showMapDescError = true;
            showMapDescriptionErrorText = MapSetConstants.ADD_MAP_DESC_ERROR;
            errorMessagesArray.push(MapSetConstants.ADD_MAP_DESC_ERROR);
            setshowEditResults(false);
            setOpen(false);
          }
          if (/^[a-zA-Z0-9 ]*$/.test(values.description) === false) {
            showMapDescError = true;
            showMapDescriptionErrorText = MapSetConstants.MAP_DESC_ERROR;
            errorMessagesArray.push(MapSetConstants.MAP_DESC_ERROR);
            setshowEditResults(false);
            setOpen(false);
          }
          setShowError({
            showBeginDateError: showBeginDateError,
            showEndDateError: showEndDateError,
            showDateOverlappingError: showDateOverlappingError,
            showLOBError: showLOBError,
            showMapTypeError: showMapTypeError,
            showMapIDError: showMapIDError,
            showMapDescError: showMapDescError
          });
          setShowErrorText({
            beginDateerrorText: beginDateerrorText,
            endDateerrorText: endDateerrorText,
            showMapIDErrorText: showMapIDErrorText,
            showMapDescriptionErrorText: showMapDescriptionErrorText
          });
          seterrorMessages(errorMessagesArray);
          if (errorMessagesArray.length === 0) {
            setShowError(false);
            searchData.mapDefDetail = mapDefinitionDataArrayState;
            searchData.auditUserID = logInUserID ? logInUserID : 'BTAYLOR1';
            searchData.auditTimeStamp = getUTCTimeStamp();
            searchData.addedAuditUserID = searchData.addedAuditUserID
              ? searchData.addedAuditUserID
              : logInUserID ? logInUserID : 'BTAYLOR1';
            searchData.addedAuditTimeStamp = searchData.addedAuditTimeStamp
              ? searchData.addedAuditTimeStamp
              : getUTCTimeStamp();
            searchData.versionNo =
              versionNo && versionNo !== "" ? versionNo : searchData.versionNo;
            const lobArray = [];
            lobArray.push(searchData.lineOfBusiness);
            const searchView = {
              lineOfBusiness: searchData.lineOfBusiness ? lobArray : null,
              mapType: searchData.mapType ? searchData.mapType : null,
              mapSetID: searchData.mapID ? searchData.mapID : null,
              mapDescription: values.description ? values.description : null,
              fieldValue: null,
              mapSetIDStartsOrContains: 1,
              mapDescStartsOrContains: 1,
              dataElementName: null
            };
            setsearchViewOnAdd(searchView);
            // editing description in search data
            const updateDescription = {
              ...searchData,
              mapDescription: values.description,
              noteSetVO: notesInput
            };
            onMasterUpdateMapDefinition(updateDescription);
            setSpinnerLoader(true);
            setAllowNavigation(false);
          }
        }
      }
    }
  };

  const resetDefinitionData = flag => {
    if (flag) {
      setSelectedDate(null);
      setSelectedDate1("12/31/9999");
    }
    setShowErrorText({
      showMapIDErrorText: "",
      showMapDescriptionErrorText: ""
    });
    setDataElement({
      dataElementCriteria: "Please Select One",
      functionalArea: "Please Select One",
      value: "Please Select One",
      exclude: false,
      value1: null,
      value2: null,
      selectedOption: "List"
    });
    seterrorMessages([]);
    setEombtype("List");
    setShowError(false);
  };

  const validateHeaderFields = () => {
    var showMapIDError = false;
    var showMapDescError = false;
    var showMapDescriptionErrorText;
    var showLOBError = false;
    var showMapTypeError = false;
    var showMapIDErrorText = "";
    if (!values.LOB || values.LOB === "Please Select One") {
      showLOBError = true;
      errorMessagesArray.push(MapSetConstants.ADD_LOB_ERROR);
      setshowEditResults(false);
      setOpen(false);
    }
    if (!values.mapType || values.mapType === "Please Select One") {
      showMapTypeError = true;
      errorMessagesArray.push(MapSetConstants.ADD_MAP_TYPE_ERROR);
      seterrorMessages(errorMessagesArray);
      setOpen(false);
    }
    if ((values.mapId && !values.mapId.trim()) || !values.mapId) {
      showMapIDError = true;
      showMapIDErrorText = MapSetConstants.ADD_MAP_ID_ERROR;
      errorMessagesArray.push(MapSetConstants.ADD_MAP_ID_ERROR);
      setshowEditResults(false);
      setOpen(false);
    }
    if (/^[a-zA-Z0-9 ]*$/.test(values.mapId) === false) {
      showMapIDError = true;
      showMapIDErrorText = MapSetConstants.MAP_ID_ERROR;
      errorMessagesArray.push(MapSetConstants.MAP_ID_ERROR);
      setshowEditResults(false);
      setOpen(false);
    }
    if (
      (values.description && !values.description.trim()) ||
      !values.description
    ) {
      showMapDescError = true;
      showMapDescriptionErrorText = MapSetConstants.ADD_MAP_DESC_ERROR;
      errorMessagesArray.push(MapSetConstants.ADD_MAP_DESC_ERROR);
      setshowEditResults(false);
      setOpen(false);
    }
    if (/^[a-zA-Z0-9 ]*$/.test(values.description) === false) {
      showMapDescError = true;
      showMapDescriptionErrorText = MapSetConstants.MAP_DESC_ERROR;
      errorMessagesArray.push(MapSetConstants.MAP_DESC_ERROR);
      setshowEditResults(false);
      setOpen(false);
    }
    seterrorMessages(errorMessagesArray);
    setShowError({
      showBeginDateError: showBeginDateError,
      showEndDateError: showEndDateError,
      showDateOverlappingError: showDateOverlappingError,
      showLOBError: showLOBError,
      showMapTypeError: showMapTypeError,
      showMapIDError: showMapIDError,
      showMapDescError: showMapDescError
    });

    setShowErrorText({
      beginDateerrorText: beginDateerrorText,
      endDateerrorText: endDateerrorText,
      showMapIDErrorText: showMapIDErrorText,
      showMapDescriptionErrorText: showMapDescriptionErrorText
    });
  };
  const rowDeleteSystemListDetails = data => {
    setRowMapDefDetailData({
      ...rowmapDefDetailData,
      rowmapDefDetailData: data
    });
  };

  function mapDefDetailRowDeleteClick(data, dataSetName) {
    let temNewDialogData = [...data];
    if (rowmapDefDetailData.rowmapDefDetailData) {
      for (let i = 0; i < rowmapDefDetailData.rowmapDefDetailData.length; i++) {
        if (rowmapDefDetailData.rowmapDefDetailData[i] !== undefined) {
          temNewDialogData = temNewDialogData.filter(
            payment => payment.id !== rowmapDefDetailData.rowmapDefDetailData[i]
          );
        }
      }
    }
    if (dataSetName === "setnewDialogDataAdd") {
      setnewDialogDataAdd(temNewDialogData);
      setmapDefinitionDataArray(temNewDialogData);
    } else if (dataSetName === "setnewDialogData") {
      setnewDialogData(temNewDialogData);
    }

    setRowMapDefDetailData([]);
  }

  const masterRowDeleteMapListDetails = data => {
    setRowMasterDataDetails({
      ...rowMasterDataDetails,
      rowMasterDataDetails: data
    });
  };

  function masterDataRowDeleteClick(data) {
    let tempData = [...data];
    setAllowNavigation(true);
    if (rowMasterDataDetails.rowMasterDataDetails) {
      for (
        let i = 0;
        i < rowMasterDataDetails.rowMasterDataDetails.length;
        i++
      ) {
        if (rowMasterDataDetails.rowMasterDataDetails[i] !== undefined) {
          tempData = tempData.filter(
            payment =>
              payment.id !== rowMasterDataDetails.rowMasterDataDetails[i]
          );
        }
      }
    }

    setmapDefinitionDataArray(tempData);
    const mapDefinitionTableDataTemp = [];
    let newArrayObj = {};

    var currentDate = new Date();
    var dd = currentDate.getDate();
    var mm = currentDate.getMonth() + 1;

    var yyyy = currentDate.getFullYear();
    if (dd < 10) {
      dd = "0" + dd;
    }
    if (mm < 10) {
      mm = "0" + mm;
    }
    currentDate = yyyy + "-" + mm + "-" + dd;

    tempData.map((mapDefState, i) => {
      mapDefState.mapDefData.map((definitionData, j) => {
        newArrayObj = {};
        if (j == 0) {
          newArrayObj.beginDate = mapDefState.beginDate;
          newArrayObj.endDate = mapDefState.endDate;
          newArrayObj.id = mapDefState.id;
        } else {
          newArrayObj.beginDate = "";
          newArrayObj.endDate = "";
          newArrayObj.isChild = true;
        }

        newArrayObj.exclude =
          definitionData.excludeIndicator == false
            ? "No"
            : definitionData.excludeIndicator == true
              ? "Yes"
              : "No";
        newArrayObj.dataElementCriteria = definitionData.dataElementCriteria;
        newArrayObj.functionalArea = definitionData.functionalArea;
        functionalAreaReference.map(fDesc => {
          if (definitionData.functionalArea == fDesc.code) {
            newArrayObj.functionalAreaDesc = fDesc.description;
          }
        });
        newArrayObj.mapSetSeq = definitionData.mapSetSeq;
        newArrayObj.value =
          definitionData.fromValue && definitionData.thruValue
            ? definitionData.fromValue + " to " + definitionData.thruValue
            : definitionData.fromValue;
        newArrayObj.voidDate =
          editMapDefinitionVoid == true ? currentDate : null;
        newArrayObj.definitionData = mapDefState.mapDefData;
        mapDefinitionTableDataTemp.push(newArrayObj);
      });
    });

    setmapDefinitionTableData(mapDefinitionTableDataTemp);
    updateGridData(mapDefinitionTableDataTemp);
    if (
      rowMasterDataDetails.rowMasterDataDetails &&
      rowMasterDataDetails.rowMasterDataDetails.length > 0
    ) {
      resetDefinitionData(true);
    }
    setshowMapDefinitionAddForm(false);
    setRowMasterDataDetails([]);
  }
  // add notes
  let notesDataArray = [];

  const addNotes = data => {
    setAllowNavigation(true);
    const noteText = data;
    notesDataArray = notesTableData;
    if (!noteaddFlag) {
      notesDataArray.push(noteText);
      setNotesTableData(notesDataArray);
      setNotesInput({ ...notesInput, notesList: notesDataArray });
    } else {
      notesTableData[notesTableData.indexOf(editNoteData)].noteText =
        data.noteText;
      notesTableData[notesTableData.indexOf(editNoteData)].usageTypeCode =
        data.usageTypeCode;
      setNotesInput({ ...notesInput, notesList: notesTableData });
    }
  };

  const [disableNotes, setDisableNotes] = React.useState(true);
  const validateParentForm = () => {
    if (!showEditScreen) {
      if (
        !values.LOB ||
        values.LOB === "Please Select One" ||
        !values.mapType ||
        values.mapType === "Please Select One" ||
        !values.mapId ||
        values.mapId === "" ||
        !values.description ||
        values.description === ""
      ) {
        return true;
      } else {
        return false;
      }
    } else {
      if (!values.description || values.description === "") {
        return true;
      } else {
        return false;
      }
    }
  };
  
  useEffect(() => {
    setDisableNotes(validateParentForm());
  }, [values]);

  // clear out success/error msgs on click of add notes
  const clearSuccessErrorMsgs = () => {
    setSuccessMessage([]);
    seterrorMessages([]);
    setShowError(false);
  };

  const handelPromptSet = (set) => {
    if (set)
        setPrompt(true);
  }

  return (
    <div className="add-map-definition">
      <UnsavedChangesMessage allowNavigation={allowNavigation} handelPromptSet={handelPromptSet}
        confirm={confirm} cancelType={cancelType} prompt={prompt} setCancelType={setCancelType}
        setPrompt={setPrompt} />
      {LoadSpinner ? <Spinner /> : null}
      <div className="tabs-container" ref={toPrintRef}>
        <ErrorMessage errorMessages={errorMessages} />
        <SuccessMessage successMessages={successMessage} />
        <div className="tab-header">
          {showEditScreen ? (
            <h1 className="tab-heading float-left">Edit Map Definition</h1>
          ) : null}
          {!showEditScreen ? (
            <h1 className="tab-heading float-left">Add Map Definition</h1>
          ) : null}
          <div className="float-right mt-2 hide-on-print">
            {showEditScreen ? (
              <Button
                variant="outlined"
                color="primary"
                className="btn btn-success"
                onClick={() => masterSave("add")}
                disabled={!userInquiryPrivileges}
              >
                <i class="fa fa-check" aria-hidden="true"></i>
                Save
              </Button>
            ) : null}
            {!showEditScreen ? (
              <Button
                variant="outlined"
                color="primary"
                className="btn btn-success"
                onClick={() => masterSave("edit")}
                disabled={!userInquiryPrivileges}
              >
                <i class="fa fa-check" aria-hidden="true"></i>
                Save
              </Button>
            ) : null}
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                return new Promise(resolve => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                dispatch(setPrintLayout(false));
              }}
              trigger={() => (
                <Button className="btn btn-primary ml-1">
                  <i class="fa fa-print" aria-hidden="true"></i>
                  Print
                </Button>
              )}
              content={() => toPrintRef.current}
            />

            <Button
              variant="outlined"
              color="primary"
              className="btn btn-secondary ml-1"
            >
              <i class="fa fa-question-circle" aria-hidden="true"></i>
              Help
            </Button>
          </div>
          <div className="clearfix"></div>
        </div>
        <div>
          {!showEditScreen ? (
            <div className="tab-body pb-1">
              <form noValidate autoComplete="off">
                <div className="form-wrapper">
                  <div className="mui-custom-form with-select input-md">
                    <TextField
                      id="lob"
                      fullWidth
                      select
                      label="LOB"
                      required
                      disabled={!userInquiryPrivileges}
                      value={values.LOB}
                      onChange={handleChange("LOB")}
                      helperText={
                        showLOBError ? MapSetConstants.ADD_LOB_ERROR : null
                      }
                      error={
                        showLOBError ? MapSetConstants.ADD_LOB_ERROR : null
                      }
                      InputLabelProps={{
                        shrink: true
                      }}
                      SelectProps={{
                        MenuProps: {
                          className: classes.menu
                        }
                      }}
                    >
                      <MenuItem selected value="Please Select One">
                        Please Select One
                      </MenuItem>
                      {LOBReference
                        ? LOBReference.map((item, index) => (
                          <MenuItem value={item.code}>
                            {item.description}
                          </MenuItem>
                        ))
                        : null}
                    </TextField>
                  </div>
                  <div className="mui-custom-form with-select input-md">
                    <TextField
                      id="map-type"
                      fullWidth
                      select
                      label="Map Type"
                      required
                      disabled={!userInquiryPrivileges}
                      helperText={
                        showMapTypeError
                          ? MapSetConstants.ADD_MAP_TYPE_ERROR
                          : null
                      }
                      error={
                        showMapTypeError
                          ? MapSetConstants.ADD_MAP_TYPE_ERROR
                          : null
                      }
                      value={values.mapType}
                      onChange={handleChange('mapType')}
                      InputLabelProps={{
                        shrink: true
                      }}
                      SelectProps={{
                        MenuProps: {
                          className: classes.menu
                        }
                      }}
                    >
                      <MenuItem selected value="Please Select One">
                        Please Select One
                      </MenuItem>
                      {MapTypeReference
                        ? MapTypeReference.map((item, index) => (
                          <MenuItem value={item.code}>
                            {item.description}
                          </MenuItem>
                        ))
                        : null}
                    </TextField>
                  </div>
                  <div className="mui-custom-form input-md">
                    <TextField
                      id="map-id"
                      fullWidth
                      label="Map ID"
                      required
                      // disabled={!userInquiryPrivileges}
                      InputProps={{
                        readOnly: !userInquiryPrivileges,
                        className: !userInquiryPrivileges ? "Mui-disabled" : ""
                      }}
                      InputLabelProps={{
                        shrink: true
                      }}
                      helperText={showMapIDError ? showMapIDErrorText : null}
                      error={showMapIDError ? showMapIDErrorText : null}
                      inputProps={{ maxLength: 6 }}
                      value={values.mapId}
                      onChange={handleChange("mapId")}
                    />
                  </div>
                  <div className="mui-custom-form input-xl">
                    <TextField
                      id="description"
                      label="Map Description"
                      required
                      // disabled={!userInquiryPrivileges}
                      InputProps={{
                        readOnly: !userInquiryPrivileges,
                        className: !userInquiryPrivileges ? "Mui-disabled" : ""
                      }}
                      fullWidth
                      helperText={
                        showMapDescError ? showMapDescriptionErrorText : null
                      }
                      error={
                        showMapDescError ? showMapDescriptionErrorText : null
                      }
                      InputLabelProps={{
                        shrink: true
                      }}
                      inputProps={{ maxLength: 30 }}
                      value={values.description}
                      onChange={handleChange('description')}
                    />
                  </div>
                </div>

                <div className="mui-custom-form pull-right w-auto mr-4 mt-2 hide-on-print">
                  <Button
                    className="btn-textConfig btn-transparent"
                    onClick={() =>
                      masterDataRowDeleteClick(mapDefinitionDataArrayState)
                    }
                  >
                    <i class="fa fa-trash" aria-hidden="true"></i>
                    Delete
                  </Button>
                  <Button
                    className="btn btn-success ml-1"
                    onClick={() => addMapDefinitionButton(values)}
                    disabled={!userInquiryPrivileges}
                  >
                    <i class="fa fa-plus" aria-hidden="true"></i>
                    Add Map Definition
                  </Button>
                </div>
                <div className="clearfix"></div>
              </form>
            </div>
          ) : null}

          {showEditScreen ? (
            <div className="tab-body pb-1">
              <form noValidate autoComplete="off">
                <div className="form-wrapper">
                  <div className="mui-custom-form with-select  input-md">
                    <TextField
                      id="lob"
                      fullWidth
                      select
                      label="LOB"
                      required
                      value={
                        searchData.lobCode
                          ? searchData.lobCode
                          : searchData.lineOfBusiness
                      }
                      disabled={true}
                      InputLabelProps={{
                        shrink: true
                      }}
                      SelectProps={{
                        MenuProps: {
                          className: classes.menu
                        }
                      }}
                    >
                      <MenuItem selected value="Please Select One">
                        Please Select One
                      </MenuItem>
                      {LOBReference
                        ? LOBReference.map((item, index) => (
                          <MenuItem value={item.code}>
                            {item.description}
                          </MenuItem>
                        ))
                        : null}
                    </TextField>
                  </div>

                  <div className="mui-custom-form with-select input-md">
                    <TextField
                      id="map-type"
                      fullWidth
                      select
                      label="Map Type"
                      required
                      value={
                        searchData.mapTypeCode
                          ? searchData.mapTypeCode
                          : searchData.mapType
                      }
                      disabled={true}
                      InputLabelProps={{
                        shrink: true
                      }}
                      SelectProps={{
                        MenuProps: {
                          className: classes.menu
                        }
                      }}
                    >
                      <MenuItem selected value="Please Select One">
                        Please Select One
                      </MenuItem>
                      {MapTypeReference
                        ? MapTypeReference.map((item, index) => (
                          <MenuItem value={item.code}>
                            {item.description}
                          </MenuItem>
                        ))
                        : null}
                    </TextField>
                  </div>

                  <div className="mui-custom-form  input-sm">
                    <TextField
                      id="map-id"
                      fullWidth
                      label="Map ID"
                      required
                      InputLabelProps={{
                        shrink: true
                      }}
                      // disabled={true}
                      InputProps={{ readOnly: true, className: "Mui-disabled" }}
                      value={
                        searchData.mapSetID
                          ? searchData.mapSetID
                          : searchData.mapID
                      }
                    />
                  </div>
                  <div className="mui-custom-form input-xl">
                    <TextField
                      id="description"
                      fullWidth
                      label="Map Description"
                      required
                      InputLabelProps={{
                        shrink: true
                      }}
                      // disabled={true}
                      // value={searchData.mapDesc ? searchData.mapDesc : searchData.mapDescription}
                      value={values.description}
                      onChange={handleChange("description")}
                      helperText={
                        showMapDescError ? showMapDescriptionErrorText : null
                      }
                      error={
                        showMapDescError ? showMapDescriptionErrorText : null
                      }
                    />
                  </div>
                </div>
                <div className="form-wrapper justify-space-bw">
                  <div className="mui-custom-form">
                    <div className="sub-radio">
                      <FormControlLabel
                        control={
                          <Checkbox
                            color="primary"
                            onChange={handleChangeshowVoids(showVoids)}
                            value={showVoids}
                          />
                        }
                        label="Show Voids"
                      />
                    </div>
                  </div>
                  <div className="mr-4 mt-2 hide-on-print">
                    <Button
                      className="btn-textConfig btn-transparent"
                      onClick={() =>
                        masterDataRowDeleteClick(mapDefinitionDataArrayState)
                      }
                    >
                      <i class="fa fa-trash" aria-hidden="true"></i>
                      Delete
                    </Button>
                    <Button
                      className="btn btn-success ml-1"
                      onClick={() => addMapDefinitionButton(values)}
                      disabled={!userInquiryPrivileges}
                    >
                      <i class="fa fa-plus" aria-hidden="true"></i>
                      Add Map Definition
                    </Button>
                  </div>
                </div>
              </form>
            </div>
          ) : null}

          <div className="tab-body">
            <div className="tab-holder">
              <div className={classes.root}>
                <h4 className="hide-on-screen mt-2">
                  <span class="badge badge-primary"> Map Definition</span>
                </h4>
                <div className="hide-on-print">
                  <TableComponent
                    isSearch={false}
                    fixedTable
                    tableData={gridData}
                    headCells={showEditScreen ? editheadCells : addheadCells}
                    onTableRowClick={handleClickOpenEdit}
                    // defaultSortColumn={showEditScreen ? editheadCells[0].id : addheadCells[0].id}
                    sortOrder={"desc"}
                    onTableRowDelete={masterRowDeleteMapListDetails}
                    defaultSortColumn="beginDate"
                  />
                </div>
                <div className="hide-on-screen">
                  <TableComponent
                    print
                    isSearch={false}
                    fixedTable
                    tableData={gridData}
                    headCells={showEditScreen ? editheadCells : addheadCells}
                    onTableRowClick={handleClickOpenEdit}
                    // defaultSortColumn={showEditScreen ? editheadCells[0].id : addheadCells[0].id}
                    sortOrder={"desc"}
                    onTableRowDelete={masterRowDeleteMapListDetails}
                    defaultSortColumn="beginDate"
                  />
                </div>
                <div className="clearfix"></div>

                {open === true && showEditResults === true ? (
                  <div className="tabs-container">
                    <div className="tab-header  mini-tab-header">
                      <div className="tab-heading float-left">
                        Edit Map Definition
                      </div>
                      <div className="float-right mt-1 hide-on-print">
                        <Button
                          variant="outlined"
                          color="primary"
                          className="btn btn-primary ml-1"
                          disabled={
                            !userInquiryPrivileges
                              ? !userInquiryPrivileges
                              : rowData.voidDate != null
                          }
                          onClick={() => checkEdit()}
                        >
                          {/* Save functionality */}
                          Update
                        </Button>
                        <Button
                          variant="outlined"
                          color="primary"
                          className="bt-reset btn-transparent  ml-1"
                          disabled={
                            !userInquiryPrivileges
                              ? !userInquiryPrivileges
                              : rowData.voidDate != null
                          }
                          onClick={() => cancelEdit()}
                        >
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset
                        </Button>
                      </div>
                      <div className="clearfix"></div>
                    </div>
                    <form className="form-wrapper" autoComplete="off">
                      <MuiPickersUtilsProvider utils={DateFnsUtils}>
                        <Grid container>
                          <div className="mui-custom-form  with-date">
                            <KeyboardDatePicker
                              maxDate={Date.parse("31 Dec 9999 00:00:00 GMT")}
                              id="begindate-picker-dialog"
                              label="Begin Date"
                              format="MM/dd/yyyy"
                              value={beginDate}
                              required
                              disabled={
                                !userInquiryPrivileges
                                  ? !userInquiryPrivileges
                                  : Object.keys(searchData).length !== 0
                              }
                              placeholder="mm/dd/yyyy"
                              InputLabelProps={{
                                shrink: true
                              }}
                              helperText={
                                showBeginDateError ? beginDateerrorText : null
                              }
                              error={
                                showBeginDateError ? beginDateerrorText : null
                              }
                              onChange={handleDateChange}
                              KeyboardButtonProps={{
                                "aria-label": "change date"
                              }}
                            />
                          </div>
                          <div className="mui-custom-form   with-date">
                            <KeyboardDatePicker
                              maxDate={Date.parse("31 Dec 9999 00:00:00 GMT")}
                              id="enddate-picker-dialog"
                              label="End Date"
                              maxDate={new Date("9999-12-31T13:00:00.000+0000")}
                              format="MM/dd/yyyy"
                              disabled={
                                !userInquiryPrivileges
                                  ? !userInquiryPrivileges
                                  : rowData.voidDate != null
                              }
                              value={
                                checkBeginDate
                                  ? '12/31/9999'
                                  : endDate
                              }
                              InputLabelProps={{
                                shrink: true
                              }}
                              placeholder="mm/dd/yyyy"
                              helperText={
                                showEndDateError ? endDateerrorText : null
                              }
                              error={showEndDateError ? endDateerrorText : null}
                              onChange={handleDateChange1}
                              KeyboardButtonProps={{
                                "aria-label": "change date"
                              }}
                            />
                          </div>
                          {Object.keys(searchData).length !== 0 ? (
                            <div className="mui-custom-form">
                              <label className="MuiFormLabel-root small-label no-margin">
                                Void
                              </label>
                              <div
                                style={{
                                  paddingTop: '10px',
                                  marginLeft: '0px'
                                }}
                              >
                                <input
                                  type="radio"
                                  value={true}
                                  id="voidyescont"
                                  disabled={
                                    !userInquiryPrivileges
                                      ? !userInquiryPrivileges
                                      : rowData.voidDate != null
                                  }
                                  checked={editMapDefinitionVoid === true}
                                  onChange={handleeditMapDefinitionVoid}
                                />
                                <span className="text-black">
                                  {' '}
                                  <label for="voidyescont"> Yes </label>
                                </span>
                                <input
                                  type="radio"
                                  value={false}
                                  id="voidnocont"
                                  disabled={
                                    !userInquiryPrivileges
                                      ? !userInquiryPrivileges
                                      : rowData.voidDate != null
                                  }
                                  checked={editMapDefinitionVoid === false}
                                  onChange={handleeditMapDefinitionVoid}
                                  className="ml-2"
                                />
                                <span className="text-black">
                                  {' '}
                                  <label for="voidnocont"> No </label>
                                </span>
                              </div>
                            </div>
                          ) : null}
                          <div
                            className="ml-auto mr-4 hide-on-print"
                            style={{ marginTop: "30px" }}
                          >
                            <Button
                              className="btn-text btn-transparent"
                              onClick={() =>
                                mapDefDetailRowDeleteClick(
                                  newDialogData,
                                  "setnewDialogData"
                                )
                              }
                            >
                              <i class="fa fa-trash" aria-hidden="true"></i>
                              Delete
                            </Button>
                            <Button
                              variant="outlined"
                              disabled={
                                !userInquiryPrivileges
                                  ? !userInquiryPrivileges
                                  : rowData.voidDate != null
                              }
                              color="primary"
                              className="btn btn-success ml-1"
                              onClick={() => addDefinitionDataButton("edit")}
                            >
                              <i class="fa fa-plus" aria-hidden="true"></i>
                              Add Definition Data
                            </Button>
                            <div className="clearfix"></div>
                          </div>
                        </Grid>
                      </MuiPickersUtilsProvider>
                    </form>
                    <div className="tab-holder">
                      <div>
                        <MapSetUpdateDefinitionData
                          rowDeleteSystemListDetails={
                            rowDeleteSystemListDetails
                          }
                          tableData={newDialogData}
                          showEdit={showEditField}
                          handleClickOpenNewDialog={handleClickOpenNewDialog}
                        />
                      </div>
                    </div>
                  </div>
                ) : null}
                <div className="clearfix"></div>
                {open === false &&
                  showEditResults === false &&
                  showMapDefinitionAddForm === true ? (
                    <div className="tabs-container p-0" hidden={showResults}>
                      <div className="tab-header mini-tab-header">
                        <div className="tab-heading float-left">
                          Add Map Definition
                        </div>
                        <div className="float-right mt-1 hide-on-print">
                          <Button
                            variant="outlined"
                            color="primary"
                            className="btn btn-success ml-1"
                            onClick={() => masterAddDefinitionData("add")}
                            disabled={!userInquiryPrivileges}
                          >
                            <i class="fa fa-plus" aria-hidden="true"></i>
                            Add
                        </Button>
                          <Button
                            variant="outlined"
                            color="primary"
                            className="bt-reset btn-transparent  ml-1"
                            onClick={() => resetDefinitionData(true)}
                            disabled={!userInquiryPrivileges}
                          >
                            <i class="fa fa-undo" aria-hidden="true"></i>
                            Reset
                        </Button>
                        </div>
                        <div className="clearfix"></div>
                      </div>
                      <form
                        style={{ display: "flex", flexWrap: "wrap" }}
                        autoComplete="off"
                      >
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                          <Grid container>
                            <div className="mui-custom-form with-date">
                              <KeyboardDatePicker
                                maxDate={Date.parse("31 Dec 9999 00:00:00 GMT")}
                                id="date-picker-dialog-begindat"
                                label="Begin Date"
                                required
                                disabled={!userInquiryPrivileges}
                                format="MM/dd/yyyy"
                                placeholder="mm/dd/yyyy"
                                InputLabelProps={{
                                  shrink: true
                                }}
                                helperText={
                                  showBeginDateError ? beginDateerrorText : null
                                }
                                error={
                                  showBeginDateError ? beginDateerrorText : null
                                }
                                value={beginDate}
                                onChange={handleDateChange}
                                KeyboardButtonProps={{
                                  "aria-label": "change date"
                                }}
                              />
                            </div>
                            <div className="mui-custom-form with-date">
                              <KeyboardDatePicker
                                maxDate={Date.parse("31 Dec 9999 00:00:00 GMT")}
                                id="date-picker-dialog-enddat"
                                label="End Date"
                                required
                                disabled={!userInquiryPrivileges}
                                maxDate={new Date("9999-12-31T13:00:00.000+0000")}
                                format="MM/dd/yyyy"
                                placeholder="mm/dd/yyyy"
                                InputLabelProps={{
                                  shrink: true
                                }}
                                helperText={
                                  showEndDateError ? endDateerrorText : null
                                }
                                error={showEndDateError ? endDateerrorText : null}
                                value={
                                  checkBeginDate
                                    ? "12/31/9999"
                                    : endDate
                                }
                                onChange={handleDateChange1}
                                KeyboardButtonProps={{
                                  "aria-label": "change date"
                                }}
                              />
                            </div>
                            <div
                              className="ml-auto mr-4 hide-on-print"
                              style={{ marginTop: "30px" }}
                            >
                              <Button
                                className="btn-textConfig btn-transparent"
                                onClick={() =>
                                  mapDefDetailRowDeleteClick(
                                    newDialogDataAdd,
                                    "setnewDialogDataAdd"
                                  )
                                }
                              >
                                <i class="fa fa-trash" aria-hidden="true"></i>
                                Delete
                            </Button>
                              <Button
                                variant="outlined"
                                color="primary"
                                className="btn btn-success ml-1"
                                onClick={() => addDefinitionDataButton("add")}
                                disabled={!userInquiryPrivileges}
                              >
                                <i class="fa fa-plus" aria-hidden="true"></i>
                                Add Definition Data
                            </Button>
                            </div>
                          </Grid>
                        </MuiPickersUtilsProvider>
                      </form>
                      <div className="tab-holder">
                        <h4 className="hide-on-screen mt-2">
                          <span class="badge badge-primary">
                            Add Definition Data
                        </span>
                        </h4>
                        <div>
                          <MapSetUpdateDefinitionData
                            rowDeleteSystemListDetails={
                              rowDeleteSystemListDetails
                            }
                            tableData={newDialogDataAdd}
                            showEdit={showEditField}
                            handleClickOpenNewDialog={handleClickOpenNewDialog}
                          />
                        </div>
                      </div>
                    </div>
                  ) : null}
                <div className="clearfix"></div>
              </div>
            </div>
            {/* Add Definition Data Dialog Box */}
            <Dialog
              className="custom-dialog dialog-614"
              fullWidth={fullWidth}
              maxWidth={maxWidth}
              open={openDialog}
              disableBackdropClick
            >
              <DialogTitle
                id="customized-dialog-title"
                onClose={handleCloseAddDefinitionDataDialog}
              >
                Add Definition Data
              </DialogTitle>
              <DialogContent dividers>
                <form noValidate autoComplete="off">
                  <div className="form-wrapper">
                    <div
                      className="mui-custom-form override-width"
                      style={{ marginTop: "10px" }}
                    >
                      <label
                        className="MuiFormLabel-root small-label"
                        for="Exclude"
                      >
                        Exclude
                      </label>
                      <div className="sub-radio">
                        <Checkbox
                          id="Exclude"
                          color="primary"
                          disabled={
                            !userInquiryPrivileges
                              ? !userInquiryPrivileges
                              : rowData.voidDate != null
                          }
                          onChange={handleChangeDataElement("exclude")}
                          value={dataElement.exclude}
                          checked={dataElement.exclude}
                        />
                      </div>
                    </div>
                    <div className="mui-custom-form with-select override-width-40" style={{width : '200px'}}>
                      <TextField
                        id="data-element-criteria"
                        select
                        label="Data Element Criteria"
                        required
                        disabled={!userInquiryPrivileges}
                        value={dataElement.dataElementCriteria}
                        onChange={handleChangeDataElement(
                          "dataElementCriteria"
                        )}
                        InputLabelProps={{
                          shrink: true
                        }}
                        SelectProps={{
                          MenuProps: {
                            className: classes.menu
                          }
                        }}
                        helperText={
                          showDataElementCriteriaError
                            ? MapSetConstants.ADD_DATAELEMENT_CRITERIA
                            : null
                        }
                        error={
                          showDataElementCriteriaError
                            ? MapSetConstants.ADD_DATAELEMENT_CRITERIA
                            : null
                        }
                      >
                        <MenuItem selected value="Please Select One">
                          Please Select One
                        </MenuItem>
                        {dataElementReference &&
                          !dataElementReference.systemFailure
                          ? dataElementReference.map((option, index) => (
                            <MenuItem value={option}>{option}</MenuItem>
                          ))
                          : null}
                      </TextField>
                    </div>
                    <div className="mui-custom-form override-width-22" style={{width:'200px'}}>
                      <label className="MuiFormLabel-root small-label">
                        Type<span>*</span>
                      </label>
                      <div style={{position: 'relative', top: '-7px', fontSize: '13px', overflow: 'hidden'}}>
                      <Radio style={{color: '#274463', paddingRight: '5px', paddingLeft: '6px'}}
                          value="List"
                          id="eombtypelist"
                          checked={dataElement.selectedOption === 'List'}
                          name="eombType"
                          disabled={false}
                          onChange={handleChangeDataElement('selectedOption')}
                        />
                        <span className="text-black">
                          <label for="eombtypelist">List</label>
                        </span>
                        <Radio style={{color: '#274463', paddingRight: '5px', paddingLeft: '6px'}}
                          className="ml-2"
                          id="eombtyperange"
                          value="Range"
                          name="eombType"
                          checked={dataElement.selectedOption === 'Range'}
                          onChange={handleChangeDataElement('selectedOption')}
                        />
                        <span className="text-black">
                          <label for="eombtyperange">Range</label>
                        </span>
                      </div>
                    </div>
                    {renderSwitch(eombType)}
                  </div>
                </form>
              </DialogContent>

              <DialogActions>
                <Button
                  className="btn btn-success ml-1"
                  onClick={() => addDefinitionDataToList(dataElement)}
                  disabled={!userInquiryPrivileges}
                >
                  <i class="fa fa-plus" aria-hidden="true"></i>
                  Add
                </Button>
                <Button
                  className="bt-reset btn-transparent  ml-1"
                  onClick={() => resetDefinitionData(false)}
                  disabled={!userInquiryPrivileges}
                >
                  <i class="fa fa-undo" aria-hidden="true"></i>
                  Reset
                </Button>
              </DialogActions>
            </Dialog>

            {/* Add Definition Data Dialog Box */}
            {/* Edit Definition Data Dialog Box */}
            <Dialog
              className="custom-dialog dialog-614"
              fullWidth={fullWidth}
              maxWidth={maxWidth}
              open={openDialogEdit}
              disableBackdropClick
            >
              <DialogTitle
                id="customized-dialog-title"
                onClose={handleCloseNewDialog}
              >
                Edit Definition Data
              </DialogTitle>
              <DialogContent dividers>
                <form noValidate autoComplete="off">
                  <div className="form-wrapper">
                    <div
                      className="mui-custom-form override-width"
                      style={{ marginTop: "10px" }}
                    >
                      <label
                        className="MuiFormLabel-root small-label"
                        for="Excludecontent"
                      >
                        Exclude
                      </label>
                      <div className="sub-radio">
                        <Checkbox
                          id="Excludecontent"
                          color="primary"
                          disabled={
                            !userInquiryPrivileges
                              ? !userInquiryPrivileges
                              : rowData.voidDate != null
                          }
                          onChange={handleChangeDataElement("exclude")}
                          value={dataElement.exclude}
                          checked={dataElement.exclude}
                        />
                      </div>
                    </div>
                    <div className="mui-custom-form with-select override-width-40" style={{width : '200px'}}>
                      <TextField
                        id="data-element-criteria"
                        select
                        label="Data Element Criteria"
                        required
                        value={dataElement.dataElementCriteria}
                        disabled={
                          !userInquiryPrivileges
                            ? !userInquiryPrivileges
                            : rowData.voidDate != null
                        }
                        onChange={handleChangeDataElement(
                          "dataElementCriteria"
                        )}
                        InputLabelProps={{
                          shrink: true
                        }}
                        SelectProps={{
                          MenuProps: {
                            className: classes.menu
                          }
                        }}
                        helperText={
                          showDataElementCriteriaError
                            ? MapSetConstants.ADD_DATAELEMENT_CRITERIA
                            : null
                        }
                        error={
                          showDataElementCriteriaError
                            ? MapSetConstants.ADD_DATAELEMENT_CRITERIA
                            : null
                        }
                      >
                        <MenuItem selected value="Please Select One">
                          Please Select One
                        </MenuItem>
                        {dataElementReference
                          ? dataElementReference.map((option, index) => (
                            <MenuItem value={option}>{option}</MenuItem>
                          ))
                          : null}
                      </TextField>
                    </div>

                    <div className="mui-custom-form override-width-22" style={{width : '200px'}}>
                      <label className="MuiFormLabel-root small-label">
                        Type<span>*</span>
                      </label>
                      <div style={{position: 'relative', top: '-7px', fontSize: '13px', overflow: 'hidden'}}>
                        <Radio style={{color: '#274463', paddingRight: '5px', paddingLeft: '6px'}}
                          className="ml-2"
                          value="List"
                          id="eomblist"
                          name="eombType"
                          disabled={false
                          }
                          checked={dataElement.selectedOption === "List"}
                          onChange={handleChangeDataElement("selectedOption")}
                        />
                        <span className="text-black">
                          <label for="eomblist">List</label>
                        </span>
                        <Radio style={{color: '#274463', paddingRight: '5px', paddingLeft: '6px'}}
                          value="Range"
                          name="eombType"
                          id="eombrange"
                          disabled={
                            !userInquiryPrivileges
                              ? !userInquiryPrivileges
                              : rowData.voidDate != null
                          }
                          disabled={false}
                          className="ml-2"
                          checked={dataElement.selectedOption === "Range"}
                          onChange={handleChangeDataElement("selectedOption")}
                        />
                        <span className="text-black">
                          <label for="eombrange">Range</label>
                        </span>
                      </div>
                    </div>
                    {renderSwitch(eombType)}
                  </div>
                </form>
              </DialogContent>
              <DialogActions>
                <Button
                  disabled={
                    !userInquiryPrivileges
                      ? !userInquiryPrivileges
                      : rowData.voidDate != null
                  }
                  className="btn btn-success ml-1"
                  onClick={saveMapDefinitionData}
                >
                {/*  <i class="fa fa-plus" aria-hidden="true"></i>*/}
                  Update
                </Button>
                <Button
                  disabled={
                    !userInquiryPrivileges
                      ? !userInquiryPrivileges
                      : rowData.voidDate != null
                  }
                  className="bt-reset btn-transparent  ml-1"
                  onClick={resetMapDefinitionData}
                >
                  <i class="fa fa-undo" aria-hidden="true"></i>
                  Reset
                </Button>
              </DialogActions>
            </Dialog>
            {/* Edit Definition Data Dialog Box */}
            {/* Dialog Box for a popupErrorMessage */}
            <Dialog
              className="custom-dialog dialog-614 with-padding"
              fullWidth={fullWidth}
              maxWidth={maxWidth}
              open={openErrorPopUp}
              disableBackdropClick
            >
              <DialogContent dividers>
                <div>
                  The Map Definition End Date is less than the Current Date. Are
                  you sure you want to save? If so, click OK to continue with
                  the save. If you click Cancel, the current updated information
                  will not be saved.
                </div>
              </DialogContent>

              <DialogActions>
                <Button
                  className="btn btn-primary ml-1"
                  onClick={() => onConfirm(null)}
                  disabled={!userInquiryPrivileges}
                >
                  OK
                </Button>
                <Button
                  className="btn btn-primary ml-1"
                  onClick={closeErrorPopUpDialog}
                  disabled={!userInquiryPrivileges}
                >
                  Cancel
                </Button>
              </DialogActions>
            </Dialog>

            <div className="tab-panelbody padTop-10">
              <div className="tab-holder my-3">
                <AppBar position="static">
                  <Tabs aria-label="simple tabs example" className="tabChange">
                    <Tab label="Notes" />
                  </Tabs>
                </AppBar>
                <TabPanel value={tabValue} index={0}>
                  <div className="tab-holder my-3">
                    <div className={classes.root}>
                      <Notes addNotes = {addNotes}
                        notesTableData = {notesTableData}
                        noteSetListInput = {noteSetListInput}
                        setNoteSetListInput = {setNoteSetListInput}
                        usageTypeCodeData= {usageTypeCodeData}
                        noteaddFlag={noteaddFlag}
                        setNoteAddFlag= {setNoteAddFlag}
                        editNoteData = {editNoteData}
                        setEditNoteData = {setEditNoteData}/>
                    </div>
                  </div>
                </TabPanel>
              </div>
            </div>
          </div>
        </div>
        <Footer print />
      </div>
    </div>
  );
}
// withRouter(MapSetAdd)// 
export default withRouter(PropsInit({Wrapped: MapSetAdd, url: "/MapSetEdit", action: mapSetActionView, selector: "appConfigState.mapSetState.mapSetView" }));
