/* eslint-disable no-unused-vars */
import React, { useEffect } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import TableComponent from '../../../../SharedModules/Table/Table';
import { withRouter } from 'react-router';

import { mapSetActionView } from '../../Store/Actions/MapSet/mapSetActions';
import { generateUUID } from '../../../../SharedModules/DateUtilities/DateUtilities';


const headCells = [
  { id: 'mapSetID', numeric: false, disablePadding: true, label: 'Map ID', width: 200, isVarChar: true, enableHyperLink: true, isVarChar: true },
  { id: 'lobDesc', numeric: false, disablePadding: false, label: 'LOB', width: 200 },
  { id: 'mapTypeDesc', numeric: false, disablePadding: false, label: 'Map Type', width: 200 },
  { id: 'mapDesc', numeric: false, disablePadding: false, label: 'Map Description', width: 300, isVarChar: true }
];

function MapSetSearchTableComponent (props) {
  const dispatch = useDispatch();
  const [showTable, setShowTable] = React.useState(false);

  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);

  const [redirect, setRedirect] = React.useState(0);
  const [useEffectValues, setUseEffectValues] = React.useState([]);

  useEffect(() => {
    console.log('in useEffect');
  }, [useEffectValues]);
  const onSearchView = searchviewvalues => dispatch(mapSetActionView(searchviewvalues));
  const payloadViewData = useSelector(state => state.appConfigState.mapSetState.mapSetView);
  if (redirect === 1) {
    if (payloadViewData) {
      payloadViewData.map(var1 => {
        var1.mapDefDetail.map(var2 => {
          //var2.id = generateUUID();
          props.functionalAreaReference.map(fDesc => { if (var2.functionalArea === fDesc.code) { var2.functionalAreaDesc = fDesc.description; } });
        });
      });

      console.log(payloadViewData);
      props.history.push({
        pathname: '/MapSetEdit',
        state: { payloadViewData }
      });
    }
  }
  const formatSearchCriteria = (_row)=>({
    lineOfBusiness: _row.lineOfBusiness !== 'Please Select One' ? [_row.lobCode] : null,
    mapType: _row.mapTypeCode !== 'Please Select One' ? _row.mapTypeCode : null,
    mapSetID: _row.mapSetID !== '' ? _row.mapSetID : null,
    mapDescription: _row.mapDesc && _row.mapDesc !== '' ? _row.mapDesc : null,
    fieldValue: _row.fieldValue && _row.fieldValue !== '' ? _row.fieldValue : null,
    mapSetIDStartsOrContains: _row.mapSetIDStartsOrContains === 'StartsWith' ? 0 : _row.mapSetIDStartsOrContains === 'Contains' ? 1 : null,
    mapDescStartsOrContains: _row.mapDescStartsOrContains === 'StartsWith' ? 0 : _row.mapDescStartsOrContains === 'Contains' ? 1 : null,
    dataElementName: _row.dataElementName && _row.dataElementName !== 'Please Select One' ? _row.dataElementName : null
  });

  const editRow = values => event => {
    let searchCriteria = formatSearchCriteria(values);
    onSearchView(searchCriteria);
    setRedirect(1);
  };

  const tableComp = <TableComponent pathTo='/MapSetEdit?data=' formatSearchCriteria={formatSearchCriteria} isSearch={true} headCells={headCells} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={'mapSetID'} />;
  return (
    showTable ? tableComp : null

  );
}

export default withRouter(MapSetSearchTableComponent);
