/* eslint-disable no-unused-vars */

import React, { useEffect } from 'react';
import { withRouter } from 'react-router';

import { systemParameterRowClickAction } from '../../Store/Actions/TextManagement/TextManagementActions';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import TableComponent from '../../../../SharedModules/Table/Table';


const headCells = [
  { id: 'lobCode', disablePadding: false, label: 'LOB', width: '10%', enableHyperLink: true },
  { id: 'eombFromCode', disablePadding: false, label: 'From Code', width: '15%', isVarchar: true },
  { id: 'procedureModifierCode1', disablePadding: false, label: 'Mod 1', width: '10%', isVarChar: true },
  { id: 'procedureModifierCode2', disablePadding: false, label: 'Mod 2', width: '10%', isVarChar: true },
  { id: 'procedureModifierCode3', disablePadding: false, label: 'Mod 3', width: '10%', isVarChar: true },
  { id: 'procedureModifierCode4', disablePadding: false, label: 'Mod 4', width: '10%', isVarChar: true },
  
  { id: 'eombThruCode', disablePadding: false, label: 'Thru Code', width: '15%', isVarchar: true },
  { id: 'thruProcedureModifierCode1', disablePadding: false, label: 'Mod 1', width: '10%', isVarChar: true },
  { id: 'thruProcedureModifierCode2', disablePadding: false, label: 'Mod 2', width: '10%', isVarChar: true },
  { id: 'thruProcedureModifierCode3', disablePadding: false, label: 'Mod 3', width: '10%', isVarChar: true },
  { id: 'thruProcedureModifierCode4', disablePadding: false, label: 'Mod 4', width: '10%', isVarChar: true },
  
  { id: 'eombDesc', disablePadding: false, label: 'Text', isProviderNotice: true, width: '20%' },
];

function ProviderNoticeTable (props) {
  const [redirect, setRedirect] = React.useState(false);

  // API CAll
  const dispatch = useDispatch();
  const onRowClick = values => dispatch(systemParameterRowClickAction(values));
  const payloadData = useSelector(state => state.appConfigState.textManagementState.EOMBData);
  if (redirect === 1) {
    if (payloadData != null) {
      if (payloadData.length === 1) {
        console.log(payloadData);
        props.history.push({
          pathname: '/TextUpdate',
          state: { row: payloadData, TextType: 'EOMB', EombType: 'hcpcs' }
        });
      }
    }
  }

  // Spinner Functionality
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (payloadData != null) {
      setspinnerLoader(false);
    }
  }, [payloadData]);

  useEffect(()=>{
console.log(payloadData,"payLoadData")
  })
  // Spinner Functionality
  const formatSearchCriteria = (_row) => ({
    eombProcedureTypeCode: 'H',
    lobCode: [_row.lobCode],
    eombFromCode: _row.eombFromCode,
    eombthruCode: _row.eombThruCode,
    eombText: _row.eombDesc,
    eombTextStartsOrContains: null,
    fromModifier1: _row.procedureModifierCode1,
    fromModifier2: _row.procedureModifierCode2,
    fromModifier3: _row.procedureModifierCode3,
    fromModifier4: _row.procedureModifierCode4,
    thruModifier1: _row.thruProcedureModifierCode1,
    thruModifier2: _row.thruProcedureModifierCode2,
    thruModifier3: _row.thruProcedureModifierCode3,
    thruModifier4: _row.thruProcedureModifierCode4
  });

  const editRow = row => event => {
    const searchCriteria = formatSearchCriteria(row);
    onRowClick(searchCriteria);
    setspinnerLoader(true);
    setRedirect(1);
  };

  const tableComp = <TableComponent pathToTEST='/TextUpdate?data=' formatSearchCriteria={formatSearchCriteria} fixedTable isSearch={true} headCells={headCells} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={headCells[0].id} />;
  return (
    tableComp

  );
}
export default withRouter(ProviderNoticeTable);
