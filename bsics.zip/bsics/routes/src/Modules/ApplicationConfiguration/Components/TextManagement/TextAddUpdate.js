
import React from 'react';
import { Button } from 'react-bootstrap'
import TextField from '@material-ui/core/TextField';
import Select from '@material-ui/core/Select';
import { Prompt } from 'react-router-dom';
import MenuItem from '@material-ui/core/MenuItem';
import TextTypeData from './TextTypeData.json';
import PropTypes from 'prop-types';
import MUIRichTextEditor from 'mui-rte';
import Footer from '../../../../SharedModules/Layout/footer';
import ReactToPrint from 'react-to-print';
//import { setPrintLayout } from '../../../../SharedModules/Store/Actions/SharedAction';
import AppBar from '@material-ui/core/AppBar';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import Box from '@material-ui/core/Box';
import Typography from '@material-ui/core/Typography';
import {
    KeyboardDatePicker,
   MuiPickersUtilsProvider
} from '@material-ui/pickers';
import DateFnsUtils from '@date-io/date-fns';
import './TextManagement.scss'
import { Editor, EditorState } from 'draft-js';
import { Form } from 'react-bootstrap';
import * as TextManagementErrors from './TextManagementErrors';
import CustomizedEditor from '../../../../SharedModules/RichTextEditor/TextEditor';
import {
    TextManagementAddProviderNoticeAction, ResetData, SetSpinner, TextManagementAddRAEOBAction, TextManagementAddRemarkTextAction,
    TextManagementAddAdjustmentReasonAction, TextManagementAddNCPDPAction, TextManagementAddEOMBAction, providerNoticeGetRecordAction,
    EOMBGetRecordAction, RaeobGetRecordAction, RemarkTextGetRecordAction, AdjustmentReasonRecordAction, NCPDPGetRecordAction
} from '../../Store/Actions/TextManagement/TextManagementAddUpdateActions';
import {
    ProviderSpecialtyDataAction, ResetTextSearchReducer
} from '../../Store/Actions/TextManagement/TextManagementActions';
import { AppConfigDropdownActions, ModifierDropdownActions , notesUsageTypeDropdown} from '../../Store/Actions/AppConfigCommon/AppConfigActions';
import { connect } from 'react-redux';
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import moment from 'moment';
import * as DateUtils from '../../../../SharedModules/DateUtilities/DateUtilities';
import { withRouter } from "react-router";
import * as AppConstants from '../../../../SharedModules/AppConstants';
import dropdownCriteria from './TextManagementAddUpdate.json';
import Notes from '../../../../SharedModules/Notes/Notes';
import UnsavedChangesMessage from '../../../../SharedModules/Errors/UnsavedChangesMessage';
import "./TextAddUpdate.css"
import TextManagementLocationAdd from "../../../TextManagementLocation/Component/TextManagementLocationAdd"
import TextManagementLocationEdit from "../../../TextManagementLocation/Component/TextManagementLocationEdit"
import ServiceAuthReasonAdd from "../../../TextManagementServiceAuth/components/ServiceAuthAdd";
import { getLoginUserDetails } from "../../../../SharedModules/utility/utilityFunction";
const userDetails = getLoginUserDetails();

function TabPanel(props) {
    const { children, value, index, ...other } = props;
    
    return (
        <Typography
            component="div"
            role="tabpanel"
            hidden={value !== index}
            id={`simple-tabpanel-${index}`}

            {...other}
        >
            <Box p={3}>{children}</Box>
        </Typography>
    );
}

TabPanel.propTypes = {
    children: PropTypes.node,
    index: PropTypes.any.isRequired,
    value: PropTypes.any.isRequired,
};

function dateCheck(date1, date2) {
    date1 = new Date(date1);
    date2 = new Date(date2);
    var dateone = new Date(date1.getFullYear(), date1.getMonth(), date1.getDate(), 0, 0, 0);
    var datetwo = new Date(date2.getFullYear(), date2.getMonth(), date2.getDate(), 0, 0, 0);
    if (dateone < datetwo) {
        return 0;
    } else if (dateone > datetwo) {
        return 1;
    } else {
        return 2;
    }

}

// const [allowNavigation, setAllowNavigation] = React.useState(false);
const mapStateToProps = state => ({
    functionalDropDown: state.appConfigState.AppConfigCommonState.appConfigDropdown,
    ModifierData: state.appConfigState.AppConfigCommonState.modifierDropdown,
    ProviderSpecialtyData: state.appConfigState.textManagementState.ProviderSpecialtyData,
    Result: (state.appConfigState.textManagementState.payload ? state.appConfigState.textManagementState.payload : null),
    Record: state.appConfigState.TextSearchState.Text,
    current: state.sharedState.currentPath,
    showSpinner: state.appConfigState.SetSpinnerState.showSpinner,
    usageTypeCodeData: state.appConfigState.AppConfigCommonState.usageDropDown,
    logInUserID: state.sharedState.logInUserID
});

class TextAddUpdate extends React.Component {
    constructor(props) {
        super(props);
        this.toPrintRef = React.createRef();
        this.locationChild = React.createRef();
        this.eombType = ''
        this.eomb_ref = React.createRef();
        this.raeob_ref = React.createRef();
        this.provider_notice_ref = React.createRef();
        this.remark_code_ref = React.createRef();
        this.adjustment_reason_ref = React.createRef();
        this.ncpdp_ref = React.createRef();
        this.notes_ref = React.createRef();
        this.state = {
            locationSave : false,
            textTypeChanged : false ,
            loginUserDetails:JSON.parse(localStorage.getItem('loginState')),
            isTextTypeSelected:"",
            TextType: 'Please Select One',
            error_messages: [],
            spinnerLoader: true,
            redirect: false,
            showMsg: false,
            allowNavigation: false,
           tabValue: 0,
           notesTableData: [],
           prompt: false,
           cancelType: false,
           confirm: false,
           notesInput: {
            auditUserID: 'BTAYLOR1',
            auditTimeStamp: null,
            addedAuditUserID: 'BTAYLOR1',
            addedAuditTimeStamp: null,
            versionNo: 0,
            dbRecord: false,
            sortColumn: null,
            tableName: null,
            noteSetSK: null,
            noteSourceName: null,
            notesList: [],
            globalNotesList: [],
            checkAll: null,
            addNewLinkRender: null,
            filterLinkRender: null,
            printLinkRender: null,
            completeNotesList: []
           },
           noteSetListInput: {
            auditUserID: 'BTAYLOR1',
            auditTimeStamp: null,
            addedAuditUserID: 'BTAYLOR1',
            addedAuditTimeStamp: null,
            versionNo: 0,
            dbRecord: false,
            sortColumn: null,
            noteTextValue: null,
            userIdName: null,
            notesCexAuditUserID: null,
            notesCexAuditTimeStamp: null,
            notesCexAddedAuditUserID: null,
            notesCexAddedAuditTimeStamp: null,
            noteSetSK: null,
            usageTypeDesc: '',
            shortNotes: null,
            checked: false,
            renderNoHistoryMsg: false,
            noteSequenceNumber: 4,
            currentNote: null,
            rowValue: null,
            usageTypeList: null,
            strBeginDate: moment(new Date()).format('MM/DD/YYYY hh:mm:ss'),
            usageTypeCode: 'Please Select One',
            tableName: null,
            noteText: '',
            commonEntityName: null,
            commonEntityTypeCode: null,
            commonEntityId: null,
            entityId: null,
            filterbeginDate: moment(new Date()).format('YYYY-MM-DD'),
            filterEndDate: null,
            userId: '',
            noteCexVersionNum: 0,
            saNoteSequenceNumber: null,
            notesCexnoteTextValue: 0,
            id: DateUtils.generateUUID()
           },
           usageTypeCodeInput:[ {
            functionalArea: 'General',
            dataElementName: 'G_NOTE_TY_CD',
            businessName: null,
            valueShortDescription: null,
            crossReferenceColumnName: null,
            crossReferenceTableName: null,
            dataEleNameStartsOrContains: null,
            busNameStartsOrContains: null
           }],
           usageTypeCodeData: [],
           editNoteData: {}
        }
        this.props.dispatch(AppConfigDropdownActions(dropdownCriteria));
        this.props.dispatch(SetSpinner(false));
        this.getProviderSpecialty = this.getProviderSpecialty.bind(this)
       
        //notes dropdown
        this.props.dispatch(notesUsageTypeDropdown(this.state.usageTypeCodeInput));
    }
    
    componentDidMount() {
        // this.props.dispatch(functionalAreaDropDown());
        
        this.setState({spinnerLoader: false })
        
           
         
    }
    MappingTextType(textType) {
if(this.state.isTextTypeSelected===true){
    this.setState({...this.state,isTextTypeSelected:"",error_messages:[]})
}

        
        switch (textType) {
            case '1-Location':
                return 'Location';   
            case '2-EOMB':
                return 'EOMB';
            case '3-RA EOB':
                return 'RA EOB';
            case '4-ProvNotice':
                return 'Provider Notice';
            case '5-Remark':
                return 'Remark Code';
            case '6-Adj Reason':
                return 'Adjustment Reason';
            case '8-NCPDP':
                return 'NCPDP Rejection Codes';
            default:
                return 'EOMB';
        }

    
    }
    handleChanges = event => {
        
        this.props.dispatch(ResetData());
        this.props.dispatch(ResetTextSearchReducer());
        this.setState({ error_messages: [], TextType: event.target.value }, () => {
        })
        this.setState({ TextType: event.target.value, showMsg: false, allowNavigation: true, redirect: false ,textTypeChanged : true});
      
    };

    handleLocationError = errors => {
     
        this.setState({ error_messages: errors });

    };
    handleLocationRedirect = (data) => {
     
       

        if (true) {
            this.props.history.push({
                pathname: '/TextUpdate',
                state: {  locationDetails : data , TextType: "Location", EombType: "revenue", message: TextManagementErrors.SUCCESS_MSG }
            });
          
        }
        
    };

    setAllowNavigation = event => {
        this.setState({ allowNavigation: true });
    }
    //set note set list input 
    setNoteSetListInput = data => {
        console.log("setNoteSetListInput", data);

        const noteSetListInput = this.state.noteSetListInput;
        // if (data.usageTypeCode !== '') {
            noteSetListInput.usageTypeCode = data.usageTypeCode;
        // }
        // if (data.usageTypeDesc !== '') {
            noteSetListInput.usageTypeDesc = data.usageTypeDesc;

        // }
        // if (data.noteText !== '') {
            noteSetListInput.noteText = data.noteText;

        // }
        this.setState({
            noteSetListInput: noteSetListInput
        })
    }


    
    setErrorNull = event => {
        this.setState({ error_messages: [] });
        this.props.dispatch(ResetData());
        this.props.dispatch(ResetTextSearchReducer());
        this.provider_notice_ref.current.setErrObject();
        this.remark_code_ref.current.setErrObject();
        this.adjustment_reason_ref.current.setErrObject();
        this.ncpdp_ref.current.setErrObject();
    }
    componentWillReceiveProps(nextProps) {
        console.log("componentWillReceiveProps",nextProps);
        // You don't have to do this check first, but it can help prevent an unneeded render
        if (nextProps.Result && nextProps.Result.respcode == '01' && nextProps.Record && nextProps.Record !== '' && nextProps.Record[0]) {
            if (nextProps.Record[0].eombType) {
                let eomb = nextProps.Record[0].eombType;
                if (eomb == 'H')
                    this.eombType = 'hcpcs'
                if (eomb == 'I')
                    this.eombType = 'surgical-procedure'
                if (eomb == 'R')
                    this.eombType = 'revenue'
            }
            let textType = '1-Location';
            switch (this.state.TextType) {
                case '1-Location':
                    textType = 'Location';
                case '2-EOMB':
                    textType = 'EOMB';
                    break;
                case '3-RA EOB':
                    textType = 'RA EOB';
                    break;
                case '4-ProvNotice':
                    textType = 'Provider Notice';
                    break;
                case '5-Remark':
                    textType = 'Remark Code';
                    break;
                case '6-Adj Reason':
                    textType = 'Adjustment Reason';
                    break;
                case '8-NCPDP':
                    textType = 'NCPDP Rejection Codes';
                    break;
                default:
                    return 'EOMB';
            }
            if (this.state.redirect) {
                this.props.history.push({
                    pathname: '/TextUpdate',
                    state: { row: nextProps.Record[0], TextType: textType, EombType: this.eombtype, message: TextManagementErrors.SUCCESS_MSG }
                });
            }
        }
    }
    // set notes input
     setNotesInput =  data => {
         const notesInput = this.state.notesInput;
         notesInput.notesList = data;
         this.setState({
            notesInput: notesInput
         })
     }
     // set notes table data
     setNotesTableData = data => {
         let notesTableData = this.state.notesTableData;
         notesTableData = data;
         this.setState({
             notesTableData: notesTableData
         });
     }
     // add notes
     addNotes = (data) => {
         debugger
        let notesDataArray = [];

        this.setAllowNavigation();
     
        const noteText = data;
        notesDataArray = this.state.notesTableData;
    
        notesDataArray.push(noteText);
        this.setNotesTableData(notesDataArray);
        this.setNotesInput(notesDataArray);
      };

    handelPromptSet = set => {
        if (set)
            this.setState({ prompt: true });
    }

    setCancelTypeFunc = () => {
        this.setState({ cancelType: false });
    }

    setPromptFunc = () => {
        this.setState({ prompt: false });
    }

c=()=>{
console.log(    this.state.TextType,"text type")
}

    handleSave = event => {
        this.setState({locationSave : true})
         
        if(this.state.TextType === 'Please Select One'){
            console.log(this.state)
const error_message=[]
error_message.push("Text type is required.")
this.setState({...this.state,isTextTypeSelected:true,error_messages:error_message})
        }
else{
        this.setState({ error_messages: [], showMsg: true,isTextTypeSelected:"" }, () => {
            let data = null;
            if (this.state.TextType !== 'Please Select One') {
                let textType = this.MappingTextType(this.state.TextType);
                switch (textType) {
                    case 'EOMB':
                        data = this.eomb_ref.current.searchCheck();
                        if (data.length == 0) {
                            data = this.eomb_ref.current.onSave();
                            if(data) {
                                data = {...data,noteSetVO: this.state.notesInput}
                            }
                            console.log(data)
                            this.props.dispatch(TextManagementAddEOMBAction(data));
                            // setTimeout(
                            //     function () {
                            //         this.props.dispatch(EOMBGetRecordAction(
                            //             {
                            //                 "eombProcedureTypeCode": data.eombType,
                            //                 "lobCode": [data.lob],
                            //                 "eombFromCode": data.eombFromCode,
                            //                 "eombthruCode": data.eombThruCode,
                            //                 "eombText": data.eombDesc,
                            //                 "eombTextStartsOrContains": null,
                            //                 "fromModifier1": data.fromModifier1,
                            //                 "fromModifier2": data.fromModifier2,
                            //                 "fromModifier3": data.fromModifier3,
                            //                 "fromModifier4": data.fromModifier4,
                            //                 "thruModifier1": data.thruModifier1,
                            //                 "thruModifier2": data.thruModifier2,
                            //                 "thruModifier3": data.thruModifier3,
                            //                 "thruModifier4": data.thruModifier4
                            //             }
                            //         ))
                            //     }
                            //         .bind(this),
                            //     2000
                            // );
                        }
                        else {
                            this.setState({ error_messages: [...this.state.error_messages, ...data], showMsg: false });
                        }
                       break;
                    case 'RA EOB':
                        data = this.raeob_ref.current.searchCheck();
                        if (data.length == 0) {
                            data = this.raeob_ref.current.onSave();
                            if(data) {
                                data = {...data,noteSetVO: this.state.notesInput}
                            }
                             
                            data.auditUserID=this.state.loginUserDetails.logInUserId
                            data.addedAuditUserID=this.state.loginUserDetails.logInUserId
                            this.props.dispatch(TextManagementAddRAEOBAction(data));
                            // setTimeout(
                            //     function () {
                            //         this.props.dispatch(RaeobGetRecordAction(
                            //             {
                            //                 "eobText": data.eobDesc,
                            //                 "lobCode": [data.lobCode],
                            //                 "claimEOBCode": data.claimEOBCode,
                            //                 "eobTextStartsOrContains": null
                            //             }
                            //         ))
                            //     }
                            //         .bind(this),
                            //     1000
                            // );
                         
                        }
                        else {
                            this.setState({ error_messages: [...this.state.error_messages, ...data], showMsg: false });
                        }
                        break;
                    case 'Provider Notice':
                        data = this.provider_notice_ref.current.searchCheck();
                        if (data.length == 0) {
                            this.provider_notice_ref.current.setErrObject();
                            data = this.provider_notice_ref.current.onSave();
                            if(data) {
                                data = {...data,noteSetVO: this.state.notesInput}
                            }
                             
                            data.auditUserID=this.state.loginUserDetails.logInUserId
                            data.addedAuditUserID=this.state.loginUserDetails.logInUserId
                            this.props.dispatch(TextManagementAddProviderNoticeAction(data));
                            // setTimeout(
                            //     function () {
                            //         this.props.dispatch(providerNoticeGetRecordAction(
                            //             {
                            //                 "lobCode": [data.lobCode],
                            //                 "providerTypeCode": data.providerType ? data.providerType : null,
                            //                 "providerNoticeText": data.providerNoticeText ? data.providerNoticeText : null,
                            //                 "providerNoticeTextStartsOrContains": null,
                            //                 "providerSpecialityCode": data.providerSpeciality ? data.providerSpeciality : null,
                            //             }
                            //         ))
                            //     }
                            //         .bind(this),
                            //     1000
                            // );
                        }
                        else {
                            this.setState({ error_messages: [...this.state.error_messages, ...data], showMsg: false });
                        }
                        break;
                    case 'Remark Code':
                        data = this.remark_code_ref.current.searchCheck();
                        if (data.length == 0) {
                            this.remark_code_ref.current.setErrObject();
                            data = this.remark_code_ref.current.onSave();
                            if(data) {
                                data = {...data,noteSetVO: this.state.notesInput}
                            }
                            data.auditUserID=this.state.loginUserDetails.logInUserId
                            data.addedAuditUserID=this.state.loginUserDetails.logInUserId
                            this.props.dispatch(TextManagementAddRemarkTextAction(data));
                            // setTimeout(
                            //     function () {
                            //         this.props.dispatch(RemarkTextGetRecordAction(
                            //             {
                            //                 "remarkCode": data.remarkCode,
                            //                 "remarkText": data.remarkText,
                            //                 "remarkTextStartsOrContains": null
                            //             }
                            //         ))
                            //     }
                            //         .bind(this),
                            //     1000
                            // );
                        }
                        else {
                            this.setState({ error_messages: [...this.state.error_messages, ...data] });
                        }
                        break;
                    case 'Adjustment Reason':
                        data = this.adjustment_reason_ref.current.searchCheck();
                        if (data.length == 0) {
                            this.adjustment_reason_ref.current.setErrObject();
                            data = this.adjustment_reason_ref.current.onSave();
                            if(data) {
                                data = {...data,noteSetVO: this.state.notesInput}
                            }
                            
                            data.auditUserID=this.state.loginUserDetails.logInUserId
                            data.addedAuditUserID=this.state.loginUserDetails.logInUserId
                            this.props.dispatch(TextManagementAddAdjustmentReasonAction(data));
                            // setTimeout(
                            //     function () {
                            //         // this.props.dispatch(AdjustmentReasonRecordAction(
                            //         //     {
                            //         //         "adjustmentReasonCode": data.adjustmentReasonCode,
                            //         //         "adjustmentReasonText": data.adjustmentReasonText,
                            //         //         "adjustmentReasonTextStartsOrContains": null
                            //         //     }
                            //         // ))
                            //     }
                            //         .bind(this),
                            //     1000
                            // );
                        }
                        else {
                            this.setState({ error_messages: [...this.state.error_messages, ...data], showMsg: false });
                        }
                        break;
                    case 'NCPDP Rejection Codes':
                        data = this.ncpdp_ref.current.searchCheck();
                        if (data.length == 0) {
                            this.ncpdp_ref.current.setErrObject();
                            data = this.ncpdp_ref.current.onSave();
                            if(data) {
                                data = {...data,noteSetVO: this.state.notesInput}
                            }
                            this.props.dispatch(TextManagementAddNCPDPAction(data));
                            // setTimeout(
                            //     function () {
                            //         this.props.dispatch(NCPDPGetRecordAction(
                            //             {
                            //                 "ncpdpRejectCode": data.ncpdpRejectCode,
                            //                 "ncpdpRejectCodeText": data.ncpdpRejectCodeText,
                            //                 "ncpdpRejectCodeStartsOrCopntains": null
                            //             }
                            //         ))
                            //     }
                            //         .bind(this),
                            //     1000
                            // );
                        }
                        else {
                            this.setState({ error_messages: [...this.state.error_messages, ...data], showMsg: false });
                        }
                        break;
                }
                this.setState({ redirect: true, allowNavigation: false }, () => {
                    // setTimeout(
                    //     function () {

                    //         if (data.eombType) {
                    //             if (data.eombType == 'H')
                    //                 this.eombType = 'hcpcs'
                    //             if (data.eombType == 'I')
                    //                 this.eombType = 'surgical-procedure'
                    //             if (data.eombType == 'R')
                    //                 this.eombType = 'revenue'
                    //         }
                    //         let textType = 'EOMB';
                    //         switch (this.state.TextType) {
                    //             case '2-EOMB':
                    //                 textType = 'EOMB';
                    //                 break;
                    //             case '3-RA EOB':
                    //                 textType = 'RA EOB';
                    //                 break;
                    //             case '4-ProvNotice':
                    //                 textType = 'Provider Notice';
                    //                 break;
                    //             case '5-Remark':
                    //                 textType = 'Remark Code';
                    //                 break;
                    //             case '6-Adj Reason':
                    //                 textType = 'Adjustment Reason';
                    //                 break;
                    //             case '8-NCPDP':
                    //                 textType = 'NCPDP Rejection Codes';
                    //                 break;
                    //             default:
                    //                 return 'EOMB';
                    //         }
                    //         if (this.props.Result && this.props.Result.respcode == '01' && this.props.Record && this.props.Record !== '' && this.props.Record[0]) {
                    //             if (this.state.redirect) {
                    //                 this.props.history.push({
                    //                     pathname: '/TextUpdate',
                    //                     state: { row: this.props.Record[0], TextType: textType, EombType: this.eombtype, message: TextManagementErrors.SUCCESS_MSG }
                    //                 });
                    //             }
                    //         }
                    //     }
                    //         .bind(this),
                    //     3000
                    // );
                })
            } else {
                let errorMessagesArray = [];
                errorMessagesArray.push(TextManagementErrors.TEXT_TYPE_REQUIRED);
                this.setState({ error_messages: errorMessagesArray });
            }
        })
}
    }
    getProviderSpecialty(value) {
        if (value === 'Please Select One') {

        } else {
            this.props.dispatch(ProviderSpecialtyDataAction(value));
        }
    }

    render() {
       this.c()
      
        
        return (
            <div>
               <UnsavedChangesMessage allowNavigation={this.state.allowNavigation} handelPromptSet={this.handelPromptSet}
                    confirm={this.state.confirm} cancelType={this.state.cancelType} prompt={this.state.prompt} setCancelType={this.setCancelTypeFunc}
                    setPrompt={this.setPromptFunc} />
                {this.props.showSpinner ? <Spinner /> : null}
               {this.state.error_messages.length > 0 ? <div class="alert alert-danger custom-alert" role="alert" >
                    {this.state.error_messages.map(message =>
                        <li>{message}</li>
                    )
                    }
                </div> : null
                }
                {this.state.showMsg ?
                    this.props.Result !== null ? this.props.Result.respcode === '01' ? <div class="alert alert-success custom-alert" role="alert" >
                        <li>{TextManagementErrors.SUCCESS_MSG
                        }</li></div> : this.props.Result !== null && this.props.Result.respcode ? <div class="alert alert-danger custom-alert" role="alert" >
                            {this.props.Result.errorMessages !== null ? this.props.Result.errorMessages.map(message =>
                                <li>{message}</li>
                            ) : <li>{this.props.Result.respdesc}</li>
                            }</div> : 
                            this.props.Result !== null && this.props.Result.status ==='400' && this.props.Result.message !== null ?  <div class="alert alert-danger custom-alert" role="alert" ><li>{this.props.Result.message}</li></div>
                            :<div class="alert alert-danger custom-alert" role="alert" >
                                <li>{TextManagementErrors.ERR_PROCESSING_REQ}</li>
                            </div> : null
                    : null}
                < div className="tabs-container" ref={this.toPrintRef} >
                    <div className="tab-header">
                        <h1 className="page-heading float-left">
                            Add Text
                         </h1>
                        <div className="float-right th-btnGroup" >
                            <Button title="Save" className='btn btn-ic btn-save'
                                onClick={this.handleSave}>
                                 Save
                        </Button>
                            <ReactToPrint
                                onBeforeGetContent={() => {
                                    this.props.dispatch(setPrintLayout(true));
                                    this.setState({ spinnerLoader: true });
                                    return new Promise((resolve) => setTimeout(() => resolve(), 100));
                                }}
                                onAfterPrint={() => {
                                    this.setState({ spinnerLoader: false });
                                    this.props.dispatch(setPrintLayout(false));
                                }}
                                trigger={() => (<Button title="Print" className='btn btn-ic btn-print' >
                                     
                                    Print
                                    </Button>)}
                                content={() => this.toPrintRef.current}
                            />
                            <Button title="Help" className='btn btn-ic btn-help'
                            >
                                
                                Help
                        </Button>
                        </div>
                        <div className="clearfix"></div>
                    </div>
                    <div className="custom-hr my-1 pb-1" />
                    <div className='tab-body mt-3'>
                        <div class="form-wrapper" >
                            <div className="mui-custom-form with-select">
                                <TextField
                                    id="text-types"
                                    fullWidth
                                    required
                                    select
                                    label="Text Type"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    value={this.state.TextType}
                                    helperText={this.state.isTextTypeSelected === true && "Text type is required."}

                                    onChange={this.handleChanges}
                                >
                                    <MenuItem selected key="Please Select One" value="Please Select One">
                                        {AppConstants.PLEASE_SELECT_ONE}
                                    </MenuItem>
                                    {this.props.functionalDropDown && this.props.functionalDropDown.listObj &&
                                        this.props.functionalDropDown.listObj['Reference#1130'] ?
                                        this.props.functionalDropDown.listObj['Reference#1130'].map(option => {
                                            return (<MenuItem key={option.code} value={option.description}>
                                               {option.description.split('-')[1]}
                                            </MenuItem>)
                                        }) : null}

                                </TextField>

                            </div>
                     </div>
                    {
                        (() => {
                            if (this.state.TextType != 'Please Select One') {
                                // if(this.props.functionalDropDown===undefined){
                                //     this.setState({spinnerLoader:true})
                                // }else{
                                //     this.setState({spinnerLoader:false})
                                // } 
                                return (
                                    <div className="tab-body">
                                        <div className="collapsable-panel">

                                            <div className="MuiExpansionPanel-root MuiExpansionPanel-roots">
                                                <div className="panel-header">
                                                    <div className="MuiExpansionPanelSummary-content MuiExpansionPanelSummary-contents ">
                                                        <p className="MuiTypography-root">
                                                            Text Details
                                        </p>
                                                    </div>
                                                </div>
                                                <div className="MuiCollapse-container MuiCollapse-entered" >
                                                    <div className="MuiCollapse-wrapper">
                                                        {(() => {
                                                            let textType = this.MappingTextType(this.state.TextType);
                                                            switch (textType) {
                                                                case 'Location':
                                                                   // return <TextManagementLocationAdd locationSave={this.state.locationSave} error_messages={this.state.error_messages} handleLocationError={this.handleLocationError} />
                                                                return <TextManagementLocationAdd locationSave={this.state.locationSave} error_messages={this.state.error_messages} handleLocationError ={this.handleLocationError}  logInUserID={this.props.logInUserID} textTypeChanged={this.state.textTypeChanged} handleLocationRedirect ={this.handleLocationRedirect}  noteSetVO={this.state.notesInput}/>
                                                                case 'EOMB':
                                                                    return <EOMB ref={this.eomb_ref} setErrorNull={this.setErrorNull} dropDown={this.props.functionalDropDown ? this.props.functionalDropDown : null} setAllowNavigation={this.setAllowNavigation} />;
                                                                case 'RA EOB':
                                                                    return <RAEOB ref={this.raeob_ref} setErrorNull={this.setErrorNull} dropDown={this.props.functionalDropDown ? this.props.functionalDropDown : null} setAllowNavigation={this.setAllowNavigation} />
                                                                case 'Provider Notice':
                                                                    return <ProviderNotice ref={this.provider_notice_ref} getProviderSpecialty={this.getProviderSpecialty} ProviderSpecialtyData={this.props.ProviderSpecialtyData}
                                                                        setErrorNull={this.setErrorNull} dropDown={this.props.functionalDropDown ? this.props.functionalDropDown : null} setAllowNavigation={this.setAllowNavigation} />
                                                                case 'Remark Code':
                                                                    return <RemarkCode ref={this.remark_code_ref} setErrorNull={this.setErrorNull} setAllowNavigation={this.setAllowNavigation} />
                                                                case 'Adjustment Reason':
                                                                    return <AdjustmentReason ref={this.adjustment_reason_ref} setErrorNull={this.setErrorNull} setAllowNavigation={this.setAllowNavigation} />
                                                                case 'Service Auth Reason':
                                                                return <ServiceAuthReasonAdd ref={this.service_auth_reason_ref} setErrorNull={this.setErrorNull} setAllowNavigation={this.setAllowNavigation} dispatch={this.props.dispatch}/>
                                                                case 'NCPDP Rejection Codes':
                                                                    return <NCPDP ref={this.ncpdp_ref} setErrorNull={this.setErrorNull} setAllowNavigation={this.setAllowNavigation} />
                                                                default:
                                                                    return null;
                                                            }
                                                        })()}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>)
                            }
                        })()
                    }

                    <div className='tab-body tab-bodies'>
                        <div className='tab-panelbody m-0'>
                            <div className="tab-holder my-3">
                                <AppBar position="static">
                                    <Tabs aria-label="simple tabs example" className="tabChanges">
                                        <Tab label="Notes" />
                                    </Tabs>
                                </AppBar>
                                <TabPanel value={this.state.tabValue} index={0}>
                                    <Notes addNotes={this.addNotes}
                                        ref={this.notes_ref}
                                        notesTableData={this.state.notesTableData}
                                        noteSetListInput={this.state.noteSetListInput}
                                        setNoteSetListInput={this.setNoteSetListInput}
                                        usageTypeCodeData={this.props.usageTypeCodeData && this.props.usageTypeCodeData.listObj && this.props.usageTypeCodeData.listObj['General#G_NOTE_TY_CD'] ? this.props.usageTypeCodeData.listObj['General#G_NOTE_TY_CD'] : []}
                                        editNoteData={this.state.editNoteData}
                                    />
                                </TabPanel>
                            </div>
          </div>
          </div>

                    <Footer print />
                </div >

            </div>
        )
    }
}

class EOMB_ extends React.Component {
    constructor(props) {
        super(props);
        this.total_characters = 320;
        this.lobData = this.props.lobData;
        this.dropDown = props.dropDown ? props.dropDown : [];
        this.state = {
            eombLob: 'Please Select One',
            disableFrom: '',
            disableThru: '',
            eombFromCode: '',
            eombThruCode: '',
            eombText: '',
            showDropdown: false,
            wordCount: this.total_characters,
            eombType: 'hcpcs',
            mod1: 'Please Select One',
            mod2: 'Please Select One',
            mod3: 'Please Select One',
            mod4: 'Please Select One',
            modt1: 'Please Select One',
            modt2: 'Please Select One',
            modt3: 'Please Select One',
            modt4: 'Please Select One',
            disableFrom: false,
            disableThru: false,
            errorObj: {
                eombLob: false,
                eombFromCode: false,
                eombThruCode: false,
                text: false
            },
            error_msg: {
                eombLob: '',
                eombFromCode: '',
                eombThruCode: '',
                text: '',
            }
        }
        this.props.dispatch(AppConfigDropdownActions(dropdownCriteria));
        this.props.dispatch(ModifierDropdownActions());
    }
    searchCheck = () => {
        let errorMessagesArray = [];
        var errorObj = this.state.errorObj;
        var error_msg = this.state.error_msg;
        if (this.state.eombLob == "Please Select One") {
            errorObj.eombLob = true
            error_msg.eombLob = "LOB" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.eombLob);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {

            })
        }
        if (!this.state.eombFromCode || (this.state.eombFromCode && !this.state.eombFromCode.trim())) {
            errorObj.eombFromCode = true
            error_msg.eombFromCode = "From Code" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.eombFromCode);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        else {
            errorObj.eombFromCode = false;
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if (!this.state.eombThruCode || (this.state.eombFromCode && !this.state.eombFromCode.trim())) {
            if (this.state.eombFromCode) {
                this.setState({ eombThruCode: this.state.eombFromCode.toUpperCase() }, () => {
                    this.handleModifiers();
                })
                errorObj.eombThruCode = false
                error_msg.eombThruCode = "";
                this.setState({ errorObj: errorObj, error_msg: error_msg, eombThruCode: this.state.eombFromCode.toUpperCase() }, () => {
                })
            }
            else {
                errorObj.eombThruCode = true
                error_msg.eombThruCode = "Thru Code" + TextManagementErrors.Required_Field_Error;
                errorMessagesArray.push(error_msg.eombThruCode);
                this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
                })
            }
        }
        else {
            if (((!isNaN(this.state.eombThruCode)) && (!isNaN(this.state.eombFromCode))) &&
                ((parseInt(this.state.eombThruCode) < parseInt(this.state.eombFromCode)))) {
                errorObj.eombFromCode = true
                if (this.state.eombType === 'revenue') {
                    error_msg.eombFromCode = TextManagementErrors.From_Thru_Equality_Error;
                } else if (this.state.eombType === 'surgical-procedure') {
                    error_msg.eombFromCode = TextManagementErrors.FROM_THRU_EQUAL_ERROR_SP;
                } else {
                    error_msg.eombFromCode = TextManagementErrors.FROM_THRU_EQUAL_ERROR_HCPCS;
                }
                errorMessagesArray.push(error_msg.eombFromCode);
                this.setState({ errorObj: errorObj, error_msg: error_msg });
            } else if (((isNaN(this.state.eombThruCode)) && (isNaN(this.state.eombFromCode))) &&
                (this.state.eombFromCode.localeCompare(this.state.eombThruCode) === 1)) {
                errorObj.eombFromCode = true
                if (this.state.eombType === 'revenue') {
                    error_msg.eombFromCode = TextManagementErrors.From_Thru_Equality_Error;
                } else if (this.state.eombType === 'surgical-procedure') {
                    error_msg.eombFromCode = TextManagementErrors.FROM_THRU_EQUAL_ERROR_SP;
                } else {
                    error_msg.eombFromCode = TextManagementErrors.FROM_THRU_EQUAL_ERROR_SP;
                }
                errorMessagesArray.push(error_msg.eombFromCode);
                this.setState({ errorObj: errorObj, error_msg: error_msg });
            }
        }
        if ((this.state.eombText && !this.state.eombText.trim()) || !this.state.eombText) {
            errorObj.text = true
            error_msg.text = "Text" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.text);
            this.setState({ errorObj: errorObj, error_msg: error_msg });
        }
        this.eombSort();
        return errorMessagesArray;
    }
    onSave = e => {
        let eombType = '';
        switch (this.state.eombType) {
            case 'hcpcs':
                eombType = 'H';
                break;
            case 'surgical-procedure':
                eombType = 'I';
                break;
            case 'revenue':
                eombType = 'R';
                break;
            default:
                eombType = 'H';
        }
        let Array1 = [this.state.mod1 !== 'Please Select One' ? this.state.mod1 : ''
            , this.state.mod2 !== 'Please Select One' ? this.state.mod2 : ''
            , this.state.mod3 !== 'Please Select One' ? this.state.mod3 : ''
            , this.state.mod4 !== 'Please Select One' ? this.state.mod4 : ''];
        let Array2 = [this.state.modt1 !== 'Please Select One' ? this.state.modt1 : ''
            , this.state.modt2 !== 'Please Select One' ? this.state.modt2 : ''
            , this.state.modt3 !== 'Please Select One' ? this.state.modt3 : ''
            , this.state.modt4 !== 'Please Select One' ? this.state.modt4 : ''];
        Array1.sort();
        Array2.sort();
        let A1 = []; let A2 = [];
        for (let i = 0; i < 4; i++) {
            if (Array1[i] !== '') {
                A1.push(Array1[i]);
            }
            if (Array2[i] !== '') {
                A2.push(Array2[i]);
            }
        }
        this.props.dispatch(SetSpinner(true));
        this.props.dispatch(ResetTextSearchReducer());
        return {
            "auditUserID": this.props.logInUserID ? this.props.logInUserID : 'BTAYLOR1',
            "auditTimeStamp": DateUtils.getUTCTimeStamp(),
            "addedAuditUserID": this.props.logInUserID ? this.props.logInUserID : 'BTAYLOR1',
            "addedAuditTimeStamp": DateUtils.getUTCTimeStamp(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
            "auditKeyListFiltered": false,
            "eombFromCode": this.state.eombFromCode,
            "eombThruCode": !this.state.eombFromCode || (this.state.eombFromCode && !this.state.eombFromCode.trim()) ? this.state.eombFromCode : this.state.eombThruCode,
            "eombType": eombType,
            "lob": this.state.eombLob,
            "eombDesc": this.state.eombText,
            "noteSet": null,
            "fromModifier1": eombType === 'H' ? A1.length < 0 ? null : A1[0] : null,
            "fromModifier2": eombType === 'H' ? A1.length < 0 ? null : A1[1] : null,
            "fromModifier3": eombType === 'H' ? A1.length < 0 ? null : A1[2] : null,
            "fromModifier4": eombType === 'H' ? A1.length < 0 ? null : A1[3] : null,
            "thruModifier1": eombType === 'H' ? A2.length < 0 ? null : A2[0] : null,
            "thruModifier2": eombType === 'H' ? A2.length < 0 ? null : A2[1] : null,
            "thruModifier3": eombType === 'H' ? A2.length < 0 ? null : A2[2] : null,
            "thruModifier4": eombType === 'H' ? A2.length < 0 ? null : A2[3] : null
        }
    }
    handleEombType = event => {
        this.props.setAllowNavigation();
        var errorObj = this.state.errorObj
        if (event.target.name == 'eombFromCode') {
            errorObj.eombFromCode = false;
            this.setState({ errorObj: errorObj });
            this.setState({ eombFromCode: event.target.value.toUpperCase() }, () => {
                this.handleModifiers()
            })
        }
        if (event.target.name == 'eombThruCode') {
            errorObj.eombThruCode = false;
            this.setState({ errorObj: errorObj });
            this.setState({ eombThruCode: event.target.value.toUpperCase() }, () => {
                this.handleModifiers()
            })
        }
    }
    eombSort = () => {
        let Array1 = [this.state.mod1 !== 'Please Select One' ? this.state.mod1 : ''
            , this.state.mod2 !== 'Please Select One' ? this.state.mod2 : ''
            , this.state.mod3 !== 'Please Select One' ? this.state.mod3 : ''
            , this.state.mod4 !== 'Please Select One' ? this.state.mod4 : ''];
        let Array2 = [this.state.modt1 !== 'Please Select One' ? this.state.modt1 : ''
            , this.state.modt2 !== 'Please Select One' ? this.state.modt2 : ''
            , this.state.modt3 !== 'Please Select One' ? this.state.modt3 : ''
            , this.state.modt4 !== 'Please Select One' ? this.state.modt4 : ''];
        console.log(Array1, Array2)
        Array1.sort();
        Array2.sort();
        let A1 = []; let A2 = [];
        for (let i = 0; i < 4; i++) {
            let c1 = 0; let c2 = 0;
            if (Array1[i] !== '') {
                A1.push(Array1[i]);
            }
            if (Array2[i] !== '') {
                A2.push(Array2[i]);
            }
        }
        this.setState({
            mod1: A1.length < 0 ? '' : A1[0],
            mod2: A1.length < 1 ? '' : A1[1],
            mod3: A1.length < 2 ? '' : A1[2],
            mod4: A1.length < 3 ? '' : A1[3],
            modt1: A2.length < 0 ? '' : A2[0],
            modt2: A2.length < 1 ? '' : A2[1],
            modt3: A2.length < 2 ? '' : A2[2],
            modt4: A2.length < 3 ? '' : A2[3]
        }, () => { console.log(this.state.mod1, this.state.mod2, this.state.mod3) });
    }
    handleChanges = name => event => {
        console.log("handleChanges")
        this.props.setAllowNavigation();
        var errorObj = this.state.errorObj;
        errorObj.eombLob = false;
        errorObj.text = false;
        errorObj.eombFromCode = false;
        errorObj.eombThruCode = false;
        this.setState({
            errorObj: errorObj, eombLob: 'Please Select One', eombFromCode: '', eombThruCode: '', mod1: 'Please Select One'
            , mod2: 'Please Select One', mod3: 'Please Select One', mod4: 'Please Select One', modt1: 'Please Select One',
            modt2: 'Please Select One', modt3: 'Please Select One', modt4: 'Please Select One', eombText: ''
        }, () => {
            this.handleModifiers()
        });
        this.setState({ eombType: event.target.value });
    }
    handleModifiers = e => {
        if (!this.state.eombFromCode) {
            this.setState({ disableFrom: false })
        } else {
            this.setState({ disableFrom: true })
        }
        if (!this.state.eombThruCode) {
            this.setState({ disableThru: false })
        } else {
            this.setState({ disableThru: true })
        }
    }
    handleField = e => {
        this.props.setAllowNavigation();
        var errorObj = this.state.errorObj;
        let name = e.target.name;
        let value = e.target.value;
        errorObj[name] = false;
        if (name == 'eombFromCode' || name == 'eombThruCode') {
            this.setState({ [name]: value.toUpperCase(), errorObj: errorObj });
        }
        else {
            this.setState({ [name]: value, errorObj: errorObj });
        }
    }
    checkWordCount = e => {
        let value = e.target.value;
        let left_Chars = this.total_characters - value.length;
        this.setState({ wordCount: left_Chars, text: value });
    }
    renderSwitch = (eombType) => {
        switch (eombType) {
            case 'hcpcs':
                return <div className="w-100 fields" >


                    <div className="form-wrapper">
                        <div className="mui-custom-form override-width-18 override-m-1">
                            <TextField
                               id='eombFromCode'
                                fullWidth
                                name='eombFromCode'
                                value={this.state.eombFromCode}
                                onChange={this.handleEombType}
                                label="From Code"

                                required
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                inputProps={{
                                    maxLength: 10
                                }}
                                helperText={this.state.errorObj.eombFromCode ? this.state.error_msg.eombFromCode : null}
                                error={this.state.errorObj.eombFromCode ? this.state.error_msg.eombFromCode : null}

                            />
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="mod1"
                                fullWidth
                                label="Modifier 1"
                                select
                                disabled={this.state.disableFrom ? false : true}
                                // InputProps={{ readOnly: !this.state.disableFrom, className: !this.state.disableFrom ? 'Mui-disabled' : '' }}
                                name='mod1'
                                value={this.state.mod1}
                                onChange={this.handleField}
                                InputLabelProps={{
                                    shrink: true,
                                }}

                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="mod2"
                                fullWidth
                                label="Modifier 2"
                                select
                                disabled={this.state.disableFrom ? false : true}
                                // InputProps={{ readOnly: !this.state.disableFrom, className: !this.state.disableFrom ? 'Mui-disabled' : '' }}
                                name='mod2'
                                value={this.state.mod2}
                                onChange={this.handleField}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                                {/*this.props.ModifierData && this.props.ModifierData.modifierList ? this.props.ModifierData.modifierList.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )) : null*/}
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="mod3"
                                fullWidth
                                label="Modifier 3"
                                select
                               disabled={this.state.disableFrom ? false : true}
                            // InputProps={{ readOnly: !this.state.disableFrom, className: !this.state.disableFrom ? 'Mui-disabled' : '' }}
                                name='mod3'
                                value={this.state.mod3}
                                onChange={this.handleField}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                               
                                {/*this.props.ModifierData && this.props.ModifierData.modifierList ? this.props.ModifierData.modifierList.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )) : null*/}
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="mod4"
                                fullWidth
                                label="Modifier 4"
                                select
                                disabled={this.state.disableFrom ? false : true}
                                // InputProps={{ readOnly: !this.state.disableFrom, className: !this.state.disableFrom ? 'Mui-disabled' : '' }}
                                name='mod4'
                                value={this.state.mod4}
                                onChange={this.handleField}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                               {/*this.props.ModifierData && this.props.ModifierData.modifierList ? this.props.ModifierData.modifierList.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )) : null*/}
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>

                    </div>


                    <div style={{ display: 'flex', flexWrap: 'wrap' }}>
                        <div className="mui-custom-form override-width-18 override-m-1">
                            <TextField
                                id="eombThruCode"
                                fullWidth
                                name='eombThruCode'
                                value={this.state.eombThruCode}
                                onChange={this.handleEombType}
                                label="Thru Code"
                                required
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                inputProps={{
                                    maxLength: 10
                                }}
                                helperText={this.state.errorObj.eombThruCode ? this.state.error_msg.eombThruCode : null}
                                error={this.state.errorObj.eombThruCode ? this.state.error_msg.eombThruCode : null}

                            />
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="modt1"
                                fullWidth
                                label="Modifier 1"
                                select
                                disabled={this.state.disableThru ? false : true}
                                // InputProps={{ readOnly: !this.state.disableThru, className: !this.state.disableThru ? 'Mui-disabled' : '' }}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                name='modt1'
                                value={this.state.modt1}
                                onChange={this.handleField}
                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                                {/*this.props.ModifierData && this.props.ModifierData.modifierList ? this.props.ModifierData.modifierList.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )) : null*/}
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="modt2"
                                fullWidth
                                label="Modifier 2"
                                select
                                disabled={this.state.disableThru ? false : true}
                                // InputProps={{ readOnly: !this.state.disableThru, className: !this.state.disableThru ? 'Mui-disabled' : '' }}
                                name='modt2'
                                value={this.state.modt2}
                                onChange={this.handleField}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                                {/*this.props.ModifierData && this.props.ModifierData.modifierList ? this.props.ModifierData.modifierList.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )) : null*/}
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="modt3"
                                fullWidth
                                label="Modifier 3"
                                select
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                disabled={this.state.disableThru ? false : true}
                                // InputProps={{ readOnly: !this.state.disableThru, className: !this.state.disableThru ? 'Mui-disabled' : '' }}
                                name='modt3'
                                value={this.state.modt3}
                                onChange={this.handleField}
                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                               {/*this.props.ModifierData && this.props.ModifierData.modifierList ? this.props.ModifierData.modifierList.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )) : null*/}
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select override-width-18 override-m-1">
                            <TextField
                                id="modt4"
                                fullWidth
                                label="Modifier 4"
                                select
                                disabled={this.state.disableThru ? false : true}
                                // InputProps={{ readOnly: !this.state.disableThru, className: !this.state.disableThru ? 'Mui-disabled' : '' }}
                                name='modt4'
                                value={this.state.modt4}
                                onChange={this.handleField}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            >
                                <MenuItem selected key="Please Select One" value="Please Select One">
                                    Please Select One
                                </MenuItem>
                                {/*this.props.ModifierData && this.props.ModifierData.modifierList ? this.props.ModifierData.modifierList.map(option => (
                                    <MenuItem key={option} value={option}>
                                        {option}
                                    </MenuItem>
                                )) : null*/}
                                {/*this.props.ModifierData.modifierList */}
                                {this.props.ModifierData && this.props.ModifierData.listObj ? this.props.ModifierData.listObj['Reference#1029'].map(option => (
                                    <MenuItem key={option} value={option.code}>
                                        {option.code}
                                    </MenuItem>
                                )) : null}
                            </TextField>
                        </div>
                    </div>
                    <div className="mui-custom-form with-textarea override-width-98 override-m-1">
                        <Form.Group>
                            <Form.Label for="eomb-text3" className='MuiFormLabel-root small-label'>Text <span>*</span></Form.Label>
                            <Form.Control id="eomb-text3" as="textarea" rows="4" name='eombText' value={this.state.eombText} onChange={this.handleField} onKeyUp={this.checkWordCount} maxLength={this.total_characters} style={{ width: '100%' }} />
                            {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                {this.state.error_msg.text
                                }
                            </p> : null
                            }
                        </Form.Group>
                        <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', width: '200px', alignText: 'center' }}>Characters Remaining:{this.state.wordCount}</div>
                    </div>
                </div>
            case 'surgical-procedure':
                return (
                    <div className="w-100"  >

                        <div className="form-wrapper">
                            <div className="mui-custom-form override-m-1">
                                <TextField
                                    id='eombSPFromCode'
                                    fullWidth
                                    name='eombFromCode'
                                    value={this.state.eombFromCode}
                                    onChange={this.handleField}
                                    label="From Code"
                                    onChange={this.handleField}
                                    required
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    inputProps={{
                                        maxLength: 10
                                    }}
                                    helperText={this.state.errorObj.eombFromCode ? this.state.error_msg.eombFromCode : null}
                                    error={this.state.errorObj.eombFromCode ? this.state.error_msg.eombFromCode : null}

                                />
                            </div>
                            <div className="mui-custom-form override-m-1">
                                <TextField
                                    max={10}
                                    id="eombSPThruCode"
                                    fullWidth
                                    name='eombThruCode'
                                    value={this.state.eombThruCode}
                                    onChange={this.handleField}
                                    required
                                    label="Thru Code"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    inputProps={{
                                        maxLength: 10
                                    }}
                                    helperText={this.state.errorObj.eombThruCode ? this.state.error_msg.eombThruCode : null}
                                    error={this.state.errorObj.eombThruCode ? this.state.error_msg.eombThruCode : null}

                                />
                            </div>
                        </div>


                        <div className="mui-custom-form with-textarea override-width-95" >
                            <Form.Group>
                                <Form.Label for="eomb-text2" className='MuiFormLabel-root small-label'>Text <span>*</span></Form.Label>
                                <Form.Control id="eomb-text2" as="textarea" rows="4" onKeyUp={this.checkWordCount} name='eombText' value={this.state.eombText} onChange={this.handleField} style={{ width: '100%' }} maxLength={this.total_characters} />
                                {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                    {this.state.error_msg.text
                                    }
                                </p> : null
                                }
                            </Form.Group>
                            <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', width: '200px', alignText: 'center' }}>Characters Remaining:{this.state.wordCount}</div>
                        </div>
                    </div>
                )
            case 'revenue':
                return (
                    <div className="w-100"  >
                        <div className="form-wrapper">
                            <div className="mui-custom-form override-m-1">
                                <TextField
                                    id='eombRFromCode'
                                    fullWidth
                                    name='eombFromCode'
                                    value={this.state.eombFromCode}
                                    onChange={this.handleField}
                                    label="From Code"
                                    required
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    inputProps={{
                                        maxLength: 10
                                    }}
                                    helperText={this.state.errorObj.eombFromCode ? this.state.error_msg.eombFromCode : null}
                                    error={this.state.errorObj.eombFromCode ? this.state.error_msg.eombFromCode : null}
                                />
                            </div>
                            <div className="mui-custom-form override-m-1">
                                <TextField
                                    id="eombRThruCode"
                                    fullWidth
                                    name='eombThruCode'
                                    value={this.state.eombThruCode}
                                    onChange={this.handleField}
                                    required
                                    label="Thru Code"
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    inputProps={{
                                        maxLength: 10
                                    }}
                                    helperText={this.state.errorObj.eombThruCode ? this.state.error_msg.eombThruCode : null}
                                    error={this.state.errorObj.eombThruCode ? this.state.error_msg.eombThruCode : null}

                                />
                            </div>
                        </div>
                        <div className="mui-custom-form with-textarea override-width-95">
                            <Form.Group>
                                <Form.Label for="eomb-text1" className='MuiFormLabel-root small-label'>Text <span>*</span></Form.Label>
                                <Form.Control id="eomb-text1" as="textarea" rows="4" name='eombText' value={this.state.eombText} onChange={this.handleField} maxLength={this.total_characters} onKeyUp={this.checkWordCount} style={{ width: '100%' }} />
                                {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                    {this.state.error_msg.text
                                    }
                                </p> : null
                                }
                            </Form.Group>
                            <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', width: '200px', alignText: 'center' }}>Characters Remaining:{this.state.wordCount}</div>
                        </div>
                    </div>)
            default:
                return null;
        }
    }
    render() {
        return (
            <form className="w-100" noValidate style={{ padding: '0px 5px' }}>
                <div className="form-wrapper">
                    <div className="mui-custom-form with-select override-width-18 override-m-1">
                        <TextField
                            id='eombLob'
                            fullWidth
                            required
                            select
                            placeholder='Please Select One'
                            label="LOB"
                            name='eombLob'
                            value={this.state.eombLob}
                            onChange={this.handleField}
                            InputLabelProps={{
                                shrink: true,
                            }}
                            helperText={this.state.errorObj.eombLob ? this.state.error_msg.eombLob : null}
                            error={this.state.errorObj.eombLob ? this.state.error_msg.eombLob : null}
                        >
                            <MenuItem selected key="Please Select One" value="Please Select One">
                                Please Select One
                            </MenuItem>
                            {this.props.functionalDropDown && this.props.functionalDropDown.listObj && this.props.functionalDropDown.listObj['Reference#1019'] ? this.props.functionalDropDown.listObj['Reference#1019'].map(option => (
                                <MenuItem key={option} value={option.code}>
                                    {option.description}
                                </MenuItem>
                            )) : null}
                        </TextField>
                    </div>
                    {this.state.eombType == 'hcpcs' ? <div className="mui-custom-form with-select override-width-40 override-m-1 sub-radios" style={{width:"400px"}}
                    >
                        <label className='MuiFormLabel-root small-label' >EOMB Type<span>*</span></label>
                        <div style={{ paddingTop: '5px', marginLeft: '0px' }}>
                            <input type="radio"
                                id="standard-radio-hcpcs"
                                defaultChecked='true'
                                value="hcpcs"
                                name="eombType"
                                onChange={this.handleChanges('selectedOption')}
                                style={{ marginLeft: '0px' }}
                            /><label for="standard-radio-hcpcs" className="text-black">HCPCS </label>
                            <input type="radio"
                                id="standard-radio-surgical"
                                value="surgical-procedure"
                                className="ml-2"
                                name="eombType"
                                onChange={this.handleChanges('selectedOption')}
                            /><label for="standard-radio-surgical" className="text-black"> Surgical Procedure</label>
                            <input type="radio"
                                id="standard-radio-revenue"
                                value="revenue"
                                className="ml-2"
                                name="eombType"
                                onChange={this.handleChanges('selectedOption')}
                            /><label for="standard-radio-revenue" className="text-black"> Revenue</label>
                        </div>
                    </div> :
                        <div className="mui-custom-form with-select override-width-40 override-m-1 sub-radios" style={{width:"400px"}}//style={{ marginLeft: '20px' }}
                        >
                            <label className='MuiFormLabel-root small-label' >EOMB Type<span>*</span></label>
                            <div style={{ paddingTop: '5px', marginLeft: '0px' }}>
                                <input type="radio"
                                    id="standard-radio-hcpcs1"
                                    defaultChecked='true'
                                    value="hcpcs"
                                    name="eombType"
                                    onChange={this.handleChanges('selectedOption')}
                                    style={{ marginLeft: '0px' }}
                                /><label for="standard-radio-hcpcs1" className="text-black"> HCPCS</label>
                                <input type="radio"
                                    id="standard-radio-surgical1"
                                    value="surgical-procedure"
                                    className="ml-2"
                                    name="eombType"
                                    onChange={this.handleChanges('selectedOption')}
                                /><label for="standard-radio-surgical1" className="text-black"> Surgical Procedure</label>
                                <input type="radio"
                                    id="standard-radio-revenue1"
                                    value="revenue"
                                    className="ml-2"
                                    name="eombType"
                                    onChange={this.handleChanges('selectedOption')}
                                /><label for="standard-radio-revenue1" className="text-black"> Revenue</label>
                            </div>
                        </div>
                    }
                </div>
                <div className="form-wrapper">
                    {this.renderSwitch(this.state.eombType)}
                </div>
            </form>
        )
    }

}

//RAEOB Class component
class RAEOB_ extends React.Component {
    constructor(props) {
        super(props);
        this.total_characters = 320;
        this.dropDown = props.dropDown ? props.dropDown : [];
        this.state = {
            raeobLob: 'Please Select One',
            eobCode: '',
            text: '',
            showDropdown: false,
            wordCount: this.total_characters,
            errorObj: {
                raeobLob: false,
                eobCode: false,
                text: false
            },
            error_msg: {
                raeobLob: '',
                eobCode: '',
                text: ''
            }
       }
        this.value = 0;
        this.props.dispatch(AppConfigDropdownActions(dropdownCriteria));
    }
    componentDidMount() {
        if (this.props.dropDown) {
            this.setState({ showDropdown: true })
        }
    }
    searchCheck = () => {
        let errorMessagesArray = [];
        var errorObj = this.state.errorObj;
        var error_msg = this.state.error_msg;
        if (this.state.raeobLob == 'Please Select One') {
            errorObj.raeobLob = true;
            error_msg.raeobLob = "LOB" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.raeobLob);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if (!this.state.eobCode || (this.state.eobCode && !this.state.eobCode.trim())) {
            errorObj.eobCode = true;
            error_msg.eobCode = "EOB Code" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.eobCode);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if ((this.state.text && !this.state.text.trim()) || !this.state.text) {
            errorObj.text = true;
            error_msg.text = "Text" + (TextManagementErrors.Required_Field_Error);
            errorMessagesArray.push(error_msg.text);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        return errorMessagesArray;
    }
    onSave = e => {
        this.props.dispatch(SetSpinner(true));
        this.props.dispatch(ResetTextSearchReducer());
        return {
            "auditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "auditTimeStamp": DateUtils.getUTCTimeStamp(),
            "addedAuditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "addedAuditTimeStamp": DateUtils.getUTCTimeStamp(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
            "auditKeyListFiltered": false,
            "claimEOBCode": this.state.eobCode,
            "checkClmExc": null,
            "eobDesc": this.state.text,
            "eobType": null,
            "eobBeginDate": null,
            "eobEndDate": null,
            "lobCode": this.state.raeobLob,
            "noteSet": null
        }
    }

    checkWordCount = e => {
        let value = e.target.value;
        let left_Chars = this.total_characters - value.length;
        this.setState({ wordCount: left_Chars, text: value });
    }
    handleField = e => {
        this.props.setAllowNavigation();
        let name = e.target.name;
        let errorObj = this.state.errorObj;
        errorObj[name] = false;
        let value = e.target.value;
        if (name == 'eobCode') {
            this.setState({ [name]: value.toUpperCase(), errorObj: errorObj });
        }
        else {
            this.setState({ [name]: value, errorObj: errorObj });
        }
    }
    handleTabs = e => {
        this.value = e.target.value;
    }
    render() {
        return (
            <div style={{ width: '100%' }}>
                {/* <AppBar position="static">
                    <Tabs value={this.value} onChange={this.handleTabs} aria-label="simple tabs example" className="tabChange">
                        <Tab label="Text Detail" />
                        <Tab label="Notes" />
                        <Tab label="Attachments" />
                        <Tab label="Audit Log" />
                    </Tabs>
                </AppBar> */}
                {/* <TabPanel value={this.value} index={0}> */}
                <div className="row">
                    <form autoComplete="off" style={{ display: 'flex', width: '100%', flexDirection: 'column', justifyContent: 'space-evenly' }} noValidate>
                        <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-start' }}>
                            <div className="mui-custom-form with-select input-md" style={{paddingLeft:"20px",width:"200px"}} >
                                <TextField
                                    id="line-of-business"
                                    fullWidth
                                    required
                                    select
                                    name='raeobLob'
                                    value={this.state.raeobLob}
                                    onChange={this.handleField}
                                    label="LOB"
                                    helperText={this.state.errorObj.raeobLob ? this.state.error_msg.raeobLob : null}
                                    error={this.state.errorObj.raeobLob ? this.state.error_msg.raeobLob : null}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                >
                                    <MenuItem selected key="Please Select One" value="Please Select One">
                                        Please Select One
                                </MenuItem>
                                    {this.props.functionalDropDown && this.props.functionalDropDown.listObj && this.props.functionalDropDown.listObj['Reference#1019'] ? this.props.functionalDropDown.listObj['Reference#1019'].map(option => (
                                        <MenuItem key={option} value={option.code}>
                                            {option.description}
                                        </MenuItem>
                                    )) : null}
                                </TextField>
                            </div>
                            <div className="mui-custom-form input-sm" style={{width:"200px"}}>
                                <TextField
                                    required
                                    id="eobCode"
                                    fullWidth
                                    label="EOB Code"
                                    name='eobCode'
                                    value={this.state.eobCode}
                                    onChange={this.handleField}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    inputProps={{
                                        maxLength: 4
                                    }}
                                    helperText={this.state.errorObj.eobCode ? this.state.error_msg.eobCode : null}
                                    error={this.state.errorObj.eobCode ? this.state.error_msg.eobCode : null}
                                >
                                </TextField>
                            </div>
                        </div>
                        <div className="mui-custom-form with-textarea override-width-95" style={{paddingLeft:"20px",paddingRight:"20px"}}>
                            {/* <label>Text*</label> */}
                            <Form.Group controlId="exampleForm.ControlTextarea1">
                                <Form.Label for="raeob-text" className='MuiFormLabel-root small-label'>Text <span>*</span></Form.Label>
                                <Form.Control id="raeob-text" as="textarea" rows='4' onChange={this.handleField} name='text' maxLength={this.total_characters} onKeyUp={this.checkWordCount} onChange={this.handleField} name='text' value={this.state.text} maxLength='320' className='text-area-text' />
                                {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                    {this.state.error_msg.text
                                    }
                                </p> : null
                                }
                            </Form.Group>
                            <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', width: '220px', alignText: 'center' }}>Characters Remaining:{this.state.wordCount}</div>
                        </div>
                    </form>
                    {/* </TabPanel> */}
                    {/* <TabPanel value={this.value} index={1}> */}
                    {/* <div>
                        Notes
                    </div> */}
                    {/* </TabPanel> */}
                </div>
            </div>

        )
    }
}
//RAEOB class component ends

class ProviderNotice_ extends React.Component {
    constructor(props) {
        super(props);
        this.total_characters = 4000;
        this.state = {
            pn_lob: 'Please Select One',
            provider_type: 'Please Select One',
            provider_specialty: 'Please Select One',
            begin_date: null,
            end_date: null,
            text: '',
            showDropdown: false,
            word_count: this.total_characters,
            errorObj: {
                pn_lob: false,
                begin_date: false,
                end_date: false,
                text: false
            },
            error_msg: {
                pn_lob: '',
                begin_date: '',
                end_date: '',
                text: ''
            },
        }
        this.editorData = this.editorData.bind(this);
        this.props.dispatch(AppConfigDropdownActions(dropdownCriteria));
        this.dropDown = (props.dropDown != undefined && props.dropDown != null) ? props.dropDown : null
        // this.providerSpecialtyData = props.ProviderSpecialtyData ? props.ProviderSpecialtyData : []
    }
    componentDidMount() {
        if (this.props.dropDown) {
            this.setState({ showDropdown: true })
        }
    }
    getProviderSpecialty = (value) => {
        this.setState({ setShow: false });
        let providertype = this.props.functionalDropDown.listObj['Provider#11'].filter(
            data => data.code === value
        )
        this.setState({ provider_specialty: 'Please Select One' });
        this.props.getProviderSpecialty(providertype[0]);
        setTimeout(
            function () {
                this.setState({ setShow: true });
            }
                .bind(this),
            2500
        );
    }
    setErrObject() {
        var errorObj = this.state.errorObj;
        errorObj.pn_lob = false;
        errorObj.begin_date = false;
        errorObj.end_date = false;
        errorObj.text = false;
        this.setState({ errorObj: errorObj });
    }
    searchCheck = () => {
        let errorMessagesArray = [];
        var errorObj = this.state.errorObj;
        var error_msg = this.state.error_msg;
        var current_date = new Date();
        let date_format_regex = /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?[0-9]{2})*$/;
        if (this.state.pn_lob == 'Please Select One') {
            errorObj.pn_lob = true;
            error_msg.pn_lob = "LOB" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.pn_lob);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
           })
        }
        if (!this.state.begin_date) {
            errorObj.begin_date = true;
            error_msg.begin_date = "Begin Date" + TextManagementErrors.Required_Field_Error
            errorMessagesArray.push("Begin Date" + TextManagementErrors.Required_Field_Error);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        else if (this.state.begin_date.toString() == 'Invalid Date') {
            errorObj.begin_date = true;
            error_msg.begin_date = TextManagementErrors.Invalid_Format_Error_BeginDate;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })

        } else if (DateUtils.validateDateMinimumValue(this.state.begin_date)) {
            errorObj.begin_date = true;
            error_msg.begin_date = AppConstants.DATE_ERROR_1964;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        } else if (dateCheck(new Date(this.state.begin_date), new Date()) == 0) {
            errorObj.begin_date = true;
            error_msg.begin_date = TextManagementErrors.Current_Date_Error;
            errorMessagesArray.push(TextManagementErrors.Current_Date_Error);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        } else if (this.state.end_date != null && dateCheck(this.state.begin_date, this.state.end_date) == 1) {
            errorObj.begin_date = true;
            error_msg.begin_date = TextManagementErrors.Begin_End_Date_Error;
            errorMessagesArray.push(TextManagementErrors.Begin_End_Date_Error);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if (!this.state.end_date) {
            errorObj.end_date = true;
            error_msg.end_date = "End Date" + TextManagementErrors.Required_Field_Error
            errorMessagesArray.push("End Date" + TextManagementErrors.Required_Field_Error);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        else if (this.state.end_date.toString() == 'Invalid Date') {
            errorObj.end_date = true;
            error_msg.end_date = TextManagementErrors.Invalid_Format_Error_EndDate;
            errorMessagesArray.push(error_msg.end_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })

        } else if (DateUtils.validateDateMinimumValue(this.state.end_date)) {
            errorObj.end_date = true;
            error_msg.end_date = AppConstants.DATE_ERROR_1964;
            errorMessagesArray.push(error_msg.end_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if ((this.state.text && !this.state.text.replace(/<\/?[^>]+(>|$)/g, '').trim()) || !this.state.text) {
            errorObj.text = true;
            error_msg.text = "Text" + (TextManagementErrors.Required_Field_Error);
            errorMessagesArray.push(error_msg.text);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        return errorMessagesArray;
    }
    onSave = e => {
        this.props.dispatch(SetSpinner(true));
        this.props.dispatch(ResetTextSearchReducer());
        let providertype = null;
        let providerSpeciality = null
        if (this.state.provider_type !== null && this.state.provider_type !== 'Please Select One') {
            providertype = this.props.functionalDropDown.listObj['Provider#11'].filter(
                data => data.code === this.state.provider_type
            )
        }
        if (this.state.provider_specialty !== null && this.state.provider_specialty !== 'Please Select One' && this.props.ProviderSpecialtyData) {
            providerSpeciality = this.props.ProviderSpecialtyData.filter(
                data => this.state.provider_specialty === data.code
            )
        }
        return {
            "auditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "auditTimeStamp": DateUtils.getUTCTimeStamp(),
            "addedAuditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "addedAuditTimeStamp": DateUtils.getUTCTimeStamp(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
           "auditKeyListFiltered": false,
            "beginDate": moment(this.state.begin_date).format('MM/DD/YYYY'),
            "endDate": moment(this.state.end_date).format('MM/DD/YYYY'),
            "voidDate": null,
            "textRALetterSK": "",
            "providerNoticeText": this.state.text,
            "providerNoticeTypeDesc": this.state.provider_type !== 'Please Select One' ? providertype ? providertype[0].description : null : null,
            "providerNoticeSpecialityDesc": this.state.provider_specialty !== 'Please Select One' ? providerSpeciality ? providerSpeciality[0].description : null : null,
            "providerSpeciality": this.state.provider_specialty !== 'Please Select One' ? providerSpeciality ? providerSpeciality[0].code : null : null,
            "providerType": this.state.provider_type != 'Please Select One' ? providertype ? providertype[0].code : null : null,
            "lobCode": this.state.pn_lob,
            "noteSet": null,
            "disableVoidFlag": false,
            "providerVoid": false,
            "inputtaxtFlag": false
        }
    }
    handleField = e => {
        this.props.setAllowNavigation();
        let value = e.target.value;
        let name = e.target.name;
        let errorObj = this.state.errorObj;
        errorObj[name] = false;
        // this.props.setErrorNull();
        if (name === 'provider_type') {
            if (value !== 'Please Select One') {
                this.setState({ [name]: value, errorObj: errorObj }, () => {
                    this.getProviderSpecialty(value)
                });
            } else {
                this.setState({ provider_specialty: 'Please Select One' })
            }
        }
        this.setState({ [name]: value, errorObj: errorObj });

    }
    // componentDidUpdate(){
    // }
    handleDate = e => {
        this.props.setAllowNavigation();
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj.begin_date = false;
        this.setState({ begin_date: e, errorObj: errorObj })
    }
    handleEndDate = e => {
        this.props.setAllowNavigation();
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj.end_date = false;
        this.setState({ end_date: e, errorObj: errorObj })
    }
    editorData = (data, editorData) => {
        this.props.setAllowNavigation();
        let errorObj = this.state.errorObj;
        errorObj.text = false;
        this.setState({ text: editorData, errorObj: errorObj }, () => {
            let value = data;
            let left_Chars = this.total_characters - value.length;
            this.setState({ word_count: left_Chars, text: editorData });
        })
    }
    render() {
        const { classes } = this.props
        return (

            <div className="w-100" style={{ padding: '0px 2px' }}>
                <div className="row">
                    <form autoComplete="off" style={{ display: 'flex', flexDirection: 'column', width: '100%' }} noValidate>
                        <div style={{ display: 'flex', flexDirection: 'row', flexWrap: 'wrap' }} className="form-170">
                            <div className="mui-custom-form with-select input-md" style={{width:"250px",paddingRight:"20px",paddingLeft:"20px"}}>
                                <TextField
                                    id="pn_lob"
                                    fullWidth
                                    required
                                    select
                                    name='pn_lob'
                                    value={this.state.pn_lob}
                                    onChange={this.handleField}
                                    label="LOB"
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    SelectProps={{
                                        MenuProps: {
                                            // className: classes.menu,
                                        },
                                    }}
                                    helperText={this.state.errorObj.pn_lob ? this.state.error_msg.pn_lob : null}
                                    error={this.state.errorObj.pn_lob ? this.state.error_msg.pn_lob : null}
                                >
                                    <MenuItem selected key="Please Select One" value="Please Select One">
                                        Please Select One
                                </MenuItem>
                                    {this.props.functionalDropDown && this.props.functionalDropDown.listObj && this.props.functionalDropDown.listObj['Reference#1019'] ? this.props.functionalDropDown.listObj['Reference#1019'].map(option => (
                                        <MenuItem key={option} value={option.code}>
                                            {option.description}
                                        </MenuItem>
                                    )) : null}
                                </TextField>
                            </div>
                            <div className="mui-custom-form with-select input-md" style={{width:"250px",paddingRight:"20px",paddingLeft:"20px"}}>
                                <TextField
                                    id="provider_type"
                                    fullWidth
                                    label="Provider Type"
                                    name='provider_type'
                                    value={this.state.provider_type}
                                    onChange={this.handleField}
                                    onClick={this.handleField}
                                    select
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    SelectProps={{
                                        MenuProps: {
                                            // className: classes.menu,
                                        },
                                    }}
                                >
                                    <MenuItem selected key="Please Select One" value="Please Select One">
                                        Please Select One
                                        </MenuItem>
                                    {(this.props.functionalDropDown && this.props.functionalDropDown.listObj && this.props.functionalDropDown.listObj['Provider#11']) ? this.props.functionalDropDown.listObj['Provider#11'].map((item, index) => (
                                        <MenuItem key={index} value={item.code}>
                                            {item.description}
                                        </MenuItem>
                                    )) : null}
                                </TextField>
                            </div>
                            <div className="mui-custom-form with-select input-md" style={{width:"250px",paddingRight:"20px",paddingLeft:"20px"}}>
                                <TextField
                                    id="provider_specialty"
                                    fullWidth
                                    label="Provider Specialty"
                                    select
                                    // disabled={this.state.provider_type == 'Please Select One' ? true : false}
                                    InputProps={{ readOnly: this.state.provider_type == 'Please Select One', className: this.state.provider_type == 'Please Select One' ? 'Mui-disabled' : '' }}
                                    name='provider_specialty'
                                    value={this.state.provider_specialty}
                                    onChange={this.handleField}
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    SelectProps={{
                                        MenuProps: {
                                            // className: classes.menu,
                                        },
                                    }}
                                >
                                    <MenuItem selected key="Please Select One" value="Please Select One">
                                        Please Select One
                                </MenuItem>
                                    {this.props.ProviderSpecialtyData && !this.props.ProviderSpecialtyData.systemError ? this.props.ProviderSpecialtyData.map((item, index) => (
                                        <MenuItem key={index} value={item.code}>
                                            {item.description}
                                        </MenuItem>
                                    )) : null}

                                </TextField>
                            </div>
                            <div className="mui-custom-form with-date" style={{width:"250px",paddingRight:"20px",paddingLeft:"20px"}}>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker
                                        maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                        id="begin_date"
                                        label="Begin Date"
                                        format="MM/dd/yyyy"
                                        required
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        placeholder='mm/dd/yyyy'
                                        name='begin_date'
                                        value={this.state.begin_date}
                                        onChange={this.handleDate}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                        helperText={this.state.errorObj.begin_date ? this.state.error_msg.begin_date : null}
                                        error={this.state.errorObj.begin_date ? TextManagementErrors.Required_Field_Error : null}

                                    />
                                </MuiPickersUtilsProvider>
                            </div>
                            <div className="mui-custom-form with-date" style={{width:"250px",paddingRight:"20px",paddingLeft:"20px"}}>

                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                    <KeyboardDatePicker
                                        maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                        id="end_date"
                                        label="End Date"
                                        format="MM/dd/yyyy"
                                        placeholder='mm/dd/yyyy'
                                        required
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        name='end_date'
                                        value={this.state.end_date}
                                        onChange={this.handleEndDate}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                        helperText={this.state.errorObj.end_date ? this.state.error_msg.end_date : null}
                                        error={this.state.errorObj.end_date ? TextManagementErrors.Required_Field_Error : null}

                                    />
                                </MuiPickersUtilsProvider>
                            </div>
                        </div >
                        <div className="mui-custom-form with-textarea override-width-95"style={{width:"98%",paddingRight:"20px",paddingLeft:"20px"}}>
                            <label className='MuiFormLabel-root small-label'>Text<span>*</span></label>
                            <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem' }}>
                                <CustomizedEditor className="ram" total_characters={this.total_characters} editorData={this.editorData} editorState={null} />
                            </div>

                            {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                {this.state.error_msg.text
                                }
                            </p> : null
                            }
                            <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', marginTop: '5px', width: '220px', alignText: 'center' }}>Characters Remaining:{this.state.word_count}</div>
                        </div>
                        {/* <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', margin: '10px', width: '200px', alignText: 'center' }}>Characters Remaining:{this.state.word_count}</div> */}
                    </form>
                </div>
            </div>
        )
    }
}

class RemarkCode_ extends React.Component {
    constructor(props) {
        super(props);
        this.total_characters = 4000;
        this.state = {
            remark_code: '',
            begin_date: null,
            text: '',
            word_count: this.total_characters,
            errorObj: {
                remark_code: false,
                begin_date: false,
                text: false
            },
            error_msg: {
                remark_code: '',
                begin_date: '',
                text: ''
            }
        }
    }
    setErrObject() {
        var errorObj = this.state.errorObj;
        errorObj.remark_code = false;
        errorObj.begin_date = false;
        errorObj.termination_date = false;
        errorObj.text = false;
        this.setState({ errorObj: errorObj });
    }
    searchCheck = () => {
        let errorMessagesArray = [];
        var errorObj = this.state.errorObj;
        var error_msg = this.state.error_msg;
        if ((this.state.remark_code && !this.state.remark_code.trim()) || !this.state.remark_code) {
            errorObj.remark_code = true;
            error_msg.remark_code = "Remark Code" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.remark_code);
            this.setState({ errorObj: errorObj }, () => {
            })
        }
        if (!this.state.begin_date) {
            errorObj.begin_date = true;
            error_msg.begin_date = "Begin Date" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        else if (this.state.begin_date.toString() == 'Invalid Date') {
            errorObj.begin_date = true;
            error_msg.begin_date = TextManagementErrors.Invalid_Format_Error_BeginDate;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })

        }
        else if (DateUtils.validateDateMinimumValue(this.state.begin_date)) {
            errorObj.begin_date = true;
            error_msg.begin_date = AppConstants.DATE_ERROR_1964;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if ((this.state.text && !this.state.text.trim()) || !this.state.text) {
            errorObj.text = true;
            error_msg.text = "Text" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push("Text" + TextManagementErrors.Required_Field_Error);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        return errorMessagesArray;
    }
    onSave = e => {
       this.props.dispatch(SetSpinner(true));
        this.props.dispatch(ResetTextSearchReducer());
        return {
            "auditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "auditTimeStamp": DateUtils.getUTCTimeStamp(),
            "addedAuditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "addedAuditTimeStamp": DateUtils.getUTCTimeStamp(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
            "auditKeyListFiltered": false,
            "beginDate": moment(this.state.begin_date).format('MM/DD/YYYY'),
            "remarkCode": this.state.remark_code,
            "remarkText": this.state.text,
            "checkClmExc": null,
            "terminationDate": "12/31/9999",
            "tempBeginDate": null,
            "tempTermDate": null,
            "remarkCodeSeqNo": null
        }
    }
    handleReset = e => {
        alert("YOYO");
    }
    checkWordCount = e => {
        let value = e.target.value;
        value = value.split(' ').join(' ')
        this.setState({ word_count: this.total_characters - value.length });
    }
    handleField = e => {
        this.props.setAllowNavigation();
        let value = e.target.value;
        let name = e.target.name;
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj[name] = false;
        if (name == 'remark_code') {
            this.setState({ [name]: value.toUpperCase(), errorObj: errorObj });
        }
        else {
            this.setState({ [name]: value, errorObj: errorObj });
        }
    }
    handleDate = e => {
        this.props.setAllowNavigation();
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj.begin_date = false;
        this.setState({ begin_date: e, errorObj: errorObj })
    }

    render() {
        return (
            <div className="w-100"  >
                <div className="row">
                    <div style={{ display: 'flex', width: '100%' }}>
                        <div className="mui-custom-form input-md" style={{paddingLeft:"20px "}}>
                            <TextField
                                id="remark_code"
                                fullWidth
                                label="Remark Code"
                                required
                                name='remark_code'
                                value={this.state.remark_code}
                                onChange={this.handleField}
                                InputLabelProps={{
                                    shrink: true
                                }}
                                helperText={this.state.errorObj.remark_code ? this.state.error_msg.remark_code : null}
                                error={this.state.errorObj.remark_code ? this.state.error_msg.remark_code : null}
                                inputProps={{
                                    maxLength: 5
                                }}
                            />
                        </div>
                        <div className="mui-custom-form with-date">
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                    id="begin_date"
                                    label="Begin Date"
                                    format="MM/dd/yyyy"
                                    required
                                    placeholder='mm/dd/yyyy'
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    name='begin_date'
                                    value={this.state.begin_date}
                                    onChange={this.handleDate}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                    helperText={this.state.errorObj.begin_date ? this.state.error_msg.begin_date : null}
                                    error={this.state.errorObj.begin_date ? this.state.error_msg.begin_date : null}

                                />
                            </MuiPickersUtilsProvider>
                        </div>
                        {/* </div> */}
                    </div>
                </div>
                <div className="row">
                    <div className="mui-custom-form with-textarea override-width-95" style={{paddingLeft:"20px",paddingRight:"20px"
                ,width:"98%"
                }}>
                        {/* <label>Text*</label> */}
                        <Form.Group>
                            <Form.Label for="remarkcode-text" className='MuiFormLabel-root small-label'>Text <span>*</span></Form.Label>
                            <Form.Control id="remarkcode-text" as="textarea" onChange={this.handleField} name='text' value={this.state.text} onChange={this.handleField} name='text' rows="4" maxLength={this.total_characters} onKeyUp={this.checkWordCount} />
                            {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                {this.state.error_msg.text
                                }
                            </p> : null
                            }
                        </Form.Group>
                        <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', width: '200px', alignText: 'center' }}>Characters Remaining:{this.state.word_count}</div>
                    </div>
                </div >
            </div>
        )
    }
}

class AdjustmentReason_ extends React.Component {
    constructor(props) {
        super(props);
        this.total_characters = 4000;
        this.state = {
            adjustment_reason_code: '',
            begin_date: null,
            text: '',
            word_count: this.total_characters,
            errorObj: {
                adjustment_reason_code: false,
                begin_date: false,
                text: false
            },
            error_msg: {
                adjustment_reason_code: '',
                begin_date: '',
                text: ''
            }
        }
    }
    setErrObject() {
        var errorObj = this.state.errorObj;
        errorObj.adjustment_reason_code = false;
        errorObj.begin_date = false;
        errorObj.termination_date = false;
        errorObj.text = false;
        this.setState({ errorObj: errorObj });
    }
    searchCheck = () => {
        let errorMessagesArray = [];
        var errorObj = this.state.errorObj;
        var error_msg = this.state.error_msg;
        if ((this.state.adjustment_reason_code && !this.state.adjustment_reason_code.trim()) || !this.state.adjustment_reason_code) {
            errorObj.adjustment_reason_code = true;
            error_msg.adjustment_reason_code = "Adjustment Reason code" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.adjustment_reason_code);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if (!this.state.begin_date) {
            errorObj.begin_date = true;
            error_msg.begin_date = "Begin Date" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        else if (this.state.begin_date.toString() == 'Invalid Date') {
            errorObj.begin_date = true;
            error_msg.begin_date = TextManagementErrors.Invalid_Format_Error_BeginDate;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })

        }
        else if (DateUtils.validateDateMinimumValue(this.state.begin_date)) {
            errorObj.begin_date = true;
            error_msg.begin_date = AppConstants.DATE_ERROR_1964;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if ((this.state.text && !this.state.text.trim()) || !this.state.text) {
            errorObj.text = true;
            error_msg.text = "Text" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.text);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        return errorMessagesArray;
    }
    onSave = e => {
        this.props.dispatch(SetSpinner(true));
        this.props.dispatch(ResetTextSearchReducer());
        return {
            "auditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "auditTimeStamp": DateUtils.getUTCTimeStamp(),
            "addedAuditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "addedAuditTimeStamp": DateUtils.getUTCTimeStamp(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
            "auditKeyListFiltered": false,
            "adjustmentReasonCode": this.state.adjustment_reason_code,
            "adjustmentReasonText": this.state.text,
            "noteSet": null,
            "checkClmExc": null,
            "terminationDate": "12/31/9999",
            "beginDate": moment(this.state.begin_date).format('MM/DD/YYYY'),
            "adjstResnSeqNo": 1
        }

    }
    handleReset = e => {
        alert("YOYO");
    }
    checkWordCount = e => {
        let value = e.target.value;
        value = value.split(' ').join(' ')
        this.setState({ word_count: this.total_characters - value.length });
    }
    handleField = e => {
        this.props.setAllowNavigation();
        let value = e.target.value;
        let name = e.target.name;
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj[name] = false;
        if (name == 'adjustment_reason_code') {
            this.setState({ [name]: value.toUpperCase(), errorObj: errorObj });
        }
        else {
            this.setState({ [name]: value, errorObj: errorObj });
        }
    }
    handleDate = e => {
        this.props.setAllowNavigation();
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj.begin_date = false;
        this.setState({ begin_date: e, errorObj: errorObj })
    }
    render() {
        return (

            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-evenly', width: '100%' }}>
                <div className="row">
                    <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-start', width: '100%' }}>

                        <div className="mui-custom-form input-md" style={{paddingLeft:"20px",width:"200px"}} >
                            <TextField
                                id="adjustment_reason_code"
                                fullWidth
                                label="Adjustment Reason Code"
                                name='adjustment_reason_code'
                                value={this.state.adjustment_reason_code}
                                onChange={this.handleField}
                                required
                                InputLabelProps={{
                                    shrink: true
                                }}
                                inputProps={{
                                    maxLength: 5
                                }}
                                helperText={this.state.errorObj.adjustment_reason_code ? this.state.error_msg.adjustment_reason_code : null}
                                error={this.state.errorObj.adjustment_reason_code ? this.state.error_msg.adjustment_reason_code : null}
                            />
                        </div>
                        <div className="mui-custom-form with-date">

                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                    id="begin_date"
                                    label="Begin Date"
                                    format="MM/dd/yyyy"
                                    placeholder='mm/dd/yyyy'
                                    name='begin_date'
                                    required
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    value={this.state.begin_date}
                                    onChange={this.handleDate}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                    helperText={this.state.errorObj.begin_date ? this.state.error_msg.begin_date : null}
                                    error={this.state.errorObj.begin_date ? this.state.error_msg.begin_date : null}

                                />
                            </MuiPickersUtilsProvider>
                        </div>
                    </div>
             </div>
        )
    }
}

class ServiceAuthReason_ extends React.Component {
    constructor(props) {
        super(props);
        this.total_characters = 4000;
        this.state = {
            service_auth_reason_code: '',
            text: '',
            checkSAExc:'N',
            letterInd:'N',
            word_count: this.total_characters,
            errorObj: {
                service_auth_reason_code: false,
                text: false
            },
            error_msg: {
                service_auth_reason_code: '',
                text: ''
            }
        }
    }
    setErrObject() {
        var errorObj = this.state.errorObj;
        errorObj.service_auth_reason_code = false;
        errorObj.text = false;
        this.setState({ errorObj: errorObj });
    }
    searchCheck = () => {
        let errorMessagesArray = [];
        var errorObj = this.state.errorObj;
        var error_msg = this.state.error_msg;
        if ((this.state.service_auth_reason_code && !this.state.service_auth_reason_code.trim()) || !this.state.service_auth_reason_code) {
            errorObj.service_auth_reason_code = true;
            error_msg.service_auth_reason_code = "Service Authroization Reason code" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.service_auth_reason_code);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if ((this.state.text && !this.state.text.trim()) || !this.state.text) {
            errorObj.text = true;
            error_msg.text = "Text" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.text);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        return errorMessagesArray;
    }
    handleChanges = event => {
        console.log("handle change",event)
        this.setState({ letterInd: event.target.value }, () => {})
    };
    onSave = e => {
        this.props.dispatch(SetSpinner(true));
        this.props.dispatch(ResetTextSearchReducer());
        return {
            "auditUserID": userDetails.loginUserID ?  userDetails.loginUserID : this.props.logInUserID ? this.props.logInUserID : null,
            "auditTimeStamp": DateUtils.getUTCTimeStamp(),
            "addedAuditUserID":  userDetails.loginUserID ?  userDetails.loginUserID : this.props.logInUserID ? this.props.logInUserID : null,
            "addedAuditTimeStamp": DateUtils.getUTCTimeStamp(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
            "auditKeyListFiltered": false,
            "authorizationReasonCode": this.state.service_auth_reason_code,
            "letterInd": this.state.letterInd,
            "text": this.state.text,
            "checkSAExc": this.state.checkSAExc
        }

    }
    handleReset = e => {
        alert("YOYO");
    }
    checkWordCount = e => {
        let value = e.target.value;
        value = value.split(' ').join(' ')
        this.setState({ word_count: this.total_characters - value.length });
    }
    handleField = e => {
        this.props.setAllowNavigation();
        let value = e.target.value;
        let name = e.target.name;
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj[name] = false;
        if (name == 'service_auth_reason_code') {
            this.setState({ [name]: value.toUpperCase(), errorObj: errorObj });
        }
        else {
            this.setState({ [name]: value, errorObj: errorObj });
        }
    }
    render() {
        return (

            
                <div className="form-wrapper form-3-column wid-100">
                

                        <div className="mui-custom-form input-md">
                            <TextField
                                id="service_auth_reason_code"
                                fullWidth
                                label="Service Authroization Reason Code"
                                name='service_auth_reason_code'
                                value={this.state.service_auth_reason_code}
                                onChange={this.handleField}
                                required
                                InputLabelProps={{
                                    shrink: true
                                }}
                                inputProps={{
                                    maxLength: 3
                                }}
                                helperText={this.state.errorObj.service_auth_reason_code ? this.state.error_msg.service_auth_reason_code : null}
                                error={this.state.errorObj.service_auth_reason_code ? this.state.error_msg.service_auth_reason_code : null}
                            />
                        </div>

                        <div className="mui-custom-form input-md field-md">
                            <label className="MuiFormLabel-root MuiInputLabel-shrink">
                                Reason code text will appear on Service Authroization
                            </label>
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    name="reasonCodeTextAppear"
                                    onChange={(e) => this.handleChanges(e)}
                                    value={this.state.letterInd}
                                    InputLabelProps={{
                                        shrink: true,
                                        required: true
                                    }}
                                >
                                    <FormControlLabel
                                        id="standard-radio-yes"
                                        value="Y"
                                        control={<Radio color="primary" />}
                                        label="Yes"
                                    />
                                    <FormControlLabel
                                        id="standard-radio-no"
                                        defaultChecked='true'
                                        value="N"
                                        control={<Radio color="primary" />}
                                        label="No"
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                       
                  
                    <div className="mui-custom-form with-textarea field-xl">
                        <Form.Group>
                            <Form.Label for="adjreason-text" className='MuiFormLabel-root small-label'>Text <span>*</span></Form.Label>
                            <Form.Control id="adjreason-text" as="textarea" onChange={this.handleField} name='text' value={this.state.text} onChange={this.handleField} name='text' rows="4" maxLength={this.total_characters} onKeyUp={this.checkWordCount} />
                            {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                {this.state.error_msg.text
                                }
                            </p> : null
                            }
                        </Form.Group>
                        <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', width: '200px', alignText: 'center' }}>Characters Remaining:{this.state.word_count}</div>
                    </div>
                </div>
            </div>
        )
    }
}

class NCPDP_ extends React.Component {
    constructor(props) {
        super(props);
        this.total_characters = 4000;
        this.state = {
            ncpdp_code: '',
            begin_date: null,
            text: '',
            word_count: this.total_characters,
            errorObj: {
                ncpdp_code: false,
                begin_date: false,
                text: false,
            },
            error_msg: {
                ncpdp_code: '',
                begin_date: '',
                text: '',
            }
        }
    }
    setErrObject() {
        var errorObj = this.state.errorObj;
        errorObj.ncpdp_code = false;
        errorObj.begin_date = false;
        errorObj.termination_date = false;
        errorObj.text = false;
        this.setState({ errorObj: errorObj });
    }
    searchCheck = () => {

        let errorMessagesArray = [];
        var errorObj = this.state.errorObj
        var error_msg = this.state.error_msg;
        if ((this.state.ncpdp_code && !this.state.ncpdp_code.trim()) || !this.state.ncpdp_code) {
            errorObj.ncpdp_code = true;
            error_msg.ncpdp_code = "NCPDP Reject Code" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.ncpdp_code);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if (!this.state.begin_date) {
            errorObj.begin_date = true;
            error_msg.begin_date = "Begin Date" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        else if (this.state.begin_date.toString() == 'Invalid Date') {
            errorObj.begin_date = true;
            error_msg.begin_date = TextManagementErrors.Invalid_Format_Error_BeginDate;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })

        }
        else if (DateUtils.validateDateMinimumValue(this.state.begin_date)) {
            errorObj.begin_date = true;
            error_msg.begin_date = AppConstants.DATE_ERROR_1964;
            errorMessagesArray.push(error_msg.begin_date);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        if ((this.state.text && !this.state.text.trim()) || !this.state.text) {
            errorObj.text = true;
            error_msg.text = "Text" + TextManagementErrors.Required_Field_Error;
            errorMessagesArray.push(error_msg.text);
            this.setState({ errorObj: errorObj, error_msg: error_msg }, () => {
            })
        }
        return errorMessagesArray;
    }
    onSave = e => {
        this.props.dispatch(SetSpinner(true));
        this.props.dispatch(ResetTextSearchReducer());
        return {
            "auditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "auditTimeStamp": DateUtils.getUTCTimeStamp(),
            "addedAuditUserID": this.props.logInUserID ? this.props.logInUserID : null,
            "addedAuditTimeStamp": DateUtils.getUTCTimeStamp(),
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "auditKeyList": [],
            "auditKeyListFiltered": false,
            "ncpdpRejectCode": this.state.ncpdp_code,
            "beginDate": moment(this.state.begin_date).format('MM/DD/YYYY'),
            "terminationDate": "12/31/9999",
            "claimException": null,
            "ncpdpRejectCodeText": this.state.text
        }
    }
    checkWordCount = e => {
        let value = e.target.value;
        value = value.split(' ').join(' ')
        this.setState({ word_count: this.total_characters - value.length });
    }
    handleField = e => {
        this.props.setAllowNavigation();
        let value = e.target.value;
        let name = e.target.name;
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj[name] = false;
        if (name == 'ncpdp_code')
            this.setState({ [name]: value.toUpperCase(), errorObj: errorObj });
        else
            this.setState({ [name]: value, errorObj: errorObj });
    }
    handleDate = e => {
        this.props.setAllowNavigation();
        let errorObj = this.state.errorObj;
        // this.props.setErrorNull();
        errorObj.begin_date = false;
        this.setState({ begin_date: e, errorObj: errorObj })
    }
    render() {
        return (
            <div style={{ display: 'flex', flexDirection: 'column', justifyContent: 'space-evenly', width: '100%' }}>
                <div className="row">
                    <div style={{ display: 'flex', flexDirection: 'row', justifyContent: 'flex-start', width: '100%' }}>

                        <div className="mui-custom-form input-md">
                            <TextField
                                id="ncpdp_code"
                                fullWidth
                                label="NCPDP Reject Code"
                                name='ncpdp_code'
                                value={this.state.ncpdp_code}
                                onChange={this.handleField}
                                required
                                InputLabelProps={{
                                    shrink: true
                                }}
                                inputProps={{
                                    maxLength: 3
                                }}
                                helperText={this.state.errorObj.ncpdp_code ? this.state.error_msg.ncpdp_code : null}
                                error={this.state.errorObj.ncpdp_code ? this.state.error_msg.ncpdp_code : null}
                            />
                        </div>
                        <div className="mui-custom-form with-date">
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                <KeyboardDatePicker
                                    maxDate={Date.parse('31 Dec 9999 00:00:00 GMT')}
                                    formnovalidate
                                    id="begin_date"
                                    label="Begin Date"
                                    format="MM/dd/yyyy"
                                    placeholder='mm/dd/yyyy'
                                    InputLabelProps={{
                                        shrink: true
                                    }}
                                    name='begin_date'
                                    value={this.state.begin_date}
                                    onChange={this.handleDate}
                                    required
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                    helperText={this.state.errorObj.begin_date ? this.state.error_msg.begin_date : null}
                                    error={this.state.errorObj.begin_date ? this.state.error_msg.begin_date : null}

                                />
                            </MuiPickersUtilsProvider>
                        </div>
                    </div>

                    <div className="mui-custom-form with-textarea override-width-95">
                        <Form.Group>
                            <Form.Label for="ncpdp-text" className='MuiFormLabel-root small-label'>Text <span>*</span></Form.Label>
                           <Form.Control id="ncpdp-text" as="textarea" onChange={this.handleField} name='text' value={this.state.text} onChange={this.handleField} name='text' rows="4" maxLength={this.total_characters} onKeyUp={this.checkWordCount} />
                            {this.state.errorObj.text > 0 ? <p class="MuiFormHelperText-root Mui-error Mui-required" role="alert" >
                                {this.state.error_msg.text
                                }
                            </p> : null
                            }
                        </Form.Group>
                        <div style={{ border: '1px solid rgb(169, 169, 169)', borderRadius: '.25rem', paddingLeft: '5px', width: '200px', alignText: 'center' }}>Characters Remaining:{this.state.word_count}</div>
                    </div>
                </div>
            </div>
        )
    }
}

export const NCPDP = connect(mapStateToProps, null, null, { forwardRef: true })(NCPDP_);
export const AdjustmentReason = connect(mapStateToProps, null, null, { forwardRef: true })(AdjustmentReason_);
export const RemarkCode = connect(mapStateToProps, null, null, { forwardRef: true })(RemarkCode_);
export const RAEOB = connect(mapStateToProps, null, null, { forwardRef: true })(RAEOB_);
export const ProviderNotice = connect(mapStateToProps, null, null, { forwardRef: true })(ProviderNotice_);
export const EOMB = connect(mapStateToProps, null, null, { forwardRef: true })(EOMB_);
export default withRouter(connect(mapStateToProps, null)(TextAddUpdate));
