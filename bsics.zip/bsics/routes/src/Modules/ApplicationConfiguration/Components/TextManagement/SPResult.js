/* eslint-disable no-unused-vars */

import React from 'react';

import { withRouter } from 'react-router';

import TableComponent from '../../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import { systemParameterRowClickAction } from '../../Store/Actions/TextManagement/TextManagementActions';


const headCells = [
  { id: 'lobCode', disablePadding: false, label: 'LOB', enableHyperLink: true },
  { id: 'eombFromCode', disablePadding: false, label: 'From Code', isVarchar: true },
  { id: 'eombThruCode', disablePadding: false, label: 'Thru Code', isVarchar: true },
  { id: 'eombDesc', disablePadding: false, label: 'Text', isText: true }
];

function SPResult (props) {
  const [redirect, setRedirect] = React.useState(false);

  const dispatch = useDispatch();
  const onRowClick = values => dispatch(systemParameterRowClickAction(values));
  const payloadData = useSelector(state => state.appConfigState.systemParameterState.rowSearchSysParam);
  if (redirect === 1) {
    if (payloadData != null) {
      if (payloadData.length === 1) {
        console.log(payloadData);
        props.history.push({
          pathname: '/TextUpdate',
          state: { row: payloadData, TextType: 'EOMB', EombType: 'surgical-procedure' }
        });
      }
    }
  }

  const editRow = row => event => {
    const searchCriteria = {
      eombProcedureTypeCode: 'I',
      lobCode: [row.lobCode],
      eombFromCode: row.eombFromCode,
      eombthruCode: row.eombTromCode,
      eombText: row.eombDesc
    };
    onRowClick(searchCriteria);
    let valuetoredirect = 0;
    valuetoredirect = valuetoredirect + 1;
    setRedirect(valuetoredirect);
  };

  return (
    <TableComponent isSearch={true} headCells={headCells} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={headCells[0].id} />
  );
}
export default withRouter((SPResult));
