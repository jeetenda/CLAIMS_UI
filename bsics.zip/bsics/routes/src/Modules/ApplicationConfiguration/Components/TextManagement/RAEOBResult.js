/* eslint-disable no-unused-vars */

import React, { useEffect } from 'react';
import { withRouter } from 'react-router';

import { useDispatch, useSelector } from 'react-redux';
import { RAEOBRowClickAction } from '../../Store/Actions/TextManagement/TextManagementActions';
import TableComponent from '../../../../SharedModules/Table/Table';


const headCells = [
  { id: 'lobCode', disablePadding: false, label: 'LOB', width: '20%', enableHyperLink: true },
  { id: 'claimEOBCode', disablePadding: false, label: 'EOB Code', width: '20%', isVarchar: true },
  { id: 'eobDesc', disablePadding: false, label: 'EOB Text', width: '60%', isText: true }
];

function RAEOBTable (props) {
  console.log('RAEOBTable');
  console.log(props);
  const [redirect, setRedirect] = React.useState(false);

  // API CAll
  const dispatch = useDispatch();
  const onRowClick = values => dispatch(RAEOBRowClickAction(values));
  const payloadData = useSelector(state => state.appConfigState.textManagementState.payload);
  if (redirect === 1) {
    if (payloadData != null) {
      if (payloadData.length === 1) {
        console.log('payloadData in js');
        console.log('payloadData');

        props.history.push({
          pathname: '/TextUpdate',
          state: { row: payloadData[0], TextType: 'RA EOB' }
        });
      }
    }
  }

  // Spinner Functionality
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (payloadData != null) {
      setspinnerLoader(false);
    }
  }, [payloadData]);
  // Spinner Functionality
  // useEffect(() => {
  //   props.tableData.map((data,index) => {
  //     //console.log('tableData');
  //     //console.log(data);
  //     data.eobDesc =data.eobDesc.toString().slice(0,30);
  //   });
  // },[props.tableData]);
  const editRow = row => event => {
    const searchCriteria = {
      lobCode: [row.lobCode],
      claimEOBCode: row.claimEOBCode,
      eobDesc: row.eobDesc
    };
    onRowClick(searchCriteria);
    setspinnerLoader(true);
    let valuetoredirect = 0;
    valuetoredirect = valuetoredirect + 1;
    setRedirect(valuetoredirect);
  };

  const tableComp = <TableComponent  isSearch={true}  fixedTable  headCells={headCells} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={headCells[0].id} />;
  return (
    tableComp

  );
}
export default withRouter((RAEOBTable));
