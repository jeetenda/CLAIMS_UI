/* eslint-disable no-unused-vars */

import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import { NCPDPRowClickAction } from '../../Store/Actions/TextManagement/TextManagementActions';
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import TableComponent from '../../../../SharedModules/Table/Table';


const headCells = [
  { id: 'ncpdpRejectCode', disablePadding: false, label: 'NCPDP Reject Code', width: 180, enableHyperLink: true, isVarchar: true },
  { id: 'ncpdpRejectCodeText', disablePadding: false, label: 'Text', isText: true }
];

function ProviderNoticeTable (props) {
  const [redirect, setRedirect] = React.useState(false);

  const dispatch = useDispatch();
  const onRowClick = values => dispatch(NCPDPRowClickAction(values));
  const payloadData = useSelector(state => state.appConfigState.textManagementState.payload);
  if (redirect === 1) {
    if (payloadData != null) {
      if (payloadData.length === 1) {
        props.history.push({
          pathname: '/TextUpdate',
          state: { row: payloadData[0], TextType: 'NCPDP Rejection Codes' }
        });
      }
    }
  }

  // Spinner Functionality
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (payloadData != null) {
      setspinnerLoader(false);
    }
  }, [payloadData]);
  // Spinner Functionality

  const editRow = row => event => {
    const searchCriteria = {
      ncpdpRejectCode: row.ncpdpRejectCode ? row.ncpdpRejectCode : null,
      ncpdpRejectCodeText: row.ncpdpRejectCodeText ? row.ncpdpRejectCodeText : null,
      ncpdpRejectCodeStartsOrCopntains: null
    };
    onRowClick(searchCriteria);
    setspinnerLoader(true);
    let valuetoredirect = 0;
    valuetoredirect = valuetoredirect + 1;
    setRedirect(valuetoredirect);
  };

  const tableComp = <TableComponent isSearch={true} headCells={headCells} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={headCells[0].id} />;
  return (
    tableComp
  );
}
export default withRouter((ProviderNoticeTable));
