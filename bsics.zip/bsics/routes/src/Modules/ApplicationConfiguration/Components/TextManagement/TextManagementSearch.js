/* eslint-disable no-unused-vars */
import React, { useEffect, useRef } from "react";
import MenuItem from "@material-ui/core/MenuItem";
import SuccessMessages from "../../../../SharedModules/Errors/TimeOutSuccessMsg";
import TextField from "@material-ui/core/TextField";
import { Button } from "react-bootstrap";
import Tabs from "@material-ui/core/Tabs";
import Tab from "@material-ui/core/Tab";
import AppBar from "@material-ui/core/AppBar";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import ProviderNotice from "./ProviderNotice";
import RAEOBResult from "./RAEOBResult";
import AdjustmentReason from "./AdjustmentReason";
import Spinner from "../../../../SharedModules/Spinner/Spinner";
import SAR from "./SAR";
import RemarkCode from "./RemarkCode";
import "./TextManagementSearch.css";
import EnhancedTableHead from "./HCPCS";
import Checkbox from "@material-ui/core/Checkbox";
import EnhancedTableHead1 from "./SPResult";
import EnhancedTableHead2 from "./RevenueResult";
import { withRouter } from "react-router";
import ServiceAuthSearch from "../../../../Modules/TextManagementServiceAuth/components/ServiceAuthSearch";

import TextManagementLocationTab from "../../../TextManagementLocation/Component/TextManagementLocationTab";
import ReactToPrint from "react-to-print";
import { setPrintLayout } from "../../../../SharedModules/Store/Actions/SharedAction";
import Footer from "../../../../SharedModules/Layout/footer";
import {
  generateUUID,
  getDateInMMDDYYYYFormat,
  getUTCTimeStamp,
} from "../../../../SharedModules/DateUtilities/DateUtilities";
import * as ErrorConstants from "./ErrorCheck";
import * as APP_CONSTANTS from "../../../../SharedModules/AppConstants";
import {
  searchSystemParameterAction,
  searchSystemParameterActionRAEOB,
  ResetTextSearchReducer,
  searchSystemParameterActionPN,
  searchSystemParameterActionSP,
  searchSystemParameterActionRevenue,
  searchSystemParameterActionRC,
  searchSystemParameterActionARC,
  searchSystemParameterActionNCPDP,
  resetSearchTextManagement,
  ProviderSpecialtyDataSearchAction,
} from "../../Store/Actions/TextManagement/TextManagementActions";
import { ResetData } from "../../Store/Actions/TextManagement/TextManagementAddUpdateActions";
import {
  AppConfigDropdownActions,
  ModifierDropdownActions,
} from "../../Store/Actions/AppConfigCommon/AppConfigActions";
import { useDispatch, useSelector } from "react-redux";
import TabPanel from "../../../../SharedModules/TabPanel/TabPanel";
import dropdownCriteria from "./TextManagementSearch.json";
import { makeStyles } from "@material-ui/core/styles";
import Radio from "@material-ui/core/Radio";

const useStyles = makeStyles({
  tab100: {
    minWidth: 100,
    padding: "6px 6px",
  },
});

function TextManagementSearch(props) {
  const printLayout = useSelector((state) => state.sharedState.printLayout);
  const toPrintRef = useRef();
  const classes = useStyles();
  const dispatch = useDispatch();
  const dropDownDispatch = (dropdownvalues) =>
    dispatch(AppConfigDropdownActions(dropdownvalues));
  const modifierDropDownDispatch = () => dispatch(ModifierDropdownActions());
  const [SuccessMessage, setSuccessMessage] = React.useState([]);
  const [NCPDPValues, setNCPDPValues] = React.useState({
    NCPDPRejectCode: "",
    NCPDPRejectCodeText: "",
  });

  const onReset = () => dispatch(resetSearchTextManagement());

  useEffect(() => {
    onReset();
    dropDownDispatch(dropdownCriteria);
    modifierDropDownDispatch();
    if (props.location.state && props.location.state.message) {
      setSuccessMessage([props.location.state.message]);
    }

    if (props.location.search) {
      let params = props.location.search.split("?")[1].split("=");
      if (params[0] == "remarkCode") {
        setValue(3);
        setrCValues({ remarkCode: params[1], remarkText: "", RCRadio: "" });
        searchCheckRC({ remarkCode: params[1], remarkText: "", RCRadio: "" });
      }
      if (params[0] == "adjustmentReason") {
        setValue(4);
        setARCValues({
          adjustmentRC: params[1],
          adjustmentRT: "",
          ARCRadio: "",
        });
        searchCheckARC({
          adjustmentRC: params[1],
          adjustmentRT: "",
          ARCRadio: "",
        });
      }
      if (params[0] == "raEob") {
        setValue(1);
        setEOBValues({ eobCode: params[1], eobText: "" });
        setValuesRAEOB({ RAEob: "MED" });
        onSearchRAEOB({
          lobCode: ["MED"],
          claimEOBCode: params[1],
          eobText: "",
          eobTextStartsOrContains: "",
        });
      }
    }
  }, []);

  useEffect(() => {
    dispatch(ResetData());
  }, [props]);

  const [redirect, setRedirect] = React.useState(0);
  const [isEOMB_TextOnlyOneCharecter, manageEOMB_Text] = React.useState(false);
  const [functionalAreaData, setFunctionalAreaData] = React.useState([]);
  const [lobCodeData, setLobCodeData] = React.useState([]);
  const [providerSpecialityData, setproviderSpecialityData] = React.useState(
    []
  );
  const [providerType, setproviderType] = React.useState([]);
  const [modifierData, setModifierData] = React.useState([]);
  const [redirectPN, setRedirectPN] = React.useState(0);
  const [redirectNCPDP, setRedirectNCPDP] = React.useState(0);
  const [redirectAR, setRedirectAR] = React.useState(0);
  const [redirectRC, setRedirectRC] = React.useState(0);
  const [redirectRAEOB, setRedirectRAEOB] = React.useState(0);
  const [displayTable, setDisplayTable] = React.useState([]);
  const [newModifierDropDown, setnewModifierDropDown] = React.useState([]);
  const onSearch = (values) => dispatch(searchSystemParameterAction(values));
  const onSearchRAEOB = (values) =>
    dispatch(searchSystemParameterActionRAEOB(values));
  const onSearchPN = (values) =>
    dispatch(searchSystemParameterActionPN(values));
  const onSearchSP = (values) =>
    dispatch(searchSystemParameterActionSP(values));
  const onSearchRC = (values) =>
    dispatch(searchSystemParameterActionRC(values));
  const onSearchARC = (values) =>
    dispatch(searchSystemParameterActionARC(values));
  const onSearchRevenue = (values) =>
    dispatch(searchSystemParameterActionRevenue(values));
  const onSearchNCPDP = (values) =>
    dispatch(searchSystemParameterActionNCPDP(values));

  const payload = useSelector(
    (state) => state.appConfigState.textManagementState.payload
  );
  const payloadlocation = useSelector(
    (state) => state.TextManagementLocation.searchResultslocation
  );
  const dropdown = useSelector(
    (state) => state.appConfigState.AppConfigCommonState.appConfigDropdown
  );
  const modifierdropdown = useSelector(
    (state) => state.appConfigState.AppConfigCommonState.modifierDropdown
  );
  const modifierDropdownsFromState = useSelector((state) => state);
  const payloads = useSelector(
    (state) => state.appConfigState.textManagementState.searchResults
  );

  const providerTypeDesc = (data) => {
    const filteredValue = providerType.filter(
      (prv, index) => prv.code === data
    );
    if (filteredValue && filteredValue.length > 0) {
      return filteredValue[0].description;
    }
    return data;
  };

  const providerSpecialityDesc = (data) => {
    if (providerSpecialityData) {
      const filteredValue = providerSpecialityData.filter(
        (prv, index) => prv.code === data
      );
      if (filteredValue && filteredValue.length > 0) {
        return filteredValue[0].description;
      }
    }
    return data;
  };
  React.useEffect(() => {
    if (
      typeof modifierDropdownsFromState.appConfigState.AppConfigCommonState
        .appConfigDropdown !== "undefined"
    ) {
      if (
        typeof modifierDropdownsFromState.appConfigState.AppConfigCommonState
          .appConfigDropdown.listObj !== "undefined"
      ) {
        const appConfigDropdown =
          modifierDropdownsFromState.appConfigState.AppConfigCommonState
            .appConfigDropdown.listObj["Provider#1054"];
        setnewModifierDropDown(appConfigDropdown);
      }
    }
  });

  React.useEffect(() => {
    if (
      payload &&
      payload != null &&
      payload.respcode === undefined &&
      !payload.systemError &&
      !payload.name
    ) {
      payload.map((data, index) => {
        if (data.providerType !== "") {
          data.providerTypeDesc = providerTypeDesc(data.providerType);
        }
        if (data.providerSpeciality !== "") {
          data.providerSpecialityDesc = providerSpecialityDesc(
            data.providerSpeciality
          );
        }
      });
    }
  }, [payload]);

  const payloadData = payload ? payload[0] : {};

  if (redirect === 1) {
    if (payload != null) {
      if (payload.length === 1) {
        props.history.push({
          pathname: "/TextUpdate",
          state: { row: payloadData, TextType: "EOMB", EombType: "hcpcs" },
        });
      }
    }
  }

  if (redirectPN === 1) {
    if (payload != null) {
      if (payload.length === 1) {
        props.history.push({
          pathname: "/TextUpdate",
          state: { row: payloadData, TextType: "Provider Notice" },
        });
      }
    }
  }

  if (redirectNCPDP === 1) {
    if (payload != null) {
      if (payload.length === 1) {
        props.history.push({
          pathname: "/TextUpdate",
          state: { row: payloadData, TextType: "NCPDP Rejection Codes" },
        });
      }
    }
  }

  if (redirectAR === 1) {
    if (payload != null) {
      if (payload.length === 1) {
        props.history.push({
          pathname: "/TextUpdate",
          state: { row: payloadData, TextType: "Adjustment Reason" },
        });
      }
    }
  }

  if (redirectRAEOB === 1) {
    if (payload != null) {
      if (payload.length === 1) {
        props.history.push({
          pathname: "/TextUpdate",
          state: { row: payloadData, TextType: "RA EOB" },
        });
      }
    }
  }

  if (redirectRC === 1) {
    if (payload && payload != null) {
      if (payload.length === 1) {
        props.history.push({
          pathname: "/TextUpdate",
          state: { row: payload[0], TextType: "Remark Code" },
        });
      }
    }
  }

  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (payloads && payloads.recordCount === 0) {
      setspinnerLoader(false);
      errorMessagesArray.push(validvaluecons.NO_RECORD_FOUND);
      seterrorMessages(errorMessagesArray);
    }
  }, [payloads]);

  useEffect(() => {
    if (payload != null && (payload.length > 0 || payload.length === 0)) {
      setspinnerLoader(false);
      setDisplayTable(payload);
    }

    if (payload != null && payload.length === 0) {
      setspinnerLoader(false);
      errorMessagesArray.push(validvaluecons.NO_RECORD_FOUND);
      seterrorMessages(errorMessagesArray);
      setShowHCPCS(false);
      setShowRevenue(false);
      setShowSP(false);
      setShowPN(false);
    }
    if (payload && payload !== null && payload.systemError) {
      setspinnerLoader(false);
      errorMessagesArray.push(APP_CONSTANTS.ERR_PROCESSING_REQ);
      seterrorMessages(errorMessagesArray);
      setShowHCPCS(false);
      setShowRevenue(false);
      setShowSP(false);
      setShowPN(false);
    }
  }, [payload]);

  useEffect(() => {
    onReset();
  }, []);

  useEffect(() => {
    if (dropdown && dropdown.listObj) {
      if (dropdown.listObj["Reference#1019"]) {
        setLobCodeData(dropdown.listObj["Reference#1019"]);
      }
      if (dropdown.listObj["Provider#11"]) {
        setproviderType(dropdown.listObj["Provider#11"]);
      }
      if (dropdown.listObj["Provider#1054"]) {
        setproviderSpecialityData(dropdown.listObj["Provider#1054"]);
      }
    }
  }, [dropdown]);

  useEffect(() => {
    if (modifierdropdown && modifierdropdown.modifierList) {
      setModifierData(modifierdropdown.modifierList);
    }
  }, [modifierdropdown]);

  const [showForm, setShowForm] = React.useState(false);
  const [showRAEOB, setShowRAEOB] = React.useState(false);
  const [showPN, setShowPN] = React.useState(false);

  const [showPC, setShowPC] = React.useState(false);

  const [showAR, setShowAR] = React.useState(false);

  const [showSAR, setShowSAR] = React.useState(false);

  const [showSP, setShowSP] = React.useState(false);

  const [showRevenue, setShowRevenue] = React.useState(false);

  const [fromMod, setFromMod] = React.useState(true);

  const [thruMod, setThruMod] = React.useState(true);

  const [providerSpeciality, setProviderSpeciality] = React.useState(true);

  const [showHCPCS, setShowHCPCS] = React.useState(false);

  const [showVoid, setShowVoid] = React.useState(false);

  const [tableData, setTableData] = React.useState([]);

  const [id, setId] = React.useState(0);

  const [inputValues, setInputValues] = React.useState({
    code: "",

    shortDescription: "",

    longDescription: "",

    constantText: "",
  });

  const [eobValues, setEOBValues] = React.useState({
    eobCode: "",

    eobText: "",

    eobRadio: "",
  });

  // Code to set Provider Notice fields to default

  const [pNValues, setpNValues] = React.useState({
    lobPN: "Please Select One",

    providertypeEOB: "Please Select One",

    providerspecialityEOB: "Please Select One",

    noticetextEOB: "",

    radioNTEOB: "",

    showVoids: false,

    PNRadio: "",
  });

  // Code to set Remark Code fields to default

  const [rCValues, setrCValues] = React.useState({
    remarkCode: "",

    remarkText: "",

    RCRadio: "",
  });

  // Code to set Adjustment Reason fields to default

  const [ARCValues, setARCValues] = React.useState({
    adjustmentRC: "",

    adjustmentRT: "",

    ARCRadio: "",
  });

  const [locationValues, setLocationValues] = React.useState({
    locationCode: "",

    locationText: "",

    locationTextStartsOrContains: "",
  });
  const [serviceAuthvalues, setserviceAuthvalues] = React.useState({
    authorizationReasonCode: "",
    authorizationReasonText: "",
    authorizationReasonTextStartsOrContains: "",
  });

  const [valueslobPN, setvalueslobPN] = React.useState({
    lobPN: "Please Select One",
  });

  // Code to set HCPCS fields to default

  const [HCPCSValues, setHCPCSValues] = React.useState({
    HCPCSfromcode: "",

    HCPCSmodifier1: "Please Select One",

    HCPCSmodifier2: "Please Select One",

    HCPCSmodifier3: "Please Select One",

    HCPCSmodifier4: "Please Select One",

    HCPCSthrucode: "",

    HCPCSmodifier11: "Please Select One",

    HCPCSmodifier21: "Please Select One",

    HCPCSmodifier31: "Please Select One",

    HCPCSmodifier41: "Please Select One",

    HCPCSEOBCode: "",

    HCPCSRadio: "",

    SPRadio: "",

    RevenueRadio: "",

    lobEOMB: "Please Select One",
  });

  // Code to set Surgical Procedure fields to default

  const [SPValues, setSPValues] = React.useState({
    SPfromcode: "",

    SPthrucode: "",

    SPEOMBText: "",
  });

  // Code to set Revenue fields to default

  const [revenueValues, setRevenueValues] = React.useState({
    revenuefromcode: "",

    revenuethrucode: "",

    revenueEOMBText: "",
  });

  const [values, setValues] = React.useState({
    lob: "",

    payee: "",

    payeeIdCode: "",

    id: "",

    name: "",

    systemPayeeId: "",

    multiline: "Controlled",

    systemPayee: "",

    memberName: "",

    lobEOMB: "Please Select One",

    lobEob: "Please Select One",

    lobPN: "Please Select One",
  });

  const [valuesPN1, setValuesPN1] = React.useState({
    providertypeEOB: "Please Select One",
  });

  const [valueslobEOMB, setValueslobEOMB] = React.useState({
    lobEOMB: "Please Select One",
  });

  const [valuesRAEOB, setValuesRAEOB] = React.useState({
    RAEob: "Please Select One",
  });

  const [valuesPN2, setValuesPN2] = React.useState({
    providerspecialityEOB: "Please Select One",
  });

  const [value, setValue] = React.useState(0);

  const [open, setOpen] = React.useState(false);

  const [eombType, setEombType] = React.useState("HCPCS");

  const [dataElement, setDataElement] = React.useState({
    id: 0,

    dataElementName: "",

    businessName: "",

    description: "",
  });

  const handleChanges = name => event => {
    manageEOMB_Text(false);

    setEombType(event.target.value);

    setValues({ ...values, [name]: event.target.value });

    setHCPCSValues({
      HCPCSfromcode: "",

      HCPCSmodifier1: "Please Select One",

      HCPCSmodifier2: "Please Select One",

      HCPCSmodifier3: "Please Select One",

      HCPCSmodifier4: "Please Select One",

      HCPCSthrucode: "",

      HCPCSmodifier11: "Please Select One",

      HCPCSmodifier21: "Please Select One",

      HCPCSmodifier31: "Please Select One",

      HCPCSmodifier41: "Please Select One",

      HCPCSEOBCode: "",

      lobEOMB: "Please Select One",
    });

    setShowHCPCS(false);

    setShowSP(false);

    setValueslobEOMB({
      lobEOMB: "Please Select One",
    });

    setShowError({
      showHCPCSError: false,

      showHCPCSthruError: false,

      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    seterrorMessages([]);

    setRevenueValues({
      revenuefromcode: "",

      revenuethrucode: "",

      revenueEOMBText: "",
    });

    setShowRevenue(false);

    setSPValues({
      SPfromcode: "",

      SPthrucode: "",

      SPEOMBText: "",
    });

    setShowSP(false);
  };

  let errorMessagesArray = [];

  React.useEffect(() => {
    if (HCPCSValues.lobEOMB !== "Please Select One") {
      setShowError({ showHCPCSError: false });

      seterrorMessages([]);
    }
  }, [HCPCSValues.lobEOMB]);

  const handleChangesEOMB = (name) => (event) => {
    setHCPCSValues({ ...HCPCSValues, [name]: event.target.value });
  };

  const searchProviderSpecialty = (values) =>
    dispatch(ProviderSpecialtyDataSearchAction(values));

  const ProviderSpecialtyData = useSelector(
    (state) => state.appConfigState.providerSpecialtyState.ProviderSpecialtyData
  );

  const handleChangesPN1 = (name) => (event) => {
    searchProviderSpecialty(event.target.value);

    setValuesPN2({ providerspecialityEOB: "Please Select One" });

    setValuesPN1({ [name]: event.target.value });
  };

  const handleChangeslobPN = (name) => (event) => {
    setvalueslobPN({ [name]: event.target.value });
  };

  const handleChangesPN2 = (name) => (event) => {
    setValuesPN2({ [name]: event.target.value });
  };

  const handleChangeTabs = (event, newValue) => {
    resetTableRAEOB();

    resetTableRC();

    resetTableARC();

    resetTableNCPDP();

    resetTableSP();

    resetTableRevenue();

    resetTablePN();

    resetTable();

    setValue(newValue);

    resetTableHCPCS();
    setLocationValues({
      locationCode: "",

      locationText: "",

      locationTextStartsOrContains: "",
    });
    setserviceAuthvalues({
      authorizationReasonCode: "",
      authorizationReasonText: "",
      authorizationReasonTextStartsOrContains: "",
    });
  };

  const handleChangeREOB = (name) => (event) => {
    setEOBValues({ ...eobValues, [name]: event.target.value });
  };

  const handleShowVoidsChange = (event) => {
    setpNValues({ ...pNValues, showVoids: !pNValues.showVoids });
  };

  const handleChangePN = (name) => (event) => {
    setpNValues({ ...pNValues, [name]: event.target.value });
  };

  const handleChangeRC = (name) => (event) => {
    setrCValues({ ...rCValues, [name]: event.target.value });
  };

  const handleChangeARC = (name) => (event) => {
    setARCValues({ ...ARCValues, [name]: event.target.value });
  };

  const handleChangeNCPDP = (name) => (event) => {
    setNCPDPValues({ ...NCPDPValues, [name]: event.target.value });
  };

  React.useEffect(() => {
    if (HCPCSValues.HCPCSfromcode) {
      setFromMod(false);
    } else {
      setFromMod(true);
    }

    if (HCPCSValues.HCPCSthrucode) {
      setThruMod(false);
    } else {
      setThruMod(true);
    }
  }, [HCPCSValues.HCPCSfromcode, HCPCSValues.HCPCSthrucode, fromMod, thruMod]);

  React.useEffect(() => {
    if (valuesPN1.providertypeEOB !== "Please Select One") {
      setProviderSpeciality(false);
    } else {
      setProviderSpeciality(true);
    }
  }, [valuesPN1.providertypeEOB, providerSpeciality]);

  const handleChangeHCPCS = (name) => (event) => {
    setHCPCSValues({ ...HCPCSValues, [name]: event.target.value });

    if (
      HCPCSValues.selectedHCPCSOption &&
      HCPCSValues.HCPCSEOBCode.length >= 1
    ) {
      setShowError({ showCommonError: false });

      seterrorMessages(errorMessagesArray);
    }
  };

  const handleChangesRAEOB = (name) => (event) => {
    setValuesRAEOB({ [name]: event.target.value });
  };

  const handleChangeRevenue = (name) => (event) => {
    setRevenueValues({ ...revenueValues, [name]: event.target.value });
  };

  const handleChangeSP = (name) => (event) => {
    setSPValues({ ...SPValues, [name]: event.target.value });
  };

  // Code to reset RA EOB fields

  const resetTableRAEOB = () => {
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setEOBValues({
      eobCode: "",

      eobText: "",
    });

    setShowRAEOB(false);

    setValuesRAEOB({
      RAEob: "Please Select One",
    });

    setShowError({ showRAEOBError: false });
  };

  // Code to reset Remark Code fields

  const resetTableRC = () => {
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setrCValues({
      remarkCode: "",

      remarkText: "",
    });

    setShowPC(false);

    setShowError({ showbusinessNameError: false });
  };

  // Code to reset Adjustemtn Reason fields

  const resetTableARC = () => {
    console.log("resetTableARC");
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setARCValues({
      adjustmentRC: "",

      adjustmentRT: "",
    });

    setShowAR(false);

    setShowError({ showdataElementNameError: false });
  };

  // Code to reset NCPDP fields

  const resetTableNCPDP = () => {
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setNCPDPValues({
      NCPDPRejectCode: "",

      NCPDPRejectCodeText: "",

      NCPDPRadio: "",
    });

    setShowSAR(false);

    setShowError({ showFunctionalAreaError: false });
  };

  // Code to reset HCPCS fields

  const resetTableHCPCS = () => {
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setHCPCSValues({
      HCPCSfromcode: "",

      HCPCSmodifier1: "Please Select One",

      HCPCSmodifier2: "Please Select One",

      HCPCSmodifier3: "Please Select One",

      HCPCSmodifier4: "Please Select One",

      HCPCSthrucode: "",

      HCPCSmodifier11: "Please Select One",

      HCPCSmodifier21: "Please Select One",

      HCPCSmodifier31: "Please Select One",

      HCPCSmodifier41: "Please Select One",

      HCPCSEOBCode: "",

      lobEOMB: "Please Select One",
    });

    setShowHCPCS(false);

    setValueslobEOMB({
      lobEOMB: "Please Select One",
    });

    setShowError({ showHCPCSError: false, showHCPCSthruError: false });
  };

  // Code to reset Surgical Procedure fields

  const resetTableSP = () => {
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setSPValues({
      SPfromcode: "",

      SPthrucode: "",

      SPEOMBText: "",
    });

    setShowSP(false);

    setHCPCSValues({
      lobEOMB: "Please Select One",

      HCPCSEOBCode: "",
    });

    setShowError({ showSPError: false });
  };

  // Code to reset Revenue fields

  const resetTableRevenue = () => {
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setRevenueValues({
      revenuefromcode: "",

      revenuethrucode: "",

      revenueEOMBText: "",
    });

    setShowRevenue(false);

    setHCPCSValues({
      lobEOMB: "Please Select One",

      HCPCSEOBCode: "",
    });

    setShowError({ showRevenueError: false });
  };

  // Code to reset Provider Notice fields

  const resetTablePN = () => {
    seterrorMessages([]);

    setDisplayTable([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setpNValues({
      lobPN: "Please Select One",

      providertypeEOB: "",

      providerspecialityEOB: "",

      noticetextEOB: "",

      radioNTEOB: "",

      showVoids: false,
    });

    setShowVoid(false);

    setShowPN(false);

    setValues({
      lobPN: "Please Select One",
    });

    setValuesPN1({
      providertypeEOB: "Please Select One",
    });

    setValuesPN2({
      providerspecialityEOB: "Please Select One",
    });

    setvalueslobPN({
      lobPN: "Please Select One",
    });

    setShowError({ showPNError: false });
  };

  const resetTable = () => {
    seterrorMessages([]);

    setShowError({
      showFunctionalAreaError: false,

      showdataElementNameError: false,

      showbusinessNameError: false,

      showPNError: false,

      showRAEOBError: false,

      showHCPCSError: false,

      showHCPCSthruError: false,

      showSPError: false,

      showRevenueError: false,

      showCommonError: false,
    });

    setValues({
      lob: "",

      payee: "",

      payeeIdCode: "",

      id: "",

      name: "",

      systemPayeeId: "",

      multiline: "Controlled",

      systemPayee: "",

      memberName: "",
    });

    setShowForm(false);
  };

  const validvaluecons = ErrorConstants;

  const [errorMessages, seterrorMessages] = React.useState([]);

  const [
    {
      showFunctionalAreaError,
      showdataElementNameError,
      showbusinessNameError,

      showPNError,
      showRAEOBError,
      showHCPCSError,
      showHCPCSthruError,
      showSPError,

      showRevenueError,
      showCommonError,
    },
    setShowError,
  ] = React.useState(false);

  const searchCheckNCPDP = (NCPDPValues) => {
    errorMessagesArray = [];
    setSuccessMessage([]);
    seterrorMessages([]);

    var showCommonError;
    var showFunctionalAreaError = false;

    if (
      NCPDPValues.selectedNCPDPOption &&
      (!NCPDPValues.NCPDPRejectCodeText ||
        NCPDPValues.NCPDPRejectCodeText.trim().length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowSAR(false);
    }

    if (!NCPDPValues.NCPDPRejectCode && !NCPDPValues.NCPDPRejectCodeText) {
      showFunctionalAreaError = true;

      errorMessagesArray.push(validvaluecons.DATA_ELEMENT_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowSAR(false);
    }

    if (errorMessagesArray.length <= 0) {
      setspinnerLoader(true);

      const searchCriteria = {
        ncpdpRejectCode: NCPDPValues.NCPDPRejectCode
          ? NCPDPValues.NCPDPRejectCode
          : null,

        ncpdpRejectCodeText: NCPDPValues.NCPDPRejectCodeText
          ? NCPDPValues.NCPDPRejectCodeText
          : null,

        ncpdpRejectCodeStartsOrCopntains: NCPDPValues.selectedNCPDPOption
          ? NCPDPValues.selectedNCPDPOption
          : null,
      };

      onSearchNCPDP(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirectNCPDP(valuetoredirect);

      if (payloadData) {
        setShowSAR(true);
      }
    }

    setShowError({
      showFunctionalAreaError: showFunctionalAreaError,

      showCommonError: showCommonError,
    });
  };

  const searchCheckARC = (ARCValues) => {
    errorMessagesArray = [];
    setSuccessMessage([]);
    seterrorMessages([]);

    var showdataElementNameError;
    var showCommonError = false;

    if (
      ARCValues.selectedARCOption &&
      (!ARCValues.adjustmentRT || ARCValues.adjustmentRT.trim().length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowAR(false);
    }

    if (!ARCValues.adjustmentRC && !ARCValues.adjustmentRT) {
      showdataElementNameError = true;

      errorMessagesArray.push(validvaluecons.DATA_ELEMENT_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowAR(false);
    }

    if (errorMessagesArray.length <= 0) {
      setspinnerLoader(true);

      const searchCriteria = {
        adjustmentReasonCode: ARCValues.adjustmentRC
          ? ARCValues.adjustmentRC
          : null,

        adjustmentReasonText: ARCValues.adjustmentRT
          ? ARCValues.adjustmentRT
          : null,

        adjustmentReasonTextStartsOrContains: ARCValues.selectedARCOption
          ? ARCValues.selectedARCOption
          : null,
      };

      onSearchARC(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirectAR(valuetoredirect);

      if (payloadData) {
        setShowAR(true);
      }
    }

    setShowError({
      showdataElementNameError: showdataElementNameError,

      showCommonError: showCommonError,
    });
  };

  const searchCheckRC = (rCValues) => {
    errorMessagesArray = [];
    setSuccessMessage([]);
    seterrorMessages([]);

    var showbusinessNameError;
    var showCommonError = false;

    if (
      rCValues.selectedRCOption &&
      (!rCValues.remarkText || rCValues.remarkText.trim().length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowAR(false);
    }

    if (!rCValues.remarkCode && !rCValues.remarkText) {
      showbusinessNameError = true;

      errorMessagesArray.push(validvaluecons.DATA_ELEMENT_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowPC(false);
    }

    if (errorMessagesArray.length <= 0) {
      setspinnerLoader(true);

      const searchCriteria = {
        remarkCode: rCValues.remarkCode ? rCValues.remarkCode : null,

        remarkText: rCValues.remarkText ? rCValues.remarkText : null,

        remarkTextStartsOrContains: rCValues.selectedRCOption
          ? rCValues.selectedRCOption
          : null,
      };

      onSearchRC(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirectRC(valuetoredirect);

      if (payloadData) {
        setShowPC(true);
      }
    }

    setShowError({
      showbusinessNameError: showbusinessNameError,

      showCommonError: showCommonError,
    });
  };

  const searchCheckPN = (valueslobPN) => {
    setSuccessMessage([]);
    errorMessagesArray = [];

    setspinnerLoader(false);

    seterrorMessages([]);

    var showPNError;
    var showCommonError = false;

    if (valueslobPN.lobPN === "Please Select One") {
      showPNError = true;

      errorMessagesArray.push("LOB " + validvaluecons.PN_PROVIDERTYPE_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowPN(false);
    }

    if (
      pNValues.selectedPNOption &&
      (!pNValues.noticetextEOB || pNValues.noticetextEOB.trim().length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowAR(false);
    }

    if (errorMessagesArray.length <= 0) {
      setspinnerLoader(true);

      const searchCriteria = {
        providerTypeCode:
          valuesPN1.providertypeEOB !== "Please Select One"
            ? valuesPN1.providertypeEOB
            : null,

        providerSpecialityCode:
          valuesPN2.providerspecialityEOB !== "Please Select One"
            ? valuesPN2.providerspecialityEOB
            : null,

        providerNoticeText: pNValues.noticetextEOB
          ? pNValues.noticetextEOB
          : null,

        providerNoticeTextStartsOrContains: pNValues.selectedPNOption
          ? pNValues.selectedPNOption
          : null,

        lobCode: [valueslobPN.lobPN],

        showVoids: pNValues.showVoids,
      };

      onSearchPN(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirectPN(valuetoredirect);

      if (payloadData) {
        setShowPN(true);
      }

      setShowPN(true);
    }

    setShowError({
      showPNError: showPNError,

      showCommonError,
    });
  };

  const searchCheckRAEOB = (valuesRAEOB) => {
    setSuccessMessage([]);
    errorMessagesArray = [];

    setspinnerLoader(false);
    seterrorMessages([]);

    var showRAEOBError;
    var showCommonError = false;

    if (valuesRAEOB.RAEob === "Please Select One") {
      showRAEOBError = true;

      errorMessagesArray.push("LOB " + validvaluecons.PN_PROVIDERTYPE_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowRAEOB(false);
    }

    if (
      eobValues.selectedRAEOBOption &&
      (!eobValues.eobText || eobValues.eobText.trim().length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowAR(false);
    }

    if (errorMessagesArray.length <= 0) {
      setspinnerLoader(true);

      const searchCriteria = {
        lobCode: [valuesRAEOB.RAEob],

        claimEOBCode: eobValues.eobCode,

        eobText: eobValues.eobText,

        eobTextStartsOrContains: eobValues.selectedRAEOBOption,
      };

      onSearchRAEOB(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirectRAEOB(valuetoredirect);

      if (payloadData) {
        setShowRAEOB(true);
      }
    }

    setShowError({
      showRAEOBError: showRAEOBError,

      showCommonError: showCommonError,
    });
  };
  React.useEffect(() => {
    if (errorMessages.length >= 1) {
      setDisplayTable([]);
      setShowHCPCS(false);
    }
  }, [errorMessages]);

  React.useEffect(() => {
    if (displayTable && displayTable.length >= 1) {
      seterrorMessages([]);
      setShowHCPCS(true);
    }
  }, [displayTable]);

  const searchCheckHCPCS = (HCPCSValues) => {
    console.log(HCPCSValues.HCPCSEOBCode, "HCPCSValues.HCPCSEOBCode");
    errorMessagesArray = [];
    setSuccessMessage([]);
    setShowHCPCS(false);

    manageEOMB_Text(false);
    setspinnerLoader(false);

    var showHCPCSError;
    var showHCPCSthruError;
    var showCommonError = false;
    if (HCPCSValues.HCPCSEOBCode.length === 1) {
      //showHCPCSError = true;
      errorMessagesArray.push(
        "A minimum of 2 characters must be entered for a starts with search and a contains search."
      );

      seterrorMessages(errorMessagesArray);

      setShowHCPCS(false);
      manageEOMB_Text(true);
    }

    if (HCPCSValues.lobEOMB === "Please Select One") {
      showHCPCSError = true;

      errorMessagesArray.push("LOB " + validvaluecons.PN_PROVIDERTYPE_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowHCPCS(false);
    }

    if (HCPCSValues.HCPCSfromcode) {
      if (!HCPCSValues.HCPCSthrucode) {
        setHCPCSValues({
          ...HCPCSValues,
          HCPCSthrucode: HCPCSValues.HCPCSfromcode,
        });
      }
    }

    if (HCPCSValues.HCPCSthrucode) {
      if (HCPCSValues.HCPCSfromcode === "") {
        showHCPCSthruError = true;

        errorMessagesArray.push(validvaluecons.FUNCTIONAL_AREA_REQUIRED);

        seterrorMessages(errorMessagesArray);

        setShowHCPCS(false);
      }
    }

    if (
      HCPCSValues.selectedHCPCSOption &&
      (!HCPCSValues.HCPCSEOBCode || HCPCSValues.HCPCSEOBCode.trim().length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowHCPCS(false);
    }

    if (errorMessagesArray.length === 0) {
      setspinnerLoader(true);
      const searchCriteria = {
        eombProcedureTypeCode: "H",

        eombFromCode: HCPCSValues.HCPCSfromcode,

        eombThruCode: HCPCSValues.HCPCSthrucode
          ? HCPCSValues.HCPCSthrucode
          : HCPCSValues.HCPCSfromcode,

        lobCode: [HCPCSValues.lobEOMB],

        eombText: HCPCSValues.HCPCSEOBCode,

        eombTextStartsOrContains: HCPCSValues.selectedHCPCSOption,
      };

      onSearch(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirect(valuetoredirect);

      if (payloadData) {
        setShowHCPCS(true);
      }
    }

    setShowError({
      showHCPCSError: showHCPCSError,

      showHCPCSthruError: showHCPCSthruError,

      showCommonError: showCommonError,
    });
  };

  const searchCheckSP = (HCPCSValues) => {
    setSuccessMessage([]);

    errorMessagesArray = [];

    setspinnerLoader(false);

    seterrorMessages([]);

    var showSPError;
    var showCommonError;
    var showHCPCSthruError = false;

    if (HCPCSValues.lobEOMB === "Please Select One") {
      showSPError = true;

      errorMessagesArray.push("LOB " + validvaluecons.PN_PROVIDERTYPE_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowSP(false);
    }
    if (HCPCSValues.HCPCSEOBCode.length === 1) {
      //showHCPCSError = true;
      errorMessagesArray.push(
        "A minimum of 2 characters must be entered for a starts with search and a contains search."
      );

      seterrorMessages(errorMessagesArray);

      setShowHCPCS(false);
      manageEOMB_Text(true);
    }
    if (
      HCPCSValues.selectedHCPCSOption &&
      (!HCPCSValues.HCPCSEOBCode || HCPCSValues.HCPCSEOBCode.length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowAR(false);
    }

    if (SPValues.SPfromcode) {
      if (!SPValues.SPthrucode) {
        setHCPCSValues({
          ...SPValues,
          SPthrucode: SPValues.SPfromcode,
        });
      }
    }

    if (SPValues.SPthrucode) {
      if (SPValues.SPfromcode === "") {
        showHCPCSthruError = true;

        errorMessagesArray.push(validvaluecons.FUNCTIONAL_AREA_REQUIRED);

        seterrorMessages(errorMessagesArray);

        setShowHCPCS(false);
      }
    }

    if (errorMessagesArray.length <= 0) {
      setspinnerLoader(true);

      const searchCriteria = {
        eombProcedureTypeCode: "S",

        eombFromCode: SPValues.SPfromcode ? SPValues.SPfromcode : null,

        eombThruCode: SPValues.SPthrucode ? SPValues.SPthrucode : null,

        lobCode: [HCPCSValues.lobEOMB],

        eombText: HCPCSValues.HCPCSEOBCode ? HCPCSValues.HCPCSEOBCode : null,

        eombTextStartsOrContains: HCPCSValues.selectedHCPCSOption
          ? HCPCSValues.selectedHCPCSOption
          : null,
      };

      onSearchSP(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirect(valuetoredirect);

      if (payloadData) {
        setShowSP(true);
      }
    }

    setShowError({
      showSPError: showSPError,

      showCommonError: showCommonError,

      showHCPCSthruError: showHCPCSthruError,
    });
  };

  const searchCheckRevenue = (HCPCSValues) => {
    setSuccessMessage([]);
    errorMessagesArray = [];

    setspinnerLoader(false);

    seterrorMessages([]);

    var showRevenueError;
    var showCommonError;
    var showHCPCSthruError = false;

    if (HCPCSValues.lobEOMB === "Please Select One") {
      showRevenueError = true;

      errorMessagesArray.push("LOB " + validvaluecons.PN_PROVIDERTYPE_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowRevenue(false);
    }
    if (HCPCSValues.HCPCSEOBCode.length === 1) {
      //showHCPCSError = true;
      errorMessagesArray.push(
        "A minimum of 2 characters must be entered for a starts with search and a contains search."
      );

      seterrorMessages(errorMessagesArray);

      setShowHCPCS(false);
      manageEOMB_Text(true);
    }
    if (
      HCPCSValues.selectedHCPCSOption &&
      (!HCPCSValues.HCPCSEOBCode || HCPCSValues.HCPCSEOBCode.length < 2)
    ) {
      showCommonError = true;

      errorMessagesArray.push(validvaluecons.BUSINESS_NAME_ERROR);

      seterrorMessages(errorMessagesArray);

      setShowAR(false);
    }

    if (revenueValues.revenuethrucode) {
      if (!revenueValues.revenuethrucode) {
        setHCPCSValues({
          ...revenueValues,
          revenuethrucode: revenueValues.revenuefromcode,
        });
      }
    }

    if (revenueValues.revenuethrucode) {
      if (revenueValues.revenuefromcode === "") {
        showHCPCSthruError = true;

        errorMessagesArray.push(validvaluecons.FUNCTIONAL_AREA_REQUIRED);

        seterrorMessages(errorMessagesArray);

        setShowHCPCS(false);
      }
    }

    if (errorMessagesArray.length <= 0) {
      setspinnerLoader(true);

      const searchCriteria = {
        eombProcedureTypeCode: "R",

        eombFromCode: revenueValues.revenuefromcode,

        eombThruCode: revenueValues.revenuethrucode,

        lobCode: [HCPCSValues.lobEOMB],

        eombText: HCPCSValues.HCPCSEOBCode,

        eombTextStartsOrContains: HCPCSValues.selectedHCPCSOption,
      };

      onSearchRevenue(searchCriteria);

      let valuetoredirect = 0;

      valuetoredirect = valuetoredirect + 1;

      setRedirect(valuetoredirect);

      if (payloadData) {
        setShowRevenue(true);
      }
    }

    setShowError({
      showRevenueError: showRevenueError,

      showCommonError: showCommonError,

      showHCPCSthruError: showHCPCSthruError,
    });
  };

  // Switch Cases to display forms based on user selection from HCPCS, Surgical Process and Revenue

  const renderSwitch = (eombType) => {
    switch (eombType) {
      case "HCPCS":
        return (
          <div id="hcpcs">
            <div className="form-wrapper">
              <div className="mui-custom-form override-width-19 override-m-05">
                <TextField
                  id="HCPCSfromcode"
                  fullWidth
                  label="From Code"
                  inputProps={{ maxlength: 10 }}
                  value={HCPCSValues.HCPCSfromcode}
                  error={
                    showHCPCSthruError
                      ? ErrorConstants.FUNCTIONAL_AREA_REQUIRED
                      : null
                  }
                  helperText={
                    showHCPCSthruError
                      ? ErrorConstants.FUNCTIONAL_AREA_REQUIRED
                      : null
                  }
                  onChange={handleChangeHCPCS("HCPCSfromcode")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier1"
                  fullWidth
                  select
                  label="Modifier 1"
                  inputProps={{ maxlength: 2 }}
                  value={HCPCSValues.HCPCSmodifier1}
                  onChange={handleChangeHCPCS("HCPCSmodifier1")}
                  disabled={fromMod}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {/*modifierData ? modifierData.map(option => (

                  <MenuItem key={option} className='LOB' value={option}>

                    {option}

                  </MenuItem>

                )) : null*/}
                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier2"
                  fullWidth
                  select
                  label="Modifier 2"
                  inputProps={{ maxlength: 2 }}
                  disabled={fromMod}
                  value={HCPCSValues.HCPCSmodifier2}
                  onChange={handleChangeHCPCS("HCPCSmodifier2")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier3"
                  fullWidth
                  select
                  label="Modifier 3"
                  inputProps={{ maxlength: 2 }}
                  value={HCPCSValues.HCPCSmodifier3}
                  disabled={fromMod}
                  onChange={handleChangeHCPCS("HCPCSmodifier3")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier4"
                  fullWidth
                  select
                  label="Modifier 4"
                  inputProps={{ maxlength: 2 }}
                  value={HCPCSValues.HCPCSmodifier4}
                  disabled={fromMod}
                  onChange={handleChangeHCPCS("HCPCSmodifier4")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>
            </div>

            <div className="form-wrapper">
              <div className="mui-custom-form override-width-19 override-m-05">
                <TextField
                  id="HCPCSthrucode"
                  fullWidth
                  label="Thru Code"
                  inputProps={{ maxlength: 10 }}
                  value={HCPCSValues.HCPCSthrucode}
                  onChange={handleChangeHCPCS("HCPCSthrucode")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier11"
                  fullWidth
                  select
                  label="Modifier 1"
                  inputProps={{ maxlength: 2 }}
                  disabled={thruMod}
                  value={HCPCSValues.HCPCSmodifier11}
                  onChange={handleChangeHCPCS("HCPCSmodifier11")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier21"
                  fullWidth
                  select
                  label="Modifier 2"
                  inputProps={{ maxlength: 2 }}
                  value={HCPCSValues.HCPCSmodifier21}
                  disabled={thruMod}
                  onChange={handleChangeHCPCS("HCPCSmodifier21")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier31"
                  fullWidth
                  select
                  label="Modifier 3"
                  inputProps={{ maxlength: 2 }}
                  value={HCPCSValues.HCPCSmodifier31}
                  disabled={thruMod}
                  onChange={handleChangeHCPCS("HCPCSmodifier31")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>

              <div className="mui-custom-form with-select MuiTextField-root override-width-19 override-m-05">
                <TextField
                  id="HCPCSmodifier41"
                  fullWidth
                  select
                  label="Modifier 4"
                  inputProps={{ maxlength: 2 }}
                  value={HCPCSValues.HCPCSmodifier41}
                  onChange={handleChangeHCPCS("HCPCSmodifier41")}
                  disabled={thruMod}
                  InputLabelProps={{
                    shrink: true,
                  }}
                >
                  <MenuItem
                    selected
                    key="Please Select One"
                    value="Please Select One"
                  >
                    Please Select One
                  </MenuItem>

                  {newModifierDropDown
                    ? newModifierDropDown.map((option) => {
                        return (
                          <MenuItem key={option} className="LOB" value={option}>
                            {option.code}
                          </MenuItem>
                        );
                      })
                    : null}
                </TextField>
              </div>
            </div>

            <div className="float-right m-3">
              <Button
                variant="outlined"
                color="primary"
                className="btn btn-primary"
                onClick={() => searchCheckHCPCS(HCPCSValues)}
              >
                <i class="fa fa-search" aria-hidden="true"></i>
                Search
              </Button>

              <Button
                variant="outlined"
                color="primary"
                className="bt-reset btn-transparent  ml-1"
                onClick={() => resetTableHCPCS()}
              >
                <i class="fa fa-undo" aria-hidden="true"></i>
                Reset
              </Button>
            </div>

            <div className="clearfix"></div>

            <div className="tab-holder">
              {showHCPCS && displayTable && displayTable.length > 0 ? (
                <EnhancedTableHead tableData={displayTable || []} />
              ) : null}
            </div>
          </div>
        );

      case "Surgical Procedure":
        return (
          <div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                flexWrap: "wrap",
              }}
            >
              <div className="mui-custom-form override-m-06 left-margin-15">
                <TextField
                  id="SPfromcode"
                  fullWidth
                  label="From Code"
                  inputProps={{ maxlength: 10 }}
                  error={
                    showHCPCSthruError
                      ? ErrorConstants.FUNCTIONAL_AREA_REQUIRED
                      : null
                  }
                  helperText={
                    showHCPCSthruError
                      ? ErrorConstants.FUNCTIONAL_AREA_REQUIRED
                      : null
                  }
                  value={SPValues.SPfromcode}
                  onChange={handleChangeSP("SPfromcode")}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>

              <div className="mui-custom-form override-m-06 left-margin-17">
                <TextField
                  id="SPthrucode"
                  fullWidth
                  label="Thru Code"
                  value={SPValues.SPthrucode}
                  onChange={handleChangeSP("SPthrucode")}
                  inputProps={{ maxlength: 10 }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>
            </div>

            <div className="float-right m-3">
              <Button
                variant="outlined"
                color="primary"
                className="btn btn-primary"
                onClick={() => searchCheckSP(HCPCSValues)}
              >
                <i class="fa fa-search" aria-hidden="true"></i>
                Search
              </Button>

              <Button
                variant="outlined"
                color="primary"
                className="btn btn-primary ml-1"
                onClick={() => resetTableSP()}
              >
                <i class="fa fa-undo" aria-hidden="true"></i>
                Reset
              </Button>
            </div>

            <div className="clearfix"></div>

            <div className="tab-holder">
              {showSP && displayTable && displayTable.length > 0 ? (
                <EnhancedTableHead1 tableData={displayTable || []} />
              ) : null}
            </div>
          </div>
        );

      case "Revenue":
        return (
          <div>
            <div
              style={{
                display: "flex",
                flexDirection: "row",
                flexWrap: "wrap",
              }}
            >
              <div className="mui-custom-form override-m-06 left-margin-15">
                <TextField
                  id="revenuefromcode"
                  fullWidth
                  label="From Code"
                  value={revenueValues.revenuefromcode}
                  onChange={handleChangeRevenue("revenuefromcode")}
                  error={
                    showHCPCSthruError
                      ? ErrorConstants.FUNCTIONAL_AREA_REQUIRED
                      : null
                  }
                  helperText={
                    showHCPCSthruError
                      ? ErrorConstants.FUNCTIONAL_AREA_REQUIRED
                      : null
                  }
                  inputProps={{ maxlength: 10 }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>

              <div className="mui-custom-form override-m-06 left-margin-17">
                <TextField
                  id="revenuethrucode"
                  fullWidth
                  label="Thru Code"
                  value={revenueValues.revenuethrucode}
                  onChange={handleChangeRevenue("revenuethrucode")}
                  inputProps={{ maxlength: 10 }}
                  InputLabelProps={{
                    shrink: true,
                  }}
                />
              </div>
            </div>

            <div className="float-right m-3">
              <Button
                variant="outlined"
                color="primary"
                className="btn btn-primary"
                onClick={() => searchCheckRevenue(HCPCSValues)}
              >
                <i class="fa fa-search" aria-hidden="true"></i>
                Search
              </Button>

              <Button
                variant="outlined"
                color="primary"
                className="btn btn-primary ml-1"
                onClick={() => resetTableRevenue()}
              >
                <i class="fa fa-undo" aria-hidden="true"></i>
                Reset
              </Button>
            </div>

            <div className="clearfix"></div>

            <div className="tab-holder">
              {payload ? (
                payload.length === 1 ? (
                  props.history.push({
                    pathname: "/TextUpdate",

                    state: {
                      row: payload[0],
                      TextType: "EOMB",
                      EombType: "revenue",
                    },
                  })
                ) : showRevenue && displayTable && displayTable.length > 0 ? (
                  <EnhancedTableHead2 tableData={displayTable || []} />
                ) : null
              ) : null}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const DelResult = useSelector(
    (state) => state.appConfigState.textManagementState.DelResult
  );

  // Code to display tabular options on main screen

  return (
    <div className="text-management-search">
      <div>
        {spinnerLoader ? <Spinner /> : null}

        {errorMessages.length > 0 ? (
          <div class="alert alert-danger custom-alert" role="alert">
            {errorMessages.map((message) => (
              <li>{message}</li>
            ))}
          </div>
        ) : null}
        <SuccessMessages successMessages={SuccessMessage} setSuccessMessages={setSuccessMessage} />

        <div className="tabs-container" ref={toPrintRef}>
          <div className="tab-header">
            <div className="page-heading float-left">
              Search Text Management
            </div>

            <div className="float-right mt-1 pt-1 hide-on-print">
              <ReactToPrint
                onBeforeGetContent={() => {
                  console.log("setPrintLayout,true");
                  dispatch(setPrintLayout(true));
                  setspinnerLoader(true);
                  return new Promise((resolve) =>
                    setTimeout(() => resolve(), 100)
                  );
                }}
                onAfterPrint={() => {
                  console.log("setPrintLayout,false");

                  setspinnerLoader(false);
                  dispatch(setPrintLayout(false));
                }}
                trigger={() => (
                  <Button className="btn btn-ic btn-print" title="Print">
                    Print
                  </Button>
                )}
                content={() => toPrintRef.current}
              />

              <Button
                title="Help"
                variant="outlined"
                color="primary"
                className="btn btn-ic btn-help"
              >
                Help
              </Button>
            </div>

            <div className="clearfix"></div>
          </div>

          <div className="tab-body">
            <div className="tab-panelbody">
              <div className="tab-holder my-3">
                <AppBar position="static" className="hide-on-print">
                  <Tabs
                    variant="fullWidth"
                    value={value}
                    onChange={handleChangeTabs}
                    // aria-label="simple tabs example"
                    className="tabChange"
                    scrollButtons="auto"
                    aria-label="scrollable auto tabs example"
                  >
                    <Tab classes={{ root: classes.tab100 }} label="Location" />

                    <Tab classes={{ root: classes.tab100 }} label="EOMB" />

                    <Tab
                      classes={{ root: classes.tab100 }}
                      label="RA EOB"
                      style={{ marginLeft: "-25px" }}
                    />

                    <Tab
                      classes={{ root: classes.tab100 }}
                      label="Provider Notice"
                    />

                    <Tab
                      classes={{ root: classes.tab100 }}
                      label="Remark Code"
                    />

                    <Tab
                      classes={{ root: classes.tab100 }}
                      label="Adjustment Reason"
                    />
                    <Tab
                      classes={{ root: classes.tab100 }}
                      label="Service Authorization Reason"
                    />

                    {/* <Tab
                      classes={{ root: classes.tab100 }}
                      label="NCPDP Reject Codes"
                    /> */}

                    {/* <Tab label="Refund Information" />

                        <Tab label="History" /> */}
                  </Tabs>
                </AppBar>

                {/* Code for location */}

                <TabPanel value={value} index={0}>
                  <TextManagementLocationTab
                    errors={{
                      showdataElementNameError,
                      showCommonError,
                    }}
                    payload={payloadlocation}
                    setShowError={setShowError}
                    privileges={props.privileges}
                    setspinnerLoader={setspinnerLoader}
                    spinnerLoader={spinnerLoader}
                    setSuccessMessage={setSuccessMessage}
                    seterrorMessages={seterrorMessages}
                    locationValues={locationValues}
                    setLocationValues={setLocationValues}
                  />
                </TabPanel>

                {/* code for first tab EOMB */}

                <TabPanel value={value} index={1}>
                  <div className="tab-holder p-0">
                    <h4 className="hide-on-screen">
                      <span class="badge badge-primary">EOMB</span>
                    </h4>
                    <form autoComplete="off">
                      <div className="form-wrapper">
                        <div className="mui-custom-form with-select override-width-19 override-m-06">
                          <TextField
                            id="lobEOMB"
                            fullWidth
                            select
                            label="LOB"
                            required
                            value={HCPCSValues.lobEOMB}
                            error={
                              showHCPCSError || showSPError || showRevenueError
                                ? "LOB " + ErrorConstants.PN_PROVIDERTYPE_ERROR
                                : null
                            }
                            helperText={
                              showHCPCSError || showSPError || showRevenueError
                                ? "LOB " + ErrorConstants.PN_PROVIDERTYPE_ERROR
                                : null
                            }
                            onChange={handleChangesEOMB("lobEOMB")}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          >
                            <MenuItem
                              selected
                              key="Please Select One"
                              value="Please Select One"
                            >
                              Please Select One
                            </MenuItem>

                            {lobCodeData
                              ? lobCodeData.map((item, index) => (
                                  <MenuItem key={index} value={item.code}>
                                    {item.description}
                                  </MenuItem>
                                ))
                              : null}
                          </TextField>
                        </div>

                        <div
                          className="mui-custom-form eomb-width"
                          style={{ lineHeight: "100%" }}
                        >
                          <label className="MuiFormLabel-root small-label">
                            EOMB Type<span>*</span>
                          </label>

                          <div className="sub-radio sub-radio-eomb-type">
                            <Radio
                              value="HCPCS"
                              id="hcpcs"
                              name="eombType"
                              onChange={handleChanges("selectedOption")}
                              checked={eombType === "HCPCS"}
                              style={{ marginLeft: "0px" }}
                            />
                            <label
                              className="text-black"
                              htmlFor="hcpcs"
                              style={{ marginLeft: "-2px" }}
                            >
                              HCPCS
                            </label>
                            <Radio
                              value="Surgical Procedure"
                              id="surgical"
                              className="ml-2"
                              style={{ marginRight: "2px" }}
                              name="eombType"
                              onChange={handleChanges("selectedOption")}
                              checked={eombType === "Surgical Procedure"}
                            />
                            <label className="text-black" htmlFor="surgical">
                              Surgical Procedure
                            </label>{" "}
                            <Radio
                              value="Revenue"
                              id="revenue"
                              className="ml-2"
                              style={{ marginRight: "2px" }}
                              name="eombType"
                              onChange={handleChanges("selectedOption")}
                              checked={eombType === "Revenue"}
                            />
                            <label className="text-black" htmlFor="revenue">
                              Revenue
                            </label>{" "}
                          </div>
                        </div>

                        <div className="mui-custom-form eombText-width">
                          <TextField
                            id="HCPCSEOBCode"
                            required
                            fullWidth
                            label="EOMB Text"
                            inputProps={{ maxlength: 35 }}
                            value={HCPCSValues.HCPCSEOBCode}
                            error={
                              showCommonError
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            helperText={
                              showCommonError || isEOMB_TextOnlyOneCharecter
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            onChange={handleChangeHCPCS("HCPCSEOBCode")}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />

                          <div className="sub-radio sub-radio-eomb-text">
                            <Radio
                              id="startsWith"
                              value="0"
                              checked={HCPCSValues.selectedHCPCSOption === "0"}
                              onChange={handleChangeHCPCS(
                                "selectedHCPCSOption"
                              )}
                            />

                            <label className="text-black" htmlFor="startsWith">
                              Starts With
                            </label>

                            <Radio
                              id="contains"
                              value="1"
                              checked={HCPCSValues.selectedHCPCSOption === "1"}
                              onChange={handleChangeHCPCS(
                                "selectedHCPCSOption"
                              )}
                              className="ml-2"
                            />

                            <label className="text-black" htmlFor="contains">
                              Contains
                            </label>
                          </div>
                        </div>
                      </div>
                      {/* Switch Call */}

                      {renderSwitch(eombType)}
                    </form>
                  </div>
                </TabPanel>

                {/* Code to display RA EOB */}

                <TabPanel value={value} index={2}>
                  <div className="tab-holder">
                    <h4 className="hide-on-screen">
                      <span class="badge badge-primary">RA EOB</span>
                    </h4>
                    <form autoComplete="off">
                      <div className="form-wrapper">
                        <div className="mui-custom-form input-md with-select">
                          <TextField
                            id="RAEob"
                            fullWidth
                            select
                            label="LOB"
                            required
                            value={valuesRAEOB.RAEob}
                            onChange={handleChangesRAEOB("RAEob")}
                            error={
                              showRAEOBError
                                ? "LOB " + ErrorConstants.PN_PROVIDERTYPE_ERROR
                                : null
                            }
                            helperText={
                              showRAEOBError
                                ? "LOB " + ErrorConstants.PN_PROVIDERTYPE_ERROR
                                : null
                            }
                            inputProps={{ maxlength: 1 }}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          >
                            <MenuItem
                              selected
                              key="Please Select One"
                              value="Please Select One"
                            >
                              Please Select One
                            </MenuItem>

                            {lobCodeData
                              ? lobCodeData.map((item, index) => (
                                  <MenuItem key={index} value={item.code}>
                                    {item.description}
                                  </MenuItem>
                                ))
                              : null}
                          </TextField>
                        </div>

                        <div className="mui-custom-form input-sm">
                          <TextField
                            id="eobCode"
                            fullWidth
                            label="EOB Code"
                            value={eobValues.eobCode}
                            onChange={handleChangeREOB("eobCode")}
                            inputProps={{ maxLength: 4 }}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                        </div>

                        <div className="mui-custom-form mui-custom-forms">
                          <TextField
                            id="eobText"
                            fullWidth
                            value={eobValues.eobText}
                            onChange={handleChangeREOB("eobText")}
                            label="EOB Text"
                            error={
                              showCommonError
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            helperText={
                              showCommonError
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            InputLabelProps={{
                              shrink: true,
                            }}
                            inputProps={{ maxLength: 35 }}
                          />

                          <div className="sub-radio sub-radio-eomb-text">
                            <Radio
                              value="0"
                              id="StartsWith"
                              checked={eobValues.selectedRAEOBOption === "0"}
                              onChange={handleChangeREOB("selectedRAEOBOption")}
                            />
                            <label className="text-black" htmlFor="StartsWith">
                              Starts With
                            </label>
                            <Radio
                              value="1"
                              id="Contains"
                              checked={eobValues.selectedRAEOBOption === "1"}
                              onChange={handleChangeREOB("selectedRAEOBOption")}
                              className="ml-2"
                            />
                            <label className="text-black" htmlFor="Contains">
                              Contains{" "}
                            </label>{" "}
                          </div>
                        </div>
                      </div>

                      <div className="float-right m-3">
                        <Button
                          variant="outlined"
                          color="primary"
                          className="btn btn-primary"
                          onClick={() => searchCheckRAEOB(valuesRAEOB)}
                        >
                          <i class="fa fa-search" aria-hidden="true"></i>
                          Search
                        </Button>

                        <Button
                          variant="outlined"
                          color="primary"
                          className="bt-reset btn-transparent  ml-1"
                          onClick={() => resetTableRAEOB()}
                        >
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset
                        </Button>
                      </div>

                      <div className="clearfix"></div>
                    </form>
                  </div>
                  <div className="tab-holder">
                    {showRAEOB && displayTable && displayTable.length > 0 ? (
                      <RAEOBResult tableData={displayTable || []} />
                    ) : null}
                  </div>
                </TabPanel>

                {/* Code for Provider Notice Tab */}

                <TabPanel value={value} index={3}>
                  {/* <form autoComplete="off"> */}
                  <div className="tab-holder">
                    <h4 className="hide-on-screen">
                      <span class="badge badge-primary">Provider Notice</span>
                    </h4>
                    <div className="form-wrapper">
                      <div className="mui-custom-form input-md with-select">
                        <TextField
                          id="lobPN"
                          fullWidth
                          select
                          label="LOB"
                          required
                          value={valueslobPN.lobPN}
                          onChange={handleChangeslobPN("lobPN")}
                          inputProps={{ maxlength: 1 }}
                          error={
                            showPNError
                              ? "LOB " + ErrorConstants.PN_PROVIDERTYPE_ERROR
                              : null
                          }
                          helperText={
                            showPNError
                              ? "LOB " + ErrorConstants.PN_PROVIDERTYPE_ERROR
                              : null
                          }
                          InputLabelProps={{
                            shrink: true,
                          }}
                        >
                          <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                          >
                            Please Select One
                          </MenuItem>

                          {lobCodeData
                            ? lobCodeData.map((item, index) => (
                                <MenuItem key={index} value={item.code}>
                                  {item.description}
                                </MenuItem>
                              ))
                            : null}
                        </TextField>
                      </div>

                      <div className="mui-custom-form input-md with-select">
                        <TextField
                          id="providertypeEOB"
                          fullWidth
                          select
                          label="Provider Type"
                          inputProps={{ maxlength: 3 }}
                          value={valuesPN1.providertypeEOB}
                          onChange={handleChangesPN1("providertypeEOB")}
                          InputLabelProps={{
                            shrink: true,
                          }}
                        >
                          <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                          >
                            Please Select One
                          </MenuItem>

                          {providerType
                            ? providerType.map((item, index) => (
                                <MenuItem key={index} value={item.code}>
                                  {item.description}
                                </MenuItem>
                              ))
                            : null}
                        </TextField>
                      </div>

                      <div className="mui-custom-form input-md with-select">
                        <TextField
                          id="providerspecialityEOB"
                          fullWidth
                          select
                          label="Provider Specialty"
                          inputProps={{ maxlength: 3 }}
                          value={valuesPN2.providerspecialityEOB}
                          onChange={handleChangesPN2("providerspecialityEOB")}
                          disabled={providerSpeciality}
                          InputLabelProps={{
                            shrink: true,
                          }}
                        >
                          <MenuItem
                            selected
                            key="Please Select One"
                            value="Please Select One"
                          >
                            Please Select One
                          </MenuItem>

                          {ProviderSpecialtyData
                            ? ProviderSpecialtyData.map((item, index) => (
                                <MenuItem key={index} value={item.code}>
                                  {item.description}
                                </MenuItem>
                              ))
                            : null}
                        </TextField>
                      </div>

                      <div className="mui-custom-form mui-custom-forms">
                        <TextField
                          id="noticetextEOB"
                          fullWidth
                          label="Notice Text"
                          error={
                            showCommonError
                              ? ErrorConstants.BUSINESS_NAME_ERROR
                              : null
                          }
                          helperText={
                            showCommonError
                              ? ErrorConstants.BUSINESS_NAME_ERROR
                              : null
                          }
                          inputProps={{ maxlength: 35 }}
                          value={pNValues.noticetextEOB}
                          onChange={handleChangePN("noticetextEOB")}
                          InputLabelProps={{
                            shrink: true,
                          }}
                        />

                        <div className="sub-radio sub-radio-eomb-text">
                          <Radio
                            value="0"
                            id="startwithoption"
                            checked={pNValues.selectedPNOption === "0"}
                            onChange={handleChangePN("selectedPNOption")}
                          />
                          <label
                            className="text-black"
                            htmlFor="startwithoption"
                          >
                            Starts With{" "}
                          </label>

                          <Radio
                            value="1"
                            id="containsoption"
                            checked={pNValues.selectedPNOption === "1"}
                            onChange={handleChangePN("selectedPNOption")}
                            className="ml-2"
                          />
                          <label
                            className="text-black"
                            htmlFor="containsoption"
                          >
                            Contains
                          </label>
                        </div>
                      </div>
                    </div>

                    <div className="form-wrapper">
                      <div className="mui-custom-form no-margin-y">
                        <div className="sub-radio sub-radios no-margin">
                          <FormControlLabel
                            control={
                              <Checkbox
                                color="primary"
                                checked={pNValues.showVoids}
                                value={pNValues.showVoids}
                                onChange={handleShowVoidsChange}
                              />
                            }
                            label="Show Voids"
                          />
                        </div>
                      </div>
                    </div>

                    <div
                      className="float-right"
                      style={{
                        marginTop: "-12px",
                        marginRight: "16px",
                        marginBottom: "16px",
                      }}
                    >
                      <Button
                        variant="outlined"
                        color="primary"
                        className="btn btn-primary"
                        onClick={() => searchCheckPN(valueslobPN)}
                      >
                        <i class="fa fa-search" aria-hidden="true"></i>
                        Search
                      </Button>

                      <Button
                        variant="outlined"
                        color="primary"
                        className="bt-reset btn-transparent  ml-1"
                        onClick={() => resetTablePN()}
                      >
                        <i class="fa fa-undo" aria-hidden="true"></i>
                        Reset
                      </Button>
                    </div>

                    <div className="clearfix"></div>

                    {/* </form> */}

                    <div className="tab-holder">
                      {showPN && displayTable && displayTable.length > 0 ? (
                        <ProviderNotice
                          tableData={displayTable || []}
                          providerType={providerType}
                          ProviderSpecialtyData={ProviderSpecialtyData}
                        />
                      ) : null}
                    </div>
                  </div>
                </TabPanel>

                {/* Code for Remark Code */}

                <TabPanel value={value} index={4}>
                  <div className="tab-holder">
                    <h4 className="hide-on-screen">
                      <span class="badge badge-primary">Remark Code</span>
                    </h4>
                    <form autoComplete="off">
                      <div className="form-wrapper">
                        <div className="mui-custom-form input-sm">
                          <TextField
                            id="remarkCode"
                            fullWidth
                            label="Remark Code"
                            inputProps={{ maxlength: 10 }}
                            error={
                              showbusinessNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : null
                            }
                            helperText={
                              showbusinessNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : null
                            }
                            value={rCValues.remarkCode}
                            onChange={handleChangeRC("remarkCode")}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                        </div>

                        <div
                          className="mui-custom-form input-xxl"
                          style={{ marginLeft: "32px" }}
                        >
                          <TextField
                            id="remarkText"
                            fullWidth
                            label="Remark Text"
                            inputProps={{ maxlength: 35 }}
                            error={
                              showbusinessNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : showCommonError
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            helperText={
                              showbusinessNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : showCommonError
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            value={rCValues.remarkText}
                            onChange={handleChangeRC("remarkText")}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />

                          <div className="sub-radio sub-radio-eomb-text">
                            <Radio
                              value="0"
                              id="startremark"
                              checked={rCValues.selectedRCOption === "0"}
                              onChange={handleChangeRC("selectedRCOption")}
                            />
                            <label className="text-black" htmlFor="startremark">
                              Starts With
                            </label>

                            <Radio
                              value="1"
                              id="containremark"
                              checked={rCValues.selectedRCOption === "1"}
                              onChange={handleChangeRC("selectedRCOption")}
                              className="ml-2"
                            />

                            <label
                              className="text-black"
                              htmlFor="containremark"
                            >
                              Contains
                            </label>
                          </div>
                        </div>
                      </div>

                      <div className="float-right m-3">
                        <Button
                          variant="outlined"
                          color="primary"
                          className="btn btn-primary"
                          onClick={() => searchCheckRC(rCValues)}
                        >
                          <i class="fa fa-search" aria-hidden="true"></i>
                          Search
                        </Button>

                        <Button
                          variant="outlined"
                          color="primary"
                          className="bt-reset btn-transparent  ml-1"
                          onClick={() => resetTableRC()}
                        >
                          {" "}
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset
                        </Button>
                      </div>

                      <div className="clearfix"></div>
                    </form>

                    <div className="tab-holder">
                      {showPC && displayTable && displayTable.length > 0 ? (
                        <RemarkCode tableData={displayTable || []} />
                      ) : null}
                    </div>
                  </div>
                </TabPanel>

                {/* Code for adjustment reason */}

                <TabPanel value={value} index={5}>
                  <div className="tab-holder">
                    <h4 className="hide-on-screen">
                      <span class="badge badge-primary">Adjustment Reason</span>
                    </h4>
                    <form autoComplete="off">
                      <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                          <TextField
                            id="adjustmentRC"
                            fullWidth
                            label="Adjustment Reason Code"
                            value={ARCValues.adjustmentRC}
                            error={
                              showdataElementNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : null
                            }
                            helperText={
                              showdataElementNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : null
                            }
                            inputProps={{ maxlength: 5 }}
                            onChange={handleChangeARC("adjustmentRC")}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                        </div>

                        <div
                          className="mui-custom-form input-xxl"
                          style={{ marginLeft: "32px" }}
                        >
                          <TextField
                            id="adjustmentRT"
                            fullWidth
                            label="Adjustment Reason Text"
                            value={ARCValues.adjustmentRT}
                            error={
                              showdataElementNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : showCommonError
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            helperText={
                              showdataElementNameError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : showCommonError
                                ? ErrorConstants.BUSINESS_NAME_ERROR
                                : null
                            }
                            inputProps={{ maxlength: 35 }}
                            onChange={handleChangeARC("adjustmentRT")}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />

                          <div className="sub-radio sub-radio-eomb-text">
                            <Radio
                              value="0"
                              id="startadjustment"
                              checked={ARCValues.selectedARCOption === "0"}
                              onChange={handleChangeARC("selectedARCOption")}
                            />
                            <label
                              className="text-black"
                              htmlFor="startadjustment"
                            >
                              Starts With
                            </label>

                            <Radio
                              value="1"
                              id="containsadjustment"
                              checked={ARCValues.selectedARCOption === "1"}
                              onChange={handleChangeARC("selectedARCOption")}
                              className="ml-2"
                            />

                            <label
                              className="text-black"
                              htmlFor="containsadjustment"
                            >
                              Contains
                            </label>
                          </div>
                        </div>
                      </div>

                      <div className="float-right m-3">
                        <Button
                          variant="outlined"
                          color="primary"
                          className="btn btn-primary"
                          onClick={() => searchCheckARC(ARCValues)}
                        >
                          <i class="fa fa-search" aria-hidden="true"></i>
                          Search
                        </Button>

                        <Button
                          variant="outlined"
                          color="primary"
                          className="bt-reset btn-transparent  ml-1"
                          onClick={() => resetTableARC()}
                        >
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset
                        </Button>
                      </div>

                      <div className="clearfix"></div>
                    </form>

                    <div className="tab-holder">
                      {showAR && displayTable && displayTable.length > 0 ? (
                        <AdjustmentReason tableData={displayTable || []} />
                      ) : null}
                    </div>
                  </div>
                </TabPanel>

                {/* Code for NCPDP */}

                {/* <TabPanel value={value} index={6}>
                  <div className="tab-holder">
                    <h4 className="hide-on-screen">
                      <span class="badge badge-primary">
                        NCPDP Reject Codes
                      </span>
                    </h4>
                    <form autoComplete="off">
                      <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                          <TextField
                            id="NCPDPRejectCode"
                            fullWidth
                            label="NCPDP Reject Code"
                            value={NCPDPValues.NCPDPRejectCode}
                            inputProps={{ maxlength: 3 }}
                            error={
                              showFunctionalAreaError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : null
                            }
                            helperText={
                              showFunctionalAreaError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : null
                            }
                            onChange={handleChangeNCPDP("NCPDPRejectCode")}
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                        </div>

                        <div
                          className="mui-custom-form input-xxl"
                          style={{ marginLeft: "32px" }}
                        >
                          <TextField
                            id="NCPDPRejectCodeText"
                            fullWidth
                            label="NCPDP Reject Code Text"
                            inputProps={{ maxlength: 50 }}
                            value={NCPDPValues.NCPDPRejectCodeText}
                            onChange={handleChangeNCPDP("NCPDPRejectCodeText")}
                            error={
                              showFunctionalAreaError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : showCommonError
                                  ? ErrorConstants.BUSINESS_NAME_ERROR
                                  : null
                            }
                            helperText={
                              showFunctionalAreaError
                                ? ErrorConstants.DATA_ELEMENT_NAME_ERROR
                                : showCommonError
                                  ? ErrorConstants.BUSINESS_NAME_ERROR
                                  : null
                            }
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />

                          <div className="sub-radio sub-radios">
                            <input
                              type="radio"
                              value="0"
                              id="startncpdp"
                              checked={NCPDPValues.selectedNCPDPOption === "0"}
                              onChange={handleChangeNCPDP(
                                "selectedNCPDPOption"
                              )}
                            />

                            <span className="text-black">
                              {" "}
                              <label for="startncpdp">Starts With</label>
                            </span>

                            <input
                              type="radio"
                              value="1"
                              id="containncp"
                              checked={NCPDPValues.selectedNCPDPOption === "1"}
                              onChange={handleChangeNCPDP(
                                "selectedNCPDPOption"
                              )}
                              className="ml-2"
                              style={{ marginRight: "3px" }}
                            />

                            <span className="text-black">
                              <label for="containncp">Contains</label>
                            </span>
                          </div>
                        </div>
                      </div>

                      <div className="float-right m-3">
                        <Button
                          variant="outlined"
                          color="primary"
                          className="btn btn-primary"
                          onClick={() => searchCheckNCPDP(NCPDPValues)}
                        >
                          <i class="fa fa-search" aria-hidden="true"></i>
                          Search
                        </Button>

                        <Button
                          variant="outlined"
                          color="primary"
                          className="bt-reset btn-transparent  ml-1"
                          onClick={() => resetTableNCPDP()}
                        >
                          <i class="fa fa-undo" aria-hidden="true"></i>
                          Reset
                        </Button>
                      </div>

                      <div className="clearfix"></div>
                    </form>

                    <div className="tab-holder">
                      {showSAR && displayTable && displayTable.length > 0 ? (
                        <SAR tableData={displayTable || []} />
                      ) : null}
                    </div>
                  </div>
                </TabPanel>*/}
                <TabPanel value={value} index={6}>
                  <ServiceAuthSearch
                    errors={{
                      showdataElementNameError,
                      showCommonError,
                    }}
                    setShowError={setShowError}
                    privileges={props.privileges}
                    setSuccessMessage={setSuccessMessage}
                    seterrorMessages={seterrorMessages}
                    serviceAuthvalues={serviceAuthvalues}
                    setserviceAuthvalues={setserviceAuthvalues}
                    setspinnerLoader={setspinnerLoader}
                    spinnerLoader={spinnerLoader}
                  />
                </TabPanel>
              </div>
            </div>
          </div>
          <Footer print />
        </div>
      </div>
    </div>
  );
}

export default withRouter(TextManagementSearch);
