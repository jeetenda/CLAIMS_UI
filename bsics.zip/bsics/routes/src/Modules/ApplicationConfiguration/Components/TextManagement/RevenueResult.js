/* eslint-disable no-unused-vars */

import React from 'react';
import { withRouter } from 'react-router';

import { useDispatch, useSelector } from 'react-redux';
import { systemParameterRowClickAction } from '../../Store/Actions/TextManagement/TextManagementActions';
import TableComponent from '../../../../SharedModules/Table/Table';


const headCells = [
  { id: 'lobCode', disablePadding: false, label: 'LOB', enableHyperLink: true },
  { id: 'eombFromCode', disablePadding: false, label: 'From Code' },
  { id: 'eombThruCode', disablePadding: false, label: 'Thru Code' },
  { id: 'eombDesc', disablePadding: false, label: 'Text', isText: true }
];

function RevenueResult (props) {
  const dispatch = useDispatch();
  const onRowClick = values => dispatch(systemParameterRowClickAction(values));
  const payloadData = useSelector(state => state.appConfigState.systemParameterState.rowSearchSysParam);
  const [redirect, setRedirect] = React.useState(false);
  if (redirect === 1) {
    if (payloadData != null) {
      if (payloadData.length === 1) {
        console.log(payloadData);
        props.history.push({
          pathname: '/TextUpdate',
          state: { row: payloadData, TextType: 'EOMB', EombType: 'revenue' }
        });
      }
    }
  }

  const editRow = row => event => {
    const searchCriteria = {
      eombProcedureTypeCode: 'R',
      lobCode: [row.lobCode],
      eombFromCode: row.eombFromCode,
      eombthruCode: row.eombTromCode
    };
    onRowClick(searchCriteria);
    let valuetoredirect = 0;
    valuetoredirect = valuetoredirect + 1;
    setRedirect(valuetoredirect);
  };
  return (
    <TableComponent isSearch={true} headCells={headCells} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={headCells[0].id} />
  );
}
export default withRouter((RevenueResult));
