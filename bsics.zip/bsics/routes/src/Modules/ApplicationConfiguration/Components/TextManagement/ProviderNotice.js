/* eslint-disable no-unused-vars */
import React, { useEffect } from 'react';
import { withRouter } from 'react-router';

import { useDispatch, useSelector } from 'react-redux';
import { providerNoticeRowClickAction } from '../../Store/Actions/TextManagement/TextManagementActions';
import TableComponent from '../../../../SharedModules/Table/Table';


const headCells = [
  {
    id: 'lobCode',
    disablePadding: false,
    label: 'LOB',
    width: '8%',
    enableHyperLink: true
  },
  {
    id: 'providerTypeDesc',
    disablePadding: false,
    label: 'Provider Type',
    width: '17%'
  },
  {
    id: 'providerSpecialityDesc',
    disablePadding: false,
    label: 'Provider Specialty',
    width: '19%'
  },
  {
    id: 'beginDate',
    disablePadding: false,
    label: 'Begin Date',
    width: '14%',
    isDate: true
  },
  {
    id: 'endDate',
    disablePadding: false,
    label: 'End Date',
    width: '12%',
    isDate: true
  },
  {
    id: 'providerNoticeText',
    disablePadding: false,
    label: 'Text',
    width: '18%',
    isText: true
  },
  {
    id: 'voidDate',
    disablePadding: false,
    label: 'Void Date',
    width: '12%',
    isDate: true
  }
];

function ProviderNoticeTable (props) {
  const [redirect, setRedirect] = React.useState(false);
  // API CAll
  const dispatch = useDispatch();
  const onRowClick = values => dispatch(providerNoticeRowClickAction(values));
  const payloadData = useSelector(
    state => state.appConfigState.textManagementState.payload
  );
  if (redirect === 1) {
    if (payloadData != null) {
      if (payloadData.length === 1) {
        props.history.push({
          pathname: '/TextUpdate',
          state: { row: payloadData[0], TextType: 'Provider Notice' }
        });
      }
    }
  }

  // Spinner Functionality
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (payloadData != null) {
      setspinnerLoader(false);
    }
  }, [payloadData]);

  const editRow = row => event => {
    console.log(row);
    const searchCriteria = {
      lobCode: [row.lobCode],
      providerTypeCode: row.providerType ? row.providerType : null,
      providerSpecialityCode: row.providerSpeciality
        ? row.providerSpeciality
        : null,
      providerNoticeText: row.providerNoticeText
        ? row.providerNoticeText
        : null,
      showVoids: row.voidDate ? true : null,
      beginDate: row.beginDate || null,
      endDate: row.endDate || null
    };
    onRowClick(searchCriteria);
    setspinnerLoader(true);
    let valuetoredirect = 0;
    valuetoredirect = valuetoredirect + 1;
    setRedirect(valuetoredirect);
  };

  const tableComp = (
    <TableComponent
      fixedTable
      isSearch={true}
      headCells={headCells}
      tableData={props.tableData ? props.tableData : []}
      onTableRowClick={editRow}
      defaultSortColumn={headCells[0].id}
    />
  );
  return tableComp;
}

export default withRouter((ProviderNoticeTable));
