/* eslint-disable no-unused-vars */

import React, { useEffect } from 'react';
import TableComponent from '../../../../SharedModules/Table/Table';
import { withRouter } from 'react-router';

import { useDispatch, useSelector } from 'react-redux';
import { ARRowClickAction } from '../../Store/Actions/TextManagement/TextManagementActions';


const headCells = [
  { id: 'adjustmentReasonCode', disablePadding: false, label: 'Adjustment Reason', width: 200, enableHyperLink: true, isVarchar: true },
  { id: 'adjustmentReasonBeginDate', disablePadding: false, label: 'Begin Date', width: 120, isDate: true },
  { id: 'adjustmentReasonEndDate', disablePadding: false, label: 'End Date', width: 120, isDate: true },
  { id: 'adjustmentReasonText', disablePadding: false, label: 'Text', width: 200, isText: true, isVarchar: true }
];

function ProviderNoticeTable (props) {
  const [redirect, setRedirect] = React.useState(false);

  const dispatch = useDispatch();
  const onRowClick = values => dispatch(ARRowClickAction(values));
  const payloadData = useSelector(state => state.appConfigState.textManagementState.payload);
  if (redirect === 1) {
    if (payloadData != null) {
      if (payloadData.length === 1) {
        props.history.push({
          pathname: '/TextUpdate',
          state: { row: payloadData[0], TextType: 'Adjustment Reason' }
        });
      }
    }
  }

  // Spinner Functionality
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  useEffect(() => {
    if (payloadData != null) {
      setspinnerLoader(false);
    }
  }, [payloadData]);
  // Spinner Functionality

  const editRow = row => event => {
    console.log(row);
    const searchCriteria = {
      adjustmentReasonCode: row.adjustmentReasonCode ? row.adjustmentReasonCode : null,
      adjustmentReasonText: row.adjustmentReasonText ? row.adjustmentReasonText : null,
      adjustmentReasonTextStartsOrContains: null
    };
    onRowClick(searchCriteria);
    setspinnerLoader(true);
    let valuetoredirect = 0;
    valuetoredirect = valuetoredirect + 1;
    setRedirect(valuetoredirect);
  };

  return (
    <TableComponent isSearch={true} headCells={headCells} tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn={headCells[0].id} />
  );
}
export default withRouter((ProviderNoticeTable));
