import React, {Component ,useState} from 'react';
import DataTable from 'react-data-table-component';
import { makeStyles } from '@material-ui/core/styles';
import MenuItem from '@material-ui/core/MenuItem';
import TextField from '@material-ui/core/TextField';
import Edit from '@material-ui/icons/Edit';
import Modal from '@material-ui/core/Modal';
import { withStyles } from '@material-ui/core/styles';
import Bootstrap, { Button } from 'react-bootstrap'
import Dialog from '@material-ui/core/Dialog';
import MuiDialogTitle from '@material-ui/core/DialogTitle';
import MuiDialogContent from '@material-ui/core/DialogContent';
import MuiDialogActions from '@material-ui/core/DialogActions';
import IconButton from '@material-ui/core/IconButton';
import CloseIcon from '@material-ui/icons/Close';
import Typography from '@material-ui/core/Typography';

 
const data = [{ id: 1, firstname: 'Tejaswi', lastname: 'Chava', cid:'C5102896', yearsofexp:'3',technology:'React' },
                { id: 2, firstname: 'Sai Purnima', lastname: 'Kandikattu', cid:'C5104422', yearsofexp:'2.9',technology:'React' },
                { id: 3,firstname: 'Kirti', lastname: 'Saraogi', cid:'C5104415', yearsofexp:'6',technology:'React' },
                { id: 4, firstname: 'Alfia', lastname: 'sadia', cid:'C5102897', yearsofexp:'1',technology:'React' },
                { id: 5,firstname: 'Priti', lastname: 'Tripathy', cid:'C5081726', yearsofexp:'7.5',technology:'React'},
                { id: 6, firstname: 'Krishna Vinay', lastname: 'Kalaga', cid:'C5102897', yearsofexp:'5',technology:'React' },
                { id: 7,firstname: 'Bharat', lastname: 'Reddy', cid:'C5081728', yearsofexp:'7.5',technology:'React' }


            ];


function rand() {
  return Math.round(Math.random() * 20) - 10;
}

function getModalStyle() {
  const top = 50 + rand();
  const left = 50 + rand();

  return {
    top: `${top}%`,
    left: `${left}%`,
    transform: `translate(-${top}%, -${left}%)`,
  };
}

const useStyles = makeStyles(theme => ({
  container: {
    display: 'flex',
    flexWrap: 'wrap',
  },
  textField: {
    marginLeft: theme.spacing(1),
    marginRight: theme.spacing(1),
    width: 200,
    textAlign: "left"
  },
  dense: {
    marginTop: 19,
  },
  menu: {
    width: 200,
  },
  paper: {
    position: 'absolute',
    width: 400,
    backgroundColor: theme.palette.background.paper,
    border: '2px solid #000',
    boxShadow: theme.shadows[5],
    padding: theme.spacing(2, 4, 3),
  },
}));
 
const styles = theme => ({
  root: {
      margin: 0,
      padding: theme.spacing(2),
  },
  closeButton: {
      position: 'absolute',
      right: theme.spacing(1),
      top: theme.spacing(1),
      color: theme.palette.grey[500],
  },
});

const DialogTitle = withStyles(styles)(props => {
  const { children, classes, onClose } = props;
  return (
      <MuiDialogTitle disableTypography className={classes.root}>
          <Typography variant="h6">{children}</Typography>
          {onClose ? (
              <IconButton aria-label="close" className={classes.closeButton} onClick={onClose}>
                  <CloseIcon />
              </IconButton>
          ) : null}
      </MuiDialogTitle>
  );
});

const DialogContent = withStyles(theme => ({
  root: {
      padding: theme.spacing(2),
  },
}))(MuiDialogContent);

const DialogActions = withStyles(theme => ({
  root: {
      margin: 0,
      padding: theme.spacing(1),
  },
}))(MuiDialogActions);



export default function TableComponent(props) {
  const [searchValues, setProfileState] = useState(props);
  const filterEvenResults = data.filter(x => {
    if(x.technology == searchValues.searchValues.currency){
      return true;
    }
  })
  const columns = [
    {
      name: 'First Name',
      selector: 'firstname',
      sortable: true,
      cell: row => <div onClick={() => handleOpen(row)} id={row.id} style={{color: "#007bff",  cursor: "pointer", textDecoration: "underline"}}>{row.firstname}</div>,
    
    },
    {
      name: 'Last Name',
      selector: 'lastname',
      sortable: true,
    },
    {
      name: 'CID',
      selector: 'cid',
      sortable: true,
    },
    {
      name: 'Years Of Exp',
      selector: 'yearsofexp',
      sortable: true,
    },
    {
      name: 'Technology',
      selector: 'technology',
      sortable: true,
    },
    // {
    //   name: 'Edit',
    //   // selector: 'edit',
    //   cell : row => <div  onClick={() => handleOpen(row)} id={row.id}><Edit></Edit></div>
    // }
  ];

  const [modalStyle] = React.useState(getModalStyle);
  const [open, setOpen] = React.useState(false);

  const handleOpen = (row) => {
    setDataElement({ 
      id : row.id,
      firstname: row.firstname,
      lastname: row.lastname,
      cid: row.cid,
      yearsofexp: row.yearsofexp,
      technology: row.technology,
    });
    setOpen(true);
  };

  const handleClose = (row) => {
    console.log(row.id);
    data.map(d => {
      if (d.id == row.id) {
        return d;
      }
    })
    setOpen(false);
  };

  const [dataElement, setDataElement] = React.useState({
    id : "",
   firstname : "",
   lastname : "",
   cid : "",
   yearsofexp : "",
   technology : "",
})
  
  const handleChangeDataElement = name => event => {
    setDataElement({ ...dataElement, [name]: event.target.value });
}

  // render() {
    const classes = useStyles();
    const [values, setValues] = React.useState({
        name: '',
    });
    const handleChange = name => event => {
    setValues({  [name]: event.target.value });
    };
    return (
    <div>    
      <DataTable
        title=""
        columns={columns}
        data={filterEvenResults}
        pagination = {true}
        highlightOnHover = {true}
        paginationPerPage = {5}
        paginationRowsPerPageOptions = {[5,10, 15, 20, 25, 30]}
        // selectableRows // add for checkbox selection
        onRowSelected={handleChange}
      />
      <Dialog className="custom-dialog" onClose={() =>handleClose(dataElement)} open={open}>
                            <DialogTitle id="customized-dialog-title" onClose={() =>handleClose(dataElement)}>
                                View 
                            </DialogTitle>
                            <DialogContent dividers>
                                <TextField
                                    id="data-element-name"
                                    disabled
                                    label="First Name"
                                    className={classes.textField}
                                    value={dataElement.firstname}
                                    onChange={handleChangeDataElement('firstname')}
                                />
                                <TextField
                                    id="business-name"
                                    disabled
                                    label="Last Name"
                                    className={classes.textField}
                                    value={dataElement.lastname}
                                    onChange={handleChangeDataElement('lastname')}
                                />
                                <TextField
                                    id="Description"
                                    disabled
                                    label="CID"
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={dataElement.cid}
                                    onChange={handleChangeDataElement('cid')} />
                                <TextField
                                    id="Description"
                                    label="Years of Experience"
                                    disabled
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={dataElement.yearsofexp}
                                    onChange={handleChangeDataElement('yearsofexp')} />
                                <TextField
                                    id="Description"
                                    label="Technology"
                                    disabled
                                    className={classes.textField}
                                    multiline
                                    rowsMax="4"
                                    value={dataElement.technology}
                                    onChange={handleChangeDataElement('technology')} />        
                            </DialogContent>
                            <DialogActions>
                            <Button variant="outlined" color="primary" className='btn btn-primary'>
              Reset
                </Button>
                            </DialogActions>
                        </Dialog>

    
      </div>
    )
  // }
}