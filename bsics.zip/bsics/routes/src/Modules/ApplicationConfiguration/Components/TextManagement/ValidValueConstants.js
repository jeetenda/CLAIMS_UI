export const FUNCTIONAL_AREA_REQUIRED = 'Functional Area Code is a required field if Valid Value Code is entered.';
export const BUSINESS_NAME_ERROR = 'A minimum of 2 characters must be entered for a starts with search and a contains search.';
export const DATA_ELEMENT_NAME_ERROR = 'A minimum of 2 characters must be entered for a starts with search and a contains search.';
