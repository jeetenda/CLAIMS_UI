import React from 'react';
import { connect } from 'react-redux';
import { withTranslation } from 'react-i18next';
// eslint-disable-next-line no-unused-vars
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import * as actions from '../Store/Actions/appConfigActions';

class MyTestComp extends React.Component {
  constructor (props) {
    super(props);
    this.state = { myVal: ' ' };
    this.onFieldChange = this.onFieldChange.bind(this);
  }

  onFieldChange (event) {
    this.setState({ ...this.state, myVal: event.target.value });
  }
  ;
  componentDidMount () {
  // console.log('this.props', this.props);
  }
  ;
  render () {
    const { t, i18n } = this.props;

    const changeLanguage = lng => {
      i18n.changeLanguage(lng);
    };
    return (
      <div>
        { t('TEST') } <br/>
        { t('WELCOME') } <br/>
        { t('APPCONFIG:EMPLOYEE.NAME')} <br/>
        { t('APPCONFIG:EMPLOYEE.ADDRESS.CITY')} <br/>
        { t('APPCONFIG:APPCONTX.LABLES.LOB')} <br/>
        <button onClick={() => changeLanguage('de')}>de</button>
        <button onClick={() => changeLanguage('en')}>en</button>
        <ToastContainer autoClose={1500} />
        {this.state.myVal}
        <br/>
        <input type="text" value = {this.state.myVal} onChange = { (event) => { this.onFieldChange(event); } }/>
        <br/>
        <button onClick = { () => { this.props.onFetch(this.state.myVal); } }>Set Redux</button>
        <br/>
        <div>I am seting from redux {this.props.retrunval ? this.props.retrunval : 'value not set' } </div>
      </div>
    );
  };
}

const mapStateToProps = (state, ownProps) => {
  return {
    retrunval: state.appConfigState.temp,
    myname: state.appConfigState.name
  };
};

const mapDispatchToProps = dispatch => {
  return {
    onFetch: (par) => dispatch(actions.fetchValue(par))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(withTranslation()(MyTestComp));
