import * as actionTypes from './mapSetActionTypes';
import * as serviceEndPoint from '../../../services/service';

import axios from 'axios';
const headers = {
  'Access-Control-Allow-Origin': '*'
};

export const resetSearchMapSet = () => {
  return {
    type: actionTypes.RESETDATA,
    resetData: []
  };
};

export const resetAddMapSet = () => {
  return {
    type: actionTypes.RESET_ADD_DATA
  };
};

export const mapSetAction = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.MAP_SET_SEARCH_ENDPOINT}`, value, { headers: headers })

      .then(response => {
        console.log(response.data);
        if (response.data.searchResults === undefined) {
          dispatch(setMapSet([]));
        } else {
          dispatch(setMapSet(response.data.searchResults));
        }
      })
      .catch(error => {
        console.log(error);
        dispatch(setMapSet({ systemFailue: true }));
      });
  };
};
export const mapSetActionView = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.MAP_SET_SEARCH_ENDPOINT}`, value, { headers: headers })

      .then(response => {
        dispatch(setmapSetView(response.data.searchResults));
      });
  };
};
export const systemListActions = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_SEARCH_ENDPOINT_NEW}`, value)
      .then(response => {
        if (response.data.searchResults === undefined) {
          dispatch(setSystemList([]));
        } else {
          dispatch(setSystemList(response.data.searchResults));
        }
      })
      .catch(error => {
        dispatch(setSystemList([]));
        console.log(error);
      });
  };
};
export const mapDefinitionAdd = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.MAP_DEFINITION_ADD}`, value)
      .then(response => {
        dispatch(setAddMapDefinition(response));
      })
      .catch(error => {
        console.log(error);
        dispatch(setAddMapDefinition({ systemError: true }));
      });
  };
};
export const mapDefinitionUpdate = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.MAP_DEFINITION_UPDATE}`, value)
      .then(response => {
        dispatch(setUpdateMapDefinition(response));
      })
      .catch(error => {
        console.log(error);
        dispatch(setUpdateMapDefinition({ systemError: true }));
      });
  };
};
export const getSubDropdownDataAction = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.VALID_VALUE_DROPDOWNS}`, value)
      .then(response => {
        dispatch(setSubDropdownData(response.data));
      })
      .catch(error => {
        dispatch(setSubDropdownData(error));
      });
  };
};

export const setSubDropdownData = (subdropdownData) => {
  return {
    type: actionTypes.MAPSET_NOTES_DATA,
    usageDropDown: subdropdownData
  };
};
export const setMapSet = (mapSet) => {
  return {
    type: actionTypes.MAP_SET_ACTION_TYPE,
    mapSet: mapSet
  };
};
export const setmapSetView = (mapSetView) => {
  return {
    type: actionTypes.MAP_SET_VIEW_ACTION_TYPE,
    mapSetView: mapSetView
  };
};
export const setAddMapDefinition = (addResponse) => {
  return {
    type: actionTypes.MAP_DEFINITION_ADD_TYPE,
    addResult: addResponse
  };
};
export const setUpdateMapDefinition = (updateResponse) => {
  return {
    type: actionTypes.MAP_DEFINITION_UPDATE_TYPE,
    updateResult: updateResponse
  };
};
export const setSystemList = (systemList) => {
  return {
    type: actionTypes.SEARCH_SYSTEM_LIST,
    systemLists: systemList
  };
};
