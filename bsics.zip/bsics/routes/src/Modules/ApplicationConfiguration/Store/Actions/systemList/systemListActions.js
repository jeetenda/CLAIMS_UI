import * as actionTypes from './systemListActionTypes';
import * as serviceEndPoint from '../../../services/service';
import axios from 'axios';

export const resetSystemList = () => {
  return {
    type: actionTypes.RESET_DATA,
    resetData: []
  };
};

export const systemListActions = (value) => {
  console.log("clicking system list search action",value)
  return dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_SEARCH_ENDPOINT}`, value)
      .then(response => {
        if (response.data.searchResults === undefined) {
          dispatch(setSystemList([]));
        } else {
          dispatch(setSystemList(response.data.searchResults));
        }
      })
      .catch(error => {
        dispatch(setSystemList(null));
        console.log(error);
      });
  };
};

export const systemListViewAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_SEARCH_ENDPOINT}`, value)
      .then(response => {
        console.log(response.data);
        dispatch(setSystemListRow(response.data.searchResults));
      })
      .catch(error => {
        console.log(error);
      });
  };
};

export const addSystemListAction = (value, logInId) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_ADD}?userIDStr=`+logInId, value)
      .then(response => {
        dispatch(setSystemListAdd(response.data));
      })
      .catch(error => {
        
        dispatch(setSystemListAdd("",true));

      });
  };
};

export const updateSystemList = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_LIST_UPDATE}?userIDStr=${value.auditUserID}`, value)
      .then(response => {
        console.log(response.data);
        dispatch(setSystemListUpdate(response.data));
      })
      .catch(error => {
        console.log(error);
      });
  };
};

export const getSubDropdownDataAction = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.VALID_VALUE_DROPDOWNS}`, value)
      .then(response => {
        dispatch(setSubDropdownData(response.data));
      })
      .catch(error => {
        dispatch(setSubDropdownData(error));
      });
  };
};

export const setSubDropdownData = (subdropdownData) => {
  return {
    type: actionTypes.SYSTEM_LIST_NOTE,
    usageDropDown: subdropdownData
  };
};

export const setSystemList = (systemList) => {
  return {
    type: actionTypes.SEARCH_SYSTEM_LIST,
    systemLists: systemList
  };
};

export const setSystemListAdd = (systemlistAddResponse,isError=false) => {
if(isError===false){
  return {
    type: actionTypes.SYSTEM_LIST_ADD,
    systemListAddResponse: systemlistAddResponse
  };

}
else{
console.log("setSystemListAdd",isError)
  return {
    
    type: "SYSTEM_LIST_ERROR",

  };

}

};

export const setSystemListUpdate = (systemListUpdateResponse) => {
  return {
    type: actionTypes.SYSTEM_LIST_UPDATE,
    systemListUpdateResponse: systemListUpdateResponse
  };
};

export const setSystemListRow = (data) => {
  return {
    type: actionTypes.SYSTEM_LIST_VIEW,
    rowsearchsyslist: data
  };
};
