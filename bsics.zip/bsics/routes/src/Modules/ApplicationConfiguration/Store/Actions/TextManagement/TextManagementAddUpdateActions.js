import * as actionTypes from './TextManagementActionTypes';
import * as serviceEndPoint from '../../../services/service';
import axios from 'axios';

export const TextManagementDeleteEOMBAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_DELETE_EOMBTEXT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response);
        dispatch(SetSpinner(false));
        dispatch(TextManagementDeleteEOMB(data));
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementDeleteEOMB(error));
      });
  };
};

export const TextManagementDeleteRAEOBAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANGEMENT_DELETE_RAEOB}`, value)
      .then(response => {
        console.log(response.data);
        let data = [];
        data = response.data;
        dispatch(SetSpinner(false));
        dispatch(TextManagementDeleteRAEOB(data));
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementDeleteRAEOB(error));
      });
  };
};

export const TextManagementUpdateEOMBAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_UPDATE_EOMB_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response);
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateEOMB(data));
        if (response.data === undefined) {
          dispatch(TextManagementUpdateEOMB([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateEOMB(error));
      });
  };
};

export const TextManagementAddEOMBAction = (value) => {
  console.log(value,"textmanagement ss")
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_ADD_EOMB_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response);
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddEOMB(data));
        if (response.data && response.data.respcode === '01') {
          dispatch(EOMBGetRecordAction(
            {
              eombProcedureTypeCode: value.eombType,
              lobCode: [value.lob],
              eombFromCode: value.eombFromCode,
              eombthruCode: value.eombThruCode,
              eombText: value.eombDesc,
              eombTextStartsOrContains: null,
              fromModifier1: value.fromModifier1 ? value.fromModifier1 : null,
              fromModifier2: value.fromModifier2 ? value.fromModifier2 : null,
              fromModifier3: value.fromModifier3 ? value.fromModifier3 : null,
              fromModifier4: value.fromModifier4 ? value.fromModifier4 : null,
              thruModifier1: value.thruModifier1 ? value.thruModifier1 : null,
              thruModifier2: value.thruModifier2 ? value.thruModifier2 : null,
              thruModifier3: value.thruModifier3 ? value.thruModifier3 : null,
              thruModifier4: value.thruModifier4 ? value.thruModifier4 : null
            }
          ));
        }
        if (response.data === undefined) {
          dispatch(TextManagementAddEOMB([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddEOMB(error));
      });
  };
};

export const TextManagementUpdateProviderNoticeAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_UPDATE_PN_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response);
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateProviderNotice(data));
        if (response.data === undefined) {
          dispatch(TextManagementUpdateProviderNotice([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateProviderNotice(error));
      });
  };
};
export const TextManagementAddProviderNoticeAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_ADD_PN_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response);
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddProviderNotice(data));
        if (response.data && response.data.respcode === '01' && response.data.enterpriseBaseVO) {
          dispatch(providerNoticeGetRecordAction(
            {
              providerTextSk: response.data.enterpriseBaseVO.textRALetterSK
            }
          ));
        }
        if (response.data === undefined) {
          dispatch(TextManagementAddProviderNotice([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddProviderNotice(error));
      });
  };
};

export const TextManagementUpdateRAEOBAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_UPDATE_RAEOB_ENDPOINT}`, value)
      .then(response => {
        console.log(response.data);
        let data = [];
        data = response.data;
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateRAEOB(data));
        if (response.data === undefined) {
          dispatch(TextManagementUpdateRAEOB([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateRAEOB(error));
      });
  };
};
export const TextManagementAddRAEOBAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_ADD_RAEOB_ENDPOINT}`, value)
      .then(response => {
        console.log(response.data);
        let data = [];
        data = response.data;
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddRAEOB(data));
        if (response.data && response.data.respcode === '01') {
          dispatch(RaeobGetRecordAction(
            {
              eobText: value.eobDesc,
              lobCode: [value.lobCode],
              claimEOBCode: value.claimEOBCode,
              eobTextStartsOrContains: null
            }
          ));
        }
        if (response.data === undefined) {
          dispatch(TextManagementAddRAEOB([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddRAEOB(error));
      });
  };
};

export const TextManagementUpdateRemarkTextAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_UPDATE_REMARK_TEXT_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response.data);
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateRemarkText(data));
        if (response.data === undefined) {
          dispatch(TextManagementUpdateRemarkText([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateRemarkText(error));
      });
  };
};
export const TextManagementAddRemarkTextAction = (value) => {
  console.log(value,"remark codessssss");
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_ADD_REMARK_TEXT_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response.data);
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddRemarkText(data));
        if (response.data && response.data.respcode === '01') {
          dispatch(RemarkTextGetRecordAction(
            {
              remarkCode: value.remarkCode,
              remarkText: value.remarkText,
              remarkTextStartsOrContains: null
            }
          ));
        }
        if (response.data === undefined) {
          dispatch(TextManagementAddRemarkText([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddRemarkText(error));
      });
  };
};

export const TextManagementUpdateAdjustmentReasonAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_UPDATE_ADJUSTMENT_REASON_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response.data);
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateAdjustmentReason(data));
        if (response.data === undefined) {
          dispatch(TextManagementUpdateAdjustmentReason([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateAdjustmentReason(error));
      });
  };
};

export const TextManagementAddAdjustmentReasonAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_ADD_ADJUSTMENT_REASON_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response.data);
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddAdjustmentReason(data));
        if (response.data && response.data.respcode === '01') {
          dispatch(AdjustmentReasonRecordAction(
            {
              adjustmentReasonCode: value.adjustmentReasonCode,
              adjustmentReasonText: value.adjustmentReasonText,
              adjustmentReasonTextStartsOrContains: null
            }
          ));
        }
        if (response.data === undefined) {
          dispatch(TextManagementAddAdjustmentReason([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddAdjustmentReason(error));
      });
  };
};

export const TextManagementUpdateServiceAuthReasonAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_UPDATE_SA_REASON_ENDPOINT}/${value.auditUserID}`, value)
      .then(response => {
        let data = [];
        if(response.data !== undefined){response.data['respcode'] = '01';}
        data = response.data;
        console.log(response.data);
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateSAReason(data));
        if (response.data === undefined) {
          dispatch(TextManagementUpdateSAReason([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateSAReason(error));
      });
  };
};

export const TextManagementAddServiceAuthReasonAction = (value) => {
  console.log("actions",value);
  console.log("service EndPoint:TextManagementAddServiceAuthReasonAction ",serviceEndPoint.TEXT_MANAGEMENT_ADD_SA_REASON_ENDPOINT);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_ADD_SA_REASON_ENDPOINT}/${value.auditUserID}`, value)
      .then(response => {
        let data = [];
        //to manage success msg
        if(response.data !== undefined && response.data.status === 'Success'){response.data['respcode'] = '01';}
        data = response.data;
        dispatch(SetSpinner(false));
        if (response.data && response.data.status === 'Success' && response.data.respcode === '01') {
          dispatch(TextManagementAddSAReason(data));
          dispatch(SAReasonRecordAction(
            {
              "authorizationReasonCode":value.authorizationReasonCode,
              "authorizationReasonText":value.text,
              "authorizationReasonTextStartsOrContains":null
              
            }
          ));
        }
        if(response.data && response.data.status === '400'){
          dispatch(TextManagementAddSAReason(data));
        }
        if (response.data === undefined) {
          dispatch(TextManagementAddSAReason([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddSAReason(error));
      });
  };
};

export const TextManagementDeleteServiceAuthReasonAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_DELETE_SA_REASON_ENDPOINT}/${value.auditUserID}`, value)
      .then(response => {
        console.log(response.data);
        let data = [];
        response.data['respcode'] = '01';
        data = response.data;
        dispatch(SetSpinner(false));
        dispatch(TextManagementDeleteSAReason(data));
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementDeleteSAReason(error));
      });
  };
};

export const TextManagementDeleteSAReason = (data) => {
  return {
    type: actionTypes.DELETE_TEXT_SA_REASON,
    SAdeletedResult: data
  };
};

export const TextManagementUpdateNCPDPAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_UPDATE_NCPDP_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response.data);
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateNCPDP(data));
        if (response.data === undefined) {
          dispatch(TextManagementUpdateNCPDP([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        dispatch(SetSpinner(false));
        dispatch(TextManagementUpdateNCPDP(error));
      });
  };
};
export const TextManagementAddNCPDPAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_NCPDP_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data;
        console.log(response.data);
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddNCPDP(data));
        if (response.data && response.data.respcode === '01') {
          dispatch(NCPDPGetRecordAction(
            {
              ncpdpRejectCode: value.ncpdpRejectCode,
              ncpdpRejectCodeText: value.ncpdpRejectCodeText,
              ncpdpRejectCodeStartsOrCopntains: null
            }
          ));
        }
        if (response.data === undefined) {
          dispatch(TextManagementAddNCPDP([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
        // dispatch(TextManagementAddNCPDP([]));
        dispatch(SetSpinner(false));
        dispatch(TextManagementAddNCPDP(error));
      });
  };
};
export const EOMBGetRecordAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_SP_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data.searchResults;
        console.log(response);
        dispatch(EOMBGetRecord(data));
        if (response.data.searchResults === undefined) {
          dispatch(EOMBGetRecord([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
      });
  };
};
export const EOMBGetRecord = (EOMBText) => {
  return {
    type: actionTypes.GET_EOMB_TEXT,
    EOMBText: EOMBText
  };
};
export const RemarkTextGetRecordAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_RC_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data.searchResults;
        console.log('response');
        console.log(response);
        dispatch(RemarkTextGetRecord(data));
        if (response.data.searchResults === undefined) {
          dispatch(RemarkTextGetRecord([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
      });
  };
};
export const RemarkTextGetRecord = (RemarkText) => {
  return {
    type: actionTypes.GET_REMARK_TEXT,
    RemarkText: RemarkText
  };
};
export const AdjustmentReasonRecordAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_ARC_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data.searchResults;
      

        console.log(response);
        dispatch(AdjustmentReasonRecord(data));
        if (response.data.searchResults === undefined) {
          dispatch(AdjustmentReasonRecord([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
      });
  };
};
export const AdjustmentReasonRecord = (ARText) => {
  return {
    type: actionTypes.GET_ADJUSTMENT_TEXT,
    ARText: ARText
  };
};
export const NCPDPGetRecordAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_NCPDP_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data.searchResults;
        console.log('response');

        console.log(response);
        dispatch(NCPDPGetRecord(data));
        if (response.data.searchResults === undefined) {
          dispatch(NCPDPGetRecord([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
      });
  };
};
export const NCPDPGetRecord = (NcpdpText) => {
  return {
    type: actionTypes.GET_NCPDP_TEXT,
    NcpdpText: NcpdpText
  };
};
export const providerNoticeGetRecordAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_PN_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data.searchResults;
        console.log('response');

        console.log(response);
        dispatch(providerNoticeGetRecord(data));
        if (response.data.searchResults === undefined) {
          dispatch(providerNoticeGetRecord([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
      });
  };
};
export const RaeobGetRecordAction = (value) => {
  console.log(value);
  return dispatch => {
    return axios.post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_RAEOB_ENDPOINT}`, value)
      .then(response => {
        let data = [];
        data = response.data.searchResults;
        console.log('response');

        console.log(response);
        dispatch(RaeobGetRecord(data));
        if (response.data.searchResults === undefined) {
          dispatch(RaeobGetRecord([]));
        }
      })
      .catch(error => {
        console.log(error, 'TextManagement error');
      });
  };
};

export const RaeobGetRecord = (RaeobText) => {
  return {
    type: actionTypes.GET_RAEOB_TEXT,
    RaeobText: RaeobText
  };
};
export const providerNoticeGetRecord = (PNText) => {
  return {
    type: actionTypes.GET_PROVIDER_NOTICE_TEXT,
    PNText: PNText
  };
};
export const TextManagementDeleteEOMB = (EOMBData) => {
  return {
    type: actionTypes.DELETE_TEXT_EOMB_TEXT,
    EOMBDelResult: EOMBData
  };
};

export const TextManagementDeleteRAEOB = (RAEOBData) => {
  return {
    type: actionTypes.DELETE_TEXT_RAEOB,
    RAEOBDelResult: RAEOBData
  };
};

export const TextManagementUpdateEOMB = (EOMBData) => {
  return {
    type: actionTypes.UPDATE_TEXT_EOMB_TEXT,
    EOMBData: EOMBData
  };
};
export const TextManagementAddEOMB = (EOMBData) => {
  return {
    type: actionTypes.ADD_TEXT_EOMB_TEXT,
    EOMBData: EOMBData
  };
};

export const TextManagementUpdateNCPDP = (NCPDPData) => {
  return {
    type: actionTypes.UPDATE_TEXT_NCPDP_TEXT,
    NCPDPData: NCPDPData
  };
};

export const TextManagementAddNCPDP = (NCPDPData) => {
  return {
    type: actionTypes.ADD_TEXT_NCPDP_TEXT,
    NCPDPData: NCPDPData
  };
};
export const TextManagementUpdateAdjustmentReason = (AdjustmentReasonData) => {
  return {
    type: actionTypes.UPDATE_TEXT_ADJUSTMENT_REASON,
    AdjustmentReasonData: AdjustmentReasonData
  };
};
export const TextManagementAddAdjustmentReason = (AdjustmentReasonData) => {
  return {
    type: actionTypes.ADD_TEXT_ADJUSTMENT_REASON,
    AdjustmentReasonData: AdjustmentReasonData
  };
};

export const TextManagementUpdateRemarkText = (RemarkTextData) => {
  return {
    type: actionTypes.UPDATE_TEXT_REMARKTEXT,
    RemarkTextData: RemarkTextData
  };
};

export const TextManagementAddRemarkText = (RemarkTextData) => {
  return {
    type: actionTypes.ADD_TEXT_REMARKTEXT,
    RemarkTextData: RemarkTextData
  };
};
export const TextManagementUpdateRAEOB = (RAEOBData) => {
  return {
    type: actionTypes.UPDATE_TEXT_RAEOB,
    RAEOBData: RAEOBData
  };
};
export const TextManagementAddRAEOB = (RAEOBData) => {
  return {
    type: actionTypes.ADD_TEXT_RAEOB,
    RAEOBData: RAEOBData
  };
};

export const TextManagementUpdateProviderNotice = (PNData) => {
  return {
    type: actionTypes.UPDATE_TEXT_PN,
    PNData: PNData
  };
};

export const TextManagementAddProviderNotice = (PNData) => {
  return {
    type: actionTypes.ADD_TEXT_PN,
    PNData: PNData
  };
};
export const SetSpinner = (value) => {
  return {
    type: actionTypes.SET_SPINNER_VALUE,
    showSpinner: value
  };
};
export const ResetData = () => {
  return {
    type: actionTypes.RESET_FIELD
  };
};
