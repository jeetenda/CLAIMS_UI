export const ADD_VALUE = 'ADD_VALUE';
export const REMOVE_VALUE = 'REMOVE_VALUE';
export const SET_VALUE = 'SET_VALUE';
export const FETCH_VALUE = 'FETCH_VALUE';
