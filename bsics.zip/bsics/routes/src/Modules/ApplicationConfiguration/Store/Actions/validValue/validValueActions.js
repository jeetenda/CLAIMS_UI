import * as actionTypes from './validValueActionTypes';
import * as serviceEndPoint from '../../../services/service';

import axios from 'axios';

export const resetSearchValidValue = () => {
  return {
    type: actionTypes.RESETDATA,
    resetData: []
  };
};

export const ValidValueUpdateAction = (values) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.VALID_VALUE_UPDATE_ENDPOINT}`, values)

      .then(response => {
        dispatch(setValidValueUpdate(response.data));
      })
      .catch(error => {
        dispatch(setValidValueUpdate({ systemError: true }));
        console.log(error);
      });
  };
};

export const validValueAction = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.VALID_VALUE_SEARCH_ENDPOINT}`, value)
      .then(response => {
        dispatch(setValidValue(response.data.searchResults));
      })
      .catch(error => {
        console.log(error);
        dispatch(setValidValue(error));
      });
  };
};

export const validValueViewAction = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.VALID_VALUE_SEARCH_ENDPOINT}`, value)
      .then(response => {
        dispatch(setValidValue(response.data.searchResults));
      })
      .catch(error => {
        console.log(error);
      });
  };
};

export const setValidValueUpdate = (validValueUpdate) => {
  return {
    type: actionTypes.VALID_VALUE_UPDATE_ACTION_TYPE,
    validValueUpdate: validValueUpdate
  };
};
export const setValidValue = (validValue) => {
  return {
    type: actionTypes.VALID_VALUE_ACTION_TYPE,
    validValue: validValue
  };
};

export const setValidValueView = (validValueView) => {
  return {
    type: actionTypes.VALID_VALUE_VIEW_ACTION_TYPE,
    validValueView: validValueView
  };
};
