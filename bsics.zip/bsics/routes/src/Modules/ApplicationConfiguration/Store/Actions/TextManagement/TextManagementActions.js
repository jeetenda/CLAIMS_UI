import * as actionTypes from "./TextManagementActionTypes";
import * as serviceEndPoint from "../../../services/service";
import axios from "axios";

export const searchSystemParameterAction = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response.data.searchResults);
        dispatch(setSystemParameter(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameter({ systemError: true }));
      });
  };
};

export const searchSystemParameterActionRAEOB = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_RAEOB_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response.data.searchResults);
        dispatch(setSystemParameter(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameter({ systemError: true }));
      });
  };
};

export const searchSystemParameterActionPN = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_PN_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response.data.searchResults);
        dispatch(setSystemParameter(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameter({ systemError: true }));
      });
  };
};

export const searchSystemParameterActionSP = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_SP_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response.data.searchResults);
        dispatch(setSystemParameter(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameter({ systemError: true }));
      });
  };
};

export const searchSystemParameterActionRevenue = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_REVENUE_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response.data.searchResults);
        dispatch(setSystemParameter(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameter({ systemError: true }));
      });
  };
};

export const systemParameterRowClickAction = (value) => {
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        dispatch(setSystemParameter(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameter({ systemError: true }));
      });
  };
};

export const providerNoticeRowClickAction = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_PN_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log("response");

        console.log(response);
        dispatch(setSystemParameterPNRowData(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameterPNRowData([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameterPNRowData({ systemError: true }));
      });
  };
};

export const RAEOBRowClickAction = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_RAEOB_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log("response");

        console.log(response);
        dispatch(setSystemParameter(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameter({ systemError: true }));
      });
  };
};

export const searchSystemParameterActionRC = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_RC_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults ? response.data.searchResults : [];
        console.log(response.data.searchResults);
        dispatch(setSystemParameterRC(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameterRC([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameterRC({ systemError: true }));
      });
  };
};

export const searchSystemParameterActionARC = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_ARC_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response.data);

        dispatch(setSystemParameterARC(data, response.data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameterARC([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameterARC({ systemError: true }));
      });
  };
};

export const searchSystemParameterActionNCPDP = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_NCPDP_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response);
        dispatch(setSystemParameterNCPDP(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameterNCPDP([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameterNCPDP({ systemError: true }));
      });
  };
};

export const NCPDPRowClickAction = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_NCPDP_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response);
        dispatch(setSystemParameterNCPDPRow(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameterNCPDPRow([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameterNCPDPRow({ systemError: true }));
      });
  };
};

export const ARRowClickAction = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_ARC_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response);

        dispatch(setSystemParameterARRow(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameterARRow([]));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameterARRow({ systemError: true }));
      });
  };
};

export const RCRowClickAction = (value) => {
  console.log(value);
  return (dispatch) => {
    return axios
      .post(`${serviceEndPoint.TEXT_MANAGEMENT_SEARCH_RC_ENDPOINT}`, value)
      .then((response) => {
        let data = [];
        data = response.data.searchResults;
        console.log(response);
        dispatch(setSystemParameterRCRow(data));
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameterRCRow({}));
        }
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(setSystemParameterRCRow({ systemError: true }));
      });
  };
};

export const resetSearchTextManagement = () => {
  return {
    type: actionTypes.RESETDATA,
    resetData: [],
  };
};

export const setSystemParameter = (eombData) => {
  return {
    type: actionTypes.SEARCH_TEXT_MANAGEMENT,
    eombData: eombData,
  };
};

export const setSystemParameterRAEOB = (RAEOBData) => {
  return {
    type: actionTypes.SEARCH_TEXT_RAEOB,
    RAEOBData: RAEOBData,
  };
};

export const setSystemParameterPN = (PNData) => {
  return {
    type: actionTypes.SEARCH_TEXT_PN,
    PNData: PNData,
  };
};

export const setSystemParameterSP = (SPData) => {
  return {
    type: actionTypes.SEARCH_TEXT_SP,
    SPData: SPData,
  };
};

export const setSystemParameterRevenue = (RevenueData) => {
  return {
    type: actionTypes.SEARCH_TEXT_REVENUE,
    RevenueData: RevenueData,
  };
};

export const setSystemParameterPNRowData = (PNRowData) => {
  return {
    type: actionTypes.SEARCH_TEXT_PNROW,
    PNRowData: PNRowData,
  };
};

export const setSystemParameterRAEOBRowData = (RAEOBRowData) => {
  return {
    type: actionTypes.SEARCH_TEXT_RAEOBROW,
    RAEOBRowData: RAEOBRowData,
  };
};

export const setSystemParameterRC = (RCData) => {
  return {
    type: actionTypes.SEARCH_TEXT_RC,
    RCData: RCData,
  };
};

export const setSystemParameterARC = (ARCData, searchResults) => {
  return {
    type: actionTypes.SEARCH_TEXT_ARC,
    ARCData: ARCData,
    searchResults: searchResults,
  };
};

export const setSystemParameterNCPDP = (NCPDPData) => {
  return {
    type: actionTypes.SEARCH_TEXT_NCPDP,
    NCPDPData: NCPDPData,
  };
};

export const setSystemParameterNCPDPRow = (NCPDPRowData) => {
  return {
    type: actionTypes.SEARCH_TEXT_NCPDPROW,
    NCPDPRowData: NCPDPRowData,
  };
};

export const setSystemParameterARRow = (ARRowData) => {
  return {
    type: actionTypes.SEARCH_TEXT_ARROW,
    ARRowData: ARRowData,
  };
};

export const ResetTextSearchReducer = () => {
  return {
    type: actionTypes.RESET_TEXT_SEARCH,
  };
};
export const setSystemParameterRCRow = (RCRowData) => {
  return {
    type: actionTypes.SEARCH_TEXT_RCROW,
    RCRowData: RCRowData,
  };
};

export const ProviderSpecialtyDataSearchAction = (ProviderCode) => {
  return (dispatch) => {
    return axios
      .get(`${serviceEndPoint.PROVIDER_SPECIALTY_ENDPOINT}${ProviderCode}`)
      .then((response) => {
        console.log(response.data.providerSpecialityList);
        if (response) {
          console.log(response, "Functional data");
        }
        // console.log()
        dispatch(ProviderSpecialtyData(response.data.providerSpecialityList));
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(ProviderSpecialtyData({ systemError: true }));
      });
  };
};

export const ProviderSpecialtyDataAction = (ProviderCode) => {
  return (dispatch) => {
    console.log(ProviderCode.code);
    return axios
      .get(`${serviceEndPoint.PROVIDER_SPECIALTY_ENDPOINT}${ProviderCode.code}`)
      .then((response) => {
        console.log(response.data.providerSpecialityList);
        if (response) {
          console.log(response, "Functional data");
        }
        dispatch(ProviderSpecialtyData(response.data.providerSpecialityList));
      })
      .catch((error) => {
        console.log(error, "TextManagement error");
        dispatch(ProviderSpecialtyData({ systemError: true }));
      });
  };
};
export const ProviderSpecialtyData = (ProviderSpecialtyData) => {
  return {
    type: actionTypes.PROVIDER_SPECIALTY_DATA,
    ProviderSpecialtyData: ProviderSpecialtyData,
  };
};
