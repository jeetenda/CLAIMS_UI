import * as actionTypes from './systemParameterActionTypes';
import * as serviceEndPoint from '../../../services/service';
import axios from 'axios';
import * as ERRORS from '../../../Components/SystemParameter/systemParameterConstants';

export const resetSearchSystemParameters = () => {
  return {
    type: actionTypes.RESETDATA,
    resetData: []
  };
};

export const searchSystemParameterAction = (value, parameterNumberStartsWith) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.SYSTEM_PARAMETER_MULTI_SEARCH_ENDPOINT}`, value)
      .then(response => {
        if (response.data.searchResults === undefined) {
          dispatch(setSystemParameter([]));
        } else {
          dispatch(setSystemParameter(response.data.searchResults));
        }
      })
      .catch(error => {
        dispatch(setSystemParameterError({ systemFailue: ERRORS.SYSTEM_ERROR }));
        console.log(error);
      });
  };
};

export const setSystemParameterError = (data) => {
  return {
    type: actionTypes.SYSTEM_ERROR,
    systemError: data
  };
};
// below fuction is associated with table in search(on click event)
export const systemParameterRowClickAction = (value) => {
  console.log(value,"value")
  return dispatch => {
    return axios.get(`${serviceEndPoint.SYSTEM_PARAMETER_SEARCH_ENDPOINT}?paramNumber=${value.parameterNumber}&functionalArea=${value.functionalArea}`)
      .then(response => {
        console.log(response,"response")
        dispatch(setSystemParameterRow(response.data));
      })
      .catch(error => {
        console.log(error);
      });
  };
};

export const updateSystemParameter = (value) => {
  // 
  return dispatch => {
    return axios.post(`${serviceEndPoint.UPDATE_SYSTEMPARAMETER}`, value)
      .then(response => {
        

        dispatch(setUpdateSystemParameter(response));
      }).catch(error => {
        console.log(error);
        dispatch(setUpdateSystemParameter({ systemError: true }));
      });
  };
};

export const addSystemParameter = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.ADD_SYSTEM_PARAMETER}`+"?userIDStr=RSHANK", value)
      .then(response => {
        dispatch(setAddSystemParameter(response));
      }).catch(error => {
        console.log(error);
        dispatch(setAddSystemParameter({ systemError: true }));
      });
  };
};

export const setUpdateSystemParameter = (value) => {
  return {
    type: actionTypes.UPDATE_SYSTEM_PARAMETER,
    updateSystemParameter: value
  };
};

export const setAddSystemParameter = (value) => {
  return {
    type: actionTypes.ADD_SYSTEM_PARAMETER,
    addSystemParameter: value
  };
};

export const setSystemParameter = (systemParameters) => {
  return {
    type: actionTypes.SEARCH_SYSTEM_PARAMETER,
    systemParameters: systemParameters
  };
};

export const setSystemParameterRow = (data) => {
  return {
    type: actionTypes.ROW_SEARCH_SYSTEM_PARAMETER,
    rowsearchsysparam: data
  };
};
