import * as actionTypes from './appConfigActionTypes';

export const addValue = (name) => {
  return {
    type: actionTypes.ADD_VALUE,
    value: name
  };
};

export const removeValue = (name) => {
  return {
    type: actionTypes.REMOVE_VALUE,
    value: name
  };
};

export const setValue = (ingredients) => {
  return {
    type: actionTypes.SET_VALUE,
    value: ingredients
  };
};

export const fetchValue = (val) => {
  return {
    type: actionTypes.FETCH_VALUE,
    value: val
  };
};
