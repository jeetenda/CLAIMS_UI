import * as actionTypes from './AppConfigActionTypes';
import * as serviceEndPoint from '../../../services/service';
import axios from 'axios';

export const AppConfigDropdownActions = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.APP_CONFIG_DROPDOWN}`, value)
      .then(response => {
        console.log(response.data);
        dispatch(AppConfigDropdown(response.data));
      })
      .catch(error => {
        dispatch(AppConfigDropdown(error));
      });
  };
};
export const AppConfigDropdown = (appConfigDropdown) => {
  return ({
    type: actionTypes.APP_CONFIG_DROPDOWNS,
    appConfigDropdown: appConfigDropdown
  });
};

export const DataElementDropdownActions = () => {
  return dispatch => {
    return axios.get(`${serviceEndPoint.DATA_ELEMENT_DROPDOWN}`)
      .then(response => {
        console.log(response.data);
        dispatch(DataElementDropdown(response.data));
      })
      .catch(error => {
        dispatch(DataElementDropdown(error));
      });
  };
};
export const DataElementDropdown = (dataElementNameDropdown) => {
  return ({
    type: actionTypes.DATA_ELEMENT_NAME_DROPDOWNS,
    dataElementNameDropdown: dataElementNameDropdown
  });
};

export const DataElementMapDropdownActions = () => {
  return dispatch => {
    return axios.get(`${serviceEndPoint.DATA_ELEMENT_MAP_DROPDOWN}`)
      .then(response => {
        console.log(response.data);
        dispatch(DataElementMapDropdown(response.data));
      })
      .catch(error => {
        dispatch(DataElementMapDropdown(error));
      });
  };
};
export const DataElementMapDropdown = (dataElementMapDropdown) => {
  return ({
    type: actionTypes.DATA_ELEMENT_MAP_NAME_DROPDOWNS,
    dataElementMapDropdown: dataElementMapDropdown
  });
};

export const ModifierDropdownActions = () => {
  //`${serviceEndPoint.MODIFIER_DROPDOWN}`
  
  return dispatch => {
    return axios.post(`${process.env.NODE_APP_HOST_ENV}SystemList/getReferenceData`,{

      "inputList": [
  
          {
  
              "functionalArea": "Reference",
  
              "elementName": null,
  
              "lobCode": null,
  
              "listNumber": 1029,
  
              "listType": null,
  
              "listDate": null,
  
              "paramNumber": null,
  
              "key": null,
  
              "fDOS": null
  
          }
  
      ]
  
  })
      .then(response => {
        //for modifier dropdowns in text management 
        dispatch(ModifierDropdown(response.data));
      })
      .catch(error => {
        
        
        dispatch(ModifierDropdown(error));

      });
  };
};
export const ModifierDropdown = (modifierDropdown) => {
  return ({
    type: actionTypes.MODIFIER_DROPDOWNS,
    modifierDropdown: modifierDropdown
  });
};
// notes usageType dropdown
export const notesUsageTypeDropdown = (value) => {
  return dispatch => {
    return axios.post(`${serviceEndPoint.VALID_VALUE_DROPDOWNS}`, value)
      .then(response => {
        dispatch(setUsageTypeDropdown(response.data));
      })
      .catch(error => {
        dispatch(setUsageTypeDropdown(error));
      });
  };
};

export const setUsageTypeDropdown = (subdropdownData) => {
  return {
    type: actionTypes.NOTES_USAGE_TYPE_DROPDOWNS,
    usageDropDown: subdropdownData
  };
};
