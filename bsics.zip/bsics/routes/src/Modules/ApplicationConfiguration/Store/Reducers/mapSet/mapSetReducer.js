import * as actionTypes from '../../Actions/MapSet/mapSetActionTypes';

const axiosPayLoad = {
  payload: null,
  lobDropDown: []
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.MAP_SET_ACTION_TYPE:
      return { ...state, payload: action.mapSet };
    case actionTypes.MAP_SET_VIEW_ACTION_TYPE:
      return { ...state, mapSetView: action.mapSetView };
    case actionTypes.MAP_DEFINITION_ADD_TYPE:
      return { ...state, addResponse: action.addResult };
    case actionTypes.MAP_DEFINITION_UPDATE_TYPE:
      return { ...state, updateResponse: action.updateResult };
    case actionTypes.SEARCH_SYSTEM_LIST:
      return { systemLists: action.systemLists };
    case actionTypes.MAPSET_NOTES_DATA:
      return { usageDropDown: action.usageDropDown };
    case actionTypes.RESETDATA:
      return action.resetData;
    case actionTypes.RESET_ADD_DATA:
      return { ...state, addResponse: null };
    default: return state;
  }
};

export default reducer;
