import * as actionTypes from '../../Actions/TextManagement/TextManagementActionTypes';

const reducer = (state = [], action) => {
  switch (action.type) {
    case actionTypes.SET_SPINNER_VALUE:
      return { ...state, showSpinner: action.showSpinner };
    default: return state;
  }
};

export default reducer;
