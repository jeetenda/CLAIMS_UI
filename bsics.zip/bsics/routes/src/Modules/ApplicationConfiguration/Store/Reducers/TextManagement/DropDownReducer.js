import * as actionTypes from '../../Actions/TextManagement/TextManagementActionTypes';

const reducer = (state = [], action) => {
  switch (action.type) {
    case actionTypes.TEXT_MANAGEMENT_SEARCH_DROPDOWN_ENDPOINT:
      return { functionalDropDown: action.functionalAreaDropDown };
    default: return state;
  }
};

export default reducer;
