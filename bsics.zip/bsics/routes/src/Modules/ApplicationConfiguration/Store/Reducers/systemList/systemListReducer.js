import * as actionTypes from '../../Actions/systemList/systemListActionTypes';

const reducer = (state = [], action) => {
  switch (action.type) {
    case actionTypes.SEARCH_SYSTEM_LIST:
      return { payload: action.systemLists };
    case actionTypes.SYSTEM_LIST_VIEW:
      return { systemListViewData: action.rowsearchsyslist };
    case actionTypes.RESET_DATA:
      return action.resetData;
    case actionTypes.SYSTEM_LIST_ADD:
      return { systemListAddResponse: action.systemListAddResponse };
    case actionTypes.SYSTEM_LIST_UPDATE:
      return { systemListUpdateResponse: action.systemListUpdateResponse };
    case actionTypes.SYSTEM_LIST_NOTE:
      return { usageDropDown: action.usageDropDown };
    default: return state;
  }
};

export default reducer;
