import * as actionTypes from '../../Actions/AppConfigCommon/AppConfigActionTypes';

const axiosPayLoad = {
  payload: null,
  lobDropDown: []
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.APP_CONFIG_DROPDOWNS:
      return { ...state, appConfigDropdown: action.appConfigDropdown };
    case actionTypes.DATA_ELEMENT_NAME_DROPDOWNS:
      return { ...state, dataElementNameDropdown: action.dataElementNameDropdown };
    case actionTypes.DATA_ELEMENT_MAP_NAME_DROPDOWNS:
      return { ...state, dataElementMapDropdown: action.dataElementMapDropdown };
    case actionTypes.MODIFIER_DROPDOWNS:
      return { ...state, modifierDropdown: action.modifierDropdown };
    default: return state;
    case actionTypes.NOTES_USAGE_TYPE_DROPDOWNS:
      return { ...state, usageDropDown: action.usageDropDown };
  }
};

export default reducer;
