import * as actionTypes from '../../Actions/TextManagement/TextManagementActionTypes';

const reducer = (state = [], action) => {
  switch (action.type) {
    case actionTypes.PROVIDER_SPECIALTY_DATA:
      console.log(action.ProviderSpecialtyData);
      return { ProviderSpecialtyData: action.ProviderSpecialtyData };
    default: return state;
  }
};

export default reducer;
