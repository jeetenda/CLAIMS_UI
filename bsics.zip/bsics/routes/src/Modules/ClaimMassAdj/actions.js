/* eslint-disable arrow-parens */
import axios from "axios";
import * as actionTypes from "./actionTypes";
import * as serviceEndPoint from "../../SharedModules/services/service";
import { getLoginUserDetails } from "../../SharedModules/utility/utilityFunction";

export const resetSearchCriteria = () => ({
  type: actionTypes.RESETDATA,
  resetData: [],
});

export const dispatchMassAdjSearch = (response) => ({
  type: actionTypes.MASS_ADJ_SEARCH,
  MassAdjSearchData: response,
});
export const dispatchMassAdjAdd = (response) => ({
  type: actionTypes.MASS_ADJ_ADD,
  MassAdjAddData: response,
});
export const dispatchMassAdjUpdate = (response) => ({
  type: actionTypes.MASS_ADJ_UPDATE,
  MassAdjUpdateData: response,
});
export const dispatchMassAdjDetails = (response) => ({
  type: actionTypes.MASS_ADJ_DETAILS,
  MassAdjDetailData: response,
});
export const dispatchMassAdjDelete = (response) => ({
  type: actionTypes.MASS_ADJ_DELETE,
  MassAdjDeleteData: response,
});

export const dispatchMassAdjRequestNumber= (response) => ({
  type: actionTypes.MASS_ADJ_REQ_NUM,
  MassAdjReqNum: response,
});

export const MassAdjSearchAction = (values) => (dispatch) => {
  return axios
    .post(`${serviceEndPoint.MASS_ADJ_SEARCH_ENDPOINT}`, values)
    .then((response) => {
      if (response.status === 500 || response.status === 400) {
        dispatch(dispatchMassAdjSearch(response.data));
      } else if (response.status === 200 && response.data.data) {
        dispatch(dispatchMassAdjSearch(response.data.data));
      } else {
        dispatch(dispatchMassAdjSearch([]));
      }
    })
    .catch((error) => {
      dispatch(dispatchMassAdjSearch(error.response.data));
    });
};

export const addData = (values) => (dispatch) => {
  const userDetails = getLoginUserDetails();
  return axios.post(`${serviceEndPoint.MASS_ADJ_CREATE_ENDPOINT+'/'+userDetails.loginUserID}`, values)
      .then(response => {
          dispatch(dispatchMassAdjAdd(response.data));
      }).catch(error => {
          dispatch(dispatchMassAdjAdd(error.response.data));
      })
}
export const updateData = values => dispatch => {
  const userDetails = getLoginUserDetails();
  return axios.post(`${serviceEndPoint.MASS_ADJ_UPDATE_ENDPOINT+'/'+userDetails.loginUserID}`, values)
      .then(response => {
          dispatch(dispatchMassAdjUpdate(response.data));
      }).catch(error => {
          dispatch(dispatchMassAdjUpdate(error.response.data));
      })
}
export const getDetails = values => dispatch => {
  return axios.post(`${serviceEndPoint.MASS_ADJ_DETAILS_ENDPOINT}`,values)
      .then(response => {
          dispatch(dispatchMassAdjDetails(response.data));
      }).catch(error => {
          dispatch(dispatchMassAdjDetails(error.response.data));
      })
}

export const deleteData = values => dispatch => {
  const userDetails = getLoginUserDetails();
  return axios.post(`${serviceEndPoint.MASS_ADJ_DELETE_ENDPOINT+'/'+userDetails.loginUserID}`,values)
      .then(response => {
          dispatch(dispatchMassAdjDelete(response.data));
      }).catch(error => {
          dispatch(dispatchMassAdjDelete(error.response.data));
      })
}




export const getRequestNumber = () => dispatch => {
  return axios.get(`${serviceEndPoint.MASS_ADJ_REQ_NUM_ENDPOINT}`)
      .then(response => {
          dispatch(dispatchMassAdjRequestNumber(response.data));
      }).catch(error => {
          dispatch(dispatchMassAdjRequestNumber(error.response.data));
      })
}
