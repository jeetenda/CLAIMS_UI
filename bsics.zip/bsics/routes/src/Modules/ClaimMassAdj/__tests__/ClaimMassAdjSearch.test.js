import React from "react";
import { mount, shallow } from "enzyme";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import thunk from "redux-thunk";
import moxios from "moxios";
import "babel-polyfill";
import { MassAdjSearchAction } from "../actions";
import * as actionTypes from "../actionTypes";
import ClaimMassAdjSearch from "../Component/ClaimMassAdjSearch";

const middlewares = [thunk];
jest.mock("../Component/ClaimMassAdjSearchTable", (props) => (props) => (
  <div id="test">Hello World</div>
));

/**
 * describe() is used to handle rendering Exception Search Component.
 * get element selector from componen using expect method of jest
 * @Date 27-Oct-2020
 * @author Jai Arora
 */

//api sucees and error method
const mockSuccess = (data) => ({ status: 200, response: data });

describe("Case Head Name Search Component", () => {
  const initialState = {
    ClaimMassAdjSearch: { MassAdjSearchData: [] },
    appDropDowns: { printLayout: [] },
  };
  const mockStore = configureStore(middlewares);
  let store, wrapper;

  store = mockStore(initialState);

  const setup = function (initialState, componentProps) {
    const updateState = jest.fn();
    React.useState = jest.fn(() => [initialState, updateState]);
    wrapper = mount(
      <Provider store={store}>
        <Router>
          <ClaimMassAdjSearch {...componentProps} />
        </Router>
      </Provider>
    );
    return wrapper;
  };

  //expect used for assert the component and match the output with testing condition
  it("should render search button without error", () => {
    const wrapper = setup(
      {
        bDInvalid: true,
        bNInvalid: true,
        bDReq: true,
        bNReq: true,
        batchDate: "abc",
        batchNo: "123",
        ascending: "",
        sortColumn: "",
        errorMessages: ["abc", "no", "why"],
      },
      { privileges: { search: true } }
    );
    const component = wrapper.find("#search-mass-adj").at(0);
    component.simulate("click");
    expect(component.length).toBe(1);
  });

  it("should render search button without error", () => {
    const wrapper = setup(
      {
        bDInvalid: true,
        bNInvalid: true,
        bDReq: true,
        bNReq: true,
        batchDate: "",
        batchNo: "",
        ascending: "",
        sortColumn: "",
      },
      { privileges: { search: true } }
    );
    const component = wrapper.find("#search-mass-adj").at(0);
    component.simulate("click");
    expect(component.length).toBe(1);
  });
  it("should render search button without error", () => {
    const wrapper = setup(
      {
        bDInvalid: true,
        bNInvalid: true,
        bDReq: true,
        bNReq: true,
        batchDate: true,
        batchNo: "9125",
        ascending: "",
        sortColumn: "",
      },
      { privileges: { search: true } }
    );
    const component = wrapper.find("#search-mass-adj").at(0);
    component.simulate("click");
    expect(component.length).toBe(1);
  });
  it("should render reset button without error", () => {
    const wrapper = setup(
      {
        bDInvalid: true,
        bNInvalid: false,
        bDReq: false,
        bNReq: true,
      },
      { privileges: { search: false, add: false } }
    );
    const component = wrapper.find("#reset-mass-adj").at(0);
    component.simulate("click");
    expect(component.length).toBe(1);
  });
  it("should render add button without error", () => {
    const wrapper = setup(
      {
        bDInvalid: false,
        bNInvalid: false,
        bDReq: false,
        bNReq: false,
      },
      { privileges: { add: true } }
    );
    const component = wrapper.find("#add-mass").at(0);
    component.simulate("click");
    expect(component.length).toBe(1);
  });

  it("should render batch number without error", () => {
    const wrapper = setup(
      { searchResults: ["1", "2", "3"] },
      { privileges: { add: true } }
    );
    const component = wrapper.find("#standard-batch-julian-date-ces1").at(0);
    expect(component.length).toBe(1);
  });

  it("should render batch number without error", () => {
    const reactMock = require("react");

    const setHookState = (newState) =>
      jest.fn().mockImplementation(() => [newState, () => {}]);
    reactMock.useState = setHookState({
      batchDate: "19162",
      batchNo: "9996",
      errorMessages: ["abc", "no", "why"],
    });
    const initialState = {
      ClaimMassAdjSearch: { MassAdjSearchData: { searchResults: [1, 2, 3] } },
      appDropDowns: { printLayout: [] },
    };
    const mockStore = configureStore(middlewares);
    let store, wrapper;
    const compProps = {};
    store = mockStore(initialState);
    wrapper = mount(
      <Provider store={store}>
        <Router>
          <ClaimMassAdjSearch {...compProps} />
        </Router>
      </Provider>
    );
    const component = wrapper.find("#search-mass-adj").at(0);
    component.simulate("click");
    expect(component.length).toBe(1);
  });

  it("should render batch number without error", () => {
    const reactMock = require("react");

    const setHookState = (newState) =>
      jest.fn().mockImplementation(() => [newState, () => {}]);
    reactMock.useState = setHookState({
      batchDate: "19162",
      batchNo: "9996",
      errorMessages: ["abc", "no", "why"],
    });
    const initialState = {
      ClaimMassAdjSearch: { MassAdjSearchData: { searchResults: [] } },
      appDropDowns: { printLayout: [] },
    };
    const mockStore = configureStore(middlewares);
    let store, wrapper;
    const compProps = {};
    store = mockStore(initialState);
    wrapper = mount(
      <Provider store={store}>
        <Router>
          <ClaimMassAdjSearch {...compProps} />
        </Router>
      </Provider>
    );
    const component = wrapper.find("#standard-batch-julian-date-ces1").at(0);
    component.prop("onChange")({ target: { value: "abc" } });
    expect(component.length).toBe(1);
  });
});

describe("Member Search API test cases", function () {
  const reqBody = {
    batchDate: "19162",
    batchNo: "9967",
    ascending: "",
    sortColumn: "",
  };

  const resObject = {
    data: { searchresult: true },
  };
  const initialState = {
    ClaimMassAdjSearch: { MassAdjSearchData: [] },
    appDropDowns: { printLayout: [] },
  };
  const mockStore = configureStore(middlewares);
  let store = mockStore(initialState);

  beforeEach(function () {
    // import and pass your custom axios instance to this method
    moxios.install();
  });

  afterEach(function () {
    // import and pass your custom axios instance to this method
    moxios.uninstall();
  });

  it("should be success the api call", () => {
    moxios.wait(() => {
      let request = moxios.requests.mostRecent();
      request.respondWith(mockSuccess(resObject));
    });

    const dispatchMassAdjSearch = {
      type: actionTypes.TPl_SEARCH_TYPE,
      MassAdjSearchhData: resObject,
    };

    return store.dispatch(MassAdjSearchAction(reqBody)).then(() => {
      const actions = store.getActions();
      expect(actions[0].MassAdjSearchData).toEqual(
        dispatchMassAdjSearch.MassAdjSearchhData.data
      );
    });
  });

  it("should showError messages", () => {
    const seterrorMessages = jest.fn();
    React.useState = jest.fn(() => [["some error"], seterrorMessages]);
    let wrapper = mount(
      <Provider store={store}>
        <Router>
          <ClaimMassAdjSearch />
        </Router>
      </Provider>
    );
    const li = wrapper.find(".alert.alert-danger.custom-alert > li");
    expect(li.length > 0).toBe(true);
  });

  it("should reactPrint function should called", () => {
    const wrapper = mount(
      <Provider store={store}>
        <Router>
          <ClaimMassAdjSearch />
        </Router>
      </Provider>
    );
    wrapper.find("#reactPrint").prop("onBeforeGetContent")();
  });
});
