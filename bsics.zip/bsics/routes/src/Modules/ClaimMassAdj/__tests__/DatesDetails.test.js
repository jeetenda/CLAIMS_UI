
import React from "react"
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { useDispatch, useSelector } from 'react-redux';

import { BrowserRouter as Router } from "react-router-dom";
import MassAdjRequestAdd, { serviceSuccessHandel } from "../Component/MassAdjRequestAdd.js";

import DatesDetails, { deleteRow } from '../Component/DatesDetails';
import CodesDetails from '../Component/CodesDetails';
import OtherDetails from '../Component/OtherDetails';
import ClaimFieldUpdate from '../Component/ClaimFieldUpdate';
import RequestInformation from "../Component/RequestInformation";
import TableComponent from '../../../SharedModules/Table/Table';

import Checkbox from '@material-ui/core/Checkbox';
import thunk from 'redux-thunk'
import moxios from 'moxios';
import * as redux from "react-redux";
import { Provider } from 'react-redux';


//********Remove error related to useDispatch & useSelector *******/
const middlewares = [thunk]
const reactMock = require("react");
// const setHookState = (newState) =>
//   jest.fn().mockImplementation(() => [newState, () => newState]);
const mockStore = configureStore(middlewares);
let store, wrapper;
let initialState = {};
store = mockStore(initialState);
// jest.mock("../../../SharedModules/Table/Table", (props) => (props) => (
//     <div id="Table-mock">
//         Hello World
//     </div>
// ));
const setHookState = (newState) => jest.fn().mockImplementation((state) => [
    newState,
    (newState) => { }
])
describe('Mass Adjustments Dates Component', function () {
    reactMock.useState = setHookState({
        editData: {
            "edit": true,
            "index": 1
        }
    });
    let wrapper;

    // const setup = (props = {}) => {
    //     // return shallow(<Provider store={store}><Router><DatesDetails {...props} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive();
    //     return mount(<Provider store={store}><Router><DatesDetails {...props} /></Router></Provider>);
    // }





    const defaultProps = {

        privileges: {
            update: true
        },

        sysdropdowns: {
            'Claims4#5037': [{ code: "1", desc: "1" }],
        },
        setErrorMessages: jest.fn(),
        setReset: jest.fn(),
        setSave: jest.fn(),
        disableAddForm: false,
        dateFormData: [1, 2, 3],
        setErrorMessages: jest.fn(),
        deleteEditDate: [1, 2],
        deleteDateData: [1, 2],
        editDateData: [1, 2],
        saveVal: true,
        resetVal: true,
        dateFormData: jest.fn(),
        deleteEditDate: jest.fn(),
        deleteDateData: jest.fn()

    };

    const setup = function (initialState, props) {
        const updateState = jest.fn();
        React.useState = jest.fn(() => [initialState, updateState]);
        wrapper = mount(
            <Provider store={store}>
                <Router>
                    <DatesDetails {...props} />
                </Router>
            </Provider>
        );
        return wrapper;
    };



    it('should render Add button without error', () => {
        const wrapper = setup(defaultProps);
        console.log(wrapper.debug());
        const component = wrapper.find("[data-test='test_add']").at(0);
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render multidelete button without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_multidelete']").at(0);
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render Add/Update button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        const component = wrapper.find("[data-test='test_addUpdate']").at(0);
        component.simulate('click').simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render Reset button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        const component = wrapper.find("[data-test='test_reset']").at(0);
        component.simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render cancel button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        const component = wrapper.find("[data-test='test_cancel']").at(0);
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render delete button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        const component = wrapper.find("[data-test='test_del']").at(0);
        component.simulate('click')
        expect(component.length).toBe(1);
    })

    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        console.log(wrapper.debug())

        const component = wrapper.find("[data-test='test_type']").at(0);
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']").at(0);
        component2.simulate('change', "11/20/2020");
        const component3 = wrapper.find("[data-test='test_upperlimit']").at(0);
        component3.simulate('change', "11/20/2020");
        const component4 = wrapper.find("[data-test='test_addUpdate']").at(0);
        component4.simulate('click');
    })
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        const component = wrapper.find("[data-test='test_type']").at(0);
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']").at(0);
        component2.simulate('change', "11/20/2020");
        const component3 = wrapper.find("[data-test='test_upperlimit']").at(0);
        component3.simulate('change', "10/20/2020");
        const component4 = wrapper.find("[data-test='test_addUpdate']").at(0);
        component4.simulate('click');
    })
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        const component = wrapper.find("[data-test='test_type']").at(0);
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']").at(0);
        component2.simulate('change', "1120/2020");
        const component3 = wrapper.find("[data-test='test_upperlimit']").at(0);
        component3.simulate('change', "10/20/2020");
        const component4 = wrapper.find("[data-test='test_addUpdate']").at(0);
        component4.simulate('click');
    })
    it('should render validation function without error', () => {
        const defaultProps = {

            privileges: {
                update: true
            },

            sysdropdowns: {
                'Claims4#5037': [1, 2, 3],
            },
            setErrorMessages: jest.fn(),
            setReset: jest.fn(),
            setSave: jest.fn(),
            disableAddForm: true,
            dateFormData: [1, 2, 3],
            setErrorMessages: jest.fn(),
            deleteEditDate: [1, 2],
            deleteDateData: [1, 2],
            editDateData: [1, 2],
            saveVal: true,
            resetVal: true,
            dateFormData: jest.fn()


        }
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").at(0).simulate('click');
        console.log(wrapper.debug())

        const component = wrapper.find("[data-test='test_type']").at(0);
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']").at(0);
        component2.simulate('change', "11/20/2020");
        // const component3 = wrapper.find("[data-test='test_upperlimit']").at(0);
        // component3.simulate('change', "");
        const component4 = wrapper.find("[data-test='test_addUpdate']").at(0);
        component4.simulate('click');
    })

    it('should show row edit row by hitting the function without error', () => {
        const wrapper = setup(defaultProps);
        const editRow = jest.fn();
        const tableComp = wrapper.find(TableComponent).at(0);
        tableComp.prop('onTableRowClick')(editRow);

        expect(tableComp.length).toBe(1);
    });

    it("should check  Reuest information component", () => {
        const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        deleteRow(defaultProps, { edit: true, index: 0, sequenceNumber: 1 }, [{ edit: true, index: 0, sequenceNumber: 1 }], mockFunction1, mockFunction2);
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
    });




})