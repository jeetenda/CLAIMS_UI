import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { useDispatch, useSelector } from 'react-redux';

import { BrowserRouter as Router } from "react-router-dom";
import MassAdjRequestAdd, { serviceSuccessHandel,majorSave,majorValidations } from "../Component/MassAdjRequestAdd.js";

import DatesDetails, { deleteRow, resetEditFormData, handleMultiDelete } from '../Component/DatesDetails';
import CodesDetails, { deleteRow as deleteRow1, resetEditFormData as resetEditFormData1, handleMultiDelete as handleMultiDelete1 } from '../Component/CodesDetails';
import OtherDetails, { deleteRow as deleteRow2, resetEditFormData as resetEditFormData2} from '../Component/OtherDetails';
import ClaimFieldUpdate from '../Component/ClaimFieldUpdate';
import RequestInformation from "../Component/RequestInformation";
import TableComponent from '../../../SharedModules/Table/Table';

import Checkbox from '@material-ui/core/Checkbox';
import thunk from 'redux-thunk'
import moxios from 'moxios';
import * as redux from "react-redux";
import { Provider } from 'react-redux';
import {useConfirm} from '../../../SharedModules/MUIConfirm/index';


//********Remove error related to useDispatch & useSelector *******/
const middlewares = [thunk]
const reactMock = require("react");
// const setHookState = (newState) =>
//   jest.fn().mockImplementation(() => [newState, () => newState]);

jest.mock("../../../SharedModules/Table/Table", (props) => (props) => (
    <div onClick={props.onTableRowClick()} id="Table-mock">
        Hello World
    </div>
));

const setHookState = (newState) => jest.fn().mockImplementation((state) => [
    newState,
    (newState) => { }
])
describe('dispatch mock', function () {
    reactMock.useState = setHookState({
        "dateData": [1, 2, 3]
    });
    it('should mock dispatch', function () {
        const useDispatchSpy = jest.spyOn(redux, 'useDispatch');
        const mockDispatchFn = jest.fn()
        useDispatchSpy.mockReturnValue(mockDispatchFn);
        useDispatchSpy.mockClear();
    })
});
describe('selector mock', function () {
    it('should mock useSelector', function () {
        const useSelectorSpy = jest.spyOn(redux, 'useSelector');
        const mockSelectorFn = jest.fn()
        useSelectorSpy.mockReturnValue(mockSelectorFn);
        useSelectorSpy.mockClear();
    })
});


describe('useEffect mock', function () {
    reactMock.useState = setHookState({
        addServiceResp: { success: true, data: true },
        rqNumber: { data: 123456 },
    });
    it('should mock useEffect', function () {
        const useEffectSpy = jest.spyOn(React, 'useEffect');
        const mockUseEffectFn = jest.fn()
        useEffectSpy.mockReturnValue(mockUseEffectFn);
        useEffectSpy.mockClear();
    })
});




let useEffect;
// let useSelector;
const mockStore = configureStore(middlewares)
let store, wrapper

// intitial state for component
const initialState = {
    appDropDowns: {
        printLayout: ""
    },
    lobReqErr: true,
    batchDtReqErr: true,
    batchNumErr: true,
    rqstTypeReqErr: true,
    paymentReqErr: true,
    claimReqErr: true,
    voidReqErr: true,
    batchDtFormatErr: true,
    batchNumFormatErr: true,
    batchDtInvalidErr: true,
    batchCurDtErr: true, batchPastDtErr: true,
    FCNErr: true,
    FCNMemberIdErr: true,
    setValues: jest.fn(),
    values: {
        "requestNumber": "",
        "lob": "-1",
        "batchDate": "",
        "batchNumber": "",
        "voidReplacementReason": "-1",
        "request": "",
        "payment": "",
        "claimStatus": "",
        "batchCycle": "Y",
        "processed": "No",
        "totalClaimsSelected": "",
        mergeAndUnmergeMemberID: "",
        fcn: ""
    },
    defaultValue: {
        "requestNumber": "",
        "lob": "-1",
        "batchDate": "",
        "batchNumber": "",
        "voidReplacementReason": "-1",
        "request": "",
        "payment": "",
        "claimStatus": "",
        "batchCycle": "Y",
        "processed": "No",
        "totalClaimsSelected": "",
        mergeAndUnmergeMemberID: "",
        fcn: ""

    }

};
let value= {
    "requestNumber": "12345",
    "lob": "MED",
    "batchDate": "20309",
    "batchNumber": "9000",
    "voidReplacementReason": "1",
    "request": "1",
    "payment": "1",
    "claimStatus": "1",
    "batchCycle": "Y",
    "processed": "No",
    "totalClaimsSelected": "1",
    mergeAndUnmergeMemberID: "",
    fcn: ""

}
store = mockStore(initialState);

beforeEach(() => {
    store = mockStore(initialState)
    useEffect = jest.spyOn(React, "useEffect").mockImplementation(f => f());
})



describe('Mass Adjustments Component', function () {
    reactMock.useState = setHookState({
        editData: {
            "edit": true,
            "index": 1
        },
        "requestNumber": "12345",
        "lob": "MED",
        "batchDate": "20306",
        "batchNumber": "9099",
        "voidReplacementReason": "1",
        "request": "1",
        "payment": "1",
        "claimStatus": "1",
        "batchCycle": "Y",
        "fcn": "",
        "mergeAndUnmergeMemberID": "",
        "dateData": [1, 2, 3]
    });
    const setup = (props = {}) => {
        return shallow(<Provider store={store}><Router><MassAdjRequestAdd {...props} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive();
    }
    const defaultProps = {
        setShowSuccessMessage: jest.fn(),
        setCancelType: jest.fn(),
        history: {
        },
        privileges: {
            add: true
        }
    }

    it('should render Add button  without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_MassAdjAdd']");
        expect(component.length).toBe(1);
    })
    it('should render Save button  without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_save']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render Cancel button  without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_cancel']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })

    it('should render Reset without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_reset']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render save function validation without error', () => {
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        const mockFunction4 = jest.fn();
        const mockFunction5 = jest.fn();
        const mockFunction6 = jest.fn();
        const mockFunction7 = jest.fn();
        const mockFunction8 = jest.fn();
        majorSave(initialState.values,{loginUserName:"1234"},[1,23],[1,23],[1,23],mockFunction1,[],  mockFunction2 , mockFunction3,mockFunction4,mockFunction5,mockFunction6,mockFunction6,mockFunction7,mockFunction8) 
    });
    it('should render save function validation without error', () => {
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        const mockFunction4 = jest.fn();
        const mockFunction5 = jest.fn();
        const mockFunction6 = jest.fn();
        const mockFunction7 = jest.fn();
        const mockFunction8 = jest.fn();
        majorSave(value,{loginUserName:"1234"},[1,23],[1,23],[1,23],mockFunction1,[],  mockFunction2 , mockFunction3,mockFunction4,mockFunction5,mockFunction6,mockFunction6,mockFunction7,mockFunction8) 
    });
    it('should render major validation function validation without error', () => {
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();

        majorValidations(mockFunction1,mockFunction2,mockFunction3,initialState.values,[1,23],[1,23],[1,23])
    });
    it('should render major validation 2 function validation without error', () => {
        let value= {
            "requestNumber": "12345",
            "lob": "MED",
            "batchDate": "20589",
            "batchNumber": "9002",
            "voidReplacementReason": "1",
            "request": "1",
            "payment": "1",
            "claimStatus": "1",
            "batchCycle": "Y",
            "processed": "No",
            "totalClaimsSelected": "1",
            mergeAndUnmergeMemberID: "123",
            fcn: "123"
        
        }
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();

        majorValidations(mockFunction1,mockFunction2,mockFunction3,value,[1,23],[1,23],[1,23])
    });
    let value= {
        "requestNumber": "12345",
        "lob": "MED",
        "batchDate": "20364",
        "batchNumber": "9001",
        "voidReplacementReason": "1",
        "request": "1",
        "payment": "1",
        "claimStatus": "1",
        "batchCycle": "Y",
        "processed": "No",
        "totalClaimsSelected": "1",
        mergeAndUnmergeMemberID: "",
        fcn: ""
    
    }

    it('should render major validation 2 function validation without error', () => {

        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();

        majorValidations(mockFunction1,mockFunction2,mockFunction3,value,[1,23],[1,23],[1,23])
    });
    it('should render major validation 3 function validation without error', () => {

        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();

        majorValidations(mockFunction1,mockFunction2,mockFunction3,{...value,batchDate:"20309",fcn:20101,mergeAndUnmergeMemberID:12},[1,23],[1,23],[1,23])
    });
    it('should render major validation 4 function validation without error', () => {

        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();

        majorValidations(mockFunction1,mockFunction2,mockFunction3,{...value,batchDate:"20309"},[1,23],[1,23],[{selectionCode:"01"}])
    });

    // it('should render major validation 5 function validation without error', () => {cl

    //     const mockFunction1 = jest.fn();
    //     const mockFunction2 = jest.fn();
    //     const mockFunction3 = jest.fn();

    //     majorValidations(mockFunction1,mockFunction2,mockFunction3,{...value,batchDate:"20209",batchNumber:"8900"},[1,23],[1,23],[{selectionCode:"01"}])
    // });

    it('should render save function validation 2 without error', () => {
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        const mockFunction4 = jest.fn();
        const mockFunction5 = jest.fn();
        const mockFunction6 = jest.fn();
        const mockFunction7 = jest.fn();
        const mockFunction8 = jest.fn();
        majorSave(value,{loginUserName:"1234"},[1,23],[1,23],[1,23],mockFunction1,[],  mockFunction2 , mockFunction3,mockFunction4,mockFunction5,mockFunction6,mockFunction6,mockFunction7,mockFunction8) 
    });

    it('should render save function validation 2 without error', () => {
        let value= {
            "requestNumber": "12345",
            "lob": "MED",
            "batchDate": "20303",
            "batchNumber": "9001",
            "voidReplacementReason": "1",
            "request": "1",
            "payment": "1",
            "claimStatus": "1",
            "batchCycle": "Y",
            "processed": "No",
            "totalClaimsSelected": "1",
            mergeAndUnmergeMemberID: "",
            fcn: ""
        
        }
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        const mockFunction4 = jest.fn();
        const mockFunction5 = jest.fn();
        const mockFunction6 = jest.fn();
        const mockFunction7 = jest.fn();
        const mockFunction8 = jest.fn();
        majorSave(value,{loginUserName:"1234"},[1,23],[1,23],[1,23],mockFunction1,[],  mockFunction2 , mockFunction3,mockFunction4,mockFunction5,mockFunction6,mockFunction6,mockFunction7,mockFunction8) 
    });
    it('should render save function validation 2 without error', () => {
        let value= {
            "requestNumber": "12345",
            "lob": "MED",
            "batchDate": "20589",
            "batchNumber": "9001",
            "voidReplacementReason": "1",
            "request": "1",
            "payment": "1",
            "claimStatus": "1",
            "batchCycle": "Y",
            "processed": "No",
            "totalClaimsSelected": "1",
            mergeAndUnmergeMemberID: "",
            fcn: ""
        
        }
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        const mockFunction4 = jest.fn();
        const mockFunction5 = jest.fn();
        const mockFunction6 = jest.fn();
        const mockFunction7 = jest.fn();
        const mockFunction8 = jest.fn();
        majorSave(value,{loginUserName:"1234"},[1,23],[1,23],[1,23],mockFunction1,[],  mockFunction2 , mockFunction3,mockFunction4,mockFunction5,mockFunction6,mockFunction6,mockFunction7,mockFunction8) 
    });
    it('should render save function validation 2 without error', () => {
        let value= {
            "requestNumber": "12345",
            "lob": "MED",
            "batchDate": "20589",
            "batchNumber": "9001",
            "voidReplacementReason": "1",
            "request": "1",
            "payment": "1",
            "claimStatus": "1",
            "batchCycle": "Y",
            "processed": "No",
            "totalClaimsSelected": "1",
            mergeAndUnmergeMemberID: "123",
            fcn: "123"
        
        }
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        const mockFunction4 = jest.fn();
        const mockFunction5 = jest.fn();
        const mockFunction6 = jest.fn();
        const mockFunction7 = jest.fn();
        const mockFunction8 = jest.fn();
        majorSave(value,{loginUserName:"1234"},[1,23],[1,23],[1,23],mockFunction1,[],  mockFunction2 , mockFunction3,mockFunction4,mockFunction5,mockFunction6,mockFunction6,mockFunction7,mockFunction8) 
    });


    

    it("should reactPrint function should called", () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_print']").prop("onBeforeGetContent")();

        wrapper.find("[data-test='test_print']").prop("onAfterPrint")();

        wrapper.find("[data-test='test_print']").prop("trigger")();

        wrapper.find("[data-test='test_print']").prop("content")();

    });
    it("should check code component", () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_code_comp']").prop("sysdropdowns");
        wrapper.find("[data-test='test_code_comp']").prop("deleteCodeData")([1, 2, 3]);
        wrapper.find("[data-test='test_code_comp']").prop("codeFormData")([1, 2, 3]);

    });

    it("should check other component", () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_other_comp']").prop("sysdropdowns");
        wrapper.find("[data-test='test_other_comp']").prop("deleteOtherData")([1, 2, 3]);
        wrapper.find("[data-test='test_other_comp']").prop("otherFormData")([1, 2, 3]);
        wrapper.find("[data-test='test_other_comp']").prop("disabledForms")([1, 2, 3]);


    });
    it("should check date component", () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_date_comp']").prop("sysdropdowns");
        wrapper.find("[data-test='test_date_comp']").prop("deleteDateData")([1, 2, 3]);
        wrapper.find("[data-test='test_date_comp']").prop("dateFormData")([1, 2, 3]);

    });

    it("should check Claim Update component", () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test-claim-update']").prop("handleChanges")("fcn", "12345");
        wrapper.find("[data-test='test-claim-update']").prop("handleChanges")("mergeAndUnmergeMemberID", "12345");
    });

    it("should check  Reuest information component", () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test-req-info']").prop("handleChanges")("lob")({ target: { value: "12345" } });


    });
    it("should check  Reuest information component", () => {
        const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        serviceSuccessHandel(defaultProps, mockFunction1, mockFunction2);
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
    });


})

describe('Mass Adjustments Request Information Component', function () {

    const setup = (props = {}) => {
        return shallow(<Provider store={store}><Router><RequestInformation {...props} /></Router></Provider>).dive().dive().dive().dive().dive().dive();
    }
    const defaultProps = {

        values: {
            "requestNumber": "12345",
            "lob": "MED",
            "batchDate": "20306",
            "batchNumber": "9099",
            "voidReplacementReason": "1",
            "request": "1",
            "payment": "1",
            "claimStatus": "1",
            "batchCycle": "Y",
            "fcn": "",
            "mergeAndUnmergeMemberID": "",
        },
        dropdowns: {

            "Claims#R_LOB_CD": [1, 2, 3],
            'Claims#C_VOID_REPLCMT_RSN_CD': [1, 2, 3],
            'Claims#C_TXN_TY_CD': [{ code: 1 }, { code: 3 }],
            "P1#C_BATCH_PMT_TY_CD": [1, 2, 3],
            "G1#C_ADJ_REQ_RTN_CD": [{ code: "Y" }, { code: "N" }],

        },
        handleChanges: jest.fn(),
        errors: {
            lobReqErr: true,
            batchDtReqErr: true,
            batchNumErr: true,
            rqstTypeReqErr: true,
            paymentReqErr: true,
            claimReqErr: true,
            voidReqErr: true,
            batchDtFormatErr: true,
            batchNumFormatErr: true,
            batchDtInvalidErr: true,
            batchCurDtErr: true, batchPastDtErr: true,
            FCNErr: true,
            FCNMemberIdErr: true,
        }
    }

    it('should render Request Number  without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_requestNumber']");
        expect(component.length).toBe(1);
    })

    it('should render LOB without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_lob']");
        component.simulate('change', { target: { value: 1 } })
        expect(component.length).toBe(1);
    })
    it('should render Batch Date without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_batchDt']");
        component.simulate('change', { target: { value: 1 } })
        expect(component.length).toBe(1);
    })
    it('should render Batch Number without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_batchNum']");
        component.simulate('change', { target: { value: 1 } })
        expect(component.length).toBe(1);
    })

    it('should render no errors without error', () => {

        const defaultProps = {

            values: {
                "requestNumber": "12345",
                "lob": "MED",
                "batchDate": "20306",
                "batchNumber": "9099",
                "voidReplacementReason": "1",
                "request": "1",
                "payment": "1",
                "claimStatus": "1",
                "batchCycle": "Y",
                "fcn": "",
                "mergeAndUnmergeMemberID": "",
            },
            dropdowns: {

                "Claims#R_LOB_CD": [1, 2, 3],
                'Claims#C_VOID_REPLCMT_RSN_CD': [1, 2, 3],
                'Claims#C_TXN_TY_CD': [{ code: 1 }, { code: 3 }],
                "P1#C_BATCH_PMT_TY_CD": [1, 2, 3],
                "G1#C_ADJ_REQ_RTN_CD": [{ code: "Y" }, { code: "N" }],

            },
            handleChanges: jest.fn(),
            errors: {
                lobReqErr: false,
                batchDtReqErr: false,
                batchNumErr: false,
                rqstTypeReqErr: false,
                paymentReqErr: false,
                claimReqErr: false,
                voidReqErr: false,
                batchDtFormatErr: false,
                batchNumFormatErr: false,
                batchDtInvalidErr: false,
                batchCurDtErr: false, batchPastDtErr: false,
                FCNErr: false,
                FCNMemberIdErr: false,
            },
            isEditOp: false
        }
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_batchNum']");
        component.simulate('change', { target: { value: 1 } })
        expect(component.length).toBe(1);
    })




})


describe('Mass Adjustments Dates Component', function () {

    const setup = (props = {}) => {
        return shallow(<Provider store={store}><Router><DatesDetails {...props} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive();
    }
    const defaultProps = {
        setReset: jest.fn(),
        setSave: jest.fn(),
        privileges: {
            update: true
        },
        sysdropdowns: {
            'Claims4#5037': [1, 2, 3],
        },
        setErrorMessages: jest.fn(),

        disableAddForm: false,
        dateFormData: [1, 2, 3],
        setErrorMessages: jest.fn(),
        deleteEditDate: [1, 2],
        deleteDateData: [1, 2],
        editDateData: [1, 2],
        saveVal: true,
        resetVal: true,
        dateFormData: jest.fn(),
        deleteEditDate: jest.fn(),
        deleteDateData: jest.fn()

    }



    it('should render Add button without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_add']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render multidelete button without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_multidelete']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render Add/Update button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_addUpdate']");
        component.simulate('click').simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render Reset button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_reset']");
        component.simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render cancel button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_cancel']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })


    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', "11/20/2020");
        const component3 = wrapper.find("[data-test='test_upperlimit']");
        component3.simulate('change', "11/20/2020");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', "11/20/2020");
        const component3 = wrapper.find("[data-test='test_upperlimit']");
        component3.simulate('change', "10/20/2020");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', "1120/2020");
        const component3 = wrapper.find("[data-test='test_upperlimit']");
        component3.simulate('change', "10/20/2020");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render validation function without error', () => {
        const defaultProps = {

            privileges: {
                update: true
            },

            sysdropdowns: {
                'Claims4#5037': [1, 2, 3],
            },
            setErrorMessages: jest.fn(),
            setReset: jest.fn(),
            setSave: jest.fn(),
            disableAddForm: false,
            dateFormData: [1, 2, 3],
            setErrorMessages: jest.fn(),
            deleteEditDate: [1, 2],
            deleteDateData: [1, 2],
            editDateData: [1, 2],
            saveVal: true,
            resetVal: true,
            dateFormData: jest.fn(),
            deleteEditDate: jest.fn()


        }
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');


        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', "11/20/2020");
        //    const component3 = wrapper.find("[data-test='test_upperlimit']");
        //    component3.simulate('change',"");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })

    it('should render validation function without error', () => {
        const defaultProps = {

            privileges: {
                update: true
            },

            sysdropdowns: {
                'Claims4#5037': [1, 2, 3],
            },
            setErrorMessages: jest.fn(),
            setReset: jest.fn(),
            setSave: jest.fn(),
            disableAddForm: false,
            dateFormData: [1, 2, 3],
            setErrorMessages: jest.fn(),
            deleteEditDate: [1, 2],
            deleteDateData: [1, 2],
            editDateData: [1, 2],
            saveVal: true,
            resetVal: true,
            dateFormData: jest.fn(),
            deleteEditDate: jest.fn()


        }
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', "11/20/2020");
        //    const component3 = wrapper.find("[data-test='test_upperlimit']");
        //    component3.simulate('change',"");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should show row edit row by hitting the function without error', () => {
        const wrapper = setup(defaultProps);
        const editRow = jest.fn();
        const tableComp = wrapper.find(TableComponent).at(0);
        tableComp.prop('onTableRowClick')(editRow);

        expect(tableComp.length).toBe(1);
    });

    it("should check  Reuest information component", () => {
        // const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        deleteRow(defaultProps, { edit: true, index: 0, sequenceNumber: 1 }, [{ edit: true, index: 0, sequenceNumber: 1 }], mockFunction1, mockFunction2);
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
    });
    it("should check  Reuest information component", () => {
        // const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        resetEditFormData(mockFunction1, mockFunction2, mockFunction3, defaultProps, { 1: 1 });
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
        expect(mockFunction3).toHaveBeenCalled();
    });





})

describe('Mass AdjustmentsClaim Field Update Component', function () {

    const setup = (props = {}) => {
        return shallow(<Provider store={store}><Router><ClaimFieldUpdate {...props} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive();
    }
    const defaultProps = {
        handleChanges: jest.fn(),
        values: {
            mergeAndUnmergeMemberID: !23,
            fcn: !23
        }

    }

    const updateProps = {
        handleChanges: jest.fn(),
        values: {


        }

    }



    it('should render fcn and memberid without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_merge']");
        component.simulate('change', { target: { value: "123" } })

        const component2 = wrapper.find("[data-test='test_fcn']");
        component2.simulate('change', { target: { value: "123" } })
    })

    it('should render fcn and memberid without error', () => {
        const wrapper = setup(updateProps);
        const component = wrapper.find("[data-test='test_merge']");
        component.simulate('change', { target: { value: "123" } })

        const component2 = wrapper.find("[data-test='test_fcn']");
        component2.simulate('change', { target: { value: "123" } })

    })



})



describe('Mass Adjustments Codes Component', function () {

    const setup = (props = {}) => {
        return shallow(<Provider store={store}><Router><CodesDetails {...props} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive();
    }
    const defaultProps = {
        setReset: jest.fn(),
        setSave: jest.fn(),
        privileges: {
            update: true
        },
        sysdropdowns: {
            'Claims4#5039': [1, 2, 3],
            'Claims#1020': [1, 2, 3],
        },
        setErrorMessages: jest.fn(),

        disableAddForm: false,
        dateFormData: [1, 2, 3],
        setErrorMessages: jest.fn(),
        deleteEditDate: [1, 2],
        deleteDateData: [1, 2],
        editDateData: [1, 2],
        saveVal: true,
        resetVal: true,
        codeFormData: jest.fn(),
        deleteEditCode: jest.fn(),
        deleteCodeData: jest.fn()

    }



    it('should render Add button without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_add']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render multidelete button without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_multidelete']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render Add/Update button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_addUpdate']");
        component.simulate('click').simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render Reset button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_reset']");
        component.simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render cancel button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_cancel']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })


    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        const component3 = wrapper.find("[data-test='test_upperlimit']");
        component3.simulate('change', { target: { value: 1 } });
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render save function without error', () => {
    const wrapper = setup(defaultProps);
    wrapper.find("[data-test='test_add']").simulate('click');

    const component = wrapper.find("[data-test='test_type']");
    component.simulate('change', { target: { value: 10 } });
    const component2 = wrapper.find("[data-test='test_lowerlimit']");
    component2.simulate('change', { target: { value: 1 } });
    const component3 = wrapper.find("[data-test='test_upperlimit']");
    component3.simulate('change', { target: { value: 0 } });
    const component4 = wrapper.find("[data-test='test_addUpdate']");
    component4.simulate('click');
})
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 18 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        const component3 = wrapper.find("[data-test='test_upperlimit']");
        component3.simulate('change', { target: { value: 1 } });
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render check duplicate function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 18 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        const component3 = wrapper.find("[data-test='test_upperlimit']");
        component3.simulate('change', { target: { value: 1 } });
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        wrapper.find("[data-test='test_type']").simulate('change', { target: { value: 18 } });
        wrapper.find("[data-test='test_lowerlimit']").simulate('change', { target: { value: 1 } });
        wrapper.find("[data-test='test_upperlimit']").simulate('change', { target: { value: 1 } });
        wrapper.find("[data-test='test_addUpdate']").simulate('click');
    })

    it('should render validation function without error', () => {
        const defaultProps = {

            privileges: {
                update: true
            },

            sysdropdowns: {
                'Claims4#5037': [1, 2, 3],
            },
            setErrorMessages: jest.fn(),
            setReset: jest.fn(),
            setSave: jest.fn(),
            disableAddForm: false,
            dateFormData: [1, 2, 3],
            setErrorMessages: jest.fn(),
            deleteEditDate: [1, 2],
            deleteDateData: [1, 2],
            editDateData: [1, 2],
            saveVal: true,
            resetVal: true,
            codeFormData: jest.fn()


        }
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');


        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        //    const component3 = wrapper.find("[data-test='test_upperlimit']");
        //    component3.simulate('change',"");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })

    it('should render validation function without error', () => {
        const defaultProps = {

            privileges: {
                update: true
            },

            sysdropdowns: {
                'Claims4#5037': [1, 2, 3],
            },
            setErrorMessages: jest.fn(),
            setReset: jest.fn(),
            setSave: jest.fn(),
            disableAddForm: false,
            dateFormData: [1, 2, 3],
            setErrorMessages: jest.fn(),
            deleteEditDate: [1, 2],
            deleteDateData: [1, 2],
            editDateData: [1, 2],
            saveVal: true,
            resetVal: true,
            codeFormData: jest.fn()


        }
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        //    const component3 = wrapper.find("[data-test='test_upperlimit']");
        //    component3.simulate('change',"");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should show row edit row by hitting the function without error', () => {
        const wrapper = setup(defaultProps);
        const editRow = jest.fn();
        const tableComp = wrapper.find(TableComponent).at(0);
        tableComp.prop('onTableRowClick')(editRow, { selectionCode: 18 });

        expect(tableComp.length).toBe(1);
    });

    it('should show row edit row by hitting the function without error', () => {
        const wrapper = setup(defaultProps);
        const editRow = jest.fn();
        const tableComp = wrapper.find(TableComponent).at(0);
        tableComp.prop('onTableRowClick')(editRow);

        expect(tableComp.length).toBe(1);
    });

    it("should check  delte row component", () => {
        // const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        deleteRow1(defaultProps, { edit: true, index: 0, sequenceNumber: 1 }, [{ edit: true, index: 0, sequenceNumber: 1 }], mockFunction1, mockFunction2);
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
    });
    it("should check  reset form information component", () => {
        // const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        resetEditFormData1(mockFunction1, mockFunction2, mockFunction3, defaultProps, { 1: 1 });
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
        expect(mockFunction3).toHaveBeenCalled();
    });





})

describe('Mass Adjustments Others Component', function () {

    const setup = (props = {}) => {
        return shallow(<Provider store={store}><Router><OtherDetails {...props} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive();
    }
    const defaultProps = {
        setReset: jest.fn(),
        setSave: jest.fn(),
        privileges: {
            update: true
        },
        sysdropdowns: {
            'Claims4#5038': [{code:"10",description:"1"}, {code:"11",description:"1"},{code:"05",description:"1"},{code:"06",description:"1"}],
            'Claims#R_LOB_CD': [1, 2, 3],
            'Claims#C_TY_CD': [1, 2, 3],
            'Claims#1020': [1, 2, 3],
        },
        dropdowns: {
            'Claims4#5038': [{code:"10",description:"1"}, {code:"11",description:"1"},{code:"05",description:"1"},{code:"06",description:"1"}],
            'Claims#R_LOB_CD': [1, 2, 3],
            'Claims#C_TY_CD': [1, 2, 3],
            'Claims#1020': [1, 2, 3],
        },
        setErrorMessages: jest.fn(),
        disabledForms:jest.fn(),
        disableAddForm: false,
        dateFormData: [1, 2, 3],
        setErrorMessages: jest.fn(),
        deleteEditDate: [1, 2],
        deleteDateData: [1, 2],
        editDateData: [1, 2],
        saveVal: true,
        resetVal: true,
        codeFormData: jest.fn(),
        deleteEditCode: jest.fn(),
        deleteCodeData: jest.fn(),
        otherFormData: jest.fn(),
        deleteEditOther: jest.fn(),
        deleteOtherData: jest.fn(),
        editOtherData:[{selectionCode:"01",description:"1-1"},{selectionCode:"11",description:"1-1"}]

    }



    it('should render Add button without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_add']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render multidelete button without error', () => {
        const wrapper = setup(defaultProps);
        const component = wrapper.find("[data-test='test_multidelete']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })
    it('should render Add/Update button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_addUpdate']");
        component.simulate('click').simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render Reset button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_reset']");
        component.simulate('click');
        expect(component.length).toBe(1);
    })
    it('should render cancel button without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_cancel']");
        component.simulate('click')
        expect(component.length).toBe(1);
    })

    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: "11" } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
       
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    });
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: "10" } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    });
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: "05" } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        component.simulate('change', { target: { value: "15" } });
       
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    });
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 18 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
       
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render save function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: "01" } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
       
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should render check duplicate function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 18 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
       
        
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        wrapper.find("[data-test='test_type']").simulate('change', { target: { value: 18 } });
        wrapper.find("[data-test='test_lowerlimit']").simulate('change', { target: { value: 1 } });
       
        wrapper.find("[data-test='test_addUpdate']").simulate('click');
    })
    it('should render check duplicate function without error', () => {
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');
        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: "01" } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
       
        
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        wrapper.find("[data-test='test_type']").simulate('change', { target: { value: "18" } });
        wrapper.find("[data-test='test_lowerlimit']").simulate('change', { target: { value: 1 } });
       
        wrapper.find("[data-test='test_addUpdate']").simulate('click');
    })

    it('should render validation function without error', () => {
        const defaultProps = {

            privileges: {
                update: true
            },

            sysdropdowns: {
                'Claims4#5037': [1, 2, 3],
            },
            setErrorMessages: jest.fn(),
            setReset: jest.fn(),
            setSave: jest.fn(),
            disableAddForm: false,
            dateFormData: [1, 2, 3],
            setErrorMessages: jest.fn(),
            deleteEditDate: [1, 2],
            deleteDateData: [1, 2],
            editDateData: [1, 2],
            saveVal: true,
            resetVal: true,
            codeFormData: jest.fn(),
            otherFormData: jest.fn()


        }
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');


        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        //    const component3 = wrapper.find("[data-test='test_upperlimit']");
        //    component3.simulate('change',"");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })

    it('should render validation function without error', () => {
        const defaultProps = {

            privileges: {
                update: true
            },

            sysdropdowns: {
                'Claims4#5037': [1, 2, 3],
            },
            setErrorMessages: jest.fn(),
            setReset: jest.fn(),
            setSave: jest.fn(),
            disableAddForm: false,
            dateFormData: [1, 2, 3],
            setErrorMessages: jest.fn(),
            deleteEditDate: [1, 2],
            deleteDateData: [1, 2],
            editDateData: [1, 2],
            saveVal: true,
            resetVal: true,
            codeFormData: jest.fn(),
            otherFormData: jest.fn()


        }
        const wrapper = setup(defaultProps);
        wrapper.find("[data-test='test_add']").simulate('click');

        const component = wrapper.find("[data-test='test_type']");
        component.simulate('change', { target: { value: 1 } });
        const component2 = wrapper.find("[data-test='test_lowerlimit']");
        component2.simulate('change', { target: { value: 1 } });
        //    const component3 = wrapper.find("[data-test='test_upperlimit']");
        //    component3.simulate('change',"");
        const component4 = wrapper.find("[data-test='test_addUpdate']");
        component4.simulate('click');
    })
    it('should show row edit row by hitting the function without error', () => {
        const wrapper = setup(defaultProps);
        const editRow = jest.fn();
        const tableComp = wrapper.find(TableComponent).at(0);
        tableComp.prop('onTableRowClick')(editRow, { selectionCode: 18 });

        expect(tableComp.length).toBe(1);
    });

    it('should show row edit row by hitting the function without error', () => {
        const wrapper = setup(defaultProps);
        const editRow = jest.fn();
        const tableComp = wrapper.find(TableComponent).at(0);
        tableComp.prop('onTableRowClick')(editRow);

        expect(tableComp.length).toBe(1);
    });

    it("should check  delte row component", () => {
        // const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        deleteRow2(defaultProps, { edit: true, index: 0, sequenceNumber: 1 }, [{ edit: true, index: 0, sequenceNumber: 1 }], mockFunction1, mockFunction2);
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
    });
    it("should check  reset form information component", () => {
        // const wrapper = setup(defaultProps);
        const mockFunction1 = jest.fn();
        const mockFunction2 = jest.fn();
        const mockFunction3 = jest.fn();
        resetEditFormData2(mockFunction1, mockFunction2, mockFunction3, defaultProps, { 1: 1 });
        expect(mockFunction1).toHaveBeenCalled();
        expect(mockFunction2).toHaveBeenCalled();
        expect(mockFunction3).toHaveBeenCalled();
    });





})