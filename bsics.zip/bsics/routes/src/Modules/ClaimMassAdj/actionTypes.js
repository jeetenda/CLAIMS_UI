
export const RESETDATA = "RESETDATA";
export const MASS_ADJ_SEARCH = "MASS_ADJ_SEARCH";
export const MASS_ADJ_ADD = "MASS_ADJ_ADD";
export const MASS_ADJ_UPDATE = "MASS_ADJ_UPDATE";
export const MASS_ADJ_DELETE = "MASS_ADJ_DELETE";

export const MASS_ADJ_DETAILS = "MASS_ADJ_DETAILS";
export const MASS_ADJ_REQ_NUM="MASS_ADJ_REQ_NUM";
