import * as actionTypes from './actionTypes';



const axiosPayLoad = {
    payload: null,
    type:'Add',
    adjudicationControlDetails:null,
    createData:null,
    updateData:null,
    deleteData:null
  };

  const reducer = (state = axiosPayLoad, action) => {
    switch (action.type) {
  
      case actionTypes.AdjudicationControl_RESETDATA:
        return axiosPayLoad;
      case actionTypes.AdjudicationControl_SEARCH_DATA:
        return {...state, payload: action.payload}
        case actionTypes.AdjudicationControl_CREATE:
          return {...state,createData:action.createData}
        case actionTypes.AdjudicationControl_UPDATE:
          return {...state,updateData:action.updateData}
        case actionTypes.AdjudicationControl_VIEW_DETAILS_TYPE:
          return { ...state, adjudicationControlDetails: action.AdjudicationControlSearchData, adjudicationControlDetailsTime: new Date(), type: 'Edit'}
          
      default: return state;
    }
  };
  
  export default reducer;