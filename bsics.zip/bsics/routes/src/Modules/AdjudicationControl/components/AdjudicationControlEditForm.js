import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import Radio from '@material-ui/core/Radio';

export default function AdjControlEditForm(props) {

	return (
		<form autoComplete="off">
			<div className="form-wrapper">
      <div className="mui-custom-form input-md">
        <label className="MuiFormLabel-root MuiInputLabel-shrink">Void</label>
        <div className="sub-radio set-sub-radio mt-1">
            <Radio
              type="radio"
              value= 'Y'
              id="voidYes"
              checked={props.values.voidInd === 'Y'}
              onChange={props.handleChanges('voidInd')}
            />
            <label className="text-black">Yes</label>
            <Radio
              type="radio"
              value= 'N'
              id="voidNo"
              checked={props.values.voidInd === 'N' }
              onChange={props.handleChanges('voidInd')}
              className="ml-2"
            />
            <label className="text-black">No</label>
          </div>
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-serviceSequencee"
            data-test='serSeq'
            label="Service Sequence"
            value={props.values.adjCtrlSeqNum}
            inputProps={{ maxLength: 7 }}
            onChange={props.handleChanges('adjCtrlSeqNum')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}
          />
        </div>
        <div className="mui-custom-form with-select input-md">
          <TextField
            id="standard-select-ClaimType"
            disabled
            data-test='typeCode'
            label="Claim Type"
            value={props.values.typeCodeDesc}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('typeCodeDesc')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}
          />
        </div>

        <div className="mui-custom-form with-select input-md">
          <TextField
            id="standard-select-batchDocType"
            disabled
            data-test='batchTypeCode'
            label="Batch Document Type"
            value={props.values.batchTypeCodeDesc}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('batchTypeCodeDesc')}
            placeholder=""
            InputLabelProps={{
              shrink: true,
            }}
          />
         
        </div>
      </div>
      <div className="form-wrapper pt-0">
      <div className="mui-custom-form input-md">
          <TextField
            id="standard-serviceName"
            label="Service Name"
            disabled
            data-test='serviceDef'
            value={props.values.serviceDefDesc}
            inputProps={{ maxLength: 7 }}
            onChange={props.handleChanges('serviceDefDesc')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}
          />
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-preServiceName"
            label="Pre Service Name"
            disabled
            data-test='preServiceDef'
            value={props.values.preServiceDefDesc}
            inputProps={{ maxLength: 7 }}
            onChange={props.handleChanges('preServiceDefDesc')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}
          />
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-postServiceName"
            label="Post Service Name"
            disabled
            data-test='postServiceDef'
            value={props.values.postServiceDefDesc}
            inputProps={{ maxLength: 7 }}
            onChange={props.handleChanges('postServiceDefDesc')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}
          />
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-faultServiceName"
            label="Fault Service Name"
            disabled
            data-test='faultServiceDef'
            value={props.values.faultServiceDefDesc}
            inputProps={{ maxLength: 7 }}
            onChange={props.handleChanges('faultServiceDefDesc')}
            placeholder=""
            InputLabelProps={{
              shrink: true
            }}
          />
        </div>
      </div>
			<div className="clearfix" />
		
		</form>
	);
}
