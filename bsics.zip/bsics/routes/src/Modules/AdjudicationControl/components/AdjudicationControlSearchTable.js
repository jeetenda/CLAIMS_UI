import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import { adjudicationControlDetailsAction } from '../actions';
import * as ErrMsgConstants from '../../../SharedModules/Messages/ErrorMsgConstants';


const headCells = [
  {
    id: 'serviceDef', numeric: false, disablePadding: true, label: 'Claim Type Code', isToolTip: true, toolTip: 'Screening Type', enableHyperLink: true, fontSize: 12, width:'20%'
  },
  {
    id: 'batchTypeCodeDesc', numeric: false, disablePadding: false, label: 'Claim Batch Document Type', enableHyperLink: false, fontSize: 12, width:'20%'
  },
  {
    id: 'serviceDef', numeric: false, disablePadding: false, label: 'Service Name', enableHyperLink: false, fontSize: 12, width:'20%'
  },
  {
    id: 'preServiceDef', numeric: false, disablePadding: false, label: 'Pre Service Name', enableHyperLink: false, fontSize: 12, width:'20%'
  },
  {
    id: 'postServiceDef', numeric: false, disablePadding: false, label: 'Post Service Name', enableHyperLink: false, fontSize: 12 , width:'20%'
  },
  {
    id: 'faultServiceDef', numeric: false, disablePadding: false, label: 'Fault Service Name', enableHyperLink: false, fontSize: 12 , width:'20%'
  },
  {
    id: 'adjCtrlSeqNum', numeric: false, disablePadding: false, label: 'Service Sequence', enableHyperLink: false, fontSize: 12 , width:'20%'
  },
  {
    id: 'voidInd', numeric: false, disablePadding: false, label: 'Void', enableHyperLink: false, fontSize: 12 , width:'20%'
  },
  
];

function AdjudicationControlSearchTable(props) {
  const errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(false);

  const dispatch = useDispatch();

  const onSearchView = searchvalues => dispatch(adjudicationControlDetailsAction(searchvalues));
  const AdjudicationControlDetails = useSelector(state => state.adjudicationControl.adjudicationControlDetails);
  const AdjudicationControlDetailsTime = useSelector(state => state.adjudicationControl.adjudicationControlDetailsTime);


  const getTableData = (data) => {
        if (data && data.length) {
          let tData = JSON.stringify(data); 
          tData = JSON.parse(tData);     
          tData.map((each,index) => {
            each.index = index;
           if(each.voidInd=="Y")  {each.voidInd=<span className="cndt-icon ic-save p-0"></span> }
           else {each.voidInd=""}
          }); 
          return tData;           
        }else{
          return [];
        }}

  useEffect(() => {
    if (AdjudicationControlDetails != null && props.redirect) {
      props.setRedirect(false);
      props.setspinnerLoader(false);
      if (AdjudicationControlDetails.errorCode === null || AdjudicationControlDetails.errorCode === undefined) {
       let adjudicationDetail = AdjudicationControlDetails.data
        props.history.push({
          pathname: '/AdjudicationControlDetails',
          state: {adjudicationDetail}
        });
      } else {
        errorMessagesArray.push(ErrMsgConstants.ERROR_OCCURED_DURING_TRANSACTION);
        props.tableErrorFunction(errorMessagesArray)
      }
    }
  }, [AdjudicationControlDetailsTime]);


  const editRow = row => (event) => {
    onSearchView({
     typeCode: row.typeCode,
     batchTypeCode: row.batchTypeCode,
     adjCtrlSeqNum : row.adjCtrlSeqNum
    });
    props.setspinnerLoader(true);
    props.setRedirect(true);
  };
  return (     
    <TableComponent headCells={headCells} tableData={getTableData(props.tableData)} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />   
  );
 
}
export default withRouter(AdjudicationControlSearchTable);
