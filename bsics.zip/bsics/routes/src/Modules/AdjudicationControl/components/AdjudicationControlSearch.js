import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import Spinner from '../../../SharedModules/Spinner/Spinner';
import ReactToPrint from 'react-to-print';
import { setPrintLayout, GET_APP_DROPDOWNS, GET_NETWORKID_DROPDOWN } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import * as ExceptionCodeConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import AdjudicationControlSearchForm from './AdjudicationControlSearchForm';
import AdjudicationControlSearchTable from './AdjudicationControlSearchTable';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { searchAction, resetCaseSearch, adjudicationControlDetailsAction } from '../actions';
import { Link } from 'react-router-dom';
import SuccessComponent from '../../../SharedModules/Errors/TimeOutSuccessMsg';

function AdjudicationControlSearch(props) {
  const [spinnerLoader, setspinnerLoader] = useState(false);
  const [showTable, setShowTable] = useState(false);
  const printRef = useRef();
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
  const [redirect, setRedirect] = useState(false);
  const [values, setValues] = useState({
    
     "claimTypeCode":"-1",
     "batchTypeCode":"-1" ,
     "serviceName" :"-1"
  
  
  });

  const [showNoRecords, setShowNoRecords] = useState(false);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [redirectCheck, setRedirectCheck] = useState(false);
  const [payloadCheck, setPayloadCheck] = useState(false);
  const [{ selectoneTypeErr,  }, setErrors] = useState(false);
  const [successMessages, setSuccessMessages] = useState([]);
  const onSearchView = searchvalues => dispatch(adjudicationControlDetailsAction(searchvalues));
  const AdjudicationControlDetails = useSelector(state => state.adjudicationControl.adjudicationControlDetails);

  const dispatch = useDispatch();
  const onReset = () => dispatch(resetCaseSearch());
  const onDropdowns = (dropdownvalues) => dispatch(GET_APP_DROPDOWNS(dropdownvalues));
  const onNetworkidDropdown = () => dispatch(GET_NETWORKID_DROPDOWN());
  const onSearch = (searchvalues) => dispatch(searchAction(searchvalues));
  const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
  const payload = useSelector(state => state.adjudicationControl.payload);
  let errorMessagesArray = [];

  useEffect(() => {
    onDropdowns([
      Dropdowns.CLAIM_TYPE_STATUS,
      Dropdowns.CLAIM_EXC_C_BATCH_DOC_TY_CD,
      Dropdowns.SERVICE_NAME
    ]);

    onReset();
    setSuccessMessages([]);
    if (props.location.deleteCode) {
      setSuccessMessages(['System successfully deleted the information.']);
      seterrorMessages(errorMessagesArray);
    }
  }, [])


  // reset table
  const resetTable = () => {
    setErrors(false);
    seterrorMessages([]);
    const resetData = {
      
      "claimTypeCode":"-1",
      "batchTypeCode":"-1" ,
      "serviceName" :"-1"
  
    }
    setValues(resetData);
    setShowTable(false);

  };


  const handleChanges = name => (event) => {
    
      setValues({ ...values, [name]: event.target.value });
 
    
  };

  const searchCheck = () => {
    setspinnerLoader(true);
    seterrorMessages([]);
    let errorMessagesArray = [];
    setErrors({})
    if(values.batchTypeCode=="-1" && values.claimTypeCode=="-1"  && values.serviceName=="-1"){
    setErrors({
      selectoneTypeErr: values.batchTypeCode == "-1" ? (() => { errorMessagesArray.push("At least one search filter must be entered"); return true; })() : false,
    });
  }
    if (errorMessagesArray.length > 0) {
      seterrorMessages(errorMessagesArray);
      setspinnerLoader(false);
      return false;
    }
    let searchCriteria = {
     
      "claimTypeCode": values.claimTypeCode != "-1"  ? values.claimTypeCode.split('-').shift() :null,
      "batchTypeCode": values.batchTypeCode != "-1" ? values.batchTypeCode.split('-').shift() :null,
      "serviceName":   values.serviceName != "-1" ? values.serviceName.split('-').shift() :null,
     // "networkID": values.networkId != "-1" ? values.networkId : "",
       }
    onSearch(searchCriteria);
  };

  useEffect(() => {
    // if (payload != null && !payload.success) {
    //   setspinnerLoader(false);
    //   seterrorMessages([ExceptionCodeConstants.ERROR_OCCURED_DURING_TRANSACTION])
    // }
    if (payload != null && payload.data != null && payload.data.length >= 0) {
      setspinnerLoader(false);
    }
    if (payload != null && payload.data != null && payload.data.length == 0) {
      setShowTable(true);
      // setShowNoRecords(true);
      // seterrorMessages([ExceptionCodeConstants.NO_RECORDS_WITHSEARCH])
    }
    if (payload != null && payload.data != null  &&   payload.data.length <= 0) {
      setspinnerLoader(false);
      setShowNoRecords(true);
      seterrorMessages([ExceptionCodeConstants.NO_RECORDS_WITHSEARCH])
    }
    if (payload != null && payload.data != null && payload.data.length > 0) {
      setShowTable(true);
    }
    if (payload != null && payload.data != null && ((payload.data.length===1) || payload.data.length === 1)) {
      setShowTable(true);
      setspinnerLoader(true);

      onSearchView({
        typeCode: payload.data[0].typeCode,
        batchTypeCode: payload.data[0].batchTypeCode,
        adjCtrlSeqNum : payload.data[0].adjCtrlSeqNum

      });
      setRedirect(true);

    }
  }, [payload]);

  const addUrl = () => {
    props.history.push({
      pathname: '/AdjudicationControlDetails'
    })
  }

  const viewUrl = () => {
    props.history.push({
      pathname: '/AdjudicationControlView'
    })
  }

  return (
    <div className="pos-relative">
      {spinnerLoader && <Spinner />}

      {errorMessages.length > 0 && (
        <div className="alert alert-danger custom-alert hide-on-print" role="alert">
          {errorMessages.map(message => <li>{message}</li>)}
        </div>
      )
      }

      {showNoRecords && payload === null && (
        <div className="alert alert-danger custom-alert hide-on-print" role="alert">
          <li>{ExceptionCodeConstants.NO_RECORDS_WITHSEARCH}</li>
        </div>
      )
      }
  { successMessages.length > 0 ? (<SuccessComponent successMessages={successMessages} setSuccessMessages={setSuccessMessages} />) : null}
      <div className="mb-2">
        <BreadCrumbs
          parent="Claims Configuration"
         
          child1="Adjudication Control"
          path="/AdjudicationControl"
        />
      </div>

      <div className="tabs-container" ref={printRef}>
        <div className="page-header">
          <h1 className="page-heading float-left">
            Adjudication Control 
          </h1>
          <div className="float-right th-btnGroup">
            
            {/* <Link to={Pdf} target="_blank" title="View"  className="btn btn-ic btn-view" >
              View </Link> */}
            <Button title="Add Adjudication Control " variant="outlined" color="primary" className="btn btn-ic btn-add" onClick={() => addUrl()}>
              Add
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (
                <Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
                  Print
                </Button>)}
              content={() => printRef.current}
            />
                        <Button onClick={() => {window.open("Help",'_blank');}} title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
                    HELP
                </Button>
          </div>
        </div>

        {/* Search Claim Exception form start */}
        <div className="tab-body mt-2">
          <AdjudicationControlSearchForm handleChanges={handleChanges} values={values} searchCheck={searchCheck} resetTable={resetTable}
            dropdowns={addDropdowns} 
            errors={{selectoneTypeErr}} />

          {
            showTable && payload && payload.data && payload.data.length > 0 ? (
              <div className="container-space mt-2">
                <div class="fw-600 mb-2">Search Results</div>
                <AdjudicationControlSearchTable
                  print
                  tableData={payload.data.map((val)=> {
                  //  return{...val,claimTypeCode : val.claimTypeCode.split("-").pop(),batchTypeCode : val.batchTypeCode.split("-").pop()}
                  return {...val}
                   
                  }
                ) }
                  // tableErrorFunction={tableErrorFunction}adjudicationControlSchedule
                  setspinnerLoader={setspinnerLoader}
                  redirect={redirect}
                  setRedirect={setRedirect}
                />

              </div>
            ) : null
          }
        </div>
        {/* Search Claim Exception form end */}

        {/* <div className="clearfix"></div> */}
        <div className="tab-body mt-2">

          <Footer print />
        </div>
      </div>
    </div>
  );
}
export default withRouter(AdjudicationControlSearch);
