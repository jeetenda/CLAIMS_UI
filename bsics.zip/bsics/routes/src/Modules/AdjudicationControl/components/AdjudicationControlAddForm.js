import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import DateFnsUtils from '@date-io/date-fns';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import {
	KeyboardDatePicker,
	MuiPickersUtilsProvider	
} from '@material-ui/pickers';
import * as ErrorMsgConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import dateFnsFormat from 'date-fns/format';

export default function AdjudicationControlAddForm(props) {

const claimTypeDropDown = props.dropdowns && props.dropdowns['Claims#C_TY_CD'] && props.dropdowns['Claims#C_TY_CD'].map(each => (
  <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));
const docTypeDropDown = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'] && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'].map(each => (
  <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));
const serviceDropDown = props.dropdowns && props.dropdowns['C4#C_SVC_NAM'] && props.dropdowns['C4#C_SVC_NAM'].map(each => (
  <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));
const faultServiceDropDown = props.dropdowns && props.dropdowns['C4#C_FAULT_SVC_NAM'] && props.dropdowns['C4#C_FAULT_SVC_NAM'].map(each => (
  <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));

	return (
		<form autoComplete="off">
			<div className="form-wrapper">
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-serviceSequencee"
            data-test='serSeq'
            label="Service Sequence"
            value={props.values.adjCtrlSeqNum}
            inputProps={{ maxLength: 7 }}
            onChange={props.handleChanges('adjCtrlSeqNum')}
            placeholder=""
            
            InputLabelProps={{
              shrink: true
            }}
            helperText={props.errors.adjCntrlSeqErr ? ErrorMsgConstants.ADJ_CNTRL_INVLD_ERR: null}
            error={props.errors.adjCntrlSeqErr ? ErrorMsgConstants.ADJ_CNTRL_INVLD_ERR: null}
          />
        </div>
        <div className="mui-custom-form with-select input-md">
          <TextField
            id="standard-select-ClaimType"
            select
            data-test='typeCode'
            label="Claim Type"
            value={props.values.typeCode}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('typeCode')}
            placeholder="Please Select One"
            // helperText={props.errors.placeOfServiceError ? ProcPlaceOfServiceConstants.PROC_POS_ERR : null}
            // error={props.errors.placeOfServiceError ? ProcPlaceOfServiceConstants.PROC_POS_ERR : null}

            InputLabelProps={{
              shrink: true
            }}
          >

            <MenuItem value="-1">Please Select One</MenuItem>
            {claimTypeDropDown}
          </TextField>
        </div>

        <div className="mui-custom-form with-select input-md">
          <TextField
            id="standard-select-batchDocType"
            select
            data-test='batchTypeCode'
            label="Batch Document Type"
            value={props.values.batchTypeCode}
            inputProps={{ maxLength: 2 }}
            onChange={props.handleChanges('batchTypeCode')}
            placeholder="Please Select One"
            InputLabelProps={{
              shrink: true,
            }}
          >

            <MenuItem value="-1">Please Select One</MenuItem>
            {docTypeDropDown}
          </TextField>
        </div>
      </div>
      <div className="form-wrapper pt-0">
      <div className="mui-custom-form input-md">
          <TextField
            id="standard-serviceName"
            select
            data-test='serviceDef'
            label="Service Name"
            value={props.values.serviceDef}
            inputProps={{ maxLength: 50 }}
            onChange={props.handleChanges('serviceDef')}
            placeholder=""
            // helperText={props.errors.procCodeError ? ProcPlaceOfServiceConstants.Proc_Code_Req_Error : null}
            InputLabelProps={{
              shrink: true
            }}
            >
            <MenuItem value="-1">Please Select One</MenuItem>
            {serviceDropDown}
          </TextField>
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-preServiceName"
            select
            data-test='preServiceDef'
            label="Pre Service Name"
            value={props.values.preServiceDef}
            inputProps={{ maxLength: 50 }}
            onChange={props.handleChanges('preServiceDef')}
            placeholder=""
            // helperText={props.errors.procCodeError ? ProcPlaceOfServiceConstants.Proc_Code_Req_Error : null}
            InputLabelProps={{
              shrink: true
            }}
          >
            <MenuItem value="-1">Please Select One</MenuItem>
            {serviceDropDown}
          </TextField>
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-postServiceName"
            select
            data-test='postServiceDef'
            label="Post Service Name"
            value={props.values.postServiceDef}
            inputProps={{ maxLength: 50 }}
            onChange={props.handleChanges('postServiceDef')}
            placeholder=""
            // helperText={props.errors.procCodeError ? ProcPlaceOfServiceConstants.Proc_Code_Req_Error : null}
            InputLabelProps={{
              shrink: true
            }}
            >
            <MenuItem value="-1">Please Select One</MenuItem>
            {serviceDropDown}
          </TextField>
        </div>
        <div className="mui-custom-form input-md">
          <TextField
            id="standard-faultServiceName"
            select
            data-test='faultServiceDef'
            label="Fault Service Name"
            value={props.values.faultServiceDef}
            inputProps={{ maxLength: 50 }}
            onChange={props.handleChanges('faultServiceDef')}
            placeholder=""
            // helperText={props.errors.procCodeError ? ProcPlaceOfServiceConstants.Proc_Code_Req_Error : null}
            InputLabelProps={{
              shrink: true
            }}
            >
            <MenuItem value="-1">Please Select One</MenuItem>
            {faultServiceDropDown}
          </TextField>
        </div>
      </div>
			<div className="clearfix" />
		</form>
	);
}
