import React, { useState, useEffect, useRef } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import * as ErrorMsgConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import AdjudicationControlEditForm from './AdjudicationControlEditForm';
import Axios from 'axios';
import * as serviceEndPoint from '../../../SharedModules/services/service';
import Checkbox from '@material-ui/core/Checkbox';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_SYSTEMLIST_DROPDOWN, GET_APP_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';
import { resetCaseSearch, adjudicationControlDetailsAction, adjudicationControlUpdateAction } from '../actions';
import dateFnsFormat from 'date-fns/format';
import * as moment from 'moment';
import 'moment-range';
import { makeStyles } from '@material-ui/core/styles';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import NavigationPrompt from "react-router-navigation-prompt";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import { useConfirm } from '../../../SharedModules/MUIConfirm/index';
import ErrorComponent from '../../../SharedModules/Errors/TimeOutErrorMsg';
import SuccessComponent from '../../../SharedModules/Errors/TimeOutSuccessMsg';
import { getLoginUserDetails } from "../../../SharedModules/utility/utilityFunction";


const useStyles = makeStyles(theme => ({
  disabledcls: {
    pointerEvents: "none"
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
  height: {
    maxHeight: 'none',
  }
}));

function AdjudicationControlEdit(props) {
  const classes = useStyles();
  let errorMessagesArray = [];
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const adjudicationDetails = useSelector(state => state.adjudicationControl.adjudicationControlDetails.data);
  const adjudicationDetailsTime = useSelector(state => state.adjudicationControl.adjudicationControlDetailsTime);
  const [values, setValues] = useState(adjudicationDetails);
  const updateServiceResp = useSelector(state => state.adjudicationControl.updateData);

  const printRef = useRef();
  const voidRef = useRef();
  const muiconfirm = useConfirm();
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [{ procCodeError, lobError, placeOfServiceError, procCodeInvalidErr }, setShowError] = React.useState(false);
  const [successMessages, setSuccessMessages] = React.useState([]);
  const [editPOS, setEditPOS] = useState(false);
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
  const [deleteSuccessUpdate, setDeleteSuccessUpdate] = useState(null);
  const [confirm, setConfirm] = useState(false);
  const  [prompt, setPrompt] = useState(false);
  const [cancelType, setCancelType] = useState(false);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState('');

  const onSearchView = searchvalues => dispatch(adjudicationControlDetailsAction(searchvalues));
  const updateAdjudicationControlService = (dataObj) => dispatch(adjudicationControlUpdateAction(dataObj));
  const onReset = () => dispatch(resetSearchCriteria());
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);

  
  const [showSuccessMessage, setShowSuccessMessage] = useState(false);

  const dispatch = useDispatch();
  const handleChanges = name => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };

  const handelPromptSet = (set) => {
    if (set) setPrompt(true);
  };

  const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });

  const majorDelete = () => {
        seterrorMessages([]);
        setSuccessMessages([]);
        setspinnerLoader(true);
        Axios.post(`${serviceEndPoint.ADJUDICATION_CONTROL_DELETE}`, values).then(res => {
          setspinnerLoader(false);

          if (values) {

            setConfirm(true);
            setDeleteSuccessUpdate(new Date());
            setSuccessMessages([ErrorMsgConstants.BENIFIT_PLAN_DELETE_SUCCESS]);
          } else { seterrorMessages([ErrorMsgConstants.DELETE_FAIL_MSG]); 
            }
        }).catch(e => {
          setspinnerLoader(false);
          seterrorMessages([ErrorMsgConstants.ERROR_OCCURED_DURING_TRANSACTION]);

        }); 
        setDialogOpen(false); setDialogType('');

  }

  useEffect(() => {
    if (deleteSuccessUpdate) {

      props.history.push({
        pathname: "/AdjudicationControl",
        deleteCode: true
      });
    }
  }, [deleteSuccessUpdate])


  const majorSave = () => {
    seterrorMessages([]);
    setSuccessMessages([]);
    setShowError({});  
      const data = {
      "typeCode": values.typeCode ? values.typeCode : null,
      "adjCtrlSeqNum": values.adjCtrlSeqNum ? values.adjCtrlSeqNum : null,
      "preServiceDef": values.preServiceDefDesc ? values.preServiceDefDesc : null,
      "serviceDef": values.serviceDefDesc ? values.serviceDefDesc : null,
      "postServiceDef": values.postServiceDefDesc ? values.postServiceDefDesc : null,
      "voidInd": values.voidInd ? values.voidInd: 'N',
      "faultServiceDef": values.faultServiceDefDesc ? values.faultServiceDefDesc : null,
      "typeCodeDesc": values.typeCodeDesc ? values.typeCodeDesc : null,
      "batchTypeCode": values.batchTypeCode ? values.batchTypeCode : null,
      "batchTypeCodeDesc": null,
      "cAdjudCntlSvcSk": values.cAdjudCntlSvcSk ? values.cAdjudCntlSvcSk : null
      };
      setspinnerLoader(true);
      updateAdjudicationControlService(data);
    }

  const serviceSuccessHandel = () => {
    setSuccessMessages(["System successfully saved the Information."])
    onSearchView({ 
    "typeCode": values.typeCode,
    "adjCtrlSeqNum": values.adjCtrlSeqNum,
    "preServiceDef": values.processPreAdjudicationUpdate,
    "serviceDef": values.serviceDef,
    "postServiceDef": values.postServiceDef,
    "voidInd": values.voidInd,
    "faultServiceDef": values.faultServiceDef,
    "typeCodeDesc": null,
    "batchTypeCode": values.batchTypeCode,
    "batchTypeCodeDesc": null,
    "cAdjudCntlSvcSk": values.cAdjudCntlSvcSk});
    }

  useEffect(() => {
    onDropdowns([
      Dropdowns.CLAIM_TYPE_STATUS,
      Dropdowns.CLAIM_EXC_C_BATCH_DOC_TY_CD,
      Dropdowns.SERVICE_NAME,
      Dropdowns.FAULT_SERVICE_NAME
    ]);
    if (showSuccessMessage) {
      setSuccessMessages(["System successfully saved the Information."]);
      setShowSuccessMessage(false);
    }
  }, [])

  useEffect(() => {
    setValues(adjudicationDetails);
    setShowSuccessMessage(true);   
  }, [adjudicationDetailsTime]);

  useEffect(() => {
    if (updateServiceResp) {
        setspinnerLoader(false);
        if (updateServiceResp.success) {
            serviceSuccessHandel();
        }
        else {
          if (updateServiceResp.status == '409' ) {
            seterrorMessages(["Duplicate Record."]);
          }
          else {
            seterrorMessages(["Record not updated!"]);
          }
        }
    }
}, [updateServiceResp])

  const searchAdjudicationControl = () => {
   setCancelType(true);
    props.history.push({
      pathname: '/AdjudicationControl'
    })
  }

  return (
    <div className="pos-relative">

      {spinnerLoader ? <Spinner /> : null}
      {errorMessages.length > 0 ? (<ErrorComponent errorMessages={errorMessages} setErrorMessages={seterrorMessages} />) : null}

      {successMessages.length > 0 ? (<SuccessComponent successMessages={successMessages} setSuccessMessages={setSuccessMessages} />) : null}
      <NavigationPrompt
                when={(crntLocation, nextLocation) => {if (confirm) {return false} else {handelPromptSet(nextLocation); return true}}}
                // when={true}
            >
                {({ onConfirm, onCancel }) => (
                    <Dialog
                        open={prompt}
                        aria-labelledby="alert-dialog-title"
                        aria-describedby="alert-dialog-description"
                        className="custom-alert-box"
                    >
                        <DialogContent>
                        <DialogContentText id="alert-dialog-description">
                            {cancelType ? "Are you sure that you want to Cancel?" : 
                            (<>Unsaved changes will be lost. <br/>
                             Are you sure you want to continue?</>)}
                        </DialogContentText>
                        </DialogContent>
                        {cancelType ? (<DialogActions>
                            <Button onClick={onConfirm} color="primary" className="btn btn-success">
                                Ok
                            </Button>
                            <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" autoFocus>
                                Cancel
                            </Button>
                        </DialogActions>) : (<DialogActions>
                            <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" className="btn btn-transparent">
                            STAY ON THIS PAGE!
                            </Button>
                            <Button onClick={onConfirm} color="primary" className="btn btn-success" autoFocus>
                            CONTINUE <i className="fa fa-arrow-right ml-1"></i>
                            </Button>
                        </DialogActions>)}
                    </Dialog>
                )}
            </NavigationPrompt>

      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to delete?
        </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {dialogType == 'majorDelete' ? majorDelete() : null }} color="primary" className="btn btn-success">
            Ok
            </Button>
          <Button onClick={() => { setDialogOpen(false); setDialogType(''); }} color="primary" autoFocus>
            Cancel
            </Button>
        </DialogActions>
      </Dialog>

      <div className="mb-2">
          <BreadCrumbs
          parent="Claims Configuration"
					child2="Edit Adjudication Control"
					path="AdjudicationControl"
				/>
      </div>
      <div className="tabs-container" ref={printRef}>
        <div className="page-header">
          <h1 className="page-heading float-left">
          Edit Adjudication Control
          </h1>
          <div className="float-right th-btnGroup">
            <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={majorSave} disabled={props.privileges && !props.privileges.update ? 'disabled' : ''}>
              Save
            </Button>
            <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => { setDialogOpen(true); setDialogType('majorDelete'); }} disabled={props.privileges && !props.privileges.update ? 'disabled' : ''}>
              Delete
            </Button>
            
            <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => searchAdjudicationControl()}>
              Cancel
            </Button>
            
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-primary">
                <i className="fa fa-print" />
              Print
              </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
              Help
            </Button>
          </div>
        </div>

        <div>
          
        </div>
        <div className="clearfix" />
        <div className="tab-body my-2 py-2">
          <AdjudicationControlEditForm values={values} handleChanges={handleChanges} errors={{procCodeError, lobError, placeOfServiceError, procCodeInvalidErr}} dropdowns={addDropdowns} />

        </div>
        <Footer print></Footer>
      </div>
    </div>
  );
}
export default withRouter(AdjudicationControlEdit);