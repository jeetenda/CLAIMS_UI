import React, { useState, useEffect, useRef } from 'react';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import * as ErrorMsgConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import AdjudicationControlAddForm from './AdjudicationControlAddForm';
import Axios from 'axios';
import * as serviceEndPoint from '../../../SharedModules/services/service';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import {GET_APP_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';
import * as moment from 'moment';
import 'moment-range';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import NavigationPrompt from "react-router-navigation-prompt";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import ErrorComponent from '../../../SharedModules/Errors/TimeOutErrorMsg';
import SuccessComponent from '../../../SharedModules/Errors/TimeOutSuccessMsg';
import { getLoginUserDetails } from "../../../SharedModules/utility/utilityFunction";
import { useConfirm } from '../../../SharedModules/MUIConfirm/index';
import { adjudicationControlCreateAction,adjudicationControlDetailsAction } from '../actions';

function AdjudicationControlAdd(props) {
  let errorMessagesArray = [];
  const [spinnerLoader, setspinnerLoader] = React.useState(false);
  const [values, setValues] = useState({
    "adjCtrlSeqNum": '',
    "typeCode": "-1",
    "batchTypeCode": "-1",
    "serviceDef": "-1",
    "preServiceDef": "-1",
    "postServiceDef": "-1",
    "faultServiceDef": "-1",
  });

  const printRef = useRef();
  const muiconfirm = useConfirm();

  const [errorMessages, setErrorMessages] = React.useState([]);
  const [successMessages, setSuccessMessages] = React.useState([]);
  
  const [prompt, setPrompt] = useState(false);
  const [cancelType, setCancelType] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [{ adjCntrlSeqErr }, setShowError] = React.useState(false);

  const [dialogOpen, setDialogOpen] = useState(false);
  const [dialogType, setDialogType] = useState('');
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
  
  const [{adjudicationErr }, setAdjudicationError] = React.useState(false);

  const onSearchView = searchvalues => dispatch(adjudicationControlDetailsAction(searchvalues));

  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);

  const addAdjudicationService = (dataObj) => dispatch(adjudicationControlCreateAction(dataObj));
  const addServiceResp = useSelector(state => state.adjudicationControl.createData);

  const dispatch = useDispatch();

  const handleChanges = (name) => (event) => {
    setValues({ ...values, [name]: event.target.value });
  };

  const handelPromptSet = (set) => {
    if (set) setPrompt(true);
  };


  useEffect(() => {
    if (addServiceResp) {
      setspinnerLoader(false);
      if (addServiceResp.message === 'success' || addServiceResp.status == 'Record Saved Successfully') {
        serviceSuccessHandel();
      }
      else {
        if (addServiceResp.status == '409' ) {
          setErrorMessages(["Duplicate Record."]);
        }
        else {
          setErrorMessages(["Record not added!"]);
        }
      }
    }
  }, [addServiceResp])

  useEffect(() => {
    onDropdowns([
      Dropdowns.CLAIM_TYPE_STATUS,
      Dropdowns.CLAIM_EXC_C_BATCH_DOC_TY_CD,
      Dropdowns.SERVICE_NAME,
      Dropdowns.FAULT_SERVICE_NAME
    ]);
  }, []);


  const majorSave = () => {
    setErrorMessages([]);
    setSuccessMessages([]);
    setAdjudicationError({});
    setShowError({});
    let adjCntrlSeqErr;

    if((values.adjCtrlSeqNum != '' || values.adjCtrlSeqNum != null) && !/^[0-9]+$/.test(values.adjCtrlSeqNum)){
      adjCntrlSeqErr = true;
      errorMessagesArray.push(ErrorMsgConstants.ADJ_CNTRL_INVLD_ERR);
      setErrorMessages(errorMessagesArray);
      return false;
    }
    const data = {
      "typeCode": values.typeCode != '-1' ? values.typeCode : null,
      "adjCtrlSeqNum": values.adjCtrlSeqNum ? values.adjCtrlSeqNum : null,
      "preServiceDef": values.preServiceDef != '-1' ? values.preServiceDef : null,
      "serviceDef": values.serviceDef != '-1' ? values.serviceDef : null,
      "postServiceDef": values.postServiceDef != '-1' ? values.postServiceDef : null,
      "voidInd": "N",
      "faultServiceDef": values.faultServiceDef != '-1' ? values.faultServiceDef : null,
      "typeCodeDesc": null,
      "batchTypeCode": values.batchTypeCode != '-1' ? values.batchTypeCode : null,
      "batchTypeCodeDesc": null
     };

     Axios.get(`${serviceEndPoint.ADJUDICATION_CONTROL_WARNING}/${values.typeCode}/${values.batchTypeCode}/${values.serviceDef}`).then(res => {
      setspinnerLoader(false);

      if (res.data.data) {
        muiconfirm({ title: "", description: 'Possible conflict for Claims Type/Batch Document Type/Service Name. Do you want to continue', dialogProps: { fullWidth: false } })
        .then(() => {
          setDialogOpen(false); setDialogType('');
          setspinnerLoader(true);
          addAdjudicationService(data);
        });
        
      }else{
        addAdjudicationService(data);
      }
      
    }).catch(e => {
      setspinnerLoader(false);
      setErrorMessages([ErrorMsgConstants.ERROR_OCCURED_DURING_TRANSACTION]);

    }); 
    
  }

  const serviceSuccessHandel = () => {
    setSuccessMessages(["System successfully saved the Information."]);
    onSearchView({
      "typeCode": values.typeCode,
      "adjCtrlSeqNum": values.adjCtrlSeqNum,
      "preServiceDef": values.processPreAdjudicationUpdate,
      "serviceDef": values.serviceDef,
      "postServiceDef": values.postServiceDef,
      "voidInd": "N",
      "faultServiceDef": values.faultServiceDef,
      "typeCodeDesc": null,
      "batchTypeCode": values.batchTypeCode,
      "batchTypeCodeDesc": null,
      "cAdjudCntlSvcSk": values.cAdjudCntlSvcSk
    });
  }


  const searchAdjudicationControl = () => {
    props.setCancelType(true);
    props.history.push({
      pathname: "/AdjudicationControl",
    });
  };

  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}
      { errorMessages.length > 0 ? (<ErrorComponent errorMessages={errorMessages} setErrorMessages={setErrorMessages} />) : null}
      { successMessages.length > 0 ? (<SuccessComponent successMessages={successMessages} setSuccessMessages={setSuccessMessages} />) : null}
      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to delete?
        </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => { dialogType == 'multiDelete' ? multiDelete() : null }} color="primary" className="btn btn-success">
            Ok
            </Button>
          <Button onClick={() => { setDialogOpen(false); setDialogType(''); }} color="primary" autoFocus>
            Cancel
            </Button>
        </DialogActions>
      </Dialog>
      <div className="mb-2">
        <BreadCrumbs
          parent="Claims Configuration"
          child2="Adjudication Control"
          path="AdjudicationControl"
        />
      </div>
      <div className="tabs-container" ref={printRef}>
        <div className="page-header">
          <h1 className="page-heading float-left">
            Add Adjudication Control
          </h1>
          <div className="float-right th-btnGroup">
            <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => majorSave()} disabled={props.privileges && !props.privileges.add ? 'disabled' : ''}>
              Save
            </Button>
            <Button title="Notes" variant="outlined" color="primary" className="btn btn-ic btn-notes" >
              Notes
            </Button>
            <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => searchAdjudicationControl()}>
              Cancel
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-primary">
                <i className="fa fa-print" />
              Print
              </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
              Help
            </Button>
          </div>
        </div>
        <div>

        </div>
        <div className="tab-body my-2 py-2">
          <AdjudicationControlAddForm values={values} handleChanges={handleChanges}  errors={{ adjudicationErr, adjCntrlSeqErr }} dropdowns={addDropdowns} />
        </div>
        <Footer print />
      </div>
    </div>
  );
}
export default withRouter(AdjudicationControlAdd);
