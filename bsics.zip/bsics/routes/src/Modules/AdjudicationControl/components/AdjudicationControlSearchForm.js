import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import Checkbox from '@material-ui/core/Checkbox';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import PropTypes from "prop-types"
import * as ExceptionCodeConstants from '../../../SharedModules/Messages/ErrorMsgConstants';

function AdjudicationControlSearchForm(props) {
<<<<<<< HEAD
	//console.log("state",props.values)
=======
	console.log("state is",props.values)
>>>>>>> b3dac61bc759e8ee586be2012630e1e21ebcd6df
	// const screeningType = props.values.screeningType;
	// let screeningTypeD = screeningType.split("-").pop();
	const claimTypeDropDown = props.dropdowns && props.dropdowns['Claims#C_TY_CD'] && props.dropdowns['Claims#C_TY_CD'].map(each => (
		<MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
	  ));
	  const docTypeDropDown = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'] && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'].map(each => (
		<MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
	  ));
	  const serviceDropDown = props.dropdowns && props.dropdowns['C4#C_SVC_NAM'] && props.dropdowns['C4#C_SVC_NAM'].map(each => (
		<MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
		));
		return (
		
		<form autoComplete="off">
			<div className="tab-body mt-2">
			<div className="form-wrapper">
				<div className="mui-custom-form with-select input-md">
					<TextField
						id="Claim_Type_Code"
						select
						//required
						label="Claim Type Code"
						value={props.values.claimTypeCode}
						inputProps={{ maxLength: 1 }}
						onChange={props.handleChanges('claimTypeCode')}
						placeholder="Please Select One"
						InputLabelProps={{
							shrink: true,
						}}
						//  helperText={props.errors.screeningTypeErr ? ExceptionCodeConstants.SCREENING_TYPE_ERR : null}
						//  helperText={props.errors.screeningTypeErr ? ExceptionCodeConstants.SCREENING_TYPE_ERR : null}
					>
						<MenuItem value="-1">Please Select One</MenuItem>
            {claimTypeDropDown}
					</TextField>
					
					
				</div>

				<div className="mui-custom-form with-select input-md">
					<TextField
						id="Claim_Batch_Document_Type"
						select
						//required
						label="Claim Batch Document Type"
						value={props.values.batchTypeCode}
						inputProps={{ maxLength: 1 }}
						onChange={props.handleChanges('batchTypeCode')}
						placeholder="Please Select One"
						InputLabelProps={{
							shrink: true,
						}}
						//  helperText={props.errors.screeningTypeErr ? ExceptionCodeConstants.SCREENING_TYPE_ERR : null}
						//  helperText={props.errors.screeningTypeErr ? ExceptionCodeConstants.SCREENING_TYPE_ERR : null}
					>
						<MenuItem value="-1">Please Select One</MenuItem>
            			{docTypeDropDown}
					</TextField>
					
					
				</div>

				<div className="mui-custom-form with-select input-md">
					<TextField
						id="Service_name"
						select
						//required
						label="Service name"
						value={props.values.serviceName}
						inputProps={{ maxLength: 1 }}
						onChange={props.handleChanges('serviceName')}
						placeholder="Please Select One"
						InputLabelProps={{
							shrink: true,
						}}
						//  helperText={props.errors.screeningTypeErr ? ExceptionCodeConstants.SCREENING_TYPE_ERR : null}
						//  helperText={props.errors.screeningTypeErr ? ExceptionCodeConstants.SCREENING_TYPE_ERR : null}
					>
						<MenuItem value="-1">Please Select One</MenuItem>
            {serviceDropDown}
          </TextField>
					
					
				</div>
				

				
				
                </div>
				{/* <div className="form-wrapper">
				
				<div className="mui-custom-form with-select input-md">
				<div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Status</label>
                                                </div>
				<div className="sub-radio set-rd-pos mt-1">
					
					
              <Radio
                type="radio"
                value="Active"
                id="active-periodicity-schedule"
                checked={props.values.status === 'Active'}
                onChange={props.handleChanges('status')}
              />
              <label for="descriptionStartsId" className="text-black" htmlFor="descriptionStartsId">Active</label>
              <Radio
                type="radio"
                value="Inactive"
                id="inactive-periodicity-schedule"
                checked={props.values.status === 'Inactive'}
                onChange={props.handleChanges('status')}
                className="ml-2"
              />
              <label for="descriptionContainsId" className="text-black" htmlFor="descriptionContainsId">Inactive</label>
            </div>
				</div>
				
                </div> */}
			<div className="tab-footer px-3 pb-3">
			<div className="float-right th-btnGroup">
				<Button
					title="Search"
					variant="outlined"
					color="primary"
					className="btn btn-ic btn-search"
					onClick={props.searchCheck}
					disabled={props.privileges && !props.privileges.search ? 'disabled' : ''}
					data-test="btn_search"
				>
					{' '}
					Search
          {' '}

				</Button>
				<Button
					title="Reset"
					variant="outlined"
					color="primary"
					className="btn btn-ic btn-reset"
					onClick={props.resetTable}
					data-test="btn_reset"
				>
					{' '}
					Reset
          {' '}

				</Button>
			</div>
			</div>
			</div>

		</form>
	);
}




export default AdjudicationControlSearchForm
