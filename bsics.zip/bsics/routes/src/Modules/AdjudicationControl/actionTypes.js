export const AdjudicationControl_RESETDATA = 'AdjudicationControl_RESETDATA';
export const AdjudicationControl_SEARCH_DATA = 'AdjudicationControl_SEARCH_DATA';
export const AdjudicationControl_VIEW_DETAILS_TYPE = 'AdjudicationControl_VIEW_DETAILS_TYPE';
export const AdjudicationControl_CREATE = 'AdjudicationControl_CREATE';
export const AdjudicationControl_UPDATE = 'AdjudicationControl_UPDATE';
// export const PROCEDURE_PROVIDER_NETWORK_DELETE = 'PROCEDURE_PROVIDER_NETWORK_DELETE';