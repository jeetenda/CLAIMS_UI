import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';
import { getLoginUserDetails } from "../../SharedModules/utility/utilityFunction";

const userDetails = getLoginUserDetails();

export const resetCaseSearch = () => ({
    type: actionTypes.AdjudicationControl_RESETDATA,
    resetData: []
});

export const dispatchSearch = (response) => ({
    type: actionTypes.AdjudicationControl_SEARCH_DATA,
    payload: response
})
export const dispatchAdjudicationControlViewDetails = (response) => ({
    type: actionTypes.AdjudicationControl_VIEW_DETAILS_TYPE,
    AdjudicationControlSearchData: response
});

export const dispatchAdjudicationControlCreate = (response) => ({
    type: actionTypes.AdjudicationControl_CREATE,
    createData: response
});

export const dispatchAdjudicationControlUpdate = (response) => ({
    type: actionTypes.AdjudicationControl_UPDATE,
    updateData: response
});

export const searchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.ADJUDICATION_CONTROL_SEARCH}`, values)
        .then(response => {
            dispatch(dispatchSearch(response.data));
        })
        .catch(error => {
            dispatch(dispatchSearch(error.response.data));
        })
}

export const adjudicationControlDetailsAction = values => dispatch => {   
    return axios.get(`${serviceEndPoint.ADJUDICATION_CONTROL_DETAILS}/${values.typeCode}/${values.batchTypeCode}/${values.adjCtrlSeqNum}`)
        .then(response => {
            dispatch(dispatchAdjudicationControlViewDetails(response.data));
        })
        .catch(error => {
            dispatch(dispatchAdjudicationControlViewDetails(error.response.data));
        })    
}

export const adjudicationControlCreateAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.ADJUDICATION_CONTROL_ADD}`, values)
    .then(response => {
        dispatch(dispatchAdjudicationControlCreate(response.data));
    })
    .catch(error => {
        dispatch(dispatchAdjudicationControlCreate(error.response.data));
    })
}

export const adjudicationControlUpdateAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.ADJUDICATION_CONTROL_UPDATE}`, values)
        .then(response => {
            dispatch(dispatchAdjudicationControlUpdate(response.data));
        })
        .catch(error => {
            dispatch(dispatchAdjudicationControlUpdate(error.response.data));
        })
}



