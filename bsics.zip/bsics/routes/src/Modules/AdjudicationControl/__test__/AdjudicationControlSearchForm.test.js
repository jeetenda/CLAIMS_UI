import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import "babel-polyfill"
//import LineItem,{getTableData, getTableData2, editRow}  from "../components/LineItemInstitutional";
import AdjudicationControlSearchForm  from "../components/AdjudicationControlSearchForm";
//import TableLineItemComponent from '../components/TableLineItem';
import TableComponent from './../../../SharedModules/Table/Table';
//import TableLI from '../../../SharedModules/Table/Table'
import * as ExceptionCodeConstants from '../../../SharedModules/Messages/ErrorMsgConstants';

const middlewares = [thunk]

const reactMock = require("react");
const setHookState = (newState) =>
    jest.fn().mockImplementation(() => [newState, () => { }]);

  reactMock.useState = setHookState({
    // setShowDetails: jest.fn(),
    //     showDetails: true,     
  });

describe('Adjudication Control SearchForm Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper, useEffect,wrapper2

    // intitial state for component
    const initialState = {editRow: jest.fn(),}

    // intitial props for component
    const componentProps = {
        dropdowns: {
            "Claims#C_TY_CD":[{code:123,description:"test"}],
            "ClaimException#C_BATCH_DOC_TY_CD":[{code:123,description:"test"}],
            "C4#C_SVC_NAM":[{code:123,description:"test"}]
        },
    handleChanges:jest.fn(),
    resetTable:jest.fn(),
    resetTable:jest.fn(),
    searchCheck:jest.fn(),
    errors:{SCREENING_TYPE_ERR : false},
        values:{
        "claimTypeCode":"F",
        "batchTypeCode":"-1",
        "serviceName":"-1"
    },
    privileges:{search:"true"}
    }

    const componentProps2 = {
        dropdowns: {
            "Claims#C_TY_CD":[{code:123,description:"test"}],
            "ClaimException#C_BATCH_DOC_TY_CD":[{code:123,description:"test"}],
            "C4#C_SVC_NAM":[{code:123,description:"test"}]
        },
    handleChanges:jest.fn(),
    resetTable:jest.fn(),
    resetTable:jest.fn(),
    searchCheck:jest.fn(),
    errors:{SCREENING_TYPE_ERR : "true"},
        values:{
        "claimTypeCode":"-1",
        "batchTypeCode":"-1",
        "serviceName":"-1"
    },
    privileges:{search:false}
    }


    //beforeEach Run before testcases is run  

    beforeEach(() => {

        useEffect = jest.spyOn(React, "useEffect").mockImplementation(f => f());

        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><AdjudicationControlSearchForm  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
       // console.log(wrapper.debug())
       wrapper2 = shallow(<Provider store={store}><Router><AdjudicationControlSearchForm  {...componentProps2} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
    })


    //expect used for assert the component and match the output with testing condition

    describe('Render Adjudication Control SearchForm Component', () => {

        it('should render Claim_Batch_Document_Type without error', () => {
            const component = wrapper.find("#Claim_Batch_Document_Type")
            expect(component.length).toBe(1);
           
        })

        it('should render Claim_Type_Code without error', () => {
            const component = wrapper.find("#Claim_Type_Code")
            expect(component.length).toBe(1);
        })

        it('should render btn_search without error', () => {
            const component = wrapper.find("[data-test='btn_search']")
            expect(component.length).toBe(1);
        })

        it('should render btn_reset without error', () => {
            const component = wrapper.find("[data-test='btn_reset']")
            expect(component.length).toBe(1);
        })
        it('should render Claim_Batch_Document_Type without error', () => {

            const component= wrapper2.find("#Claim_Batch_Document_Type")
            expect(component.length).toBe(1);
        })
        it('should render Claim_Type_Code without error', () => {
            const component = wrapper2.find("#Claim_Type_Code")
            expect(component.length).toBe(1);
        })

        it('should render btn_search without error', () => {
            const component = wrapper2.find("[data-test='btn_search']")
            expect(component.length).toBe(1);
        })

        it('should render btn_reset without error', () => {
            const component = wrapper2.find("[data-test='btn_reset']")
            expect(component.length).toBe(1);
        })

        

        // it('should check exception for function call on total table component without error', () => {
        //     getTableData([]);
    
        //   });
        //   it('should check exception for function call on total table component without error', () => {
        //     getTableData2([]);
    
        //   });
    
    })

//     test("calling edit row function", () => {
        
//         const setShowDetails = jest.fn();
//         const setLineItem = jest.fn();
        
//         editRow({}, setShowDetails, setLineItem)
        
//        });
    
//        it('should check exception for function call on total table component without error', () => {
//         const editRow = jest.fn();
//         const setShowDetails = jest.fn();
//         const setLineItem = jest.fn();
//         const tableComp = wrapper.find(TableComponent)
//         tableComp.at(0).prop('onTableRowClick')(editRow,setShowDetails,setLineItem);
//         expect(tableComp.length).toBe(6);
//       });

//       it('should check exception for function call on total table component without error', () => {
//         const editRow = jest.fn();
//         const setShowDetails = jest.fn();
//         const setLineItem = jest.fn();
//         const tableComp = wrapper.find(TableLI)
//         tableComp.at(0).prop('onTableRowClick')(editRow,setShowDetails,setLineItem);
//         expect(tableComp.length).toBe(6);
//       });

//       it('should check exception for function call on total table component without error', () => {
//         const editRow = jest.fn();
//         const setShowDetails = jest.fn();
//         const setLineItem = jest.fn();
//         const tableComp = wrapper.find(TableLineItemComponent)
//         tableComp.at(0).prop('onTableRowClick')(editRow,setShowDetails,setLineItem);
//         expect(tableComp.length).toBe(1);
//       });

//       it('should check exception for function call on total table component without error', () => {
//         getTableData([{lineNumber: 1, lineno: 1}], 1);

//       });

//       it('should check exception for function call on total table component without error', () => {
//         getTableData([{lineNumber: 2, lineno: 41}], 2);

//       });

//       it('should check exception for function call on total table component without error', () => {
//         getTableData2([{lineNumber: 1, lineno: 1}]);

//       });

//       it('should check exception for function call on total table component without error', () => {
// wrapper.find("[data-test='test-closeButton']").simulate('click')
// const  x  = { tableData: {
//     institutionalClaimsDataVO: {lineItemsList : []} } }
//         store = mockStore(initialState)
// const wrapper2 = shallow(<Provider store={store}><Router><LineItem  {...x} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
// });
// it('should check exception for function call on total table component without error', () => {

//         React.useState = jest.fn(() => [{svcAuthID: true}, jest.fn])
//     const  x  = { tableData: {
//         institutionalClaimsDataVO: {lineItemsList : []} } }
//             store = mockStore(initialState)
//     const wrapper2 = shallow(<Provider store={store}><Router><LineItem  {...x} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
//     });

//     it('should check exception for function call on total table component without error', () => {

//         React.useState = jest.fn(() => [{svcAuthID: true}, jest.fn])
//     const  x  = { tableData: {
//         allLineNumberSubmittedProviders: [],
//         institutionalClaimsDataVO: {lineItemsList : []} } }
//             store = mockStore(initialState)
//     const wrapper2 = shallow(<Provider store={store}><Router><LineItem  {...x} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
//     });
});
