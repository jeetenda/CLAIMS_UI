import React from "react";
import { shallow, mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"
import AdjudicationControlAddForm from "../components/AdjudicationControlAddForm"


const middlewares = [thunk]

const reactMock = require("react");

const setHookState = (newState) =>
    jest.fn().mockImplementation(() => [newState, () => { }]);

  reactMock.useState = setHookState({
    setSelectedBeginDate: jest.fn(),
    selectedBeginDate: '10/10/2020',     
  });

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('Adjudication Control Add Form Component', () => {

    const mockStore = configureStore(middlewares);
    
    let store, wrapper,useEffect

    // intitial state for component
    const initialState = {

    }
    

    // intitial props for component
    const componentProps = {
        values: {
            "adjCtrlSeqNum": null,
            "typeCode": "-1",
            "batchTypeCode": "-1",
            "serviceDef": "-1",
            "preServiceDef": "-1",
            "postServiceDef": "-1",
            "faultServiceDef": "-1",
            
        },
        handleChanges: jest.fn(),

        errors: {
            adjCntrlSeqErr: false, 
        }

    }

    //beforeEach Run before testcases is run 
    //for shallow 
   
    beforeEach(() => {
        store = mockStore(initialState);
        wrapper = shallow(<Provider store={store}><Router><AdjudicationControlAddForm {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
        useEffect = jest.spyOn(React, 'useEffect').mockImplementation(f => f());
    })



    describe('Rendering of Adjudication Control ADD form Component', () => {

        it('should render Service Sequence without error', () => {
            const component = wrapper.find("[data-test='serSeq']")
            expect(component.exists()).toBe(true);

        })

        it('should render Type code without error', () => {
            const component = wrapper.find("[data-test='typeCode']")
            expect(component.length).toBe(1);

        })

        it('should render Batch Type Code without error', () => {
            const component = wrapper.find("[data-test='batchTypeCode']")
            expect(component.length).toBe(1);
        })

        it('should render Service Name without error', () => {
            const component = wrapper.find("[data-test='serviceDef']")
            expect(component.length).toBe(1);
        })
        it('should render Pre Service Name without error', () => {
            const component = wrapper.find("[data-test='preServiceDef']")
            expect(component.length).toBe(1);
        })
        it('should render Post Service Name without error', () => {
            const component = wrapper.find("[data-test='postServiceDef']")
            expect(component.length).toBe(1);
        })
        it('should render Fault Serice Name without error', () => {
            const component = wrapper.find("[data-test='faultServiceDef']")
            expect(component.length).toBe(1);
        })
        

        it('should render mass change type dropdown without error', () => {

            React.useState = jest.fn(() => [{svcAuthID: true}, jest.fn])
            const componentProps1 = {
                handleChanges: jest.fn(),
                searchCheck: jest.fn(),
                resetTable: jest.fn(),
                dropdowns: {
                    'Claims#C_TY_CD': [
                      {
                        code: "1",
                        description: "1-CarrMerge",
                        longDescription: "1-CarrMerge",
                      }
                    ],
                    'ClaimException#C_BATCH_DOC_TY_CD': [
                        {
                          code: "1",
                          description: "1-CarrMerge",
                          longDescription: "1-CarrMerge",
                        }
                      ],
                      'C4#C_SVC_NAM': [
                        {
                          code: "1",
                          description: "1-CarrMerge",
                          longDescription: "1-CarrMerge",
                        }
                      ],
                      'C4#C_FAULT_SVC_NAM': [
                        {
                          code: "1",
                          description: "1-CarrMerge",
                          longDescription: "1-CarrMerge",
                        }
                      ]
                  },
                  privileges: {search: true},
                values: {
                    serviceDef: 'Please Select One',
                    preServiceDef: 'Please Select One',
                    postServiceDef: 'Please Select One',
                    faultServiceDef: 'Please Select One'
                },
                errors: {
                    adjCntrlSeqErr : true,
                }
            }
                store = mockStore(initialState)
        const wrapper2 = shallow(<Provider store={store}><Router><AdjudicationControlAddForm  {...componentProps1} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
        });

    });


})