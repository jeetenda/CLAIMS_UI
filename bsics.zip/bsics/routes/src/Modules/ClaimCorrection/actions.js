import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';

export const resetSearchClaimsCorrection = () => ({
    type: actionTypes.RESETDATA,
    resetData: []
});

export const dispatchClaimsCorrectionTCNSearch = (response) => ({
    type: actionTypes.CLAIMS_CORRECTION_SEARCH_TYPE,
    claimsCorrectionSearchData: response
});

export const dispatchClaimsCorrectionLocationSearch = (response) => ({
    type: actionTypes.CLAIMS_CORRECTION_LOCATION_SEARCH,
    claimsCorrectionLocationSearchData: response
});

export const dispatchClaimsCorrectionAdvanceSearch = (response) => ({
    type: actionTypes.CLAIMS_CORRECTION_ADVANCE_SEARCH,
    claimsCorrectionAdvanceSearchData: response
});

export const dispatchLocationDropdown = (response) => ({
    type: actionTypes.GET_LOCATION_DROPDOWN,
    locationData: response,
});

export const dispatchGetClaimCorrectionData = (response) => ({
    type: actionTypes.GET_ALL_CLAIMS_CORRECTION_DATA,
    getAllClaimsCorrectionData: response
});

export const dispatchClaimCorrectionMemberLockingData = (response) => ({
    type: actionTypes.CLAIMS_CORRECTION_MEMBER_LOCKING_DATA,
    claimsCorrectionMemberLocking: response
});
export const dispatchClaimCorrectionReleaseLockingData = (response) => ({
    type: actionTypes.CLAIMS_CORRECTION_RELEASE_LOCKING_DATA,
    claimsCorrectionReleaseLocking: response
});

export const claimCorrectionTCNSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_CORRECTION_TCN_SEARCH}`, values)
        .then(response => {
            //console.log(response.data.data.searchResults)
            if (response.status === 500 || response.status === 400) {
                dispatch(dispatchClaimsCorrectionTCNSearch(response.data));
            } else if (response.status === 200 && response.data.data.recordCount === 0) {
                dispatch(dispatchClaimsCorrectionTCNSearch(response.data));
            }
            else {
                 let obj = {
                     tcnNum:response.data.data.searchResults[0].tcn,
                     memAltId:response.data.data.searchResults[0].memberAltID,
                     userId:"TEST",
                     insertOrSelect:true,
                     ediIndicator:false,
                     dateOfBirth:"2013-03-24T21:04:35",
                     processFlag:false,
                 }
                 return axios.post(`${serviceEndPoint.CLAIM_CORRECTION_MEMBER_LOCK_ENDPOINT}`, obj)
                 .then(MLResponse => {
                     //console.log(MLResponse);
                     if (MLResponse.data.status === 'OK' && MLResponse.data.message === 'Member Locked') {
                         var claimType = response.data.data.searchResults[0].claimTypeCode.split('-')[0];
                         var memberSystemID = response.data.data.searchResults[0].memberSystemID;
                         var memberID = response.data.data.searchResults[0].memberID;
                         var tcn = response.data.data.searchResults[0].tcn
                         dispatch(getClaimCorrectionDetails({ claimType, tcn, memberSystemID }))
                     }else if(MLResponse.data.data.isLocked === true){
                         dispatch(dispatchClaimCorrectionMemberLockingData(MLResponse.data));
                     }
                 })
                // var claimType = response.data.data.searchResults[0].claimTypeCode.split('-')[0];
                // var memberSystemID = response.data.data.searchResults[0].memberSystemID;
                // var memberID = response.data.data.searchResults[0].memberID;
                // var tcn = response.data.data.searchResults[0].tcn
                // dispatch(getClaimCorrectionDetails({ claimType, tcn, memberSystemID, memberID }));

            }
        })
        .catch(error => {
            dispatch(dispatchClaimsCorrectionTCNSearch(error.data));
        })
}

export const getClaimCorrectionDetails = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_CORRECTION_DETAILS_ENDPOINT}`, values)
        .then(response => {
            //console.log(response);
            dispatch(dispatchGetClaimCorrectionData(response.data));
        }).catch(error => {
            dispatch(dispatchGetClaimCorrectionData(null));
        })
}

export const claimCorrectionMemberLocking = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_CORRECTION_MEMBER_LOCK_ENDPOINT}`, values)
        .then(response => {
            console.log(response);
            dispatch(dispatchClaimCorrectionMemberLockingData(response.data));
        }).catch(error => {
            dispatch(dispatchClaimCorrectionMemberLockingData(null));
        })
}
export const claimCorrectionReleaseLocking = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_CORRECTION_RELEASE_LOCK_ENDPOINT}`, values)
        .then(response => {
            console.log(response);
            dispatch(dispatchClaimCorrectionReleaseLockingData(response.data));
        }).catch(error => {
            dispatch(dispatchClaimCorrectionReleaseLockingData(null));
        })
}

export const claimCorrectionLocationSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_CORRECTION_LOCATION_SEARCH}`, values)
        .then(response => {
            console.log(response)
            if (response.data.status === 500 || response.data.status === 400) {
                dispatch(dispatchClaimsCorrectionLocationSearch(response.data));
            } else {
                dispatch(dispatchClaimsCorrectionLocationSearch(response.data));
            }
        })
        .catch(error => {
            dispatch(dispatchClaimsCorrectionLocationSearch(error.data));
        })
}

export const claimCorrectionAdvanceSearchAction = values => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_CORRECTION_ADVANCE_SEARCH}`, values)
        .then(response => {
            console.log(response)
            if (response.data.status === 500 || response.data.status === 400) {
                dispatch(dispatchClaimsCorrectionAdvanceSearch(response.data));
            } else {
                dispatch(dispatchClaimsCorrectionAdvanceSearch(response.data));
            }
        })
        .catch(error => {
            dispatch(dispatchClaimsCorrectionAdvanceSearch(error.data));
        })
}

export const locationDropdownAction = () => dispatch => {
    return axios.post(`${serviceEndPoint.CLAIM_LOCATION_DROPDOWN_ENDPOINT}`, {})
        .then(response => {
            console.log(response)
            if (response.data.status === 500 || response.data.status === 400) {
                dispatch(dispatchLocationDropdown(response.data));
            } else {
                dispatch(dispatchLocationDropdown(response.data));
            }
        })
        .catch(error => {
            dispatch(dispatchLocationDropdown(error.data));
        })
}