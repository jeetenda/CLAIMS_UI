import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"
import BasicClaimInfo from "../Components/DentalClaim/BasicClaimInfo"

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 24-Sep-2020
   * @author Himanshu Joshi
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('Basic Claim Info Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper

    // intitial state for component
    const initialState = {}

    // intitial props for component
    const componentProps = {
        data: { auditUserID: "SMOKEP1", auditTimeStamp: "2016-08-18T05:53:20.875+0000", addedAuditUserID: "SMOKEP1", addedAuditTimeStamp: "2016-08-18T05:53:20.875+0000", versionNo: 0 },
        setClaimEntryData: jest.fn()
    }

    //beforeEach Run before testcases is run  

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><BasicClaimInfo  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
        //console.log(wrapper.debug())
    })

    //expect used for assert the component and match the output with testing condition

    describe('Render Basic Claim Info Component', () => {

        it('should render submitter id without error', () => {
            const component = wrapper.find("[data-test='submitter-id']")
            expect(component.length).toBe(1);

        })

        describe('Provider Information', () => {

            describe('Billing Provider', () => {

                it('should render entity qualifier without error', () => {
                    const component = wrapper.find("[data-test='entity-qualifier']")
                    expect(component.length).toBe(1);

                })

                it('should render currency code without error', () => {
                    const component = wrapper.find("[data-test='currency-code']")
                    expect(component.length).toBe(1);

                })

                it('should render last name without error', () => {
                    const component = wrapper.find("[data-test='last-name']")
                    expect(component.length).toBe(1);

                })

                it('should render first name without error', () => {
                    const component = wrapper.find("[data-test='first-name']")
                    expect(component.length).toBe(1);

                })

                it('should render city without error', () => {
                    const component = wrapper.find("[data-test='city']")
                    expect(component.length).toBe(1);

                })

                it('should render state without error', () => {
                    const component = wrapper.find("[data-test='state']")
                    expect(component.length).toBe(1);

                })

                it('should render zip without error', () => {
                    const component = wrapper.find("[data-test='zip']")
                    expect(component.length).toBe(1);

                })

            })

            describe('Rendering (Performing) Provider', () => {

                it('should render entity qualifier without error', () => {
                    const component = wrapper.find("[data-test='rendering-entity-qualifier']")
                    expect(component.length).toBe(1);

                })

                it('should render last name without error', () => {
                    const component = wrapper.find("[data-test='rendering-last-name']")
                    expect(component.length).toBe(1);

                })

                it('should render first name without error', () => {
                    const component = wrapper.find("[data-test='rendering-first-name']")
                    expect(component.length).toBe(1);

                })

                it('should render mi without error', () => {
                    const component = wrapper.find("[data-test='rendering-mi']")
                    expect(component.length).toBe(1);

                })
                it('should render suffix without error', () => {
                    const component = wrapper.find("[data-test='rendering-suffix']")
                    expect(component.length).toBe(1);

                })

            })

            describe('Reffering Provider', () => {

                it('should render entity qualifier without error', () => {
                    const component = wrapper.find("[data-test='referring-entity-qualifier']")
                    expect(component.length).toBe(1);

                })

                it('should render last name without error', () => {
                    const component = wrapper.find("[data-test='referring-last-name']")
                    expect(component.length).toBe(1);

                })

                it('should render first name without error', () => {
                    const component = wrapper.find("[data-test='referring-first-name']")
                    expect(component.length).toBe(1);

                })

                it('should render mi without error', () => {
                    const component = wrapper.find("[data-test='referring-mi']")
                    expect(component.length).toBe(1);

                })
                it('should render suffix without error', () => {
                    const component = wrapper.find("[data-test='referring-suffix']")
                    expect(component.length).toBe(1);

                })

            })

        })

        describe('Member Information', () => {

            it('should render property casualty number without error', () => {
                const component = wrapper.find("[data-test='property-casualty-number']")
                expect(component.length).toBe(1);

            })

            it('should render ssn without error', () => {
                const component = wrapper.find("[data-test='ssn']")
                expect(component.length).toBe(1);

            })

            it('should render member entity qualifier without error', () => {
                const component = wrapper.find("[data-test='member-entity-qualifier']")
                expect(component.length).toBe(1);

            })

            it('should render address1 without error', () => {
                const component = wrapper.find("[data-test='address1']")
                expect(component.length).toBe(1);

            })

            it('should render responsibility sequence code without error', () => {
                const component = wrapper.find("[data-test='responsibility-sequence-code']")
                expect(component.length).toBe(1);

            })

            it('should render policy number without error', () => {
                const component = wrapper.find("[data-test='policy-number']")
                expect(component.length).toBe(1);

            })

            it('should render insurance type code without error', () => {
                const component = wrapper.find("[data-test='insurance-type-code']")
                expect(component.length).toBe(1);

            })

            it('should render entity qualifier without error', () => {
                const component = wrapper.find("[data-test='plan-name']")
                expect(component.length).toBe(1);

            })


        })

        describe('Claim Information', () => {

            it('should render auto accident country without error', () => {
                const component = wrapper.find("[data-test='auto-accident-country']")
                expect(component.length).toBe(1);

            })

            it('should render accident time without error', () => {
                const component = wrapper.find("[data-test='accident-time']")
                expect(component.length).toBe(1);

            })

            it('should render delay reason code without error', () => {
                const component = wrapper.find("[data-test='delay-reason-code']")
                expect(component.length).toBe(1);

            })

            it('should render special program type code without error', () => {
                const component = wrapper.find("[data-test='spec_prog_type_code_claim_data']")
                expect(component.length).toBe(1);

            })

            it('should render Predetermination Benefit ID Number without error', () => {
                const component = wrapper.find("[data-test='predetermine_benefit_id_num_claim_data']")
                expect(component.length).toBe(1);

            })
            it('should render Appliance Date without error', () => {
                const component = wrapper.find("[data-test='appliance_date_claim_data']")
                expect(component.length).toBe(1);

            })

            it('should render Medicare Assignment Code without error', () => {
                const component = wrapper.find("[data-test='medicare_assignment_code_claim_data']")
                expect(component.length).toBe(1);

            })


            it('should render claim notes without error', () => {
                const component = wrapper.find("[data-test='claim_notes']")
                expect(component.length).toBe(1);

            })


        })

        describe('Basic Line Item Information', () => {

            it('should render basic line header', () => {
                const component = wrapper.find("[data-test='basic-line']")
                expect(component.length).toBe(1);
    
            })

            it('should render basic line table without error', () => {
                const component = wrapper.find("[data-test='item-information']")
                expect(component.length).toBe(1);
    
            })
        })

    })
})


