import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import "babel-polyfill"

import OtherServiceInfo from "../components/OtherServiceInfo";

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 24-Sep-2020
   * @author Ganesh 
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })


describe('Dental Other Claim Info Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper
    
  // intitial state for component
  const initialState = {}

  const compProps = {
    data: {
        data: {},
        miscellaneousLineInfoVO: {},
        claimAdjustmentReasons: [],
      
    },
    showViewOtherPayer: true,
    showLLA: true
  }

  //beforeEach Run before testcases is run  

  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><OtherServiceInfo {...compProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive();
    console.log(wrapper.debug());
  })

  describe('Dentail Other Claim Info Component test cases', function () {
    it("should render Previous button without error", () => {
      const component = wrapper.find("#previous_button");
      expect(component.exists()).toBe(true);
    });
    it('should render Repriced Claim Number Component  without error', () => {
      const component = wrapper.find("[data-test='repriced-claim-number']")
      expect(component.length).toBe(1);
    });
    it('should render Adjusted Repriced Claim Number Component  without error', () => {
      const component = wrapper.find("[data-test='adjusted-repriced-claim-number']")
      expect(component.length).toBe(1);
    });
    it('should render Adjusted Repriced Claim Number Component  without error', () => {
      const component = wrapper.find("[data-test='adjusted-repriced-claim-number']")
      expect(component.length).toBe(1);
    });
    it('should render Predetermination Benefit Id Number Component  without error', () => {
      const component = wrapper.find("[data-test='predetermination-benefit-id-number']")
      expect(component.length).toBe(1);
    });
    it('should render Procedure Code Description Component  without error', () => {
      const component = wrapper.find("[data-test='procedureCodeDescription']")
      expect(component.length).toBe(1);
    });
    it('should render contractTypeCode Component  without error', () => {
      const component = wrapper.find("[data-test='contractTypeCode']")
      expect(component.length).toBe(1);
    });
    it('should render contractAmount Component  without error', () => {
      const component = wrapper.find("[data-test='contractAmount']")
      expect(component.length).toBe(1);
    });
    it('should render contractPercentage Component  without error', () => {
      const component = wrapper.find("[data-test='contractPercentage']")
      expect(component.length).toBe(1);
    });
    it('should render contractCode Component  without error', () => {
      const component = wrapper.find("[data-test='contractCode']")
      expect(component.length).toBe(1);
    });
    it('should render contractDiscountPercentage Component  without error', () => {
      const component = wrapper.find("[data-test='contractDiscountPercentage']")
      expect(component.length).toBe(1);
    });
    it('should render contractVersionID  without error', () => {
      const component = wrapper.find("[data-test='contractVersionID']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation1  without error', () => {
      const component = wrapper.find("[data-test='fileInformation1']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation2  without error', () => {
      const component = wrapper.find("[data-test='fileInformation2']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation3  without error', () => {
      const component = wrapper.find("[data-test='fileInformation3']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation4  without error', () => {
      const component = wrapper.find("[data-test='fileInformation4']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation5  without error', () => {
      const component = wrapper.find("[data-test='fileInformation5']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation6  without error', () => {
      const component = wrapper.find("[data-test='fileInformation6']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation7  without error', () => {
      const component = wrapper.find("[data-test='fileInformation7']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation8  without error', () => {
      const component = wrapper.find("[data-test='fileInformation8']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation9  without error', () => {
      const component = wrapper.find("[data-test='fileInformation9']")
      expect(component.length).toBe(1);
    });
    it('should render fileInformation10  without error', () => {
      const component = wrapper.find("[data-test='fileInformation10']")
      expect(component.length).toBe(1);
    });
    it('should render methodologyCode  without error', () => {
      const component = wrapper.find("[data-test='methodologyCode']")
      expect(component.length).toBe(1);
    });
    it('should render repriceAllowedAmount  without error', () => {
      const component = wrapper.find("[data-test='repriceAllowedAmount']")
      expect(component.length).toBe(1);
    });
    it('should render savingsAmount  without error', () => {
      const component = wrapper.find("[data-test='savingsAmount']")
      expect(component.length).toBe(1);
    });
    it('should render organizationID  without error', () => {
      const component = wrapper.find("[data-test='organizationID']")
      expect(component.length).toBe(1);
    });
    it('should render repricePerDiemRate  without error', () => {
      const component = wrapper.find("[data-test='repricePerDiemRate']")
      expect(component.length).toBe(1);
    });
    it('should render serviceCode  without error', () => {
      const component = wrapper.find("[data-test='serviceCode']")
      expect(component.length).toBe(1);
    });
    it('should render unitQuantity  without error', () => {
      const component = wrapper.find("[data-test='unitQuantity']")
      expect(component.length).toBe(1);
    });
    it('should render rejectReasonCode  without error', () => {
      const component = wrapper.find("[data-test='rejectReasonCode']")
      expect(component.length).toBe(1);
    });
    it('should render policyComplianceCode  without error', () => {
      const component = wrapper.find("[data-test='policyComplianceCode']")
      expect(component.length).toBe(1);
    });
    it('should render exceptionCode  without error', () => {
      const component = wrapper.find("[data-test='exceptionCode']")
      expect(component.length).toBe(1);
    });
    it('should render relatedDiagnosisPointer1  without error', () => {
      const component = wrapper.find("[data-test='relatedDiagnosisPointer1']")
      expect(component.length).toBe(1);
    });
    it('should render relatedDiagnosisPointer2  without error', () => {
      const component = wrapper.find("[data-test='relatedDiagnosisPointer2']")
      expect(component.length).toBe(1);
    });
    it('should render relatedDiagnosisPointer3  without error', () => {
      const component = wrapper.find("[data-test='relatedDiagnosisPointer3']")
      expect(component.length).toBe(1);
    });
    it('should render relatedDiagnosisPointer4  without error', () => {
      const component = wrapper.find("[data-test='relatedDiagnosisPointer4']")
      expect(component.length).toBe(1);
    });
    it('should render entityTypeCode  without error', () => {
      const component = wrapper.find("[data-test='entityTypeCode']")
      expect(component.length).toBe(1);
    });
    it('should render lastName  without error', () => {
      const component = wrapper.find("[data-test='lastName']")
      expect(component.length).toBe(1);
    });
    it('should render lastName  without error', () => {
      const component = wrapper.find("[data-test='lastName']")
      expect(component.length).toBe(1);
    });
    it('should render firstName  without error', () => {
      const component = wrapper.find("[data-test='firstName']")
      expect(component.length).toBe(1);
    });
    it('should render middleName  without error', () => {
      const component = wrapper.find("[data-test='middleName']")
      expect(component.length).toBe(1);
    });
    it('should render suffixName  without error', () => {
      const component = wrapper.find("[data-test='suffixName']")
      expect(component.length).toBe(1);
    });
    it('should render facilitylastName  without error', () => {
      const component = wrapper.find("[data-test='facilitylastName']")
      expect(component.length).toBe(1);
    });
    it('should render facilityAddressLine1  without error', () => {
      const component = wrapper.find("[data-test='facilityAddressLine1']")
      expect(component.length).toBe(1);
    });
    it('should render facilityAddressLine2  without error', () => {
      const component = wrapper.find("[data-test='facilityAddressLine2']")
      expect(component.length).toBe(1);
    });
    it('should render facilityCityName  without error', () => {
      const component = wrapper.find("[data-test='facilityCityName']")
      expect(component.length).toBe(1);
    });
    it('should render facilityStateCode  without error', () => {
      const component = wrapper.find("[data-test='facilityStateCode']")
      expect(component.length).toBe(1);
    });
    it('should render facilityZipCode  without error', () => {
      const component = wrapper.find("[data-test='facilityZipCode']")
      expect(component.length).toBe(1);
    });
    it('should render facilityZipCodeExt  without error', () => {
      const component = wrapper.find("[data-test='facilityZipCodeExt']")
      expect(component.length).toBe(1);
    });
    it('should render facilityCountryCode  without error', () => {
      const component = wrapper.find("[data-test='facilityCountryCode']")
      expect(component.length).toBe(1);
    });
    it('should render facilitySubDivisionCode  without error', () => {
      const component = wrapper.find("[data-test='facilitySubDivisionCode']")
      expect(component.length).toBe(1);
    });
    it('should render assistantLastName  without error', () => {
      const component = wrapper.find("[data-test='assistantLastName']")
      expect(component.length).toBe(1);
    });
    it('should render assistantFirstName  without error', () => {
      const component = wrapper.find("[data-test='assistantFirstName']")
      expect(component.length).toBe(1);
    });
    it('should render assistantMiddleName  without error', () => {
      const component = wrapper.find("[data-test='assistantMiddleName']")
      expect(component.length).toBe(1);
    });
    it('should render assistantSuffixName  without error', () => {
      const component = wrapper.find("[data-test='assistantSuffixName']")
      expect(component.length).toBe(1);
    });
    it('should render assistantLastName  without error', () => {
      const component = wrapper.find("[data-test='assistantLastName']")
      expect(component.length).toBe(1);
    });
    it('should render supervisingLastName  without error', () => {
      const component = wrapper.find("[data-test='supervisingLastName']")
      expect(component.length).toBe(1);
    });
    it('should render supervisingFirstName  without error', () => {
      const component = wrapper.find("[data-test='supervisingFirstName']")
      expect(component.length).toBe(1);
    });
    it('should render supervisingMiddleName  without error', () => {
      const component = wrapper.find("[data-test='supervisingMiddleName']")
      expect(component.length).toBe(1);
    });
    it('should render supervisingSuffixName  without error', () => {
      const component = wrapper.find("[data-test='supervisingSuffixName']")
      expect(component.length).toBe(1);
    });
    it("should render Table component without error", () => {
      const component = wrapper.find("#table");
      expect(component.exists()).toBe(true);
    });
    it('should render tplSequenceNumber  without error', () => {
      const component = wrapper.find("[data-test='tplSequenceNumber']")
      expect(component.length).toBe(1);
    });
    it('should render otherPayerID  without error', () => {
      const component = wrapper.find("[data-test='otherPayerID']")
      expect(component.length).toBe(1);
    });
    it('should render otherPayerPaidAmount  without error', () => {
      const component = wrapper.find("[data-test='otherPayerPaidAmount']")
      expect(component.length).toBe(1);
    });
    it('should render otherPayerPaidDate  without error', () => {
      const component = wrapper.find("[data-test='otherPayerPaidDate']")
      expect(component.length).toBe(1);
    });
    it('should render paidUnitCount  without error', () => {
      const component = wrapper.find("[data-test='paidUnitCount']")
      expect(component.length).toBe(1);
    });
    it('should render serviceQualifierCode  without error', () => {
      const component = wrapper.find("[data-test='serviceQualifierCode']")
      expect(component.length).toBe(1);
    });
    it('should render serviceCodeServiceLine  without error', () => {
      const component = wrapper.find("[data-test='serviceCodeServiceLine']")
      expect(component.length).toBe(1);
    });
    it('should render serviceDescription  without error', () => {
      const component = wrapper.find("[data-test='serviceDescription']")
      expect(component.length).toBe(1);
    });
    it('should render bundlingLineNumber  without error', () => {
      const component = wrapper.find("[data-test='bundlingLineNumber']")
      expect(component.length).toBe(1);
    });
    it('should render procedureModifier1  without error', () => {
      const component = wrapper.find("[data-test='procedureModifier1']")
      expect(component.length).toBe(1);
    });
    it('should render procedureModifier2  without error', () => {
      const component = wrapper.find("[data-test='procedureModifier2']")
      expect(component.length).toBe(1);
    });
    it('should render procedureModifier3  without error', () => {
      const component = wrapper.find("[data-test='procedureModifier3']")
      expect(component.length).toBe(1);
    });
    it('should render procedureModifier4  without error', () => {
      const component = wrapper.find("[data-test='procedureModifier4']")
      expect(component.length).toBe(1);
    });
    it('should render remainingPatientLiabilityAmount  without error', () => {
      const component = wrapper.find("[data-test='remainingPatientLiabilityAmount']")
      expect(component.length).toBe(1);
    });
    it('should render adjustmentGroupCode  without error', () => {
      const component = wrapper.find("[data-test='adjustmentGroupCode']")
      expect(component.length).toBe(1);
    });
    it('should render reasonCode  without error', () => {
      const component = wrapper.find("[data-test='reasonCode']")
      expect(component.length).toBe(1);
    });
    it('should render reasonAmount  without error', () => {
      const component = wrapper.find("[data-test='reasonAmount']")
      expect(component.length).toBe(1);
    });
    it('should render quantity  without error', () => {
      const component = wrapper.find("[data-test='quantity']")
      expect(component.length).toBe(1);
    });
    it('should render reasonCode2  without error', () => {
      const component = wrapper.find("[data-test='reasonCode2']")
      expect(component.length).toBe(1);
    });
    it('should render Amount 2  without error', () => {
      const component = wrapper.find("[data-test='othe3srf3srseermi']")
      expect(component.length).toBe(1);
    });
    it('should render quantity 2  without error', () => {
      const component = wrapper.find("[data-test='quantity2']")
      expect(component.length).toBe(1);
    });
    it('should render reasonCode3  without error', () => {
      const component = wrapper.find("[data-test='reasonCode3']")
      expect(component.length).toBe(1);
    });
    
   
})

})