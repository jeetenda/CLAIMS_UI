import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { claimCorrectionTCNSearchAction } from '../actions'
import * as actionTypes from '../actionTypes'
import OtherClaimInfo from "../components/DentalOtherInfo";

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 18-Sep-2020
   * @author Vamshi Krishna
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('Dental Other Claim Info Component', () => {

  const mockStore = configureStore(middlewares)
  let store, wrapper

  // intitial state for component
  const initialState = {}

  const compProps = {
    data: {
      claimProviderID: [],
      claimTPLInfo: {},
      diagnosis: [],
      enterpriseClaimAux: {
        c837ClaimHdr: {
          c837ClaimProvider: {}
        }
      }
    }
  }

  //beforeEach Run before testcases is run  

  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><OtherClaimInfo {...compProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive()
  })

  //expect used for assert the component and match the output with testing condition

  describe('Dentail Other Claim Info Component test cases', function () {

    it('should render Orthodontic Treatment Months Count Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-orthtretcount']")
      expect(component.length).toBe(1);
    });

    it('should render Orthodontic Treatment Months Remaining Count Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-orthtretmonths']")
      expect(component.length).toBe(1);
    })

    it('should render Orthodontic Treatment Indicator Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-orthtretind']")
      expect(component.length).toBe(1);
    })

    it('should render Principal Diag Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-princdiagcode']")
      expect(component.length).toBe(1);
    })

    it('should render Other Diagnosis Code 1 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-othdiagcode1']")
      expect(component.length).toBe(1);
    })

    it('should render Other Diagnosis Code 2 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-othdiagcode2']")
      expect(component.length).toBe(1);
    })

    it('should render Other Diagnosis Code 3 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-othdiagcode3']")
      expect(component.length).toBe(1);
    })

    it('should render Contract Type Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-conctypecode']")
      expect(component.length).toBe(1);
    })

    it('should render Contract Amount Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-concamt']")
      expect(component.length).toBe(1);
    })

    it('should render Contract Percent Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-contperc']")
      expect(component.length).toBe(1);
    })

    it('should render Contract Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-contcode']")
      expect(component.length).toBe(1);
    })

    it('should render Terms Discount Percent Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-descperc']")
      expect(component.length).toBe(1);
    })

    it('should render Contract Version ID Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-contid']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 1 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo1']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 2 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo2']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 3 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo3']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 4 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo4']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 5 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo5']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 6 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo6']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 7 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo7']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 8 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo8']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 9 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo9']")
      expect(component.length).toBe(1);
    })

    it('should render File Information 10 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-fileinfo10']")
      expect(component.length).toBe(1);
    })

    it('should render Pricing Methodology Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-pricmethcode']")
      expect(component.length).toBe(1);
    })

    it('should render Allowed Amount Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-allowamt']")
      expect(component.length).toBe(1);
    })

    it('should render Organization Identifier Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-orgident']")
      expect(component.length).toBe(1);
    })

    it('should render Savings Amount Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-savingamt']")
      expect(component.length).toBe(1);
    })

    it('should render Per Diem or Flat Rate Amt Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-rateamt']")
      expect(component.length).toBe(1);
    })

    it('should render Approved DRG Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-approvdrgcode']")
      expect(component.length).toBe(1);
    })

    it('should render Rejection Reason Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-regreasoncode']")
      expect(component.length).toBe(1);
    })

    it('should render Policy Compliance Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-policycomptcode']")
      expect(component.length).toBe(1);
    })

    it('should render Exception Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-execcode']")
      expect(component.length).toBe(1);
    })

    it('should render Org / Last Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-lastname']")
      expect(component.length).toBe(1);
    })

    it('should render Address 1 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-add1']")
      expect(component.length).toBe(1);
    })

    it('should render Address 2 Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-add2']")
      expect(component.length).toBe(1);
    })

    it('should render City Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-city']")
      expect(component.length).toBe(1);
    })

    it('should render State Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-state']")
      expect(component.length).toBe(1);
    })

    it('should render Zip Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-zip']")
      expect(component.length).toBe(1);
    })

    it('should render Extension Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-extension']")
      expect(component.length).toBe(1);
    })

    it('should render Country Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-country']")
      expect(component.length).toBe(1);
    })

    it('should render Subdivision Code Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-subdivcode']")
      expect(component.length).toBe(1);
    })

    it('should render Entity Qualifier Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-entyqualify']")
      expect(component.length).toBe(1);
    })

    it('should render First Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-firstname']")
      expect(component.length).toBe(1);
    })

    it('should render Org / Last Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-orglastname']")
      expect(component.length).toBe(1);
    })

    it('should render MI Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-mi']")
      expect(component.length).toBe(1);
    })

    it('should render Suffix Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-suffix']")
      expect(component.length).toBe(1);
    })

    it('should render Primary Care Provider First Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-primfirstname']")
      expect(component.length).toBe(1);
    })

    it('should render Primary Care Provider Org / Last Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-primlastname']")
      expect(component.length).toBe(1);
    })

    it('should render Primary Care Provider MI Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-primmi']")
      expect(component.length).toBe(1);
    })

    it('should render Primary Care Provider Suffix Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-primsuffix']")
      expect(component.length).toBe(1);
    })

    it('should render Assistant Surgeon First Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-assistfirstname']")
      expect(component.length).toBe(1);
    })

    it('should render Assistant Surgeon Org / Last Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-assistlastname']")
      expect(component.length).toBe(1);
    })

    it('should render Assistant Surgeon MI Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-assistmi']")
      expect(component.length).toBe(1);
    })

    it('should render Assistant Surgeon Suffix Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-assistsuffix']")
      expect(component.length).toBe(1);
    })

    it('should render Supervising Provider First Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-supprovfirstname']")
      expect(component.length).toBe(1);
    })

    it('should render Supervising Provider Org / Last Name Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-supprovlastname']")
      expect(component.length).toBe(1);
    })

    it('should render Supervising Provider MI Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-supprovmi']")
      expect(component.length).toBe(1);
    })

    it('should render Supervising Provider Suffix Component  without error', () => {
      const component = wrapper.find("[data-test='other-claim-info-supprovsuffix']")
      expect(component.length).toBe(1);
    })
  })


})