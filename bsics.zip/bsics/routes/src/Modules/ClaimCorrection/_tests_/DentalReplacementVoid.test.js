import React from "react"
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import moxios from 'moxios';
import "babel-polyfill"

import { claimCorrectionTCNSearchAction } from '../actions'
import * as actionTypes from '../actionTypes'
import ReplacementVoid from "../components/DentalClaim/ReplacementVoid";

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 17-Sep-2020
   * @author Divya Chauhan
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

describe('Dental Claim Replacement/Void Component', () => {

  const mockStore = configureStore(middlewares)
  let store, wrapper

  // intitial state for component
  const initialState = {}

  const compProps = {
    data: {
      claimAdjustment: ""
    }
  }

  //beforeEach Run before testcases is run  

  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = mount(<Provider store={store}><Router><ReplacementVoid {...compProps} /></Router></Provider>)
  })

  //expect used for assert the component and match the output with testing condition

  describe('Dentail Claim Replacement/Void Component test cases', function () {

    it('should render Replacement/Void Component  without error', () => {
      const component = wrapper.find("[data-test='replacement-void-component']")
      expect(component.length).toBe(1);
    })

    it('should render Replacement/Void Table without error', () => {
      const component = wrapper.find("[data-test='replacement-void-table']").at(0)
      expect(component.length).toBe(1);
    })
  })

  describe('Procedure Code/Provider Type Search API test cases', function () {

    const reqBody = {
      claimType: "D",
      memberSystemID: 4011171,
      tcn: "16231100010000020",
    }

    const resObject = {
      claimAdjustment: [{
        addedAuditTimeStamp: "2016-08-18T05:53:20.963+0000",
        addedAuditUserID: "SMOKEP1",
        adjustmentOriginalTCN: null,
        adjustmentReasonCode: null,
        adjustmentReasonCodeDesc: null,
        adjustmentStatusCode: null,
        auditTimeStamp: "2016-08-18T05:53:20.963+0000",
        auditUserID: "SMOKEP1",
        externalTCN: null,
        fcn: null,
        replacedTCN: null,
        replacementTCN: null,
        sequenceNumber: 0,
        versionNo: 0        
      }]
    }

    const reqResponse = {
      data: resObject
    }

    beforeEach(function () {
      // import and pass your custom axios instance to this method
      moxios.install()
    })

    afterEach(function () {
      // import and pass your custom axios instance to this method
      moxios.uninstall()
    })

    it('should be success the api call', () => {
      moxios.wait(() => {
        let request = moxios.requests.mostRecent()
        request.respondWith(mockSuccess(reqResponse));
      })

      const dispatchClaimsCorrectionTCNSearch = {
        type: actionTypes.CLAIMS_CORRECTION_SEARCH_TYPE,
        claimsCorrectionSearchData: resObject
      }
      return store.dispatch(claimCorrectionTCNSearchAction(reqBody))
        .then(() => {
          const actions = store.getActions()
           expect(actions[0].claimsCorrectionSearchData.data.claimAdjustment)
           .toEqual(dispatchClaimsCorrectionTCNSearch.claimsCorrectionSearchData.claimAdjustment);
        })

    })

    it('should be fail the api call', () => {
      const errResponse = {
        error: "no data found"
      }
      moxios.wait(() => {
        let request = moxios.requests.mostRecent()
        request.respondWith(mockError(errResponse))
      })
      return store.dispatch(claimCorrectionTCNSearchAction(reqBody))
        .then(() => {
          const actions = store.getActions()
          expect(actions[0].claimsCorrectionSearchData.data).toEqual(errResponse);
        })
    })
  })
})