import React from "react";
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import thunk from 'redux-thunk';
import checkPropTypes from "check-prop-types";
import History from "../components/DentalClaim/History";

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

let store, wrapper
// intitial state for component
const initialState = {}
// intitial props for component
const componentProps = {
    data: {
        previousLocations: [],
        relatedHistory: []
    }
}
//beforeEach Run before testcases is run  

beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><History  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
})

describe('Rendering  History Component', () => {
    it('should render the history panel without error', () => {
        const component = wrapper.find("[data-test='test_history']");
        expect(component.length).toBe(1)
    })

})
describe('Rendering Related History  in History Component', () => {
    it('should render the related history heading without error', () => {
        const component = wrapper.find("[data-test='test_rltd_history']");
        expect(component.length).toBe(1)
    })
    it('should render the related history table without error', () => {
        const component = wrapper.find("[data-test='test_rltd_history_table']");
        expect(component.length).toBe(1)
    })


})

describe('Rendering Location History in History Component', () => {

    it('should render the location history heading without error', () => {
        const component = wrapper.find("[data-test='test_locn_history']");
        expect(component.length).toBe(1)
    })
    it('should render the location history table without error', () => {
        const component = wrapper.find("[data-test='test_locn_history_table']");
        expect(component.length).toBe(1)
    })
})

describe('check prop types for History', () => {
    it('should check prop types without error', () => {
        const expectedProps = {
            data: {
                previousLocations: [],
                relatedHistory: []
            }
        }
        const propErr = checkPropTypes(History.propTypes, expectedProps, 'props', History.name)
        expect(propErr).toBeUndefined()
    })

})


