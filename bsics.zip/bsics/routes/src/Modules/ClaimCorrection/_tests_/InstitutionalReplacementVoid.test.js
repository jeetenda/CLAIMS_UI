import React from "react";
import { shallow, mount } from "enzyme";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import thunk from "redux-thunk";
import "babel-polyfill";
import * as redux from "react-redux";
import ReplacementVoid,{getTableData} from "../components/InstitutionalClaim/ReplacementVoid";

const middlewares = [thunk];
describe('dispatch mock', function () {
    it('should mock dispatch', function () {
        const useDispatchSpy = jest.spyOn(redux, 'useDispatch');
        const mockDispatchFn = jest.fn()
        useDispatchSpy.mockReturnValue(mockDispatchFn);
        useDispatchSpy.mockClear();
    })
  });
  describe('selector mock', function () {
    it('should mock useSelector', function () {
        const useSelectorSpy = jest.spyOn(redux, 'useSelector');
        const mockSelectorFn = jest.fn()
        useSelectorSpy.mockReturnValue(mockSelectorFn);
        useSelectorSpy.mockClear();
    })
  });
describe("Institutional Claim correction > Replacement/Void Component:", () => {
    const mockStore = configureStore(middlewares);
    let store, wrapper,wrapper1,useEffect;
  
    // intitial state for component
    const initialState = {
      handleVoidCheck: jest.fn(),
      editRow1: jest.fn(),
      editRowTcn:jest.fn(),
    };
    const componentProps1 = {
      
        handleChanges:jest.fn(),
        setTabValue:jest.fn(),
        setAdTabId:jest.fn(),
        tableData1:{
            pharmacyFlag:true,
            replacementVoidList:[],
        },
        
        tableData:{
            pharmacyFlag:true,
            replacementVoidList:[{"auditUserID": null,
            "auditTimeStamp": null,
            "addedAuditUserID": null,
            "addedAuditTimeStamp": null,
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "seqNum": 1,
            "exceptionLocationCode": "004",
            "exceptionLocationId": null,
            "suspenseLocationExceptionCode": "1060",
            "exceptionLocationDate": "2017-02-19T18:30:00.000+0000",
            "exceptionLocationUserId": null
        }]

        }
    }
    
    beforeEach(() => {

        store = mockStore(initialState);
        wrapper = shallow(
          <Provider store={store}>
            <Router>
              <ReplacementVoid  {...componentProps1}/>
            </Router>
          </Provider>
        )
          .dive()
          .dive()        
          .dive()
          .dive()
          .dive()
          .dive()
          
          
          //console.log(wrapper.debug());        
      });

      describe("Rendering Replacement/Void Tables:", () => {
        //console.log(wrapper);    
        it('should Render The Head Content Without Error', () => {
          const component = wrapper.find("[data-test='headcontent']")
          expect(component.length).toBe(1);
          
      }) 
      
        //console.log(wrapper);    
      it('should Render the Replacement/Void table without error', () => {
          const component = wrapper.find("[data-test='Replacement-Void']")
          expect(component.length).toBe(1);
          
      })

      it('should render Replacement/Void Table Function without error', () => {
        let result = getTableData([{},{}]);
        expect(result.length).toBe(2);
      });

      it('should render Replacement/Void click function Component  without error', async () => {
        const handelClickMock = await jest.fn();
        const event = {}
        const compProps = {
          data: {
            claimAdjustment: [{"auditUserID": null,
            "auditTimeStamp": null,
            "addedAuditUserID": null,
            "addedAuditTimeStamp": null,
            "versionNo": 0,
            "dbRecord": false,
            "sortColumn": null,
            "seqNum": 1,
            "exceptionLocationCode": "004",
            "exceptionLocationId": null,
            "suspenseLocationExceptionCode": "1060",
            "exceptionLocationDate": "2017-02-19T18:30:00.000+0000",
            "exceptionLocationUserId": null
        }]
          },
          setClaimEntryData: jest.fn(),
        }
        const wrapper = mount(<ReplacementVoid {...compProps} onTableRowClick={handelClickMock}/>)
        const component = wrapper.find("#table_redirect_cell_click");
        expect(handelClickMock).toBeTruthy();
    });

    });
    

});