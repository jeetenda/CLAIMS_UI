import React from "react"
import { mount } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import "babel-polyfill"
import Claim from "../components/Main/Claim";
import Member from "../components/Main/Member";
import PaymentProvider from "../components/Main/Payment&Provider";

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 27-Sep-2020
   * @author jitendra 
*/

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })


/***For Claim  Component****** */
describe('Claim  Component Test', () => {

  const mockStore = configureStore(middlewares)
  let store, wrapper

  // intitial state for component
  const initialState = {}

  const compProps = {
    data:{batchInfo :"",
      statusCodeDesc : "" ,
      additionalClaimData : "" ,
      claimAdjustment :[] ,
      subRepVoidTCN : "" ,
      auditTimeStamp : "" ,
      pricingMethodCodeDesc : "" ,
      pricingMethodCode : "" ,
      tcn :"" ,
      lobCode : "" ,
      exceptionLocationCode :"" ,
      externalTCN :"" ,
      userId : "",
      claimTypeDesc :"",
      documentTypeCodeDesc :"",
      enterpriseClaimAux :"",
      implGuideVersionName :"",
      adjudicationDate :"",
    },
      setClaimEntryData:()=>{},
      claimMainErr:""
   
  }

  //beforeEach Run before testcases is run  

  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = mount(<Provider store={store}><Router><Claim {...compProps} /></Router></Provider>)
  })

  //expect used for assert the component and match the output with testing condition

  describe('Dentail Claim  Component test cases', function () {

    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='DOC#']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='Status']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='PayType']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='ReplaceVoidTCN']")
      expect(component.length).toBe(1);
    })
    
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='override_loc']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='user_name']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='AdjudDateTime']")
      expect(component.length).toBe(1);
    })
        it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='pricingMethodCode']")
      expect(component.length).toBe(1);
    })
        it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='transactionTypeCodeDesc']")
      expect(component.length).toBe(1);
    })
        it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='Location']")
      expect(component.length).toBe(1);
    })
        it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='adjustmentReasonCodeDesc']")
      expect(component.length).toBe(1);
    })
        it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='externalTCN#']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='userId']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='claimTypeCode']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='documentTypeCodeDesc']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='InsuranceGroup']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='PolicyNumber']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='ReplacementTCN']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='implGuideVersionName']")
      expect(component.length).toBe(1);
    })
    it('should render Claim Component  without error', () => {
      const component = wrapper.find("[data-test='adjudicationDate']")
      expect(component.length).toBe(1);
    })

  
  })
})
/********* */


