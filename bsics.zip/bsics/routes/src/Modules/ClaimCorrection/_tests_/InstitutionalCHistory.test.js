import React from "react";
import { shallow, mount } from "enzyme";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import thunk from "redux-thunk";
import "babel-polyfill";
import * as redux from "react-redux";
import AdjustmentHistory,{getTableData,getTableDataLocation} from "../components/InstitutionalClaim/History";

const middlewares = [thunk];
describe('dispatch mock', function () {
    it('should mock dispatch', function () {
        const useDispatchSpy = jest.spyOn(redux, 'useDispatch');
        const mockDispatchFn = jest.fn()
        useDispatchSpy.mockReturnValue(mockDispatchFn);
        useDispatchSpy.mockClear();
    })
  });
  describe('selector mock', function () {
    it('should mock useSelector', function () {
        const useSelectorSpy = jest.spyOn(redux, 'useSelector');
        const mockSelectorFn = jest.fn()
        useSelectorSpy.mockReturnValue(mockSelectorFn);
        useSelectorSpy.mockClear();
    })
  });
describe("Professional Claim Entry > History Component:", () => {
    const mockStore = configureStore(middlewares);
    let store, wrapper;
  
    // intitial state for component
    const initialState = {
      handleVoidCheck: jest.fn(),
      editRow1: jest.fn(),
      editRowTcn:jest.fn(),
    };
    const componentProps1 = {
        data: {},
        setClaimEntryData: jest.fn(),
    }
    
    beforeEach(() => {
        
        
        store = mockStore(initialState);
        wrapper = shallow(
          <Provider store={store}>
            <Router>
              <AdjustmentHistory  {...componentProps1}/>
            </Router>
          </Provider>
        )
      });

      describe("Rendering History Tables:", () => {
        const setupDefault = (props = {}) => {
            return mount(<Provider store={store}><Router><AdjustmentHistory  {...props} /></Router></Provider>)
        }
        it('should Render The Head Content Without Error', () => {
          const component = wrapper.find("[data-test='history-pro-correction']")
          expect(component.length).toBe(0);
        });
        it('should render History Related Table Function without error', () => {
            let result = getTableData([{},{}]);
            expect(result.length).toBe(2);
        });
        it('should render History Location Table Function without error', () => {
            let result = getTableDataLocation([{},{}]);
            expect(result.length).toBe(2);
        });

        it('should render History location click function Component  without error', async () => {
            const handelClickMock = await jest.fn();
            const event = {}
            const defaultProps = {
              data: {
                previousLocations: [{
                    "auditUserID": null,
                    "auditTimeStamp": null,
                    "addedAuditUserID": null,
                    "addedAuditTimeStamp": null,
                    "versionNo": 0,
                    "exceptionLocationCode": "004",
                    "suspenseLocationExceptionCode": "1060",
                    "exceptionLocationID": null,
                    "exceptionLocationDate": "2014-04-17T00:00:00.000+0000",
                    "exceptionLocationUserID": null,
                    "sequenceNumber": null
                  }]
              },
              setClaimEntryData: jest.fn(),
            }
            wrapper = setupDefault(defaultProps);
            const component = wrapper.find("#table_ah_cell_click");
            component.at(0).simulate("click", event);
            expect(handelClickMock).toBeTruthy();
        });

        it('should render History related click function Component  without error', async () => {
            const handelClickMock = await jest.fn();
            const event = {}
            const defaultProps = {
              data: {
                relatedHistory: [{
                    "auditUserID": null,
                    "auditTimeStamp": null,
                    "addedAuditUserID": null,
                    "addedAuditTimeStamp": null,
                    "versionNo": 0,
                    "exceptionLocationCode": "004",
                    "suspenseLocationExceptionCode": "1060",
                    "exceptionLocationID": null,
                    "exceptionLocationDate": "2014-04-17T00:00:00.000+0000",
                    "exceptionLocationUserID": null,
                    "sequenceNumber": null
                  }]
              },
              setClaimEntryData: jest.fn(),
            }
            wrapper = setupDefault(defaultProps);
            const component = wrapper.find("#table_ah_cell_click");
            component.at(0).simulate("click", event);
            expect(handelClickMock).toBeTruthy();
        });
    });
    
});