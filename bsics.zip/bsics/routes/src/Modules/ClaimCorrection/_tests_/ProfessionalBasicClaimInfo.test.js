import React from "react";
import { shallow } from "enzyme";
import configureStore from "redux-mock-store";
import { Provider } from "react-redux";
import { BrowserRouter as Router } from "react-router-dom";
import "babel-polyfill";
import thunk from "redux-thunk";
import InstitutionalClaimBasicInfo from "../components/ProfessionalClaim/BasicClaimInfo";
import TableComponent from '../../../SharedModules/Table/Table';

/**
   * describe() is used to handle rendering Basic Claim Info Component.
   * get element selector from component using expect method of jest
   * @Date 15-Oct-2020
   * @author Sandeep Prasad
*/
const middlewares = [thunk];
describe("Check Professional Basic Claim info conmponent render without any error", () => {
    const mockStore = configureStore(middlewares);
    const initialState = {}
    let store, wrapper, wrapper1;
    const componentProps={
        data:{
            enterpriseClaimAux:{
                c837ClaimHdr : {
                    billingProviderContactInfo :{
                        "entityCode": null,
                        "entityQualifierCode": null,
                        "submitterQualifierCode": null,
                        "submitterID": null,
                        "contactCode1": null,
                        "contactCode2": null,
                        "contactCode3": null,
                        "contactName1": "name1",
                        "contactName2": "name2",
                        "contactName3": null,
                        "communicationQualifierCode1A": "TE",
                        "communicationQualifierCode2A": null,
                        "communicationQualifierCode3A": null,
                        "communicationNumber1A": "8522564973",
                        "communicationNumber2A": "test",
                        "communicationNumber3A": null,
                        "communicationQualifierCode1B": null,
                        "communicationQualifierCode2B": null,
                        "communicationQualifierCode3B": null,
                        "communicationNumber1B": "test",
                        "communicationNumber2B": "test",
                        "communicationNumber3B": null,
                        "communicationQualifierCode1C": null,
                        "communicationQualifierCode2C": null,
                        "communicationQualifierCode3C": null,
                        "communicationNumber1C": "test",
                        "communicationNumber2C": "test",
                        "communicationNumber3C": null,
                        "submitterName": null
                    },
                    submitterInfo : {},
                    c837ClaimProvider : {
                        billingProvider : {
                            "entityCode": null,
                            "entityTypeCode": "2",
                            "addressLine1": "164 HIGH STREET",
                            "addressLine2": null,
                            "cityName": "GREENFIELD",
                            "stateCode": "MA",
                            "zipCode": "013012613",
                            "countryCode": null,
                            "countrySubDivisionCode": null,
                            "providerName": {
                              "lastName": "BAYSTATE FRANKLIN MED",
                              "firstName": "Testname",
                              "middleName": null,
                              "suffixName": "M",
                            }
                          },
                        renderingProvider : {
                            "entityCode": null,
                            "entityTypeCode": "2",
                            "addressLine1": "164 HIGH STREET",
                            "addressLine2": null,
                            "cityName": "GREENFIELD",
                            "stateCode": "MA",
                            "zipCode": "013012613",
                            "countryCode": null,
                            "countrySubDivisionCode": null,
                            "providerName": {
                              "lastName": "BAYSTATE FRANKLIN MED",
                              "firstName": "Testname",
                              "middleName": null,
                              "suffixName": "M",
                            }
                        },
                        referringProvider1: {
                            "entityCode": null,
                            "entityTypeCode": "2",
                            "addressLine1": "test",
                            "addressLine2": "test",
                            "cityName": "test",
                            "stateCode": "test",
                            "zipCode": "12345678",
                            "countryCode": "NH",
                            "countrySubDivisionCode": "2",
                            "providerName": {
                              "lastName": "Last1",
                              "firstName": "test",
                              "middleName": "test",
                              "suffixName": "test",
                            }
                        },
                    },
                    "c837Payer": {
                        "categoryCode1": null,
                        "certificationIndicator1": false,
                        "conditionCode1A": null,
                        "conditionCode1B": null,
                        "conditionCode1C": null,
                        "conditionCode1D": null,
                        "conditionCode1E": null,
                        "categoryCode2": null,
                        "certificationIndicator2": false,
                        "conditionCode2A": null,
                        "conditionCode2B": null,
                        "conditionCode2C": null,
                        "conditionCode2D": null,
                        "conditionCode2E": null,
                        "categoryCode3": null,
                        "certificationIndicator3": false,
                        "conditionCode3A": null,
                        "conditionCode3B": null,
                        "conditionCode3C": null,
                        "conditionCode3D": null,
                        "conditionCode3E": null,
                        "subscriber": {
                          "payerSequenceCode": "P",
                          "relationshipCode": null,
                          "policyNumber": null,
                          "planName": "0000000000",
                          "insuranceTypeCode": null,
                          "claimFilingCode": null,
                          "dateOfBirthQualifierCode": null,
                          "dateOfBirth": "1985-02-23T00:00:00.000+0000",
                          "genderCode": "F",
                          "patientSignatureSourceCode": null,
                          "informationReleaseCode": null,
                          "entityCode": null,
                          "entityQualifierCode": null,
                          "subscriberQualifierCode": null,
                          "subscriberID": "92617922378",
                          "addressLine1": "319 MANNING HILL",
                          "addressLine2": null,
                          "cityName": "WINCHESTER",
                          "stateCode": "NH",
                          "zipCode": "03470",
                          "countryCode": null,
                          "additionalQualifierCode1": null,
                          "additionalID1": "001079536",
                          "additionalQualifierCode2": null,
                          "additionalID2": null,
                          "additionalQualifierCode3": null,
                          "additionalID3": null,
                          "hierarchicalID": null,
                          "hierarchicalParentID": null,
                          "hierarchicalLevelCode": null,
                          "hierarchicalChildCode": null,
                          "responsibilitySequenceCode": null,
                          "cobIndicator": null,
                          "patientDateOfDeathQualifierCode": null,
                          "patientDateOfDeath": null,
                          "patientweightCode": null,
                          "patientWeight": 0,
                          "pregnancyIndicator": false,
                          "propertyClaimQualifierCode": null,
                          "additionalQualifierCode4": null,
                          "additionalID4": null,
                          "propertyClaimNumber": "7777906871",
                          "subscriberName": null,
                          "subscriberCreditOrDebitCard": null,
                          "propertyCasualityContact": {
                            "contactCode": null,
                            "contactName": "KEN",
                            "communicationAQualifierCode": null,
                            "communicationANumber": "PA1212344",
                            "communicationBQualifierCode": null,
                            "communicationBNumber": null
                          },
                          "benefitCertificationCode": null,
                          "countrySubDivisionCode": null
                        },
                        "payer": null,
                        "responsibleParty": null,
                        "patient": {
                          "hierarchicalCode": null,
                          "hierarchicalID": null,
                          "hierarchicalLevelCode": null,
                          "hierarchicalChildCode": null,
                          "relationshipCode": null,
                          "studentStatusCode": null,
                          "patientDateOfDeathQualifierCode": null,
                          "patientDateOfDeath": null,
                          "patientweightCode": null,
                          "patientWeight": 59,
                          "pregnancyIndicator": false,
                          "entityCode": null,
                          "entityQualifierCode": null,
                          "memberQualifierCode": "P1",
                          "memberID": null,
                          "addressLine1": "319 MANNING HILL",
                          "addressLine2": null,
                          "cityName": "WINCHESTER",
                          "stateCode": "NH",
                          "zipCode": "03470",
                          "countryCode": null,
                          "dateOfBirth": "1985-02-23T00:00:00.000+0000",
                          "dateOfBirthQualifierCode": null,
                          "genderCode": "F",
                          "additionQualifierCode1": "PPP",
                          "additionalID1": null,
                          "additionQualifierCode2": null,
                          "additionalID2": "P1",
                          "additionQualifierCode3": null,
                          "additionalID3": null,
                          "additionQualifierCode4": null,
                          "additionalID4": null,
                          "additionQualifierCode5": null,
                          "additionalID5": null,
                          "propertyQualifierCode": null,
                          "propertyClaimNumber": null,
                          "patientName": null,
                          "countrySubDivisionCode": null,
                          "propertyCasualityContact": null
                        },
                        "payToPlan": null
                      }, 
                    "c837SpecializedService": {
                        "auditUserID": null,
                        "auditTimeStamp": null,
                        "addedAuditUserID": null,
                        "addedAuditTimeStamp": null,
                        "versionNo": 0,
                        "spinalConditionCode": "C",
                        "spinalConditionDescription1": "cnd1",
                        "spinalConditionDescription2": "cnd2",
                        "spinalXRayAvailabilityIndicator": false,
                        "homeboundCode": null,
                        "homeboundIndicator": false,
                        "homeboundConditionCode": null,
                        "espdtCode": null,
                        "epsdtIndicator": false,
                        "espdtConditionCode1": null,
                        "espdtConditionCode2": "CN2",
                        "espdtConditionCode3": null,
                        "repricedClaimInfo": {
                          "methodologyCode": "02",
                          "methodologyCodeDesc": null,
                          "repriceAllowedAmount": null,
                          "savingsAmount": null,
                          "organizationID": null,
                          "repricePerDiemRate": null,
                          "repriceAPGCode": null,
                          "repriceAPGAmount": null,
                          "repriceRejectReasonCode": null,
                          "repriceComplianceCode": null,
                          "repriceExceptionCode": "03",
                          "drgCode": null,
                          "drgAmount": null,
                          "revenueCode": null,
                          "serviceQualifierCode": null,
                          "serviceCode": null,
                          "unitCode": null,
                          "unitQuantity": null,
                          "rejectReasonCode": null,
                          "policyComplianceCode": null,
                          "exceptionCode": null,
                          "ambulatoryPatientGroupCode": null,
                          "ambulatoryPatientGroupAmount": null
                        },
                        "noteCode": null,
                        "noteText": null,
                        "c837ProfessionalLineItems": [
                          {
                            "auditUserID": null,
                            "auditTimeStamp": null,
                            "addedAuditUserID": null,
                            "addedAuditTimeStamp": null,
                            "versionNo": 0,
                            "lineNumber": 2,
                            "emergencyIndicator": false,
                            "coPayStatusCode": "D",
                            "hospiceEmployeeCode": null,
                            "hospiceEmployeeIndicator": false,
                            "hospiceConditionCode": null,
                            "serviceQualifierCode": "HC",
                            "submittedUnitsCode": "UN",
                            "certificationRevisionQualifierCode": null,
                            "certificationRevisionPeriodQualifierCode": null,
                            "certificationRevisionDate": null,
                            "lastCertificationQualifierCode": null,
                            "lastCertificationPeriodQualifierCode": null,
                            "lastCertificationDate": null,
                            "therapyQualifierCode": null,
                            "therapyPeriodQualifierCode": null,
                            "therapyBeginDate": null,
                            "lastSeenQualifierCode": null,
                            "lastSeenPeriodQualifierCode": null,
                            "lastSeenDate": "2013-04-10T00:00:00.000+0000",
                            "shippedQualifierCode": null,
                            "shippedPeriodQualifierCode": null,
                            "shippedDate": null,
                            "illnessQualifierCode": null,
                            "illnessPeriodQualifierCode": null,
                            "illnessDate": null,
                            "lastXRayQualifierCode": null,
                            "lastXRayPeriodQualifierCode": null,
                            "lastXRayDate": null,
                            "acuteQualifierCode": null,
                            "acutePeriodQualifierCode": null,
                            "acuteDate": null,
                            "initialTreatmentQualifierCode": null,
                            "initialTreatmentPeriodQualifierCode": null,
                            "initialTreatmentDate": null,
                            "similarIllnessQualifierCode": null,
                            "similarIllnessPeriodQualifierCode": null,
                            "similarIllnessDate": null,
                            "servicePeriodQualifierCode": null,
                            "serviceDateQualifierCode": "472",
                            "priorAuthReferral": {
                              "referralQualifierCode2": null,
                              "referralID2": "RefId1",
                              "otherPayerInfo": null
                            },
                          }
                        ],
                      },  
                }
            },
        submitterID:"NH100847",
        claimProviderID:[{"providerIDType":'EI', "providerID":"205821812"}],
        subscriberInformation:{
            responsibilitySequenceCode:'S',
            planName:'GRANITE STATE HEALTH PLAN',
            policyOrGroupNumber:'',
            claimFilingCode:'MC'
        },
        otherclaimNotes:{note:""},
        
        claimServiceLineItemsList:[],
        addClaimData:{
            delayReasonCode:'',
            specialProgramCode:'',
            mediCareAssignCode:'',
            releaseInfoCode:'',
            patientSigSourceCode:'',
            benefitsAssignCert:'Yes',
        },
        }
    }
    const componentProps1={
        data:{
            enterpriseClaimAux:{},
        submitterID:"",
        claimProviderID:[],
        subscriberInformation:{
            responsibilitySequenceCode:'',
            planName:'',
            policyOrGroupNumber:'',
            claimFilingCode:''
        },
        otherclaimNotes:{note:""},
        
        claimServiceLineItemsList:[],
        addClaimData:{
            delayReasonCode:'',
            specialProgramCode:'',
            mediCareAssignCode:'',
            releaseInfoCode:'',
            patientSigSourceCode:'',
            benefitsAssignCert:'',
        },
        }
    }
    
    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><InstitutionalClaimBasicInfo  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive();
        wrapper1 = shallow(<Provider store={store}><Router><InstitutionalClaimBasicInfo  {...componentProps1} /></Router></Provider>).dive().dive().dive().dive().dive().dive();

        // console.log(wrapper.debug())
      }); 
      describe('Check render for Basic claim info component' , ()=>{
        it('should check exception for submitter Information component without error', () => {
          const component = wrapper.find("[data-test='prof-basicInfo-stdDesc']")
          expect(component.exists()).toBe(true);
        });
        it('should check exception for function call on total table component without error', () => {
          const editRow = jest.fn();
          const tableComp = wrapper.find(TableComponent)
          tableComp.at(0).prop('onTableRowClick')(editRow);
          expect(tableComp.length).toBe(6);
        });

        describe('Check render for Provider Information component' , ()=>{
            describe('Check render for Bill Provider Information component' , ()=>{
              it('should check exception for Billing Provider component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for EntityQual component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-entityQual']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Last Name component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-lastName']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Firstname component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-firstName']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for MI component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-mi']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Suffix component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-suffix']")
                  expect(component.exists()).toBe(true);
                });
               it('should check exception for Address1 component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-address1']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Address2 component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-address2']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for City component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-city']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for State component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-state']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Zip component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-zip']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Extension component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-extension']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Country component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-country']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for SubDivision Code component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-subDivCode']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Currency Code component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-currCode']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Secondary ID table component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-secIdtable']")
                  expect(component.exists()).toBe(true);
                });
                it('should check exception for Contact Information Table component without error', () => {
                  const component = wrapper.find("[data-test='prof-basicInfo-billProvider-contactInfoTable']")
                  expect(component.exists()).toBe(true);
                });
             
          });
        
          describe('Check render for Rendering Provider Information component' , ()=>{
            it('should check exception for Rendering Provider component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-renderingProvider']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for Last Name component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-renderingProvider-lastName']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for First Name component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-renderingProvider-firstName']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for MI component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-renderingProvider-mi']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for Suffix component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-renderingProvider-suffix']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for Secondary ID table component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-renderingProvider-secIdtable']")
              expect(component.exists()).toBe(true);
            });
          })

          describe('Check render for Refering Provider Information component' , ()=>{
            it('should check exception for Refering Provider component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-referingProvider']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for Last Name component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-referingProvider-lastName']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for First Name component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-referingProvider-firstName']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for MI component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-referingProvider-mi']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for Suffix component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-referingProvider-suffix']")
              expect(component.exists()).toBe(true);
            });
            it('should check exception for Secondary ID table component without error', () => {
              const component = wrapper.find("[data-test='prof-basicInfo-referingProvider-secIdtable']")
              expect(component.exists()).toBe(true);
            });
            
          })
    });
});
});