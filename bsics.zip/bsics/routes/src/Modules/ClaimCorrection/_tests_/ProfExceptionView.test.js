import React, { useState } from "react";
import { shallow,mount } from 'enzyme';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import thunk from 'redux-thunk';
import checkPropTypes from "check-prop-types";
import ExceptionView from '../components/ProfessionalClaim/ExceptionView';
import {getClaimCorrectionDetails} from '../actions';
import * as actionTypes from '../actionTypes';
import * as redux from "react-redux";
import moxios from 'moxios';
import "babel-polyfill";
/**
    * describe() is used to handle rendering Exception Search Component.
    * get element selector from componen using expect method of jest
    * @Date 16-Sep-2020
    * @author Vaishali Gaikwad
 */
const middlewares = [thunk];
const mockStore = configureStore(middlewares);
//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })

const reactMock = require("react");
// const setHookState = (newState) =>
//   jest.fn().mockImplementation(() => [newState, () => newState]);
 
  const setHookState = (newState) => jest.fn().mockImplementation((state) => [
    newState,
    (newState) => {}
    ])

/********Remove error related to useDispatch & useSelector *******/
describe('dispatch mock', function () {
    reactMock.useState = setHookState({
        exceptionList: [{"lineNumber": "0", "exceptionCode": "3801", "statusCode": "1"}],
        //exceptionList: [],
        showDetails: true,
    });
    it('should mock dispatch', function () {
        const useDispatchSpy = jest.spyOn(redux, 'useDispatch');
        const mockDispatchFn = jest.fn()
        useDispatchSpy.mockReturnValue(mockDispatchFn);
        useDispatchSpy.mockClear();
    })
});
describe('selector mock', function () {
    it('should mock useSelector', function () {
        const useSelectorSpy = jest.spyOn(redux, 'useSelector');
        const mockSelectorFn = jest.fn()
        useSelectorSpy.mockReturnValue(mockSelectorFn);
        useSelectorSpy.mockClear();
    })
});
describe('useEffect mock', function () {
    it('should mock useEffect', function () {
        const useEffectSpy = jest.spyOn(React, 'useEffect');
        const mockUseEffectFn = jest.fn()
        useEffectSpy.mockReturnValue(mockUseEffectFn);
        useEffectSpy.mockClear();
    })
});

let store, wrapper, useEffect
// intitial state for component
const initialState = {}
// intitial props for component
const componentProps = {
    updateException: "test", 
    value:{},
    setClaimEntryData:{},
    correctClaim:jest.fn(),
    handleChanges:jest.fn(),
    showDetailsJest: true,
    exceptionListJest: [{"lineNumber":"1","exceptionCode":"3765","shortDescription":"test","clerkId":"1","forceDenyCode":"1","userName":"test"}]
}

//beforeEach Run before testcases is run  

beforeEach(() => {
    
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><ExceptionView  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
    useEffect = jest.spyOn(React, "useEffect").mockImplementation(f => f());

})
afterEach(() => {
    jest.clearAllMocks();
  });

describe('Rendering  Exception View Component', () => {
    
    it('should render the Exception View panel without error', () => {
        const component = wrapper.find("[data-test='test_exceptionView']");
        expect(component.length).toBe(1)
    })
})

describe('Rendering Related Exceptions  in Exception view Component', () => {
    it('should render TCN without error', () => {
        const component = wrapper.find("[data-test='test_TCN']");
        expect(component.length).toBe(1)
    })
    it('should render exceptions without error', () => {
        const component = wrapper.find("[data-test='test_exceptions']");
        expect(component.length).toBe(1)
    })
    it('should render exception table without error', () => {
        const component = wrapper.find("[data-test='test_exceptionList']");
        expect(component.length).toBe(1)
    })
    it('should render validate button without error', () => {
        const component = wrapper.find("[data-test='test-validate-button']");
        expect(component.length).toBe(1)
    })
    it('should render Exception List without error', () => {
        const mockFn = jest.fn();
         //console.log(wrapper.find('.txtbox-stat'))
         const component = wrapper.find(".txtbox-stat").first();
        //  component.simulate('change', { target: { value: 'Changed' } });
        //  expect(component.length).toBe(1)
    })
    
  
});

describe('check prop types for Exception View', () => {
    it('should check prop types without error', () => {
        const expectedProps = {
            value:{},
            setClaimEntryData:{},
            correctClaim:jest.fn(),
        }
        const propErr = checkPropTypes(ExceptionView.propTypes, expectedProps, 'props', ExceptionView.name)
        expect(propErr).toBeUndefined()
    })

})



describe('Exception View API Test Case ', function () {
    const store = mockStore({});
    beforeEach(function () {
        moxios.install()
    })

    afterEach(function () {
        moxios.uninstall()
    })

    
    it('should be success the get detail api call', () => {
        const reqResponse = {
            status: "success"
        }
        let reqBody = {
            "claimType":"D",
            "memberID":"71235080686",
            "tcn":"13064812030000430",
            "memberSystemID":"4348226"
        }
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockSuccess(reqResponse))
        })
        const dispatchGetClaimCorrectionData = {
            type: actionTypes.GET_ALL_CLAIMS_CORRECTION_DATA,
            getAllClaimsCorrectionData: reqResponse
        };
        return store.dispatch(getClaimCorrectionDetails(reqBody))
            .then(() => {
                const actions = store.getActions();
                expect(actions[0]).toEqual(dispatchGetClaimCorrectionData);
            })
    })

    it('should be fail the detail api call', () => {
        const errResponse = {
            status: "fail"
        }
        let reqBody = {
            "claimType":"D",
            "memberID":"71235080686",
            "tcn":"13064812030000430",
            "memberSystemID":"4348226"
        }
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockSuccess(errResponse))
        })
        const dispatchGetClaimCorrectionData = {
            type: actionTypes.GET_ALL_CLAIMS_CORRECTION_DATA,
            getAllClaimsCorrectionData: errResponse
        };
        return store.dispatch(getClaimCorrectionDetails(reqBody))
            .then(() => {
                const actions = store.getActions();
                expect(actions[1]).toEqual(dispatchGetClaimCorrectionData);
            })
    });

});