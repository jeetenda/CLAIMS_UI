import * as actionTypes from './actionTypes';

const axiosPayLoad = {
    payload: null,
    tcnSearchPayload: null,
    locationSearchPayload: null,
    advanceSearchPayload: null,
    correctionDetailsPayload: null,
    memberLockingPayload: null,
    lockReleasingPayload: null,
  };

  const reducer = (state = axiosPayLoad, action) => {
    switch (action.type) {
  
      case actionTypes.RESETDATA:
        return axiosPayLoad;
  
      case actionTypes.CLAIMS_CORRECTION_SEARCH_TYPE:
        return { ...state, tcnSearchPayload: action.claimsCorrectionSearchData }

      case actionTypes.GET_ALL_CLAIMS_CORRECTION_DATA:
        return { ...state, correctionDetailsPayload: action.getAllClaimsCorrectionData }

      case actionTypes.CLAIMS_CORRECTION_MEMBER_LOCKING_DATA:
        return { ...state, memberLockingPayload: action.claimsCorrectionMemberLocking }
        
      case actionTypes.CLAIMS_CORRECTION_RELEASE_LOCKING_DATA:
        return { ...state, lockReleasingPayload: action.claimsCorrectionReleaseLocking }

      case actionTypes.CLAIMS_CORRECTION_LOCATION_SEARCH:
        return { ...state, locationSearchPayload: action.claimsCorrectionLocationSearchData }

      case actionTypes.CLAIMS_CORRECTION_ADVANCE_SEARCH:
        return { ...state, advanceSearchPayload: action.claimsCorrectionAdvanceSearchData }

        case actionTypes.GET_LOCATION_DROPDOWN:
        return { ...state, locationPayload: action.locationData, searchData: action.searchData }
       
      default: return state;
    }
  };
  
  export default reducer;