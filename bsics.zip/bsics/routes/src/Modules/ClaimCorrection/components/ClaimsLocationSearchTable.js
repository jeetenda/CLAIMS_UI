import React, {useState, useEffect } from 'react';
import { withRouter } from 'react-router';
import TableComponent from '../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import moment from 'moment';
import { claimCorrectionTCNSearchAction } from '../actions';

const headCells = [
    
    {
        id: 'tcn', numeric: false, disablePadding: false, label: 'TCN', enableHyperLink: true, width: 160, fontSize: 12
    },
    {
        id: 'claimTypeCode', numeric: false, disablePadding: false, label: 'Claim Type', enableHyperLink: false, width: 120, fontSize: 12
    },
    {
        id: 'exceptionLocationCode', numeric: false, disablePadding: false, label: 'Location Code', enableHyperLink: false, width: 130, fontSize: 12
    },
    {
        id: 'mediaSourceCode', numeric: false, disablePadding: false, label: 'Media Source', enableHyperLink: false, width: 130, fontSize: 12
    },
    {
        id: 'billingProviderID', numeric: false, disablePadding: false, label: 'Billing Prov ID', enableHyperLink: false, width: 120, fontSize: 12
    },
    {
        id: 'memberAltID', numeric: false, disablePadding: false, label: 'Member ID', enableHyperLink: false, width: 120, fontSize: 12
    },
    {
        id: 'exceptionLocationDate', numeric: false, disablePadding: false, label: 'Location Date', enableHyperLink: false, width: 120, fontSize: 12
    },

    
];
function ClaimLocationSearchTable(props) {
    const dispatch = useDispatch();
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const onSearch = searchvalues => { return dispatch(claimCorrectionTCNSearchAction(searchvalues)) };
    const editRow = row => (event) => {
        setspinnerLoader(true);
        props.setRedirect(true);
        let obj = {
            "searchByTCN": "true",
            "statusCode": "S",
            "tcn" : row.tcn
        }
        onSearch(obj);
      };
      const getFullData = (tableData) => {
        if(tableData && tableData.length) {
          let fData = JSON.stringify(tableData);
          fData = JSON.parse(fData);
          
          fData.map((each, index) => {
            each.index = index;
            each.exceptionLocationDate = moment(each.exceptionLocationDate).format('MM/DD/YYYY');
          });

          return fData;
        } else {
          return [];
        }
      }

    const tableComp = <TableComponent headCells={headCells} tableData={getFullData(props.tableData ? props.tableData : [])} onTableRowClick={editRow} defaultSortColumn="claimType" />;

    return (
        <>
         {spinnerLoader ? <Spinner /> : null}
        <div>            
            {props.tableData && props.tableData.length ?
                tableComp : null}
        </div>
</>
    );
}
export default withRouter(ClaimLocationSearchTable);