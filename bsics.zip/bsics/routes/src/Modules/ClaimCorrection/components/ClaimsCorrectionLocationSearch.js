import React from 'react';
import { Button } from 'react-bootstrap';
import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import TextField from '@material-ui/core/TextField';
import DateFnsUtils from '@date-io/date-fns';
import RadioGroup from '@material-ui/core/RadioGroup';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import { withRouter } from 'react-router';
//import { useDispatch, useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import dateFnsFormat from 'date-fns/format';
import * as ClaimsCorrectionConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Checkbox from '@material-ui/core/Checkbox';
import { resetSearchClaimsCorrection, claimCorrectionLocationSearchAction, locationDropdownAction } from '../actions';
import ClaimsLocationSearchTable from './ClaimsLocationSearchTable';
import ClaimCorrectionLocationSearchForm from './ClaimCorrectionLocationSearchForm'
function ClaimsCorrectionLocationSearch(props) {

    let errorMessagesArray = [];
    //const dispatch = useDispatch();
    const [showNoRecords, setShowNoRecords] = useState(false);
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const [showTable, setShowTable] = useState(false);
    const [showRecords, setShowRecords] = useState([]);

    const [values, setValues] = useState({ locationCode: '-1', locationType: '-1', restrictLocationUserID: null });
    // const props.props.onReset = () => dispatch(resetSearchClaimsCorrection());
    // const onSearch = searchvalues => { return dispatch(claimCorrectionLocationSearchAction(searchvalues)) };
    // const locationDropdown = () => dispatch(locationDropdownAction());
    // const props.payload = useSelector(state => state.claimCorrectionSearch.locationSearchprops.payload);
    // const locationDropdownData = useSelector(state => state.serviceSearch.locationprops.payload);
    // const claimTypeDropDown = props.dropdowns && props.dropdowns['Claims#C_TY_CD'] && props.dropdowns['Claims#C_TY_CD'].map(each => (
    //     <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    // ));
    const handleChanges = name => (event) => {
        if (event.target.type === 'checkbox') {
            setValues({ ...values, [name]: event.target.checked });
          } else {
            setValues({ ...values, [name]: event.target.value });
          }
    };

    
    const [redirect, setRedirect] = useState(false);

    // reset table
    const resetTable = () => {
        setShowNoRecords(false);
        props.setLocationShowError({
            showLocationCodeError: false,
            showLocationTypeError: false,
            showRestrictLocationUserIdError: false,
        });
        setValues(
            {
                "locationCode": "-1",
                "locationType": "-1",
                "restrictLocationUserID": null
            }
        );
        setShowTable(false);
        props.setLocationErrorMessages([]);
        props.locationDropdown();
        props.onReset()
    };

    const searchCheck = () => {
        setShowTable(false);
        setspinnerLoader(false);
        errorMessagesArray = [];
        props.setLocationErrorMessages([]);
        props.setLocationShowError({});
        let reqFieldArr = [];
        let showLocationCodeError;
        let showLocationTypeError;
        let showRestrictLocationUserIdError;

        if (values.locationCode === '-1') {
            showLocationCodeError = true;
            errorMessagesArray.push([ClaimsCorrectionConstants.LOCATION_CODE_ERROR]);
        }

        if (errorMessagesArray.length == 0) {
            if (values.locationCode != '-1' && values.locationType == '-1' && values.restrictLocationUserID == null) {
                let searchCriteria = {
                    "locationCode": values.locationCode,
                };
                props.onSearch(searchCriteria);
                setspinnerLoader(true);
            } else if (values.locationCode != '-1' && values.locationType != '-1' && values.restrictLocationUserID == null) {
                let searchCriteria = {
                    "claimType": values.locationType,
                    "locationCode": values.locationCode,
                };
                props.onSearch(searchCriteria);
                setspinnerLoader(true);
            } else if (values.locationCode != '-1' && values.locationType != '-1' && values.restrictLocationUserID != null) {
                let searchCriteria = {
                    "claimType": values.locationType,
                    "locationCode": values.locationCode,
                    "restrictLocationUserID": "52035009"
                };
                props.onSearch(searchCriteria);
                setspinnerLoader(true);
            }
        }
        else {
            props.setLocationErrorMessages(errorMessagesArray);
            setShowTable(false);
            props.setLocationShowError({
                showLocationCodeError,
                showLocationTypeError,
                showRestrictLocationUserIdError
            });
        }
    };

    useEffect(() => {
        props.locationDropdown();
    }, []);

    useEffect(() => {
        console.log(props.payload)
        if (props.payload && props.payload.data.recordCount == 0) {
            setspinnerLoader(false);
            setShowRecords([])
            props.setLocationErrorMessages([ClaimsCorrectionConstants.NO_RECORDS_WITHSEARCH]);
        }
        if (props.payload != null && props.payload.data.recordCount == 1) {
            props.history.push({
                pathname: '/CorrectionDetails',
            });
        }
        if (props.payload != null && props.payload.data.recordCount > 1) {
            props.setLocationErrorMessages(false)
            setShowRecords(props.payload.data.searchResults)
            setspinnerLoader(false);
        }

    }, [props.payload]);
    return (
        <div>
                    {spinnerLoader ? <Spinner /> : null}

           < ClaimCorrectionLocationSearchForm 
           spinnerLoader = {spinnerLoader}
           values = {values}
           handleChanges = {handleChanges}
           errors = {props.errors}
           locationDropdownData = {props.locationDropdownData}
           claimTypeDropDown = {props.dropdowns}
           searchCheck = {searchCheck}
           resetTable = {resetTable}
           />
            <ClaimsLocationSearchTable tableData={showRecords} setRedirect = {props.setRedirect}/>
        </div>

    )

}
export default ClaimsCorrectionLocationSearch