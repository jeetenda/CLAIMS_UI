import React from 'react';
export const setZeroAtdecimalPoint = (value) => {
    if (value != "" && value.split(".").length > 1) {
        let valuesplit = value.split(".");
        let newVal = valuesplit[1].length == 0 ? value + "00" : valuesplit[1].length == 1 ? value + "0" : value;
        return newVal;
    }
    else {
        return value;
    }
}


