
import React, { useState, useEffect, useRef } from 'react';
import { Button } from 'react-bootstrap';
import TextField from '@material-ui/core/TextField';
import * as ErrorMessageConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import * as serviceEndPoint from '../../../SharedModules/services/service';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import TableComponent from '../../../SharedModules/Table/Table';
import ExceptionTableComponent from './../../../SharedModules/Table/ExceptionViewTable';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import TabPanel from '../../../SharedModules/TabPanel/TabPanel';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import Grid from '@material-ui/core/Grid';
import Axios from 'axios';
import Claim from './Main/Claim';
import QuickLinks from '../../ClaimsEntry/Components/DentalClaim/QuickLinks';
import Member from './Main/Member';
import Visit from '../../ClaimsEntry/Components/DentalClaim/Visit';
import OtherPayer from '../../ClaimsEntry/Components/DentalClaim/OtherPayer';
import LineItems from '../../ClaimsEntry/Components/DentalClaim/LineItems/LineItem';
import PaymentProvider from './Main/Payment&Provider';
import ReplacementVoids from './DentalClaim/ReplacementVoid';
import History from './DentalClaim/History';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import AttachmentsComponent from '../../ClaimsEntry/Components/DentalClaim/LineItems/AttachmentsComponent';
import ManualEobsComponent from '../../ClaimsEntry/Components/DentalClaim/LineItems/ManualEobsComponent';
import AdditionalRemarksComponent from '../../ClaimsEntry/Components/DentalClaim/LineItems/AdditionalRemarksComponent';
import OverrideException from '../../ClaimsEntry/Components/DentalClaim/OverrideException';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';
import { useDispatch, useSelector } from 'react-redux';
import { useConfirm } from '../../../SharedModules/MUIConfirm/index';
import ExceptionView from './ExceptionView';
import OtherServiceInfo from './OtherServiceInfo';
import ClaimsOtherInfo from './DentalOtherInfo';
import BasicClaimInfo from './DentalClaim/BasicClaimInfo';
import dateFnsFormat from 'date-fns/format';
import * as moment from "moment";
import "moment-range";
import NavigationPrompt from "react-router-navigation-prompt";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import * as ErrorConst from '../../../SharedModules/Messages/ErrorMsgConstants';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

const headCells = [
    { id: "lineNumber", numeric: false, disablePadding: true, label: 'LI', enableHyperLink: false, fontSize: 12 },
    { id: "exceptionCode", numeric: false, disablePadding: true, label: 'Code', enableHyperLink: true, fontSize: 12 },
    { id: "statusCode", numeric: false, disablePadding: true, label: 'Status', enableHyperLink: false, fontSize: 12 }
]
function ClaimCorrectionDetails(props) {
    console.log("props is --",props)
    const classes = useStyles();
    const muiconfirm = useConfirm();
    const [tabValue, setTabValue] = useState(0);
    //const [claimDetailsData, setClaimDetailsData] = React.useState(props.location.getClaimCorrection)
    const data = props.location && props.location.getClaimCorrection ? props.location.getClaimCorrection : {};
    let d = data.data ? data.data : {};
    if (data.data && data.data.batchInfo && data.data.batchInfo.paymentTypeCode == null && data.data.additionalClaimData.paymentTypeCode) {
        data.data.batchInfo.paymentTypeCode = data.data.additionalClaimData.paymentTypeCode;
    }
    d.claimTPLInfo.map(eachTPLInfo => {
        eachTPLInfo.claimTPLAmountInfo.map(eachAmount => {
          eachAmount.allowedAmount= eachAmount.allowedAmount ? Number.parseFloat(eachAmount.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
          eachAmount.billedAmount= eachAmount.billedAmount ? Number.parseFloat(eachAmount.billedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
          eachAmount.coPayAmount= eachAmount.coPayAmount ? Number.parseFloat(eachAmount.coPayAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
          eachAmount.coinsuranceAmount= eachAmount.coinsuranceAmount ? Number.parseFloat(eachAmount.coinsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
          eachAmount.deductibleAmount= eachAmount.deductibleAmount ? Number.parseFloat(eachAmount.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
          eachAmount.paidAmount= eachAmount.paidAmount ? Number.parseFloat(eachAmount.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
          eachAmount.patientResponsibleAmount= eachAmount.patientResponsibleAmount ? Number.parseFloat(eachAmount.patientResponsibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
        });
      });
      d.enterpriseClaimLineItem.map(eachline => {
        eachline.submitChargeAmount = eachline.submitChargeAmount ? Number.parseFloat(eachline.submitChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
        eachline.submitUnits = eachline.submitUnits ? Number.parseFloat(eachline.submitUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
        eachline.baseRateAmount = eachline.baseRateAmount ? Number.parseFloat(eachline.baseRateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
        eachline.calculatedAllowedAmount = eachline.calculatedAllowedAmount ? Number.parseFloat(eachline.calculatedAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
        eachline.allowedChargeAmount = eachline.allowedChargeAmount ? Number.parseFloat(eachline.allowedChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
        eachline.allowedUnitQty = eachline.allowedUnitQty ? Number.parseFloat(eachline.allowedUnitQty).toFixed(1) : Number.parseFloat(0).toFixed(1);
        eachline.tplAmount = eachline.tplAmount ? Number.parseFloat(eachline.tplAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
        eachline.reimbursementAmount = eachline.reimbursementAmount ? Number.parseFloat(eachline.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
        eachline.reimbursementUnits = eachline.reimbursementUnits ? Number.parseFloat(eachline.reimbursementUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
      });
      d.totalChargeAmount = d.totalChargeAmount ? Number.parseFloat(d.totalChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
      d.totalTPLAmount = d.totalTPLAmount ? Number.parseFloat(d.totalTPLAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
      d.totalNetChargeAmount = d.totalNetChargeAmount ? Number.parseFloat(d.totalNetChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
      let payment = d.payment ? d.payment : {};
      payment.reimbursementAmount = payment.reimbursementAmount ? Number.parseFloat(payment.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
      d.payment = payment;
      data.data = d;
    const [spinnerLoader, setspinnerLoader] = useState(false);
    const [errorMessages, seterrorMessages] = useState([]);
    const [lineItemData, setLineItemData] = useState([]);
    const [claimEntryData, setClaimEntryData] = useState(data.data);
    const [defaultClaimEntryData, setDefaultClaimEntryData] = useState(JSON.parse(JSON.stringify(claimEntryData)));
    const [successMessages, setSuccessMessages] = useState([]);
    const [exceptionCodeList, setExceptionCodeList] = React.useState();
    const [exceptionDetail, setExceptionDetail] = useState([]);
    const [showDetails, setShowDetails] = useState(false);
    const [lineNum, setShowLineNum] = useState();
    const [showExceptionCode, setShowExceptionCode] = useState();
    const [readResolution, setReadResolution] = useState(false);
    const [adTabId, setAdTabId] = useState([]);
    const dispatch = useDispatch();
    const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
    const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
    const [quickLinks,setQuickLinks] = useState(["Claim", "Member", "Visit", "Other Payer", "Line Items", "Payment & Provider", "Replacement / Void", "History", "Attachments", "Override Exceptions", "Additional Remarks", "Manual EOBs"]);
    const [diagnosis, setDiagnosis] = useState([]);
    const [accidentIllnessDate, setAccidentIllnessDate] = useState(null);
    const [{billedDateErr, dobDateErr, accidentIllErr, payTotalChrgErr, payNetAmtErr}, setFieldError] = useState(false);
    const [{billedDate,dateOfBitrh}, setInputDates] = useState({});
    const [prompt, setPrompt] = useState(false)
    const [cancelType, setCancelType] = useState(false);
    const [confirm, setConfirm] = useState(false);
    const [attachmentSeqNum, setAttachmentSeqNum] = useState(1);
    const [claimMainErr,setClaimMainErr] = useState({});
    const [defaultLineItem, setDefaultLineItem] = useState({
        "auditUserID": null,
        "auditTimeStamp": null,
        "addedAuditUserID": null,
        "addedAuditTimeStamp": null,
        "versionNo": 0,
        "lineNumber": 1,
        "abortionIndicator": false,
        "allowedChargeAmount": 0.0,
        "allowedUnitQty": 0.0,
        "benefitPlanID": "",
        "followUpLimitDate": "",
        "fundCode": "",
        "fdos": "9999-12-31",
        "ldos": "",
        "multipleSurgeryIndicator": false,
        "lifetimeIndicator": false,
        "billingProcedureModifier1": null,
        "billingProcedureModifier2": null,
        "billingProcedureModifier3": null,
        "billingProcedureModifier4": null,
        "reimbursementStatusCode": "",
        "serviceAuthIndicator": false,
        "epsdtConditionCode": null,
        "baseRateSourceCode": "",
        "baseRateAmount": 0.0,
        "calculatedAllowedAmount": 0.0,
        "categoryOfServiceCode": "",
        "submittedCLIANumber": null,
        "copayExemptCode": null,
        "costAvoidIndicator": false,
        "duplicateCheckIndicator": false,
        "fatalErrorIndicator": false,
        "hysterectomyIndicator": false,
        "placeOfServiceCode": "",
        "procedureCode": null,
        "submitChargeAmount": 0.0,
        "mapSetID": "",
        "reimbursementAmount": 0.0,
        "reimbursementUnits": 0,
        "serviceArea": "",
        "sterilizationIndicator": false,
        "submitUnits": 0,
        "tplAmount": 0,
        "memberLockInSystemID": null,
        "memberLockInTypeCode": null,
        "claimServiceAuthorization": {
        "serviceAuthID": null,
        "serviceAuthLineNumber": 0,
        "serviceAuthIndicator": false,
        "submittedServiceAuthID": null,
        "saRequiredIndicator": false,
        "saUnitAmount": null,
        "saUnits": null,
        "approvedUnitAmount": null,
        "approvedAmount": null,
        "usedUnitAmount": null,
        "usedAmount": null
        },
        "renderingProvider": null,
        "referringProvider": null,
        "attendingProvider": null,
        "dentalLineItem": {
        "oralCavityCode1": null,
        "toothInformation": [
                {
                    "auditUserID": null,
                    "auditTimeStamp": null,
                    "addedAuditUserID": null,
                    "addedAuditTimeStamp": null,
                    "versionNo": 0,
                    "toothNumberCode": null,
                    "surfaceCode1": null,
                    "surfaceCode2": null,
                    "surfaceCode3": null,
                    "surfaceCode4": null,
                    "surfaceCode5": null,
                    "sequenceNumber": 1,
                    "toothQualifierCode": "",
                    "lineNumber": null
                }
            ],
        "oralCavityCode2": null,
        "oralCavityCode3": null,
        "oralCavityCode4": null,
        "oralCavityCode5": null,
        "multipleToothIndicator": false,
        "toothSurfaceCode1": null,
        "toothSurfaceCode2": null,
        "toothSurfaceCode3": null,
        "toothSurfaceCode4": null,
        "toothSurfaceCode5": null,
        "toothCode": null,
        "relatedDiagnosisPointer1": null,
        "relatedDiagnosisPointer2": null,
        "relatedDiagnosisPointer3": null,
        "relatedDiagnosisPointer4": null
        },
        "professionalLineItem": null,
        "institutionalLineItem": null,
        "procedureModifierCode1": null,
        "procedureModifierCode2": null,
        "procedureModifierCode3": null,
        "procedureModifierCode4": null,
        "statusCode": null,
        "dispositionCode": null,
        "medicareDetails": null,
        "referralID": null,
        "localProcedureCode": null,
        "cosDefaultIndicator": false,
        "upn": null,
        "claimLineItemProcessFields": null,
        "enterpriseClaimLineItemAux": {
        "networkID": "",
        "serviceComponentCode": "",
        "revenueCodeReqsProcIndicator": false,
        "preOpLimitDate": "",
        "memberAge": 0,
        "cliaNumber": null,
        "levelOfCareCode": null,
        "familyPlanIndicator": false,
        "tplIndicator": false,
        "allowanceUnitIndicator": false,
        "retentionCode": null,
        "serviceAuthTypeCode": null,
        "referralID": null,
        "liableAmount": 0,
        "federalFundAmount": 0,
        "stateFundAmount": 0,
        "countyFundAmount": 0,
        "otherFundAmount": 0,
        "checkLineNumber": 0,
        "checkResultCode": null,
        "checkStatusCode": null,
        "managedCareCoPayAmount": 0,
        "coeCode": "",
        "memberLockInTypeCode": null,
        "submittedLineNumber": 0,
        "memberLockInSystemID": 0
        },
        "claimLIDrugInfo": [],
        "lobCode": null,
        "line1099Indicator": true,
        "bpNetworkStatusCode": "",
        "orderedLIDrugInfo": [],
        "procedureCodeDescription": "",
        "emergencyIndicator": false,
        "peIndicator": null,
        "nnnCode": null,
        "ndcrelatedLineNum": 0,
        "mcolineItemStatCode": null,
        "manualEOB": [],
        "additionalRemark": [],
        "attachment": [],
        "claimSubmittedProvider": [],
        "baseRateChangeInfo": [],
        "professionalLineItem":{  
            "relatedDiagnosisPointer1" : null,
            "relatedDiagnosisPointer2" : null,
            "relatedDiagnosisPointer3" : null,
            "relatedDiagnosisPointer4" : null,
            "familyPlanIndicator" : false,
            "obstetricAnesthesiaAddlUnitQuantity" : null,
            "submittedFamilyPlanningIndicator" : false
        }
    });
    const [showQuickLink, setShowQuickLink] = useState(true);
    const [updateException, setUpdateException] = useState(new Date());
    const handelPromptSet = (set) => {
        if (set)
            setPrompt(true);
      }
    useEffect(() => {
        onDropdowns([Dropdowns.VV_PROVIDER_ROLE, Dropdowns.VV_PROVIDER_ROLE_ID_TYPE]);
        setLineItemData(data.data.enterpriseClaimLineItem);   
        let intBilledDate = data.data && data.data.billedDate ? data.data.billedDate : "";
        let intDateBirth = data.data && data.data.claimMember && data.data.claimMember.dateOfBirth ? dateFnsFormat(new Date(data.data.claimMember.dateOfBirth),"MM/dd/yyyy") : "01/01/0001";
        setInputDates({billedDate: intBilledDate, dateOfBitrh: intDateBirth});
        let max = data.data && data.data.claimAttachment && data.data.claimAttachment.length > 0 ? Math.max.apply(Math, data.data.claimAttachment.map(function(o) { return o.sequenceNumber; })) : 0;
        setAttachmentSeqNum(max + 1);
        if (data.data.relatedCauseCode1 || data.data.relatedCauseCode2 || data.data.relatedCauseCode3) {
            setAccidentIllnessDate(data.data && data.data.enterpriseClaimAux && data.data.enterpriseClaimAux.accidentDateTime ? data.data.enterpriseClaimAux.accidentDateTime : null );
          } else {
            setAccidentIllnessDate(data.data && data.data.illnessDate ? data.data.illnessDate : null);
          }  
        if (props.location.type && props.location.type == 'entry_validated') {
            setSuccessMessages([ErrorMessageConstants.CLAIM_ENTRY_VALIDATE]);
        }
    },[]);
    useEffect(() => {

    }, [adTabId, setAdTabId]);
    const handleAdjustment = '';

    if (!data) {
        props.history.push({ pathname: '/Entry' });
    }

    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
        if(newValue == 0){
            setQuickLinks(["Claim", "Member", "Visit", "Other Payer", "Line Items", "Payment & Provider", "Replacement / Void", "History", "Attachments", "Override Exceptions", "Additional Remarks", "Manual EOBs"]);
        }
        if(newValue == 1){
            setQuickLinks(["Provider Information", "Member Information", "Claim Information", "Basic Line Item Information"]);
        }
        if(newValue == 2){
            setQuickLinks(["Claim  Information  ", "Claim Provider Information", "Coordination of Benefits"]);
        }
        if(newValue == 3){
            setQuickLinks(["Service Line Information", "Service Line Provider Information", "Other Payer Service Line Provider Information"]);
        }
    }
    const setManualEobsValues = (val) => {
        setClaimEntryData({...claimEntryData,manualEOB:val.manualEOB?val.manualEOB:[]});
    };
    const setAdditionalRemarksValues = (val) => {
        setClaimEntryData({...claimEntryData,additionalRemark:val.additionalRemark?val.additionalRemark:[]});
    };
    const setAttachmentsValues = (val) => {
        setClaimEntryData({...claimEntryData,claimAttachment:val.attachment?val.attachment:[]});
    };
    const handelDeleteFunc = () => {
        seterrorMessages([]);
        setspinnerLoader(true);
        muiconfirm({title:"", description: 'Are you sure that you want to delete?',dialogProps: { fullWidth: false}})
        .then(() => {
            if (props.location.type && props.location.type == 'entry_validated') {
                setConfirm(true);
                props.history.push({
                    pathname: '/Entry',
                    message: ErrorMessageConstants.BENIFIT_PLAN_DELETE_SUCCESS
                });
            } else {
                let values = {
                    "tcn": data.data.tcn,
                    "statusCode": "Z",
                    "userId": data.data.userId
                }
                Axios.post(`${serviceEndPoint.CLAIM_CORRECTION_DELETE_ENDPOINT}`, values).then(res => {
                    setspinnerLoader(false);
                    setConfirm(true);                    
                    if(res.data) {
                        props.history.push({
                            pathname: '/Correction',
                            message: ErrorMessageConstants.BENIFIT_PLAN_DELETE_SUCCESS
                        });
                    }else{                             
                        seterrorMessages(['Claim Correction is not Deleted']);
                    }
                })
                .catch(e => {
                    setspinnerLoader(false);
                    seterrorMessages([ErrorMessageConstants.ERROR_OCCURED_DURING_TRANSACTION]);
                });
            }
        });
    };

    const cancelFunc = () => {
    setCancelType(true);
    if (props.location.type && props.location.type == 'entry_validated') {
        props.history.push({
            pathname: '/Entry',
            currentTab: props.location.tabValue
            });
    } else {
        props.history.push({
        pathname: '/Correction',
        currentTab: props.location.tabValue
        });
    }
  };

  const releaseLockFunc = () => {
    let values = {
        "tcnNum": claimEntryData.tcn,
      "memSysId":claimEntryData.claimMember.altMemberID,
      "userId":"Naga",
      "deleteOrSelect":true,
      "ediIndicator":false
    }
    axios.post(`${serviceEndPoint.CLAIM_CORRECTION_RELEASE_LOCK_ENDPOINT}`, values) 
};
   
    
    const correctClaim = (claimSource) => {
        const errorMessagesArray = [];        
        seterrorMessages([]);
        setSuccessMessages([]);
        setClaimMainErr({});
        if(claimEntryData.payment.overrideLocationCode || claimEntryData.overrideUserID){
        if(!claimEntryData.payment.overrideLocationCode){
            setClaimMainErr({overrideLocReq:true});
            seterrorMessages([ErrorMessageConstants.CC_OVR_LOC_REQ]);
            return false;
        }
        if(!claimEntryData.overrideUserID){
            setClaimMainErr({userIdReq:true});
            seterrorMessages([ErrorMessageConstants.CC_OVR_USR_REQ]);
            return false;
        }
        }
        setspinnerLoader(true);
        setFieldError({
            dobDateErr: dateOfBitrh && (!moment(dateOfBitrh, 'MM/DD/YYYY',true).isValid() || new Date(dateOfBitrh).toString() == "Invalid Date" ) ? (() => {errorMessagesArray.push(ErrorConst.MEMBER_DATE_ERR); return true;})() : false,
            billedDateErr: (billedDate && billedDate.toString() == "Invalid Date") || billedDate == null ? (() => {errorMessagesArray.push(ErrorConst.BILLED_DATE_ERR); return true;})() : false,
            accidentIllErr: (accidentIllnessDate && new Date(accidentIllnessDate).toString() == "Invalid Date") || accidentIllnessDate == null ? (() => {errorMessagesArray.push(ErrorConst.VISIT_ILLNESS_ERROR); return true;})() : false,
            payTotalChrgErr: claimEntryData.totalChargeAmount && (isNaN(claimEntryData.totalChargeAmount) || claimEntryData.totalChargeAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.PAYMENT_TOTAL_CHRG_ERR); return true;})() : false,
            payNetAmtErr: claimEntryData.totalNetChargeAmount && (isNaN(claimEntryData.totalNetChargeAmount) || claimEntryData.totalNetChargeAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.PAYMENT_NET_AMT_ERR); return true;})() : false,
          });
          if (errorMessagesArray.length > 0) {
            seterrorMessages(errorMessagesArray);
            setspinnerLoader(false);
            return false;
          }
          let linedataMod = JSON.parse(JSON.stringify(lineItemData));
    // if (linedataMod.length == 0) {
    //   linedataMod.push(defaultLineItem);
    // }
    let submittedProviderList = [];
    let attachmentList = [];
    submittedProviderList.push(...JSON.parse(JSON.stringify(claimEntryData.claimProviderID)));
    attachmentList.push(...JSON.parse(JSON.stringify(claimEntryData.claimAttachment)));
    linedataMod.map((each) => {
        each.claimSubmittedProvider ? submittedProviderList.push(...JSON.parse(JSON.stringify(each.claimSubmittedProvider))) : submittedProviderList;
        each.attachment ? attachmentList.push(...JSON.parse(JSON.stringify(each.attachment))) : attachmentList;
    });
    const uniqueSubmittedProvider = Array.from(new Set(submittedProviderList.map(each => `${each.lineNumber}/${each.providerRoleCode}/${each.providerIDType}`)))
        .map(id => submittedProviderList.find(each => each.lineNumber == id.split('/')[0] && each.providerRoleCode == id.split('/')[1] && each.providerIDType == id.split('/')[2]));
    const uniqueAttachments = Array.from(new Set(attachmentList.map(each => each.sequenceNumber)))
        .map(id => attachmentList.find(each => each.sequenceNumber == id))
    linedataMod.map(each => {
      each.claimSubmittedProvider = uniqueSubmittedProvider.filter(e => e.lineNumber == each.lineNumber);
      each.attachment = uniqueAttachments.filter(e => e.lineNumber == each.lineNumber);
    });
    claimEntryData.enterpriseClaimLineItem = linedataMod;
    claimEntryData.claimProviderID = uniqueSubmittedProvider; 
    claimEntryData.claimAttachment = uniqueAttachments;
          claimEntryData.billedDate = billedDate && billedDate != '01/01/0001' ? moment(billedDate).format("YYYY-MM-DD") : "";
          claimEntryData.claimMember.dateOfBirth = dateOfBitrh && dateOfBitrh != '01/01/0001' ? moment(dateOfBitrh.replace("/",'-')).format("YYYY-MM-DD") : "";
        if (claimEntryData.relatedCauseCode1 || claimEntryData.relatedCauseCode2 || claimEntryData.relatedCauseCode3) {
            claimEntryData.enterpriseClaimAux.accidentDateTime = accidentIllnessDate;
          } else {
            claimEntryData.illnessDate = accidentIllnessDate;
          }
        if(claimEntryData.claimProcessFields){
            claimEntryData.claimProcessFields["claimSource"] = claimSource;
        }else{
            claimEntryData.claimProcessFields = {
                "auditUserID": "test",
                "auditTimeStamp": null,
                "addedAuditUserID": "test",
                "addedAuditTimeStamp": null,
                "versionNo": 0,
                "medicareAssignmentCode": "",
                "ruleCode": "",
                "drgReturnCode": "",
                "mdcCode": "",
                "mdcTitle": "",
                "drgGrouperVersion": "",
                "drgTitle": "",
                "reimbInvocationCount": 0,
                "networkStatusCode": "",
                "spendDownLeft": 0,
                "spendDownSpanSeqNumber": 0,
                "finDataExists": false,
                "replacedClaimStatus": "",
                "adjustmentReasonCode": "",
                "faultName": "",
                "claimSourceID": "",
                "saLowerOfLogicIndicator": false,
                "pricingIdentifier": "",
                "procedureCodeSwitchIndicator": false,
                "memberLocked": false,
                "payeeCode": "",
                "submittedRemarksNotInSL": false,
                "autoAdjustment": false,
                "bundledClaim": false,
                "accidentIndicator": false,
                "billingProviderCmnEntitySK": "",
                "renderingProviderCmnEntitySK": "",
                "attendingProviderCmnEntitySK": "",
                "referringProviderCmnEntitySK": "",
                "payToProviderCmnEntitySK": "",
                "memberCmnEntitySK": "",
                "replacedMemberID": "",
                "doAdjustmentsIndicator": false,
                "gender": "",
                "systemListParamUseHeaderIndicator": false,
                "systemListParamDate": "",
                "coeCodeFlag": false,
                "patStatusFlag": false,
                "defaultLowDate": "",
                "defaultHighDate": "",
                "compoundDrugIndicator": false,
                "usedFundCodeSK": "",
                "usedClaimTypeSK": "",
                "bypassDupChkAndUR": false,
                "profitIndicator": false,
                "creditClaim": false,
                "bhConnectivityFlag": false,
                "originalClaimUserId": "",
                "claimSource": "ONLINE_VALIDATE",
                "isStaleClaim": false,
                "proceducreLTCIndicator": false
            };
            claimEntryData.claimProcessFields["claimSource"] = claimSource;
        }
        if ( props.location.type && props.location.type == 'entry_validated') {
            claimEntryData.operationType = "Save";
        } else {claimEntryData.operationType = "Update";}
        if (claimEntryData.batchInfo.batchTypeCode == null && claimEntryData.additionalClaimData.batchTypeCode) {
            claimEntryData.batchInfo.batchTypeCode = claimEntryData.additionalClaimData.batchTypeCode;
        }
        // claimEntryData.diagnosis = claimEntryData.diagnosis.filter(e => e.sequenceNumber !== null || e.sequenceNumber !== "");
        //increasing timeout to 5mins for testing
        Axios.post(`${serviceEndPoint.CLAIMS_ENTER_CLAIM}`, claimEntryData)
          .then(response => {
            if (response.data.status === 'Success') {
                  if (claimSource == 'ONLINE_SAVE') {
                      if ( props.location.type && props.location.type == 'entry_validated') {
                        setConfirm(true);
                        claimEntryRedirect();
                      }
                      setSuccessMessages([ErrorMessageConstants.SUCCESSFULLY_SAVED_INFORMATION]);
                  }
                if (claimSource == 'ONLINE_VALIDATE') {
                    let d = JSON.parse(response.data.data)
                    let billedDate = d.billedDate ?  d.billedDate : "";
                    let DateOfBirthconst = d.claimMember ? d.claimMember.dateOfBirth ? dateFnsFormat(new Date(d.claimMember.dateOfBirth),"MM/dd/yyyy") : "01/01/0001" : "01/01/0001";
                    setInputDates({billedDate: billedDate, dateOfBitrh: DateOfBirthconst});
                    if (d.relatedCauseCode1 || d.relatedCauseCode2 || d.relatedCauseCode3) {
                        setAccidentIllnessDate(d.enterpriseClaimAux.accidentDateTime);
                      } else {
                        setAccidentIllnessDate(d.illnessDate);
                      }
                      d.claimAttachment = d.claimAttachment.filter(e => e.sequenceNumber != null);
                  d.enterpriseClaimLineItem.map(eachLine => {
                    eachLine.attachment = eachLine.attachment ? eachLine.attachment.filter(e => e.sequenceNumber != null && e.lineNumber == eachLine.lineNumber) : [];
                  });
                  d.claimTPLInfo.map(eachTPLInfo => {
                    eachTPLInfo.claimTPLAmountInfo.map(eachAmount => {
                      eachAmount.allowedAmount= eachAmount.allowedAmount ? Number.parseFloat(eachAmount.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                      eachAmount.billedAmount= eachAmount.billedAmount ? Number.parseFloat(eachAmount.billedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                      eachAmount.coPayAmount= eachAmount.coPayAmount ? Number.parseFloat(eachAmount.coPayAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                      eachAmount.coinsuranceAmount= eachAmount.coinsuranceAmount ? Number.parseFloat(eachAmount.coinsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                      eachAmount.deductibleAmount= eachAmount.deductibleAmount ? Number.parseFloat(eachAmount.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                      eachAmount.paidAmount= eachAmount.paidAmount ? Number.parseFloat(eachAmount.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                      eachAmount.patientResponsibleAmount= eachAmount.patientResponsibleAmount ? Number.parseFloat(eachAmount.patientResponsibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    });
                  });
                  d.enterpriseClaimLineItem.map(eachline => {
                    eachline.submitChargeAmount = eachline.submitChargeAmount ? Number.parseFloat(eachline.submitChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachline.submitUnits = eachline.submitUnits ? Number.parseFloat(eachline.submitUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
                    eachline.baseRateAmount = eachline.baseRateAmount ? Number.parseFloat(eachline.baseRateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachline.calculatedAllowedAmount = eachline.calculatedAllowedAmount ? Number.parseFloat(eachline.calculatedAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachline.allowedChargeAmount = eachline.allowedChargeAmount ? Number.parseFloat(eachline.allowedChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachline.allowedUnitQty = eachline.allowedUnitQty ? Number.parseFloat(eachline.allowedUnitQty).toFixed(1) : Number.parseFloat(0).toFixed(1);
                    eachline.tplAmount = eachline.tplAmount ? Number.parseFloat(eachline.tplAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachline.reimbursementAmount = eachline.reimbursementAmount ? Number.parseFloat(eachline.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachline.reimbursementUnits = eachline.reimbursementUnits ? Number.parseFloat(eachline.reimbursementUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
                  });
                  d.totalChargeAmount = d.totalChargeAmount ? Number.parseFloat(d.totalChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  d.totalTPLAmount = d.totalTPLAmount ? Number.parseFloat(d.totalTPLAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  d.totalNetChargeAmount = d.totalNetChargeAmount ? Number.parseFloat(d.totalNetChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  let payment = d.payment ? d.payment : {};
                  payment.reimbursementAmount = payment.reimbursementAmount ? Number.parseFloat(payment.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  d.payment = payment;
                  setLineItemData(d.enterpriseClaimLineItem);
                    setClaimEntryData(d);
                    setSuccessMessages([ErrorMessageConstants.CLAIM_ENTRY_VALIDATE]);
                    setUpdateException(new Date());
                }
            } else {
              seterrorMessages([ErrorMessageConstants.ERROR_OCCURED_DURING_TRANSACTION]);
            }
          })
          .catch(error => {
            seterrorMessages([ErrorMessageConstants.ERROR_OCCURED_DURING_TRANSACTION]);
          })
          .then(function () {
            setspinnerLoader(false);
            
          });
    };

    const claimEntryRedirect = () => {
        Axios.post(`${serviceEndPoint.CLAIMS_ENTER_DOCUMENT}`, { "batchDate":  props.location.batchDetails.batchDate, "batchNo":  props.location.batchDetails.batchNo })
        .then(response => {
            if (response.data.status == 200) {
                if (response.data.data) {
                    props.history.push({pathname:"/DentalClaimEntry",state:{detail:response.data.data, batchDetails:props.location.batchDetails, type: "corrextion_success" }})
                } else {
                    setConfirm(true);
                    props.history.push({pathname:"/Entry", state: {type: "total_documents_entered"}});
                }
            }else if(response.data.status == 500 || !response.data){
                setConfirm(true);
                props.history.push({pathname:"/Entry", state: {type: "total_documents_entered"}});
            }else {
                setConfirm(true);
            props.history.push({pathname:"/Entry", state: {type: "total_documents_entered"}});
            }
        })
        .catch(error => {
            setConfirm(true);
        props.history.push({pathname:"/Entry"});
        })
    }
    const handelDocFunc = () => { 
        window.open(`/ViewDocuments`, "_blank");   
    };  
    const handelNotesFunc = () => { 
        window.open(`/Notes`, "_blank");   
    };  
    return (
        <div className="pos-relative">
            <NavigationPrompt
          when={(crntLocation, nextLocation) => {if (confirm) {return false} else {handelPromptSet(nextLocation); return true}}}
          // when={true}
      >
          {({ onConfirm, onCancel }) => (
              <Dialog
                  open={prompt}
                  aria-labelledby="alert-dialog-title"
                  aria-describedby="alert-dialog-description"
                  className="custom-alert-box"
              >
                  <DialogContent>
                  <DialogContentText id="alert-dialog-description">
                      {cancelType ? "Are you sure that you want to Cancel?" : 
                      (<>Unsaved changes will be lost. <br/>
                        Are you sure you want to continue?</>)}
                  </DialogContentText>
                  </DialogContent>
                  {cancelType ? (<DialogActions>
                      <Button onClick={() => {onConfirm(); releaseLockFunc()}} color="primary" className="btn btn-success">
                          Ok
                      </Button>
                      <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" autoFocus>
                          Cancel
                      </Button>
                  </DialogActions>) : (<DialogActions>
                      <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" className="btn btn-transparent">
                      STAY ON THIS PAGE!
                      </Button>
                      <Button onClick={onConfirm} color="primary" className="btn btn-success" autoFocus>
                      CONTINUE <i className="fa fa-arrow-right ml-1"></i>
                      </Button>
                  </DialogActions>)}
              </Dialog>
          )}
      </NavigationPrompt>
            {spinnerLoader
                ? <Spinner />
                : null}
            {errorMessages.length
                ? (
                    <div className="alert alert-danger custom-alert" role="alert">
                        {errorMessages.map(message => <li>{message}</li>)}
                    </div>
                )
                : null
            }
            {successMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {successMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null}
            <div className="mb-2">
                <BreadCrumbs
                    parent="Claims"
                    child1="Claim Correction"
                    path="Correction"
                />
            </div>

            <div className="tabs-container">
                <div className="tab-header claim-btnarea-bdr pb-2 mb-3">
                    <h1 className="page-heading float-left"> Internal Claim Correction - Dental </h1>
                    <div className="float-right th-btnGroup">
                        <Button title="Save &amp; Submit" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={()=>{correctClaim("ONLINE_SAVE")}} disabled={props.privileges && !props.privileges.update? 'disabled':''}> Save &amp; Submit</Button>
                        <Button title="Validate" variant="outlined" color="primary" className="btn btn-ic btn-validate" onClick={()=>{correctClaim("ONLINE_VALIDATE")}}> Validate</Button>
                        <Button title="Notes" variant="outlined" color="primary" className="btn btn-ic btn-notes" onClick={() => handelNotesFunc()}> Notes </Button>
                        <Button title="View Documents" className="btn btn-ic btn-view"  onClick={() => handelDocFunc()}>View Documents</Button>
                        <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => handelDeleteFunc()} disabled={props.privileges && !props.privileges.update? 'disabled':''}>Delete</Button>
                        <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => {setClaimEntryData({...defaultClaimEntryData});}}>Reset</Button>
                        <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => cancelFunc()} > Cancel</Button>
                        <Button title="Print" className="btn btn-ic btn-print">Print </Button>
                        <Button title="Help" className="btn btn-ic btn-help"> Help</Button>
                    </div>
                </div>
                <div className="clm-inquiry-tabData pull-left">
                    <div className="tab-body-bordered my-2">
                        <div className='tab-holder custom-tabber pb-3'>
                            <AppBar position='static' color="default">
                                <Tabs value={tabValue} onChange={handleTabChange}
                                    indicatorColor="primary"
                                    textColor="primary"
                                    variant="scrollable"
                                    scrollButtons="auto"
                                    aria-label='simple tabs example'
                                >
                                    <Tab title="Main" label="Main" {...a11yProps(0)} />
                                    <Tab title="Basic Claim Info" label="Basic Claim Info"{...a11yProps(1)} onClick={() => setShowQuickLink(true)} />
                                    <Tab title="Other Claim Info" label="Other Claim Info" {...a11yProps(2)} onClick={() => setShowQuickLink(true)} />
                                    <Tab title="Other Service Info" label="Other Service Info" {...a11yProps(3)} onClick={() => setShowQuickLink(false)} />
                                </Tabs>
                            </AppBar>
                            <TabPanel value={tabValue} index={0}>
                                <div id="Claim Div Id">
                                    <Claim
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} history={props.history}
                                        claimMainErr={claimMainErr}/>
                                </div>
                                <div id="Member Div Id">
                                    <Member
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} 
                                        dates={{billedDate,dateOfBitrh}} setInputDates={setInputDates}
                                        errors={{dobDateErr}} />
                                </div>
                                <div id="Visit Div Id">
                                    <Visit
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData}
                                        accidentIllnessDate={accidentIllnessDate} setAccidentIllnessDate={setAccidentIllnessDate}
                                        errors={{accidentIllErr}}/>
                                </div>
                                <div id="Other Payer Div Id">
                                    <OtherPayer
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} seterrorMessages={seterrorMessages} setsuccessMessages = {setSuccessMessages}/>
                                </div>
                                <div id="Line Items Div Id">
                                    <LineItems lineItemData={lineItemData} headerSubmittedProvider={claimEntryData.claimProviderID} setLineItemData={setLineItemData} seterrorMessages={seterrorMessages} addDropdowns={addDropdowns} type="correction"
                                    attachmentSeqNum={attachmentSeqNum} setAttachmentSeqNum={setAttachmentSeqNum}
                                    setsuccessMessages={setSuccessMessages} mainData={claimEntryData}
                                    setClaimEntryData={setClaimEntryData} />
                                </div>
                                <div id="Payments & Provider Div Id">
                                    <PaymentProvider
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} seterrorMessages={seterrorMessages}
                                        lineItemDate={lineItemData} setLineItemData={setLineItemData}
                                        dates={{billedDate,dateOfBitrh}} setInputDates={setInputDates}
                                        errors={{billedDateErr, payTotalChrgErr, payNetAmtErr}}
                                        setsuccessMessages={setSuccessMessages}/>
                                </div>
                                <div id="Replacement/Void Div Id">
                                    <ReplacementVoids
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData}
                                        onSearchParent={handleAdjustment} />
                                </div>
                                <div id="History Div Id">
                                    <History 
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData}
                                        onSearchParent={handleAdjustment}
                                        adTabId={adTabId}
                                        setAdTabId={setAdTabId}
                                        setTabValue={setTabValue} 
                                    />                                   
                                </div>
                                <div className="pos-relative">
                                    <div className="tabs-container custom-panel">
                                        <div className='tab-holder CustomExpansion-panel my-3'>
                                            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                                <ExpansionPanelSummary
                                                    expandIcon={<ExpandMoreIcon />}
                                                    aria-controls="tpl-summary"
                                                    id="expansion-panel-tpl-summary">
                                                    <Typography className={classes.heading}> Additional Details</Typography>
                                                </ExpansionPanelSummary>
                                                <ExpansionPanelDetails>
                                                    <div id="Attachments Div Id">
                                                        <AttachmentsComponent attachmentSeqNum={attachmentSeqNum} setAttachmentSeqNum={setAttachmentSeqNum} values={{"attachment":claimEntryData?claimEntryData.claimAttachment?claimEntryData.claimAttachment:[]:[]}} setValues={setAttachmentsValues} seterrorMessages={seterrorMessages} usedFor="additionalDetails"/>
                                                    </div>
                                                    <div id="Override Exception Div Id">
                                                        <OverrideException data={claimEntryData} setClaimEntryData={setClaimEntryData} seterrorMessages={seterrorMessages} claimType="correction"/>
                                                    </div>
                                                    <div id="Additional Remarks Div Id">
                                                        <AdditionalRemarksComponent values={{"additionalRemark":claimEntryData?claimEntryData.additionalRemark?claimEntryData.additionalRemark:[]:[]}} setValues={setAdditionalRemarksValues} seterrorMessages={seterrorMessages} />
                                                    </div>
                                                    <div id="Manual Eobs Div Id">
                                                        <ManualEobsComponent values={{"manualEOB":claimEntryData?claimEntryData.manualEOB?claimEntryData.manualEOB:[]:[]}} setValues={setManualEobsValues} seterrorMessages={seterrorMessages} />
                                                    </div>
                                                </ExpansionPanelDetails>
                                            </ExpansionPanel >
                                        </div>
                                    </div>
                                </div>
                            </TabPanel>
                            <TabPanel value={tabValue} index={1}><BasicClaimInfo data={claimEntryData}  setClaimEntryData={setClaimEntryData} /></TabPanel>
                            <TabPanel value={tabValue} index={2}>{""}</TabPanel>
                            <TabPanel value={tabValue} index={2}><ClaimsOtherInfo  data={claimEntryData} /></TabPanel>
                            <TabPanel value={tabValue} index={3}><OtherServiceInfo data={claimEntryData}  setClaimEntryData={setClaimEntryData} /></TabPanel>
                        </div>
                    </div>
                </div>
                <div className="clm-inquiry-exceptionData pull-left mb-3 sticky-block">
                    <ExceptionView value = {claimEntryData} setClaimEntryData={setClaimEntryData} updateException={updateException} correctClaim= {() => correctClaim("ONLINE_VALIDATE")}/>
                    {/* <div className="clm-inquiry-exceptionData pull-left"> */}
                    {showQuickLink ? (
                    <QuickLinks links={quickLinks} enableExpand={true} />
                    ) : null }
                    {/* </div> */}
                    <div className="clearfix"></div>
                </div>
                <div className="clearfix"></div>
            </div>
        </div>
    );

}

export default ClaimCorrectionDetails;