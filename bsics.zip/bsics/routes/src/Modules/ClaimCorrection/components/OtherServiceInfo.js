import React, { useState, Fragment } from "react"
//import React, { useState, useEffect } from 'react';
import { ExpansionPanel, ExpansionPanelSummary, Typography, ExpansionPanelDetails, TextField } from "@material-ui/core";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { makeStyles } from "@material-ui/core/styles";
import { Button } from 'react-bootstrap';
import TableComponent from './../../../SharedModules/Table/Table';
import { RadioGroup } from '@material-ui/core';
import { FormControlLabel } from '@material-ui/core';
import { Radio } from '@material-ui/core';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import InputAdornment from '@material-ui/core/InputAdornment';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import MenuItem from '@material-ui/core/MenuItem';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

const editRow = row => (event) => {
    getThemeProps.setOpen(true);
};

function OtherServiceInfo(props) {

    const claimHdr = props.data && props.data.enterpriseClaimAux ? props.data.enterpriseClaimAux : {};
    const mainDataList = claimHdr && claimHdr.c837ClaimHdr ? claimHdr.c837ClaimHdr : {};
    const lineItemOtherServiceList = mainDataList && mainDataList.c837ServiceLineItems ? mainDataList.c837ServiceLineItems : {};
    const enterpriseClaimLineItem = props.data && props.data.enterpriseClaimLineItem ? props.data.enterpriseClaimLineItem : {};
    const providerInformation = mainDataList && mainDataList.c837LineItemProviders ? mainDataList.c837LineItemProviders : {};
    const assistantSurgeonInformation = mainDataList && mainDataList.c837DentalClaims ? mainDataList.c837DentalClaims : {};
    const assistantSurgeonOtherPayers = mainDataList && mainDataList.c837OtherPayers ? mainDataList.c837OtherPayers : {};
    const [lineItemNum, setLineItemNum] = useState(0);

    const data = lineItemOtherServiceList[lineItemNum] ? lineItemOtherServiceList[lineItemNum] : {};
    const enterpriseClaimLineItemData = enterpriseClaimLineItem[lineItemNum] ? enterpriseClaimLineItem[lineItemNum]: {};
    const providerInformationData = providerInformation[lineItemNum] ? providerInformation[lineItemNum] : {};
    const assistantSurgeonInformationData = assistantSurgeonInformation[lineItemNum] ? assistantSurgeonInformation[lineItemNum] : {};
    const assistantSurgeonOtherPayerList = assistantSurgeonOtherPayers[lineItemNum] ? assistantSurgeonOtherPayers[lineItemNum] : {};

    const previousLineItem = () => {
        if (lineItemNum == 0) {
            return false;
        }
        setLineItemNum(lineItemNum - 1);
    };
    const nextLineItem = () => {
        if (lineItemNum == Object.keys(lineItemOtherServiceList).length - 1) {
            return false;
        }
        setLineItemNum(lineItemNum + 1);
    };
    const classes = useStyles();
    const miscellaneousLineInfoVO = data && data ? data : {};
    const fileInformationVO = data && data.fileFormatInfo ? data.fileFormatInfo : {};
    const repricedClaimVO = data && data.repricedClaimInfo ? data.repricedClaimInfo : {};
    const enterpriseClaimLineItemInfo= enterpriseClaimLineItemData && enterpriseClaimLineItemData.professionalLineItem ? enterpriseClaimLineItemData.professionalLineItem : {}
    const renderingProviderInfo = providerInformationData && providerInformationData.renderingProvider ? providerInformationData.renderingProvider : {};
    const renderingProviderSecIds = props.data && props.data.claimProviderID ? props.data.claimProviderID :[];
    const providerName = renderingProviderInfo && renderingProviderInfo.providerName ? renderingProviderInfo.providerName : {};
    const serviceFacilityInformation = providerInformationData && providerInformationData.serviceFacility ? providerInformationData.serviceFacility : {};
    const serviceFacilityInfo = serviceFacilityInformation && serviceFacilityInformation.serviceFacilityName ? serviceFacilityInformation.serviceFacilityName :{};
    const assistantSurgeonLineItem = assistantSurgeonInformationData && assistantSurgeonInformationData.c837DentalLineItems ? assistantSurgeonInformationData.c837DentalLineItems[0] : [];
    const assistantSurgeonInformationList = assistantSurgeonLineItem && assistantSurgeonLineItem.assistantSurgeonInfo ? assistantSurgeonLineItem.assistantSurgeonInfo : {};
    const assistantSurgeonInfo = assistantSurgeonInformationList && assistantSurgeonInformationList.assistantSurgeonName ? assistantSurgeonInformationList.assistantSurgeonName:{};
    const payerDeterminationInfo = assistantSurgeonLineItem && assistantSurgeonLineItem.predeterminationBenefits ? assistantSurgeonLineItem.predeterminationBenefits: {};
    const additionalSupervisingInfo = providerInformationData && providerInformationData.supervisingProvider ? providerInformationData.supervisingProvider.providerName: {};
    const assistantSurgeonSecIds = assistantSurgeonOtherPayerList && assistantSurgeonOtherPayerList.otherPayerSubmittedProviderIDs ? assistantSurgeonOtherPayerList.otherPayerSubmittedProviderIDs : [];
    
    const [showViewOtherPayer,setShowViewOtherPayer] = useState(false);
    const serviceLineAdjustment = props.data && props.data.claimAdjustmentReasons ? props.data.claimAdjustmentReasons : [];
    const otherSrvInfoOtherPayerRenderingInfo = mainDataList && mainDataList.c837OtherPayerAdjustments ? mainDataList.c837OtherPayerAdjustments: [];
    const otherSrvInfoOtherPayerSrvAuthInfoList = providerInformationData && providerInformationData.otherPayer1 ? providerInformationData.otherPayer1: {};
    
    const otherSrvInfoOtherPayerSrvAuthInfo = [];
    const otherSrvInfoOtherPayerSrvAuthInfoA = otherSrvInfoOtherPayerSrvAuthInfoList && otherSrvInfoOtherPayerSrvAuthInfoList.priorAuthorizationInfoA ? otherSrvInfoOtherPayerSrvAuthInfoList.priorAuthorizationInfoA : {};
    const otherSrvInfoOtherPayerSrvAuthInfoB = otherSrvInfoOtherPayerSrvAuthInfoList && otherSrvInfoOtherPayerSrvAuthInfoList.priorAuthorizationInfoB ? otherSrvInfoOtherPayerSrvAuthInfoList.priorAuthorizationInfoB : {};
    
    otherSrvInfoOtherPayerSrvAuthInfo.push(otherSrvInfoOtherPayerSrvAuthInfoA);
    otherSrvInfoOtherPayerSrvAuthInfo.push (otherSrvInfoOtherPayerSrvAuthInfoB);

    const otherSrvInfoOtherPayerSrvAuthIds = Object.keys(otherSrvInfoOtherPayerSrvAuthInfoA ).length ? [otherSrvInfoOtherPayerSrvAuthInfoA ] : [];
    
    const [LLAData,setLLAData] = useState({});
    const [showLLA,setShowLLA] = useState(false);
    const[serviceLine, setServiceLine] = useState({});

    const SecIDs = [
        {
            id: 'providerIDType', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12
        }
    ];

    const serviceLineAdjustmentCells = [
        { id: "adjustmentGroupCode", numeric: false, disablePadding: true, label: 'Claim Adjustment Group Code', enableHyperLink: true, fontSize: 12 },
        { id: "adjustmentReasonCode", numeric: false, disablePadding: false, label: 'Reason Code', enableHyperLink: false, fontSize: 12 },
        { id: "adjustmentReasonAmount", numeric: false, disablePadding: false, label: 'Amount', enableHyperLink: false, isBalance: true, fontSize: 12 },
        { id: "adjustmentUnitQuantity", numeric: false, disablePadding: false, label: 'Quantity', enableHyperLink: false, fontSize: 12 }

    ]

    const otherpayerheadCells = [
        { id: "tplSequenceNumber" , numeric: false, disablePadding: true, label: 'Sequence Number', enableHyperLink: true, fontSize: 12},
        { id: "otherPayerID" , numeric: false, disablePadding: true, label: 'Other Payer Primary ID', enableHyperLink: false, fontSize: 12},
        { id: "serviceCode" , numeric: false, disablePadding: true, label: 'Procedure Code', enableHyperLink: false, fontSize: 12},
        { id: "paidUnitCount" , numeric: false, disablePadding: true, label: 'Paid Service Unit Count', enableHyperLink: false, fontSize: 12},
        { id: "otherPayerPaidAmount" , numeric: false, disablePadding: true, label: 'Service Line Paid Amount', enableHyperLink: false, fontSize: 12},
        { id: "otherPayerPaidDate" , numeric: false, disablePadding: true, label: 'Adjudicated or Pay Date', enableHyperLink: false, isDate:true, fontSize: 12}
       ]

       const OtherPayerServiceHeadCells = [
        {
            id: 'priorAuthQualifierCode', numeric: false, disablePadding: false, label: 'Number Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'priorAuthID', numeric: false, disablePadding: false, label: 'SA or Referral Number', enableHyperLink: false, fontSize: 12
        }
        
    ];
    const viewOtherInfo = row => (event) => { 
        setShowViewOtherPayer(true);
        setServiceLine(row);
    };

    const viewLLA = row => (event) => {
        setLLAData(row);
        setShowLLA(true);
    };

    return (
        <Fragment>

            <div className='tabs-container my-3'>
                <div className='tab-header'>
                <h1 className="tab-heading float-left">Line # {miscellaneousLineInfoVO.lineNumber}</h1>

                    <div className="float-right th-btnGroup">
                        <Button id="previous_button" title="Previous" variant="outlined" color="primary" className="btn btn-primary" onClick={previousLineItem} >
                            <i className="fa fa-arrow-left" />
                            Previous
                </Button>
                        <Button title="Next" variant="outlined" color="primary" className="btn btn-primary" onClick={nextLineItem}>
                            Next
                    <i className="fa fa-arrow-right ml-1" />
                        </Button>
                    </div>
                </div>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3' id="Service Line Information Div Id">
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content1"
                        id="panelp1a-header1">
                        <Typography className={classes.heading} >Service Line Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Miscellaneous Line Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="form-wrapper wrap-form-label px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Repriced_Claim_Number"
                                            label="Repriced Claim Number"
                                            placeholder=""
                                            data-test='repriced-claim-number'
                                            value={
                                                miscellaneousLineInfoVO.repriceReferenceNumber ? miscellaneousLineInfoVO.repriceReferenceNumber : ""
                                            }
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Adjusted_Repriced_Claim_Number"
                                            label="Adjusted Repriced Claim Number"
                                            placeholder=""
                                            data-test='adjusted-repriced-claim-number'
                                            value={
                                                miscellaneousLineInfoVO.adjustedRepriceReferenceNumber ? miscellaneousLineInfoVO.adjustedRepriceReferenceNumber : ""
                                            }
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Predetermination_BenefitID_Number"
                                            label="Predetermination Benefit ID Number"
                                            placeholder=""
                                            data-test='predetermination-benefit-id-number'
                                            value={
                                                payerDeterminationInfo.benefitsID1 ? payerDeterminationInfo.benefitsID1 : ""
                                            }
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Procedure_Description"
                                            label="Procedure Description"
                                            placeholder=""
                                            data-test='procedureCodeDescription'
                                            value={
                                                miscellaneousLineInfoVO.procedureCodeDescription ? miscellaneousLineInfoVO.procedureCodeDescription : ""
                                            }
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Contract Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract_Type_Code"
                                            label="Contract Type Code"
                                            placeholder=""
                                            data-test='contractTypeCode'
                                            value={miscellaneousLineInfoVO.contractTypeCode ? miscellaneousLineInfoVO.contractTypeCode : ""}
                                            multiline
                                            rows="4"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract_Amount"
                                            label="Contract Amount"
                                            placeholder=""
                                            data-test='contractAmount'
                                            value={miscellaneousLineInfoVO.contractAmount ? miscellaneousLineInfoVO.contractAmount : ""}
                                            InputLabelProps={{ shrink: true }}
                                            InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment>, }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract_Percent"
                                            label="Contract Percent"
                                            placeholder=""
                                            data-test='contractPercentage'
                                            value={miscellaneousLineInfoVO.contractPercentage ? miscellaneousLineInfoVO.contractPercentage : ""}
                                            InputLabelProps={{ shrink: true }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract_Code"
                                            label="Contract Code"
                                            placeholder=""
                                            data-test='contractCode'
                                            value={miscellaneousLineInfoVO.contractCode ? miscellaneousLineInfoVO.contractCode : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Terms_Discount_Percent"
                                            label="Terms Discount Percent"
                                            placeholder=""
                                            data-test='contractDiscountPercentage'
                                            value={miscellaneousLineInfoVO.contractDiscountPercentage ? miscellaneousLineInfoVO.contractDiscountPercentage : ""}
                                            InputLabelProps={{ shrink: true }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract_VersionID"
                                            label="Contract Version ID"
                                            placeholder=""
                                            data-test='contractVersionID'
                                            value={miscellaneousLineInfoVO.contractVersionID ? miscellaneousLineInfoVO.contractVersionID : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>File Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information1"
                                            label="File Information 1"
                                            placeholder=""
                                            data-test='fileInformation1'
                                            value={fileInformationVO.fileInformation1 ? fileInformationVO.fileInformation1 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information2"
                                            label="File Information 2"
                                            placeholder=""
                                            data-test='fileInformation2'
                                            value={fileInformationVO.fileInformation2 ? fileInformationVO.fileInformation2 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information3"
                                            label="File Information 3"
                                            placeholder=""
                                            data-test='fileInformation3'
                                            value={fileInformationVO.fileInformation3 ? fileInformationVO.fileInformation3 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information4"
                                            label="File Information 4"
                                            placeholder=""
                                            data-test='fileInformation4'
                                            value={fileInformationVO.fileInformation4 ? fileInformationVO.fileInformation4 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information5"
                                            label="File Information 5"
                                            placeholder=""
                                            data-test='fileInformation5'
                                            value={fileInformationVO.fileInformation5 ? fileInformationVO.fileInformation5 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information6"
                                            label="File Information 6"
                                            placeholder=""
                                            data-test='fileInformation6'
                                            value={fileInformationVO.fileInformation6 ? fileInformationVO.fileInformation6 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information7"
                                            label="File Information 7"
                                            placeholder=""
                                            data-test='fileInformation7'
                                            value={fileInformationVO.fileInformation7 ? fileInformationVO.fileInformation7 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information8"
                                            label="File Information 8"
                                            placeholder=""
                                            data-test='fileInformation8'
                                            value={fileInformationVO.fileInformation8 ? fileInformationVO.fileInformation8 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information9"
                                            label="File Information 9"
                                            placeholder=""
                                            data-test='fileInformation9'
                                            value={fileInformationVO.fileInformation9 ? fileInformationVO.fileInformation9 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File_Information10"
                                            label="File Information 10"
                                            placeholder=""
                                            data-test='fileInformation10'
                                            value={fileInformationVO.fileInformation10 ? fileInformationVO.fileInformation10 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Claim Pricing/Repricing</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="form-wrapper wrap-form-label px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Pricing Methodology Code"
                                            label="Pricing Methodology Code"
                                            placeholder=""
                                            data-test='methodologyCode'
                                            value={repricedClaimVO.methodologyCode ? repricedClaimVO.methodologyCode : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Allowed Amount"
                                            label="Allowed Amount"
                                            placeholder=""
                                            data-test='repriceAllowedAmount'
                                            value={repricedClaimVO.repriceAllowedAmount ? repricedClaimVO.repriceAllowedAmount : ""}
                                            InputLabelProps={{ shrink: true }}
                                            InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment>, }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Saving Amount"
                                            label="Savings Amount"
                                            placeholder=""
                                            data-test='savingsAmount'
                                            value={repricedClaimVO.savingsAmount ? repricedClaimVO.savingsAmount : ""}
                                            InputLabelProps={{ shrink: true }}
                                            InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment>, }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Organization Identifier"
                                            label="Organization Identifier"
                                            placeholder=""
                                            data-test='organizationID'
                                            value={repricedClaimVO.organizationID ? repricedClaimVO.organizationID : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Per Diem or Flat Rate Amount"
                                            label="Per Diem or Flat Rate Amount"
                                            placeholder=""
                                            data-test='repricePerDiemRate'
                                            value={repricedClaimVO.repricePerDiemRate ? repricedClaimVO.repricePerDiemRate : ""}
                                            InputLabelProps={{ shrink: true }}
                                            InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment>, }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="HCPCS_Code"
                                            label="HCPCS Code"
                                            placeholder=""
                                            data-test='serviceCode'
                                            value={repricedClaimVO.serviceCode ? repricedClaimVO.serviceCode : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved_ServiceUnits_Count"
                                            label="Approved Service Units Count"
                                            placeholder=""
                                            data-test='unitQuantity'
                                            value={repricedClaimVO.unitQuantity ? repricedClaimVO.unitQuantity : ""}
                                            InputLabelProps={{ shrink: true }}
                                            InputProps={{ startAdornment: <InputAdornment position="start">$</InputAdornment>, }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="rejectReasonCode"
                                            label="Rejection Reason Code"
                                            placeholder=""
                                            data-test='rejectReasonCode'
                                            value={repricedClaimVO.rejectReasonCode ? repricedClaimVO.rejectReasonCode : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="policyComplianceCode"
                                            label="Policy Complaince Code"
                                            placeholder=""
                                            data-test='policyComplianceCode'
                                            value={repricedClaimVO.policyComplianceCode ? repricedClaimVO.policyComplianceCode : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Exception Code"
                                            label="Exception Code"
                                            placeholder=""
                                            data-test='exceptionCode'
                                            value={repricedClaimVO.exceptionCode ? repricedClaimVO.exceptionCode : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Diagnosis Pointers</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="Diagnosis_Pointer1"
                                            label="Diagnosis Pointer1"
                                            placeholder=""
                                            data-test='relatedDiagnosisPointer1'
                                            value={enterpriseClaimLineItemInfo.relatedDiagnosisPointer1 ? enterpriseClaimLineItemInfo.relatedDiagnosisPointer1 : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="Diagnosis_Pointer2"
                                            label="Diagnosis Pointer2"
                                            placeholder=""
                                            data-test='relatedDiagnosisPointer2'
                                            value={enterpriseClaimLineItemInfo.relatedDiagnosisPointer2 ? enterpriseClaimLineItemInfo.relatedDiagnosisPointer2 : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="Diagnosis_Pointer3"
                                            label="Diagnosis Pointer3"
                                            placeholder=""
                                            data-test='relatedDiagnosisPointer3'
                                            value={enterpriseClaimLineItemInfo.relatedDiagnosisPointer3 ? enterpriseClaimLineItemInfo.relatedDiagnosisPointer3 : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="Diagnosis_Pointer4"
                                            label="Diagnosis Pointer4"
                                            placeholder=""
                                            data-test='relatedDiagnosisPointer4'
                                            value={enterpriseClaimLineItemInfo.relatedDiagnosisPointer4 ? enterpriseClaimLineItemInfo.relatedDiagnosisPointer4 : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>
            <div className='tab-holder CustomExpansion-panel my-3' id="Service Line Provider Information Div Id">

                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography className={classes.heading}>Service Line Provider Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        {/* Rendering Provider */}
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Rendering Provider Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="tabs-container">
                                    <div className="set-form-wrapper">
                                    <div className="form-wrapper py-0">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Entity_Qualifier"
                                                label="Entity Qualifier"
                                                placeholder=""
                                                data-test='entityTypeCode'
                                                value={renderingProviderInfo.entityTypeCode ? renderingProviderInfo.entityTypeCode : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper pt-1">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="lastName"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='lastName'
                                                value={providerName.lastName ? providerName.lastName : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="firstName"
                                                label="First Name"
                                                placeholder=""
                                                data-test='firstName'
                                                value={providerName.firstName ? providerName.firstName : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mi"
                                                label="MI"
                                                placeholder=""
                                                data-test='middleName'
                                                value={providerName.middleName ? providerName.middleName : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="suffix"
                                                label="Suffix"
                                                placeholder=""
                                                data-test='suffixName'
                                                value={providerName.suffixName ? providerName.suffixName : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                    </div>

                                    </div>
                                </div>
                                <div className="custom-hr">&nbsp;</div>
                                <div className="tabs-container px-1">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={SecIDs} tableData={renderingProviderSecIds} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />

                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        {/* Service Facility Information */}
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Service Facility Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="tabs-container">
                                    <div className="set-form-wrapper">
                                    <div className="form-wrapper py-0">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="lastName"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='facilitylastName'
                                                value={serviceFacilityInfo.lastName ? serviceFacilityInfo.lastName : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md w-100">
                                            <TextField
                                                disabled
                                                id="Address1"
                                                label="Address 1"
                                                placeholder=""
                                                data-test='facilityAddressLine1'
                                                value={serviceFacilityInformation.addressLine1 ? serviceFacilityInformation.addressLine1 : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md w-100">
                                            <TextField
                                                disabled
                                                id="Address2"
                                                label="Address 2"
                                                placeholder=""
                                                data-test='facilityAddressLine2'
                                                value={serviceFacilityInformation.addressLine2 ? serviceFacilityInformation.addressLine2 : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="City"
                                                label="City"
                                                placeholder=""
                                                data-test='facilityCityName'
                                                value={serviceFacilityInformation.cityName ? serviceFacilityInformation.cityName : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="State"
                                                label="State"
                                                placeholder=""
                                                data-test='facilityStateCode'
                                                value={serviceFacilityInformation.stateCode ? serviceFacilityInformation.stateCode : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="custom-form-wrapp-inner flex-inner p-0">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Zip_and_Extension"
                                                label="Zip & Extension"
                                                placeholder=""
                                                data-test='facilityZipCode'
                                                value={serviceFacilityInformation.zipCode ? serviceFacilityInformation.zipCode.toString().substring(0,5) : ''}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Zip_and_Extension"
                                                label=""
                                                placeholder=""
                                                data-test='facilityZipCodeExt'
                                                value={serviceFacilityInformation.zipCode ? serviceFacilityInformation.zipCode.toString().substring(5) : ''}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Country"
                                                label="Country"
                                                placeholder=""
                                                data-test='facilityCountryCode'
                                                value={serviceFacilityInformation.countryCode ? serviceFacilityInformation.countryCode : ""}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                    </div>
                                    <div className="custom-hr">&nbsp;</div>
                                    <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Subdivision_Code"
                                            label="Subdivision Code"
                                            placeholder=""
                                            data-test='facilitySubDivisionCode'
                                            value={serviceFacilityInformation.countrySubDivisionCode ? serviceFacilityInformation.countrySubDivisionCode : ""}
                                            InputLabelProps={{ shrink: true }}
                                        />
                                    </div>
                                    </div>
                                    </div>
                                </div>

                                <div className="tabs-container px-1">
                                    <div className="tab-header pt-0">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={SecIDs} tableData={renderingProviderSecIds} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />

                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        {/* Assistant Surgeon Information */}
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Assistant Surgeon Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="tabs-container">
                                    <div className="set-form-wrapper">
                                    <div className="form-wrapper pt-0">
                                        <div className="mui-custom-form input-md field-md md-field-lg">
                                            <TextField
                                                disabled
                                                id="orgName"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='assistantLastName'
                                                value={assistantSurgeonInfo.lastName ? assistantSurgeonInfo.lastName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 35 }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-md md-field-lg">
                                            <TextField
                                                disabled
                                                id="firstName"
                                                label="First Name"
                                                placeholder=""
                                                data-test='assistantFirstName'
                                                value={assistantSurgeonInfo.firstName ? assistantSurgeonInfo.firstName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 25 }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-md md-field-lg">
                                            <TextField
                                                disabled
                                                id="mi"
                                                label="MI"
                                                placeholder=""
                                                data-test='assistantMiddleName'
                                                value={assistantSurgeonInfo.middleName ? assistantSurgeonInfo.middleName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 25 }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="suffix"
                                                label="Suffix"
                                                placeholder=""
                                                data-test='assistantSuffixName'
                                                value={assistantSurgeonInfo.suffixName ? assistantSurgeonInfo.suffixName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 10 }}
                                            />
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                <div className="custom-hr mt-1">&nbsp;</div>

                                <div className="tabs-container px-2">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={SecIDs} tableData={assistantSurgeonSecIds} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />

                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        {/* Additional Supervising Provider */}
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Supervising Provider</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="tabs-container">
                                    <div className="set-form-wrapper">
                                    <div className="form-wrapper pt-1">
                                        <div className="mui-custom-form input-md field-lg md-field-xl">
                                            <TextField
                                                disabled
                                                id="standrad-description"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='supervisingLastName'
                                                value={additionalSupervisingInfo.lastName ? additionalSupervisingInfo.lastName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 60 }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-md md-field-lg">
                                            <TextField
                                                disabled
                                                id="firstName"
                                                label="First Name"
                                                placeholder=""
                                                data-test='supervisingFirstName'
                                                value={additionalSupervisingInfo.firstName ? additionalSupervisingInfo.firstName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 35 }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-md md-field-lg">
                                            <TextField
                                                disabled
                                                id="mi"
                                                label="MI"
                                                placeholder=""
                                                data-test='supervisingMiddleName'
                                                value={additionalSupervisingInfo.middleName ? additionalSupervisingInfo.middleName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 25 }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="suffix"
                                                label="Suffix"
                                                placeholder=""
                                                data-test='supervisingSuffixName'
                                                value={additionalSupervisingInfo.suffixName ? additionalSupervisingInfo.suffixName : ""}
                                                InputLabelProps={{ shrink: true }}
                                                inputProps={{ maxLength: 10 }}
                                            />
                                        </div>
                                    </div>
                                    </div>
                                </div>
                                <div className="custom-hr">&nbsp;</div>
                                <div className="tabs-container px-1">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent id="table" headCells={SecIDs} tableData={assistantSurgeonSecIds} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />

                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>
            {/* Other Payer Serivce Line Provider Information */}
            <div className='tab-holder CustomExpansion-panel my-3' id="Other Payer Service Line Provider Information Div Id">
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                    >
                        <Typography className={classes.heading} >Other Payer Serivce Line Provider Information</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails className="clear-block">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Other Payer Service Information </h2>
                            </div>
                        <div className="mt-1">
                            <TableComponent headCells={otherpayerheadCells} tableData={otherSrvInfoOtherPayerRenderingInfo} onTableRowClick={viewOtherInfo} defaultSortColumn="tplSeqNum" />
                        </div>
                        {showViewOtherPayer || props.showViewOtherPayer ? (
                                <div className="tabs-container mt-3">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left">
                                          View Other Payer Service Information
                                        </h2>
                                        <div className="float-right th-btnGroup">                                           
                                            <Button id="cancel" title="Cancel" variant="outlined" color="primary" className="btn btn-primary" onClick={() => { setShowViewOtherPayer(false);}}>
                                                Cancel
                                            </Button>
                                        </div>
                                    </div>
                            
                    
               
                     
                    <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography className={classes.heading}>Service Line Adjudication</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                            <div className="form-wrapper wrap-form-label">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Sequence Number"
                                            label="Sequence Number"
                                            placeholder=""
                                            data-test='tplSequenceNumber'
                                            value={serviceLine.tplSequenceNumber ? serviceLine.tplSequenceNumber : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                           
                                    />
                                </div>
                                <div className="mui-custom-form input-md field-xl">
                                    <TextField
                                            disabled
                                            id="Other Payer Primary ID"
                                            label="Other Payer Primary ID"
                                            placeholder=""
                                            data-test='otherPayerID'
                                            value={serviceLine.otherPayerID ? serviceLine.otherPayerID : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                            inputProps={{ maxLength: 80 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Service Line Payed amount"
                                            label="Service Line Payed Amount"
                                            placeholder=""
                                            data-test='otherPayerPaidAmount'
                                            value={serviceLine.otherPayerPaidAmount ? serviceLine.otherPayerPaidAmount : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}              
                                    />
                                </div>
                                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Date Last Seen"
                                                label="Adjudicated or Pay Date"
                                                format="MM/dd/yyyy"
                                                data-test='otherPayerPaidDate'
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={serviceLine.otherPayerPaidDate ? serviceLine.otherPayerPaidDate : ""}

                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                </MuiPickersUtilsProvider>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Payed Service unit Count"
                                            label="Payed Service Unit Count"
                                            placeholder=""
                                            data-test='paidUnitCount'
                                            value={serviceLine.paidUnitCount ? serviceLine.paidUnitCount : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                            
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Procedure Qualifier"
                                            label="Procedure Qualifier"
                                            placeholder=""
                                            data-test='serviceQualifierCode'
                                            value={serviceLine.serviceQualifierCode ? serviceLine.serviceQualifierCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                            
                                    />
                                </div>
                                <div className="mui-custom-form input-md field-lg md-field-xl">
                                    <TextField
                                            disabled
                                            id="Procedure Code"
                                            label="Procedure Code"
                                            placeholder=""
                                            data-test='serviceCodeServiceLine'
                                            value={serviceLine.serviceCode ? serviceLine.serviceCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                            
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Procedure Code Description"
                                            label="Procedure Code Description"
                                            placeholder=""
                                            data-test='serviceDescription'
                                            value={serviceLine.serviceDescription ? serviceLine.serviceDescription : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                            inputProps={{ maxLength: 48 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Bundled Line Number"
                                            label="Bundled Line Number"
                                            placeholder=""
                                            data-test='bundlingLineNumber'
                                            value={serviceLine.bundlingLineNumber ? serviceLine.bundlingLineNumber : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                           
                                    />
                                </div>
                            </div>
                                <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                label="Procedure Code Modifiers"
                                                placeholder=""
                                                data-test='procedureModifier1'
                                                value={serviceLine.procedureModifier1 ? serviceLine.procedureModifier1 : ""}
                                                InputLabelProps={{ shrink: true }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">1</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                label=""
                                                placeholder=""
                                                data-test='procedureModifier2'
                                                value={serviceLine.procedureModifier2 ? serviceLine.procedureModifier2 : ""}
                                                InputLabelProps={{ shrink: true }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">2</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                label=""
                                                placeholder=""
                                                data-test='procedureModifier3'
                                                value={serviceLine.procedureModifier3 ? serviceLine.procedureModifier3 : ""}
                                                InputLabelProps={{ shrink: true }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">3</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                label=""
                                                placeholder=""
                                                data-test='procedureModifier4'
                                                value={serviceLine.procedureModifier4 ? serviceLine.procedureModifier4 : ""}
                                                InputLabelProps={{ shrink: true }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">4</InputAdornment>,
                                                }}
                                            />
                                        </div>

                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="revenue Code111"
                                            label="Remaining Patient Liability"
                                            placeholder=""
                                            data-test='remainingPatientLiabilityAmount'
                                            value={serviceLine.remainingPatientLiabilityAmount ? serviceLine.remainingPatientLiabilityAmount : "" }
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                             InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}
                                            
                                    />
                                </div>
                            </div>
                           
                           
                    <ExpansionPanel className="collapsable-panel mt-3">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Service Adjustment</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block">                                                      
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left"> Line Level Adjustments </h2>
                                        <TableComponent headCells={serviceLineAdjustmentCells}  tableData={serviceLineAdjustment} onTableRowClick={viewLLA} defaultSortColumn="IDType"  />  
                                        {showLLA || props.showLLA?
                                        <div className="tabs-container">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left">
                                            View Line Level Adjustments
                                            </h2>
                                            <div className="float-right th-btnGroup">                                           
                                                <Button id="cancel_line" title="Cancel" variant="outlined" color="primary" className="btn btn-primary" onClick={() => { setShowLLA(false);}}>
                                                    Cancel
                                                </Button>
                                            </div>
                                        </div>
                                        <div className="form-wrapper form-3-column">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    select
                                                    id="adjustmentGroupCode"
                                                    label="Claim Adjustment Group Code"
                                                    placeholder=""
                                                    data-test="adjustmentGroupCode"
                                                    value={LLAData.adjustmentGroupCode ? LLAData.adjustmentGroupCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                        required: true
                                                    }}
                                                />
                                               <MenuItem key="09" value="09">ICD-09</MenuItem> 
                                            </div>
                                        </div>
                                        <div className="form-wrapper form-3-column">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="reasonCode"
                                                    label="Reason Code"
                                                    placeholder=""
                                                    data-test="reasonCode"
                                                    value={LLAData.sequenceNumber === 1 && LLAData.adjustmentReasonCode ? LLAData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                        required: true
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="amount"
                                                    label="Amount"
                                                    placeholder=""
                                                    data-test="reasonAmount"
                                                    value={LLAData.sequenceNumber === 1 && LLAData.adjustmentReasonAmount ? LLAData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                        required: true
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>                                                                                   
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="quantity"
                                                    label="Quantity"
                                                    placeholder=""
                                                    data-test="quantity"
                                                    value={LLAData.sequenceNumber === 1 && LLAData.adjustmentUnitQuantity ? LLAData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="reasonCode2"
                                                    label="Reason Code 2"
                                                    placeholder=""
                                                    data-test="reasonCode2"
                                                    value={LLAData.sequenceNumber === 2 && LLAData.adjustmentReasonCode ? LLAData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="othe3srf3srseermi"
                                                    label="Amount 2"
                                                    placeholder=""
                                                    data-test="othe3srf3srseermi"
                                                    value={ LLAData.sequenceNumber === 2 && LLAData.adjustmentReasonAmount ? LLAData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="quantity2"
                                                    label="Quantity 2"
                                                    placeholder=""
                                                    data-test="quantity2"
                                                    value={LLAData.sequenceNumber === 2 && LLAData.adjustmentUnitQuantity ? LLAData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="reasonCode3"
                                                    label="Reason Code 3"
                                                    placeholder=""
                                                    data-test="reasonCode3"
                                                    value={LLAData.sequenceNumber === 3 && LLAData.adjustmentReasonCode ? LLAData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="othe3srf3srseermi"
                                                    label="Amount 3"
                                                    placeholder=""
                                                    value={ LLAData.sequenceNumber === 3 && LLAData.adjustmentReasonAmount ? LLAData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="quantity3"
                                                    label="Quantity 3"
                                                    placeholder=""
                                                    value={LLAData.sequenceNumber === 3 && LLAData.adjustmentUnitQuantity ? LLAData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="reasonCode4"
                                                    label="Reason Code 4"
                                                    placeholder=""
                                                    value={LLAData.sequenceNumber === 4 && LLAData.adjustmentReasonCode ? LLAData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="amount4"
                                                    label="Amount 4"
                                                    placeholder=""
                                                    value={ LLAData.sequenceNumber === 4 && LLAData.adjustmentReasonAmount ? LLAData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="dgftr4rf5fg"
                                                    label="Quantity 4"
                                                    placeholder=""
                                                    value={LLAData.sequenceNumber === 4  && LLAData.adjustmentUnitQuantity ? LLAData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="ffesd4fgf"
                                                    label="Reason Code 5"
                                                    placeholder=""
                                                    value={LLAData.sequenceNumber === 5 && LLAData.adjustmentReasonCode ? LLAData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="amount5"
                                                    label="Amount 5"
                                                    placeholder=""
                                                    value={ LLAData.sequenceNumber === 5 && LLAData.adjustmentReasonAmount ? LLAData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="quantity5"
                                                    label="Quantity 5"
                                                    placeholder=""
                                                    value={LLAData.sequenceNumber === 5 && LLAData.adjustmentUnitQuantity ? LLAData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="reasonCode6"
                                                    label="Reason Code 6"
                                                    placeholder=""
                                                    value={LLAData.sequenceNumber === 6 && LLAData.adjustmentReasonCode ? LLAData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="othe3srf3srseermi"
                                                    label="Amount 6"
                                                    placeholder=""
                                                    value={ LLAData.sequenceNumber === 6 && LLAData.adjustmentReasonAmount ? LLAData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="dgftr4rf5fg"
                                                    label="Quantity 6"
                                                    placeholder=""
                                                    value={LLAData.sequenceNumber === 6 && LLAData.adjustmentUnitQuantity ? LLAData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            

                                        </div>    

                                </div>
                                :null}

                                    </div>
                                    </ExpansionPanelDetails>
                            </ExpansionPanel>
                          </ExpansionPanelDetails>
                    </ExpansionPanel>
                    <ExpansionPanel className="collapsable-panel">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Other Payer Rendering Provider</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block">     
                                    <div className="tab-header pt-1 mb-1">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                        <TableComponent headCells={SecIDs}  tableData={assistantSurgeonSecIds} onTableRowClick={editRow} defaultSortColumn="IDType"  />    
                            
                          </ExpansionPanelDetails>
                    </ExpansionPanel>
                    <ExpansionPanel className="collapsable-panel">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Other Payer Service Facility Information</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block">     
                                    <div className="tab-header pt-1 mb-1">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                        <TableComponent headCells={SecIDs}  tableData={assistantSurgeonSecIds} onTableRowClick={editRow} defaultSortColumn="IDType"  />                                                                
                            
                          </ExpansionPanelDetails>
                    </ExpansionPanel>
                    <ExpansionPanel className="collapsable-panel">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Other Payer Assistant Surgeon  Provider</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block">     
                                    <div className="tab-header pt-1 mb-1">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={SecIDs}  tableData={assistantSurgeonSecIds} onTableRowClick={editRow} defaultSortColumn="IDType"  />                                                           
                            
                          </ExpansionPanelDetails>
                    </ExpansionPanel>
                    <ExpansionPanel className="collapsable-panel">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Other Payer Supervising Provider Information</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block">     
                                    <div className="tab-header pt-1 mb-1">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={SecIDs}  tableData={assistantSurgeonSecIds} onTableRowClick={editRow} defaultSortColumn="IDType"  />                                                                   
                            
                          </ExpansionPanelDetails>
                    </ExpansionPanel>

                    <ExpansionPanel className="collapsable-panel">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Other Payer Predetermination ID</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block">  
                            <div className="form-wrapper form-3-column">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Predeter Number"
                                            label="Other Payer Predetermination ID Number"
                                            placeholder=""
                                            value={
                                                payerDeterminationInfo.benefitsID1 ? payerDeterminationInfo.benefitsID1 : ""
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                           
                                    />
                                </div>
                            </div>   
                          </ExpansionPanelDetails>
                    </ExpansionPanel>

                    <ExpansionPanel className="collapsable-panel">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Other Payer Service Authorization or Referal number</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block"> 
                            <div className="form-wrapper form-3-column">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Predeter Number"
                                            label=" ID "
                                            placeholder=""
                                            value={
                                                otherSrvInfoOtherPayerSrvAuthInfoList.payerID ? otherSrvInfoOtherPayerSrvAuthInfoList.payerID : ""
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                           
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Predeter Number"
                                            label=" ID Type"
                                            placeholder=""
                                            value={
                                                otherSrvInfoOtherPayerSrvAuthInfoList.payerQualifierCode ? otherSrvInfoOtherPayerSrvAuthInfoList.payerQualifierCode : ""
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                           
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                            disabled
                                            id="Predeter Number"
                                            label=" Org /last name "
                                            placeholder=""
                                            value={
                                                otherSrvInfoOtherPayerSrvAuthInfoList.payerName ? otherSrvInfoOtherPayerSrvAuthInfoList.payerName : ""
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                             }}
                                           
                                    />
                                </div>
                            </div>       
                        <ExpansionPanel className="collapsable-panel mt-3">
                          <ExpansionPanelSummary
                             expandIcon={<ExpandMoreIcon/>}
                             aria-controls = "panel1a-content"
                             id="panel1a-header"
                            >
                             <Typography>Other Payer Service Authorization  or Referal number</Typography>
                          </ExpansionPanelSummary>
                          <ExpansionPanelDetails className="clear-block">     
                                    <div className="py-2">
                                        
                                        <TableComponent headCells={OtherPayerServiceHeadCells}  tableData={otherSrvInfoOtherPayerSrvAuthInfo} onTableRowClick={editRow} defaultSortColumn="IDType"  />                                                            
                                    </div>                                                 
                            
                          </ExpansionPanelDetails>
                    </ExpansionPanel>
                          </ExpansionPanelDetails>
                    </ExpansionPanel>
                
                                 
                            </div>) : null}
                              
                               
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>

</Fragment>
                
    )
}

export default OtherServiceInfo;