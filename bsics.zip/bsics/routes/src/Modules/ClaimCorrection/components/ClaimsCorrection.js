import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import TabPanel from '../../../SharedModules/TabPanel/TabPanel';
import { withRouter } from 'react-router';
import { useDispatch, useSelector } from 'react-redux';
import React, { useState, useEffect } from 'react';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import { Button } from 'react-bootstrap';
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';
import * as ClaimsCorrectionConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import { Link, Route } from 'react-router-dom';
import queryString from 'query-string';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import ClaimsCorrectionTCNSearchForm from './ClaimsCorrectionTCNSearchForm';
import ClaimsCorrectionLocationSearch from './ClaimsCorrectionLocationSearch';
import ClaimsCorrectionAdvanceSearch from './ClaimsCorrectionAdvanceSearch';
import ClaimCorrectionBatchData from './ClaimCorrectionBatchData'
import { resetSearchClaimsCorrection, claimCorrectionTCNSearchAction } from '../actions';
import { claimCorrectionLocationSearchAction, locationDropdownAction } from '../actions';


function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

function ClaimsCorrection(props) {
    let errorMessagesArray = [];
    const [tabValue, setTabValue] = useState(0);
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const dispatch = useDispatch();
    const [showTable, setShowTable] = useState(false);
    const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
    const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
    const onReset = () => dispatch(resetSearchClaimsCorrection());
    const onSearch = searchvalues => { return dispatch(claimCorrectionTCNSearchAction(searchvalues)) };
    const paylod = useSelector(state => state.claimCorrectionSearch.tcnSearchPayload);
    const getClaimCorrection = useSelector(state => state.claimCorrectionSearch.correctionDetailsPayload);
    const MemberLockingPaylod = useSelector(state => state.claimCorrectionSearch.memberLockingPayload);
    const onResetLocation = () => dispatch(resetSearchClaimsCorrection());
    const onSearchLocation = searchvalues => { return dispatch(claimCorrectionLocationSearchAction(searchvalues)) };
    const locationDropdown = () => dispatch(locationDropdownAction());
    const payloadLocation = useSelector(state => state.claimCorrectionSearch.locationSearchPayload);
    const locationDropdownData = useSelector(state => state.serviceSearch.locationPayload);
    
    const [batchDataInfo, setBatchDataInfo] = React.useState([])
    const [locationErrorMessages, setLocationErrorMessages] = React.useState([])
    const [advanceErrorMessages, setAdvanceErrorMessages] = React.useState([])
    const [showNoRecords, setShowNoRecords] = useState(false);
    const [redirect, setRedirect] = useState(false);
    const [successMessages, setSuccessMessages] = useState([]);
    const handleChanges = name => (event) => {
        if (successMessages.length) {           
            setSuccessMessages([]);
        }
        setValues({ ...values, [name]: event.target.value });
    };
    
    useEffect(() => {
        if (props.location.currentTab) {           
            setTabValue(props.location.currentTab)
        }else{
            setTabValue(0)
        }
        
    },[props.location.currentTab]);
    useEffect(() => {
        if (props.location.message) {           
            setSuccessMessages([props.location.message]);
        }
    },[]);
    const [values, setValues] = useState({
        "tcn": "",
        "batchNo": "",
        "julianDate": "",
        "mediaSource": "-1",
    });
    const [errorMessages, seterrorMessages] = React.useState([]);
    const [{ showClaimsInquiryError,
        showTcnError,
        showTcnInvError,
        showBatchNoError,
        showJulianDateError,
        showMediaSourceError,
        showTcnBatchError,
        showBatchInvError,
        showJulianInvError, showJulianDateInvError, shoJulianDateLessError, showBatchNumberError, showTCNNumberError },
        setShowError] = React.useState(false);
    const [{ showLocationCodeError, showLocationTypeError,
        showRestrictLocationUserIdError },
        setLocationShowError] = React.useState(false);
    const [{ showProviderDataError,
        showProviderRoleError,
        showProviderIdTypeError,
        showBeginDateError,
        showBgdtGTEnddtErr,
        beginDtInvalidErr,
        endDtInvalidErr,
        showEndDateError,
        showProviderIdError, showMemberIdError, beginDtADJInvalidErr, endDtADJInvalidErr, showBgdtGTADJEnddtErr,
        beginDtPaidInvalidErr, endDtPaidInvalidErr, showBgdtGTPaidEnddtErr, showBeginDOSError, showEndDOSError,  showBeginADJError, showEndADJError,
        showFromBilledAmountErr,
        showFromBilledAmountFloatErr,
        showFromBilledAmountFormatErr,
        showToBilledAmountErr,
        showToBilledAmountFloatErr,
        showToBilledAmountFormatErr,
        showFromAllowedAmountErr,
        showFromAllowedAmountFloatErr,
        showFromAllowedAmountFormatErr,
        showToAllowedAmountErr,
        showToAllowedAmountFloatErr,
        showToAllowedAmountFormatErr,
    },
        setAdvanceShowError] = React.useState(false);
    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
        setAdvanceErrorMessages([])
        seterrorMessages([])
        setLocationErrorMessages([])
        setLocationShowError({});
        setAdvanceShowError({});
        setShowError({});
    }



    // reset table
    const resetTable = () => {
        setShowNoRecords(false);
        seterrorMessages([]);
        setShowError({
            showTcnError: false,
            showBatchNoError: false,
            showJulianDateError: false,
            showMediaSourceError: false,
            showBatchNumberError: false,
            showTCNNumberError: false,
            showJulianDateInvError: false,
            shoJulianDateLessError: false,
        });
        setValues(
            {
                "tcn": "",
                "batchNo": "",
                "julianDate": "",
                "mediaSource": "-1",
            }
        );
        setShowTable(false);
        setBatchDataInfo()
        onReset()
    };

    const searchCheck = () => {
        // tcn = values.tcn;
        let dT = new Date(), dbD = values.julianDate.substr(2, 4), ybD = values.julianDate.substr(0, 2), yyyy = dT.getFullYear();
        setShowTable(false);
        setspinnerLoader(false);
        errorMessagesArray = [];
        seterrorMessages([]);
        setShowError({});
        let showTcnError;
        let showBatchNoError;
        let showJulianDateError;
        let showMediaSourceError;
        let showClaimsInquiryError;
        let showTcnInvError;
        let showTcnBatchError;
        let showBatchInvError;
        let showJulianInvError;
        let showBatchNumberError;
        let showTCNNumberError;
        let showJulianDateInvError;
        let shoJulianDateLessError;
        if (values.tcn.length == "" && values.batchNo.length == "" && values.julianDate.length == "") {
            showClaimsInquiryError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.claim_inquiry_error);
        }

        if (values.tcn.length != "" && values.batchNo.length != "") {
            showTcnBatchError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.TCN_Batch_NUM_Error);
        }


        if (values.tcn && (!values.tcn || values.tcn.length < 17 || values.tcn.length > 17)) {
            showTcnInvError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.CORRECTION_TCN_NUM_Error)
        }

        if (!(values.tcn === '' || values.tcn === undefined || values.tcn === null)) {
            if (!/^[0-9]+$/.test(values.tcn)) {
                showTCNNumberError = true;
               // errorMessagesArray.push(ClaimsCorrectionConstants.TCN_NUMBER_ERROR);
            }
        }

        if (!(values.batchNo === '' || values.batchNo === undefined || values.batchNo === null)) {
            if (!/^[0-9]+$/.test(values.batchNo)) {
                showBatchNumberError = true;
                errorMessagesArray.push(ClaimsCorrectionConstants.BATCH_NUMBER_ERROR);
                //   seterrorMessages(errorMessagesArray);
            }
        }

        if (values.tcn == "" && values.batchNo == "" && values.julianDate != "" && values.mediaSource != "-1") {
            showBatchNoError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Batch_No_Error);
        }

        if (values.tcn == "" && values.batchNo != "" && values.julianDate == "" && values.mediaSource != "-1") {
            showJulianDateError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Julian_Date_Error);
        }

        if (values.tcn == "" && values.batchNo != "" && values.julianDate != "" && values.mediaSource == "-1") {
            showJulianDateError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Media_Source_Error);
        }

        if (values.batchNo && (!values.batchNo || values.batchNo.length < 4) && values.tcn == '') {
            showBatchInvError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Batch_No_INV_Error);
        }

        if (values.julianDate && (!values.julianDate || values.julianDate.length < 5)) {
            showJulianInvError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.JULIAN_DATE_INV_Error);
        }
        if (values.julianDate) {
            if (values.julianDate.length != 5 || isNaN(values.julianDate)) {
                showJulianDateInvError = true;
                errorMessagesArray.push(ClaimsCorrectionConstants.BATCH_DATE_INVALID);
            } else if (
                values.julianDate == "00000"
                || dbD == "000"
                || ybD > yyyy % 100
                || (ybD == yyyy % 100 && dbD >= ((Date.UTC(yyyy, dT.getMonth(), dT.getDate()) - Date.UTC(yyyy, 0, 0)) / 24 / 60 / 60 / 1000))
                || (ybD % 4 == 0 && dbD > 366)
                || (ybD % 4 != 0 && ybD > 365)
            ) {
                shoJulianDateLessError = true;
                errorMessagesArray.push(ClaimsCorrectionConstants.BATCH_DATE_GT_CDT);
            }
        } 

        if (values.batchNo != "" && values.julianDate == "" && values.mediaSource == "-1" && values.tcn == '') {
            showJulianDateError = true;
            showMediaSourceError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Julian_Date_Error);
            errorMessagesArray.push(ClaimsCorrectionConstants.Media_Source_Error);
        }

        if (values.batchNo == "" && values.julianDate != "" && values.mediaSource == "-1" && values.tcn == '') {
            showBatchNoError = true;
            showMediaSourceError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Batch_No_Error);
            errorMessagesArray.push(ClaimsCorrectionConstants.Media_Source_Error);
        }

        if (values.batchNo == "" && values.julianDate == "" && values.mediaSource != "-1" && values.tcn == '') {
            showBatchNoError = true;
            showJulianDateError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Batch_No_Error);
            errorMessagesArray.push(ClaimsCorrectionConstants.Julian_Date_Error);
        }

        if (values.batchNo != "" && values.julianDate != "" && values.mediaSource == "-1" && values.tcn == '') {
            showMediaSourceError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Media_Source_Error);
        }

        if (errorMessagesArray.length == 0) {
            setShowTable(false);
            setspinnerLoader(true);
            setRedirect(true);
            let searchCriteria = {};
            if (!(values.tcn === '')) {
                searchCriteria = {
                    "searchByTCN": "true",
                    "statusCode": "S",
                    "tcn": values.tcn !== '' ? values.tcn : null,
                };
                setspinnerLoader(true);
                onSearch(searchCriteria);
            } else if (values.tcn === '') {
                searchCriteria = {
                    "searchByTCN": "true",
                    "statusCode": "S",
                    "batchNumber": values.batchNo !== '' ? values.batchNo : null,
                    "julianDateNumber": values.julianDate !== '' ? values.julianDate : null,
                    "mediaSource": values.mediaSource !== '-1' ? values.mediaSource : null,
                }
                setspinnerLoader(true);
                onSearch(searchCriteria);
            }

        } else {
            seterrorMessages(errorMessagesArray);
            setShowTable(false);
            // setspinnerLoader(true);
            setShowError({
                showTcnError,
                showBatchNoError,
                showJulianDateError,
                showMediaSourceError,
                showClaimsInquiryError,
                showTcnInvError,
                showTcnBatchError,
                showBatchInvError,
                showJulianInvError,
                showBatchNumberError,
                showTCNNumberError,
                shoJulianDateLessError,
                showJulianDateInvError
            });
        }
    };

    useEffect(() => {
        onDropdowns([Dropdowns.CLAIMS_INQUIRY_MEDIA, Dropdowns.CLAIM_TYPE_STATUS,
        Dropdowns.CLAIMS_INQUIRY_PROVIDER_TYPE,
        Dropdowns.CLAIM_HISTORY_TAB,
        Dropdowns.PROVIDER_TYPE,
        Dropdowns.REV_LOB,
        Dropdowns.CLAIM_TYPE_VALIDVALUE,
        Dropdowns.TRANS_TYPE,
        Dropdowns.R_PROC_MOD_CD,
        Dropdowns.CATEGORY_OF_SERVICE_VALIDVALUE
        ]);


    }, []);

    useEffect(() => {
        if (getClaimCorrection && redirect) {
            if (getClaimCorrection.data.claimTypeCode == "D") {
                props.history.push({
                    pathname: '/CorrectionDetails',     
                    getClaimCorrection: getClaimCorrection,
                    tabValue: tabValue,
                });
            } else if (getClaimCorrection.data.claimTypeCode == "M" || getClaimCorrection.data.claimTypeCode == "Y") {
                props.history.push({
                    pathname: '/ProfessionalCorrectionDetails',     
                    getClaimCorrection: getClaimCorrection,
                    tabValue: tabValue,
                });
            } else if (getClaimCorrection.data.claimTypeCode == "O" || getClaimCorrection.data.claimTypeCode == "I") {
                props.history.push({
                    pathname: '/InstitutionalCorrectionDetails',     
                    getClaimCorrection: getClaimCorrection,
                    tabValue: tabValue,
                });
            } 
            }
        }, [getClaimCorrection])

    useEffect(() => {
        if (MemberLockingPaylod) {
            setspinnerLoader(false);
            seterrorMessages([MemberLockingPaylod.message]);
               
            }
        }, [MemberLockingPaylod])


    useEffect(() => {
        if (paylod && paylod.data.recordCount == 0) {
            setspinnerLoader(false);
            seterrorMessages([ClaimsCorrectionConstants.NO_RECORDS_WITHSEARCH]);
            setBatchDataInfo()
        }
        if (paylod && paylod.data.recordCount == 1) {
            let obj = {
                "claimType" : paylod.data.searchResults[0].claimTypeCode,                
                "tcn" : paylod.data.searchResults[0].tcn,
                "memberSystemID" : paylod.data.searchResults[0].memberSystemID
            }

            getClaimCorrectionDetails(obj);
        }
        if (paylod && paylod.data.recordCount > 1) {
            setBatchDataInfo(paylod.data.searchResults)
            setspinnerLoader(false);
        }
    }, [paylod]);

    // const getMemberLockedData= (searchResults) => {
    //    console.log("searchResults"+JSON.stringify(searchResults))
    // }

    return (
        <div className="pos-relative">
            {successMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {successMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null}
            {spinnerLoader ? <Spinner /> : null}
            {tabValue == 0 && errorMessages.length > 0 ? (
                <div className="alert alert-danger custom-alert" role="alert">
                    {errorMessages.map(message => <li>{message}</li>)
                    }
                </div>
            ) : null
            }
            {tabValue == 1 && setLocationErrorMessages && locationErrorMessages.length > 0 ? (
                <div className="alert alert-danger custom-alert" role="alert">
                    {locationErrorMessages.map(message => <li>{message}</li>)}
                </div>
            ) : null
            }
            {tabValue == 2 && setAdvanceErrorMessages && advanceErrorMessages.length > 0 ? (
                <div className="alert alert-danger custom-alert" role="alert">
                    {advanceErrorMessages.map(message => <li>{message}</li>)
                    }
                </div>
            ) : null
            }

            {errorMessages.length == 0 && showNoRecords ? (
                <div className="alert alert-danger custom-alert" role="alert">
                    <li>{ClaimsCorrectionConstants.NO_RECORDS_WITHSEARCH}</li>
                </div>
            ) : null
            }

            <div className="mb-2">
                <BreadCrumbs
                    parent="Claims"
                    child1="Claim Correction"
                    path="Correction"
                />
            </div>

            <div className="tabs-container">

                <div className="tab-header">
                    <h1 className="tab-heading page-heading float-left"> Claim Correction </h1>
                    <div className="float-right th-btnGroup">
                        <Button title="Print" variant="outlined" color="primary" className="btn btn-primary">
                            <i className="fa fa-print" />
                            Print
    </Button>
                        <Button title="Help" variant="outlined" color="primary" className="btn btn-secondary">
                            <i className="fa fa-question-circle" />
                            Help
    </Button>
                    </div>
                </div>
                <div className="custom-hr my-1 pb-1" />

                <div className="tab-body clm-correction-panel-1">
                    <div className='tab-holder custom-tabber my-3'>
                        <AppBar position='static' color="default">
                            <Tabs value={tabValue} onChange={handleTabChange}
                                indicatorColor="primary"
                                textColor="primary"
                                variant="scrollable"
                                scrollButtons="auto"
                                aria-label="scrollable auto tabs example">
                                <Tab title="TCN" label="TCN" {...a11yProps(0)} />
                                <Tab title="Location" label="Location" {...a11yProps(1)} />
                                <Tab title="Advance" label="Advance"{...a11yProps(2)} />
                            </Tabs>
                        </AppBar>

                        <TabPanel value={tabValue} index={0}>
                            <ClaimsCorrectionTCNSearchForm values={values} spinnerLoader={spinnerLoader}
                                setspinnerLoader={setspinnerLoader}
                                handleChanges={handleChanges} searchCheck={searchCheck}
                                resetTable={resetTable}
                                errors={{ showTcnError, showTCNNumberError, showBatchNoError, showJulianDateError, showJulianDateInvError, shoJulianDateLessError, showBatchNumberError, showMediaSourceError, showClaimsInquiryError, showTcnInvError, showTcnBatchError, showBatchInvError, showJulianInvError }}
                                dropdowns={addDropdowns} setLocationErrorMessages={setLocationErrorMessages} setAdvanceErrorMessages={setAdvanceErrorMessages} privileges={props.privileges}/>

                            {batchDataInfo ? <ClaimCorrectionBatchData tableData={batchDataInfo} setRedirect = {setRedirect}/> : null}
                        </TabPanel>

                        <TabPanel value={tabValue} index={1}>
                            <ClaimsCorrectionLocationSearch 
                            onReset = {onResetLocation}
                            onSearch = {onSearchLocation}
                            locationDropdown = {locationDropdown}
                            payload = {payloadLocation}
                            locationDropdownData = {locationDropdownData}
                            errors={{
                                showLocationCodeError, showLocationTypeError,
                                showRestrictLocationUserIdError
                            }} dropdowns={addDropdowns} setLocationErrorMessages={setLocationErrorMessages} setLocationShowError={setLocationShowError} history={props.history} setAdvanceErrorMessages={setAdvanceErrorMessages} setRedirect = {setRedirect} privileges={props.privileges}/>
                        </TabPanel>
                        <TabPanel value={tabValue} index={2}>
                            <ClaimsCorrectionAdvanceSearch errors={{
                                showProviderDataError, showProviderRoleError, showProviderIdTypeError, showBeginDateError, showBgdtGTEnddtErr,
                                beginDtInvalidErr, endDtInvalidErr, showEndDateError, showProviderIdError, showMemberIdError, beginDtADJInvalidErr, endDtADJInvalidErr, showBgdtGTADJEnddtErr,
                                beginDtPaidInvalidErr, endDtPaidInvalidErr, showBgdtGTPaidEnddtErr, showBeginDOSError, showEndDOSError, showBeginADJError, showEndADJError,showFromBilledAmountErr,
                                showFromBilledAmountFloatErr,
                                showFromBilledAmountFormatErr,
                                showToBilledAmountErr,
                                showToBilledAmountFloatErr,
                                showToBilledAmountFormatErr,
                                showFromAllowedAmountErr,
                                showFromAllowedAmountFloatErr,
                                showFromAllowedAmountFormatErr,
                                showToAllowedAmountErr,
                                showToAllowedAmountFloatErr,
                                showToAllowedAmountFormatErr,
                            }} dropdowns={addDropdowns} setAdvanceShowError={setAdvanceShowError} setAdvanceErrorMessages={setAdvanceErrorMessages} history={props.history} setRedirect = {setRedirect} privileges={props.privileges}/>
                        </TabPanel>
                    </div>
                </div>
            </div>
        </div>

    )
}

export default withRouter(ClaimsCorrection);