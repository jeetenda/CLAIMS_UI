import React from 'react';
import { Button } from 'react-bootstrap';
import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import TextField from '@material-ui/core/TextField';
import DateFnsUtils from '@date-io/date-fns';
import RadioGroup from '@material-ui/core/RadioGroup';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import { useDispatch, useSelector } from 'react-redux';
import { useState, useEffect } from 'react';
import MenuItem from '@material-ui/core/MenuItem';
import Checkbox from '@material-ui/core/Checkbox';
import dateFnsFormat from 'date-fns/format';
import * as ClaimsCorrectionConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import InputAdornment from '@material-ui/core/InputAdornment';
import ClaimsCorrectionAdvanceSearchTable from './ClaimsCorrectionAdvanceSearchTable'
import ClaimCorrectionAdvanceSearchForm from './ClaimCorrectionAdvanceSearchForm'
import { resetSearchClaimsCorrection, claimCorrectionAdvanceSearchAction, locationDropdownAction } from '../actions';
function ClaimsCorrectionAdvanceSearch(props) {

    let errorMessagesArray = [];
    const dispatch = useDispatch();
    const [showNoRecords, setShowNoRecords] = useState(false);
    const [spinnerLoader, setspinnerLoader] = React.useState(false);
    const [showTable, setShowTable] = useState(false);
    const [showRecords, setShowRecords] = useState([]);
    const [selectedEndDate, setSelectedDosEndDate] = React.useState('');
    const [selectedBeginDate, setSelectedDosBeginDate] = React.useState('');
    const [selectedAdjBeginDate, setSelectedAdjudicationBeginDate] = React.useState('');
    const [selectedAdjEndDate, setSelectedAdjudicationEndDate] = React.useState('');
    const [selectedPaidBeginDate, setSelectedPaidBeginDate] = React.useState('');
    const [selectedPaidEndDate, setSelectedPaidEndDate] = React.useState('');
    const onReset = () => dispatch(resetSearchClaimsCorrection());
    const onSearch = searchvalues => { return dispatch(claimCorrectionAdvanceSearchAction(searchvalues)) };
    const payload = useSelector(state => state.claimCorrectionSearch.advanceSearchPayload);
    const locationDropdown = () => dispatch(locationDropdownAction());
    const locationDropdownData = useSelector(state => state.serviceSearch.locationPayload);
    const handleChanges = name => (event) => {

        if (event.target.type === 'checkbox') {
            setValues({ ...values, [name]: event.target.checked });
        } else {
            setValues({ ...values, [name]: event.target.value });
        }
    };

    const handleDCDtChange = (name, date) => {
        setValues({ ...values, [name]: date });
    }
    const handleAdjudicationBeginDateChange = date => {
        // setSelectedAdjudicationBeginDate(date);
        handleDCDtChange('beginAdjudicationDate', formatDate(date));
    };

    const handleAdjudicationEndDateChange = date => {
        // setSelectedAdjudicationEndDate(date);
        handleDCDtChange('endAdjudicationDate', formatDate(date));
    };
    const handlePaidBeginDateChange = date => {
        // setSelectedPaidBeginDate(date);
        handleDCDtChange('beginPaidDate', formatDate(date));
    };

    const handlePaidEndDateChange = date => {
        // setSelectedPaidEndDate(date);
        handleDCDtChange('endPaidDate', formatDate(date));
    };
    const handleBeginDateChange = date => {
        setSelectedDosBeginDate(date);
        handleDCDtChange('beginDOS', formatDate(date));
    };

    const handleEndDateChange = date => {
        setSelectedDosEndDate(date);
        handleDCDtChange('endDOS', formatDate(date));
    };
    const date1 = new Date()
    const date2 = new Date()
    const beforeDate = date2.setDate((new Date()).getDate() - 90);
    const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        dt = new Date(dt);
        if (dt.toString() == "Invalid Date") {
            return dt;
        } else {
            return dateFnsFormat(dt, "MM/dd/yyyy");
        }
    };
    
    React.useEffect(() => {
        values.beginAdjudicationDate !== '' ? setSelectedAdjudicationBeginDate(values.beginAdjudicationDate) : setSelectedAdjudicationBeginDate('');
        values.endAdjudicationDate !== '' ? setSelectedAdjudicationEndDate(values.endAdjudicationDate) : setSelectedAdjudicationEndDate('');
    }, []);
    React.useEffect(() => {
        values.beginDOS !== '' ? setSelectedDosBeginDate(values.beginDOS) : setSelectedDosBeginDate('');
        values.endDOS !== '' ? setSelectedDosEndDate(values.endDOS) : setSelectedDosEndDate('');
    }, []);
    React.useEffect(() => {
        values.beginPaidDate !== '' ? setSelectedPaidBeginDate(values.beginPaidDate) : setSelectedPaidBeginDate('');
        values.endPaidDate !== '' ? setSelectedPaidEndDate(values.endPaidDate) : setSelectedPaidEndDate('');
    }, []);
    const [values, setValues] = useState({
        providerRole: "",
        providerIDTypeCode: "-1",
        providerID: '',
        memberID: '',
        claimType: '-1',
        beginDOS: formatDate(beforeDate),
        endDOS: formatDate(date1),
        beginAdjudicationDate: '',
        endAdjudicationDate: '',
        fedralTaxID: '',
        serviceAuthID: '',
        lob: '-1',
        benefitPlanId: '',
        categoryOfService: '-1',
        providerType: '-1',
        diagnosisCode: '',
        drgCode: '',
        locationCode: '-1',
        transType: '-1',
        fromProcedureCode: '',
        toProcedureCode: '',
        fromRevenueCode: '',
        toRevenueCode: '',
        fromBilledAmount: '',
        toBilledAmount: '',
        fromAllowedAmount: '',
        toAllowedAmount: '',
        frModifier1: '-1',
        frModifier2: '-1',
        frModifier3: '-1',
        frModifier4: '-1',
        toModifier1: '-1',
        toModifier2: '-1',
        toModifier3: '-1',
        toModifier4: '-1',

    });

    
    const [redirect, setRedirect] = useState(false);
    const resetTable = () => {
        setShowNoRecords(false);
        props.setAdvanceErrorMessages([]);
        props.setAdvanceShowError({
            showProviderDataError: false,
            showProviderRoleError: false,
            showProviderIdTypeError: false,
            showProviderIdError: false,
            showMemberIdError: false,
            showBeginDateError: false,
            showBgdtGTEnddtErr: false,
            beginDtInvalidErr: false,
            endDtInvalidErr: false,
            showEndDateError: false,
            beginDtADJInvalidErr: false,
            endDtADJInvalidErr: false,
            showBgdtGTADJEnddtErr: false,
            beginDtPaidInvalidErr: false,
            endDtPaidInvalidErr: false,
            showBgdtGTPaidEnddtErr: false,
            showBeginDOSError: false,
            showEndDOSError: false,
            showBeginADJError: false,
            showEndADJError: false,
            showFromBilledAmountErr:false,
            showFromBilledAmountFloatErr: false,
            showFromBilledAmountFormatErr: false,
            showToBilledAmountErr: false,
            showToBilledAmountFloatErr: false,
            showToBilledAmountFormatErr: false,
            showFromAllowedAmountErr: false,
            showFromAllowedAmountFloatErr: false,
            showFromAllowedAmountFormatErr: false,
            showToAllowedAmountErr: false,
            showToAllowedAmountFloatErr: false,
            showToAllowedAmountFormatErr: false,
        });
        setValues(
            {
                providerRole: "",
                providerIDTypeCode: "-1",
                providerID: '',
                memberID: '',
                claimType: '-1',
                beginDOS: formatDate(beforeDate),
                endDOS: formatDate(date1),
                beginAdjudicationDate: '',
                endAdjudicationDate: '',
                fedralTaxID: '',
                serviceAuthID: '',
                lob: '-1',
                benefitPlanId: '',
                categoryOfService: '-1',
                providerType: '-1',
                diagnosisCode: '',
                drgCode: '',
                locationCode: '-1',
                transType: '-1',
                fromProcedureCode: '',
                toProcedureCode: '',
                fromRevenueCode: '',
                toRevenueCode: '',
                fromBilledAmount: '',
                toBilledAmount: '',
                fromAllowedAmount: '',
                toAllowedAmount: '',
                frModifier1: '-1',
                frModifier2: '-1',
                frModifier3: '-1',
                frModifier4: '-1',
                toModifier1: '-1',
                toModifier2: '-1',
                toModifier3: '-1',
                toModifier4: '-1',
            }
        );
        setShowTable(false);
        setShowRecords([])
        onReset()
    };

    const checkAmountValue = (maxAllowAmount) =>{
        var regex = /^[0-9.]{1,15}$/;
        if (regex.test(maxAllowAmount)) {
          var isDot = maxAllowAmount.indexOf('.');
          if (isDot <= -1) {
              if(maxAllowAmount.length>11){ 
                  return "MaxAmountErr";
                }
          } else {
            var afterDot = maxAllowAmount.split('.')[1];
            var afterDotCount = maxAllowAmount.split('').filter(val=> val==".");
            if(afterDot.length>2 || afterDotCount.length>1){
                return "IncorrectFormatErr";         
            }
          }
        }else{
            return "FloatErr";
       }
    //    if( maxAllowAmountCurr!==""){
    //        return true;
    //    }

    }

    const searchCheck = () => {
        setShowTable(false);
        setspinnerLoader(false);
        errorMessagesArray = [];
        props.setAdvanceErrorMessages([]);
        props.setAdvanceShowError({});
        let showProviderDataError;
        let showProviderRoleError;
        let showProviderIdTypeError;
        let showProviderIdError;
        let showMemberIdError;
        let showBeginDateError;
        let showBgdtGTEnddtErr;
        let beginDtInvalidErr;
        let endDtInvalidErr;
        let showEndDateError;
        let beginDtADJInvalidErr;
        let endDtADJInvalidErr;
        let showBgdtGTADJEnddtErr;
        let showEndDOSError;
        let showBeginDOSError;
        let showBeginADJError;
        let showEndADJError;
        let showBgdtGTPaidEnddtErr;
        let showFromBilledAmountErr;
        let showFromBilledAmountFloatErr;
        let showFromBilledAmountFormatErr;
        let showToBilledAmountErr;
        let showToBilledAmountFloatErr;
        let showToBilledAmountFormatErr; 
        let showFromAllowedAmountErr;
        let showFromAllowedAmountFloatErr;
        let showFromAllowedAmountFormatErr;
        let showToAllowedAmountErr;
        let showToAllowedAmountFloatErr;
        let showToAllowedAmountFormatErr;
        
        if (values.providerIDTypeCode === '-1' && values.providerID === '' && values.providerRole === '' && values.memberID == '') {
            showProviderDataError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_DATA_Error);
        }
        

        if (values.providerRole !== '' && values.providerIDTypeCode === '-1' && values.providerID === '') {
            showProviderIdError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ID_Error);
            showProviderIdTypeError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error);
        }
        if (values.providerIDTypeCode !== '-1' && values.providerRole === '' && values.providerID === '') {
            showProviderIdError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ID_Error);
            showProviderRoleError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ROLE_Error);
        }
        if (values.providerID !== '' && values.providerIDTypeCode === '-1' && values.providerRole == "") {
            showProviderRoleError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ROLE_Error);
            showProviderIdTypeError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error);
        }
        if (values.providerID !== '' && values.providerIDTypeCode !== '-1' && values.providerRole == "") {
            showProviderRoleError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ROLE_Error);
        }
        if (values.providerID !== '' && values.providerIDTypeCode == '-1' && values.providerRole !== "") {
            showProviderIdTypeError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error);
        }
        if (values.providerID == '' && values.providerIDTypeCode !== '-1' && values.providerRole !== "") {
            showProviderIdError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.PROVIDER_ID_Error);
        }
        if (values.beginDOS == '' && values.endDOS == '') {
            showBeginDateError = true;
            errorMessagesArray.push(['At least One Date Range Is Required.']);
        }

        if(values.beginDOS == '' && values.endDOS != ''){
            showBeginDOSError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.BEGINDOSERR);
        }

        if(values.beginDOS != '' && values.endDOS == ''){
            showEndDOSError = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.ENDDOSERR);
        }

        if(values.beginAdjudicationDate == '' && values.endAdjudicationDate != '' && values.beginDOS == '' && values.endDOS == ''){
            showBeginADJError = true;
            errorMessagesArray.pop()
            errorMessagesArray.push(ClaimsCorrectionConstants.BEGINADJERR);
        }

        if(values.beginAdjudicationDate != '' && values.endAdjudicationDate == '' && values.beginDOS == '' && values.endDOS == ''){
            showEndADJError = true;
            errorMessagesArray.pop()
            errorMessagesArray.push(ClaimsCorrectionConstants.ENDADJERR);
        }

        if (values.beginAdjudicationDate != '' && values.endAdjudicationDate != '') {
            showBeginDateError = false;
            errorMessagesArray.pop()
        }
        if (values.beginDOS != '' && values.beginDOS.toString() == "Invalid Date") {
            beginDtInvalidErr = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Invalid_Begin_Date_Error);
        }
        if (values.endDOS != '' && values.endDOS.toString() == "Invalid Date") {
            endDtInvalidErr = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Invalid_End_Date_Error);
        }
        if (values.beginDOS != '' && values.endDOS != '' && values.beginDOS.toString() != "Invalid Date" && values.endDOS.toString() != "Invalid Date" && new Date(values.beginDOS) <= new Date(values.endDOS) == false) {
            showBgdtGTEnddtErr = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Bgndt_GT_Enddt_Err);
        }

        if (values.beginAdjudicationDate != '' && values.beginAdjudicationDate.toString() == "Invalid Date") {
            beginDtADJInvalidErr = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Invalid_Begin_Date_Error);
        }
        if (values.endAdjudicationDate != '' && values.endAdjudicationDate.toString() == "Invalid Date") {
            endDtADJInvalidErr = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Invalid_End_Date_Error);
        }
        if (values.beginAdjudicationDate != '' && values.endAdjudicationDate != '' && values.beginAdjudicationDate.toString() != "Invalid Date" && values.endAdjudicationDate.toString() != "Invalid Date" && new Date(values.beginAdjudicationDate) <= new Date(values.endAdjudicationDate) == false) {
            showBgdtGTADJEnddtErr = true;
            errorMessagesArray.push(ClaimsCorrectionConstants.Bgndt_GT_Enddt_Err);
        }
        if (values.fromBilledAmount != "") {
            let checkAmountRslt = checkAmountValue(values.fromBilledAmount);
            if (checkAmountRslt === "MaxAmountErr") {
                showFromBilledAmountErr = true;
            }
            else if (checkAmountRslt === "IncorrectFormatErr") {
                showFromBilledAmountFormatErr = true;  
            }
            else if (checkAmountRslt === "FloatErr") {
                showFromBilledAmountFloatErr = true;
            }
        }
        if (values.toBilledAmount != "") {
            let checkAmountRslt = checkAmountValue(values.toBilledAmount);
            if (checkAmountRslt === "MaxAmountErr") {
                showToBilledAmountErr = true;
            }
            else if (checkAmountRslt === "IncorrectFormatErr") {
                showToBilledAmountFormatErr = true;
            }
            else if (checkAmountRslt === "FloatErr") {
                showToBilledAmountFloatErr = true;
            }
        }

        if (values.fromAllowedAmount != "" ) {
            let checkAmountRslt = checkAmountValue(values.fromAllowedAmount);
            if (checkAmountRslt === "MaxAmountErr") {
                showFromAllowedAmountErr = true;
            }
            else if (checkAmountRslt === "IncorrectFormatErr") {
                showFromAllowedAmountFormatErr = true;
            }
            else if (checkAmountRslt === "FloatErr") {
                showFromAllowedAmountFloatErr = true;
            }
        }
        if (values.toAllowedAmount != "" ) {
            let checkAmountRslt = checkAmountValue(values.toAllowedAmount);
            if (checkAmountRslt === "MaxAmountErr") {
                showToAllowedAmountErr = true;
            }
            else if (checkAmountRslt === "IncorrectFormatErr") {
                showToAllowedAmountFormatErr = true;
            }
            else if (checkAmountRslt === "FloatErr") {
                showToAllowedAmountFloatErr = true;
            }
        }

        if(showFromBilledAmountErr ||showToBilledAmountErr || showFromAllowedAmountErr || showToAllowedAmountErr){
            errorMessagesArray.push(ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR);
        }
        if(showFromBilledAmountFormatErr ||showToBilledAmountFormatErr || showToAllowedAmountFormatErr|| showFromAllowedAmountFormatErr){
            errorMessagesArray.push(ClaimsCorrectionConstants.Amt_Incorrect_Format_Error);
        }
        if(showFromBilledAmountFloatErr||showToBilledAmountFloatErr  || showFromAllowedAmountFloatErr||showToAllowedAmountFloatErr){
            errorMessagesArray.push(ClaimsCorrectionConstants.Amt_Float_Error);
        }

        if (errorMessagesArray.length == 0) {
            if (values.providerRole === 'BI') {
                let searchCriteria = {

                    "billingProvider": "true",
                    "billingProviderSystemID": values.providerID,
                    "billingProviderID": values.providerIDTypeCode,
                    "statusCode": "S",
                    "claimType": values.claimType,
                    "serviceBeginDate": values.beginDOS,
                    "serviceEndDate": values.endDOS,                   
                    "memberID": values.memberID ? values.memberID : null,
                    "adjudicationBeginDate": values.beginAdjudicationDate ? values.beginAdjudicationDate : null,
                    "adjudicationEndDate": values.endAdjudicationDate ? values.endAdjudicationDate : null,
                    "federalTaxID": values.fedralTaxID ? values.fedralTaxID : null,
                    "serviceAuthID": values.serviceAuthID ? values.serviceAuthID : null,
                    "lobCode": values.lob == '-1' ? null : values.lob,
                    "benefitPlanId": values.benefitPlanId ? values.benefitPlanId : null,
                    "categoryOfService": values.categoryOfService == '-1' ? null : values.categoryOfService,
                    "providerType": values.providerType == '-1' ? null : values.providerType,
                    "diagnosisCode": values.diagnosisCode ? values.diagnosisCode : null,
                    "drgCode": values.drgCode ? values.drgCode : null,
                    "locationCode": values.locationCode == '-1' ? null : values.locationCode,
                    "transactionType": values.transType == '-1' ? null : values.transType,
                    "procedureFromCode": values.fromProcedureCode ? values.fromProcedureCode : null,
                    "procedureToCode": values.toProcedureCode ? values.toProcedureCode : null,
                    "revenueFromCode": values.fromRevenueCode ? values.fromRevenueCode : null,
                    "revenueToCode": values.toRevenueCode ? values.toRevenueCode : null,
                    "billedFromAmount": values.fromBilledAmount ? values.fromBilledAmount : null,
                    "billedToAmount": values.toBilledAmount ? values.toBilledAmount : null,
                    "allowedFromAmount": values.fromAllowedAmount ? values.fromAllowedAmount : null,
                    "allowedToAmount": values.toAllowedAmount ? values.toAllowedAmount : null,
                    "frModifier1": values.frModifier1 == '-1' ? null : values.frModifier1,
                    "frModifier2": values.frModifier2 == '-1' ? null : values.frModifier2,
                    "frModifier3": values.frModifier3 == '-1' ? null : values.frModifier3,
                    "frModifier4": values.frModifier4 == '-1' ? null : values.frModifier4,
                    "toModifier1": values.toModifier1 == '-1' ? null : values.toModifier1,
                    "toModifier2": values.toModifier2 == '-1' ? null : values.toModifier2,
                    "toModifier3": values.toModifier3 == '-1' ? null : values.toModifier3,
                    "toModifier4": values.toModifier4 == '-1' ? null : values.toModifier4
                };
                onSearch(searchCriteria);
                setspinnerLoader(true);
            } else if (values.providerRole === 'RN') {
                let searchCriteria = {
                    "renderingProvider": "true",
                    "renderingProviderSystemID": values.providerIDTypeCode,
                    "renderingProviderID": values.providerID,
                    "statusCode": "S",
                    "claimType": values.claimType,
                    "serviceBeginDate": values.beginDOS,
                    "serviceEndDate": values.endDOS,
                    "memberID": values.memberID ? values.memberID : null,
                    "adjudicationBeginDate": values.beginAdjudicationDate ? values.beginAdjudicationDate : null,
                    "adjudicationEndDate": values.endAdjudicationDate ? values.endAdjudicationDate : null,
                    "federalTaxID": values.fedralTaxID ? values.fedralTaxID : null,
                    "serviceAuthID": values.serviceAuthID ? values.serviceAuthID : null,
                    "lobCode": values.lob == '-1' ? null : values.lob,
                    "benefitPlanId": values.benefitPlanId ? values.benefitPlanId : null,
                    "categoryOfService": values.categoryOfService == '-1' ? null : values.categoryOfService,
                    "providerType": values.providerType == '-1' ? null : values.providerType,
                    "diagnosisCode": values.diagnosisCode ? values.diagnosisCode : null,
                    "drgCode": values.drgCode ? values.drgCode : null,
                    "locationCode": values.locationCode == '-1' ? null : values.locationCode,
                    "transactionType": values.transType == '-1' ? null : values.transType,
                    "procedureFromCode": values.fromProcedureCode ? values.fromProcedureCode : null,
                    "procedureToCode": values.toProcedureCode ? values.toProcedureCode : null,
                    "revenueFromCode": values.fromRevenueCode ? values.fromRevenueCode : null,
                    "revenueToCode": values.toRevenueCode ? values.toRevenueCode : null,
                    "billedFromAmount": values.fromBilledAmount ? values.fromBilledAmount : null,
                    "billedToAmount": values.toBilledAmount ? values.toBilledAmount : null,
                    "allowedFromAmount": values.fromAllowedAmount ? values.fromAllowedAmount : null,
                    "allowedToAmount": values.toAllowedAmount ? values.toAllowedAmount : null,
                    "frModifier1": values.frModifier1 == '-1' ? null : values.frModifier1,
                    "frModifier2": values.frModifier2 == '-1' ? null : values.frModifier2,
                    "frModifier3": values.frModifier3 == '-1' ? null : values.frModifier3,
                    "frModifier4": values.frModifier4 == '-1' ? null : values.frModifier4,
                    "toModifier1": values.toModifier1 == '-1' ? null : values.toModifier1,
                    "toModifier2": values.toModifier2 == '-1' ? null : values.toModifier2,
                    "toModifier3": values.toModifier3 == '-1' ? null : values.toModifier3,
                    "toModifier4": values.toModifier4 == '-1' ? null : values.toModifier4,
                };
                onSearch(searchCriteria);
                setspinnerLoader(true);
            }else if(values.providerRole === ''){
                let searchCriteria = {
                    "renderingProvider": "false",
                    "renderingProviderSystemID": values.providerIDTypeCode == '-1' ? null : values.providerIDTypeCode,
                    "renderingProviderID": values.providerID ? values.providerID : null,
                    "billingProvider": "false",
                    "billingProviderSystemID": values.providerID  ? values.providerID : null,
                    "billingProviderID": values.providerIDTypeCode == '-1' ? null : values.providerIDTypeCode,
                    "statusCode": "S",
                    "claimType": values.claimType == '-1' ? null : values.claimType,
                    "serviceBeginDate": values.beginDOS,
                    "serviceEndDate": values.endDOS,                   
                    "memberID": values.memberID ? values.memberID : null,
                    "adjudicationBeginDate": values.beginAdjudicationDate ? values.beginAdjudicationDate : null,
                    "adjudicationEndDate": values.endAdjudicationDate ? values.endAdjudicationDate : null,
                    "federalTaxID": values.fedralTaxID ? values.fedralTaxID : null,
                    "serviceAuthID": values.serviceAuthID ? values.serviceAuthID : null,
                    "lobCode": values.lob == '-1' ? null : values.lob,
                    "benefitPlanId": values.benefitPlanId ? values.benefitPlanId : null,
                    "categoryOfService": values.categoryOfService == '-1' ? null : values.categoryOfService,
                    "providerType": values.providerType == '-1' ? null : values.providerType,
                    "diagnosisCode": values.diagnosisCode ? values.diagnosisCode : null,
                    "drgCode": values.drgCode ? values.drgCode : null,
                    "locationCode": values.locationCode == '-1' ? null : values.locationCode,
                    "transactionType": values.transType == '-1' ? null : values.transType,
                    "procedureFromCode": values.fromProcedureCode ? values.fromProcedureCode : null,
                    "procedureToCode": values.toProcedureCode ? values.toProcedureCode : null,
                    "revenueFromCode": values.fromRevenueCode ? values.fromRevenueCode : null,
                    "revenueToCode": values.toRevenueCode ? values.toRevenueCode : null,
                    "billedFromAmount": values.fromBilledAmount ? values.fromBilledAmount : null,
                    "billedToAmount": values.toBilledAmount ? values.toBilledAmount : null,
                    "allowedFromAmount": values.fromAllowedAmount ? values.fromAllowedAmount : null,
                    "allowedToAmount": values.toAllowedAmount ? values.toAllowedAmount : null,
                    "frModifier1": values.frModifier1 == '-1' ? null : values.frModifier1,
                    "frModifier2": values.frModifier2 == '-1' ? null : values.frModifier2,
                    "frModifier3": values.frModifier3 == '-1' ? null : values.frModifier3,
                    "frModifier4": values.frModifier4 == '-1' ? null : values.frModifier4,
                    "toModifier1": values.toModifier1 == '-1' ? null : values.toModifier1,
                    "toModifier2": values.toModifier2 == '-1' ? null : values.toModifier2,
                    "toModifier3": values.toModifier3 == '-1' ? null : values.toModifier3,
                    "toModifier4": values.toModifier4 == '-1' ? null : values.toModifier4
                };
                onSearch(searchCriteria);
                setspinnerLoader(true);
            }
            
        }
        else {
            props.setAdvanceErrorMessages(errorMessagesArray);
            setShowTable(false);
            props.setAdvanceShowError({
                showProviderDataError,
                showProviderRoleError,
                showProviderIdTypeError,
                showProviderIdError,
                showBeginDateError,
                showBgdtGTEnddtErr,
                beginDtInvalidErr,
                endDtInvalidErr,
                showEndDateError,
                beginDtADJInvalidErr,
                endDtADJInvalidErr,
                showBgdtGTADJEnddtErr,
                showEndDOSError,
                showBeginDOSError,
                showBeginADJError,
                showEndADJError,
                showFromBilledAmountErr,
                showFromBilledAmountFloatErr,
                showFromBilledAmountFormatErr,
                showToBilledAmountErr,
                showToBilledAmountFloatErr,
                showToBilledAmountFormatErr,
                showFromAllowedAmountErr,
                showFromAllowedAmountFloatErr,
                showFromAllowedAmountFormatErr,
                showToAllowedAmountErr,
                showToAllowedAmountFloatErr,
                showToAllowedAmountFormatErr,
            });
        }
    };


    useEffect(() => {
        locationDropdown();
       
    }, []);

    useEffect(() => {
        console.log(payload)
        if (payload && payload.data.recordCount == 0) {
            setspinnerLoader(false);
            setShowRecords([])
            props.setAdvanceErrorMessages([ClaimsCorrectionConstants.NO_RECORDS_WITHSEARCH]);
        }
        if (payload != null && payload.data.recordCount == 1) {
            // props.setAdvanceErrorMessages(false)
            // setShowRecords(payload.data.searchResults)
            // setspinnerLoader(false);
            props.history.push({
                pathname: '/CorrectionDetails',
            });
        }
        if (payload != null && payload.data.recordCount > 1) {
            props.setAdvanceErrorMessages(false)
            setShowRecords(payload.data.searchResults)
            setspinnerLoader(false);
        }

    }, [payload]);

    return (
            <div>
             {spinnerLoader ? <Spinner /> : null}
            <ClaimCorrectionAdvanceSearchForm 
            values = {values}
            errors = {props.errors}
           handleChanges = {handleChanges}
           searchCheck = {searchCheck}
           resetTable = {resetTable}
           dropdowns = {props.dropdowns}
           locationDropdownData = {locationDropdownData}
           handleBeginDateChange = {handleBeginDateChange}
           handleEndDateChange = {handleEndDateChange}
           handleAdjudicationBeginDateChange = {handleAdjudicationBeginDateChange}
           handleAdjudicationEndDateChange = {handleAdjudicationEndDateChange}

            />
            <ClaimsCorrectionAdvanceSearchTable tableData={showRecords} setRedirect = {props.setRedirect}/>
            </div>
    )
}

export default ClaimsCorrectionAdvanceSearch;