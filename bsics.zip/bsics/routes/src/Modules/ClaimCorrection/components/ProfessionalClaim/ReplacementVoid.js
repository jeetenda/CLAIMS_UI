import React, { useState } from "react";
import { Button } from 'react-bootstrap';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableAHComponent from '../../../../SharedModules/Table/TableRedirect';


const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

const headCells = [
    { id: "replacedTCN" , numeric: false, disablePadding: true, label: 'TCN', enableHyperLink: true, fontSize: 12, width: '50%'},
    { id: "adjustmentReasonCodeDesc" , numeric: false, disablePadding: true, label: 'Reason', enableHyperLink: false, fontSize: 12},
]

function  ReplacementVoid(props) {
    const classes = useStyles();
    console.log(props.data.claimAdjustment);

    const getTableData = (data) => {
        if (data && data.length) {
          let tData = JSON.stringify(data); 
          tData = JSON.parse(tData);     
          tData.map((each,index) => {
            each.index = index;
          }); 
          return tData;           
        }else{
          return [];
        }
    };

    const editRowTCN= row => (event) => { 
        let searchCriteria = {};
	    searchCriteria = {
                    tcn: row.replacedTCN !== '' ? row.replacedTCN : null,
                };
				setspinnerLoader(true);
				props.onSearchParent(searchCriteria);
    return true;

    };
    
    return (
        <div className="pos-relative">
            <div className="tabs-container custom-panel">
                <div className='tab-holder CustomExpansion-panel my-3'>
        <ExpansionPanel className="collapsable-panel">
            <ExpansionPanelSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panelp1a-content32"
                id="panelp1a-header3244">
                <Typography className={classes.heading}> Replacement/Void</Typography>
            </ExpansionPanelSummary>
            <ExpansionPanelDetails>
                    <div className="tab-header pb-2">
                        <h2 className="tab-heading float-left">
                            Replacememt Claims
                        </h2>
                    </div>
                    <TableAHComponent headCells={headCells} tableData={getTableData(props.data.claimAdjustment? props.data.claimAdjustment: [])} onTableRowClick={editRowTCN} defaultSortColumn="diagnosisCode" />    
            </ExpansionPanelDetails>
        </ExpansionPanel>
        </div>
        </div>
        </div>
    )
}

export default  ReplacementVoid;