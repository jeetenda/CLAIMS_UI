import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import { Divider } from "@material-ui/core";
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import * as ErrorConst from '../../../../SharedModules/Messages/ErrorMsgConstants';
import DiagnosisCodes from './DiagnosisCodes';
import InputAdornment from "@material-ui/core/InputAdornment";


const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

function Visit(props) {
    const classes = useStyles();
    const data = props.data;
    return (
        <div className="pos-relative">
            <div className="tabs-container custom-panel">
                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="visit-header3244"
                            id="visit-header3244">
                            <Typography className={classes.heading}>Visit</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <div className="set-form-wrapper mt-2">
                                <div className="form-wrapper form-3-column p-0">
                                    <div className="mui-custom-form input-md wdth17">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Other Insurance</label>
                                        </div>
                                        <div className="sub-radio mt-0">
                                            <RadioGroup
                                                row
                                                aria-label="Other Insurance"
                                                name="Other Insurance"
                                                checked={data.otherInsuranceIndicator}
                                                value={data.otherInsuranceIndicator}
                                                onChange={e => { props.setClaimEntryData({ ...data, otherInsuranceIndicator: e.target.value == "true" ? true : false }) }}
                                            >
                                                <FormControlLabel
                                                    value={true}
                                                    control={<Radio color="primary" />}
                                                    label="Yes"
                                                />
                                                <FormControlLabel
                                                    value={false}
                                                    control={<Radio color="primary" />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                        </div>
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Accident</label>
                                        </div>
                                        <div className="sub-radio pl-2 mt-2">
                                            <FormGroup row>
                                                <FormControlLabel
                                                    id="emp_visit_v2"
                                                    className="mr-2"
                                                    control={
                                                        <Checkbox
                                                            checked={data.relatedCauseCode1}
                                                            value={"EM"}
                                                            onChange={e => { props.setClaimEntryData({ ...data, relatedCauseCode1: e.target.checked ? e.target.value : null }) }}
                                                            name="visitAccidentEmployment"
                                                            color="primary"
                                                            inputProps={{ 'id': 'visit_accident_employment' }}
                                                        />
                                                    }
                                                    label="Employment"
                                                />
                                                <FormControlLabel
                                                    id="auto_visit_v2"
                                                    className="mr-2"
                                                    control={
                                                        <Checkbox
                                                            checked={data.relatedCauseCode2}
                                                            value={"AA"}
                                                            onChange={e => { props.setClaimEntryData({ ...data, relatedCauseCode2: e.target.checked ? e.target.value : null }) }}
                                                            name="visitAccidentAuto"
                                                            color="primary"
                                                            inputProps={{ 'id': 'visit_accident_auto' }}
                                                        />
                                                    }
                                                    label="Auto"
                                                />
                                                <FormControlLabel
                                                    id="others_visit_v2"
                                                    className="mr-2"
                                                    control={
                                                        <Checkbox
                                                            checked={data.relatedCauseCode3}
                                                            value={"OA"}
                                                            onChange={e => { props.setClaimEntryData({ ...data, relatedCauseCode3: e.target.checked ? e.target.value : null }) }}
                                                            name="visitAccidentOther"
                                                            color="primary"
                                                            inputProps={{ 'id': 'visit_accident_other' }}
                                                        />
                                                    }
                                                    label="Other"
                                                />
                                            </FormGroup>
                                        </div>
                                    </div>
                                </div>
                                <Divider />
                                <div className="form-wrapper wrap-form-label px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="accident_state_visit"
                                            label="Accident State"
                                            placeholder=""
                                            value={
                                                data.enterpriseClaimAux ? data.enterpriseClaimAux.accidentStateCode ? data.enterpriseClaimAux.accidentStateCode : "" : ""
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, enterpriseClaimAux: { ...data.enterpriseClaimAux, accidentStateCode: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                        />
                                    </div>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="accident_or_IllnessDate_visit"
                                                label="Accident / Illness Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    props.accidentIllnessDate ? props.accidentIllnessDate : null
                                                }
                                                helperText={props.errors.accidentIllErr ? ErrorConst.VISIT_ILLNESS_ERROR : null}
                                                error={props.errors.accidentIllErr}
                                                onChange={dt => { props.setAccidentIllnessDate(dt); }}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="unable_to_work_bg_visit"
                                                label="Unable to Work Begin Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={data.professionalClaim.unableToWorkFromDate ? data.professionalClaim.unableToWorkFromDate : null}
                                                helperText={props.errors.unWorkBeginDateErr ? ErrorConst.UNABLE_WORK_BEGIN_ERR : null}
                                                error={props.errors.unWorkBeginDateErr}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "professionalClaim": { ...data.professionalClaim, "unableToWorkFromDate": (dt ? isNaN(dt.getTime()) ? val : dt : val) } }); }}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="unable_to_work_en_visit"
                                                label="Unable to Work End Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={data.professionalClaim.unableToWorkToDate ? data.professionalClaim.unableToWorkToDate : null}
                                                helperText={props.errors.unWorkEndDateErr ? ErrorConst.UNABLE_WORK_END_ERR : null}
                                                error={props.errors.unWorkEndDateErr}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "professionalClaim": { ...data.professionalClaim, "unableToWorkToDate": (dt ? isNaN(dt.getTime()) ? val : dt : val) } }); }}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="hospital_bg_visit"
                                                label="Hospital Begin"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={data.admitDateTime ? data.admitDateTime : null}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "admitDateTime": (dt ? isNaN(dt.getTime()) ? val : dt : val) }); }}
                                                helperText={props.errors.hospBeginErr ? ErrorConst.VISIT_HOSP_BEGIN_ERR : null}
                                                error={props.errors.hospBeginErr}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="hospital_en_visit"
                                                label="Hospital End"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={data.dischargeDateTime ? data.dischargeDateTime : null}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "dischargeDateTime": (dt ? isNaN(dt.getTime()) ? val : dt : val) }); }}
                                                helperText={props.errors.hospEndErr ? ErrorConst.VISIT_HOSP_END_ERR : null}
                                                error={props.errors.hospEndErr}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <div className="mui-custom-form input-md">
                                        <FormControlLabel
                                            id="emp_visit_v2"
                                            className="m-0 set-no-pading input-check-label"
                                            control={
                                                <Checkbox
                                                    checked={data.professionalClaim && data.professionalClaim.outlabIndicator ? true : false}
                                                    value={
                                                        data.professionalClaim && data.professionalClaim.outlabIndicator ? data.professionalClaim.outlabIndicator : ""
                                                    }
                                                    onChange={e => { props.setClaimEntryData({ ...data, professionalClaim: { ...data.professionalClaim, outlabIndicator: e.target.checked ? true : null } }) }}
                                                    name="outlabIndicator"
                                                    color="primary"
                                                    inputProps={{ 'id': 'visit_accident_employment' }}
                                                />
                                            }
                                            label="Out Lab / Amt"
                                        />
                                        <TextField
                                            className="wrap-label-margin"
                                            id="out_lab_amt_visit"
                                            label=""
                                            placeholder=""
                                            value={
                                                data.professionalClaim && data.professionalClaim.outlabAmount ? data.professionalClaim.outlabAmount : ""
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, professionalClaim: { ...data.professionalClaim, outlabAmount: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 12 }}
                                            helperText={props.errors.outLabAmtErr ? ErrorConst.OUT_LAB_AMT_ERR : null}
                                            error={props.errors.outLabAmtErr}
                                            InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">$</InputAdornment>
                                                ),
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper wrap-form-label px-0 pt-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="subSvcAuthId_visit"
                                            label="Sub Svc Auth ID"
                                            placeholder=""
                                            value={
                                                data.claimServiceAuthorization && data.claimServiceAuthorization.submittedServiceAuthID ? data.claimServiceAuthorization.submittedServiceAuthID : ""
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, claimServiceAuthorization: { ...data.claimServiceAuthorization, submittedServiceAuthID: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 12 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="referralId_visit"
                                            label="Referral ID"
                                            placeholder=""
                                            value={
                                                data.referralID ? data.referralID : ""
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, referralID: e.target.value }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 12 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="anesthesia_pc_poc_visit"
                                            label="Anesthesia Principal Proc Code"
                                            placeholder=""
                                            value={
                                                data.enterpriseClaimAux && data.enterpriseClaimAux.anesthesiaRelatedProcCode1 ? data.enterpriseClaimAux.anesthesiaRelatedProcCode1 : ""
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, enterpriseClaimAux: { ...data.enterpriseClaimAux, anesthesiaRelatedProcCode1: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 12 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="anesthesia_ot_poc_visit"
                                            label="Anesthesia Other Proc Code"
                                            placeholder=""
                                            value={
                                                data.enterpriseClaimAux && data.enterpriseClaimAux.anesthesiaRelatedProcCode2 ? data.enterpriseClaimAux.anesthesiaRelatedProcCode2 : ""
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, enterpriseClaimAux: { ...data.enterpriseClaimAux, anesthesiaRelatedProcCode2: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 12 }}
                                        />
                                    </div>
                                </div>
                            </div>
                            <div id="Diagnosis Codes Div Id">
                                <DiagnosisCodes
                                    data={data}
                                    setClaimEntryData={props.setClaimEntryData}
                                    diagnosis={props.diagnosis} setDiagnosis={props.setDiagnosis}
                                    setConditionCodes={props.setConditionCodes}
                                    clearDiagnosis={props.clearDiagnosis} setClearDiagnosis={props.setClearDiagnosis}
                                    updateDiagnosis={props.updateDiagnosis}
                                    addDropdowns={props.addDropdowns}
                                    seterrorMessages={props.seterrorMessages} />
                            </div>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>
            </div>
        </div>
    )
}

export default Visit;