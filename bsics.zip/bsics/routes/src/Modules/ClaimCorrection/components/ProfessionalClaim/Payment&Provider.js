import React, { useEffect, useState, useRef } from "react";
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import Checkbox from '@material-ui/core/Checkbox';
import InputAdornment from '@material-ui/core/InputAdornment';
import MenuItem from '@material-ui/core/MenuItem';
import * as Dropdowns from '../../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS } from '../../../../SharedModules/Dropdowns/actions';
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import { useDispatch, useSelector } from 'react-redux';
import TableComponent from '../../../../SharedModules/Table/Table';
import { Button } from 'react-bootstrap';
import { Divider } from "@material-ui/core";
import BaseRateChanges from "../../../ClaimsEntry/Components/DentalClaim/LineItems/baseRateChanges.js";
import dateFnsFormat from "date-fns/format";
import * as ErrorConst from "../../../../SharedModules/Messages/ErrorMsgConstants";
import { useConfirm } from '../../../../SharedModules/MUIConfirm/index';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import moment from 'moment';
const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));
const headCells = [
    { id: "lineNumber", numeric: false, disablePadding: true, label: 'Line #', enableHyperLink: true, fontSize: 12 },
    { id: "providerRoleCodeDesc", numeric: false, disablePadding: true, label: 'Prov Role', enableHyperLink: false, fontSize: 12 },
    { id: "providerIDTypeDesc", numeric: false, disablePadding: true, label: 'Prov ID Type', enableHyperLink: false, fontSize: 12 },
    { id: "providerID", numeric: false, disablePadding: true, label: 'Prov ID', enableHyperLink: true, fontSize: 12 },
    { id: "providerTaxonomyCode", numeric: false, disablePadding: true, label: 'Taxonomy', enableHyperLink: false, fontSize: 12 },
    { id: "providerTypeCodeDesc", numeric: false, disablePadding: true, label: 'Prov Type', enableHyperLink: false, fontSize: 12 },
    { id: "providerSpecialityCodeDesc", numeric: false, disablePadding: true, label: 'Prov Spec', enableHyperLink: false, fontSize: 12 },
    { id: "sysID", numeric: false, disablePadding: true, label: 'P_SYS_ID', enableHyperLink: false, isIconShuffle: true, fontSize: 12 },
    { id: "prcsSelectionCodeDesc", numeric: false, disablePadding: true, label: 'HC', enableHyperLink: false, fontSize: 12 },
    { id: "providerUsedIndicator", numeric: false, disablePadding: true, label: 'Used', enableHyperLink: false, isIcon: true, fontSize: 12 },
    { id: "submittedProviderIDIndicator", numeric: false, disablePadding: true, label: 'Subm', enableHyperLink: false, isIcon: true, fontSize: 12 },
];
const sysHeadCells = [
    {
        id: 'sysID', numeric: false, disablePadding: true, isRadio: true, isRadioEnabled: true, label: 'Select', enableHyperLink: false, fontSize: 12
    },
    { id: "sysID", numeric: false, disablePadding: true, label: 'P_SYS_ID', enableHyperLink: true, fontSize: 12 },
    { id: "npiNum", numeric: false, disablePadding: true, label: 'NPI', enableHyperLink: false, fontSize: 12 },
    { id: "medicadeID", numeric: false, disablePadding: true, label: 'Medicaid ID', enableHyperLink: false, fontSize: 12 },
    { id: "beginDate", numeric: false, disablePadding: true, label: 'Begin Date', enableHyperLink: false, fontSize: 12 },
    { id: "endDate", numeric: false, disablePadding: true, label: 'End Date', enableHyperLink: false, fontSize: 12 },
    { id: "providerName", numeric: false, disablePadding: true, label: 'Provider Name', enableHyperLink: false, fontSize: 12 },
    { id: "addressLine1", numeric: false, disablePadding: true, label: 'Address', enableHyperLink: false, fontSize: 12 },
    { id: "providerType", numeric: false, disablePadding: true, label: 'Provider Type', enableHyperLink: false, fontSize: 12 },
    { id: "taxonomy", numeric: false, disablePadding: true, label: 'Taxonomy', enableHyperLink: false, fontSize: 12 },
];
function PaymentProvider(props) {
    const classes = useStyles();
    const dispatch = useDispatch();
    const muiconfirm = useConfirm();
    const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values, "paymentProviderDropDowns"));
    const addDropdowns = useSelector(state => state.appDropDowns.paymentProviderDropDowns);
    const [showForm, setShowForm] = useState(false);
    const [showSYS_ID, setShowSYS_ID] = useState(false);
    const [formData, setFormData] = useState({});
    const [resetFormData, setResetFormData] = useState({});
    const [sysFormData, setSysFormData] = useState({});
    const [selectedSP, setSelectedSP] = useState([]);
    const [sysList, setSysList] = useState([]);
    const [{ provRoleErr, provIDErr, duplicateErr, provLineErr }, setErrors] = useState(false);
    const [success, setSuccess] = useState(false);
    const data = props.data;
    useEffect(() => {
        onDropdowns([Dropdowns.PAYEE_TYPE, Dropdowns.PROV_ROLE, Dropdowns.PROV_ID_TYPE]);
    }, []);
    const handleAmountInputChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };
    
    const editSubmittedProvider = row => (event) => {
        if (row.providerID == event.target.innerText) {
            window.open(`/ProviderInquiry?providerID=${row.providerID}&providerIDType=${row.providerIDType}`, "_blank");
            return false;
        }
        setFormData(row);
        setResetFormData(row);
        setShowForm(true);
        props.seterrorMessages([]);
        setErrors({});
    };
    const handleShuffle = row => (event) => {
        setSysFormData(row);
        setShowSYS_ID(true);
        setSysList(row.submittedProviderSet ? row.submittedProviderSet : []);
        setTimeout(function () {
            scrollToRef(addSYS_IDRef);
        }.bind(this), 1000);
        event.stopPropagation();
        return false;
    };
    const getTableData = () => {
        let dd = data.claimProviderID ? data.claimProviderID : [];
        if (dd && dd.length) {
            let tData = JSON.stringify(dd);
            tData = JSON.parse(tData);
            tData.map((each, index) => {
                each.index = index;
            });
            return tData;
        } else {
            return [];
        }
    };
    const addSubmittedProvider = () => {
        setShowForm(true);
        setTimeout(function () {
            scrollToRef(addSubmitProvRef);
        }.bind(this), 1000);
        setFormData({lineNumber: 0});
        setResetFormData({lineNumber: 0});
        setSuccess(false);
        props.seterrorMessages([]);
        setErrors({});
        props.setsuccessMessages([]);
    };
    const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        if (new Date(dt).toString() == "Invalid Date" || dt.length < 10) {
            return dt;
        } else {
            return dateFnsFormat(new Date(dt), "MM/dd/ccyy");
        }
    };
    const handelMultiDelete = () => {
        setSuccess(false);
        setShowForm(false);
        setShowSYS_ID(false);
        props.setsuccessMessages([]);
        muiconfirm({ title: "", description: 'Are you sure that you want to delete?', dialogProps: { fullWidth: false } })
            .then(() => {
                const t = data.claimProviderID ? data.claimProviderID : [];
                // for (let i = 0; i < selectedSP.length; i++) {
                //     t.splice(selectedSP[i].index, 1);
                // }
                let tdata = [];
                t.map((each, index) => {
                    if (selectedSP.filter(eachDelete => index == eachDelete.index).length == 0) {
                        return tdata.push(each);
                    }
                });
                props.setClaimEntryData({ ...data, claimProviderID: tdata });
                let totalLineitemData = JSON.parse(JSON.stringify(props.lineItemDate));
                totalLineitemData.map((eachLine) => {
                    let updatedsp = [];
                    eachLine.claimSubmittedProvider.map(eachsp => {
                        if (selectedSP.findIndex(each => each.lineNumber == eachsp.lineNumber && each.providerRoleCode == eachsp.providerRoleCode && each.providerIDType == eachsp.providerIDType) == -1) {
                            updatedsp.push(eachsp);
                        }
                    });
                    eachLine.claimSubmittedProvider = updatedsp;
                });
                props.setLineItemData(totalLineitemData);
                //setSuccess(true);
                //props.setsuccessMessages([ErrorConst.SUCCESSFULLY_SAVED_INFORMATION]);
                setSelectedSP([]);
            });
    };
    const handleTotalAmountInputChange = (e) => {
        let t = e.target.getAttribute("inputType");
        if(t == "number" && /^[0-9\b]+$/.test(e.target.value) || t == "text" && /^[a-zA-Z\s]*$/.test(e.target.value) || t!="text" && t!="number" || e.target.value == ""){
        // if(/^([0-9]{1,13}|[0-9]{1,13}\.|[0-9]{1,13}\.[0-9]{1,2})$/.test(e.target.value)){
            props.setClaimEntryData({ ...data, totalChargeAmount: e.target.value });
        }
     };
     const handleNetAmountInputChange = (e) => {
        let t = e.target.getAttribute("inputType");
        if(t == "number" && /^[0-9\b]+$/.test(e.target.value) || t == "text" && /^[a-zA-Z\s]*$/.test(e.target.value) || t!="text" && t!="number" || e.target.value == ""){
        // if(/^([0-9]{1,13}|[0-9]{1,13}\.|[0-9]{1,13}\.[0-9]{1,2})$/.test(e.target.value)){
            props.setClaimEntryData({ ...data, totalNetChargeAmount: e.target.value });
        }
     };
     const handelDuplicateCheck = (submittedProviderArray, lineNumber, providerRole, providerType) => {
        if (submittedProviderArray.length > 0) {
            const result = submittedProviderArray.map((each) => {
                  if (each.lineNumber == lineNumber && each.providerRoleCode == providerRole && each.providerIDType == providerType) {
                    return true;
                  }
                  return false;
              });
              if (result.filter((e) => e === true).length > 0) {
                return true;
              } else {
                return false;
              }
        } else {
            return false
        }
    };
    const lineItemSave = async () => {
        setErrors(false);
        setSuccess(false);
        props.setsuccessMessages([]);
        props.seterrorMessages([]);
        let errors = {};
        let err = [];
        let totalLineitemData = JSON.parse(JSON.stringify(props.lineItemDate));
        let totalLineData = JSON.parse(JSON.stringify(props.lineItemDate));
        let submittedProviderData = [];
        submittedProviderData.push(...JSON.parse(JSON.stringify(data.claimProviderID)));
        totalLineData.map((each) => {
            each.claimSubmittedProvider ? submittedProviderData.push(...JSON.parse(JSON.stringify(each.claimSubmittedProvider))) : submittedProviderData;
        });
        if (formData.index>-1) {
            let filterData = submittedProviderData.filter(each => each.lineNumber == resetFormData.lineNumber && each.providerRoleCode == resetFormData.providerRoleCode && each.providerIDType == resetFormData.providerIDType ? false : true)
            submittedProviderData = filterData;
        }
        const duplicateCheck = await handelDuplicateCheck(submittedProviderData, formData.lineNumber, formData.providerRoleCode, formData.providerIDType);
        if (formData.lineNumber==null || formData.lineNumber < "-1") {
            errors["provLineErr"] = true;
            err.push(ErrorConst.LINE_REQ);
        }
        if (!formData.providerRoleCode || formData.providerRoleCode == "-1") {
            errors["provRoleErr"] = true;
            err.push(ErrorConst.PROV_ROLE_INVALID);
        }
        if (!formData.providerIDType || formData.providerIDType == "-1") {
            errors["provIDErr"] = true;
            err.push(ErrorConst.PROV_ID_INVALID);
        }
        if (formData.providerRoleCode != "-1" && formData.providerIDType != "-1" && duplicateCheck) {
            errors["duplicateErr"] = true;
            err.push(ErrorConst.SUBMITTED_DUPL_ROWS);
        }

        if (err.length) {
            setErrors(errors);
            props.seterrorMessages(err);
            return false;
        }
        let claimProvider = {
            "auditUserID": formData.auditUserID ? formData.auditUserID : null,
            "auditTimeStamp": null,
            "addedAuditUserID": null,
            "addedAuditTimeStamp": null,
            "versionNo": formData.versionNo ? formData.versionNo : 0,
            "lineNumber": formData.lineNumber,
            "providerRoleCode": formData.providerRoleCode,
            "providerRoleCodeDesc": formData.providerRoleCodeDesc,
            "providerIDType": formData.providerIDType,
            "providerIDTypeDesc": formData.providerIDTypeDesc,
            "providerID": formData.providerID,
            "providerUsedIndicator": formData.providerUsedIndicator?formData.providerUsedIndicator:false,
            "movedFromHeader": formData.movedFromHeader ? formData.movedFromHeader : false,
            "sysID": formData.sysID,
            "providerDescription": formData.providerDescription,
            "submittedProviderIDIndicator": formData.submittedProviderIDIndicator?formData.submittedProviderIDIndicator:true,
            "submittedProviderSet": formData.submittedProviderSet ? formData.submittedProviderSet : [],
            "prcsSelectionCode": formData.prcsSelectionCode,
            "prcsSelectionCodeDesc": formData.prcsSelectionCodeDesc,
            "prcsSelectionSystemListNumber": formData.prcsSelectionSystemListNumber ? formData.prcsSelectionSystemListNumber : null,
            "providerTypeCode": formData.providerTypeCode ? formData.providerTypeCode : null,
            "orderingProvInSysList": formData.orderingProvInSysList ? formData.orderingProvInSysList : false,
            "referringProvInSysList": formData.referringProvInSysList ? formData.referringProvInSysList : false,
            "providerType": formData.providerRoleCode,
            "providerTypeDesc": formData.providerRoleCodeDesc,
            "providerSpecialityCode": formData.providerSpecialityCode ? formData.providerSpecialityCode : null,
            "providerSpecialityCodeDesc": formData.providerSpecialityCodeDesc ? formData.providerSpecialityCodeDesc : null,
            "providerTaxonomyCode": formData.providerTaxonomyCode ? formData.providerTaxonomyCode : null
        };
        let claimProviderID = data.claimProviderID ? data.claimProviderID : [];
        formData.index > -1 ? claimProviderID[formData.index] = claimProvider : claimProviderID.push(claimProvider);
        props.setClaimEntryData({ ...data, claimProviderID: claimProviderID });
        
        totalLineitemData.map((eachLine) => {
            let itemIndex = eachLine.claimSubmittedProvider ? eachLine.claimSubmittedProvider.findIndex(each => each.lineNumber == resetFormData.lineNumber && each.providerRoleCode == resetFormData.providerRoleCode && each.providerIDType == resetFormData.providerIDType) : -1;
            if (itemIndex > -1) {
                eachLine.claimSubmittedProvider[itemIndex] = claimProvider;
            }
        });
        props.setLineItemData(totalLineitemData);
        setShowForm(false);
        //setSuccess(true);
        //props.setsuccessMessages([ErrorConst.SUCCESSFULLY_SAVED_INFORMATION]);
    };
    // ADD anchoring start
    const addSubmitProvRef = useRef(null);
    const addSYS_IDRef = useRef(null);
    const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
    const [sysFormData_sysID, setSysFormData_sysID] = useState(null);
    // ADD anchoring end
    const sysIdSelection = () => {
        data.claimProviderID[sysFormData.index] = { ...sysFormData, sysID: sysFormData_sysID };
        props.setClaimEntryData({ ...data, claimProviderID: data.claimProviderID });
        setShowForm(false);
        setShowSYS_ID(false);
       //setSuccess(true);
        //props.setsuccessMessages([ErrorConst.SUCCESSFULLY_SAVED_INFORMATION]);
    };

    const sysIDEdit = row => (event) => {
        setSysFormData_sysID(row.sysID);
    };
    const [extension,setExtension] = useState(data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider &&
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.zipCode?
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.zipCode.substr(5,4) : "");
    const [zip,setZip] = useState(data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider &&
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.zipCode?
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.zipCode.substr(0,5) : '');
    const [extension1,setExtension1] = useState(data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility &&
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.zipCode?
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.zipCode.substr(5,4) : "");
    const [zip1,setZip1] = useState(data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility && 
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.zipCode?
        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.zipCode.substr(0,5) : "");
    const [addressType,setAddressType] = useState("");
    useEffect(() => {
        if(addressType == "billingProvider"){
            props.setClaimEntryData({ ...data, enterpriseClaimAux: 
                { ...data.enterpriseClaimAux, c837ClaimHdr: 
                    { ...data.enterpriseClaimAux.c837ClaimHdr, c837ClaimProvider: 
                        {...data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider, [addressType]: 
                            { ...data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider[addressType], zipCode: (zip+extension) } } } } });
        }else if(addressType == "serviceFacility"){
            props.setClaimEntryData({ ...data, enterpriseClaimAux: 
                { ...data.enterpriseClaimAux, c837ClaimHdr: 
                    { ...data.enterpriseClaimAux.c837ClaimHdr, c837ClaimProvider: 
                        {...data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider, [addressType]: 
                            { ...data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider[addressType], zipCode: (zip1+extension1)} } } } });
        }
    },[extension,zip,extension1,zip1]);    
    const addressChange = async (e,type) => {
        setAddressType(type);
        if(e.target.name == "extension" && type == "billingProvider"){
            setExtension(e.target.value);          
        }
        else if(e.target.name == "zip" && type == "billingProvider"){
            setZip(e.target.value); 
        }
        else if(e.target.name == "extension"  && type == "serviceFacility"){
            setExtension1(e.target.value); 
        }
        else if(e.target.name == "zip" && type == "serviceFacility"){
            setZip1(e.target.value); 
        }else{
            props.setClaimEntryData({ ...data, enterpriseClaimAux: 
                { ...data.enterpriseClaimAux, c837ClaimHdr: 
                    { ...data.enterpriseClaimAux.c837ClaimHdr, c837ClaimProvider: 
                        {...data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider, [type]: 
                            { ...data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider[type], [e.target.name]: e.target.value } } } } });   
        }        
    };
    return (
        <div className="pos-relative">
            <div className="tabs-container custom-panel">
                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="payment_and_provider"
                            id="payment_and_provider">
                            <Typography className={classes.heading}>Payment &amp; Provider</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <div className="form-wrapper form-3-column px-0">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="pp_patient_account#"
                                        name="patientAccountNumber"
                                        label="Patient Account #"
                                        placeholder=""
                                        value={data.patientAccountNumber ? data.patientAccountNumber : null}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, patientAccountNumber: e.target.value }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 38 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="pp_medical_record#"
                                        name="medicalRecordNumber"
                                        label="Medical Record #"
                                        placeholder=""
                                        value={data.payment && data.payment.medicalRecordNumber ? data.payment.medicalRecordNumber : ""}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, payment: { ...data.payment, medicalRecordNumber: e.target.value } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 30 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <div className="cndt-row">
                                        <div className="cndt-col-2">
                                            <Checkbox
                                                checked={data.payment && data.payment.signIndicator ? data.payment.signIndicator : false}
                                                value={data.payment ? data.payment.signIndicator : null}
                                                onChange={(e) => { props.setClaimEntryData({ ...data, payment: { ...data.payment, signIndicator: e.target.checked } }); }}
                                                name="signIndicator"
                                                style={{ marginTop: '25px' }}
                                                color="primary"
                                                inputProps={{ id: "pp_sing_indicator" }}
                                                inputProps={{ maxLength: 1 }}
                                            />
                                        </div>
                                        {/* <div className="cndt-col-10"> */}
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="cndt-col-10">
                                                    <KeyboardDatePicker
                                                        id="pp_sign_date"
                                                        name="billedDate"
                                                        label="Sign / Date"                                                        
                                                        format="MM/dd/yyyy"
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}    
                                                        placeholder="mm/dd/yyyy"                                                    
                                                        value={
                                                            props.dates && props.dates.billedDate ? props.dates.billedDate : null
                                                        }
                                                        helperText={props.errors.billedDateErr ? ErrorConst.BILLED_DATE_ERR : null}
                                                        error={props.errors.billedDateErr}
                                                        onChange={dt => { props.setInputDates({...props.dates,"billedDate":(dt ? isNaN(dt.getTime())?null:dt : null)}); }}                                                        
                                                        KeyboardButtonProps={{
                                                            "aria-label": "change date"
                                                        }}
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>
                                        {/* </div> */}
                                       
                                    </div>


                                </div>
                            </div>
                            <div className="form-wrapper form-4-column px-0">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="pp_total_charge"
                                        label="Total Charge"
                                        placeholder=""
                                        value={data.totalChargeAmount}
                                        onChange={handleTotalAmountInputChange}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                        inputProps={{ maxLength: 16 }}
                                        helperText={props.errors.payTotalChrgErr ? ErrorConst.PAYMENT_TOTAL_CHRG_ERR : null}
                                        error={props.errors.payTotalChrgErr}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="pp_tpl_amt"
                                        label="TPL Amt"
                                        disabled
                                        placeholder=""
                                        value={data.totalTPLAmount}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, totalTPLAmount: e.target.value }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                        inputProps={{ maxLength: 16 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="pp_net_amt"
                                        label="Net Amt"
                                        placeholder=""
                                        value={data.totalNetChargeAmount}
                                        onChange={handleNetAmountInputChange}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                        inputProps={{ maxLength: 16 }}
                                        helperText={props.errors.payNetAmtErr ? ErrorConst.PAYMENT_NET_AMT_ERR : null}
                                        error={props.errors.payNetAmtErr}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="pp_reimbursement"
                                        label="Reimbursement"
                                        disabled
                                        placeholder=""
                                        value={data.payment ? data.payment.reimbursementAmount : null}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, payment: { ...data.payment, reimbursementAmount: e.target.value } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                        inputProps={{ maxLength: 16 }}
                                    />
                                </div>
                            </div>
                            <div className="form-wrapper form-4-column px-0">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="pp_tax_id_ssn"
                                        label="Tax ID / SSN"
                                        placeholder=""
                                        value={data.billingFedaralTaxID}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, billingFedaralTaxID: e.target.value }); }}
                                        inputProps={{ maxLength: 9 }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="pp_fcn"
                                        label="FCN"
                                        placeholder=""
                                        value={data.payment && data.payment.fcn ? data.payment.fcn : ""}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, payment: { ...data.payment, fcn: e.target.value } }); }}
                                        inputProps={{ maxLength: 14 }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        select
                                        id="pp_payee_type"
                                        label="Payee Type"
                                        placeholder=""
                                        value={data.payeeEntityExtlIdTypeCode ? data.payeeEntityExtlIdTypeCode : "-1"}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, payeeEntityExtlIdTypeCode: e.target.value }); }}
                                        inputProps={{ maxLength: 1 }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    >
                                        <MenuItem selected key="Please Select One" value="-1">
                                            Please Select One
                        </MenuItem>
                                        {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#G_CMN_ENTY_TY_CD'] && addDropdowns['Claims#G_CMN_ENTY_TY_CD'].map(each => (
                                            (each.code == "M" || each.code == "P") ? <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem> : null
                                        ))}
                                    </TextField>
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="pp_payee_id"
                                        label="Payee ID"
                                        placeholder=""
                                        value={data.payeeEntityExtlId}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, payeeEntityExtlId: e.target.value }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form with-select input-md" >
                                    <label className="MuiFormLabel-root MuiInputLabel-shrink">Co-Pay Waiver:</label>
                                    <div className="sub-radio mt-0">
                                        <RadioGroup
                                            row
                                            value={data.copayExclusionCode ? data.copayExclusionCode : "N"}
                                            onChange={(e) => { props.setClaimEntryData({ ...data, copayExclusionCode: e.target.value }); }}
                                            aria-label="Copay_Waiver"
                                            name="Copay_Waiver">
                                            <FormControlLabel
                                                disabled
                                                value='Y'
                                                id="pp_co_pay_waiver_yes"
                                                control={<Radio color="primary" />}
                                                label="Yes"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                            />
                                            <FormControlLabel
                                                disabled
                                                value='N'
                                                id="pp_co_pay_waiver_no"
                                                control={<Radio color="primary" />}
                                                label="No"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                            />

                                        </RadioGroup>
                                    </div>
                                </div>
                            </div>

                            <Divider />

                            <div className="tabs-container pt-2">
                                <div className="tab-header">
                                    <div className="tab-heading float-left">
                                        Medicare
                                    </div>
                                </div>
                                <div className="tab-body-bordered">
                                    <form autoComplete="off">
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_med_allow_amt"
                                                    name='allowedAmount'
                                                    label="Allow Amt"
                                                    value={data.medicareDetails ? data.medicareDetails.allowedAmount : null}
                                                    onChange={(e) => { props.setClaimEntryData({ ...data, "medicareDetails": { ...data.medicareDetails, "allowedAmount": e.target.value } }); }}
                                                    inputProps={{ maxLength: 14 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                    helperText={props.errors.medAllowAmtInvErr ? ErrorConst.MEDCAIR_ALLOW_AMT_INV : null}
                                                    error={props.errors.medAllowAmtInvErr}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_med_deductible_amt"
                                                    name='deductibleAmount'
                                                    label="Deduct Amt"
                                                    value={data.medicareDetails ? data.medicareDetails.deductibleAmount : null}
                                                    onChange={(e) => { props.setClaimEntryData({ ...data, "medicareDetails": { ...data.medicareDetails, "deductibleAmount": e.target.value } }); }}
                                                    inputProps={{ maxLength: 14 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    helperText={props.errors.medDeductAmtInvErr ? ErrorConst.MEDI_DEDUCT_AMT_INV : null}
                                                    error={props.errors.medDeductAmtInvErr}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_med_coInsurance_amt"
                                                    name='coInsuranceAmount'
                                                    label="Coins Amt"
                                                    value={data.medicareDetails ? data.medicareDetails.coInsuranceAmount : null}
                                                    onChange={(e) => { props.setClaimEntryData({ ...data, "medicareDetails": { ...data.medicareDetails, "coInsuranceAmount": e.target.value } }); }}
                                                    inputProps={{ maxLength: 14 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    helperText={props.errors.medCoinsAmtInvErr ? ErrorConst.MEDI_COINS_AMT_INV : null}
                                                    error={props.errors.medCoinsAmtInvErr}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_med_paid_amt"
                                                    name='paidAmount'
                                                    label="Paid Amt"
                                                    value={data.medicareDetails ? data.medicareDetails.paidAmount : null}
                                                    onChange={(e) => { props.setClaimEntryData({ ...data, "medicareDetails": { ...data.medicareDetails, "paidAmount": e.target.value } }); }}
                                                    inputProps={{ maxLength: 14 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    helperText={props.errors.medPaidAmtInvErr ? ErrorConst.MEDI_PAID_AMT_INV : null}
                                                    error={props.errors.medPaidAmtInvErr}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_med_mic"
                                                    name='mic'
                                                    label="MIC"
                                                    value={data.payment ? data.payment.mic : ""}
                                                    onChange={(e) => { props.setClaimEntryData({ ...data, "payment": { ...data.payment, "mic": e.target.value } }); }}
                                                    inputProps={{ maxLength: 10 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>                                            
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        id="pp_med_eombDate"
                                                        label="EOMB Date"
                                                        format="MM/dd/yyyy"
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        placeholder="mm/dd/yyyy"
                                                        value={data.payment && data.payment.eombDate ? data.payment.eombDate
                                                                : null}
                                                        helperText={props.errors.medEombDateErr ? ErrorConst.EOMB_DATE_INV : null}
                                                        error={props.errors.medEombDateErr}
                                                        onChange={dt => { props.setClaimEntryData({ ...data, "payment": { ...data.payment, "eombDate": (dt ? isNaN(dt.getTime())?null:dt : null) } }); }}
                                                        KeyboardButtonProps={{
                                                            "aria-label": "change date"
                                                        }}                               
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>
                                        </div>
                                    </form>
                                </div>
                            </div>

                            <BaseRateChanges values={{ "baseRateChangeInfo": data.baseRateChangeInfo ? data.baseRateChangeInfo : [] }} />

                            <div className="tab-body-bordered inner-bdr-wrap">
                                {success ? (
                                    <div className="alert alert-success custom-alert" role="alert">
                                        {ErrorConst.SUCCESSFULLY_SAVED_INFORMATION}
                                    </div>
                                ) : null}
                                <div className="tab-header">
                                    <div className="tab-heading float-left">
                                        Submitted Providers
                                    </div>
                                    <div className="float-right th-btnGroup">
                                        <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectedSP.length == 0} onClick={() => handelMultiDelete()} >
                                            <i className="fa fa-trash" />
                                        </Button>
                                        <Button title="Add submitted provider" variant="outlined" color="primary" className="btn btn-secondary btn-icon-only" onClick={addSubmittedProvider}>
                                            <i className="fa fa-plus" />
                                        </Button>
                                    </div>
                                </div>
                                {duplicateErr ? (
                                    <div className="alert alert-danger custom-alert" role="alert">
                                        <li>{ErrorConst.SUBMITTED_DUPL_ROWS}</li>
                                    </div>
                                    ) : null }
                                <TableComponent headCells={headCells} selected={selectedSP} setSelected={setSelectedSP} multiDelete onTableRowClick={editSubmittedProvider} handleShuffle={handleShuffle} tableData={getTableData()} sortOrder="desc" defaultSortColumn="lineNumber" />
                                {showForm ? (
                                    <div className="tabs-container tabs-container-inner" ref={addSubmitProvRef}>
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left">
                                                {formData.index > -1 ? "Edit" : "Add"} Submitted Provider
                                            </h2>
                                            <div className="float-right th-btnGroup">
                                                <Button title={formData.index > -1 ? 'Update' : 'Add'} className='btn btn-ic btn-add' onClick={() => lineItemSave()}>
                                                {formData.index > -1 ? 'Update' : 'Add'}
                                                </Button>
                                                <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => setFormData({})}>
                                                Reset
                                                </Button>
                                                <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => setShowForm(false)}>
                                                Cancel
                                                </Button>
                                            </div>
                                        </div>
                                        <div className="mt-0">
                                            <form autoComplete="off">
                                                <div className="form-wrapper">
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            id="sp_line#id"
                                                            name='lineNumber'
                                                            label="Line #"
                                                            value={formData.lineNumber > -1 ? formData.lineNumber : ""}
                                                            onChange={handleAmountInputChange}
                                                            inputProps={{ maxLength: 5 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            helperText={provLineErr ? ErrorConst.LINE_REQ : null}
                                                            error={provLineErr}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            select
                                                            id="sp_prov_role_id"
                                                            name='providerRoleCode'
                                                            label="Prov Role"
                                                            value={formData.providerRoleCode ? formData.providerRoleCode : "-1"}
                                                            onChange={(e) => { setFormData({ ...formData, [e.target.name]: e.target.value, providerRoleCodeDesc: e.nativeEvent.target.innerText }); }}
                                                            inputProps={{ maxLength: 2 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            helperText={provRoleErr ? ErrorConst.PROV_ROLE_INVALID : null}
                                                            error={provRoleErr}
                                                        >
                                                            <MenuItem selected key="Please Select One" value="-1">
                                                                Please Select One
                                            </MenuItem>
                                                            {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#C_PROV_ROLE_CD'] && addDropdowns['Claims#C_PROV_ROLE_CD'].map(each => (
                                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                                            ))}
                                                        </TextField>
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            select
                                                            id="sp_prov_id_type_id"
                                                            name='providerIDType'
                                                            label="Prov ID Type"
                                                            value={formData.providerIDType ? formData.providerIDType : "-1"}
                                                            onChange={(e) => { setFormData({ ...formData, [e.target.name]: e.target.value, providerIDTypeDesc: e.nativeEvent.target.innerText }); }}
                                                            inputProps={{ maxLength: 3 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            helperText={provIDErr ? ErrorConst.PROV_ID_INVALID : null}
                                                            error={provIDErr}
                                                        >
                                                            <MenuItem selected key="Please Select One" value="-1">
                                                                Please Select One
                                            </MenuItem>
                                                            {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#P_ALT_ID_SRC_TY_CD'] && addDropdowns['Claims#P_ALT_ID_SRC_TY_CD'].map(each => (
                                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                                            ))}
                                                        </TextField>
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            id="sp_prov_id_id"
                                                            name='providerID'
                                                            label="Prov ID"
                                                            value={formData.providerID ? formData.providerID : ""}
                                                            onChange={handleAmountInputChange}
                                                            inputProps={{ maxLength: 15 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            id="sp_taxonomy_id"
                                                            name='providerTaxonomyCode'
                                                            label="Taxonomy"
                                                            value={formData.providerTaxonomyCode ? formData.providerTaxonomyCode : ""}
                                                            onChange={handleAmountInputChange}
                                                            inputProps={{ maxLength: 10 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                ) : null}
                                <Divider className="mr-3 ml-3 mt-3" />
                                {showSYS_ID ?
                                    <div className="tabs-container tabs-container-inner">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left">
                                                P_SYS_ID Selection
                                                    </h2>
                                            <div className="float-right th-btnGroup">
                                                <Button title='Save' className='btn btn-ic-only btn-icon-only-save' onClick={sysIdSelection}></Button>
                                                <Button title="Cancel" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-cancel" onClick={() => setShowSYS_ID(false)}></Button>
                                            </div>
                                        </div>
                                        <div className="mt-0" ref={addSYS_IDRef}>
                                            <form autoComplete="off">
                                                <div className="form-wrapper">
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="sp_line#id"
                                                            name='lineNumber'
                                                            label="Line #"
                                                            value={sysFormData.lineNumber > -1 ? sysFormData.lineNumber : ""}
                                                            inputProps={{ maxLength: 5 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            select
                                                            id="sp_prov_role_id"
                                                            name='providerRoleCode'
                                                            label="Prov Role"
                                                            value={sysFormData.providerRoleCode ? sysFormData.providerRoleCode : ""}
                                                            inputProps={{ maxLength: 2 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            >
                                                            <MenuItem selected key="Please Select One" value="-1">
                                                                Please Select One
                                            </MenuItem>
                                                            {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#C_PROV_ROLE_CD'] && addDropdowns['Claims#C_PROV_ROLE_CD'].map(each => (
                                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                                            ))}
                                                        </TextField>
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            select
                                                            id="sp_prov_id_type_id"
                                                            name='providerIDType'
                                                            label="Prov ID Type"
                                                            value={sysFormData.providerIDType ? sysFormData.providerIDType : ""}
                                                            inputProps={{ maxLength: 3 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            >
                                                            <MenuItem selected key="Please Select One" value="-1">
                                                                Please Select One
                                            </MenuItem>
                                                            {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#P_ALT_ID_SRC_TY_CD'] && addDropdowns['Claims#P_ALT_ID_SRC_TY_CD'].map(each => (
                                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                                            ))}
                                                        </TextField>
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="sp_prov_id_id"
                                                            name='providerID'
                                                            label="Prov ID"
                                                            value={sysFormData.providerID ? sysFormData.providerID : ""}
                                                            inputProps={{ maxLength: 15 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="sp_sys_id_id"
                                                            name='p_sys_id'
                                                            label="P_SYS_ID"
                                                            value={sysFormData.sysID ? sysFormData.sysID : ""}
                                                            inputProps={{ maxLength: 1 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="sp_prov_type_id"
                                                            name='providerTypeCodeDesc'
                                                            label="Provider Type"
                                                            value={sysFormData.providerTypeCodeDesc ? sysFormData.providerTypeCodeDesc : ""}
                                                            inputProps={{ maxLength: 3 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="sp_prov_specialty_id"
                                                            name='providerSpecialtyCode'
                                                            label="Provider Specialty"
                                                            value={sysFormData.providerSpecialityCodeDesc ? sysFormData.providerSpecialityCodeDesc : ""}
                                                            inputProps={{ maxLength: 3 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="sp_taxonomy_id"
                                                            name='providerTaxonomyCode'
                                                            label="Taxonomy"
                                                            value={sysFormData.providerTaxonomyCode ? sysFormData.providerTaxonomyCode : ""}
                                                            inputProps={{ maxLength: 10 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="sp_p_sys_id_Hierarchy_Code_id"
                                                            name='p_sys_id_Hierarchy_Code'
                                                            label="P_SYS_ID Hierarchy Code"
                                                            value={sysFormData.providerUsedIndicator ? sysFormData.providerUsedIndicator : ""}
                                                            inputProps={{ maxLength: 1 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                        <div className="tab-header">
                                            <h3 className="tab-heading float-left">
                                            Select the P_SYS_ID that matches the Provider
                                                    </h3>
                                        </div>
                                        <div className="mr-3 ml-3">
                                            <TableComponent headCells={sysHeadCells} tableData={sysList} onTableRowClick={sysIDEdit} tableRowRadioSelVal={sysFormData_sysID} />
                                        </div>
                                    </div>
                                    : null}
                            </div>
                           
                            <div className="tabs-container pt-2">
                                <div className="tab-header">
                                    <div className="tab-heading float-left">
                                    Provider Addresses
                                    </div>
                                </div>
                                <div className="tab-body-bordered collapsable-panel mb-4">
                                    <div className="custom-panel"><div className="panel-header panel-header-white"><span>Billing Provider Address</span></div></div>
                                    <form autoComplete="off">
                                        <div className="mui-custom-form">
                                            <TextField
                                                id="pp_bp_address1"
                                                name='addressLine1'
                                                label="Address"
                                                value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider ? 
                                                    data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.addressLine1 : null}
                                                onChange={(e) => {addressChange(e,"billingProvider");}}
                                                placeholder="Address 1"
                                                inputProps={{ maxLength: 55 }}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form">
                                            <TextField
                                                id="pp_bp_address2"
                                                name='addressLine2'
                                                value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider ? 
                                                    data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.addressLine2 : null}
                                                onChange={(e) => {addressChange(e,"billingProvider");}}
                                                placeholder="Address 2"
                                                inputProps={{ maxLength: 55 }}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_bp_city"
                                                    name='cityName'
                                                    label="City"
                                                    value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider ? 
                                                        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.cityName : null}
                                                    onChange={(e) => {addressChange(e,"billingProvider");}}
                                                    placeholder=""
                                                    inputProps={{ maxLength: 30 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_bp_state"
                                                    name='stateCode'
                                                    label="State"
                                                    value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider ? 
                                                        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.billingProvider.stateCode : null}
                                                    onChange={(e) => {addressChange(e,"billingProvider");}}
                                                    placeholder=""
                                                    inputProps={{ maxLength: 2 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <div className="cndt-row">
                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            id="pp_bp_zip"
                                                            name="zip"
                                                            label="Zip &amp; Extension"
                                                            placeholder=""
                                                            value={zip}
                                                            onChange={(e) => {addressChange(e,"billingProvider");}}
                                                            inputProps={{ maxLength: 5 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            id="pp_bp_ext"
                                                            name="extension"
                                                            placeholder=""
                                                            value={extension}
                                                            onChange={(e) => {addressChange(e,"billingProvider");}}
                                                            inputProps={{ maxLength: 4 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>


                                <div className="tab-body-bordered collapsable-panel">
                                    <div className="custom-panel"><div className="panel-header panel-header-white"><span>Rendering Provider Address</span></div></div>
                                    <form autoComplete="off">
                                        <div className="mui-custom-form">
                                            <TextField
                                                id="pp_rp_address1"
                                                name='addressLine1'
                                                label="Address"
                                                value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility ? 
                                                    data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.addressLine1 : null}
                                                onChange={(e) => {addressChange(e,"serviceFacility");}}
                                                placeholder="Address 1"
                                                inputProps={{ maxLength: 55 }}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form">
                                            <TextField
                                                id="pp_rp_address2"
                                                name='addressLine2'
                                                value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility ? 
                                                    data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.addressLine2 : null}
                                                onChange={(e) => {addressChange(e,"serviceFacility");}}
                                                placeholder="Address 2"
                                                inputProps={{ maxLength: 55 }}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_rp_city"
                                                    name='cityName'
                                                    label="City"
                                                    value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility ? 
                                                        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.cityName : null}
                                                    onChange={(e) => {addressChange(e,"serviceFacility");}}
                                                    placeholder=""
                                                    inputProps={{ maxLength: 30 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    id="pp_rp_state"
                                                    name='stateCode'
                                                    label="State"
                                                    value={data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider && data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility ? 
                                                        data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider.serviceFacility.stateCode : null}
                                                    onChange={(e) => {addressChange(e,"serviceFacility");}}
                                                    placeholder=""
                                                    inputProps={{ maxLength: 2 }}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <div className="cndt-row">
                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            id="pp_rp_zip"
                                                            name="zip"
                                                            label="Zip &amp; Extension"
                                                            placeholder=""
                                                            value={zip1}
                                                            onChange={(e) => {addressChange(e,"serviceFacility");}}
                                                            inputProps={{ maxLength: 5 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            id="pp_rp_ext"
                                                            name="extension"
                                                            placeholder=""
                                                            value={extension1}
                                                            onChange={(e) => {addressChange(e,"serviceFacility");}}
                                                            inputProps={{ maxLength: 4 }}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>

                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>
            </div>
        </div >
    )
}

export default PaymentProvider;