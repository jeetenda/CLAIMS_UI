import React from "react";
import moment from 'moment';
import * as ErrorMessageConstants from '../../../../SharedModules/Messages/ErrorMsgConstants';
function Claim(props) {
    const InputStyles = {
        "padding": "2px 8px",
        "border-radius": "2px",
        "display": "inline",
        "width": "40%",
        "border": "1px solid #dcdcdc"
    };
    const SmallWidthInput = {
        "width": "15%",
        "margin-right": "2px"
    };
    const data = props.data;
    const handleReplacedTcn = (replacetcn) => {
        // props.history.push({
        //     pathname: '/Inquiry'            
        // });
    }
    return (
        <div className="tabs-holder">
            <div className="tab-body-bordered collapsable-panel mt-3">

                <div className="custom-panel">
                    <div className="panel-header">
                        <span> Claim Data </span>
                    </div>
                </div>
                <div className="p-3">

                    <div className="cndt-row-wrapper columns-claim-data">
                        <div className="cndt-row row-feilds rspc-col">
                            <div className="cndt-col-4">

                                <div className="flex-grid-1">
                                    <span className="inline-title">DOC# : </span>
                                    
                                    <span>{data.batchInfo && data.batchInfo.documentNumber ?data.batchInfo.documentNumber:null}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Status : </span>
                                    <span>{data.statusCodeDesc ? data.statusCodeDesc : data.statusCode}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Pay Type : </span>
                                    <span>{data.additionalClaimData ? data.additionalClaimData.paymentTypeCodeDesc : null}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Override Loc/User ID: </span>
                                    <span>
                                         <input id="override_loc" type="text" maxlength="3"
                                          onChange={(e) => { props.setClaimEntryData({ ...data, "payment":{...data.payment,"overrideLocationCode": e.target.value} }) }}
                                          value={data.payment && data.payment.overrideLocationCode ? data.payment.overrideLocationCode : ""}
                                         style={{ ...InputStyles, ...SmallWidthInput }} />
                                         <input id="user_name" type="text" maxlength="10"
                                          onChange={(e) => { props.setClaimEntryData({ ...data, "overrideUserID":e.target.value}) }}
                                          value={data.overrideUserID?data.overrideUserID:""}
                                          style={{ ...InputStyles, ...SmallWidthInput }} />
                                           {props.claimMainErr.overrideLocReq ? <p className="MuiFormHelperText-root Mui-error Mui-required">{ErrorMessageConstants.CC_OVR_LOC_REQ}</p> : null}
                                           {props.claimMainErr.userIdReq ? <p className="MuiFormHelperText-root Mui-error Mui-required">{ErrorMessageConstants.CC_OVR_USR_REQ}</p> : null}                                    
                                    </span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Replaced TCN : </span>
                                    {/* <span>{data.claimAdjustment[0]?data.claimAdjustment[0].replacedTCN:null}</span> */}
                                    {data.claimAdjustment[0] && data.claimAdjustment[0].replacedTCN ? data.claimAdjustment[0].replacedTCN != '0' ? (
                                        <a href="/Inquiry" target="_blank"><span >{data.claimAdjustment[0].replacedTCN}</span></a>
                                    ) : data.claimAdjustment[0].replacedTCN : ''}
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Submitted Replace/Void TCN : </span>
                                    <input id="override_loc" type="text" maxlength="17"
                                          disabled={(data.batchInfo && data.batchInfo.transactionTypeCode=="4" && (data.batchInfo.mediaSourceCode=="1"||data.batchInfo.mediaSourceCode=="2"||data.batchInfo.mediaSourceCode=="3"))?false:true}
                                          onChange={(e) => { props.setClaimEntryData({ ...data, "subRepVoidTCN": e.target.value }) }}
                                          value={data.subRepVoidTCN?data.subRepVoidTCN:""}
                                         style={{ ...InputStyles, ...SmallWidthInput }} />                                   
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Policy Number : </span>
                                    <span >{data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr&&data.enterpriseClaimAux.c837ClaimHdr.c837Payer?data.enterpriseClaimAux.c837ClaimHdr.c837Payer.subscriber.policyNumber:null}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">User ID : </span>
                                    <span>{data.userId}</span>
                                </div>                                                                                                 
                            </div>

                            <div className="cndt-col-4">

                                <div className="flex-grid-1">
                                    <span className="inline-title">TCN : </span>
                                    <span>{data.tcn}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">LOB : </span>
                                    <span>{data.lobCode}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Trans Type : </span>
                                    <span>{data.batchInfo ? data.batchInfo.transactionTypeCodeDesc : null}</span>
                                </div>                                
                                <div className="flex-grid-1">
                                    <span className="inline-title">Replacement Reason : </span>
                                    <span>{data.claimAdjustment[0]?data.claimAdjustment[0].adjustmentReasonCodeDesc:null}</span>
                                </div>     
                                <div className="flex-grid-1">
                                    <span className="inline-title">External TCN : </span>
                                    <span>{data.externalTCN?data.externalTCN:null}</span>
                                </div> 
                                <div className="flex-grid-1">
                                    <span className="inline-title">X12 Version Number : </span>
                                    <span>{data.implGuideVersionName}</span>
                                </div> 
                                <div className="flex-grid-1">
                                    <span className="inline-title">Adjud Date : </span>                                   
                                    {data.adjudicationDate ? (
                                        <span>{moment(data.adjudicationDate).utc().format('MM/DD/YYYY')}</span>
                                    ) : ''}
                                </div>                                                         
                            </div>

                            <div className="cndt-col-4">
                                <div className="flex-grid-1">
                                    <span className="inline-title">Claim Type : </span>
                                    <span>{data.claimTypeDesc ? data.claimTypeDesc : data.claimTypeCode}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Doc Type : </span>
                                    <span>{data.batchInfo ? data.batchInfo.documentTypeCodeDesc : null}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Location : </span>
                                    <span>{data.exceptionLocationCode}</span>
                                </div> 
                                <div className="flex-grid-1">
                                    <span className="inline-title">Replacement TCN : </span>                                    
                                    <a href="/Inquiry" target="_blank"><span >{data.claimAdjustment[0]?data.claimAdjustment[0].replacementTCN:null}</span></a>
                                </div> 
                                <div className="flex-grid-1">
                                    <span className="inline-title">Insurance Group : </span>
                                    <span>{data.enterpriseClaimAux && data.enterpriseClaimAux.c837ClaimHdr&&data.enterpriseClaimAux.c837ClaimHdr.c837Payer&&data.enterpriseClaimAux.c837ClaimHdr.c837Payer.payer?data.enterpriseClaimAux.c837ClaimHdr.c837Payer.payer.payerName:null}</span>
                                </div>
                                <div className="flex-grid-1">
                                    <span className="inline-title">Adjud Date / Time : </span>                                    
                                    {data.auditTimeStamp ? (
                                        <span>{moment(data.auditTimeStamp).utc().format('MM/DD/YYYY hh:mm:ss A')}</span>
                                    ) : ''}
                                </div>                                                                                                                                
                                <div className="flex-grid-1">
                                    <span className="inline-title">Pricing Method Code : </span>
                                    <span>{data.pricingMethodCodeDesc ? data.pricingMethodCodeDesc : data.pricingMethodCode }</span>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Claim;