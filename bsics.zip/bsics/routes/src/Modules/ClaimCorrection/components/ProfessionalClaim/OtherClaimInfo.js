import React, { useState } from 'react';
import { withRouter } from 'react-router';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import { Accordion } from '@material-ui/core'
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../../SharedModules/Table/Table';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import TextField from '@material-ui/core/TextField';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from '@material-ui/core/InputAdornment';
import Alert from '@material-ui/lab/Alert';
import OtherClaimCoordinatesOfBenefits from './OtherClaimCoordinatesOfBenefits';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
    small: {
        width: theme.spacing(3),
        height: theme.spacing(3),
    },
    txtfullwidth: {
        width: '100%',
    }
}));


export const editRow = (event, row, setBenefitsData, setVisionData) => {
    setBenefitsData(true)
    setVisionData(row)
};

export const editRowOtherPayer = (event, row, setCoordinates) => {
    setCoordinates(true)
    // setVisionData(row)
};

export const unwantedFunc = () => {
    return false;
};

function OtherClaimInfo(props) {

    const classes = useStyles();
    const [lineItemNum, setLineItemNum] = useState(0);
    const emptyString=' ';
    const [benefitsData, setBenefitsData] = React.useState(false);
    const [coordinates, setCoordinates] = React.useState(false);
    const [visiondata, setVisionData] = React.useState(false);
    const claimsInfo = props?.data?.enterpriseClaimAux?.c837ClaimHdr || {};
    const claimInfodates = claimsInfo?.c837Claim || {};
    const claimServiceInfo = claimsInfo?.c837ServiceLineItems[0]?.ambulatoryPatientGroup || {};

    const claimDetailMisc = props?.data?.enterpriseClaimAux || {};
    const fileInfoVOList = claimsInfo?.c837ServiceLineItems[0]?.fileFormatInfo || [];
    const repricedClaim = claimsInfo?.c837SpecializedService?.repricedClaimInfo || {};
    const claimInfoAmbulance = claimsInfo?.c837SpecializedService?.ambulanceInfo || {};
    const claimInfoAmbulancePickup = claimsInfo?.c837ServiceLineItems[0]?.ambulancePickupLocation || {};
    const claimInfoAmbulanceDrop = claimsInfo?.c837ServiceLineItems[0]?.ambulanceDropoffLocation || {};

    const claimInfoSpinalInfo = claimsInfo?.c837SpecializedService || {};

    const vision = claimsInfo?.c837SpecializedService?.patientVisionCondition || {};
        
    const visionList = [];
    vision.visionCode1 != null ? visionList.push({"visionConditionIndicator1":vision.visionConditionIndicator1,"visionCode":vision.visionCode1, "conditionCode1": vision.conditionCode1A, "conditionCode2": vision.conditionCode1B, "conditionCode3": vision.conditionCode1C, "conditionCode4": vision.conditionCode1D, "conditionCode5": vision.conditionCode1E}) : null
    vision.visionCode2 != null ? visionList.push({"visionConditionIndicator1":vision.visionConditionIndicator2,"visionCode":vision.visionCode2, "conditionCode1": vision.conditionCode2A, "conditionCode2": vision.conditionCode2B, "conditionCode3": vision.conditionCode2C, "conditionCode4": vision.conditionCode2D, "conditionCode5": vision.conditionCode2E}): null
    vision.visionCode3 != null ? visionList.push({"visionConditionIndicator1":vision.visionConditionIndicator3,"visionCode":vision.visionCode3, "conditionCode1": vision.conditionCode3A, "conditionCode2": vision.conditionCode3B, "conditionCode3": vision.conditionCode3C, "conditionCode4": vision.conditionCode3D, "conditionCode5": vision.conditionCode3E}): null
    const claimInfoHomeHealthCare = claimsInfo?.c837HomeHealthPlans || {};
    const claimInfoServiceFacilityInfo = claimsInfo?.serviceFacility?.serviceFacilityName || {};
    const additionalPrimaryCareProviderInformation = claimsInfo?.c837ClaimProvider?.referringProvider1.providerName || {};
    const purchasedServiceProvider = claimsInfo?.c837ClaimProvider?.purchasedServiceProvider || {};
    const supervisingProvider = claimsInfo?.c837ClaimProvider?.supervisingProvider?.providerName || {};
    const claimInfoServiceFacilityInfoIdInfo = props?.data?.claimProviderID || [];
    var cobClaimTplSequenceNumber = [props?.data?.claimTPLInfo[0]] || []
    const coboOtherPayerInsuranceList = [claimsInfo?.c837OtherPayers[0]] || [];
    
    var j = coboOtherPayerInsuranceList.length;
    var coordinationOfBenefitInformation = [];
    if(coboOtherPayerInsuranceList.length > 0 && cobClaimTplSequenceNumber.length > 0){  
        for(var i=0;i<j;i++){      
            coordinationOfBenefitInformation.push({
                'subscriberQualifierCode': coboOtherPayerInsuranceList[i]?.otherSubscriberInfo?.subscriberID || '',
                'otherPayerID': coboOtherPayerInsuranceList[i]?.otherPayerID || '',
                'tplPaidAmount': coboOtherPayerInsuranceList[i]?.otherPayerTPLInfo?.tplPaidAmount?.toFixed(2) || '',
                'sequenceNumber': cobClaimTplSequenceNumber[i]?.sequenceNumber,
                'otherPayerName': cobClaimTplSequenceNumber[i]?.otherPayerName
            })
        }
        
    }
    const CertificationConditionsTC = [
        {
            id: 'visionConditionIndicator1', numeric: false, disablePadding: false, label: 'Certification Condition Indicator', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'visionCode', numeric: false, disablePadding: false, label: 'Code Category', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'conditionCode1', numeric: false, disablePadding: false, label: 'Condition 1', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'conditionCode2', numeric: false, disablePadding: false, label: 'Condition 2', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'conditionCode3', numeric: false, disablePadding: false, label: 'Condition 3', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'conditionCode4', numeric: false, disablePadding: false, label: 'Condition 4', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'conditionCode5', numeric: false, disablePadding: false, label: 'Condition 5', enableHyperLink: false, fontSize: 12
        },

    ];
    const ClaimProviderInfoCells = [
        {
            id: 'providerIDType', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12
        }
    ];
    const CoordinationOfBenefitsCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: 'Sequence Number', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'subscriberQualifierCode', numeric: false, disablePadding: false, label: 'Subscriber ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerID', numeric: false, disablePadding: false, label: 'Payer/Carrier ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerName', numeric: false, disablePadding: false, label: 'Payer/Insurance Org', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'tplPaidAmount', numeric: false, disablePadding: false, label: 'Payer Paid Amount', enableHyperLink: false, fontSize: 12
        }
    ];
    
    const closeVision = () => {
        setBenefitsData(false)
    }

    

    return (
        <div className='tab-holder CustomExpansion-panel my-3'>
            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content1"
                        id="panelp1a-header1">
                        <Typography className={classes.heading}>Claim Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content11"
                                id="panelp1a-header11">
                                <Typography className={classes.heading}>Relevant Dates</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label px-0">
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Date Last Seen"
                                                label="Date Last Seen"
                                                format="MM/dd/yyyy"
                                                data-test="DataLastSeen"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.lastSeenDate || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Property Casualty 1st Contact Date"
                                                label="Property Casualty 1st Contact Date"
                                                format="MM/dd/yyyy"
                                                data-test="Property Casualty"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.propCasualFirstContactDate || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Admission Date"
                                                label="Admission Date"
                                                format="MM/dd/yyyy"
                                                data-test="Admission Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={claimInfodates?.admissionDate || null}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Discharge Date"
                                                label="Discharge Date"
                                                format="MM/dd/yyyy"
                                                data-test="Discharge Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.dischargeDate || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Assumed Care Date"
                                                label="Assumed Care Date"
                                                data-test="Assumed Care Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.relinquishedCareDate1 || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Relinquished Care Date"
                                                label="Relinquished Care Date"
                                                format="MM/dd/yyyy"
                                                data-test="Relinquished Care Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.relinquishedCareDate2 || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Repricer Received Date"
                                                label="Repricer Received Date"
                                                format="MM/dd/yyyy"
                                                data-test="Repricer Received Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.repriceReceivedDate || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>

                                </div>
                                <div className="form-wrapper wrap-form-label px-0">
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Disability Begin Date"
                                                label="Disability Begin Date"
                                                format="MM/dd/yyyy"
                                                data-test="Disability Begin Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.DisabilityInfo?.beginDate1 || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Disability End Date"
                                                label="Disability End Date"
                                                format="MM/dd/yyyy"
                                                data-test="Disability End Date"
                                                maxDate={new Date('9999-12-31T13:00:00.000+0000')}
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.DisabilityInfo?.endDate1 || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Hearing Vision Prescription Date"
                                                label="Hearing &amp; Vision Prescription Date"
                                                format="MM/dd/yyyy"
                                                data-test="Hearing Vision Prescription Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.hearingVisionQualifierCode || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Acute Manifestation Date"
                                                label="Acute Manifestation Date"
                                                data-test="Acute Manifestation Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.acuteInfo?.acuteManifestationDate1 || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Last X-Ray Date"
                                                label="Last X-Ray Date"
                                                format="MM/dd/yyyy"
                                                data-test="Last X-Ray Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.lastXRayDate || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="Initial Treatment Date"
                                                label="Initial Treatment Date"
                                                format="MM/dd/yyyy"
                                                data-test="Initial Treatment Date"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    claimInfodates?.initialTreatmentDate || null
                                                }
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content12"
                                id="panelp1a-header12">
                                <Typography className={classes.heading}>Miscellaneous Claim</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="CLIA#"
                                            label="CLIA#"
                                            placeholder=""
                                            data-test="CLIA#"
                                            value={claimDetailMisc?.cliaNumber1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Medicare Section 4081 Indicator</label>
                                        </div>
                                        <div className="sub-radio">
                                            <RadioGroup
                                                disabled
                                                row
                                                aria-label="Medicare Section 4081 Indicator"
                                                name="Medicare Section 4081 Indicator"
                                                data-test="MedicareSection"
                                                value={claimInfodates?.section4081Indicator || false}
                                            >
                                                <FormControlLabel
                                                    value="true"
                                                    control={<Radio color="primary" />}
                                                    label="Yes"
                                                />
                                                <FormControlLabel
                                                    value="false"
                                                    control={<Radio color="primary" />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                        </div>
                                        <div className="clearfix"></div>
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Ambulatory Patient Group Number"
                                            label="Ambulatory Patient Group Number"
                                            placeholder=""
                                            data-test="AmbulatoryPatient"
                                            value={claimServiceInfo?.apgCode1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Investigational Device Exemption ID"
                                            label="Investigational Device Exemption ID"
                                            data-test="Investigational"
                                            placeholder=""
                                            value={claimInfodates?.investExemptionID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Mammography Certification"
                                            label="Mammography Certification#"
                                            data-test="Mammography"
                                            placeholder=""
                                            value={claimInfodates?.mammographyCertNumber || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Demonstration Project ID"
                                            label="Demonstration Project ID"
                                            data-test="Demonstration"
                                            placeholder=""
                                            value={claimInfodates?.demoProjectID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Homebound Certification Indicator</label>
                                        </div>
                                        <div className="sub-radio">
                                            <RadioGroup
                                                disabled
                                                row
                                                aria-label="Homebound Certification Indicator"
                                                data-test="Homebound"
                                                name="Homebound Certification Indicator"
                                                value={claimsInfo?.c837SpecializedService?.homeboundIndicator || false}
                                            >
                                                <FormControlLabel
                                                    value="true"
                                                    control={<Radio color="primary" />}
                                                    label="Yes"
                                                />
                                                <FormControlLabel
                                                    value="false"
                                                    control={<Radio color="primary" />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                        </div>
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Total Purchased Serivce Amount"
                                            label="Total Purchased Service Amount"
                                            data-test="totalPurchased"
                                            placeholder=""
                                            type="number"
                                            value={claimInfodates?.purchasedServiceAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Service Authorization Exception Code"
                                            label="Service Authorization Exception Code"
                                            data-test="Service Auth"
                                            placeholder=""
                                            value={claimInfodates?.exceptionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Repriced Claim"
                                            label="Repriced Claim#"
                                            data-test="Repriced Claim"
                                            placeholder=""
                                            value={claimInfodates?.repricedClaimNumber || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Adjusted Repriced Claim"
                                            label="Adjusted Repriced Claim#"
                                            data-test="Adjusted Claim"
                                            placeholder=""
                                            value={claimInfodates?.adjustedRepricedClaimNumber || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Care Plan Oversight Number"
                                            label="Care Plan Oversight Number"
                                            data-test="Care Plan"
                                            placeholder=""
                                            value={claimInfodates?.carePlanOverSightQualifierCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content13"
                                id="panelp1a-header13">
                                <Typography className={classes.heading}>File Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 1"
                                            label="File Information 1"
                                            data-test="File1"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 2"
                                            label="File Information 2"
                                            data-test="File2"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation2 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 3"
                                            label="File Information 3"
                                            data-test="File3"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation3 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 4"
                                            label="File Information 4"
                                            data-test="File4"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation4 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 5"
                                            label="File Information 5"
                                            data-test="File5"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation5 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 6"
                                            label="File Information 6"
                                            data-test="File6"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation6 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 7"
                                            label="File Information 7"
                                            data-test="File7"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation7 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 8"
                                            label="File Information 8"
                                            data-test="File8"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation8 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 9"
                                            label="File Information 9"
                                            data-test="File9"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation9 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 10"
                                            label="File Information 10"
                                            data-test="File10"
                                            placeholder=""
                                            value={ fileInfoVOList?.fileInformation10 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header14">
                                <Typography className={classes.heading}>Contract Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Type Code"
                                            label="Contract Type Code"
                                            placeholder=""
                                            value={claimInfodates?.contractTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Amount"
                                            label="Contract Amount"
                                            placeholder=""
                                            value={claimInfodates?.contractAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Percent"
                                            label="Contract Percent"
                                            placeholder=""
                                            value={ claimInfodates?.contractPercentage || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Code"
                                            label="Contract Code"
                                            placeholder=""
                                            value={claimInfodates?.contractCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Terms Discount Percent"
                                            label="Terms Discount Percent"
                                            placeholder=""
                                            value={claimInfodates?.contractDiscountPercentage || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Version ID"
                                            label="Contract Version ID"
                                            placeholder=""
                                            value={claimInfodates?.contractVersionID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content15"
                                id="panelp1a-header15">
                                <Typography className={classes.heading}>Claims Pricing/Repricing</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Pricing Methodology Code"
                                            label="Pricing Methodology Code"
                                            placeholder=""
                                            value={repricedClaim?.methodologyCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Allowed Amount"
                                            label="Allowed Amount"
                                            placeholder=""
                                            value={repricedClaim?.repriceAllowedAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Savings Amount"
                                            label="Savings Amount"
                                            placeholder=""
                                            value={ repricedClaim?.savingsAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Organization Identifier"
                                            label="Organization Identifier"
                                            placeholder=""
                                            value={ repricedClaim?.organizationID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Per Diem or Falt Rate Amount"
                                            label="Per Diem or Flat Rate Amount"
                                            placeholder=""
                                            value={repricedClaim?.repricePerDiemRate || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved DRG Code"
                                            label="Approved DRG Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceAPGCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved DRG Amount"
                                            label="Approved DRG Amount"
                                            placeholder=""
                                            value={repricedClaim?.repriceAPGAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Rejection Reason Code"
                                            label="Rejection Reason Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceRejectReasonCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Policy Compliance Code"
                                            label="Policy Compliance Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceComplianceCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Exception Code"
                                            label="Exception Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceExceptionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content2"
                        id="panelp1a-header2">
                        <Typography className={classes.heading}>Specialized Services Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content21"
                                id="panelp1a-header21">
                                <Typography className={classes.heading}>Home Health Care</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Discipline Type Code"
                                            label="Discipline Type Code"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.disciplineTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Total Visits Rendered"
                                            label="Total Visits Rendered"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.priorVisitsCount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Projected Visits"
                                            label="Projected Visits"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.projectedVisitsCount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Number of Visits"
                                            label="Number of Visits"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.visitsCount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Frequency of Visits"
                                            label="Frequency of Visits"
                                            placeholder=""
                                            value={ claimInfoHomeHealthCare?.frequencyPeriodCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Frequency Count"
                                            label="Frequency Count"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.frequencyCount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Type of Units"
                                            label="Type of Units"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.unitQualifierCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Number of Units"
                                            label="Number of Units"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.unitsQuantity || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Delivery Time Pattern"
                                            label="Delivery Time Pattern"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.patternCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Time Code"
                                            label="Time Code"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.patternTimeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content22"
                                id="panelp1a-header22">
                                <Typography className={classes.heading}>Ambulance</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Ambulance Transport Code"
                                            label="Ambulance Transport Code"
                                            placeholder=""
                                            data-test="ambulanceTransportCode"
                                            value={claimInfoAmbulance?.transportCode || ''}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Ambulance Transport Reason Code"
                                            label="Ambulance Transport Reason Code"
                                            placeholder=""
                                            value={ claimInfoAmbulance?.transportReasonCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Transport Distance"
                                            label="Transport Distance"
                                            placeholder=""
                                            value={ claimInfoAmbulance?.transportDistance || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">miles</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Patient Weight"
                                            label="Patient Weight"
                                            placeholder=""
                                            value={claimInfoAmbulance?.patientWeight || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">lbs</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md field-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                data-shrink="true"
                                                htmlFor="Round3Trip4Purpose5Description"
                                                id="Round3Trip4Purpose5Description-label">Round Trip Purpose Description</label>
                                        </div>
                                        <div className="disabled-form pt-3">
                                            <TextareaAutosize
                                                disabled
                                                className={classes.txtfullwidth}
                                                id="Round Trip Purpose Description"
                                                placeholder=""
                                                value={claimInfoAmbulance?.roundTripDescription || ""}
                                                rowsMin={6}
                                                rowsMax={6}

                                            />
                                        </div>
                                    </div>
                                    <div className="mui-custom-form input-md field-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                data-shrink="true"
                                                htmlFor="Round3Trip4Purpose5Description"
                                                id="Round3Trip4Purpose5Description-label">Stretcher Purpose Description</label>
                                        </div>
                                        <div className="disabled-form pt-3">
                                            <TextareaAutosize
                                                className={classes.txtfullwidth}
                                                disabled
                                                id="Stretcher Purpose Description"
                                                placeholder=""
                                                value={claimInfoAmbulance?.stretcherDescription || ""}
                                                rowsMin={6}
                                                rowsMax={6}

                                            />
                                        </div>
                                    </div>
                                    <div className="mui-custom-form w-100">
                                        <div className={classes.root}>
                                            <Alert severity="error">If the patient was admitted to the hospital, please enter the admission date in the Relevant Dates Section.</Alert>
                                        </div>
                                    </div>
                                </div>

                                <div className="tabs-container pb-2">
                                    <div className="tab-header mt-1">
                                        <h2 className="tab-heading float-left pb-0"> Certification Conditions </h2>
                                    </div>

                                    <div className="tab-body-bordered">
                                        <div className="form-wrapper">

                                            <div className="mui-custom-form input-md">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Certification Condition Indicator</label>
                                                </div>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        disabled
                                                        row
                                                        aria-label="eftactive"
                                                        name="HideInactiveProviders"
                                                        value={ claimInfodates?.certificationIndicator1 || " "}
                                                    >
                                                        <FormControlLabel
                                                            value="Yes"
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value="No"
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 1"
                                                    label="Condition 1"
                                                    placeholder=""
                                                    value={claimInfodates?.conditionCode1A || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 2"
                                                    label="Condition 2"
                                                    placeholder=""
                                                    value={claimInfodates?.conditionCode1B || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 3"
                                                    label="Condition 3"
                                                    placeholder=""
                                                    value={claimInfodates?.conditionCode1C || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 4"
                                                    label="Condition 4"
                                                    placeholder=""
                                                    value={ claimInfodates?.conditionCode1D || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 5"
                                                    label="Condition 5"
                                                    placeholder=""
                                                    value={claimInfodates?.conditionCode1E || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content23"
                                id="panelp1a-header23">
                                <Typography className={classes.heading}>Ambulance Pickup Location</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="Address 1"
                                            label="Address 1"
                                            placeholder=""
                                            value={claimInfoAmbulancePickup?.address?.addressLine1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="Address 2"
                                            label="Address 2"
                                            placeholder=""
                                            value={ claimInfoAmbulancePickup?.address?.addressLine2 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="City"
                                            label="City"
                                            placeholder=""
                                            value={claimInfoAmbulancePickup?.address?.cityName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="State"
                                            label="State"
                                            placeholder=""
                                            value={claimInfoAmbulancePickup?.address?.stateCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="cndt-row">
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="Zip and Extension"
                                                    label="Zip and Extension"
                                                    placeholder=""
                                                    value={ claimInfoAmbulancePickup?.address?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="Zip and Extension1"
                                                    placeholder=""
                                                    value={claimInfoAmbulancePickup?.address?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>

                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Country12"
                                            label="Country"
                                            placeholder=""
                                            value={claimInfoAmbulancePickup?.address?.countryCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Subdivision Code"
                                            label="Subdivision Code"
                                            placeholder=""
                                            value={claimInfoAmbulancePickup?.address?.countrySubDivisionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>

                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content24"
                                id="panelp1a-header24">
                                <Typography className={classes.heading}>Ambulance Dropoff Location</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Ambulance Dropoff Location"
                                            label="Ambulance Dropoff Location"
                                            placeholder=""
                                            value={claimInfoAmbulanceDrop?.locationName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="Address1233"
                                            label="Address 1"
                                            placeholder=""
                                            value={claimInfoAmbulanceDrop?.address?.addressLine1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="Address12333"
                                            label="Address 2"
                                            placeholder=""
                                            value={claimInfoAmbulanceDrop?.address?.addressLine2 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="City1233"
                                            label="City"
                                            placeholder=""
                                            value={claimInfoAmbulanceDrop?.address?.cityName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="State1233"
                                            label="State"
                                            placeholder=""
                                            value={ claimInfoAmbulanceDrop?.address?.stateCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="cndt-row">
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="Zipandextension1"
                                                    label="Zip and Extension"
                                                    placeholder=""
                                                    value={claimInfoAmbulanceDrop?.address?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="Zipandextension122"
                                                    placeholder=""
                                                    value={ claimInfoAmbulanceDrop?.address?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>

                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Country122"
                                            label="Country"
                                            placeholder=""
                                            value={claimInfoAmbulanceDrop?.address?.countryCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Subdivisioncode12"
                                            label="Subdivision Code"
                                            placeholder=""
                                            value={ claimInfoAmbulanceDrop?.address?.countrySubDivisionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>

                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>Spinal Manipulation</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="patientconditioncode"
                                            label="Patient Condition Code"
                                            placeholder=""
                                            value={claimInfoSpinalInfo?.spinalConditionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md field-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                data-shrink="true"
                                                htmlFor="Round3Trip4Purpose5Description"
                                                id="Round3Trip4Purpose5Description-label">Patient Condition Description 1</label>
                                        </div>
                                        <div className="disabled-form pt-1">
                                        <TextareaAutosize
                                            className={classes.txtfullwidth}
                                            disabled
                                            id="Patientconditiondesc1"
                                            placeholder=""
                                            value={claimInfoSpinalInfo?.spinalConditionDescription1 || ""}
                                            rowsMin={6}
                                            rowsMax={6}
                                        />
                                        </div>
                                    </div>
                                    <div className="mui-custom-form input-md field-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                data-shrink="true"
                                                htmlFor="Round3Trip4Purpose5Description"
                                                id="Round3Trip4Purpose5Description-label">Patient Condition Description 2</label>
                                        </div>
                                        <div className="disabled-form pt-1">
                                        <TextareaAutosize
                                            className={classes.txtfullwidth}
                                            disabled
                                            id="Patientconditiondesc2"
                                            placeholder=""
                                            value={claimInfoSpinalInfo?.spinalConditionDescription2 || ""}
                                            rowsMin={6}
                                            rowsMax={6}
                                        />
                                        </div>
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">X-ray Availability Indicator</label>
                                        </div>
                                        <div className="sub-radio mt-0">
                                            <RadioGroup
                                                disabled
                                                row
                                                aria-label="eftactive"
                                                name="HideInactiveProviders"
                                                value={ claimInfoSpinalInfo?.SpinalXRayAvailabilityIndicator || false}
                                            >
                                                <FormControlLabel
                                                    value="true"
                                                    control={<Radio color="primary" />}
                                                    label="Yes"
                                                />
                                                <FormControlLabel
                                                    value="false"
                                                    control={<Radio color="primary" />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                        </div>
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content26"
                                id="panelp1a-header26">
                                <Typography className={classes.heading}>Patient Condition - Vision</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="cndt-row-wrapper py-2">
                                    <Typography className="mb-2 bold-text">Certification Conditions</Typography>
                                    <TableComponent headCells={CertificationConditionsTC} tableData={visionList} onTableRowClick={(row)=> editRow({}, row, setBenefitsData, setVisionData)} defaultSortColumn="visionConditionIndicator1" />
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        {benefitsData ?
                            <>
                                <div className='tab-holder CustomExpansion-panel my-3'>
                                    <div className="tabs-container">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left">Edit Patient Condition - Vision</h2>
                                            <div className="float-right th-btnGroup">
                                                <button data-test="cancel_btn" color="primary" type="button" className="btn btn-primary" onClick={closeVision}>Cancel</button>
                                            </div>
                                        </div>
                                    </div>
                                    <div className="tab-body-bordered">
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Certification Condition Indicator</label>
                                                </div>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        disabled
                                                        row
                                                        aria-label="eftactive"
                                                        name="HideInactiveProviders"
                                                        value={visiondata?.visionConditionIndicator1 || "false"}
                                                    >
                                                        <FormControlLabel
                                                            value="true"
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value="false"
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Code Category"
                                                    label="Code Category"
                                                    placeholder=""
                                                    value={visiondata?.visionCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 1"
                                                    label="Condition 1"
                                                    placeholder=""
                                                    value={visiondata?.conditionCode1 || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 2"
                                                    label="Condition 2"
                                                    placeholder=""
                                                    value={visiondata?.conditionCode2 || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 3"
                                                    label="Condition 3"
                                                    placeholder=""
                                                    value={visiondata?.conditionCode3 || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 4"
                                                    label="Condition 4"
                                                    placeholder=""
                                                    value={visiondata.conditionCode4 || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="Condition 5"
                                                    label="Condition 5"
                                                    placeholder=""
                                                    value={visiondata?.conditionCode5 || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </>
                            : ''}

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content3"
                        id="panelp1a-header3">
                        <Typography className={classes.heading}>Claim Provider Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content31"
                                id="panelp1a-header31">
                                <Typography className={classes.heading}>Service Facility</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="entitytype1"
                                            label="Entity Type"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.entityTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname"
                                            label="Org/ Last Name"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.lastName || ""}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname"
                                            label="First Name"
                                            placeholder=""
                                            value={ claimInfoServiceFacilityInfo?.firstName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="MI12"
                                            label="MI"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.middleName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="MI12"
                                            label="Suffix"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.suffixName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="address41"
                                            label="Address 1"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.addressLine1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="address42"
                                            label="Address 2"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.addressLine2 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="city41"
                                            label="City"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.cityName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="state41"
                                            label="State"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.stateCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="cndt-row">
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="zipandextension41"
                                                    label="Zip and Extension"
                                                    placeholder=""
                                                    value={claimInfoServiceFacilityInfo?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="zipandextension412"
                                                    placeholder=""
                                                    value={claimInfoServiceFacilityInfo?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>

                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="country41"
                                            label="Country"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.countryCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="subdivision41"
                                            label="Subdivision Code"
                                            placeholder=""
                                            value={ claimInfoServiceFacilityInfo?.countrySubDivisionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>

                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content32"
                                id="panelp1a-header32">
                                <Typography className={classes.heading}>Primary Care Provider</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname32b"
                                            label="Org / Last Name"
                                            placeholder=""
                                            data-test="lastNamePrimaryCare"
                                            value={additionalPrimaryCareProviderInformation?.lastName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="fname32b"
                                            label="First Name"
                                            placeholder=""
                                            data-test="firstNamePrimaryCare"
                                            value={additionalPrimaryCareProviderInformation?.firstName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="mi32b"
                                            label="MI"
                                            data-test="middleNamePrimaryCare"
                                            placeholder=""
                                            value={additionalPrimaryCareProviderInformation?.middleName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="suffix32b"
                                            label="Suffix"
                                            placeholder=""
                                            value={additionalPrimaryCareProviderInformation?.suffixName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent  headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content33"
                                id="panelp1a-header33">
                                <Typography className={classes.heading}>Purchased Service Provider</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="entityqualifier32b"
                                            label="Entity Qualifier"
                                            placeholder=""
                                            value={ purchasedServiceProvider?.entityTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname32bc"
                                            label="Org / Last Name"
                                            placeholder=""
                                            value={purchasedServiceProvider?.providerName?.lastName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="fname32bc"
                                            label="First Name"
                                            placeholder=""
                                            value={ purchasedServiceProvider?.providerName?.firstName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="mi32bc"
                                            label="MI"
                                            placeholder=""
                                            value={purchasedServiceProvider?.providerName?.middleName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="suffix32bc"
                                            label="Suffix"
                                            placeholder=""
                                            value={ purchasedServiceProvider?.providerName?.suffixName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0">Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content34"
                                id="panelp1a-header34">
                                <Typography className={classes.heading}>Supervising Provider</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname32bcd"
                                            label="Org / Last Name"
                                            placeholder=""
                                            value={supervisingProvider?.lastName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="fname32bcd"
                                            label="First Name"
                                            placeholder=""
                                            value={supervisingProvider?.firstName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="mi32bcd"
                                            label="MI"
                                            placeholder=""
                                            value={ supervisingProvider?.middleName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="suffix32bcd"
                                            label="Suffix"
                                            placeholder=""
                                            value={supervisingProvider?.suffixName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content4"
                        id="panelp1a-header4">
                        <Typography className={classes.heading}>Coordination Of Benefits</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>

                        <div className="tabs-container">
                            <div className="tab-header mt-1">
                                <h2 className="tab-heading float-left"> Other Insurance </h2>
                            </div>

                            <TableComponent headCells={CoordinationOfBenefitsCells} tableData={coordinationOfBenefitInformation} onTableRowClick={(row)=> editRowOtherPayer({}, row, setCoordinates)} defaultSortColumn="payerSeq" />
                            {coordinates ? <OtherClaimCoordinatesOfBenefits tableData={claimsInfo} professoionalData={props.data}
                                setCoordinates={setCoordinates}
                            /> : null}
                        </div>

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

        </div>
    );
}
export default withRouter(OtherClaimInfo);