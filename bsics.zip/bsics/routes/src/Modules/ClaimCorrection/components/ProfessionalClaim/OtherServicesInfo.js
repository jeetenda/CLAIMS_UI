import React, { useState } from 'react';
import { withRouter } from 'react-router';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../../SharedModules/Table/Table';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import TextField from '@material-ui/core/TextField';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from '@material-ui/core/InputAdornment';
import Alert from '@material-ui/lab/Alert';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
    small: {
        width: theme.spacing(3),
        height: theme.spacing(3),
    },
    txtfullwidth: {
        width: '100%',
    }
}));

export const viewOtherInfo = (event, row, setShowViewOtherPayer) => {
    setShowViewOtherPayer(true);
};

export const viewLLA = (event, row, setShowLLA, setLLAData) => {
    setLLAData(row);
    setShowLLA(true);
};
export const unwantedFunc = () => {
    return false;
};

function OtherServicesInfo(props) {
    const classes = useStyles();
    const lineItemOtherServiceMap = props.data && props.data.lineItemOtherServiceMap ? props.data.lineItemOtherServiceMap : {};

    const [lineItemNum, setLineItemNum] = useState(1);
    const claimsInfo = props?.data?.enterpriseClaimAux.c837ClaimHdr || {};

    const serviceInfodates = claimsInfo?.c837SpecializedService?.c837ProfessionalLineItems || {};
    const miscellaneousLineInfoVO = claimsInfo?.c837ServiceLineItems[0] || {};

    const renderingProviderInfo = claimsInfo?.c837LineItemProviders[0]?.renderingProvider?.providerName || {};
    const renderingProviderInfoSecIDsData = props?.data?.claimProviderID || [];
    const serviceInfoServiceFacilityInfo = claimsInfo?.c837LineItemProviders[0]?.serviceFacility || {};
    const referringProviderInfo = claimsInfo?.c837LineItemProviders[0]?.ReferringProvider?.ProviderName || {};
    const additionalPrimaryCareProviderInformation = claimsInfo?.c837LineItemProviders[0]?.referringProvider2?.providerName || {};
    const purchasedServiceProviderInfo = claimsInfo?.c837LineItemProviders[0]?.PurchasedServiceProvider || {};
    const orderingProviderInfo = claimsInfo?.c837LineItemProviders[0]?.orderingProvider || {};
    const supervisingProviderInfo = claimsInfo?.c837LineItemProviders[0]?.SupervisingProvider?.ProviderName || {};
    const durableMedicalEquipment = claimsInfo?.c837SpecializedService?.c837ProfessionalLineItems[0]?.dmercInfo || {};
    const oxygenTherapy = claimsInfo?.c837SpecializedService?.c837ProfessionalLineItems[0]?.oxygenTherapy || {};
    const serviceInfoAmbulance = claimsInfo?.c837SpecializedService?.c837ProfessionalLineItems[0]?.ambulanceInfo || {};
    const serviceInfoAmbulancePickUp = claimsInfo?.c837ServiceLineItems[0]?.ambulancePickupLocation?.address || {};
    const serviceInfoAmbulanceDropOff = claimsInfo?.c837ServiceLineItems[0]?.ambulanceDropoffLocation?.address || {};

    const serviceInfoSpinalInfo = claimsInfo?.c837SpecializedService?.c837ProfessionalLineItems[0]?.spinalPatientInfo || {};
    const testDataResults =  claimsInfo?.c837SpecializedService?.c837ProfessionalLineItems[0]?.testInfo || {};
    const testResultLineItemVOList =
    (testDataResults.testMeasurementCode6 ? [{ "testMeasurementID": testDataResults.testMeasurementCode6, "testMeasurementQual": testDataResults.testMeasurementQualifierCode6, "testResult": testDataResults.testResult6 }] : []);
Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode7 ? [{ "testMeasurementID": testDataResults.testMeasurementCode7, "testMeasurementQual": testDataResults.testMeasurementQualifierCode7, "testResult": testDataResults.testResult7 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode8 ? [{ "testMeasurementID": testDataResults.testMeasurementCode8, "testMeasurementQual": testDataResults.testMeasurementQualifierCode8, "testResult": testDataResults.testResult8 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode9 ? [{ "testMeasurementID": testDataResults.testMeasurementCode9, "testMeasurementQual": testDataResults.testMeasurementQualifierCode9, "testResult": testDataResults.testResult9 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode10 ? [{ "testMeasurementID": testDataResults.testMeasurementCode10, "testMeasurementQual": testDataResults.testMeasurementQualifierCode10, "testResult": testDataResults.testResult10 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode11 ? [{ "testMeasurementID": testDataResults.testMeasurementCode11, "testMeasurementQual": testDataResults.testMeasurementQualifierCode11, "testResult": testDataResults.testResult11 }] : []) : null;
        (testDataResults.testMeasurementCode12 ? [{ "testMeasurementID": testDataResults.testMeasurementCode12, "testMeasurementQual": testDataResults.testMeasurementQualifierCode12, "testResult": testDataResults.testResult12 }] : []);
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode13 ? [{ "testMeasurementID": testDataResults.testMeasurementCode13, "testMeasurementQual": testDataResults.testMeasurementQualifierCode13, "testResult": testDataResults.testResult13 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode14 ? [{ "testMeasurementID": testDataResults.testMeasurementCode14, "testMeasurementQual": testDataResults.testMeasurementQualifierCode14, "testResult": testDataResults.testResult14 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode15 ? [{ "testMeasurementID": testDataResults.testMeasurementCode15, "testMeasurementQual": testDataResults.testMeasurementQualifierCode15, "testResult": testDataResults.testResult15 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode16 ? [{ "testMeasurementID": testDataResults.testMeasurementCode16, "testMeasurementQual": testDataResults.testMeasurementQualifierCode16, "testResult": testDataResults.testResult16 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode17 ? [{ "testMeasurementID": testDataResults.testMeasurementCode17, "testMeasurementQual": testDataResults.testMeasurementQualifierCode17, "testResult": testDataResults.testResult17 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode18 ? [{ "testMeasurementID": testDataResults.testMeasurementCode18, "testMeasurementQual": testDataResults.testMeasurementQualifierCode18, "testResult": testDataResults.testResult18 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode19 ? [{ "testMeasurementID": testDataResults.testMeasurementCode19, "testMeasurementQual": testDataResults.testMeasurementQualifierCode19, "testResult": testDataResults.testResult19 }] : []) : null;
    Object.keys(testDataResults).length ?
        (testDataResults.testMeasurementCode20 ? [{ "testMeasurementID": testDataResults.testMeasurementCode20, "testMeasurementQual": testDataResults.testMeasurementQualifierCode20, "testResult": testDataResults.testResult20 }] : []) : null;
    const serviceLineAdjudicationList = claimsInfo && claimsInfo.c837OtherPayerAdjustments ? claimsInfo.c837OtherPayerAdjustments : [];
    const lineLevelAdjudicationList = props.data && props.data.claimAdjustmentReasons ? props.data.claimAdjustmentReasons : [];
    const submittedProvidersData = props.data && props.data.otherPayerSubmittedProviderIDs ? props.data.otherPayerSubmittedProviderIDs : [];
    const serviceLineAdjudication = claimsInfo && claimsInfo.c837OtherPayerAdjustments ? claimsInfo.c837OtherPayerAdjustments : {};
    const otherPayerSA = claimsInfo && claimsInfo.c837LineItemProviders && claimsInfo.c837LineItemProviders.length > 0 && claimsInfo.c837LineItemProviders[0].otherPayer1 ? claimsInfo.c837LineItemProviders[0].otherPayer1 : {};
    const otherPayerSACellsList = claimsInfo && claimsInfo.c837LineItemProviders && claimsInfo.c837LineItemProviders.length > 0 && claimsInfo.c837LineItemProviders[0].otherPayer1 ? claimsInfo.c837LineItemProviders[0].otherPayer1.priorAuthorizationInfoA : [];
    const [showViewOtherPayer, setShowViewOtherPayer] = useState(false);
    const [LLAData, setLLAData] = useState({});
    const [showLLA, setShowLLA] = useState(false);
    const otherPayerSACells = [
        {
            id: 'priorAuthQualifierCode', numeric: false, disablePadding: false, label: 'Number Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'priorAuthID', numeric: false, disablePadding: false, label: 'SA or Referral Number', enableHyperLink: false, fontSize: 12
        }
    ];
    const serviceLineAdjustmentVOListCells = [
        {
            id: 'adjustmentGroupCode', numeric: false, disablePadding: true, label: 'Claim Adjustment Group Code', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'adjustmentReasonCode', numeric: false, disablePadding: false, label: 'Reason Code', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'adjustmentReasonAmount', numeric: false, disablePadding: false, label: 'Amount', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'adjustmentUnitQuantity', numeric: false, disablePadding: false, label: 'Quantity', enableHyperLink: false, fontSize: 12
        }
    ];
    const testResultLineItemVOListCells = [
        {
            id: 'testMeasurementID', numeric: false, disablePadding: true, label: 'Test Measurement ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'testMeasurementQual', numeric: false, disablePadding: false, label: 'Test measurement Qualifier', enableHyperLink: false, fontSize: 12
        }, {
            id: 'testResult', numeric: false, disablePadding: true, label: 'Test Result', enableHyperLink: false, fontSize: 12
        }
    ];
    const OtherPayerSeriveInfoCells = [
        {
            id: 'tplSequenceNumber', numeric: false, disablePadding: true, label: 'Sequence Number', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'otherPayerID', numeric: false, disablePadding: false, label: 'Other Payer Primary ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'serviceCode', numeric: false, disablePadding: false, label: 'Procedure Code', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'paidUnitCount', numeric: false, disablePadding: false, label: 'Paid Service Unit Count', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerPaidAmount', numeric: false, disablePadding: false, label: 'Service Line Paid Amount', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerPaidDate', numeric: false, disablePadding: false, label: 'Adjudicated or Pay Date', enableHyperLink: false, fontSize: 12
        }
    ];

    const SecIDs = [
        {
            id: 'providerIDType', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12
        }
    ];
    const ContactInfoCells = [
        {
            id: 'contactName', numeric: false, disablePadding: true, label: 'Name', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'communicationNumber1', numeric: false, disablePadding: false, label: 'Phone / Ext.', enableHyperLink: false, fontSize: 12, width: 200
        },
        {
            id: 'communicationQualifierCode1', numeric: false, disablePadding: false, label: 'Fax', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'email', numeric: false, disablePadding: false, label: 'Email', enableHyperLink: false, fontSize: 12
        }
    ];
    const previousLineItem = () => {
        if (lineItemNum == 1) {
            return false;
        }
        setLineItemNum(lineItemNum - 1);
    };
    const nextLineItem = () => {
        if (lineItemNum == Object.keys(lineItemOtherServiceMap).length) {
            return false;
        }
        setLineItemNum(lineItemNum + 1);
    };
  
    
    return (
        <div>
            <div className='tabs-container my-3'>
                <div className='tab-header'>
                    <h1 className="tab-heading float-left">Line #{serviceInfodates?.lineNumber}</h1>
                    <div className="float-right th-btnGroup">
                        <Button data-test="previous_click" variant="outlined" color="primary" className="btn btn-primary" onClick={previousLineItem}>
                            <i className="fa fa-arrow-left" />
                    Previous
                </Button>
                        <Button data-test="next_click" variant="outlined" color="primary" className="btn btn-primary" onClick={nextLineItem}>
                            Next
                     <i className="fa fa-arrow-right ml-1" />
                        </Button>
                    </div>
                </div>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3'>
                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panelp1a-content1"
                            id="panelp1a-header1">
                            <Typography className={classes.heading}>Service Line Information</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3542">
                                    <Typography className={classes.heading}>Relevant Dates</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper wrap-form-label">
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Last Seen"
                                                    label="Date Last Seen"
                                                    format="MM/dd/yyyy"
                                                    data-test="DataLastSeen"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.lastSeenDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="dateshipped"
                                                    label="Date Shipped"
                                                    data-test="dateshipped"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.shippedDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>

                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="onsetofcurrentilnessorshinppngdate"
                                                    label="Onset of Current Illness / Symptom Date"
                                                    format="MM/dd/yyyy"
                                                    data-test="Current Illness"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates.illnessDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="similarillnesorsymptomdate"
                                                    label="Similar Illness / Symptom Date"
                                                    format="MM/dd/yyyy"
                                                    data-test="Similar Illness"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.similarIllnessDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="lastcertification"
                                                    label="Last Certification"
                                                    format="MM/dd/yyyy"
                                                    data-test="Last Certification"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.lastCertificationDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="certificationrevsion"
                                                    label="Certification Revision"
                                                    data-test="certificationrevsion"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                         serviceInfodates?.certificationRevisionDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="begintherapy"
                                                    label="Begin Therapy"
                                                    data-test="begintherapy"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.therapyBeginDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="lastxraydate"
                                                    label="Last X-ray Date"
                                                    format="MM/dd/yyyy"
                                                    data-test="lastxraydate"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.lastXRayDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="acutemanifestaiondate"
                                                    label="Acute Manifestation Date"
                                                    format="MM/dd/yyyy"
                                                    data-test="acutemanifestaiondate"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                         serviceInfodates?.acuteDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="initialtreatmentdate"
                                                    label="Initial Treatment Date"
                                                    data-test="initialtreatmentdate"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.initialTreatmentDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                    </div>
                                    <div className="form-wrapper wrap-form-label">
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="oxygensaturationtestdate"
                                                    label="Oxygen Saturation Test Date"
                                                    data-test="oxygensaturationtestdate"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                         serviceInfodates?.oxygenTherapy?.dependantEdemaTestDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="hemolobintestdate"
                                                    label="Hemoglobin Test Date"
                                                    format="MM/dd/yyyy"
                                                    data-test="hemolobintestdate"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.testInfo?.testDate1 || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="arterialbloodgastestdate"
                                                    label="Arterial Blood Gas Test Date"
                                                    format="MM/dd/yyyy"
                                                    data-test="arterialbloodgastestdate"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.oxygenTherapy?.dependantEdemaTestDate || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="serumcretinetestdate"
                                                    label="Serum Creatine Test Date"
                                                    data-test="serumcretinetestdate"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        serviceInfodates?.testInfo?.testDate1 || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>


                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header26893">
                                    <Typography className={classes.heading}>Miscellaneous Line Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="immunizationbatch#"
                                                label="Immunization Batch #"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.immunizationBatchNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="postageclaimedamnt"
                                                label="Postage Claimed Amount"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.postageClaimedAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="salestaxamount"
                                                label="Sales Tax Amount"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.taxAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="approvedamount"
                                                label="Approved Amount"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.approvedAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="referringclia#"
                                                label="Referring CLIA #"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.referringCLIANumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="lineitmecontrol#"
                                                label="Line Item Control #"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.controlNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mammographycertification#"
                                                label="Mammography Certification #"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.mammographyCertificationID || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="ambulatorypatientgroup#"
                                                label="Ambulatory Patient Group #"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.ambulatoryPatientGroup?.apgCode1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="obstretricanesthesiaatnlunits"
                                                label="Obstetric Anesthesia Additional Units"
                                                placeholder=""
                                                value={ serviceInfodates?.obstetricAnesthesiaAddlUnitQuantity || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="repricedclaimreferencenumber"
                                                label="Repriced Claim Reference Number"
                                                placeholder=""
                                                value={claimsInfo?.c837Claim?.repricedClaimNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="repricedclaimreferencenumber"
                                                label="Adjusted Repriced Claim Reference Number"
                                                placeholder=""
                                                value={claimsInfo?.c837Claim?.adjustedRepricedClaimQualiferCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Hospice Employer Provider Indicator:</label>
                                            </div>
                                            <div className="sub-radio">
                                                <RadioGroup
                                                    row
                                                    aria-label="Hospice Employer Provider Indicator"
                                                    name="Hospice Employer Provider Indicator"
                                                    value={serviceInfodates?.hospiceEmployeeIndicator || "No"}
                                                >
                                                    <FormControlLabel
                                                        disabled
                                                        value="Yes"
                                                        control={<Radio color="primary" />}
                                                        label="Yes"
                                                        className="primary-text"
                                                    />
                                                    <FormControlLabel
                                                        disabled
                                                        value="No"
                                                        control={<Radio color="primary" />}
                                                        label="No"
                                                        className="primary-text"
                                                    />
                                                </RadioGroup>
                                            </div>
                                        </div>

                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="upnqualifier"
                                                label="UPN Qualifier"
                                                placeholder=""
                                                type="number"
                                                value={ miscellaneousLineInfoVO?.universalProductQualifierCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mscupn"
                                                label="UPN"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.universalProductNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mscproceduredesc"
                                                label="Procedure Description"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.proceduredescritpion || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3">
                                    <Typography className={classes.heading}>Contract Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="contracttypecode"
                                                label="Contract Type Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.contractTypeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="sercontractamount"
                                                label="Contract Amount"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO.contractAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="sercontractpercent"
                                                label="Contract Percent"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.contractPercentage || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="sercontractcode"
                                                label="Contract Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.contractCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="termsdiscountpercent"
                                                label="Terms Discount Percent"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.contractDiscountPercentage || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="sercontractversionid"
                                                label="Contract Version ID"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.contractVersionID || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>


                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3">
                                    <Typography className={classes.heading}>Claims Pricing/Repricing</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="pricingmethodologycode"
                                                label="Pricing Methodology Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.methodologyCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serallowedamount"
                                                label="Allowed Amount"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.repriceAllowedAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="sersavingsamount"
                                                label="Savings Amount"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.savingsAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorganizationidentifier"
                                                label="Organization Identifier"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.organizationID || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serperdiemorflatrateamnt"
                                                label="Per Diem or Flat Rate Amount"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.repricePerDiemRate || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprvddrgcode"
                                                label="Approved DRG Code"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.repriceAPGCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprvdrgamnt"
                                                label="Approved DRG Amount"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.repriceAPGAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="repricedaprvdsrvccode"
                                                label="Repriced Approved Procedure Service Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.serviceCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprunitqunty"
                                                label="Approved Unit Quantity"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.unitCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrjectionrsncode"
                                                label="Rejection Reason Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.rejectReasonCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serpolicycompliancecode"
                                                label="Policy Compliance Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.policyComplianceCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serexceipitoncode"
                                                label="Exception Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.exceptionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>

                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panelp1a-content2"
                            id="panelp1a-header27902">
                            <Typography className={classes.heading}>Service Line Provider Information</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header36913">
                                    <Typography className={classes.heading}>Rendering Provider Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={renderingProviderInfo?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={renderingProviderInfo?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi"
                                                label="MI"
                                                placeholder=""
                                                value={renderingProviderInfo?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={ renderingProviderInfo?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>



                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={renderingProviderInfoSecIDsData} onTableRowClick={unwantedFunc} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header27902">
                                    <Typography className={classes.heading}>Service Facility Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serotherentitytype"
                                                label="Entity Type"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.entityTypeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrorglastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.serviceFacilityName?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrrotherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.serviceFacilityName?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seeerothersermi"
                                                label="MI"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.serviceFacilityName?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrrothersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.serviceFacilityName?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="serrseaddr1"
                                                label="Address1"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.addressLine1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="serotherentitytypecountryaddr2"
                                                label="Address 2"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.addressLine2 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrseaddrcity"
                                                label="City"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.cityName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrseaddrcstate"
                                                label="State"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.stateCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <div className="cndt-row">
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="zipandextension412"
                                                        label="Zip and Extension"
                                                        placeholder=""
                                                        value={serviceInfoServiceFacilityInfo?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="zipandextension4122"
                                                        placeholder=""
                                                        value={ serviceInfoServiceFacilityInfo?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>

                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serotherentitytypecountry"
                                                label="Country"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo?.countryCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serotherentitytypecountrysubdiv"
                                                label="Subdivision Code"
                                                placeholder=""
                                                value={ serviceInfoServiceFacilityInfo?.countrySubDivisionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                    </div>
                                    <div className="tabs-container">
                                        <div className="tab-header mt-2">
                                            <h2 className="tab-heading float-left">Secondary IDs</h2>
                                        </div>
                                        <div className="tab-body-bordered mt-0">
                                            <TableComponent headCells={SecIDs} tableData={renderingProviderInfoSecIDsData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header27902">
                                    <Typography className={classes.heading}>Referring Provider Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    {/* <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Additional Referring Provider Information </h2>
                                        </div> */}

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entityqualifier32rb"
                                                label="Entity Qualifier"
                                                placeholder=""
                                                value={serviceInfoServiceFacilityInfo.taxonomyQualifierCode ? serviceInfoServiceFacilityInfo.taxonomyQualifierCode : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={referringProviderInfo?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={referringProviderInfo?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi"
                                                label="MI"
                                                placeholder=""
                                                value={referringProviderInfo?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={referringProviderInfo?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>



                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={renderingProviderInfoSecIDsData} onTableRowClick={unwantedFunc} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header279034432">
                                    <Typography className={classes.heading}>Primary Care Provider Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    {/* <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Additional Primary Care Provider Information </h2>
                                        </div> */}
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={additionalPrimaryCareProviderInformation?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={additionalPrimaryCareProviderInformation?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi"
                                                label="MI"
                                                placeholder=""
                                                value={additionalPrimaryCareProviderInformation?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={ additionalPrimaryCareProviderInformation?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>


                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={renderingProviderInfoSecIDsData} onTableRowClick={unwantedFunc} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header279034432">
                                    <Typography className={classes.heading}>Purchased Service Provider Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    {/* <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Additional Purchased Service Provider Information </h2>
                                        </div> */}
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entityqulifserorgorlastname"
                                                label="Entity Qualifier"
                                                placeholder=""
                                                value={ purchasedServiceProviderInfo?.entityTypeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>


                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={renderingProviderInfoSecIDsData} onTableRowClick={unwantedFunc} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>



                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header279477502">
                                    <Typography className={classes.heading}>Ordering Provider Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrorglastnam11e"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={orderingProviderInfo?.providerName?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrrotherserfirstname1"
                                                label="First Name"
                                                placeholder=""
                                                value={ orderingProviderInfo?.providerName?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seeerotherserm1i"
                                                label="MI"
                                                placeholder=""
                                                value={ orderingProviderInfo?.providerName?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrrothersersuffux1"
                                                label="Suffix"
                                                placeholder=""
                                                value={orderingProviderInfo?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="serrseaddr11"
                                                label="Address1"
                                                placeholder=""
                                                value={orderingProviderInfo?.addressLine1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="serotherentitytypecountryaddr21"
                                                label="Address 2"
                                                placeholder=""
                                                value={orderingProviderInfo?.addressLine2 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrseaddrcity1"
                                                label="City"
                                                placeholder=""
                                                value={orderingProviderInfo?.cityName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrseaddrcstat1e"
                                                label="State"
                                                placeholder=""
                                                value={orderingProviderInfo?.stateCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <div className="cndt-row">
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="zipandextension4112"
                                                        label="Zip and Extension"
                                                        placeholder=""
                                                        value={orderingProviderInfo?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="zipandextension41212"
                                                        placeholder=""
                                                        value={orderingProviderInfo?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>

                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serotherentitytypecountry1"
                                                label="Country"
                                                placeholder=""
                                                value={orderingProviderInfo?.countryCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serotherentitytypecountrysubdiv1"
                                                label="Subdivision Code"
                                                placeholder=""
                                                value={orderingProviderInfo?.countrySubDivisionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>


                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={renderingProviderInfoSecIDsData} onTableRowClick={unwantedFunc} defaultSortColumn="idtype" />
                                    </div>
                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Contact Information </h2>
                                        </div>
                                        <TableComponent headCells={ContactInfoCells} tableData={contactInfoVOList} onTableRowClick={unwantedFunc} defaultSortColumn="name" />
                                        <TableComponent headCells={ContactInfoCells} tableData={orderingProviderInfoList} onTableRowClick={() => { return false; }} defaultSortColumn="name" />
                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3">
                                    <Typography className={classes.heading}>Supervising Provider Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname333"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={supervisingProviderInfo?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname12"
                                                label="First Name"
                                                placeholder=""
                                                value={supervisingProviderInfo?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi76"
                                                label="MI"
                                                placeholder=""
                                                value={supervisingProviderInfo?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux145"
                                                label="Suffix"
                                                placeholder=""
                                                value={supervisingProviderInfo?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>

                                    <div className="tabs-container">
                                        <div className="tab-header mt-2">
                                            <h2 className="tab-heading float-left">Secondary IDs</h2>
                                        </div>
                                        <div className="tab-body-bordered mt-0">
                                            <TableComponent headCells={SecIDs} tableData={renderingProviderInfoSecIDsData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>

                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panelp1a-content3"
                            id="panelp1a-header3">
                            <Typography className={classes.heading}>Specialized Line Information</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content1"
                                    id="panelp1a-header1">
                                    <Typography className={classes.heading}>Durable Medical Equipment</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="orglastnampce"
                                                label="Procedure Code"
                                                placeholder=""
                                                value={durableMedicalEquipment?.serviceID || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="orglastnamefrequency"
                                                label="Frequency"
                                                placeholder=""
                                                value={durableMedicalEquipment?.rentalUnitPriceIndicator || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="MI12lngmedcialnes"
                                                label="Length of Medical Necessity"
                                                placeholder=""
                                                value={ durableMedicalEquipment?.durationNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    endAdornment: <InputAdornment position="end">days</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                    </div>

                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entitytype1dmere"
                                                label="DME Rental Price"
                                                placeholder=""
                                                value={durableMedicalEquipment?.rentalAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entitytype1dmereorpricepp"
                                                label="DME Purchase Price"
                                                placeholder=""
                                                value={durableMedicalEquipment?.dmepurchasePrice || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content1"
                                    id="panelp1a-header1">
                                    <Typography className={classes.heading}>DMERC</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="attachmenttransimdate"
                                                label="Attachment Transmission Code"
                                                placeholder=""
                                                value={durableMedicalEquipment?.transmissionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="ceficationtypecoderti"
                                                label="Certification Type Code"
                                                placeholder=""
                                                value={durableMedicalEquipment?.certificationTypeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="numberofmonthsneeded"
                                                label="Number of Months Needed"
                                                placeholder=""
                                                value={durableMedicalEquipment?.durationNumber || "0"}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                        <div className="mui-custom-form input-md">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl Mui-disabled">Certification Condition Indicator:</label>
                                            </div>
                                            <div className="sub-radio">
                                                <RadioGroup
                                                    row
                                                    aria-label="eftactive"
                                                    name="dmerccci"
                                                    value={ durableMedicalEquipment?.certificationIndicator1 || "No"}
                                                >
                                                    <FormControlLabel
                                                        disabled
                                                        value="Yes"
                                                        control={<Radio color="primary" />}
                                                        label="Yes"
                                                    />
                                                    <FormControlLabel
                                                        disabled
                                                        value="No"
                                                        control={<Radio color="primary" />}
                                                        label="No"
                                                    />
                                                </RadioGroup>
                                            </div>
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="codecategory12dmerccc"
                                                label="Code Category"
                                                placeholder=""
                                                value={durableMedicalEquipment?.certificationCode1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition31dmerc1"
                                                label="Condition 1"
                                                placeholder=""
                                                value={durableMedicalEquipment?.conditionCode1A || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition3dmerc2"
                                                label="Condition 2"
                                                placeholder=""
                                                value={ durableMedicalEquipment?.conditionCode1B || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition33dmerc3"
                                                label="Condition 3"
                                                placeholder=""
                                                value={ durableMedicalEquipment?.conditionCode1C || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition34dmerc4"
                                                label="Condition 4"
                                                placeholder=""
                                                value={durableMedicalEquipment?.conditionCode1D || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition35dmerc5"
                                                label="Condition 5"
                                                placeholder=""
                                                value={ durableMedicalEquipment?.conditionCode1E || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header2">
                                    <Typography className={classes.heading}>Home Health Care</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="numberofvisits"
                                                label="Number of Visits"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.visitsCount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="frequnecyperiod"
                                                label="Frequency Period"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.visitFrequencyPeriodCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="frequencycount"
                                                label="Frequency Count"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.visitFrequencyCount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="typesofunts"
                                                label="Types of Units"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.visitPeriodQualifierCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="numberofunitsCount"
                                                label="Number of Units"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.numofUnits || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="aptterncodehh"
                                                label="Pattern Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.visitPatternCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="TimeCodehh"
                                                label="Time Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.visitPatternTimeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>


                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header2">
                                    <Typography className={classes.heading}>Home Oxygen Therapy</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="certificaitontypecodehot"
                                                label="Certification Type Code"
                                                placeholder=""
                                                value={oxygenTherapy?.certificationTypeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="treatperiodcounthot"
                                                label="Treatment Period Count"
                                                placeholder=""
                                                value={oxygenTherapy?.certificationPeriod || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="arterialbloodgashot"
                                                label="Arterial Blood Gas Quantity"
                                                placeholder=""
                                                value={oxygenTherapy?.bloodGasQuantity || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="oxygensaturationquantityhot"
                                                label="Oxygen Saturation Quantity"
                                                placeholder=""
                                                value={oxygenTherapy?.saturationQuantity || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="oxygentestcondintioncodehot"
                                                label="Oxygen Test Condition Code"
                                                placeholder=""
                                                value={oxygenTherapy?.testConditionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="oxygenflowrate"
                                                label="Oxygen Flow Rate"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.oxygenFlowRateQualifierCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="tab-header mt-1">
                                        <h2 className="tab-heading pb-0"> Oxygen Test Finding Code:</h2>
                                        <span className="txt-instruction">(Check all boxes that apply)</span>
                                    </div>
                                    <div className="form-wrapper sub-radio-group">
                                        <div className="sub-radio w-100">
                                            <Checkbox
                                                disabled
                                                type="checkbox"
                                                value={oxygenTherapy?.dependantEdemaCode[0] || null}
                                                id="deschf"
                                                checked={oxygenTherapy.dependantEdemaCode && oxygenTherapy.dependantEdemaCode[0] == 1 ? true : false}
                                            />
                                            <label className="text-black" htmlFor="deschf">Dependent Edema Suggesting Congestive Heart Failure</label>
                                        </div>
                                        <div className="sub-radio w-100">
                                            <Checkbox
                                                disabled
                                                type="checkbox"
                                                value={oxygenTherapy.pulmonaleCode ? oxygenTherapy.pulmonaleCode[1] : null}
                                                id="ppoeekg"
                                                checked={oxygenTherapy.pulmonaleCode && oxygenTherapy.pulmonaleCode[1] == 2 ? true : false}
                                            />
                                            <label className="text-black" htmlFor="ppoeekg">"P" Pulmonale on Electrocardiogram (EKG)</label>
                                        </div>
                                        <div className="sub-radio w-100">
                                            <Checkbox
                                                disabled
                                                type="checkbox"
                                                value={oxygenTherapy.erythrocythemiaCode ? oxygenTherapy.erythrocythemiaCode[2] : null}
                                                id="ewahg56"
                                                checked={oxygenTherapy.erythrocythemiaCode && oxygenTherapy.erythrocythemiaCode[2] == 3 ? true : false}
                                            />
                                            <label className="text-black" htmlFor="ewahg56">Erythrocythemia with a Hematocrit Greater Than 56%</label>
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3">
                                    <Typography className={classes.heading}>Ambulance</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Ambulance2Transport1Code"
                                                label="Transport Code"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.transportCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Ambulance2TransportReasonCode"
                                                label="Transport Reason Code"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.transportReasonCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Transport3Distance"
                                                label="Transport Distance"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.transportDistance || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    endAdornment: <InputAdornment position="end">miles</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Patient Weight"
                                                label="Patient Weight"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.patientWeight || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    endAdornment: <InputAdornment position="end">lbs</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-md">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="Round3Trip4Purpose5Description"
                                                    id="Round3Trip4Purpose5Description-label">Round Trip Purpose Description</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    id="Round3Trip4Purpose5Description"
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    value={serviceInfoAmbulance?.roundTripDescription || ""}
                                                    placeholder=""
                                                />
                                            </div>
                                        </div>
                                        <div className="mui-custom-form input-md field-md">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="Round3Trirtp4Purpose5Description"
                                                    id="Round3Trirtp4Purpose5Description-label">Stretcher Purpose Description</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    id="Round3Trirtp4Purpose5Description"
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    value={serviceInfoAmbulance?.stretcherDescription || ""}
                                                    placeholder=""
                                                />
                                            </div>
                                        </div>
                                        <div className="mui-custom-form w-100">
                                            <div className={classes.root}>
                                                <Alert severity="error">If the patient was admitted to the hospital, please enter the admission date in the Relevant Dates Section of the Other Claim Info tab.</Alert>
                                            </div>
                                        </div>
                                    </div>

                                    <div className="form-wrapper p-0">
                                        <div className="mui-custom-form input-md field-xl">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Certification Condition Indicator:</label>
                                            </div>
                                            <div className="sub-radio mt-0">
                                                <RadioGroup
                                                    row
                                                    aria-label="eftactive"
                                                    name="serviceInfoAmbulanceconditionInd"
                                                    value={serviceInfoAmbulance?.certificationIndicator1 || "No"}
                                                >
                                                    <FormControlLabel
                                                        disabled
                                                        value="Yes"
                                                        control={<Radio color="primary" />}
                                                        label="Yes"
                                                    />
                                                    <FormControlLabel
                                                        disabled
                                                        value="No"
                                                        control={<Radio color="primary" />}
                                                        label="No"
                                                    />
                                                </RadioGroup>
                                            </div>
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition 1"
                                                label="Condition 1"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.conditionCode1A || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition 2"
                                                label="Condition 2"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.conditionCode1B || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition 3"
                                                label="Condition 3"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.conditionCode1C || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition 4"
                                                label="Condition 4"
                                                placeholder=""
                                                value={serviceInfoAmbulance?.conditionCode1D || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Condition 5"
                                                label="Condition 5"
                                                placeholder=""
                                                value={ serviceInfoAmbulance?.conditionCode1E || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3">
                                    <Typography className={classes.heading}>Ambulance Pickup Location</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="Addresserfd1"
                                                label="Address 1"
                                                placeholder=""
                                                value={ serviceInfoAmbulancePickUp?.addressLine1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="Addresser2"
                                                label="Address 2"
                                                placeholder=""
                                                value={serviceInfoAmbulancePickUp?.addressLine2 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="City"
                                                label="City"
                                                placeholder=""
                                                value={ serviceInfoAmbulancePickUp?.cityName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="State"
                                                label="State"
                                                placeholder=""
                                                value={ serviceInfoAmbulancePickUp?.stateCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <div className="cndt-row">
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="ZipsdandsdExtension"
                                                        label="Zip and Extension"
                                                        placeholder=""
                                                        value={ serviceInfoAmbulancePickUp?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="ZipsdandsdExtension1"
                                                        placeholder=""
                                                        value={serviceInfoAmbulancePickUp?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>

                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Country12"
                                                label="Country"
                                                placeholder=""
                                                value={serviceInfoAmbulancePickUp?.countryCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Subdivision Code"
                                                label="Subdivision Code"
                                                placeholder=""
                                                value={serviceInfoAmbulancePickUp?.countrySubDivisionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3">
                                    <Typography className={classes.heading}>Ambulance Drop off Location</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="AmbulanceorgDropoffnameLocation"
                                                label="Organization Name"
                                                placeholder=""
                                                // value={serviceInfoAmbulanceDropOff.addressLine1 ? serviceInfoAmbulanceDropOff.addressLine1 : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="Address1233"
                                                label="Address 1"
                                                placeholder=""
                                                value={serviceInfoAmbulanceDropOff?.addressLine1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="Address12333"
                                                label="Address 2"
                                                placeholder=""
                                                value={ serviceInfoAmbulanceDropOff?.addressLine2 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="City1233"
                                                label="City"
                                                placeholder=""
                                                value={serviceInfoAmbulanceDropOff?.cityName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="State1233"
                                                label="State"
                                                placeholder=""
                                                value={serviceInfoAmbulanceDropOff?.stateCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <div className="cndt-row">
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="Zipandextension1"
                                                        label="Zip and Extension"
                                                        placeholder=""
                                                        value={serviceInfoAmbulanceDropOff?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="Zipandextension122"
                                                        placeholder=""
                                                        value={serviceInfoAmbulance?.zipCode || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>

                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Country122"
                                                label="Country"
                                                placeholder=""
                                                value={ serviceInfoAmbulanceDropOff?.countryCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Subdivisioncode12"
                                                label="Subdivision Code"
                                                placeholder=""
                                                value={serviceInfoAmbulanceDropOff?.countrySubDivisionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>


                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content4"
                                    id="panelp1a-header4">
                                    <Typography className={classes.heading}>Service Notes</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md field-xl">
                                            <TextField
                                                disabled
                                                id="typecodde12"
                                                label="Type Code"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.noteCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md field-xl">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="dddwdsghsgtertrSD"
                                                    id="dddwdsghsgtertrSD-label">Note</label>
                                            </div>
                                            <div className="disabled-form pt-4">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    id="dddwdsghsgtertrSD"
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    value={miscellaneousLineInfoVO?.noteText || ""}
                                                    placeholder=""
                                                />
                                            </div>
                                            <div className="mt-1">
                                                <Chip avatar={<Avatar>{miscellaneousLineInfoVO?.length || 80}</Avatar>} label="Characters remaining" />
                                            </div>
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content4"
                                    id="panelp1a-header444">
                                    <Typography className={classes.heading}>Third Party Organization Notes</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md field-xl">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="dddwdsghsgtertrSD"
                                                    id="dddwdsghsgtertrSD-label">Notes</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    id="dddwdsghsgtertrSD"
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    value={miscellaneousLineInfoVO?.thridPartyOrgRepricedNoteText || ""}
                                                    placeholder=""
                                                />
                                            </div>
                                            <div className="mt-1"><Chip avatar={<Avatar>{miscellaneousLineInfoVO?.length || 80}</Avatar>} label="Characters remaining" /></div>
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content4"
                                    id="panelp1a-header4444">
                                    <Typography className={classes.heading}>File Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 1ser"
                                                label="File Information 1"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 2ser"
                                                label="File Information 2"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation2 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 3ser"
                                                label="File Information 3"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation3 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 4ser"
                                                label="File Information 4"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation4 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 5ser"
                                                label="File Information 5"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation5 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 6ser"
                                                label="File Information 6"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation6 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 7ser"
                                                label="File Information 7"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation7 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 8ser"
                                                label="File Information 8"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation8 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File Information 9ser"
                                                label="File Information 9"
                                                placeholder=""
                                                value={ miscellaneousLineInfoVO?.fileInfo?.fileInformation9 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="File4Information 10ser"
                                                label="File Information 10"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.fileInfo?.fileInformation10 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content4"
                                    id="panelp1a-header4">
                                    <Typography className={classes.heading}>Spinal Manipulation</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="natreofcondition"
                                                label="Nature of Condition"
                                                placeholder=""
                                                value={ serviceInfoSpinalInfo?.conditionCode1 || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md field-md">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="dddwdsgedfdhsgtertrSD"
                                                    id="dddwdsgedfdhsgtertrSD-label">Condition Description 1</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    id="dddwdsgedfdhsgtertrSD"
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    value={serviceInfoSpinalInfo?.conditionDescription1A || ""}
                                                    placeholder=""
                                                />
                                            </div>
                                        </div>
                                        <div className="mui-custom-form input-md field-md">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="dddwdsgedfdhdsdsgtertrSD"
                                                    id="dddwdsgedfdhdsdsgtertrSD-label">Condition Description 2</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    id="dddwdsgedfdhdsdsgtertrSD"
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    value={ serviceInfoSpinalInfo?.conditionDescription1B || ""}
                                                    placeholder=""
                                                />
                                            </div>
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">X-ray Availability Indicator:</label>
                                            </div>
                                            <div className="sub-radio mt-0">
                                                <RadioGroup
                                                    row
                                                    aria-label="eftactive"
                                                    name="Xrayavilabil1"
                                                    value={serviceInfoSpinalInfo?.spinalXRayAvailabilityIndicator1 || "No"}
                                                >
                                                    <FormControlLabel
                                                        disabled
                                                        value="Yes"
                                                        control={<Radio color="primary" />}
                                                        label="Yes"
                                                    />
                                                    <FormControlLabel
                                                        disabled
                                                        value="No"
                                                        control={<Radio color="primary" />}
                                                        label="No"
                                                    />
                                                </RadioGroup>
                                            </div>
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>


                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content4"
                                    id="panelp1a-header4564">
                                    <Typography className={classes.heading}>Purchased Services</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="purchasedserivepoverid"
                                                label="Purchased Service Provider ID"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.purchasedServiceProviderID || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="purchasedserivepoveridamnt"
                                                label="Purchased Service Amount"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.purchasedServiceChargeAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content4"
                                    id="panelp1a-header441233">
                                    <Typography className={classes.heading}>Test Result Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="tabs-container px-1 mt-3">
                                        <TableComponent headCells={testResultLineItemVOListCells} tableData={testResultLineItemVOList && testResultLineItemVOList.length > 0 ? testResultLineItemVOList : [] } onTableRowClick={unwantedFunc} defaultSortColumn="testMeasurementID" />
                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content4"
                                    id="panelp1a-header441332">
                                    <Typography className={classes.heading}>Form Identification Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="formtypeserform"
                                                label="Form Type"
                                                placeholder=""
                                                value={claimsInfo?.c837Questions?.formIDQualifierCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="formidserifrm"
                                                label="Form ID"
                                                placeholder=""
                                                value={claimsInfo?.c837Questions?.formID || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>

                                    <div className="tabs-container">
                                        <div className="tab-header px-1">
                                            <h2 className="tab-heading float-left">  Supporting Documentation Information </h2>
                                        </div>
                                        <div className="form-wrapper tab-body-bordered mt-0">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="formtypeserform"
                                                    label="Question # or Letter"
                                                    placeholder=""
                                                    value={claimsInfo?.c837Questions?.questionCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="tab-header w-100 ml-2">
                                                <h2 className="tab-heading float-left"> Possible Responses to Question Referenced Above </h2>
                                            </div>
                                            <div className="mui-custom-form input-md field-xl">

                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Question Response</label>
                                                </div>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        row
                                                        aria-label="eftactive"
                                                        name="WuestionResoponse"
                                                        value={ claimsInfo?.c837Questions?.responseCode || "No"}
                                                    >
                                                        <FormControlLabel
                                                            disabled
                                                            value="Yes"
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            disabled
                                                            value="No"
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                        <FormControlLabel
                                                            disabled
                                                            value="N/A"
                                                            control={<Radio color="primary" />}
                                                            label="N/A"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="refernceidorresponse"
                                                    label="Reference ID  Response"
                                                    placeholder=""
                                                    value={claimsInfo?.c837Questions?.formIDQualifierCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="percentresponse"
                                                    label="Percent Response"
                                                    placeholder=""
                                                    value={claimsInfo?.c837Questions?.responsePercent || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="dataeresponse"
                                                    label="Date Response"
                                                    placeholder=""
                                                    value={claimsInfo?.c837Questions?.responseDate || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                        </div>

                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>



                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panelp1a-content4"
                            id="panelp1a-header4412902">
                            <Typography className={classes.heading}>Other Payer Service Line Provider Information</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <div className="tabs-container">
                                <div className="tab-header">
                                    <h2 className="tab-heading float-left"> Other Payer Service Information</h2>
                                </div>
                                <TableComponent headCells={OtherPayerSeriveInfoCells} tableData={serviceLineAdjudicationList} onTableRowClick={(row)=> (event) => viewOtherInfo(event, row, setShowViewOtherPayer)} defaultSortColumn="groupCode" />
                                {showViewOtherPayer ? (
                                    <div className="tabs-container mt-3">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left">
                                                View Other Payer Service Information
                                        </h2>
                                            <div className="float-right th-btnGroup">
                                                <Button variant="outlined" color="primary" className="btn btn-primary" onClick={() => { setShowViewOtherPayer(false); }}>
                                                    Close
                                            </Button>
                                            </div>
                                        </div>
                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content13"
                                                id="panelp1a-heaf5fgder13">
                                                <Typography className={classes.heading}>Service Line Adjudication</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="form-wrapper">
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="serorseqgorlastname"
                                                            label="Sequence Number"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.sequenceNumber ? serviceLineAdjudication.sequenceNumber : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="dddesd"
                                                            label="Other Payer Primary ID"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.otherPayerID ? serviceLineAdjudication.otherPayerID : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="othe3srsermi"
                                                            label="Service Line Paid Amount"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.otherPayerPaidAmount ? serviceLineAdjudication.otherPayerPaidAmount : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                        <div className="mui-custom-form input-md with-select">
                                                            <KeyboardDatePicker
                                                                disabled
                                                                id="DatesdaLastsdfSeen"
                                                                label="Adjudicated or Pay Date"
                                                                format="MM/dd/yyyy"
                                                                InputLabelProps={{
                                                                    shrink: true
                                                                }}
                                                                placeholder="mm/dd/yyyy"
                                                                value={
                                                                    serviceLineAdjudication.otherPayerPaidDate ? serviceLineAdjudication.otherPayerPaidDate : null
                                                                }
                                                                KeyboardButtonProps={{
                                                                    "aria-label": "change date"
                                                                }}
                                                            />
                                                        </div>
                                                    </MuiPickersUtilsProvider>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="dgftr45fg"
                                                            label="Paid Service Unit Count"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.paidUnitCount ? serviceLineAdjudication.paidUnitCount : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="dgf5grttr45fg"
                                                            label="Bundled Line Number"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.bundlingLineNumber ? serviceLineAdjudication.bundlingLineNumber : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="form-wrapper">
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="asdfn454fgh"
                                                            label="Procedure Qualifier"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.serviceQualifierCode ? serviceLineAdjudication.serviceQualifierCode : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="44456nfgh"
                                                            label="Procedure Code"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.serviceCode ? serviceLineAdjudication.serviceCode : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="othesdfg4d3srsermi"
                                                            label="Procedure Code Description"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.serviceDescription ? serviceLineAdjudication.serviceDescription : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>

                                                </div>
                                                <div className="form-wrapper">
                                                    <div className="tab-header w-100 ml-2"><h2 className="tab-heading float-left">Procedure Code</h2></div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="Zipasdf"
                                                            label=" Modifier 1"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.procedureModifier1 ? serviceLineAdjudication.procedureModifier1 : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">1</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="ZipdsandasEx2tension1"
                                                            label="Modifier 2"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.procedureModifier2 ? serviceLineAdjudication.procedureModifier2 : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">2</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="ZipdsandasExt3ension1"
                                                            label="Modifier 3"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.procedureModifier3 ? serviceLineAdjudication.procedureModifier3 : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">3</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="ZipdsandasEx4tension1"
                                                            label="Modifier 4"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.procedureModifier4 ? serviceLineAdjudication.procedureModifier4 : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="asdrffn454fgh"
                                                            label="Remaining Patient Liability"
                                                            placeholder=""
                                                            value={serviceLineAdjudication.remainingPatientLiabilityAmount ? serviceLineAdjudication.remainingPatientLiabilityAmount : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                                    <ExpansionPanelSummary
                                                        expandIcon={<ExpandMoreIcon />}
                                                        aria-controls="panelp1a-content13"
                                                        id="panesr34lp1a-header13">
                                                        <Typography className={classes.heading}>Service Adjustment</Typography>
                                                    </ExpansionPanelSummary>
                                                    <ExpansionPanelDetails>
                                                        <div className="tabs-container mt-2">
                                                            <div className="tab-header">
                                                                <h2 className="tab-heading float-left"> Line Level Adjustments </h2>
                                                            </div>
                                                            <TableComponent headCells={serviceLineAdjustmentVOListCells} tableData={lineLevelAdjudicationList} onTableRowClick={(row)=> (event) => viewLLA(event, row, setShowLLA, setLLAData)} defaultSortColumn="idtype" />
                                                            {showLLA ?
                                                                <div className="tabs-container">
                                                                    <div className="tab-header">
                                                                        <h2 className="tab-heading float-left">
                                                                            View Line Level Adjustments
                                            </h2>
                                                                        <div className="float-right th-btnGroup">
                                                                            <Button data-test="close_line" variant="outlined" color="primary" className="btn btn-primary" onClick={() => { setShowLLA(false); }}>
                                                                                Close
                                                </Button>
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper wrap-form-label">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="serorseqgorlasrtname"
                                                                                label="Claim Adjustment Group Code"
                                                                                placeholder=""
                                                                                value={LLAData.adjustmentGroupCode ? LLAData.adjustmentGroupCode : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="ffesdf"
                                                                                label="Reason Code"
                                                                                placeholder=""
                                                                                value={LLAData.adjustmentReasonCode ? LLAData.adjustmentReasonCode : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf3sermi"
                                                                                label="Amount"
                                                                                placeholder=""
                                                                                value={LLAData.adjustmentReasonAmount ? LLAData.adjustmentReasonAmount : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4rf5fg"
                                                                                label="Quantity"
                                                                                placeholder=""
                                                                                value={LLAData.adjustmentUnitQuantity ? LLAData.adjustmentUnitQuantity : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="ffesd4fgf"
                                                                                label="Reason Code 2"
                                                                                placeholder=""
                                                                                // value={LLAData.reason2 ? LLAData.reason2 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf3srseermi"
                                                                                label="Amount 2"
                                                                                placeholder=""
                                                                                // value={LLAData.amount2 ? LLAData.amount2.replace('$0.0','') : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4r3df5fg"
                                                                                label="Quantity 2"
                                                                                placeholder=""
                                                                                // value={LLAData.quantity2 ? LLAData.quantity2 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="ffe333sdf"
                                                                                label="Reason Code 3"
                                                                                placeholder=""
                                                                                // value={LLAData.reason3 ? LLAData.reason3 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf333sermi"
                                                                                label="Amount 3"
                                                                                placeholder=""
                                                                                // value={LLAData.amount3 ? LLAData.amount3.replace('$0.0','') : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4333rf5fg"
                                                                                label="Quantity 3"
                                                                                placeholder=""
                                                                                // value={LLAData.quantity3 ? LLAData.quantity3 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="4444f4s"
                                                                                label="Reason Code 4"
                                                                                placeholder=""
                                                                                // value={LLAData.reason4 ? LLAData.reason4 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3s444rf3sermi"
                                                                                label="Amount 4"
                                                                                placeholder=""
                                                                                // value={LLAData.amount4 ? LLAData.amount4.replace('$0.0','') : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4rf54444fg"
                                                                                label="Quantity 4"
                                                                                placeholder=""
                                                                                // value={LLAData.quantity4 ? LLAData.quantity4 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="5555sdg34"
                                                                                label="Reason Code 5"
                                                                                placeholder=""
                                                                                // value={LLAData.reason5 ? LLAData.reason5 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="555sdr4324"
                                                                                label="Amount 5"
                                                                                placeholder=""
                                                                                // value={LLAData.amount5 ? LLAData.amount5.replace('$0.0','') : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr555554rf5fg"
                                                                                label="Quantity 5"
                                                                                placeholder=""
                                                                                // value={LLAData.quantity5 ? LLAData.quantity5 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="6666we4sdf"
                                                                                label="Reason Code 6"
                                                                                placeholder=""
                                                                                // value={LLAData.reason6 ? LLAData.reason6 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf3ser55666mi"
                                                                                label="Amount 6"
                                                                                placeholder=""
                                                                                // value={LLAData.amount6 ? LLAData.amount6.replace('$0.0','') : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4rf6665fg"
                                                                                label="Quantity 6"
                                                                                placeholder=""
                                                                                // value={LLAData.quantity6 ? LLAData.quantity6 : ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                : null}
                                                        </div>
                                                    </ExpansionPanelDetails>
                                                </ExpansionPanel>
                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>

                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Rendering Provider Information</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>

                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Service Facility Information</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>

                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hesdfsdfe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Referring Provider Information</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>

                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4esdfbs4bader32">
                                                <Typography className={classes.heading}>Other Payer Primary Care Provider Information</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>


                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Purchasing Provider Information</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>


                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Ordering Provider Information</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>


                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Supervising Provider Information</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>


                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Service Authorization or Referral Number</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="form-wrapper px-0">
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="entitesdsdytype1"
                                                            label="ID"
                                                            placeholder=""
                                                            value={otherPayerSA.payerID ? otherPayerSA.payerID : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="entisdtytype1"
                                                            label="ID Type"
                                                            placeholder=""
                                                            value={otherPayerSA.payerQualifierCode ? otherPayerSA.payerQualifierCode : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="entitygcgtype1"
                                                            label="Org / Last Name"
                                                            placeholder=""
                                                            value={otherPayerSA.payerName ? otherPayerSA.payerName : ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="tabs-container inner-collapse-container">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Other Payer Service Authorization or Referral Number </h2>
                                                    </div>
                                                    <TableComponent headCells={otherPayerSACells} tableData={otherPayerSACellsList && otherPayerSACellsList.length > 0 ? otherPayerSACellsList : []} onTableRowClick={unwantedFunc} defaultSortColumn="numberType" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>

                                    </div>) : null}
                            </div>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>
            </div >
        </div >
    );
}
export default withRouter(OtherServicesInfo);