import React, { Fragment } from "react";
import { ExpansionPanel, ExpansionPanelSummary, Typography, ExpansionPanelDetails, TextField } from "@material-ui/core";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { makeStyles } from "@material-ui/core/styles";
import TableComponent from '../../../../SharedModules/Table/Table';
import { RadioGroup } from '@material-ui/core';
import { FormControlLabel } from '@material-ui/core';
import { Radio } from '@material-ui/core';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import { Divider } from "@material-ui/core";
import DateFnsUtils from '@date-io/date-fns';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider,
    DatePicker
} from '@material-ui/pickers'
import dateFnsFormat from 'date-fns/format';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import moment from 'moment';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
    small: {
        width: theme.spacing(3),
        height: theme.spacing(3),
    },
    txtfullwidth: {
        width: '100%',
    }
}));

const billingProviderheadCells = [
    { id: "providerIDType", numeric: false, disablePadding: true, label: 'ID Type', enableHyperLink: false,width: 300, fontSize: 12 },
    { id: "providerID", numeric: false, disablePadding: true, label: 'ID Number', enableHyperLink: false,width:300, fontSize: 12 }
]
const billingProviderheadCells1 = [
    { id: "payerIDType", numeric: false, disablePadding: true, label: 'ID Type', enableHyperLink: false,width:300, fontSize: 12 },
    { id: "payerIDNumber", numeric: false, disablePadding: true, label: 'ID Number', enableHyperLink: false,width:300, fontSize: 12 }
]
// export const editRow = (event, row, setOpen) => {
//     getThemeProps.setOpen(true);
// };
const editRow = row => (event) => {
    //getThemeProps.setOpen(true);
};

const billingProviderContactheadCells = [
    { id: "contactName", numeric: false, disablePadding: true, label: 'Name', enableHyperLink: false,fontSize: 12 },
    { id: "phoneNumber", numeric: false, disablePadding: true, label: 'Phone/Ext', enableHyperLink: false,fontSize: 12 },
    { id: "faxNumber", numeric: false, disablePadding: true, label: 'Fax', enableHyperLink: false,fontSize: 12 },
    { id: "emailID", numeric: false, disablePadding: true, label: 'Email', enableHyperLink: false,fontSize: 12}
]

function BasicClaimInfo(props) {
    const classes = useStyles();
    //console.log('Professional Basic Claim:',props.data);
    const claimHdr = props.data && props.data.enterpriseClaimAux ? props.data.enterpriseClaimAux : {};
    const mainDataList = claimHdr && claimHdr.c837ClaimHdr ? claimHdr.c837ClaimHdr : {};
    
    const submitter = mainDataList && mainDataList.submitterInfo ? mainDataList.submitterInfo : {};
    
    const claimProviderList = mainDataList && mainDataList.c837ClaimProvider ? mainDataList.c837ClaimProvider : {};
    const billingProviderInfo = claimProviderList && claimProviderList.billingProvider ? claimProviderList.billingProvider : {};

    // Secondary ID
    const billinProviderSecIDs = props.data && props.data.claimProviderID ? props.data.claimProviderID : [];
    const billingProviderST = [];
    const ReferingProviderST = [];
    const RenderingProviderST = [];
    const secondaryTableBI = billinProviderSecIDs.filter((e)=> e.providerRoleCode === 'BI' && e.lineNumber == 0).map(e => billingProviderST.push({'providerIDType': e.providerIDType,'providerID': e.providerID}));
    const secondaryTableRF = billinProviderSecIDs.filter((e)=> e.providerRoleCode === 'RF' && e.lineNumber == 0).map(e => ReferingProviderST.push({'providerIDType': e.providerIDType,'providerID': e.providerID}));
    const secondaryTableRN = billinProviderSecIDs.filter((e)=> e.providerRoleCode === 'RN' && e.lineNumber == 0).map(e => RenderingProviderST.push({'providerIDType': e.providerIDType,'providerID': e.providerID}));
    // console.log('Main Table:',billinProviderSecIDs);
    // console.log('Billing Table:',billingProviderST);
    // console.log('Refering Table:',ReferingProviderST);
    // console.log('Rendering Table:',RenderingProviderST);

    const providerInfo = billingProviderInfo && billingProviderInfo.providerName ? billingProviderInfo.providerName : {};
    const contactInformation = mainDataList && mainDataList.billingProviderContactInfo ? mainDataList.billingProviderContactInfo : {};    
    const contactInformationList = [];
    //console.log('Contact Table:',contactInformation);
    const contactInfoA = {contactName:contactInformation.contactName1, phoneNumber: contactInformation.communicationNumber1A, faxNumber: contactInformation.communicationNumber1C, emailID: contactInformation.communicationNumber1B};
    const contactInfoB = {contactName:contactInformation.contactName2, phoneNumber: contactInformation.communicationNumber2A, faxNumber: contactInformation.communicationNumber2C, emailID: contactInformation.communicationNumber2B};
    
    const contactName1 = contactInformation.contactName1; 
    const phoneNumber1 = contactInformation.communicationNumber1A;
    const faxNumber1 = contactInformation.communicationNumber1C; 
    const emailID1 = contactInformation.communicationNumber1B;
    const contactName2 = contactInformation.contactName2; 
    const phoneNumber2 = contactInformation.communicationNumber2A;
    const faxNumber2 = contactInformation.communicationNumber2C; 
    const emailID2 = contactInformation.communicationNumber2B;
    if(contactInformation != null){
        if(contactName1 != null || phoneNumber1 != null || faxNumber1 != null || emailID1 != null){
            contactInformationList.push(contactInfoA);
        }
        if(contactName2 != null || phoneNumber2 != null || faxNumber2 != null || emailID2 != null){
            contactInformationList.push(contactInfoB);
        }
    }
    //const payToProviderInfo = claimProviderList && claimProviderList.payToProvider ? claimProviderList.payToProvider : {};
    //const payToproviderNameInfo = payToProviderInfo && payToProviderInfo.providerName ? payToProviderInfo.providerName : {};

    const renderingProvider = claimProviderList && claimProviderList.renderingProvider ? claimProviderList.renderingProvider: {};
    const renderingProviderInfo = renderingProvider && renderingProvider.providerName ? renderingProvider.providerName: {};

    const referringProvider = claimProviderList && claimProviderList.referringProvider1 ? claimProviderList.referringProvider1 : {};
    const referringProviderInfo = referringProvider && referringProvider.providerName ? referringProvider.providerName: {};

    const memberInfo = mainDataList && mainDataList.c837Payer ?  mainDataList.c837Payer: {};
    const payerSubscriber = memberInfo && memberInfo.subscriber ? memberInfo.subscriber : {};
    const propertyCasualtyInformation = memberInfo && memberInfo.subscriber && memberInfo.subscriber.propertyCasualityContact ? memberInfo.subscriber.propertyCasualityContact : {};
    
    const payerIDType = payerSubscriber && payerSubscriber.additionalQualifierCode1!== null ? payerSubscriber.additionalQualifierCode1 : '';
    const payerIDNumber = payerSubscriber && payerSubscriber.additionalID1!== null ? payerSubscriber.additionalID1 : '';
    const payerSubscriberTable = payerIDType!== '' || payerIDNumber!== '' ? {payerIDType, payerIDNumber} : '';
    const subscriberSecIDs = []; 
    
    payerSubscriberTable!== '' ? subscriberSecIDs.push(payerSubscriberTable): subscriberSecIDs;  
    
    const memberInformation = memberInfo && memberInfo.payer ? memberInfo.payer : {};
    //const entityInfo = memberInformation && memberInformation.patient ? memberInformation.patient : {}
    const entityInfo = memberInfo && memberInfo.patient ? memberInfo.patient : {}
    const accidentInfo = mainDataList && mainDataList.c837Claim ? mainDataList.c837Claim : {};
    const claimData = mainDataList && mainDataList.c837DentalClaims ? mainDataList.c837DentalClaims[0] : [];
    // const basicLineItemInfoList = claimData && claimData.c837DentalLineItems ? claimData.c837DentalLineItems : [];
    //const notesInfo = mainDataList && mainDataList.c837ServiceLineItems ? mainDataList.c837ServiceLineItems[0] : {};
    const notesInformation = mainDataList && mainDataList.c837DentalClaims ? mainDataList.c837DentalClaims[0] : [];
    const notesInfo = notesInformation && notesInformation.notesInfo ? notesInformation.notesInfo : '';

    const epsdtInfo = mainDataList && mainDataList.c837SpecializedService ? mainDataList.c837SpecializedService : {}
    const basicLineItem = mainDataList && mainDataList.c837SpecializedService ? mainDataList.c837SpecializedService : {};
    const basicLineItemInfoList = basicLineItem && basicLineItem.c837ProfessionalLineItems ? basicLineItem.c837ProfessionalLineItems[0] : [];
    const basicLineItemTable = [];
   // console.log('BasicList',basicLineItemInfoList);
    const basicLineNumber = basicLineItemInfoList ? basicLineItemInfoList.lineNumber : "";
    const basicCoPayStatusCode = basicLineItemInfoList ? basicLineItemInfoList.coPayStatusCode : "";
    const basicSubmittedUnitsCode = basicLineItemInfoList ? basicLineItemInfoList.submittedUnitsCode : "";
    const basicReferralID2 = basicLineItemInfoList && basicLineItemInfoList.priorAuthReferral ? basicLineItemInfoList.priorAuthReferral.referralID2 : "";
    //console.log('Referral: ',basicReferralID2);
    basicLineItemTable.push({"lineNumber":basicLineNumber,"referralID2":basicReferralID2,"coPayStatusCode":basicCoPayStatusCode,"submittedUnitsCode":basicSubmittedUnitsCode});
    //console.log('Basic Table:', basicLineItemTable);
    const basicLineItemsheadCells = [
        { id: "lineNumber", numeric: false, disablePadding: true, label: 'Line #', enableHyperLink: false, fontSize: 12 },
        { id: "referralID2", numeric: false, disablePadding: true, label: 'Referal #', enableHyperLink: false, fontSize: 12, width: '130px' },
        { id: "coPayStatusCode", numeric: false, disablePadding: true, label: "Co-pay Status", enableHyperLink: false, fontSize: 12, width: '110px' },
        { id: "submittedUnitsCode", numeric: false, disablePadding: true, label: "Unit Code", enableHyperLink: false, fontSize: 12, width: '110px' },
    ]
    
    const characterRemaining = notesInfo ? notesInfo.noteText1 : 80;

    return (
        <div className="pos-relative">
            <div className="tabs-container">
                <div className="tab-holder">


                    <div className="tabs-container">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left">
                                Submitter Information </h2>
                        </div>
                        <div className="tab-body-bordered mt-0">
                            <div className="form-wrapper">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="submitter_id"
                                        label="Submitter ID"
                                        value={submitter ? submitter.submitterID : null}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        data-test='prof-basicInfo-stdDesc'
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className='tab-holder CustomExpansion-panel my-3' id="Provider Information Div Id">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header">
                                <Typography > Provider Information </Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form" data-test='prof-basicInfo-billProvider'>
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panelp1a-content11"
                                        id="panelp1a-header11">
                                        <Typography>Billing Provider</Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>


                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="entity_qualifier_billing_prov"
                                                    label="Entity qualifier"
                                                    value={billingProviderInfo.entityTypeCode} 
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-entityQual'

                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="curr_code_billing_prov"
                                                    label="Currency Code"
                                                    value={mainDataList.currencyCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-currCode'

                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="lname_billing_prov"
                                                    label="Org / Last Name"
                                                    value={providerInfo.lastName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-lastName'

                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="fname_billing_prov"
                                                    label="First Name"
                                                    value={providerInfo.firstName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-firstName'

                                                />
                                                
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="mi_billing_prov"
                                                    label="MI"
                                                    value={providerInfo.middleName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-mi'

                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="suffix_billing_prov"
                                                    label="Suffix"
                                                    value={providerInfo.suffixName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-suffix'

                                                />
                                            </div>
                                            <div className="mui-custom-form input-md input-md-1-col">
                                                <TextField
                                                    disabled
                                                    id="address1_billing_prov"
                                                    label="Address 1"
                                                    value={billingProviderInfo.addressLine1}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-address1'

                                                />
                                            </div>
                                            <div className="mui-custom-form input-md input-md-1-col">
                                                <TextField
                                                    disabled
                                                    id="address2_billing_prov"
                                                    label="Address 2"
                                                    value={billingProviderInfo.addressLine2}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-address2'

                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="city_billing_prov"
                                                    label="City"
                                                    value={billingProviderInfo.cityName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-city'

                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="state_billing_prov"
                                                    label="State"
                                                    value={billingProviderInfo.stateCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-state'

                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <div className="cndt-row">

                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            disabled
                                                            id="zip_billing_prov"
                                                            label="Zip & Extension"
                                                            placeholder=""
                                                            value={billingProviderInfo.zipCode ? billingProviderInfo.zipCode.toString().substring(0,5) : ''}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            data-test='prof-basicInfo-billProvider-zip'

                                                        />
                                                    </div>

                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            disabled
                                                            id="ext_billing_prov"
                                                            placeholder=""
                                                            value={billingProviderInfo.zipCode ? billingProviderInfo.zipCode.toString().substring(5) : ''}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            data-test='prof-basicInfo-billProvider-extension'

                                                        />
                                                    </div>

                                                </div>

                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="country_billing_prov"
                                                    label="Country"
                                                    value={billingProviderInfo.countryCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-country'

                                                />
                                            </div>


                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="subdiv_billing_prov"
                                                    label="Subdivision Code"
                                                    value={billingProviderInfo.countrySubDivisionCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-billProvider-subDivCode'

                                                />
                                            </div>

                                        </div>

                                        <Divider className="mt-4" />
                                        <div className="tabs-container mt-2" data-test='prof-basicInfo-billProvider-secIdtable'>
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                            </div>
                                            <TableComponent headCells={billingProviderheadCells} tableData={billingProviderST} onTableRowClick={editRow} defaultSortColumn="id" />
                                        </div>
                                        <div className="tabs-container mt-2" data-test='prof-basicInfo-billProvider-contactInfoTable'>
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Contact Information </h2>
                                            </div>
                                            <TableComponent headCells={billingProviderContactheadCells} tableData={contactInformationList} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />
                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>
                                {/* <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panelp1a-content11"
                                        id="panelp1a-header11">
                                        <Typography>Pay-To Provider</Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>


                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="entity_qualifier_payTo"
                                                    label="Entity qualifier"
                                                    value={payToProviderInfo.entityTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="lname_payTo"
                                                    label="Org / Last Name"
                                                    value={payToproviderNameInfo.lastName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="fname_payTo"
                                                    label="First Name"
                                                    value={payToproviderNameInfo.firstName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="mi_payTo"
                                                    label="MI"
                                                    value={payToproviderNameInfo.middleName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="suffix_payTo"
                                                    label="Suffix"
                                                    value={payToproviderNameInfo.suffixName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md input-md-1-col">
                                                <TextField
                                                    disabled
                                                    id="address1_payTo"
                                                    label="Address 1"
                                                    value={payToProviderInfo.addressLine1}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md input-md-1-col">
                                                <TextField
                                                    disabled
                                                    id="address2_payTo"
                                                    label="Address 2"
                                                    value={payToProviderInfo.addressLine2}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="city_payTo"
                                                    label="City"
                                                    value={payToProviderInfo.cityName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="state_payTo"
                                                    label="State"
                                                    value={payToProviderInfo.stateCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <div className="cndt-row">

                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            disabled
                                                            id="zip_payTo"
                                                            label="Zip & Extension"
                                                            placeholder=""
                                                            value={payToProviderInfo.zipCode ? payToProviderInfo.zipCode.toString().substring(0,5) : ''}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>

                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            disabled
                                                            id="ext_payTo"
                                                            placeholder=""
                                                            value={payToProviderInfo.zipCode ? payToProviderInfo.zipCode.toString().substring(5) : ''}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>

                                                </div>

                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="country_payTo"
                                                    label="Country"
                                                    value={payToProviderInfo.countryCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>


                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="subdiv_payTo"
                                                    label="Subdivision Code"
                                                    value={payToProviderInfo.countrySubDivisionCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                        </div>

                                        <Divider className="mt-4" />
                                        <div className="tabs-container mt-2">
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                            </div>
                                            <TableComponent headCells={billingProviderheadCells} tableData={billinProviderSecIDs} onTableRowClick={editRow} defaultSortColumn="id" />
                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel> */}


                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                    >
                                        <Typography > Rendering (Performing) Provider </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block">

                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="entity_qualifier_render_perform_prov"
                                                    label="Entity Qualifier"
                                                    value={renderingProvider.entityTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-renderingProvider'
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="org_lname_render_perform_prov"
                                                    label="Org / Last Name"
                                                    value={renderingProviderInfo.lastName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-renderingProvider-lastName'
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="fname_render_perform_prov"
                                                    label="First Name"
                                                    value={renderingProviderInfo.firstName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-renderingProvider-firstName'
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="mi_render_perform_prov"
                                                    label="MI"
                                                    value={renderingProviderInfo.middleName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-renderingProvider-mi'
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="suffix_render_perform_prov"
                                                    label="Suffix"
                                                    value={renderingProviderInfo.suffixName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-renderingProvider-suffix'
                                                />
                                            </div>
                                        </div>

                                        <Divider className="mt-4" />
                                        <div className="tabs-container mt-2" data-test='prof-basicInfo-renderingProvider-secIdtable'>
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                            </div>
                                            {/* <TableComponent headCells={billingProviderheadCells1} tableData={[]} onTableRowClick={editRow} defaultSortColumn="id" /> */}
                                            <TableComponent headCells={billingProviderheadCells} tableData={RenderingProviderST} onTableRowClick={editRow} defaultSortColumn="id" />
                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header">
                                        <Typography >Referring Provider </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block">
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="entity_qualifier_render_prov"
                                                    label="Entity Qualifier"
                                                    value={referringProvider.entityTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-referingProvider'
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="org_lname_render_prov"
                                                    label="Org / Last Name"
                                                    value={referringProviderInfo.lastName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-referingProvider-lastName'
                                                    />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="fname_render_prov"
                                                    label="First Name"
                                                    value={referringProviderInfo.firstName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test='prof-basicInfo-referingProvider-firstName'
                                                    />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="mi_render_prov"
                                                    label="MI"
                                                    value={referringProviderInfo.middleName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }} 
                                                    data-test='prof-basicInfo-referingProvider-mi'
                                                    />

                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="suffix_render_prov"
                                                    label="Suffix"
                                                    value={referringProviderInfo.suffixName}
                                                    placeholder=""
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }} 
                                                    data-test='prof-basicInfo-referingProvider-suffix'
                                                    />

                                            </div>
                                        </div>


                                        <Divider className="mt-4" />
                                        <div className="tabs-container mt-2" data-test='prof-basicInfo-referingProvider-secIdtable'>
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                            </div>
                                            {/* <TableComponent headCells={billingProviderheadCells1} tableData={[]} onTableRowClick={editRow} defaultSortColumn="id" /> */}
                                            <TableComponent headCells={billingProviderheadCells} tableData={ReferingProviderST} onTableRowClick={editRow} defaultSortColumn="id" />
                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>






                    <div className='tab-holder CustomExpansion-panel my-3' id="Member Information Div Id">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography > Member Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="tab-body-bordered py-2">
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="prop_casuality_num_mem_info"
                                                label="Property Casualty Number"
                                                value={payerSubscriber.propertyClaimNumber}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="ssn_mem_info"
                                                label="SSN"
                                                value={payerSubscriber.additionalID1}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entity_qualifier_mem_info"
                                                label="Entity Qualifier"
                                                value={entityInfo.memberQualifierCode}
                                                placeholder=""
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md input-md-1-col">
                                            <TextField
                                                disabled
                                                id="address1_mem_info"
                                                label="Address 1"
                                                value={entityInfo.addressLine1}
                                                placeholder=""
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md input-md-1-col">
                                            <TextField
                                                disabled
                                                id="address2_mem_info"
                                                label="Address 2"
                                                value={entityInfo.addressLine2}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="city_mem_info"
                                                label="City"
                                                value={entityInfo.cityName}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="state_mem_info"
                                                label="State"
                                                value={payerSubscriber.stateCode}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                        <div className="mui-custom-form input-md">
                                            <div className="cndt-row">

                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="zip_mem_info"
                                                        label="Zip & Extension"
                                                        placeholder=""
                                                        value={entityInfo.zipCode ? entityInfo.zipCode.toString().substring(0,5) : ''}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>

                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="ext_mem_info"
                                                        placeholder=""
                                                        value={entityInfo.zipCode ? entityInfo.zipCode.toString().substring(5) : ''}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>

                                            </div>

                                        </div>

                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="country_mem_info"
                                                label="Country"
                                                value={entityInfo.countryCode}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="subdiv_mem_info"
                                                label="Subdivision Code"
                                                value={payerSubscriber.countrySubDivisionCode}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Weight"
                                                label="Weight"
                                                value={entityInfo.patientWeight}
                                                placeholder=""
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        id="repricer_recieved_date_claim_data"
                                                        label="Date of Death"
                                                        format="MM/dd/yyyy"
                                                        helperText= ''
                                                        error=''
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        disabled
                                                        placeholder="mm/dd/yyyy"
                                                        value={entityInfo.patientDateOfDeath}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>
                                            <div className="mui-custom-form input-md wdth17">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Is the patient pregnant?</label>
                                                </div>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        row
                                                        aria-label="Is the patient pregnant?"
                                                        name="Is the patient pregnant?"
                                                        value={entityInfo.pregnancyIndicator}
                                                    >
                                                        <FormControlLabel
                                                            value={true}
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value={false}
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        id="repricer_recieved_date_claim_data"
                                                        label="Last Menstrual Period"
                                                        format="MM/dd/yyyy"
                                                        helperText= ''
                                                        error=''
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        disabled
                                                        placeholder="mm/dd/yyyy"
                                                        value={accidentInfo.lastMenstrualDate}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>
                                    </div>
                                    <Divider className="mt-4 ml-3 mr-3" />
                                    <div className="tabs-container p-2 ml-2 mr-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                        </div>
                                        {/* <TableComponent headCells={billingProviderheadCells1} tableData={[]} onTableRowClick={editRow} defaultSortColumn="id" /> */}
                                        <TableComponent headCells={billingProviderheadCells1} tableData={subscriberSecIDs} onTableRowClick={editRow} defaultSortColumn="id" />
                                    </div>
                                </div>
                                <div class="tabs-container mt-3">

                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left">
                                            Subscriber Information </h2>
                                    </div>
                                    <div className="tab-body-bordered py-2">
                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="seq_code_subscribe_info"
                                                    label="Responsibility Sequence Code"
                                                    value={payerSubscriber.responsibilitySequenceCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="policy_group_num_subscribe_info"
                                                    label="Policy or Group Number"
                                                    value={payerSubscriber.policyNumber}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="insurance_type_code_subscribe_info"
                                                    label="Insurance Type Code"
                                                    value={payerSubscriber.insuranceTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="plan_name_subscribe_info"
                                                    label="Plan Name"
                                                    value={payerSubscriber.planName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="claim_filing_code_subscribe_info"
                                                    label="Claim Filing Code                                     "
                                                    value={payerSubscriber.claimFilingCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <div class="tabs-container mt-3">

                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left">
                                            Property Casualty Information </h2>
                                    </div>
                                    <div className="tab-body-bordered py-2">
                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="seq_code_subscribe_info"
                                                    label="Contact Name"
                                                    value={propertyCasualtyInformation.contactName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="policy_group_num_subscribe_info"
                                                    label="Phone"
                                                    value={propertyCasualtyInformation.communicationANumber}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="insurance_type_code_subscribe_info"
                                                    label="Extension"
                                                    value={propertyCasualtyInformation.communicationBNumber}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        
                                    </div>
                                </div>


                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>

                    {/* <p> Claim Information </p>   */}

                    <div className='tab-holder CustomExpansion-panel my-3' id="Claim Information Div Id">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header">
                                <Typography >Claim Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panelp1a-content22"
                                        id="panelp1a-header22">
                                        <Typography> Accident Related Information </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>

                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="auto_accident_country_claim_info"
                                                    label="Auto Accident Country"
                                                    value={accidentInfo.countryCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="accident_time_claim_info"
                                                    label="Accident Time"
                                                    value={claimHdr.accidentDateTime ? claimHdr.accidentDateTime : ''}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header">
                                        <Typography >Claim Notes</Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="delay_reason_code_claim_data"
                                                    //value={accidentInfo.delayReasonCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        
                                            <div className="mui-custom-form input-md field-xl">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="dddwdsghsgtertrSD"
                                                    id="dddwdsghsgtertrSD-label">Note</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                     className={classes.txtfullwidth}
                                                    aria-label="minimum-height"
                                                    id="claim_notes"
                                                    placeholder=""
                                                    value={notesInfo && notesInfo.noteText1 ? notesInfo.noteText1 : ""}
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                                </div>
                                                <div className="mt-1"><Chip avatar={<Avatar>{characterRemaining&&characterRemaining.length ? 80-characterRemaining.length : 80}</Avatar>} label="Characters remaining" /></div>
                                            </div>
                                        </div>
                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                <ExpansionPanel className="collapsable-panel mt-1 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header">
                                        <Typography >EPSDT / Family Planning </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block">

                                        <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md wdth17">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Certification Condition Indicaator</label>
                                                </div>
                                                <div className="sub-radio">
                                                    <RadioGroup
                                                        row
                                                        aria-label="Certification Condition Indicaator"
                                                        name="Certification Condition Indicaator"
                                                        value={epsdtInfo.epsdtIndicator}
                                                    >
                                                        <FormControlLabel
                                                            value={true}
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value={false}
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                            
                                        </div>
                                        
                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="relaease_of_info_code_claim_data"
                                                    label="Condition 1"
                                                    value={epsdtInfo.espdtConditionCode1}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="service_auth_exception_code_claim_data"
                                                    label="Condition 2"
                                                    value={epsdtInfo.espdtConditionCode2}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="service_auth_exception_code_claim_data"
                                                    label="Condition 3"
                                                    value={epsdtInfo.espdtConditionCode3}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        
                                    </ExpansionPanelDetails>
                                </ExpansionPanel>
                        
                                <ExpansionPanel className="collapsable-panel mt-1 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header">
                                        <Typography >Claim Data </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block">

                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="delay_reason_code_claim_data"
                                                    label="Delay Reason Code"
                                                    value={accidentInfo.delayReasonCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="spec_prog_type_code_claim_data"
                                                    label="Special Program Type Code"
                                                    value={accidentInfo.specialProgramCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="medicare_assignment_code_claim_data"
                                                    label="Medicare Assignment Code"
                                                    value={accidentInfo.medicareAssignmentCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        
                                        <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md wdth17">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Benefits Assignment Certification:</label>
                                                </div>
                                                <div className="sub-radio">
                                                    <RadioGroup
                                                        row
                                                        aria-label="Benefits Assignment Certification"
                                                        name="Benefits Assignment Certification"
                                                        value={accidentInfo.benefitCertificationCode}
                                                    >
                                                        <FormControlLabel
                                                            value={true}
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value={false}
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="relaease_of_info_code_claim_data"
                                                    label="Release of Information Code"
                                                    value={accidentInfo.releaseOfInformationCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="service_auth_exception_code_claim_data"
                                                    label="Patient Signature Source Code"
                                                    value={accidentInfo.patientSignatureIndicator}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        
                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>

                    <div className='tab-holder CustomExpansion-panel my-3' id="Basic Line Item Information Div Id">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography > Basic Line Item Information </Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                            <div className="tabs-container pb-2 mt-3 wrap-th-header">
                            <TableComponent headCells={basicLineItemsheadCells} tableData={basicLineItemTable} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />
                            {/* <TableComponent headCells={basicLineItemsheadCells} tableData={basicLineItemInfoList} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" /> */}
                            </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default BasicClaimInfo;