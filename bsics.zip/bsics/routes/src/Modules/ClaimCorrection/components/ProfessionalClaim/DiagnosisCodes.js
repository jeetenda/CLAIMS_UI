import React, { useState, useEffect, useRef } from "react";
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import TableComponent from '../../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import * as Dropdowns from '../../../../SharedModules/Dropdowns/dropdowns';
import { GET_SYSTEMLIST_DROPDOWN } from '../../../../SharedModules/Dropdowns/actions';
import * as ErrorConst from '../../../../SharedModules/Messages/ErrorMsgConstants';

function DiagnosisCodes(props) {
    const dispatch = useDispatch();
    const data = props.data;
    const [showForm, setShowForm] = useState(false);
    const [showForm1, setShowForm1] = useState(false);
    const [success, setSuccess] = useState(false);
    const [mSuccess, setMSuccess] = useState([]);
    const [selectDeleteArray, setSelectDeleteArray] = useState([]);
    const [selectDeleteArray1, setSelectDeleteArray1] = useState([]);
    const tableCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: '#', enableHyperLink: true, width: "20%", fontSize: 12
        },
        {
            id: 'diagnosisDescription', numeric: false, disablePadding: false, label: 'Type', enableHyperLink: false, width: "40%", fontSize: 12
        },
        {
            id: 'diagnosisCode', numeric: false, disablePadding: false, label: 'Code', enableHyperLink: false, width: "40%", fontSize: 12
        }
    ];
    const tableCells1 = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: '#', enableHyperLink: true, width: "20%", fontSize: 12
        },
        {
            id: 'conditionCode', numeric: false, disablePadding: false, label: 'Code', enableHyperLink: false, width: "80%", fontSize: 12
        }
    ];
    const [values, setValues] = useState({});
    const [values1, setValues1] = useState({});
    const [tableData, setTableData] = useState([]);
    const [tableData1, setTableData1] = useState([]);
    const editRow = row => (event) => {
        scroltoaddEditDiagnosis();
        setValues(row);
        setShowForm(true);
        setSuccess(false);
    };
    const editRow1 = row => (event) => {
        scroltoaddEditCondition();
        setValues1(row);
        setShowForm1(true);
        setSuccess(false);
    };
    const onDropdowns = (val) => dispatch(GET_SYSTEMLIST_DROPDOWN(val));
    const addDropdowns = useSelector(state => state.appDropDowns.sysdropdowns);
    const [{ dErr, qErr, dQErr }, setErrors] = useState({});
    const [localDiagnosis, setLocalDiagnosis] = useState([{
        "auditUserID": "test",
        "auditTimeStamp": null,
        "addedAuditUserID": "test",
        "addedAuditTimeStamp": null,
        "versionNo": 0,
        "diagnosisCode": "",
    },
    {
        "auditUserID": "test",
        "auditTimeStamp": null,
        "addedAuditUserID": "test",
        "addedAuditTimeStamp": null,
        "versionNo": 0,
        "diagnosisCode": "",
    },
    {
        "auditUserID": "test",
        "auditTimeStamp": null,
        "addedAuditUserID": "test",
        "addedAuditTimeStamp": null,
        "versionNo": 0,
        "diagnosisCode": "",
    },
    {
        "auditUserID": "test",
        "auditTimeStamp": null,
        "addedAuditUserID": "test",
        "addedAuditTimeStamp": null,
        "versionNo": 0,
        "diagnosisCode": "",
    }]);
    const [icdVersion, setIcdVersion] = useState("");
    const [number, setNumber] = useState(1);
    const addEditDiagnosis = useRef(null);
    const addEditCondition = useRef(null);
    const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
    const scroltoaddEditDiagnosis = () => {
        setTimeout(function () {
            scrollToRef(addEditDiagnosis);
        }.bind(this), 1000);
    };
    const scroltoaddEditCondition = () => {
        setTimeout(function () {
            scrollToRef(addEditCondition);
        }.bind(this), 1000);
    };
    
    const handelChangeFunc = (index, value) => {
        let data = localDiagnosis;
        let mainData = props.diagnosis;
        if (data[index].sequenceNumber) {
            let data = localDiagnosis;
            let mainData = props.diagnosis;
            data[index].diagnosisCode = value;
            setLocalDiagnosis([...data]);
            let mainIndex = mainData.findIndex(e => e.sequenceNumber == data[index].sequenceNumber);
            mainData[mainIndex].diagnosisCode = value;
            props.setDiagnosis(mainData);
        } else {
            data[index].diagnosisCode = value;
            data[index].sequenceNumber = number;
            if (icdVersion == "09") {
                if (index == '0') {
                    data[index].diagnosisType = 'BK';
                } else {
                    data[index].diagnosisType = 'BF'
                }
            } else {
                if (index == '0') {
                    data[index].diagnosisType = 'ABK';
                } else {
                    data[index].diagnosisType = 'ABF';
                }
            }
            mainData.push(data[index]);
            setLocalDiagnosis(data);
            props.setDiagnosis(mainData);
            setNumber(number + 1);
        }
    }
    useEffect(() => {
        onDropdowns({ "inputList": [Dropdowns.PROF_DIAG_QLFY_TYPE] });        
        if (props.data.diagnosis && props.data.diagnosis.length > 0) {
            setTableData(props.data.diagnosis);
        }
        if (props.data.icdVersion) {
            setIcdVersion(props.data.icdVersion)
        }
        if (props.data.professionalClaim && props.data.professionalClaim.conditionCode && props.data.professionalClaim.conditionCode.length > 0) {
            setTableData1(props.data.professionalClaim.conditionCode);
        }
    }, []);
    const handelIcdChange = (e) => {
        setIcdVersion(e.target.value);
        props.setClaimEntryData({ ...data, icdVersion: e.target.value });
        let mainData = props.diagnosis;
        mainData.map(e => {
            if (e.target.value == '09') {
                if (e.diagnosisType == 'ABK') {
                    e.diagnosisType = 'BK';
                } else if (e.diagnosisType == 'ABF') {
                    e.diagnosisType = 'BF';
                }
            } else {
                if (e.diagnosisType == 'BK') {
                    e.diagnosisType = 'ABK';
                } else if (e.diagnosisType == 'BF') {
                    e.diagnosisType = 'ABF';
                }
            }
        });
        props.setDiagnosis(mainData);
    };

    useEffect(() => {
        if (props.clearDiagnosis) {
            setLocalDiagnosis([{
                "auditUserID": "test",
                "auditTimeStamp": null,
                "addedAuditUserID": "test",
                "addedAuditTimeStamp": null,
                "versionNo": 0,
                "diagnosisCode": "",
            },
            {
                "auditUserID": "test",
                "auditTimeStamp": null,
                "addedAuditUserID": "test",
                "addedAuditTimeStamp": null,
                "versionNo": 0,
                "diagnosisCode": "",
            },
            {
                "auditUserID": "test",
                "auditTimeStamp": null,
                "addedAuditUserID": "test",
                "addedAuditTimeStamp": null,
                "versionNo": 0,
                "diagnosisCode": "",
            },
            {
                "auditUserID": "test",
                "auditTimeStamp": null,
                "addedAuditUserID": "test",
                "addedAuditTimeStamp": null,
                "versionNo": 0,
                "diagnosisCode": "",
            }]);
            props.setClearDiagnosis(false);
        }
    }, [props.clearDiagnosis]);
    const onRowAdd = () => {
        scroltoaddEditDiagnosis();
        setSuccess(false);
        setMSuccess([]);
        setShowForm(true);
        setValues({
            "sequenceNumber": tableData.length ? tableData.length + 1 : 1,
            "diagnosisType": "-1",
            "diagnosisCode": ""
        });
    };
    const onRowAdd1 = () => {
        scroltoaddEditCondition();
        setSuccess(false);
        setMSuccess([]);
        setShowForm1(true);
        setValues1({
            "sequenceNumber": tableData1.length ? tableData1.length + 1 : 1,            
            "conditionCode": ""
        });
    };
    const onRowCancel = () => {
        setShowForm(false);        
    };
    const onRowCancel1 = () => {
        setShowForm1(false);        
    };
    const handelSave = () => {
        setErrors({});
        props.seterrorMessages([]);
        if((!values.diagnosisType || values.diagnosisType == "-1") && (!values.diagnosisCode.trim())){
            setErrors({dQErr:true});
            props.seterrorMessages([ErrorConst.D_And_Q_Code_Req_Error]);
            return false;
        }
        if(!values.diagnosisType || values.diagnosisType == "-1"){
            setErrors({qErr:true});
            props.seterrorMessages([ErrorConst.Q_Req_When_D_Enter_Error]);
            return false;
        }
        if(!values.diagnosisCode.trim()){
            setErrors({dErr:true});
            props.seterrorMessages([ErrorConst.D_Req_When_Q_Enter_Error]);
            return false;
        }
        if (values.index>-1) {
            const { index, ...vals } = values;
            tableData[index] = vals;
            setTableData([...tableData]);
        } else {
            tableData.push(values);
            setTableData([...tableData]);
        }
        setShowForm(false);
        props.setDiagnosis(tableData);         
    };
    const handelSave1 = () => {
        if (values1.index>-1) {
            const { index, ...vals } = values1;
            tableData1[index] = vals;
            setTableData1([...tableData1]);
        } else {
            tableData1.push(values1);
            setTableData1([...tableData1]);
        }
        setShowForm1(false);
        props.setConditionCodes(tableData1);        
    };

    const getTableData = (dt) => {
        if (dt && dt.length) {
            let tData = JSON.stringify(dt);
            tData = JSON.parse(tData);
            tData.map((each, index) => {          
                each.index = index;
            });
            return tData;
        } else {
            return [];
        }
    };
    return (
        <>
            <div className="tabs-container tabs-container-inner">
                <div className="tab-body-bordered mb-2">
                    <div className="tab-header px-3 mt-2">
                        <h3 className="tab-heading pb-0 float-left">
                            Diagnosis
                    </h3>
                        <div className="float-right th-btnGroup">
                            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => { handleMultiDelete(); }}>
                                <i className="fa fa-trash" />
                            </Button>
                            <Button
                                title="Add Diagnosis"
                                variant="outlined"
                                color="primary"
                                className="btn btn-secondary btn-icon-only"
                                onClick={onRowAdd}
                            >
                                <i className="fa fa-plus" />
                            </Button>
                        </div>
                    </div>
                    <div className="form-wrapper form-3-column">
                        <div className="mui-custom-form input-md">
                            <TextField
                                id="icd_ver_diag_code"
                                label="ICD Version"
                                placeholder=""
                                value={icdVersion}
                                onChange={event => handelIcdChange(event)}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                    </div>
                    <div className="tab-body px-3 pb-3">
                        <TableComponent multiDelete selected={selectDeleteArray} setSelected={setSelectDeleteArray} print={print} headCells={tableCells} tableData={getTableData(tableData)} onTableRowClick={editRow} defaultSortColumn="procedureCode" />
                    </div>
                    {showForm ? (
                        <div className="tabs-container tabs-container-inner" ref={addEditDiagnosis}>
                            <div className="tab-header">
                                <h2 className="tab-heading float-left">
                                    {values.index > -1 ? "Edit" : "Add"} Diagnosis
                                </h2>
                                
                                <div className="float-right th-btnGroup">
                                    <Button title={values.index > -1 ? 'Update' : 'Add'} variant="outlined" color="primary" className='btn btn-ic-only btn-icon-only-save' onClick={handelSave}>
                                    </Button>
                                    <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-reset" onClick={() => { setValues({}); setErrors({}); }}>
                                    </Button>
                                    <Button title="Cancel" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-cancel" onClick={onRowCancel}>
                                    </Button>
                                </div>
                            </div>
                            <form autoComplete="off">
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="visit_diagnosis_sequenceNumber"
                                            name="sequenceNumber"
                                            value={values.sequenceNumber ? values.sequenceNumber : ""}
                                            label="#"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            select
                                            id="visit_diagnosis_diagnosisType"
                                            name="diagnosisType"
                                            label="Type"
                                            placeholder=""
                                            value={values.diagnosisType ? values.diagnosisType : "-1"}
                                            onChange={event => { setValues({ ...values, [event.target.name]: event.target.value, "diagnosisDescription": event.nativeEvent.target.innerText }); }}
                                            inputProps={{ maxLength: 1 }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            helperText={dQErr ? ErrorConst.D_And_Q_Code_Req_Error : qErr ? ErrorConst.Q_Req_When_D_Enter_Error : null}
                                            error={qErr || dQErr}
                                        >
                                            <MenuItem selected key="Please Select One" value="-1">
                                                Please Select One
                                        </MenuItem>
                                            {addDropdowns && Object.keys(addDropdowns).length > 0 && addDropdowns['Claims#1168'] && addDropdowns['Claims#1168'].map(each => (
                                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                                            ))}
                                        </TextField>
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="visit_diagnosis_diagnosisCode"
                                            name="diagnosisCode"
                                            value={values.diagnosisCode ? values.diagnosisCode : ""}
                                            onChange={event => { setValues({ ...values, [event.target.name]: event.target.value }); }}
                                            label="Code"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 4 }}
                                            helperText={dErr ? ErrorConst.D_Req_When_Q_Enter_Error : null}
                                            error={dErr}
                                        />
                                    </div>

                                </div>
                            </form>
                        </div>
                    ) : null}
                </div>
            </div>
            <div className="tabs-container tabs-container-inner mt-4">
                <div className="tab-body-bordered mb-2">
                    <div className="tab-header px-3 mt-2">
                        <h3 className="tab-heading pb-0 float-left">
                            Condition Codes
                        </h3>
                        <div className="float-right th-btnGroup">
                            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray.length == 0} onClick={() => { handleMultiDelete(); }}>
                                <i className="fa fa-trash" />
                            </Button>
                            <Button
                                title="Add Diagnosis"
                                variant="outlined"
                                color="primary"
                                className="btn btn-secondary btn-icon-only"
                                onClick={onRowAdd1}
                            >
                                <i className="fa fa-plus" />
                            </Button>
                        </div>
                    </div>
                    <div className="tab-body px-3 pb-3">
                        <TableComponent multiDelete selected={selectDeleteArray1} setSelected={setSelectDeleteArray1} print={print} headCells={tableCells1} tableData={getTableData(tableData1)} onTableRowClick={editRow1} defaultSortColumn="procedureCode" />
                    </div>
                    {showForm1 ? (
                        <div className="tabs-container tabs-container-inner" ref={addEditCondition}>
                            <div className="tab-header">
                                <h2 className="tab-heading float-left">
                                    {values.index > -1 ? "Edit" : "Add"} Condition Code
                                </h2>
                                <div className="float-right th-btnGroup">
                                    <Button title={values.index > -1 ? 'Update' : 'Add'} variant="outlined" color="primary" className='btn btn-ic-only btn-icon-only-save' onClick={() => handelSave1()}>
                                    </Button>
                                    <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-reset" onClick={() => { setValues1({}); }}>
                                    </Button>
                                    <Button title="Cancel" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-cancel" onClick={onRowCancel1}>
                                    </Button>
                                </div>
                            </div>
                            
                            <form autoComplete="off">
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="visit_condition_code_sequenceNumber"
                                            name="sequenceNumber"
                                            value={values1.sequenceNumber ? values1.sequenceNumber : ""}                                            
                                            label="#"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}                                            
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="visit_condition_code_conditionCode"
                                            name="conditionCode"
                                            value={values1.conditionCode ? values1.conditionCode : ""}
                                            onChange={event => { setValues1({ ...values1, [event.target.name]: event.target.value }); }}
                                            label="Code"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                            helperText={null}
                                            error={null}
                                        />
                                    </div>

                                </div>
                            </form>
                        </div>
                    ) : null}
                </div>
            </div>
        </>
    )
}

export default DiagnosisCodes;