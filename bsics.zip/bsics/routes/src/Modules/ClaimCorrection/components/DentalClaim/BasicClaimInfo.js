import React, { Fragment } from "react";
import { ExpansionPanel, ExpansionPanelSummary, Typography, ExpansionPanelDetails, TextField } from "@material-ui/core";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../../SharedModules/Table/Table';
import { RadioGroup } from '@material-ui/core';
import { FormControlLabel } from '@material-ui/core';
import { Radio } from '@material-ui/core';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import { Divider } from "@material-ui/core";
import DateFnsUtils from '@date-io/date-fns';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider,
    DatePicker
} from '@material-ui/pickers'
import dateFnsFormat from 'date-fns/format';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import moment from 'moment';

const billingProviderheadCells = [
    { id: "providerIDTypeDesc", numeric: false, disablePadding: true, label: 'ID Type', enableHyperLink: false,width: 300, fontSize: 12 },
    { id: "providerID", numeric: false, disablePadding: true, label: 'ID Number', enableHyperLink: false,width:300, fontSize: 12 }
]
const billingProviderheadCells1 = [
    { id: "payerIDType", numeric: false, disablePadding: true, label: 'ID Type', enableHyperLink: false,width:300, fontSize: 12 },
    { id: "payerIDNumber", numeric: false, disablePadding: true, label: 'ID Number', enableHyperLink: false,width:300, fontSize: 12 }
]

const editRow = row => (event) => {
    getThemeProps.setOpen(true);
};

const billingProviderContactheadCells = [
    { id: "contactName", numeric: false, disablePadding: true, label: 'Name', enableHyperLink: false,fontSize: 12 },
    { id: "phoneNumber", numeric: false, disablePadding: true, label: 'Phone/Ext', enableHyperLink: false,fontSize: 12 },
    { id: "faxNumber", numeric: false, disablePadding: true, label: 'Fax', enableHyperLink: false,fontSize: 12 },
    { id: "emailID", numeric: false, disablePadding: true, label: 'Email', enableHyperLink: false,fontSize: 12}
]

function BasicClaimInfo(props) {
    const claimHdr = props.data && props.data.enterpriseClaimAux ? props.data.enterpriseClaimAux : {};
    const mainDataList = claimHdr && claimHdr.c837ClaimHdr ? claimHdr.c837ClaimHdr : {};
    const submitter = mainDataList && mainDataList.submitterInfo ? mainDataList.submitterInfo : {};
    const claimProviderList = mainDataList && mainDataList.c837ClaimProvider ? mainDataList.c837ClaimProvider : {};
    const billingProviderInfo = claimProviderList && claimProviderList.billingProvider ? claimProviderList.billingProvider : {};
    const billinProviderSecIDs = props.data && props.data.claimProviderID ? props.data.claimProviderID : [];
    const providerInfo = billingProviderInfo && billingProviderInfo.providerName ? billingProviderInfo.providerName : {};
    const contactInformation = mainDataList && mainDataList.billingProviderContactInfo ? mainDataList.billingProviderContactInfo : {};    
    const contactInformationList = [];
    const contactInfoA = {contactName:contactInformation.contactName1, phoneNumber: contactInformation.communicationNumber1A, faxNumber: contactInformation.communicationNumber1C, emailID: contactInformation.communicationNumber1B};
    const contactInfoB = {contactName:contactInformation.contactName2, phoneNumber: contactInformation.communicationNumber2A, faxNumber: contactInformation.communicationNumber2C, emailID: contactInformation.communicationNumber2B};
  
    contactInformationList.push(contactInfoA);
    contactInformationList.push(contactInfoB);
    const renderingProvider = claimProviderList && claimProviderList.renderingProvider ? claimProviderList.renderingProvider: {};
    const renderingProviderInfo = renderingProvider && renderingProvider.providerName ? renderingProvider.providerName: {};
    const referringProvider = claimProviderList && claimProviderList.referringProvider1 ? claimProviderList.referringProvider1 : {};
    const referringProviderInfo = referringProvider && referringProvider.providerName ? referringProvider.providerName: {};
    const memberInfo = mainDataList && mainDataList.c837Payer ?  mainDataList.c837Payer: {};
    const payerSubscriber = memberInfo && memberInfo.subscriber ? memberInfo.subscriber : {};
    
    const payerIDType = payerSubscriber && payerSubscriber.additionalQualifierCode1!== null ? payerSubscriber.additionalQualifierCode1 : '';
    const payerIDNumber = payerSubscriber && payerSubscriber.additionalID1!== null ? payerSubscriber.additionalID1 : '';
    const payerSubscriberTable = payerIDType!== '' || payerIDNumber!== '' ? {payerIDType, payerIDNumber} : '';
    const subscriberSecIDs = []; 
    
    payerSubscriberTable!== '' ? subscriberSecIDs.push(payerSubscriberTable): subscriberSecIDs;  
    
    const memberInformation = memberInfo && memberInfo.payer ? memberInfo.payer : {};
    const entityInfo = memberInformation && memberInformation.patient ? memberInformation.patient : {}
    const accidentInfo = mainDataList && mainDataList.c837Claim ? mainDataList.c837Claim : {};
    const claimData = mainDataList && mainDataList.c837DentalClaims ? mainDataList.c837DentalClaims[0] : [];
    const basicLineItemInfoList = claimData && claimData.c837DentalLineItems ? claimData.c837DentalLineItems : [];
    const notesInfo = mainDataList && mainDataList.c837ServiceLineItems ? mainDataList.c837ServiceLineItems[0] : {};

    const basicLineItemsheadCells = [
        { id: "lineNumber", numeric: false, disablePadding: true, label: 'Line #', enableHyperLink: false, fontSize: 12 },
        { id: "applianceDate", numeric: false, disablePadding: true, label: 'Orthodontic Banding Date', enableHyperLink: false, fontSize: 12, isDate: true, width: '130px' },
        { id: "treatmentStartDate", numeric: false, disablePadding: true, label: "Treatment Start Date", enableHyperLink: false, isDate: true, fontSize: 12, width: '110px' },
        { id: "treatmentEndtDate", numeric: false, disablePadding: true, label: 'Treatment Completion Date', enableHyperLink: false, isDate: true, fontSize: 12, width: '155px' },
        { id: "replacementDate", numeric: false, disablePadding: true, label: 'Replacement Date', enableHyperLink: false, isDate: true, fontSize: 12, width: '130px' },
        { id: "priorPlacementDate", numeric: false, disablePadding: true, label: 'Prior Placement Date', enableHyperLink: false, isDate: true, fontSize: 12, width: '150px' },
        { id: "controlNumber", numeric: false, disablePadding: true, label: 'LI Control #', enableHyperLink: false, fontSize: 12, width: '120px' },
        { id: "placementStatusCode", numeric: false, disablePadding: true, label: 'Prosthesis, Crown or Inlay Code', enableHyperLink: false, fontSize: 12, width: '160px' },
        { id: "approvedAmount", numeric: false, disablePadding: true, label: 'Approved Amount', enableHyperLink: false, fontSize: 12, width: '100px' },
        { id: "taxAmount", numeric: false, disablePadding: true, label: 'Sales Tax Amount', enableHyperLink: false, fontSize: 12, width: '100px' },
        { id: "anestesiaCount1", numeric: false, disablePadding: true, label: 'Anesthesia Unit Count', enableHyperLink: false, fontSize: 12, width: '100px' },

    ]
    
    const characterRemaining = notesInfo ? notesInfo.noteText : 80;

    return (
        <div className="pos-relative">
            <div className="tabs-container">
                <div className="tab-holder">


                    <div className="tabs-container">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left">
                                Submitter Information </h2>
                        </div>
                        <div className="tab-body-bordered mt-0">
                            <div className="form-wrapper">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="submitter_id"
                                        label="Submitter ID"
                                        value={submitter.submitterID}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}

                                        data-test="submitter-id"
                                    />
                                </div>
                            </div>
                        </div>
                    </div>

                    <div className='tab-holder CustomExpansion-panel my-3' id="Provider Information Div Id">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header">
                                <Typography > Provider Information </Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panelp1a-content11"
                                        id="panelp1a-header11">
                                        <Typography>Billing Provider</Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>


                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="entity_qualifier_billing_prov"
                                                    label="Entity qualifier"
                                                    value={billingProviderInfo.entityTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="entity-qualifier"
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="curr_code_billing_prov"
                                                    label="Currency Code"
                                                    value={billingProviderInfo.currencyCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="currency-code"
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="lname_billing_prov"
                                                    label="Org / Last Name"
                                                    value={providerInfo.lastName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="last-name"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="fname_billing_prov"
                                                    label="First Name"
                                                    value={providerInfo.firstName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="first-name"
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="mi_billing_prov"
                                                    label="MI"
                                                    value={providerInfo.middleName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="suffix_billing_prov"
                                                    label="Suffix"
                                                    value={providerInfo.suffixName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md input-md-1-col">
                                                <TextField
                                                    disabled
                                                    id="address1_billing_prov"
                                                    label="Address 1"
                                                    value={billingProviderInfo.addressLine1}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md input-md-1-col">
                                                <TextField
                                                    disabled
                                                    id="address2_billing_prov"
                                                    label="Address 2"
                                                    value={billingProviderInfo.addressLine2}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="city_billing_prov"
                                                    label="City"
                                                    value={billingProviderInfo.cityName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="city"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="state_billing_prov"
                                                    label="State"
                                                    value={billingProviderInfo.stateCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="state"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <div className="cndt-row">

                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            disabled
                                                            id="zip_billing_prov"
                                                            label="Zip & Extension"
                                                            placeholder=""
                                                            value={billingProviderInfo.zipCode ? billingProviderInfo.zipCode.toString().substring(0,5) : ''}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            data-test="zip"
                                                        />
                                                    </div>

                                                    <div className="cndt-col-6">
                                                        <TextField
                                                            disabled
                                                            id="ext_billing_prov"
                                                            placeholder=""
                                                            value={billingProviderInfo.zipCode ? billingProviderInfo.zipCode.toString().substring(5) : ''}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>

                                                </div>

                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="country_billing_prov"
                                                    label="Country"
                                                    value={billingProviderInfo.countryCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>


                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="subdiv_billing_prov"
                                                    label="Subdivision Code"
                                                    value={billingProviderInfo.countrySubDivisionCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                        </div>

                                        <Divider className="mt-4" />
                                        <div className="tabs-container mt-2">
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                            </div>
                                            <TableComponent headCells={billingProviderheadCells} tableData={billinProviderSecIDs} onTableRowClick={editRow} defaultSortColumn="id" />
                                        </div>
                                        <div className="tabs-container mt-2">
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Contact Information </h2>
                                            </div>
                                            <TableComponent headCells={billingProviderContactheadCells} tableData={contactInformationList} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />
                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>


                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header"
                                    >
                                        <Typography > Rendering (Performing) Provider </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block">

                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="entity_qualifier_render_perform_prov"
                                                    label="Entity Qualifier"
                                                    value={renderingProvider.entityTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="rendering-entity-qualifier"
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="org_lname_render_perform_prov"
                                                    label="Org / Last Name"
                                                    value={renderingProviderInfo.lastName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="rendering-last-name"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="fname_render_perform_prov"
                                                    label="First Name"
                                                    value={renderingProviderInfo.firstName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="rendering-first-name"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="mi_render_perform_prov"
                                                    label="MI"
                                                    value={renderingProviderInfo.middleName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="rendering-mi"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="suffix_render_perform_prov"
                                                    label="Suffix"
                                                    value={renderingProviderInfo.suffixName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="rendering-suffix"
                                                />
                                            </div>
                                        </div>

                                        <Divider className="mt-4" />
                                        <div className="tabs-container mt-2">
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                            </div>
                                            <TableComponent headCells={billingProviderheadCells} tableData={billinProviderSecIDs} onTableRowClick={editRow} defaultSortColumn="id" />
                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header">
                                        <Typography >Referring Provider </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block">
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="entity_qualifier_render_prov"
                                                    label="Entity Qualifier"
                                                    value={referringProvider.entityTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="referring-entity-qualifier"
                                                    
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="org_lname_render_prov"
                                                    label="Org / Last Name"
                                                    value={referringProvider.lastName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }} 
                                                    data-test="referring-last-name"
                                                    />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="fname_render_prov"
                                                    label="First Name"
                                                    value={referringProvider.firstName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }} 
                                                    
                                                    data-test="referring-first-name"/>
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="mi_render_prov"
                                                    label="MI"
                                                    value={referringProvider.middleName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }} 
                                                    data-test="referring-mi"
                                                    />

                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="suffix_render_prov"
                                                    label="Suffix"
                                                    value={referringProvider.suffixName}
                                                    placeholder=""
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }} 
                                                    data-test="referring-suffix"
                                                    />
                                                            
                                            </div>
                                        </div>


                                        <Divider className="mt-4" />
                                        <div className="tabs-container mt-2">
                                            <div className="tab-header">
                                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                            </div>
                                            <TableComponent headCells={billingProviderheadCells} tableData={billinProviderSecIDs} onTableRowClick={editRow} defaultSortColumn="id" />
                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>






                    <div className='tab-holder CustomExpansion-panel my-3' id="Member Information Div Id">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography > Member Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                                <div className="tab-body-bordered py-2">
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="prop_casuality_num_mem_info"
                                                label="Property Casualty Number"
                                                value={payerSubscriber.propertyClaimNumber}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}

                                                data-test="property-casualty-number"
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="ssn_mem_info"
                                                label="SSN"
                                                value={payerSubscriber.additionalID1}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}

                                                data-test="ssn"
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entity_qualifier_mem_info"
                                                label="Entity Qualifier"
                                                value={entityInfo.memberQualifierCode}
                                                placeholder=""
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}

                                                data-test="member-entity-qualifier"
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md input-md-1-col">
                                            <TextField
                                                disabled
                                                id="address1_mem_info"
                                                label="Address 1"
                                                value={payerSubscriber.addressLine1}
                                                placeholder=""
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                data-test="address1"
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md input-md-1-col">
                                            <TextField
                                                disabled
                                                id="address2_mem_info"
                                                label="Address 2"
                                                value={payerSubscriber.addressLine2}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="city_mem_info"
                                                label="City"
                                                value={payerSubscriber.cityName}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="state_mem_info"
                                                label="State"
                                                value={payerSubscriber.stateCode}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>

                                        <div className="mui-custom-form input-md">
                                            <div className="cndt-row">

                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="zip_mem_info"
                                                        label="Zip & Extension"
                                                        placeholder=""
                                                        value={payerSubscriber.zipCode ? payerSubscriber.zipCode.toString().substring(0,5) : ''}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>

                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="ext_mem_info"
                                                        placeholder=""
                                                        value={payerSubscriber.zipCode ? payerSubscriber.zipCode.toString().substring(5) : ''}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>

                                            </div>

                                        </div>

                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="country_mem_info"
                                                label="Country"
                                                value={payerSubscriber.countryCode}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="subdiv_mem_info"
                                                label="Subdivision Code"
                                                value={payerSubscriber.countrySubDivisionCode}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <Divider className="mt-4 ml-3 mr-3" />
                                    <div className="tabs-container p-2 ml-2 mr-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                        </div>
                                        <TableComponent headCells={billingProviderheadCells1} tableData={subscriberSecIDs} onTableRowClick={editRow} defaultSortColumn="id" />
                                    </div>
                                </div>
                                <div class="tabs-container mt-3">

                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left">
                                            Subscriber Information </h2>
                                    </div>
                                    <div className="tab-body-bordered py-2">
                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="seq_code_subscribe_info"
                                                    label="Responsibility Sequence Code"
                                                    value={payerSubscriber.responsibilitySequenceCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="responsibility-sequence-code"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="policy_group_num_subscribe_info"
                                                    label="Policy or Group Number"
                                                    value={payerSubscriber.policyNumber}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="policy-number"
                                                    
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="insurance_type_code_subscribe_info"
                                                    label="Insurance Type Code"
                                                    value={payerSubscriber.insuranceTypeCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="insurance-type-code"
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="plan_name_subscribe_info"
                                                    label="Plan Name"
                                                    value={payerSubscriber.planName}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="plan-name"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="claim_filing_code_subscribe_info"
                                                    label="Claim Filing Code                                     "
                                                    value={payerSubscriber.claimFilingCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="claim-filling-code"
                                                />
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>

                    {/* <p> Claim Information </p>   */}

                    <div className='tab-holder CustomExpansion-panel my-3' id="Claim Information Div Id">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header">
                                <Typography >Claim Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panelp1a-content22"
                                        id="panelp1a-header22">
                                        <Typography> Accident Related Information </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails>

                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="auto_accident_country_claim_info"
                                                    label="Auto Accident Country"
                                                    value={accidentInfo.countryCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="auto-accident-country"
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="accident_time_claim_info"
                                                    label="Accident Time"
                                                    value={claimHdr.accidentDateTime ? claimHdr.accidentDateTime : ''}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="accident-time"
                                                />
                                            </div>

                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                <ExpansionPanel className="collapsable-panel mt-1 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header">
                                        <Typography >Claim Data </Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block">

                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="delay_reason_code_claim_data"
                                                    label="Delay Reason Code"
                                                    value={accidentInfo.delayReasonCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="delay-reason-code"

                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="spec_prog_type_code_claim_data"
                                                    label="Special Program Type Code"
                                                    value={accidentInfo.specialProgramCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="spec_prog_type_code_claim_data"
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="predetermine_benefit_id_num_claim_data"
                                                    label="Predetermination Benefit ID Number"
                                                    value={claimData && claimData.predeterminationBenefits ? claimData.predeterminationBenefits.benefitsID1: ''}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="predetermine_benefit_id_num_claim_data"
                                                />
                                            </div>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        disabled
                                                        id="appliance_date_claim_data"
                                                        label="Appliance Date"
                                                        format="MM/dd/yyyy"
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        placeholder="mm/dd/yyyy"
                                                        value={claimData && claimData.applianceDate1 ? claimData.applianceDate1 : null}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}

                                                        data-test="appliance_date_claim_data"
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="medicare_assignment_code_claim_data"
                                                    label="Medicare Assignment Code"
                                                    value={accidentInfo.medicareAssignmentCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}

                                                    data-test="medicare_assignment_code_claim_data"
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="benefit_assign_certificate_claim_data"
                                                    label="Benefits Assignment Certification"
                                                    value={accidentInfo.benefitCertificationCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="relaease_of_info_code_claim_data"
                                                    label="Release of Information Code"
                                                    value={accidentInfo.releaseOfInformationCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="service_auth_exception_code_claim_data"
                                                    label="Service Authorization Exception Code"
                                                    value={accidentInfo.exceptionCode}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper wrap-form-label">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="patient_paid_amt_claim_data"
                                                    label="Patient Paid Aamount"
                                                    value={`$${accidentInfo.patientPaidAmount ? accidentInfo.patientPaidAmount : ''}`}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="repriced_claim_num_claim_data"
                                                    label="Repriced Claim Number"
                                                    value={accidentInfo.repricedClaimNumber}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="adjust_repriced_claim_claim_data"
                                                    label="Adjusted Repriced Claim"
                                                    value={accidentInfo.adjustedRepricedClaimNumber}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        id="repricer_recieved_date_claim_data"
                                                        label="Repricer Received Date"
                                                        format="MM/dd/yyyy"
                                                        helperText= ''
                                                        error=''
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        disabled
                                                        placeholder="mm/dd/yyyy"
                                                        value={accidentInfo.repriceReceivedDate}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>

                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        id="admission_date_claim_data"
                                                        label="Admission Date"
                                                        format="MM/dd/yyyy"
                                                        helperText= ''
                                                        error=''
                                                        disabled
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        placeholder="mm/dd/yyyy"
                                                        value={props.data.admitDateTime == "" ? null : props.data.admitDateTime}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>

                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        id="discharge_date_claim_data"
                                                        label="Discharge Date"
                                                        format="MM/dd/yyyy"
                                                        helperText= ''
                                                        error=''
                                                        disabled
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        placeholder="mm/dd/yyyy"
                                                        value={accidentInfo.dischargeDate == "" ? null : accidentInfo.dischargeDate}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>
                                            <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                <div className="mui-custom-form input-md with-select">
                                                    <KeyboardDatePicker
                                                        id="referral_date_claim_data"
                                                        label="Referral Date"
                                                        disabled
                                                        format="MM/dd/yyyy"
                                                        helperText= ''
                                                        error=''
                                                        InputLabelProps={{
                                                            shrink: true
                                                        }}
                                                        placeholder="mm/dd/yyyy"
                                                        value={claimHdr.referralDate == "" ? null : claimHdr.referralDate}
                                                        KeyboardButtonProps={{
                                                            'aria-label': 'change date',
                                                        }}
                                                    />
                                                </div>
                                            </MuiPickersUtilsProvider>

                                        </div>

                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                    <ExpansionPanelSummary
                                        expandIcon={<ExpandMoreIcon />}
                                        aria-controls="panel1a-content"
                                        id="panel1a-header">
                                        <Typography >Claim Note</Typography>
                                    </ExpansionPanelSummary>
                                    <ExpansionPanelDetails className="clear-block custom-form-feild">
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md input-md-1-col">
                                                <TextareaAutosize
                                                    className="wid-100 textarea-with-counter"
                                                    aria-label="minimum-height"
                                                    id="claim_notes"
                                                    label=""
                                                    placeholder=""
                                                    value={notesInfo && notesInfo.noteText ? notesInfo.noteText : ""}
                                                    multiline
                                                    rowsMin={2}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    data-test="claim_notes"
                                                />
                                                <div className="mt-1"><Chip avatar={<Avatar>{characterRemaining&&characterRemaining.length ? 80-characterRemaining.length : 80}</Avatar>} label="Characters remaining" /></div>
                                            </div>
                                        </div>
                                    </ExpansionPanelDetails>
                                </ExpansionPanel>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>

                    <div className='tab-holder CustomExpansion-panel my-3' id="Basic Line Item Information Div Id" data-test="basic-line">
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panel1a-content"
                                id="panel1a-header"
                            >
                                <Typography data-test="item-information"> Basic Line Item Information </Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails className="clear-block">
                            <div className="tabs-container pb-2 mt-3 wrap-th-header">
                            <TableComponent headCells={basicLineItemsheadCells} tableData={basicLineItemInfoList} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />
                            </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                    </div>

                </div>
            </div>
        </div>
    )
}

export default BasicClaimInfo;