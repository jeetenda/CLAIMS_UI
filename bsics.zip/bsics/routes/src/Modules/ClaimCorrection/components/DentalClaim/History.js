import React, { useState } from "react";
import { Button } from 'react-bootstrap';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import DateFnsUtils from "@date-io/date-fns";
import dateFnsFormat from 'date-fns/format';
import TableComponent from '../../../../SharedModules/Table/Table';
import moment from 'moment';
import TableAHComponent from '../../../../SharedModules/Table/TableAH';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

const relatedHeadCells = [
    { id: "lineNumber" , numeric: false, disablePadding: true, label: 'Line #', enableHyperLink: false, fontSize: 12},
    { id: "claimExceptionCode" , numeric: false, disablePadding: true, label: 'Exception', enableHyperLink: true, fontSize: 12},
    { id: "historyTCN" , numeric: false, disablePadding: true, label: 'History TCN', enableHyperLink: false, fontSize: 12},
    { id: "historyLineNumber" , numeric: false, disablePadding: true, label: 'History Line', enableHyperLink: true, fontSize: 12},
    { id: "relatedClaimTypeCode" , numeric: false, disablePadding: true, label: 'Claim Type', enableHyperLink: false, fontSize: 12},
    { id: "relatedPaidDate" , numeric: false, disablePadding: true, label: 'Paid Date', enableHyperLink: false, fontSize: 12},
];

const locationHeadCells = [
    { id: "exceptionLocationCode" , numeric: false, disablePadding: true, label: 'Code', enableHyperLink: false, fontSize: 12},
    { id: "exceptionLocationID" , numeric: false, disablePadding: true, label: 'Routed To User ID', enableHyperLink: false, fontSize: 12},
    { id: "suspenseLocationExceptionCode" , numeric: false, disablePadding: true, label: 'Exception', enableHyperLink: true, fontSize: 12},
    { id: "exceptionLocationDate" , numeric: false, disablePadding: true, label: 'Date', enableHyperLink: false, fontSize: 12},
];

function  History(props) {
    const classes = useStyles();
    const getTableData = (data) => {
        if (data && data.length) {
          let tData = JSON.stringify(data); 
          tData = JSON.parse(tData);     
          tData.map((each,index) => {
            each.lineNumber = each.lineNumber;
			each.claimExceptionCode = each.claimExceptionCode;
			each.historyTCN = each.historyTCN;
			each.historyLineNumber = each.historyLineNumber;
			each.relatedClaimTypeCode = each.relatedClaimTypeCode;
			each.relatedPaidDate = moment(each.relatedPaidDate).format('MM/DD/YYYY');
            each.index = index;
          }); 
          console.log('Related Table Data: ',tData);
          return tData;           
        }else{
          return [];
        }
    };

    const getTableDataLocation = (data) => {
        if (data && data.length) {
          let tData = JSON.stringify(data); 
          tData = JSON.parse(tData);     
          tData.map((each,index) => {
            
			each.exceptionLocationCode = each.exceptionLocationCode;
			each.exceptionLocationUserID = each.exceptionLocationUserID;
			each.suspenseLocationExceptionCode = each.suspenseLocationExceptionCode;
			each.exceptionLocationDate = moment(each.exceptionLocationDate).format('MM/DD/YYYY');
            each.index = index;
          }); 
          console.log('Location Table Data: ',tData);
          return tData;           
        }else{
          return [];
        }
    };

    const relatedEditRow = () => {};

    const locationEditRow = () => {};
    const editRow = (row) => (event) => {};

    const editRow1=row=>(event)=>{
        props.setTabValue(0);
        props.setAdTabId(row.claimExceptionCode)
    }
    
    const editRowTcn = row => (event) => { 
        let searchCriteria = {};
      searchCriteria = {
                      tcn: row.replacementTCN !== '' ? row.replacementTCN : null,
                      batchNo:  null,
                      julianDate: null,
                      "mediaSource":  null,
                  };
                  setspinnerLoader(true);
                  //onSearch(searchCriteria);
                  props.onSearchParent(searchCriteria);
      return true;
     
    };
    
    return (
        <div className="pos-relative">
            {props.spinnerLoader ? <Spinner /> : null}
            <div className="tabs-container custom-panel">
                <div className='tab-holder CustomExpansion-panel my-3'>
        <ExpansionPanel className="collapsable-panel">
            <ExpansionPanelSummary
                expandIcon={<ExpandMoreIcon />}
                aria-controls="panelp1a-content32"
                id="panelp1a-header42116">
                <Typography className={classes.heading}  data-test="test_history"> History </Typography>
            </ExpansionPanelSummary>
            <ExpansionPanelDetails>
                    <div className="tab-header">
                        <h2 className="tab-heading float-left" data-test="test_rltd_history">
                            Related History
                        </h2>
                    </div>
                    
                    <TableAHComponent headCells={relatedHeadCells} tableData={props.data && props.data.relatedHistory?getTableData(props.data.relatedHistory ? props.data.relatedHistory : []) : []} onTableRowClick={relatedEditRow}   newfun1={editRow1} newfun2={editRow} defaultSortColumn="diagnosisCode" data-test="test_rltd_history_table"/>    
                  
                    <div className="tab-header">
                        <h2 className="tab-heading float-left" data-test='test_locn_history'>
                            Location History
                        </h2>
                    </div>
                    <TableAHComponent headCells={locationHeadCells} tableData={props.data && props.data.previousLocations?getTableDataLocation(props.data.previousLocations ? props.data.previousLocations : []):[]} onTableRowClick={locationEditRow} defaultSortColumn="diagnosisCode" data-test='test_locn_history_table'/>    
            </ExpansionPanelDetails>
        </ExpansionPanel>
        </div>
        </div>
        </div>
    )
}

export default  History;