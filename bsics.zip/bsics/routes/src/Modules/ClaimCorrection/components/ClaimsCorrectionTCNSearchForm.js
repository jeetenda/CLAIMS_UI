// import React from "react"
import TextField from '@material-ui/core/TextField';
import { Button } from 'react-bootstrap';
import MenuItem from '@material-ui/core/MenuItem';
import * as ClaimsInquiryConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import React, { useState, useEffect } from 'react';
function ClaimsCorrectionTCNSearchForm(props) {
    
     const handleInputChange = () => {
         props.values.tcn = props.values.tcn.replace(/[^0-9]/g, '') 
}
    const mediaSourceDropDown =  props.dropdowns &&  props.dropdowns['Claims#C_BATCH_MEDIA_SRC_CD'] && props.dropdowns['Claims#C_BATCH_MEDIA_SRC_CD'].map( each => (
		<MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
        
     ))

     return (
        < >
        
        <form autoComplete="off">
        {/* {props.spinnerLoader ? <Spinner /> : null} */}
            <div className="mt-3">
            <h5 className="py-2 sub-h2">TCN OR Batch Number, Julian Date &amp; Media Source must be specified.</h5>
            <div className="set-form-wrapper">
                <div className="form-wrapper">
                <div className="mui-custom-form input-md ">
                    <TextField
                        id="tcn_correction_id"
                        label="TCN"
                        className="inline-lable-ttl"
                        value={props.values.tcn}
                        type="text"
                        inputProps={{ maxLength: 17 }}
                        onChange={props.handleChanges('tcn')}
                        placeholder=""
                        onInput={ handleInputChange()}
                        helperText={props.errors.showTcnError ? ClaimsInquiryConstants.TCN_Error : props.errors.showTcnInvError ? ClaimsInquiryConstants.CORRECTION_TCN_NUM_Error : props.errors.showTCNNumberError ? ClaimsInquiryConstants.TCN_NUMBER_ERROR : null}
                        InputLabelProps={{
                            shrink: true,
                        }}
                        error={props.errors.showTcnError ? ClaimsInquiryConstants.TCN_Error : props.errors.showTcnInvError ? ClaimsInquiryConstants.CORRECTION_TCN_NUM_Error : props.errors.showTCNNumberError ? ClaimsInquiryConstants.TCN_NUMBER_ERROR : null}
                        data-test = "claims-correction-tcn"
                    />
                </div>
                </div>
            </div>
            </div>
            <div className="tabs-container pb-3">
                <div className="tab-header">
                    <h1 className="tab-heading float-left"> Batch Data </h1>
                </div>                

                <div className="tab-body-bordered">
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                id="batch_number_tcn_correction_tab"
                                label="Batch Number"
                                value={props.values.batchNo}
                                inputProps={{ maxLength: 4 }}
                                onChange={props.handleChanges('batchNo')}
                                placeholder=""
                                helperText={props.errors.showBatchNoError ? ClaimsInquiryConstants.Batch_No_Error : props.errors.showBatchInvError ? ClaimsInquiryConstants.Batch_No_INV_Error : props.errors.showBatchNumberError ? ClaimsInquiryConstants.BATCH_NUMBER_ERROR : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                error={props.errors.showBatchNoError ? ClaimsInquiryConstants.Batch_No_Error : props.errors.showBatchInvError ? ClaimsInquiryConstants.Batch_No_INV_Error : props.errors.showBatchNumberError ? ClaimsInquiryConstants.BATCH_NUMBER_ERROR : null}
                                data-test = "batch-number-tcn"
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                id="julian_date_tcn_correction_tab"
                                label="Julian Date"
                                format="MM/dd/yyyy"
                                value={props.values.julianDate}
                                inputProps={{ maxLength: 5 }}
                                onChange={props.handleChanges('julianDate')}
                                helperText={props.errors.showJulianDateError ? ClaimsInquiryConstants.Julian_Date_Error : props.errors.showJulianInvError?ClaimsInquiryConstants.JULIAN_DATE_INV_Error : props.errors.showJulianDateInvError?ClaimsInquiryConstants.BATCH_DATE_INVALID : props.errors.shoJulianDateLessError?ClaimsInquiryConstants.BATCH_DATE_GT_CDT : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                error={props.errors.showJulianDateError ? ClaimsInquiryConstants.Julian_Date_Error : props.errors.showJulianInvError?ClaimsInquiryConstants.JULIAN_DATE_INV_Error : props.errors.showJulianDateInvError?ClaimsInquiryConstants.BATCH_DATE_INVALID : props.errors.shoJulianDateLessError?ClaimsInquiryConstants.BATCH_DATE_GT_CDT : null}
                                data-test = "julian-date-tcn"
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="media_source_tcn_correction_tab"
                                select
                                label="Media Source"
                                value={props.values.mediaSource}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('mediaSource')}
                                placeholder="Please Select One"
                                helperText={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                error={props.errors.showMediaSourceError ? ClaimsInquiryConstants.Media_Source_Error : null}
                                data-test = "media-source-tcn"
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                            {mediaSourceDropDown}
                            </TextField>
                        </div>
                    </div>
                   
                </div>
                <div className="tab-header pt-3">
                    <div className="float-right th-btnGroup mb-2">
                        <Button
                            title="Search"
                            variant="outlined"
                            color="primary"
                            className="btn btn-primary"
                            onClick={props.searchCheck}
                            disabled={props.privileges && !props.privileges.search? 'disabled':''}
                            data-test="search-button-claims-tcn"
                        >
                            {' '}
                            <i className="fa fa-search" />
                            Search
                    {' '}

                        </Button>
                        <Button
                            title="Reset"
                            variant="outlined"
                            color="primary"
                            className="btn btn-reset"
                            onClick={props.resetTable}
                            data-test = "reset-button-claims-tcn"
                        >
                            {' '}
                            <i className="fa fa-undo" />
                            Reset
                    {' '}

                        </Button>
                    </div>
                    <div className="clearfix" />
                </div>
                

            </div>
        </form>
        </>
    )
}


export default ClaimsCorrectionTCNSearchForm;