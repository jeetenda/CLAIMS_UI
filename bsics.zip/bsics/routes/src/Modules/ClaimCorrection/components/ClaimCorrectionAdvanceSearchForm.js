import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import Radio from '@material-ui/core/Radio';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import DateFnsUtils from '@date-io/date-fns';
import RadioGroup from '@material-ui/core/RadioGroup';
import InputAdornment from '@material-ui/core/InputAdornment';
import * as ClaimsCorrectionConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';


export default function ClaimCorrectionAdvanceSearchForm(props) {
	
const providerTypeCodeDropDown = props.dropdowns && props.dropdowns['P1#P_ALT_ID_TY_CD'] && props.dropdowns['P1#P_ALT_ID_TY_CD'].map(each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));

const COSDropDown = props.dropdowns && props.dropdowns['Claims#C_COS_CD'] && props.dropdowns['Claims#C_COS_CD'].map(each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));

const providerTypeDropDown = props.dropdowns && props.dropdowns['P1#P_TY_CD'] && props.dropdowns['P1#P_TY_CD'].map(each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));

const locationDropDownData = props.locationDropdownData && props.locationDropdownData.searchResultsValues && props.locationDropdownData.searchResultsValues.map(each => (
    <MenuItem selected key={each.locationCode} value={each.locationCode}>{each.locationCode}-{(each.locationText).split('-')[0]}</MenuItem>
))

const LOBDropDown = props.dropdowns && props.dropdowns['Claims#R_LOB_CD'] && props.dropdowns['Claims#R_LOB_CD'].map(each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));

const claimTypeDropDown = props.dropdowns && props.dropdowns['Claims#C_TY_CD'] && props.dropdowns['Claims#C_TY_CD'].map(each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));

const transTypeDropDown = props.dropdowns && props.dropdowns['Claims#C_TXN_TY_CD'] && props.dropdowns['Claims#C_TXN_TY_CD'].map(each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));

const procedureModifiersDropDown = props.dropdowns && props.dropdowns['Claims#R_PROC_MOD_CD'] && props.dropdowns['Claims#R_PROC_MOD_CD'].map(each => (
    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
));
	return (
        <form autoComplete="off">
        {/* {props.spinnerLoader ? <Spinner /> : null} */}

        <div className="tabs-container-inner">
            <div className="tab-note">
                <p> *Provider Data, Member Data and/or Claim Type is required.</p>
            </div>
            <div className="tab-body-bordered">
                <div className="form-wrapper">
                    <div className="mui-custom-form with-select input-md" >
                        <label className="MuiFormLabel-root MuiInputLabel-shrink">Provider Role:</label>
                        <div className="sub-radio mt-0">
                            <RadioGroup
                                row
                                aria-label="providerRole"
                                name="providerRole">
                                <FormControlLabel
                                    value='BI'
                                    id="billing_adv_tab"
                                    control={<Radio color="primary" />}
                                    label="Billing"
                                    checked={props.values.providerRole === 'BI'}
                                    onChange={props.handleChanges('providerRole')}
                                    InputLabelProps={{
                                        shrink: true,
                                        required: true
                                    }}
                                    data-test = 'advance-billing'
                                />
                                <FormControlLabel
                                    value='RN'
                                    id="rendering_adv_tab"
                                    control={<Radio color="primary" />}
                                    checked={props.values.providerRole === 'RN'}
                                    onChange={props.handleChanges('providerRole')}
                                    label="Rendering"
                                    InputLabelProps={{
                                        shrink: true,
                                        required: true
                                    }}
                                    data-test = 'advance-rendering'

                                />

                            </RadioGroup>
                        </div>
                    </div>
                    <div className="mui-custom-form with-select input-md">
                        <TextField
                            id="provider_id_type_code_adv_tab"
                            select
                            label="Provider ID Type Code"
                            value={props.values.providerIDTypeCode}
                            inputProps={{ maxLength: 2 }}
                            onChange={props.handleChanges('providerIDTypeCode')}
                            placeholder="Please Select One"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test = 'provider-id-type-code'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {providerTypeCodeDropDown}

                        </TextField>
                    </div>
                    <div className="mui-custom-form input-md">
                        <TextField
                            id="provider_id_adv_tab"
                            label="Provider ID"
                            value={props.values.providerID}
                            inputProps={{ maxLength: 15 }}
                            onChange={props.handleChanges('providerID')}
                            placeholder=""
                            // helperText={showProviderIdError ? ClaimsCorrectionConstants.PROVIDER_ID_Error : null}
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test = 'provider-id-type'
                        // error={showProviderIdError ? ClaimsCorrectionConstants.PROVIDER_ID_Error : null}
                        />
                    </div>
                </div>
                <div className="form-wrapper">
                    <div className="mui-custom-form with-select input-md">
                        <TextField
                            id="member_id_adv_tab"
                            label="Member ID"
                            value={props.values.memberID}
                            inputProps={{ maxLength: 15 }}
                            onChange={props.handleChanges('memberID')}
                            placeholder=""
                            // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='member-id'
                        // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                        />
                    </div>

                </div>
                <div className="form-wrapper">
                    <div className="mui-custom-form with-select input-md">
                        <TextField
                            id="Claim_type_adv_tab"
                            select
                            label="Claim Type"
                            value={props.values.claimType}
                            inputProps={{ maxLength: 2 }}
                            onChange={props.handleChanges('claimType')}
                            placeholder="Please Select One"
                            // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            InputLabelProps={{
                                shrink: true,
                            }}
                        // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            data-test = 'claim-type'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                          { claimTypeDropDown}
                        </TextField>
                    </div>

                </div>
            </div>
        </div>

        <div className="py-2">
            <span>*One date range is required. You may enter more than one.</span>
        </div>
        <div className="tab-body-bordered">
            <div className="form-wrapper">
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form input-md with-select" >
                        <KeyboardDatePicker
                            id="dos_bgn_date_adv_tab"
                            label="DOS Begin"
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            placeholder="mm/dd/yyyy"
                            value={props.values.beginDOS}
                            onChange={props.handleBeginDateChange}
                            helperText={props.errors.showBgdtGTEnddtErr ? ClaimsCorrectionConstants.Bgndt_GT_Enddt_Err : props.errors.beginDtInvalidErr ? ClaimsCorrectionConstants.Invalid_Begin_Date_Error : props.errors.showBeginDOSError ? ClaimsCorrectionConstants.BEGINDOSERR : null}
                            error={props.errors.showBgdtGTEnddtErr ? ClaimsCorrectionConstants.Bgndt_GT_Enddt_Err : props.errors.beginDtInvalidErr ? ClaimsCorrectionConstants.Invalid_Begin_Date_Error : props.errors.showBeginDOSError ? ClaimsCorrectionConstants.BEGINDOSERR : null}
                            KeyboardButtonProps={{
                                'aria-label': 'change date',
                            }}
                            data-test='dos-begin'
                        />
                    </div>
                </MuiPickersUtilsProvider>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form input-md with-select" >
                        <KeyboardDatePicker
                            id="dos_end_date_adv_tab"
                            label="DOS End"
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            placeholder="mm/dd/yyyy"
                            value={props.values.endDOS}
                            onChange={props.handleEndDateChange}
                            helperText={props.errors.endDtInvalidErr ? ClaimsCorrectionConstants.Invalid_End_Date_Error : props.errors.showEndDOSError ? ClaimsCorrectionConstants.ENDDOSERR : null}
                            error={props.errors.endDtInvalidErr ? ClaimsCorrectionConstants.Invalid_End_Date_Error : props.errors.showEndDOSError ? ClaimsCorrectionConstants.ENDDOSERR : null}
                            KeyboardButtonProps={{
                                'aria-label': 'change date',
                            }}
                            data-test='dos-end'
                        />
                    </div>
                </MuiPickersUtilsProvider>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form input-md with-select" >
                        <KeyboardDatePicker
                            id="adjudication_bgn_date_adv_tab"
                            label="Adjudication Date Begin"
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            placeholder="mm/dd/yyyy"
                            value={props.values.beginAdjudicationDate ? props.values.beginAdjudicationDate : null}
                            onChange={props.handleAdjudicationBeginDateChange}
                            helperText={props.errors.showBgdtGTADJEnddtErr ? ClaimsCorrectionConstants.Bgndt_GT_Enddt_Err : props.errors.beginDtADJInvalidErr ? ClaimsCorrectionConstants.Invalid_Begin_Date_Error : props.errors.showBeginADJError ? ClaimsCorrectionConstants.BEGINADJERR : null}
                            error={props.errors.showBgdtGTADJEnddtErr ? ClaimsCorrectionConstants.Bgndt_GT_Enddt_Err : props.errors.beginDtADJInvalidErr ? ClaimsCorrectionConstants.Invalid_Begin_Date_Error : props.errors.showBeginADJError ? ClaimsCorrectionConstants.BEGINADJERR : null}
                            KeyboardButtonProps={{
                                'aria-label': 'change date',
                            }}
                            data-test = 'adjucation-date-begin'
                        />
                    </div>
                </MuiPickersUtilsProvider>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                    <div className="mui-custom-form input-md with-select" >
                        <KeyboardDatePicker
                            id="adjudication_end_date_adv_tab"
                            label="Adjudication Date End"
                            format="MM/dd/yyyy"
                            InputLabelProps={{
                                shrink: true,
                            }}
                            placeholder="mm/dd/yyyy"
                            value={props.values.endAdjudicationDate ? props.values.endAdjudicationDate : null}
                            onChange={props.handleAdjudicationEndDateChange}
                            helperText={props.errors.endDtADJInvalidErr ? ClaimsCorrectionConstants.Invalid_End_Date_Error : props.errors.showEndADJError ? ClaimsCorrectionConstants.ENDADJERR : null}
                            error={props.errors.endDtADJInvalidErr ? ClaimsCorrectionConstants.Invalid_End_Date_Error : props.errors.showEndADJError ? ClaimsCorrectionConstants.ENDADJERR : null}
                            KeyboardButtonProps={{
                                'aria-label': 'change date',
                            }}
                            data-test = 'adjucation-date-end'
                        />
                    </div>
                </MuiPickersUtilsProvider>

            </div>
        </div>

        <div className="tab-header">
            <h2 className="tab-heading float-left"> Additional Search Criteria </h2>
        </div>
        <div className="tab-body-bordered mb-3 pb-3">
            <div className="tab-inner-body">

                <div className="tab-body-bordered">
                    <div className="form-wrapper">
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="federal_tax_id_adv_tab"
                                label="Federal Tax ID"
                                value={props.values.fedralTaxID}
                                inputProps={{ maxLength: 9 }}
                                onChange={props.handleChanges('fedralTaxID')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            data-test = 'federal-tax-id'
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="service_auth_adv_tab"
                                label="Service Auth ID"
                                value={props.values.remittanceAdvice}
                                inputProps={{ maxLength: 30 }}
                                onChange={props.handleChanges('remittanceAdvice')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'service-auth-id'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>

                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="lob_adv_tab"
                                select
                                label="LOB"
                                value={props.values.lob}
                                inputProps={{ maxLength: 3 }}
                                onChange={props.handleChanges('lob')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'lob'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {LOBDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="benefit_plan_id_adv_tab"
                                label="Benefit Plan ID"
                                value={props.values.benefitPlanId}
                                inputProps={{ maxLength: 6 }}
                                onChange={props.handleChanges('benefitPlanId')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='benefit-plan-id'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="category_of_services_adv_tab"
                                select
                                label="Category Of Services"
                                value={props.values.categoryOfService}
                                inputProps={{ maxLength: 3 }}
                                onChange={props.handleChanges('categoryOfService')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'category-of-service'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {COSDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="provider_type_adv_tab"
                                select
                                label="Provider Type"
                                value={props.values.providerType}
                                inputProps={{ maxLength: 3 }}
                                onChange={props.handleChanges('providerType')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                data-test = 'provider-type-two'
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {providerTypeDropDown}

                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="diagnosis_code_adv_tab"
                                label="Diagnosis Code"
                                value={props.values.diagnosisCode}
                                inputProps={{ maxLength: 10 }}
                                onChange={props.handleChanges('diagnosisCode')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'diagnosis-code'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="drg_code_adv_tab"
                                label="DRG Code"
                                value={props.values.drgCode}
                                inputProps={{ maxLength: 5 }}
                                onChange={props.handleChanges('drgCode')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'drg-code'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>


                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="location_code_adv_tab"
                                select
                                label="Location Code"
                                value={props.values.claimType}
                                inputProps={{ maxLength: 3 }}
                                onChange={props.handleChanges('claimType')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'location-code'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {locationDropDownData}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="trans_type_adv_tab"
                                select
                                label="Transaction Type"
                                value={props.values.transType}
                                inputProps={{ maxLength: 3 }}
                                onChange={props.handleChanges('transType')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='transaction-type'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>

                                {transTypeDropDown}

                            </TextField>
                        </div>


                    </div>
                </div>
            </div>
            <div className="tab-inner-body">
                <div className="tab-header">
                    <h2 className="tab-heading float-left">Procedure Code</h2>
                </div>
                <div className="tab-body-bordered">
                    <div className="form-wrapper">
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="form_adv_tab"
                                label="From"
                                value={props.values.fromProcedureCode}
                                inputProps={{ maxLength: 7 }}
                                onChange={props.handleChanges('fromProcedureCode')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='from-code'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="from_modifier_1_adv_tab"
                                select
                                label="Modifier 1"
                                value={props.values.frModifier1}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('frModifier1')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='modifier-1'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="from_modifier_2_adv_tab"
                                select
                                label="Modifier 2"
                                value={props.values.frModifier2}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('frModifier2')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'modifier-2'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="from_modifier_3_adv_tab"
                                select
                                label="Modifier 3"
                                value={props.values.frModifier3}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('frModifier3')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'modifier-3'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="from_modifier_4_adv_tab"
                                select
                                label="Modifier 4"
                                value={props.values.frModifier4}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('frModifier4')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test = 'modifier-4'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>


                    </div>

                    <div className="form-wrapper">
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="to_adv_tab"
                                label="To"
                                value={props.values.toProcedureCode}
                                inputProps={{ maxLength: 7 }}
                                onChange={props.handleChanges('toProcedureCode')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='to-code'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="to_modifier_1_adv_tab"
                                select
                                label="Modifier 1"
                                value={props.values.toModifier1}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('toModifier1')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='modifier-1-2'

                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="to_modifier_2_adv_tab"
                                select
                                label="Modifier 2"
                                value={props.values.toModifier2}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('toModifier2')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='modifier-2-2'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="to_modifier_3_adv_tab"
                                select
                                label="Modifier 3"
                                value={props.values.toModifier3}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('toModifier3')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='modifier-2-3'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="to_modifier_4_adv_tab"
                                select
                                label="Modifier 4"
                                value={props.values.toModifier4}
                                inputProps={{ maxLength: 2 }}
                                onChange={props.handleChanges('toModifier4')}
                                placeholder="Please Select One"
                                // helperText={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='modifier-2-4'
                            // error={showProviderIdTypeError ? ClaimsCorrectionConstants.PROVIDER_ID_TYPE_Error : null}
                            >
                                <MenuItem value="-1">Please Select One</MenuItem>
                                {procedureModifiersDropDown}
                            </TextField>
                        </div>


                    </div>
                </div>
            </div>
            <div className="tab-inner-body">
                <div className="tab-header">
                    <h2 className="tab-heading float-left">Revenue Code</h2>
                </div>
                <div className="tab-body-bordered">
                    <div className="form-wrapper">
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="revenue_code_from_adv_tab"
                                label="From"
                                value={props.values.fromRevenueCode}
                                inputProps={{ maxLength: 7 }}
                                onChange={props.handleChanges('fromRevenueCode')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='from-revenue-code'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="revenue_code_to_adv_tab"
                                label="To"
                                value={props.values.toRevenueCode}
                                inputProps={{ maxLength: 7 }}
                                onChange={props.handleChanges('toRevenueCode')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                data-test='to-revenue-code'
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            />
                        </div>


                    </div>
                </div>
            </div>
            <div className="tab-inner-body">
                <div className="tab-header">
                    <h2 className="tab-heading float-left">Billed Amount</h2>
                </div>
                <div className="tab-body-bordered">
                    <div className="form-wrapper">
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="billing_amt_from_adv_tab"
                                label="From"
                                value={props.values.fromBilledAmount}
                                inputProps={{ maxLength: 14 }}
                                onChange={props.handleChanges('fromBilledAmount')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                InputProps={{
                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                }}
                                helperText={
                                    props.errors.showFromBilledAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR :
                                        props.errors.showFromBilledAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error :
                                            props.errors.showFromBilledAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                                : null
                                }
                                error={
                                    props.errors.showFromBilledAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR :
                                        props.errors.showFromBilledAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error :
                                            props.errors.showFromBilledAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                                : null
                                }
                                data-test = 'from-billed-amount'
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="billing_amt_to_adv_tab"
                                label="To"
                                value={props.values.toBilledAmount}
                                inputProps={{ maxLength: 14 }}
                                onChange={props.handleChanges('toBilledAmount')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                InputProps={{
                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                }}
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            helperText={
                                props.errors.showToBilledAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR:
                                props.errors.showToBilledAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error:
                                props.errors.showToBilledAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                : null
                            }
                            error={
                                props.errors.showToBilledAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR:
                                props.errors.showToBilledAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error:
                                props.errors.showToBilledAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                : null
                            }
                            data-test='to-billed-amount'
                            />
                        </div>


                    </div>
                </div>
            </div>


            <div className="tab-inner-body">
                <div className="tab-header">
                    <h2 className="tab-heading float-left">Allowed Amount</h2>
                </div>
                <div className="tab-body-bordered">
                    <div className="form-wrapper">
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="allowed_amt_from_adv_tab"
                                label="From"
                                value={props.values.fromAllowedAmount}
                                inputProps={{ maxLength: 14 }}
                                onChange={props.handleChanges('fromAllowedAmount')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                InputProps={{
                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                }}
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            helperText={
                                props.errors.showFromAllowedAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR:
                                props.errors.showFromAllowedAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error:
                                props.errors.showFromAllowedAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                : null
                            }
                            error={
                                props.errors.showFromAllowedAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR:
                                props.errors.showFromAllowedAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error:
                                props.errors.showFromAllowedAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                : null
                            }
                            data-test='allowed-amount'
                            />
                        </div>
                        <div className="mui-custom-form with-select input-md">
                            <TextField
                                id="allowed_amt_to_adv_tab"
                                label="To"
                                value={props.values.toAllowedAmount}
                                inputProps={{ maxLength: 14 }}
                                onChange={props.handleChanges('toAllowedAmount')}
                                placeholder=""
                                // helperText={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                                InputProps={{
                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                }}
                            // error={showMemberIdError ? ClaimsCorrectionConstants.MEMBER_ID_Error : null}
                            helperText={
                                props.errors.showToAllowedAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR:
                                props.errors.showToAllowedAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error:
                                props.errors.showToAllowedAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                : null
                            }
                            error={
                                props.errors.showToAllowedAmountErr ? ClaimsCorrectionConstants.MAX_ALLOW_AMT_ERR:
                                props.errors.showToAllowedAmountFormatErr ? ClaimsCorrectionConstants.Amt_Incorrect_Format_Error:
                                props.errors.showToAllowedAmountFloatErr ? ClaimsCorrectionConstants.Amt_Float_Error
                                : null
                            }
                            data-test = 'to-allowed-amount'
                            />
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div className="float-right th-btnGroup mr-3 mb-3">
            <Button
                title="Search"
                variant="outlined"
                color="primary"
                className="btn btn-primary"
                onClick={props.searchCheck}
                disabled={props.privileges && !props.privileges.search? 'disabled':''}
                data-test = 'search-button-click'
            >
                <i className="fa fa-search"></i>
                {' '}
                Search
      {' '}

            </Button>
            <Button
                title="Reset"
                variant="outlined"
                color="primary"
                className="btn btn-reset  ml-1"
                onClick={props.resetTable}
                data-test = 'reset-button-click'

                >
                <i className="fa fa-undo"></i>
                {' '}
                Reset
      {' '}

            </Button>
        </div>
        <div className="clearfix" />
   </form>
  
			);
}
