import React, {useState} from 'react';
import { withRouter } from 'react-router';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../SharedModules/Table/Table';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import TextField from '@material-ui/core/TextField';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from '@material-ui/core/InputAdornment';
import { Divider } from "@material-ui/core";
import Alert from '@material-ui/lab/Alert';
import { setZeroAtdecimalPoint } from "./ClaimUtility";
import moment from 'moment';

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

function ClaimOtherDentalCoordinateOfBenefits(props) {
    const classes = useStyles();
    const [adjustmentsData, setAdjustmentsData] = React.useState(false);
    const [showData, setShowData] = React.useState([]);
   // const [otherPayerTable, setOtherPayerTable] = React.useState([]);
    
    const [lineIndex, setLineIndex] = useState(0);
    const claimLevelAdjustmentTable = props.tableData && props.tableData.claimAdjustmentReasons ? props.tableData.claimAdjustmentReasons : [];
    const claimOtherPayersInfo = props.tableData.enterpriseClaimAux && props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex] ? props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex] : {};
    const otherPayerMedicareInfo = props.tableData.enterpriseClaimAux && props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex].otherPayerMedicareInfo ? props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex].otherPayerMedicareInfo : {};
    const cobMonetryAmount = props.tableData.enterpriseClaimAux && props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex].otherPayerTPLInfo ? props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex].otherPayerTPLInfo : {};
    const otherInsuranceCoverage = props.tableData.enterpriseClaimAux && props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex].otherSubscriberInfo ? props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[lineIndex].otherSubscriberInfo : {};
    const otherPayersSubDivisionCode = otherInsuranceCoverage;
    //console.log("Esrd",props.tableData.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers[0].otherPayerMedicareInfo.outPatientESRDAmount);
    const otherPayerPatientInfo = claimOtherPayersInfo;
    const otherPayerRenderingInfo = claimOtherPayersInfo;
    const otherPayerReferingInfo = claimOtherPayersInfo;
    const otherPayerAssistantSurgeonProviderInfo = claimOtherPayersInfo;
    const otherPayerBillingProviderInfo = claimOtherPayersInfo;
    const otherPayer = claimOtherPayersInfo

    
    var otherPayerTable = [];
    const tbleID = claimOtherPayersInfo;
    var idtype1 = tbleID.additionalQualifierCode1; var id1 = tbleID.additionalID1; var payerID1 = tbleID.additionalID1;
    var idtype2 = tbleID.additionalQualifierCode2; var id2 = tbleID.additionalID2; var payerID2 = tbleID.additionalID2;
    var idtype3 = tbleID.additionalQualifierCode3; var id3 = tbleID.additionalID3; var payerID3 = tbleID.additionalID3;
    var eIdNumber1 = tbleID.additionalID1; var claimOfficeNumber1 = tbleID.additionalID1; var naicCode1 = tbleID.additionalID1;
    var eIdNumber2 = tbleID.additionalID2; var claimOfficeNumber2 = tbleID.additionalID2; var naicCode2 = tbleID.additionalID2;
    var eIdNumber3 = tbleID.additionalID3; var claimOfficeNumber3 = tbleID.additionalID3; var naicCode3 = tbleID.additionalID3;
    if(idtype1 != null || id1 != null || payerID1 != null || eIdNumber1 != null || claimOfficeNumber1 != null || naicCode1 != null){
        otherPayerTable.push({'idtype':tbleID.additionalQualifierCode1, 'id':tbleID.additionalID1, 'payerID':tbleID.additionalID1, 'employerIdNumber':tbleID.additionalID1, 'claimOfficeNumber':tbleID.additionalID1, 'naicCode':tbleID.additionalID1})
    }
    if(idtype2 != null || id2 != null || payerID2 != null || eIdNumber2 != null || claimOfficeNumber2 != null || naicCode2 != null){
        otherPayerTable.push({'idtype':tbleID.additionalQualifierCode2, 'id':tbleID.additionalID2, 'payerID':tbleID.additionalID2, 'employerIdNumber':tbleID.additionalID2, 'claimOfficeNumber':tbleID.additionalID2, 'naicCode':tbleID.additionalID2})
        
    }
    if(idtype3 != null || id3 != null || payerID3 != null || eIdNumber3 != null || claimOfficeNumber3 != null || naicCode3 != null){
        otherPayerTable.push({'idtype':tbleID.additionalQualifierCode3, 'id':tbleID.additionalID3+' ', 'payerID':tbleID.additionalID3+' ', 'employerIdNumber':tbleID.additionalID3+' ', 'claimOfficeNumber':tbleID.additionalID3+' ', 'naicCode':tbleID.additionalID3+' '})    
    }

   // console.log('Other Payer Table: ', otherPayerTable);
    const otherSubscriberInfo = otherInsuranceCoverage;
    const otherSubscriberSecondaryTable = [];
    var providerIDType1 = otherSubscriberInfo.additionalQualifierCode1; var providerIDType2 = otherSubscriberInfo.additionalQualifierCode2; var providerIDType3 = otherSubscriberInfo.additionalQualifierCode3;
    var providerID1 = otherSubscriberInfo.additionalID1; var providerID2 = otherSubscriberInfo.additionalID2; var providerID3 = otherSubscriberInfo.additionalID3;
     if(providerIDType1 != null || providerID1 != null){    
        otherSubscriberSecondaryTable.push({'providerIDTypeShortDesc': otherSubscriberInfo.additionalQualifierCode1,'providerID': otherSubscriberInfo.additionalID1});
     }
     if(providerIDType2 != null || providerID2 != null){    
        otherSubscriberSecondaryTable.push({'providerIDTypeShortDesc': otherSubscriberInfo.additionalQualifierCode2,'providerID': otherSubscriberInfo.additionalID2});
     }
     if(providerIDType3 != null || providerID3 != null){    
        otherSubscriberSecondaryTable.push({'providerIDTypeShortDesc': otherSubscriberInfo.additionalQualifierCode3,'providerID': otherSubscriberInfo.additionalID3});
     }
          //console.log('ST',otherSubscriberSecondaryTable);
    const opSecondaryTable = claimOtherPayersInfo.otherPayerSubmittedProviderIDs;
    var opSecondaryTableSFArray = [];
    var opSecondaryTablePCArray = [];
    var opSecondaryTableASArray = [];
    var opSecondaryTableSUArray = [];
    var opSecondaryTableBIArray = [];
   //var opSecondaryTableRNArray = [];
    //var opSecondaryTableRFArray = [];
    //var opSecondaryTablePTArray = [];
    const secondaryTableSf = opSecondaryTable.filter((e)=> e.providerRoleCode === 'SF' && e.lineNumber == 0).map(e => opSecondaryTableSFArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));
    const secondaryTablePc = opSecondaryTable.filter((e)=> e.providerRoleCode === 'PC' && e.lineNumber == 0).map(e => opSecondaryTablePCArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));
    const secondaryTableAs = opSecondaryTable.filter((e)=> e.providerRoleCode === 'AS' && e.lineNumber == 0).map(e => opSecondaryTableASArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));
    const secondaryTableSU = opSecondaryTable.filter((e)=> e.providerRoleCode === 'SU' && e.lineNumber == 0).map(e => opSecondaryTableSUArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));
    const secondaryTableBI = opSecondaryTable.filter((e)=> e.providerRoleCode === 'BI' && e.lineNumber == 0).map(e => opSecondaryTableBIArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));
    //const secondaryTableRN = opSecondaryTable.filter((e)=> e.providerRoleCode === 'RN' && e.lineNumber == 0).map(e => opSecondaryTableRNArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));
    //const secondaryTableRF = opSecondaryTable.filter((e)=> e.providerRoleCode === 'RF' && e.lineNumber == 0).map(e => opSecondaryTableRFArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));
    //const secondaryTablePT = opSecondaryTable.filter((e)=> e.providerRoleCode === 'PT' && e.lineNumber == 0).map(e => opSecondaryTablePTArray.push({'providerIDTypeShortDesc': e.providerIDTypeShortDesc,'providerID': e.providerID}));

   // console.log('Other payers:', claimOtherPayersInfo);
    //console.log('OPAdju:', otherPayersAdj);
    //console.log('COB Amout:', cobMonetryAmount);
   // console.log('OPSF:', opSecondaryTableSFArray);
//console.log('Insurance:', otherInsuranceCoverage);
   // console.log('Other Subscriber ',otherSubscriberInfo);
   // console.log('Other Payer: ',opSecondaryTable);
    
    
    //.log('Other payers1:', props.data.enterpriseClaimAux.c837ClaimHdr.c837OtherPayers);
    const [LLAData,setLLAData] = useState({});
    const viewLLA = row => (event) => {
        setLLAData(row);
        setShowLLA(true);
    };
    const ClaimProviderOtherPayerInfoCells = [
        {
            id: 'idtype', numeric: false, disablePadding: true, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'id', numeric: false, disablePadding: true, label: 'ID Number', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'payerID', numeric: false, disablePadding: true, label: 'Payer ID', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'employerIdNumber', numeric: false, disablePadding: true, label: "Employer's Identification Number", enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'claimOfficeNumber', numeric: false, disablePadding: true, label: 'Claim Office Number', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'naicCode', numeric: false, disablePadding: true, label: 'NAIC Code', enableHyperLink: false, fontSize: 12, width: "15%"
        }
    ];
    

    const ClaimLevelAdjustmentsInfoCells = [
        {
            id: 'adjustmentGroupCode', numeric: false, disablePadding: false, label: 'Claim Adjustment Group Code', enableHyperLink: true, fontSize: 12, width: "25%"
        },
        {
            id: 'adjustmentReasonCode', numeric: false, disablePadding: false, label: 'Reason Code', enableHyperLink: false, fontSize: 12, width: "25%"
        },
        {
            id: 'adjustmentReasonAmount', numeric: false, disablePadding: false, label: 'Amount', enableHyperLink: false, fontSize: 12, width: "25%"
        },
        {
            id: 'adjustmentUnitQuantity', numeric: false, disablePadding: false, label: 'Quantity', enableHyperLink: false, fontSize: 12, width: "25%"
        }
    ];

    const ClaimProviderInfoCells = [
        {
            id: 'providerIDTypeShortDesc', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12, width: "50%"
        }
    ];

    const editRow = row => (event) => {
        setAdjustmentsData(true)
        setShowData(row)
      };
    


      const cancelAdjustPage = () => {
        setAdjustmentsData(false)
      }

      const cancelCOBPage = () => {
        props.setBenefitsData(false)
      }
    return (
        <div className='tab-holder CustomExpansion-panel my-3'>
            <div className="tabs-container">
                <div className="tab-header">
                    <h2 className="tab-heading float-left">View Other Insurance</h2>
                    <div className="float-right th-btnGroup">
                        <button color="primary" type="button" className="btn btn-primary" onClick={cancelCOBPage}>Cancel</button>
                    </div>
                </div>
            </div>
            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_subscriber_info">
                    <Typography className={classes.heading}>Other Subscriber Information</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>

                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_subscriber_info_group_policy"
                                className="cust-label"
                                label="Group or Policy #"
                                placeholder=""
                                value={otherSubscriberInfo.policyNumber ? otherSubscriberInfo.policyNumber : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}

                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_subscriber_info_plan_name"
                                className="cust-label"
                                label="Group or Plan Name"
                                placeholder=""
                                value={otherSubscriberInfo.planName ? otherSubscriberInfo.planName : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}

                            />
                        </div>

                    </div>

                    <div className="form-wrapper wrap-form-label">

                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_subscriber_info_entity_qualifier"
                                label="Entity Qualifier"
                                placeholder=""
                                value={otherSubscriberInfo.entityQualifierCode ? otherSubscriberInfo.entityQualifierCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_subscriber_info_ssn"
                                label="SSN"
                                placeholder=""
                                value={otherSubscriberInfo.additionalQualifierCode1 ? otherSubscriberInfo.additionalQualifierCode1 : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_subscriber_info_relationtoindividual"
                                label="Relation to Individual"
                                placeholder=""
                                value={otherSubscriberInfo.relationshipCode ? otherSubscriberInfo.relationshipCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_subscriber_info_claim_filing"
                                label="Claim Filing Code"
                                placeholder=""
                                value={otherSubscriberInfo.claimFilingCode ? otherSubscriberInfo.claimFilingCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="Insurance Type Code"
                                label="Insurance Type Code"
                                placeholder=""
                                value={otherSubscriberInfo.insuranceTypeCode ? otherSubscriberInfo.insuranceTypeCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_subscriber_info_payer_responsibility"
                                label="Payer Responsibility Seq # Code"
                                placeholder=""
                                value={otherSubscriberInfo.payerSequenceCode ? otherSubscriberInfo.payerSequenceCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>


                    </div>
                    <Divider className="mt-4" />
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={additionalOtherSubscriberIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTableSUArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}

                       <TableComponent headCells={ClaimProviderInfoCells} tableData={otherSubscriberSecondaryTable} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>

                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="panelp1a-header11">
                    <Typography className={classes.heading}>  Other Insurance Coverage </Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>

                    <div className="form-wrapper wrap-form-label">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_insurance_cov_certification"
                                label="Benefits Assignment Certification"
                                placeholder=""
                                value={otherInsuranceCoverage.benefitCertificationCode ? otherInsuranceCoverage.benefitCertificationCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_insurance_cov_release"
                                label="Release of Information"
                                placeholder=""
                                value={otherInsuranceCoverage.informationReleaseCode ? otherInsuranceCoverage.informationReleaseCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_insurance_cov_source_code"
                                label="Patient Source Code"
                                placeholder=""
                                value={otherInsuranceCoverage.patientSignatureSourceCode ? otherInsuranceCoverage.patientSignatureSourceCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                    </div>


                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="panelp1a-header11">
                    <Typography className={classes.heading}> Outpatient Adjudication Information</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    
                        <div className="form-wrapper">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_reimbursment"
                                    label="Reimbursement Rate"
                                    placeholder=""
                                    value={otherPayerMedicareInfo.outPatientReimburseRate ? otherPayerMedicareInfo.outPatientReimburseRate : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
									disabled
									id="cob_outpatient_hcpcs_amt"
									label="HCPCS Payable Amount"
									placeholder=""
									//value={otherPayersAdj.outPatientHCPCSAmount ?setZeroAtdecimalPoint( otherPayersAdj.outPatientHCPCSAmount) : ""}
									value={otherPayerMedicareInfo.outPatientHCPCSAmount ? otherPayerMedicareInfo.outPatientHCPCSAmount.toFixed(2) : ""}
									InputLabelProps={{
										shrink: true,
									}}
									InputProps={{
										startAdornment: <InputAdornment position="start">$</InputAdornment>,
									}}
								/>
                            </div>
                        </div>
                        <div className="form-wrapper">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_remark1"
                                    label="Remark Code 1"
                                    placeholder=""
                                     value={otherPayerMedicareInfo.outPatientRemarkCode1 ? otherPayerMedicareInfo.outPatientRemarkCode1 : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_remark2"
                                    label="Remark Code 2"
                                    placeholder=""
                                    value={otherPayerMedicareInfo.outPatientRemarkCode2 ? otherPayerMedicareInfo.outPatientRemarkCode2 : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_remark3"
                                    label="Remark Code 3"
                                    placeholder=""
                                    value={otherPayerMedicareInfo.outPatientRemarkCode3 ? otherPayerMedicareInfo.outPatientRemarkCode3 : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_remark4"
                                    label="Remark Code 4"
                                    placeholder=""
                                    value={otherPayerMedicareInfo.outPatientRemarkCode4 ? otherPayerMedicareInfo.outPatientRemarkCode4 : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_remark5"
                                    label="Remark Code 5"
                                    placeholder=""
                                    value={otherPayerMedicareInfo.outPatientRemarkCode5 ? otherPayerMedicareInfo.outPatientRemarkCode5 : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                        </div>
                        <div className="form-wrapper wrap-form-label">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_esrd_amount"
                                    label="ESRD Paid Amount"
                                    placeholder=""
                                    value={otherPayerMedicareInfo.outPatientESRDAmount ? otherPayerMedicareInfo.outPatientESRDAmount.toFixed(2) : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_outpatient_prof_component"
                                    label="Professional Component Amount"
                                    placeholder=""
                                    //value={medicareOPInfo.professionalComp ? setZeroAtdecimalPoint(medicareOPInfo.professionalComp) : ""}
									 value={otherPayerMedicareInfo.outPatientProfessionalAmount ? otherPayerMedicareInfo.outPatientProfessionalAmount.toFixed(2) : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>
                        </div>

                   
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="panelp1a-header11">
                    <Typography className={classes.heading}>Other Payer</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>

                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_payer"
                                label="Payer/Carrier ID Qualifier"
                                placeholder=""
                                value={claimOtherPayersInfo.otherPayerQualifierCode ? claimOtherPayersInfo.otherPayerQualifierCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}

                            />
                        </div>

                    </div>

                    <div className="form-wrapper">

                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_entity_qualifier"
                                label="Entity Qualifier"
                                placeholder=""
                                value={claimOtherPayersInfo.entityTypeCode ? claimOtherPayersInfo.entityTypeCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>

                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_id"
                                label="ID"
                                placeholder=""
                                value={claimOtherPayersInfo.otherPayerID ? claimOtherPayersInfo.otherPayerID : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_idtype"
                                label="ID Type"
                                placeholder=""
                                value={claimOtherPayersInfo.otherPayerQualifierCode ? claimOtherPayersInfo.otherPayerQualifierCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md input-md-1-col">
                            <TextField
                                disabled
                                id="cob_other_payer_address1"
                                label="Address 1"
                                placeholder=""
                                value={claimOtherPayersInfo.addressLine1 ? claimOtherPayersInfo.addressLine1 : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md input-md-1-col">
                            <TextField
                                disabled
                                id="cob_other_payer_address2"
                                label="Address 2"
                                placeholder=""
                                value={claimOtherPayersInfo.addressLine2 ? claimOtherPayersInfo.addressLine2 : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_city"
                                label="City"
                                placeholder=""
                                value={claimOtherPayersInfo.cityName ? claimOtherPayersInfo.cityName : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_state"
                                label="State"
                                placeholder=""
                                value={claimOtherPayersInfo.stateCode ? claimOtherPayersInfo.stateCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <div className="cndt-row">

                                <div className="cndt-col-6">
                                <TextField
                                    disabled
                                    id="cob_other_payer_zip"
                                    label="Zip & Extension"
                                    placeholder=""
                                    value={claimOtherPayersInfo.zipCode ? claimOtherPayersInfo.zipCode.toString().substring(0,5) : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                                </div>

                                <div className="cndt-col-6">
                                <TextField
                                    disabled
                                    id="cob_other_payer_ext"
                                    placeholder=""
                                    value={claimOtherPayersInfo.zipCode ? claimOtherPayersInfo.zipCode.toString().substring(5) : ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                                </div>

                            </div>
                            
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_country"
                                label="Country"
                                placeholder=""
                                value={claimOtherPayersInfo.countryCode ? claimOtherPayersInfo.countryCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_subdivision"
                                label="Subdivision Code"
                                placeholder=""
                                value={otherPayersSubDivisionCode.countrySubDivisionCode ? otherPayersSubDivisionCode.countrySubDivisionCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        </div>
                        <div className="form-wrapper">
                        {/* <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_adjudication"
                                label="Adjudication Date"
                                placeholder=""
                                value={claimOtherPayersInfo.paidDate ? claimOtherPayersInfo.paidDate : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div> */}
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="cob_other_payer_adjudication"
                                                label="Adjudication Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={claimOtherPayersInfo.paidDate ? moment(claimOtherPayersInfo.paidDate).format('MM/DD/YYYY') : null}

                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                </MuiPickersUtilsProvider>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_numbertype"
                                label="Number Type"
                                placeholder=""
                                value={claimOtherPayersInfo.referralQualifierCode1 ? claimOtherPayersInfo.referralQualifierCode1 : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_sa"
                                label="SA / Referral #"
                                placeholder=""
                                value={claimOtherPayersInfo.referralID1 ? claimOtherPayersInfo.referralID1 : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        </div>
                        <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <div className="MuiFormControl-root MuiTextField-root">
                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Payer Claim Adjustment:</label>
                            </div>
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    disabled
                                    row
                                    aria-label="eftactive"
                                    name="HideInactiveProviders"
                                    value={claimOtherPayersInfo.adjustmentIndicatorCode1 ? claimOtherPayersInfo.adjustmentIndicatorCode1 : "FALSE"}
                                >
                                    <FormControlLabel
                                        value="TRUE"
                                        control={<Radio color="primary" />}
                                        label="Yes"
                                    />
                                    <FormControlLabel
                                        value="FALSE"
                                        control={<Radio color="primary" />}
                                        label="No"
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_authorization_no"
                                label="Authorization Number"
                                placeholder=""
                                value={claimOtherPayersInfo.referralID1 ? claimOtherPayersInfo.referralID1 : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_control_no"
                                label="Claim Control Number"
                                placeholder=""
                                value={claimOtherPayersInfo.claimControlNumber ? claimOtherPayersInfo.claimControlNumber : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>


                    </div>
                    <Divider className="mt-4" />
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderOtherPayerInfoCells} tableData={additionalOtherPayerInfoIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderOtherPayerInfoCells} tableData={otherPayerTable} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="panelp1a-header11">
                    <Typography className={classes.heading}>COB Monetary Amounts</Typography>
                </ExpansionPanelSummary>


                <ExpansionPanelDetails>

                    <div className="form-wrapper wrap-form-label">

                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_monetary_approved_amount"
                                    label="Approved Amount"
                                    placeholder=""
                                    value={cobMonetryAmount.approvedAmount ? cobMonetryAmount.approvedAmount.toFixed(2) : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>

                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_monetary_patient_responsibility"
                                    label="Patient Responsibility Amount"
                                    placeholder=""
                                    value={cobMonetryAmount.patientResponsibilityAmount ? cobMonetryAmount.patientResponsibilityAmount : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_monetary_non_covered"
                                    label="Total Non-Covered Amount"
                                    placeholder=""
                                    value={cobMonetryAmount.nonCoveredAmount ? cobMonetryAmount.nonCoveredAmount.toFixed(2) : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_monetary_covered"
                                    label="Covered Amount"
                                    placeholder=""
                                    value={cobMonetryAmount.coveredAmount ? cobMonetryAmount.coveredAmount.toFixed(2) : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_monetary_discount"
                                    label="Discount Amount"
                                    placeholder=""
                                    value={cobMonetryAmount.discountAmount ? cobMonetryAmount.discountAmount.toFixed(2) : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="cob_monetary_liability"
                                    label="Remaining Patient Liability Amount"
                                    placeholder=""
                                    value={cobMonetryAmount.remainingPatientLiabilityAmount ? cobMonetryAmount.remainingPatientLiabilityAmount.toFixed(2) : "0.00"}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                    InputProps={{
                                        startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                    }}
                                />
                            </div>
                        </div>

                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="panelp1a-header11">
                    <Typography className={classes.heading}>Claim Level Adjustments</Typography>
                </ExpansionPanelSummary>

                <ExpansionPanelDetails>
                    
                        <div className="tabs-container pb-2 mt-3">
                            {/* <TableComponent headCells={ClaimLevelAdjustmentsInfoCells} tableData={serviceLineAdjustmentVOList} onTableRowClick={editRow} defaultSortColumn="id" /> */}
                            <TableComponent headCells={ClaimLevelAdjustmentsInfoCells} tableData={claimLevelAdjustmentTable.map((o)=>({...o,adjustmentReasonAmount:'$'+o.adjustmentReasonAmount.toFixed(2),adjustmentUnitQuantity: o.adjustmentUnitQuantity.toFixed(1)}))}  onTableRowClick={editRow} defaultSortColumn="id" />
                        </div>
                        {adjustmentsData ? <>
                            <div className="tabs-container">
                                <div className="tab-header mb-3">
                                    <h2 className="tab-heading float-left">View Claim Level Adjustments</h2>
                                    <div className="float-right th-btnGroup">
                                        <button color="primary" type="button" className="btn btn-primary" onClick={cancelAdjustPage}>Cancel</button>
                                    </div>
                                </div>
                               
                                    <div className="tab-body-bordered mt-0">


                                        <div className="form-wrapper wrap-form-label">

                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_group_code"
                                                    label="Claim Adjustment Group Code"
                                                    placeholder=""
                                                    value={showData.adjustmentGroupCode ? showData.adjustmentGroupCode : null}
                                                    //value={LLAData.adjustmentGroupCode ? LLAData.adjustmentGroupCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                        required: true
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_reason_code"
                                                    label="Reason Code"
                                                    placeholder=""
                                                    //value={showData.adjustmentReasonCode ? showData.adjustmentReasonCode : "0.00"}
                                                    value={showData.sequenceNumber === 1 && showData.adjustmentReasonCode ? showData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                        required: true
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_amount"
                                                    label="Amount"
                                                    placeholder=""
                                                    //value={showData.adjustmentReasonAmount ? showData.adjustmentReasonAmount.toFixed(2) : "0.00"}
                                                    value={showData.sequenceNumber === 1 && showData.adjustmentReasonAmount ? showData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                        required: true
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start"></InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_quantity"
                                                    label="Quantity"
                                                    placeholder=""
                                                   // value={showData.adjustmentUnitQuantity ? showData.adjustmentUnitQuantity.toFixed(1) : "0.0"}
                                                    value={showData.sequenceNumber === 1 && showData.adjustmentUnitQuantity ? showData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>

                                        </div>

                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_reason_code2"
                                                    label="Reason Code 2"
                                                    placeholder=""
                                                    //value={showData.reason2 ? showData.reason2 : "0.00"}
                                                    value={showData.sequenceNumber === 2 && showData.adjustmentReasonCode ? showData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_amount2"
                                                    label="Amount 2"
                                                    placeholder=""
                                                    //value={showData.amount2 ? showData.amount2 : "0.00"}
                                                    value={ showData.sequenceNumber === 2 && showData.adjustmentReasonAmount ? showData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start"></InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_quantity2"
                                                    label="Quantity 2"
                                                    placeholder=""
                                                    //value={showData.quantity2 ? showData.quantity2 : "0.00"}
                                                    value={showData.sequenceNumber === 2 && showData.adjustmentUnitQuantity ? showData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_reason_code3"
                                                    label="Reason Code 3"
                                                    placeholder=""
                                                    //value={showData.reason3 ? showData.reason3 : "0.00"}
                                                    value={showData.sequenceNumber === 3 && showData.adjustmentReasonCode ? showData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_amount3"
                                                    label="Amount 3"
                                                    placeholder=""
                                                    //value={showData.amount3 ? showData.amount3 : "0.00"}
                                                    value={ showData.sequenceNumber === 3 && showData.adjustmentReasonAmount ? showData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start"></InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_quantity3"
                                                    label="Quantity 3"
                                                    placeholder=""
                                                    //value={showData.quantity3 ? showData.quantity3 : "0.00"}
                                                    value={showData.sequenceNumber === 3 && showData.adjustmentUnitQuantity ? showData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_reason_code4"
                                                    label="Reason Code 4"
                                                    placeholder=""
                                                    //value={showData.reason4 ? showData.reason4 : "0.00"}
                                                    value={showData.sequenceNumber === 4 && showData.adjustmentReasonCode ? showData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_amount4"
                                                    label="Amount 4"
                                                    placeholder=""
                                                    //value={showData.amount4 ? showData.amount4 : "0.00"}
                                                    value={ showData.sequenceNumber === 4 && showData.adjustmentReasonAmount ? showData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start"></InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_quantity4"
                                                    label="Quantity 4"
                                                    placeholder=""
                                                    //value={showData.quantity4 ? showData.quantity4 : "0.00"}
                                                    value={showData.sequenceNumber === 4  && showData.adjustmentUnitQuantity ? showData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_reason_code5"
                                                    label="Reason Code 5"
                                                    placeholder=""
                                                    //value={showData.reason5 ? showData.reason5 : "0.00"}
                                                    value={showData.sequenceNumber === 5 && showData.adjustmentReasonCode ? showData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_amount5"
                                                    label="Amount 5"
                                                    placeholder=""
                                                    //value={showData.amount5 ? showData.amount5 : "0.00"}
                                                    value={ showData.sequenceNumber === 5 && showData.adjustmentReasonAmount ? showData.adjustmentReasonAmount : ""}

                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start"></InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_quantity5"
                                                    label="Quantity 5"
                                                    placeholder=""
                                                    //value={showData.quantity5 ? showData.quantity5 : "0.00"}
                                                    value={showData.sequenceNumber === 5 && showData.adjustmentUnitQuantity ? showData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                        <div className="form-wrapper">
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_reason_code6"
                                                    label="Reason Code 6"
                                                    placeholder=""
                                                    //value={showData.reason6 ? showData.reason6 : "0.00"}
                                                    value={showData.sequenceNumber === 6 && showData.adjustmentReasonCode ? showData.adjustmentReasonCode : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_amount6"
                                                    label="Amount 6"
                                                    placeholder=""
                                                    //value={showData.amount6 ? showData.amount6 : "0.00"}
                                                    value={ showData.sequenceNumber === 6 && showData.adjustmentReasonAmount ? showData.adjustmentReasonAmount : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                    InputProps={{
                                                        startAdornment: <InputAdornment position="start"></InputAdornment>,
                                                    }}
                                                />
                                            </div>
                                            <div className="mui-custom-form input-md">
                                                <TextField
                                                    disabled
                                                    id="cob_claim_adjustment_quantity6"
                                                    label="Quantity 6"
                                                    placeholder=""
                                                    //value={showData.quantity6 ? showData.quantity6 : "0.00"}
                                                    value={showData.sequenceNumber === 6 && showData.adjustmentUnitQuantity ? showData.adjustmentUnitQuantity : ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>
                                    </div>

                            </div>
                        </>
                            : null}
                    
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_payer_patient_info">
                    <Typography className={classes.heading}>Other Payer Patient Information</Typography>
                </ExpansionPanelSummary>

                <ExpansionPanelDetails>
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_patient_info_id"
                                label="ID"
                                placeholder=""
                                value={otherPayerPatientInfo.patientMemberID ? otherPayerPatientInfo.patientMemberID : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}

                            />
                        </div>
                    </div>
                    <Divider className="mt-4" />
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerPatientIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTable} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_payer_rendering">
                    <Typography className={classes.heading}>Other Payer Rendering Provider</Typography>
                </ExpansionPanelSummary>

                <ExpansionPanelDetails>
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_rendering_entity_qual"
                                label="Entity Qualifier"
                                placeholder=""
                                 value={otherPayerRenderingInfo.renderingProviderEntityTypeCode ? otherPayerRenderingInfo.renderingProviderEntityTypeCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}

                            />
                        </div>
                    </div>
                    <Divider className="mt-4" />
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerRenderingIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTable} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_payer_service_facility">
                    <Typography className={classes.heading}>Other Payer Service Facility Location Information</Typography>
                </ExpansionPanelSummary>

                <ExpansionPanelDetails>

                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerServFaciLocIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTableSFArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_payer_refering">
                    <Typography className={classes.heading}>Other Payer Referring Provider </Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_refering_entity_qual"
                                label="Entity Qualifier"
                                placeholder=""
                                 value={otherPayerReferingInfo.referringProviderEntityTypeCode1 ? otherPayerReferingInfo.referringProviderEntityTypeCode1 : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                    </div>
                    <Divider className="mt-4" />
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerReferringIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTable} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_payer_primary">
                    <Typography className={classes.heading}>Other Payer Primary Care Provider</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerPrimaryCareProviderIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTablePCArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="cob_other_payer_assistant_surgeon"
                    id="panelp1a-header11">
                    <Typography className={classes.heading}>Other Payer Assistant Surgeon Provider</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_assistant_surgeon_entity_qual"
                                label="Entity Qualifier"
                                placeholder=""
                                value={otherPayerAssistantSurgeonProviderInfo.asstSurgeonEntityTypeCode ? otherPayerAssistantSurgeonProviderInfo.asstSurgeonEntityTypeCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                    </div>
                    <Divider className="mt-4" />
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerAssistantSurgeonProviderIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTableASArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_payer_supervising">
                    <Typography className={classes.heading}>Other Payer Supervising Provider Information</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerSupervisingProviderIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTableSUArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>

            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                <ExpansionPanelSummary
                    expandIcon={<ExpandMoreIcon />}
                    aria-controls="panelp1a-content11"
                    id="cob_other_payer_billing">
                    <Typography className={classes.heading}>Other Payer Billing Provider</Typography>
                </ExpansionPanelSummary>
                <ExpansionPanelDetails>
                    <div className="form-wrapper">
                        <div className="mui-custom-form input-md">
                            <TextField
                                disabled
                                id="cob_other_payer_billing_entity_qual"
                                label="Entity Qualifier"
                                placeholder=""
                                 value={otherPayerBillingProviderInfo.billingProviderEntityTypeCode ? otherPayerBillingProviderInfo.billingProviderEntityTypeCode : ""}
                                InputLabelProps={{
                                    shrink: true,
                                }}
                            />
                        </div>
                    </div>
                    <Divider className="mt-4" />
                    <div className="tabs-container pb-2">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left"> Secondary IDs </h2>
                        </div>
                        {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={otherPayerBillingProviderIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                        <TableComponent headCells={ClaimProviderInfoCells} tableData={opSecondaryTableBIArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                    </div>
                </ExpansionPanelDetails>
            </ExpansionPanel>


        </div>
    );
}
export default withRouter(ClaimOtherDentalCoordinateOfBenefits);