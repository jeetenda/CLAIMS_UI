import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import Checkbox from '@material-ui/core/Checkbox';
import * as ClaimsCorrectionConstants from '../../../SharedModules/Messages/ErrorMsgConstants';


export default function ClaimCorrectionLocationSearchForm(props) {

    const locationDropDown = props.locationDropdownData && props.locationDropdownData.searchResultsValues && props.locationDropdownData.searchResultsValues.map(each => (
        <MenuItem selected key={each.locationCode} value={each.locationCode}>{each.locationCode}</MenuItem>
    ))

    const claimTypeDropDown = props.claimTypeDropDown && props.claimTypeDropDown['Claims#C_TY_CD'] && props.claimTypeDropDown['Claims#C_TY_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>))

	
	return (
        <form autoComplete="off">

        <div className="tab-body mt-2">
            <div className="form-wrapper">
                <div className="mui-custom-form with-select input-md">
                    <TextField
                        id="location_code_correction_tab"
                        select
                        label="Location Code"
                        value={props.values.locationCode}
                        inputProps={{ maxLength: 2 }}
                        onChange={props.handleChanges('locationCode')}
                        placeholder="Please Select One"
                        helperText={props.errors.showLocationCodeError ? ClaimsCorrectionConstants.LOCATION_CODE_ERROR : null}
                        InputLabelProps={{
                            shrink: true,
                            required: true
                        }}
                        error={props.errors.showLocationCodeError ? ClaimsCorrectionConstants.LOCATION_CODE_ERROR : null}
                        data-test = "location-code"
                    >
                        <MenuItem value='-1'>Please Select One</MenuItem>
                        {locationDropDown}

                    </TextField>
                </div>
                <div className="mui-custom-form with-select input-md">
                    <TextField
                        id="location_type_code_correction_tab"
                        select
                        label="Claim Type"
                        value={props.values.locationType}
                        inputProps={{ maxLength: 2 }}
                        onChange={props.handleChanges('locationType')}
                        placeholder="Please Select One"
                        // helperText={props.errors.showMediaSourceError ? ClaimsCorrectionConstants.Media_Source_Error : null}
                        InputLabelProps={{
                            shrink: true,
                        }}
                    // error={props.errors.showMediaSourceError ? ClaimsCorrectionConstants.Media_Source_Error : null}
                        data-test = 'claim-type'
                    >
                        <MenuItem value='-1'>Please Select One</MenuItem>
                      {claimTypeDropDown}

                    </TextField>
                </div>
                <div className="mui-custom-form ml-3 mr-3 mt-2">
                    <div className="sub-radio mt-4">
                        <label className="MuiFormControlLabel-root inline-radio-label float-left">
                            <Checkbox
                                type="checkbox"
                                checked={props.values.restrictLocationUserID}
                                onChange={props.handleChanges('restrictLocationUserID')}
                                value="restrictLocationUserID"
                                id="voidId"
                                data-test = 'restrict-location-user-id'
                            />
                            <span className="MuiFormControlLabel-label">Restrict Location to User ID</span>
                        </label>
                        <div className="clearfix" />
                    </div>
                </div>
            </div>
        </div>
        <div className="tab-header pt-0">
            <div className="float-right th-btnGroup mr-3 mb-2">
                <Button
                    title="Search"
                    variant="outlined"
                    color="primary"
                    className="btn btn-primary"
                    onClick={props.searchCheck}
                    disabled={props.privileges && !props.privileges.search? 'disabled':''}
                    data-test='search-button'
                >
                    {' '}
                    <i className="fa fa-search" />
                    Search
  {' '}

                </Button>
                <Button
                    title="Reset"
                    variant="outlined"
                    color="primary"
                    className="btn btn-reset"
                    onClick={props.resetTable}
                    data-test='reset-button'
                >
                    {' '}
                    <i className="fa fa-undo" />
                    Reset
  {' '}

                </Button>
            </div>
        </div>
        <div className="clearfix" />
    </form>
  
			);
}
