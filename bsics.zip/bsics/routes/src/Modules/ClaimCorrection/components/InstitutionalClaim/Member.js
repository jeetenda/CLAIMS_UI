import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import moment from 'moment';
import AvailableEligibilitySpans from '../../../ClaimsInquiry/components/mainTab/AvailableEligibilitySpans';
import TableComponent from '../../../../SharedModules/Table/Table';
import * as ErrorConst from "../../../../SharedModules/Messages/ErrorMsgConstants";

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));
const claimAvailableBenefitPlansListCells = [
    {
        id: 'beginDate', numeric: false, disablePadding: true, label: 'Begin Date', isDate: true, enableHyperLink: false, fontSize: 12, width: '150px'
    },
    {
        id: 'endDate', numeric: false, disablePadding: true, label: 'End Date', isDate: true, enableHyperLink: false, fontSize: 12, width: '150px'
    },
    {
        id: 'benefitPlanID', numeric: false, disablePadding: true, label: 'Plan ID', enableHyperLink: true, fontSize: 12
    }
];

const headCells = [
    {
        id: 'beginDate', numeric: false, disablePadding: true, label: 'Begin Date', isDate: true, enableHyperLink: false, fontSize: 12, width: '150px'
    },
    {
        id: 'endDate', numeric: false, disablePadding: true, label: 'End Date', isDate: true, enableHyperLink: false, fontSize: 12, width: '150px'
    },
    {
        id: 'coeCodeDesc', numeric: false, disablePadding: true, label: 'COE', enableHyperLink: false, fontSize: 12
    }
];

function Member(props) {
    const classes = useStyles();
    const data = props.data;
    const getAge = (d) => {       
        return `${Math.floor(d/12)}yrs-${d%12}mons`;       
    };
    const toBP = row => (event) => {
        if(event.target.text == row.benefitPlanID){
            window.open(`/SearchBenefitPlan?benefitPlanID=${row.benefitPlanID}`, "_blank");
        }        
    };
    const getTableData = (data) => {
        if (data && data.length) {
          let tData = JSON.stringify(data); 
          tData = JSON.parse(tData);     
          tData.map((each,index) => {
            each.index = index;
            each.coeCodeDesc = each.coeCodeDesc ? each.coeCodeDesc : each.coeCode;
          }); 
          return tData;           
        }else{
          return [];
        }
    }
    return (
        <div className="pos-relative">
            <div className="tabs-container custom-panel">
                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="member_expansion_panel"
                            id="member_expansion_panel_id">
                            <Typography className={classes.heading}>Member</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <div className="set-form-wrapper mt-3">
                            <div className="form-wrapper p-0">
                                <div className="mui-custom-form input-md">                                   
                                    <div className="cndt-label pt-1 mb-2">Member ID : </div>                                   
                                    <a href={`/MemberSummaryInquiry?memberSysID=${data.memberSystemID?data.memberSystemID:""}&lineOfBusiness=${data.lobCode?data.lobCode:""}`} target="_blank"><span >{data.claimMember&&data.claimMember.altMemberID?data.claimMember.altMemberID:""}</span></a>
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="sub_mem_id_member"
                                        label="Sub Member ID"
                                        placeholder=""
                                        value={data.claimMember&&data.claimMember.submittedMemberID?data.claimMember.submittedMemberID:""}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, "claimMember": { ...data.claimMember, "submittedMemberID": e.target.value } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 15 }}
                                    />
                                </div>
                            </div>
                            <div className="form-wrapper p-0">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="last_name_member"
                                        label="Last Name"
                                        placeholder=""
                            value={data.claimMember && data.claimMember.memberName && data.claimMember.memberName.lastName ? data.claimMember.memberName.lastName : ""}
                            onChange={(e) => { props.setClaimEntryData({ ...data, "claimMember": { ...data.claimMember, "memberName": { ...data.claimMember.memberName, "lastName": e.target.value } } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 35 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="first_name_member"
                                        label="First Name"
                                        placeholder=""
                            value={data.claimMember && data.claimMember.memberName && data.claimMember.memberName.firstName ? data.claimMember.memberName.firstName : ""}
                            onChange={(e) => { props.setClaimEntryData({ ...data, "claimMember": { ...data.claimMember, "memberName": { ...data.claimMember.memberName, "firstName": e.target.value } } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 25 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="mi_member"
                                        label="MI"
                                        placeholder=""
                            value={data.claimMember && data.claimMember.memberName && data.claimMember.memberName.middleName ? data.claimMember.memberName.middleName : ""}
                            onChange={(e) => { props.setClaimEntryData({ ...data, "claimMember": { ...data.claimMember, "memberName": { ...data.claimMember.memberName, "middleName": e.target.value } } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                            inputProps={{ maxLength: 25 }}
                                    />
                                </div>
                               <div className="mui-custom-form input-md">
                        <TextField
                            id="suffix_member"
                            label="Suffix"
                            placeholder=""
                            value={data.claimMember && data.claimMember.memberName && data.claimMember.memberName.suffixName ? data.claimMember.memberName.suffixName : ""}
                            onChange={(e) => { props.setClaimEntryData({ ...data, "claimMember": { ...data.claimMember, "memberName": { ...data.claimMember.memberName, "suffixName": e.target.value } } }); }}
                            InputLabelProps={{
                                shrink: true,
                            }}
                            inputProps={{ maxLength: 10 }}
                        />
                    </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="dob_member"
                                        label="Date of Birth"
                                        placeholder=""
                                        value={props.dates.dateOfBitrh ? props.dates.dateOfBitrh : null}
                                        onChange={(e)=>{props.setInputDates({...props.dates,"dateOfBitrh":e.target.value});}}
                                        helperText={props.errors.dobDateErr ? ErrorConst.MEMBER_DATE_ERR : null}
                                        error={props.errors.dobDateErr}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 10 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="age_member"
                                        label="Age"
                                        placeholder=""
                                        value={data.claimMember&&data.claimMember.age?getAge(data.claimMember.age):""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 5 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="gender_member"
                                        label="Gender"
                                        placeholder=""
                                        value={data.claimMember&&data.claimMember.sex ? data.claimMember.sex : ""}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, "claimMember": { ...data.claimMember, "sex": e.target.value } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 1 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        id="memCoeCodeDesc_member"
                                        label="COE"
                                        disabled
                                        placeholder=""
                                        value={data.claimMember&&data.claimMember.coeCodeDesc?data.claimMember.coeCodeDesc:""}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, "claimMember": { ...data.claimMember, "coeCodeDesc": e.target.value } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 4 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="mem_presumptive_eligibility"
                                        label="Presumptive Eligibility"
                                        placeholder=""
                                        value={data.enterpriseClaimAux&&data.enterpriseClaimAux.peIndicator?data.enterpriseClaimAux.peIndicator:""}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, "enterpriseClaimAux": { ...data.enterpriseClaimAux, "peIndicator": e.target.value } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 1 }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="mem_newly_not_newly"
                                        label="Newly/Not Newly"
                                        placeholder=""
                                        value={data.enterpriseClaimAux&&data.enterpriseClaimAux.nnnCode?data.enterpriseClaimAux.nnnCode:""}
                                        onChange={(e) => { props.setClaimEntryData({ ...data, "enterpriseClaimAux": { ...data.enterpriseClaimAux, "nnnCode": e.target.value } }); }}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        inputProps={{ maxLength: 2 }}
                                    />
                                </div>
                            </div>
                            </div>
                            <div className="tabs-holder mt-1">
                                <div className="tab-header">
                                    <h2 className="tab-heading float-left"> Available Eligibility Spans </h2>
                                    </div>
                                <div className="clean-table tbl-no-border">
                                    <TableComponent headCells={headCells} tableData={getTableData(data.claimMember&&data.claimMember.availableEligibilitySpan && data.claimMember.availableEligibilitySpan.length > 0 ? data.claimMember.availableEligibilitySpan : data.claimMember&&data.claimMember.applicableEligibilitySpans && data.claimMember.applicableEligibilitySpans.length > 0 ? data.claimMember.applicableEligibilitySpans : [])} onTableRowClick={() => { return false; }} defaultSortColumn="beginDate" />
                                </div>
                            </div>

                            <div className="tabs-holder mt-3">
                                <div className="tab-header">
                                    <h2 className="tab-heading float-left"> Available Benefit Plans </h2>
                                    <div className="clearfix" />
                                </div>
                                <div className="clean-table tbl-no-border">
                                    <TableComponent headCells={claimAvailableBenefitPlansListCells} tableData={data.claimMember&&data.claimMember.availableBenefitPlan ? data.claimMember.availableBenefitPlan : []} onTableRowClick={toBP} defaultSortColumn="beginDate" />
                                </div>
                            </div>

                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>
            </div>
        </div>
    )
}

export default Member;