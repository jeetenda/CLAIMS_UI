import React, { useState, useEffect } from 'react';
import List from '@material-ui/core/List';
import ListItem from '@material-ui/core/ListItem';
import ListItemText from '@material-ui/core/ListItemText';

import { Button } from 'react-bootstrap';


function ExceptionView(props) {

    const [exceptionList, setExceptionList] = useState([]);
    const [claimEntryData, setClaimEntryData] = useState({});
    const [showDetails, setShowDetails] = useState(false);
    const [lineNum, setShowLineNum] = useState();
    const [showExceptionCode, setShowExceptionCode] = useState();
    const [showStatusCode, setShowStatusCode] = useState();
    const [readResolution, setReadResolution] = useState(false);

    const handleChanges = (index) => event => {
        let exceptionData = [];
        exceptionData = exceptionList,
            exceptionData[index].statusCode = event.target.value;
        setExceptionList([...exceptionData]);
    };

    useEffect(() => {
        setExceptionList(props.value.claimAdjudicationEdit);
        setClaimEntryData(props.value);
    }, [props.updateException]);

    return (

        <div className="tab-body mb-4">
            <div class="custom-panel mb-2"><div class="panel-header"><span>Claim</span></div></div>
            {/* <div className="tab-header">
                <h2 className="tab-heading float-left"> Claim </h2>
            </div> */}
            <div className="data-panel">
                <div className="pb-1">
                    <div className="tcn-title pb-1"> TCN: </div>
                    <div className="tcn-no">{claimEntryData && claimEntryData.tcn ? claimEntryData.tcn : ''}</div>
                </div>
                <div className="custom-hr my-2 pb-1" />
                <div className="excp-title pt-1"> Exceptions: </div>
                <div className="cnv-title pb-2"> Convergence Point </div>
                <div className="d-table mb-3">
                    <ul className="d-column">
                        <li className="ex-li-hd">LI</li>
                        <li className="ex-code-hd">Code</li>
                        <li className="ex-status-hd">Status</li>
                    </ul>
                    <div className="rec-scroll">
                        {exceptionList.map((exception, Index) => (<ul className="d-row">
                            <li className="ex-li-lst">{exception.lineNumber}</li>
                            <li className="ex-code-lst"><Button title={exception.shortDescription} variant="outlined" color="primary" className="btn view-more-btn p-0 button-underline" onClick={() => { setShowDetails(true), setShowLineNum(exception.lineNumber), setShowExceptionCode(exception.exceptionCode), setReadResolution(false); }}>
                                {exception.exceptionCode}</Button></li>
                            <li className="ex-status-lst">
                                <input
                                    id={exception.statusCode}
                                    type="text"
                                    className="txtbox-stat"
                                    value={exception.statusCode}
                                    onChange={handleChanges(Index)}
                                /></li>
                        </ul>))}
                    </div>
                </div>
                {/* table end */}

                {showDetails === true ? (<div>
                    <div className="tab-body mt-3">
                        <div className="text-right p-2 data-panel-title view-more">
                            <Button title="Close" variant="outlined" color="primary" className="btn view-more-btn p-0" onClick={() => setShowDetails(false)}>
                                Close
                                        </Button>
                        </div>
                        {exceptionList.map(exception => (<div>
                            {exception.lineNumber === lineNum && exception.exceptionCode === showExceptionCode ? (<div className="data-panel mt-2">
                                <div className="pb-1">
                                    <div className="tcn-title pb-1"> Exc Code: {exception.exceptionCode}</div>
                                </div>
                                <div className="pb-1">
                                    <div className="tcn-title pb-1"> Exc Desc: {exception.shortDescription ? exception.shortDescription : exception.statusDesc}  </div>
                                </div>
                                {(exception.forceApprovalCode === "1" || exception.forceDenyCode === "1") ? (<div className="pb-1">
                                    <div className="tcn-title pb-1"> User ID: {exception.clerkId} </div>
                                </div>) : null}
                                {(exception.forceApprovalCode === "1" || exception.forceDenyCode === "1") ? (<div className="pb-1">
                                    <div className="tcn-title pb-1"> User Name: {exception.userName} </div>
                                </div>) : null}

                                <div className="pb-1">
                                    <div className="tcn-title pb-1"> Param Nbr in Error: {exception.listParameterNumber} </div>
                                </div>
                                <div className="pb-1">
                                    <Button title="Resolution Text" variant="outlined" color="primary" className="btn view-more-btn p-0 btn-underln" onClick={() => { setReadResolution(true) }}>
                                        Resolution Text
                                    </Button>
                                    {readResolution === true ? (<div className="tcn-title pb-1">{exception.resolutionText} </div>) : null}
                                </div>
                            </div>) : null}
                        </div>
                        ))}
                    </div>
                </div>) : null}
                <div className="text-right p-2 data-panel-title view-more">
                    <Button title="Validate" variant="outlined" color="primary" className="btn btn-ic btn-validate" onClick={props.correctClaim}>
                        Validate
                                </Button>
                </div>
            </div>
        </div>
    )
}

export default ExceptionView;