import React from "react";
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import TextField from '@material-ui/core/TextField';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import FormGroup from '@material-ui/core/FormGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import Checkbox from '@material-ui/core/Checkbox';
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import { Divider } from "@material-ui/core";
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import * as ErrorConst from '../../../../SharedModules/Messages/ErrorMsgConstants';
import CoverageAndAdmission from './Coverage&Admission';
import InputAdornment from "@material-ui/core/InputAdornment";


const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

function CoverageAdmissionMain(props) {
    const classes = useStyles();
    const data = props.data;
    return (
        <div className="pos-relative">
            <div className="tabs-container custom-panel">
                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="visit-header3244"
                            id="visit-header3244">
                            <Typography className={classes.heading}>Coverage &amp; Admission</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <div className="set-form-wrapper mt-2">
                                <div className="form-wrapper form-3-column p-0">
                                    <div className="mui-custom-form input-md wdth17">
                                        <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Other Insurance Coverage</label>
                                        </div>
                                        <div className="sub-radio mt-0">
                                            <RadioGroup
                                                row
                                                aria-label="Other Insurance Coverage"
                                                name="Other Insurance Coverage"
                                                checked={data.otherInsuranceIndicator}
                                                value={data.otherInsuranceIndicator}
                                                onChange={e => { props.setClaimEntryData({ ...data, otherInsuranceIndicator: e.target.value == "true" ? true : false }) }}
                                            >
                                                <FormControlLabel
                                                    value={true}
                                                    control={<Radio color="primary" />}
                                                    label="Yes"
                                                />
                                                <FormControlLabel
                                                    value={false}
                                                    control={<Radio color="primary" />}
                                                    label="No"
                                                />
                                            </RadioGroup>
                                        </div>
                                    </div>
                                </div>

                                <Divider />
                                <div className="form-wrapper wrap-form-label px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coverage_and_admission_typeOfBill"
                                            label="Type Of Bill"
                                            placeholder=""
                                            value={
                                                 data.institutionalClaim ?.coverageAdmission ?.typeOfBillCode
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: { ...data.institutionalClaim, 
                                                coverageAdmission: {...data.institutionalClaim.coverageAdmission, typeOfBillCode : e.target.value } 
                                            }}) }
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 4 }}
                                        />
                                    </div>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="coa_dos_begin_date"
                                                label="Dos Begin"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                   data.FDOS
                                                }
                                                //onChange={(dt, val) => { props.setClaimEntryData({ ...data, "FDOS" : (dt ? isNaN(dt.getTime()) ? val : dt : val) } ); }}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "FDOS" : (dt ? isNaN(dt.setTime( dt.getTime() - new Date().getTimezoneOffset()*60*1000 )) ? val : dt : val) } ); }}
                                                helperText={null}
                                                error={null}                                                
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="dos_end_date"
                                                label="DOS End "
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={data.LDOS}
                                                //onChange={(dt, val) => { props.setClaimEntryData({ ...data, "LDOS" : (dt ? isNaN(dt.getTime()) ? val : dt : val) } ); }}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "LDOS" : (dt ? isNaN(dt.setTime( dt.getTime() - new Date().getTimezoneOffset()*60*1000 )) ? val : dt : val) } ); }}
                                                helperText={null}
                                                error={null}                                                
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                </div>
                                <div className="form-wrapper wrap-form-label px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_Covered_Days"
                                            label="Covered Days"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.coveredDays
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    coveredDays : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_Non_Covered_Days"
                                            label="Non-Covered Days"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.nonCoveredDays
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    nonCoveredDays : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="coa_admit_date"
                                                label="Admit Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={data?.admitDateTime}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "admitDateTime": (dt ? isNaN(dt.getTime()) ? val : dt : val) }); }}
                                                helperText={null}
                                                error={null}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="Coverage_Admission_Admit_Hour"
                                            label="Admit Hour"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.admitHour
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    admitHour : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 10 }}
                                        />
                                    </div>
                                 
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_Admit_Type"
                                            label="Admit Type"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.admitTypeCode
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    admitTypeCode : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 1 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_Admit_Source"
                                            label="Admit Source"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.admitSourceCode
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    admitSourceCode : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 1 }}
                                        />
                                    </div>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                disabled
                                                id="coa_Discharge_Date"
                                                label="Discharge Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={data.dischargeDateTime ? data.dischargeDateTime : null}
                                                onChange={(dt, val) => { props.setClaimEntryData({ ...data, "dischargeDateTime": (dt ? isNaN(dt.getTime()) ? val : dt : val) }); }}
                                                helperText={null}
                                                error={null}
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_Discharge_Hour"
                                            label="Discharge Hour"
                                            placeholder=""
                                            value={data.dischargeTMNumber ? data.dischargeTMNumber : null}
                                            onChange={(dt, val) => { props.setClaimEntryData({ ...data, "dischargeTMNumber": (dt ? isNaN(dt.getTime()) ? val : dt : val) }); }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 10 }}
                                        />
                                    </div>
                                 
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_Patient_status"
                                            label="Patient Status"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.patientStatusCode
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    patientStatusCode : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_Length_of_stay"
                                            label="Length Of Stay"
                                            placeholder=""
                                            value={
                                                data.additionalClaimData ?.lengthOfStay
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, additionalClaimData: 
                                                { ...data.additionalClaimData, lengthOfStay : e.target.value} }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_hours_billed"
                                            label="Hours Billed"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.billedHours
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    billedHours : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 4 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_benefit_plan"
                                            label="Benefit Plan"
                                            placeholder=""
                                            value={
                                                data?.benefitPlanID
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, benefitPlanID: e.target.value }); }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 6 }}
                                        />
                                    </div>
                                 
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_map_set_id"
                                            label="Mapset ID"
                                            placeholder=""
                                            value={
                                                data?.mapSetID
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, mapSetID: e.target.value }); }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 6 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_cat_of_svc"
                                            label="Cat Of Svc"
                                            placeholder=""
                                            value={
                                                data?.categoryOfServiceCode
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, categoryOfServiceCode: e.target.value }); }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 3 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="fund_code"
                                            label="Fund Code"
                                            placeholder=""
                                            value={
                                                data.institutionalClaim ?.coverageAdmission ?.fundCode
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, institutionalClaim: 
                                                { ...data.institutionalClaim, coverageAdmission: {...data.institutionalClaim.coverageAdmission,
                                                    fundCode : e.target.value } }}) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_accident_state"
                                            label="Accident State"
                                            placeholder=""
                                            value={
                                                data?.enterpriseClaimAux?.accidentStateCode
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, enterpriseClaimAux: { ...data.enterpriseClaimAux, accidentStateCode: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                        />
                                    </div>
                                 
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_sub_svc_auth_id"
                                            label="Sub Svc Auth ID"
                                            placeholder=""
                                            value={
                                                data?.claimServiceAuthorization?.submittedServiceAuthID
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, claimServiceAuthorization: { ...data.claimServiceAuthorization, submittedServiceAuthID: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 30 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="svc_auth_req"
                                            label="Svc Auth Req'd"
                                            placeholder=""
                                            value={
                                                data?.claimServiceAuthorization?.saRequiredIndicator
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, claimServiceAuthorization: { ...data.claimServiceAuthorization, saRequiredIndicator: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 1 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="svc_auth_line_applied"
                                            label="Svc Auth Line Applied"
                                            placeholder=""
                                            value={
                                                data?.claimServiceAuthorization?.serviceAuthLineNumber
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, claimServiceAuthorization: { ...data.claimServiceAuthorization, serviceAuthLineNumber: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="svc_auth_id"
                                            label="Svc Auth ID"
                                            placeholder=""
                                            value={
                                                data?.claimServiceAuthorization?.serviceAuthID
                                            }
                                            onChange={e => { props.setClaimEntryData({ ...data, claimServiceAuthorization: { ...data.claimServiceAuthorization, serviceAuthID: e.target.value } }) }}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 12 }}
                                        />
                                    </div>
                                </div>
                            </div>
                                <div id="Diagnosis Codes Div Id">
                                    <CoverageAndAdmission
                                        data={data}
                                        setClaimEntryData={props.setClaimEntryData}
                                        setConditionCodes={props.setConditionCodes}
                                        setOccurrenceCodes={props.setOccurrenceCodes}
                                        setOccurrenceSpans={props.setOccurrenceSpans}
                                        setValueCodes={props.setValueCodes}
                                        addDropdowns={props.addDropdowns}
                                        seterrorMessages={props.seterrorMessages} />
                                </div>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>

                </div>
            </div >
        </div>
    )
}

export default CoverageAdmissionMain;