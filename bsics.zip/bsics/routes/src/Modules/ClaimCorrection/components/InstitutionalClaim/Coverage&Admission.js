import React, { useState, useEffect, useRef } from "react";
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
import TableComponent from '../../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import * as Dropdowns from '../../../../SharedModules/Dropdowns/dropdowns';
import { GET_SYSTEMLIST_DROPDOWN } from '../../../../SharedModules/Dropdowns/actions';
import * as ErrorConst from '../../../../SharedModules/Messages/ErrorMsgConstants';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import { useConfirm } from '../../../../SharedModules/MUIConfirm/index';

function CoverageAndAdmission(props) {
    const dispatch = useDispatch();
    const muiconfirm = useConfirm();
    const data = props.data;    
    const [showForm1, setShowForm1] = React.useState(false);
    const [showForm2, setShowForm2] = React.useState(false);
    const [showForm3, setShowForm3] = React.useState(false);
    const [showForm4, setShowForm4] = React.useState(false);
    
    const [selectDeleteArray1, setSelectDeleteArray1] = React.useState([]);
    const [selectDeleteArray2, setSelectDeleteArray2] = React.useState([]);
    const [selectDeleteArray3, setSelectDeleteArray3] = React.useState([]);
    const [selectDeleteArray4, setSelectDeleteArray4] = React.useState([]);
    const OccurrenceCodeCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: '#', enableHyperLink: true, width: "20%", fontSize: 12
        },
        {
            id: 'occurrenceCode', numeric: false, disablePadding: false, label: 'Code', enableHyperLink: false, width: "40%", fontSize: 12
        },
        {
            id: 'occurrenceDate', numeric: false, disablePadding: false, label: 'Date', enableHyperLink: false, width: "40%", fontSize: 12, isDate: true
        },
    ];
    const ValueCodeCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: '#', enableHyperLink: true, width: "20%", fontSize: 12
        },
        {
            id: 'valueCode', numeric: false, disablePadding: false, label: 'Code', enableHyperLink: false, width: "40%", fontSize: 12
        },
        {
            id: 'valueAmount', numeric: false, disablePadding: false, label: 'Amount', enableHyperLink: false, width: "40%", fontSize: 12, isBalance: true
        },
    ];
    const OccurrenceSpansCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: '#', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'occurrenceSpanCode', numeric: false, disablePadding: false, label: 'Code', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'beginDate', numeric: false, disablePadding: false, label: 'Begin Date', enableHyperLink: false, fontSize: 12, isDate: true
        },
        {
            id: 'endDate', numeric: false, disablePadding: false, label: 'End Date', enableHyperLink: false, fontSize: 12, isDate: true
        }
    ];
    const conditionCodeCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: '#', enableHyperLink: true, width: "20%", fontSize: 12
        },
        {
            id: 'conditionCode', numeric: false, disablePadding: false, label: 'Code', enableHyperLink: false, width: "80%", fontSize: 12
        }
    ];

    const payerCells = [
        {
            id: 'otherPayerID', numeric: false, disablePadding: true, label: 'Payer', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'otherPayerProviderId', numeric: false, disablePadding: false, label: 'Provider ID', enableHyperLink: false, fontSize: 12,
        },
        {
            id: 'paidAmount', numeric: false, disablePadding: false, label: 'Prior Payment', enableHyperLink: false, fontSize: 12, isBalance: true
        },
        {
            id: 'patientResponsibleAmount', numeric: false, disablePadding: false, label: 'Est Amt Due', enableHyperLink: false, fontSize: 12, isBalance: true
        },
        {
            id: 'insuredID', numeric: false, disablePadding: false, label: 'Other Insured ID', enableHyperLink: false, fontSize: 12,
        },
        {
            id: 'authorizationID', numeric: false, disablePadding: false, label: 'Treatment Auth', enableHyperLink: false, fontSize: 12,
        }
    ];   
    const [values1, setValues1] = useState({}); 
    const [values2, setValues2] = useState({});
    const [values3, setValues3] = useState({});
    const [values4, setValues4] = useState({});   
    const [tableData1, setTableData1] = useState([]);
    const [tableData2, setTableData2] = useState([]);
    const [tableData3, setTableData3] = useState([]);
    const [tableData4, setTableData4] = useState([]);
    const addEditRef1 = useRef(null);
    const addEditRef2 = useRef(null);
    const addEditRef3 = useRef(null);
    const addEditRef4 = useRef(null);

    const onDropdowns = (val) => dispatch(GET_SYSTEMLIST_DROPDOWN(val));
    const addDropdowns = useSelector(state => state.appDropDowns.sysdropdowns);
    const [{ dErr, qErr, dQErr }, setErrors] = useState({});
   

    const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });  

    const scrollToAddEdit1 = () => {
        setTimeout(function () {
            scrollToRef(addEditRef1);
        }.bind(this), 1000);
    };
    
    const scrollToAddEdit2 = () => {
        setTimeout(function () {
            scrollToRef(addEditRef2);
        }.bind(this), 1000);
    }; 

    const scrollToAddEdit3 = () => {
        setTimeout(function () {
            scrollToRef(addEditRef3);
        }.bind(this), 1000);
    }; 

    const scrollToAddEdit4 = () => {
        setTimeout(function () {
            scrollToRef(addEditRef4);
        }.bind(this), 1000);
    }; 

    useEffect(() => {
        onDropdowns({ "inputList": [Dropdowns.PROF_DIAG_QLFY_TYPE] });        
        if (props.data?.institutionalClaim?.coverageAdmission?.conditionCode?.length) {
            setTableData1(props.data.institutionalClaim.coverageAdmission.conditionCode);
        }
        if (props.data?.institutionalClaim?.coverageAdmission?.occurrenceCode?.length) {
            setTableData2(props.data.institutionalClaim.coverageAdmission.occurrenceCode);
        }
        if (props.data?.institutionalClaim?.coverageAdmission?.occurrenceSpan?.length) {
            setTableData3(props.data.institutionalClaim.coverageAdmission.occurrenceSpan);
        }
        if (props.data?.institutionalClaim?.coverageAdmission?.value?.length) {
            setTableData4(props.data.institutionalClaim.coverageAdmission.value);
        }
    }, []); 

    const onRowAdd1 = () => {
        scrollToAddEdit1();        
        setShowForm1(true);
        setValues1({
            "sequenceNumber": tableData1.length ? tableData1.length + 1 : 1,
            "conditionCode": null
        });
    };  
    const editRow1 = row => (event) => {
        scrollToAddEdit1();
        setValues1(row);
        setShowForm1(true);        
    };  
    const onRowCancel1 = () => {
        setShowForm1(false);
    };    
    const handelSave1 = () => {
        if (values1.index > -1) {
            const { index, ...vals } = values1;
            tableData1[index] = vals;
            setTableData1([...tableData1]);
        } else {
            tableData1.push(values1);
            setTableData1([...tableData1]);
        }
        setShowForm1(false);
        props.setConditionCodes(tableData1);
    };

    const onRowAdd2 = () => {
        scrollToAddEdit2();       
        setShowForm2(true);
        setValues2({
            "sequenceNumber": tableData2.length ? tableData2.length + 1 : 1,
            "occurrenceCode": null,
            "occurrenceDate": null
        });
    };  
    const editRow2 = row => (event) => {
        scrollToAddEdit2();
        setValues2(row);
        setShowForm2(true);        
    };  
    const onRowCancel2 = () => {
        setShowForm2(false);
    };    
    const handelSave2 = () => {
        if (values2.index > -1) {
            const { index, ...vals } = values2;
            tableData2[index] = vals;
            setTableData2([...tableData2]);
        } else {
            tableData2.push(values2);
            setTableData2([...tableData2]);
        }
        setShowForm2(false);
        props.setOccurrenceCodes(tableData2);
    };

    const onRowAdd3 = () => {
        scrollToAddEdit3();        
        setShowForm3(true);
        setValues3({
            "sequenceNumber": tableData3.length ? tableData3.length + 1 : 1,
            "occurrenceSpanCode": null,
            "beginDate": null,
            "endDate": null
        });
    };  
    const editRow3 = row => (event) => {
        scrollToAddEdit3();
        setValues3(row);
        setShowForm3(true);        
    };  
    const onRowCancel3 = () => {
        setShowForm3(false);
    };    
    const handelSave3 = () => {
        if (values3.index > -1) {
            const { index, ...vals } = values3;
            tableData3[index] = vals;
            setTableData3([...tableData3]);
        } else {
            tableData3.push(values3);
            setTableData3([...tableData3]);
        }
        setShowForm3(false);
        props.setOccurrenceSpans(tableData3);
    };

    const onRowAdd4 = () => {
        scrollToAddEdit4();        
        setShowForm4(true);
        setValues4({
            "sequenceNumber": tableData4.length ? tableData4.length + 1 : 1,
            "valueCode": null,
            "valueAmount": null
        });
    };  
    const editRow4 = row => (event) => {
        scrollToAddEdit4();
        setValues4(row);
        setShowForm4(true);        
    };  
    const onRowCancel4 = () => {
        setShowForm4(false);
    };    
    const handelSave4 = () => {
        if (values4.index > -1) {
            const { index, ...vals } = values4;
            tableData4[index] = vals;
            setTableData4([...tableData4]);
        } else {
            tableData4.push(values4);
            setTableData4([...tableData4]);
        }
        setShowForm4(false);
        props.setValueCodes(tableData4);
    };

    const handleMultiDelete1 = () => {      
        muiconfirm({ title: "", description: 'Are you sure that you want to delete?', dialogProps: { fullWidth: false } })
            .then(() => {
                selectDeleteArray1.forEach((e)=>{
                    tableData1.splice(tableData1.findIndex((f)=>{f.index==e.index}),1);  
                });                                
                props.setConditionCodes(tableData1);
                setShowForm1(false);
                setSelectDeleteArray1([]);
            });
    };

    const handleMultiDelete2 = () => {      
        muiconfirm({ title: "", description: 'Are you sure that you want to delete?', dialogProps: { fullWidth: false } })
            .then(() => {
                selectDeleteArray2.forEach((e)=>{
                    tableData2.splice(tableData2.findIndex((f)=>{f.index==e.index}),1);  
                });                  
                props.setOccurrenceCodes(tableData2);
                setShowForm2(false);
                setSelectDeleteArray2([]);
            });
    };

    const handleMultiDelete3 = () => {      
        muiconfirm({ title: "", description: 'Are you sure that you want to delete?', dialogProps: { fullWidth: false } })
            .then(() => {
                selectDeleteArray3.forEach((e)=>{
                    tableData3.splice(tableData3.findIndex((f)=>{f.index==e.index}),1);  
                });                  
                props.setOccurrenceSpans(tableData3);
                setShowForm3(false);
                setSelectDeleteArray3([]);
            });
    };

    const handleMultiDelete4 = () => {      
        muiconfirm({ title: "", description: 'Are you sure that you want to delete?', dialogProps: { fullWidth: false } })
            .then(() => {
                selectDeleteArray4.forEach((e)=>{
                    tableData4.splice(tableData4.findIndex((f)=>{f.index==e.index}),1);  
                });               
                props.setValueCodes(tableData4);
                setShowForm4(false);
                setSelectDeleteArray4([]);
            });
    };


    const getTableData = (dt) => {
        if (dt && dt.length) {
            let tData = JSON.stringify(dt);
            tData = JSON.parse(tData);
            tData.map((each, index) => {
                each.index = index;
            });
            return tData;
        } else {
            return [];
        }
    };
    return (
        <>
            <div className="tabs-container tabs-container-inner mt-4">
                <div className="tab-body-bordered mb-2">
                    <div className="tab-header px-3 mt-2">
                        <h3 className="tab-heading pb-0 float-left">
                            Condition Codes
                        </h3>
                        <div className="float-right th-btnGroup">
                            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray1.length == 0} onClick={() => { handleMultiDelete1(); }}>
                                <i className="fa fa-trash" />
                            </Button>
                            <Button
                                title="Add Diagnosis"
                                variant="outlined"
                                color="primary"
                                className="btn btn-secondary btn-icon-only"
                                onClick={onRowAdd1}
                            >
                                <i className="fa fa-plus" />
                            </Button>
                        </div>
                    </div>
                    <div className="tab-body px-3 pb-3">
                        <TableComponent multiDelete selected={selectDeleteArray1} setSelected={setSelectDeleteArray1} print={print} headCells={conditionCodeCells} tableData={getTableData(tableData1)} onTableRowClick={editRow1} defaultSortColumn="sequenceNumber" />
                    </div>
                    {showForm1 ? (
                        <div className="tabs-container tabs-container-inner" ref={addEditRef1}>
                            <div className="tab-header">
                                <h2 className="tab-heading float-left">
                                    {values1.index > -1 ? "Edit" : "Add"} Condition Code
                                </h2>
                                <div className="float-right th-btnGroup">
                                    <Button title={values1.index > -1 ? 'Update' : 'Add'} variant="outlined" color="primary" className='btn btn-ic-only btn-icon-only-save' onClick={() => handelSave1()}>
                                    </Button>
                                    <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-reset" onClick={() => { setValues1({}); }}>
                                    </Button>
                                    <Button title="Cancel" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-cancel" onClick={onRowCancel1}>
                                    </Button>
                                </div>
                            </div>

                            <form autoComplete="off">
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coa_condition_code_sequenceNumber"
                                            name="sequenceNumber"
                                            value={values1.sequenceNumber ? values1.sequenceNumber : ""}
                                            label="#"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_condition_code_conditionCode"
                                            name="conditionCode"
                                            value={values1.conditionCode ? values1.conditionCode : ""}
                                            onChange={event => { setValues1({ ...values1, [event.target.name]: event.target.value }); }}
                                            label="Code"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                            helperText={null}
                                            error={null}
                                        />
                                    </div>

                                </div>
                            </form>
                        </div>
                    ) : null}
                </div>
            </div>
            <div className="tabs-container tabs-container-inner mt-4">
                <div className="tab-body-bordered mb-2">
                    <div className="tab-header px-3 mt-2">
                        <h3 className="tab-heading pb-0 float-left">
                            Occurrence Codes
                        </h3>
                        <div className="float-right th-btnGroup">
                            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray2.length == 0} onClick={() => { handleMultiDelete2(); }}>
                                <i className="fa fa-trash" />
                            </Button>
                            <Button
                                title="Add Diagnosis"
                                variant="outlined"
                                color="primary"
                                className="btn btn-secondary btn-icon-only"
                                onClick={onRowAdd2}
                            >
                                <i className="fa fa-plus" />
                            </Button>
                        </div>
                    </div>
                    <div className="tab-body px-3 pb-3">
                        <TableComponent multiDelete selected={selectDeleteArray2} setSelected={setSelectDeleteArray2} print={print} headCells={OccurrenceCodeCells} tableData={getTableData(tableData2)} onTableRowClick={editRow2} defaultSortColumn="sequenceNumber" />
                    </div>
                    {showForm2 ? (
                        <div className="tabs-container tabs-container-inner" ref={addEditRef2}>
                            <div className="tab-header">
                                <h2 className="tab-heading float-left">
                                    {values2.index > -1 ? "Edit" : "Add"} Occurrence Codes
                                </h2>
                                <div className="float-right th-btnGroup">
                                    <Button title={values2.index > -1 ? 'Update' : 'Add'} variant="outlined" color="primary" className='btn btn-ic-only btn-icon-only-save' onClick={() => handelSave2()}>
                                    </Button>
                                    <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-reset" onClick={() => { setValues2({}); }}>
                                    </Button>
                                    <Button title="Cancel" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-cancel" onClick={onRowCancel2}>
                                    </Button>
                                </div>
                            </div>

                            <form autoComplete="off">
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="visit_condition_code_sequenceNumber"
                                            name="sequenceNumber"
                                            value={values2.sequenceNumber ? values2.sequenceNumber : ""}
                                            label="#"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coa_condition_code_occurrenceCode"
                                            name="occurrenceCode"
                                            value={values2?.occurrenceCode}
                                            onChange={event => { setValues2({ ...values2, [event.target.name]: event.target.value }); }}
                                            label="Code"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                            helperText={null}
                                            error={null}
                                        />
                                    </div>

                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="coa_occurrenceDate"
                                                label="Date"
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                   values2?.occurrenceDate
                                                }
                                                onChange={(dt, val) => { setValues2({ ...values2, "occurrenceDate" : (dt ? isNaN(dt.getTime()) ? val : dt : val) } ); }}
                                                helperText={ null}
                                                error={null}                                                
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    
                                   
                                </div>
                            </form>
                        </div>
                    ) : null}
                </div>
            </div>
            <div className="tabs-container tabs-container-inner mt-4">
                <div className="tab-body-bordered mb-2">
                    <div className="tab-header px-3 mt-2">
                        <h3 className="tab-heading pb-0 float-left">
                            Occurrence Spans
                        </h3>
                        <div className="float-right th-btnGroup">
                            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray3.length == 0} onClick={() => { handleMultiDelete3(); }}>
                                <i className="fa fa-trash" />
                            </Button>
                            <Button
                                title="Add Diagnosis"
                                variant="outlined"
                                color="primary"
                                className="btn btn-secondary btn-icon-only"
                                onClick={onRowAdd3}
                            >
                                <i className="fa fa-plus" />
                            </Button>
                        </div>
                    </div>
                    <div className="tab-body px-3 pb-3">
                        <TableComponent multiDelete selected={selectDeleteArray3} setSelected={setSelectDeleteArray3} print={print} headCells={OccurrenceSpansCells} tableData={getTableData(tableData3)} onTableRowClick={editRow3} defaultSortColumn="sequenceNumber" />
                    </div>
                    {showForm3 ? (
                        <div className="tabs-container tabs-container-inner" ref={addEditRef3}>
                            <div className="tab-header">
                                <h2 className="tab-heading float-left">
                                    {values3.index > -1 ? "Edit" : "Add"} Occurrence Spans
                                </h2>
                                <div className="float-right th-btnGroup">
                                    <Button title={values3.index > -1 ? 'Update' : 'Add'} variant="outlined" color="primary" className='btn btn-ic-only btn-icon-only-save' onClick={() => handelSave3()}>
                                    </Button>
                                    <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-reset" onClick={() => { setValues3({}); }}>
                                    </Button>
                                    <Button title="Cancel" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-cancel" onClick={onRowCancel3}>
                                    </Button>
                                </div>
                            </div>

                            <form autoComplete="off">
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coverage_admission_occurrence_span_sequenceNumber"
                                            name="sequenceNumber"
                                            value={values3.sequenceNumber ? values3.sequenceNumber : ""}
                                            label="#"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coverage_admission_occurrence_span_conditionCode"
                                            name="occurrenceSpanCode"
                                            value={values3?.occurrenceSpanCode}
                                            onChange={event => { setValues3({ ...values3, [event.target.name]: event.target.value }); }}
                                            label="Code"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                            helperText={null}
                                            error={null}
                                        />
                                    </div>
                                    
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="coverage_admission_occurrence_span_begin_date"
                                                label="Begin Date "
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    values3?.beginDate
                                                }
                                                onChange={(dt, val) => { setValues3({ ...values3, "beginDate" : (dt ? isNaN(dt.getTime()) ? val : dt : val) } ); }}
                                                helperText={ null}
                                                error={null}                                                
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>
                                    
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                        <div className="mui-custom-form input-md with-select">
                                            <KeyboardDatePicker
                                                id="coverage_admission_occurrence_span_end_date"
                                                label="End Date "
                                                format="MM/dd/yyyy"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                placeholder="mm/dd/yyyy"
                                                value={
                                                    values3?.endDate
                                                }
                                                onChange={(dt, val) => { setValues3({ ...values3, "endDate" : (dt ? isNaN(dt.getTime()) ? val : dt : val) } ); }}
                                                helperText={ null}
                                                error={null}                                               
                                                KeyboardButtonProps={{
                                                    "aria-label": "change date"
                                                }}
                                            />
                                        </div>
                                    </MuiPickersUtilsProvider>                                

                                </div>
                            </form>
                        </div>
                    ) : null}
                </div>
            </div>
            <div className="tabs-container tabs-container-inner mt-4">
                <div className="tab-body-bordered mb-2">
                    <div className="tab-header px-3 mt-2">
                        <h3 className="tab-heading pb-0 float-left">
                            Values Codes
                        </h3>
                        <div className="float-right th-btnGroup">
                            <Button title="Delete" variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" disabled={selectDeleteArray4.length == 0} onClick={() => { handleMultiDelete4(); }}>
                                <i className="fa fa-trash" />
                            </Button>
                            <Button
                                title="Add Diagnosis"
                                variant="outlined"
                                color="primary"
                                className="btn btn-secondary btn-icon-only"
                                onClick={onRowAdd4}
                            >
                                <i className="fa fa-plus" />
                            </Button>
                        </div>
                    </div>
                    <div className="tab-body px-3 pb-3">
                        <TableComponent multiDelete selected={selectDeleteArray4} setSelected={setSelectDeleteArray4} print={print} headCells={ValueCodeCells} tableData={getTableData(tableData4)} onTableRowClick={editRow4} defaultSortColumn="sequenceNumber" />
                    </div>
                    {showForm4 ? (
                        <div className="tabs-container tabs-container-inner" ref={addEditRef4}>
                            <div className="tab-header">
                                <h2 className="tab-heading float-left">
                                    {values4.index > -1 ? "Edit" : "Add"} Value Codes
                                </h2>
                                <div className="float-right th-btnGroup">
                                    <Button title={values4.index > -1 ? 'Update' : 'Add'} variant="outlined" color="primary" className='btn btn-ic-only btn-icon-only-save' onClick={() => handelSave4()}>
                                    </Button>
                                    <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-reset" onClick={() => { setValues4({}); }}>
                                    </Button>
                                    <Button title="Cancel" variant="outlined" color="primary" className="btn btn-ic-only btn-icon-only-cancel" onClick={onRowCancel4}>
                                    </Button>
                                </div>
                            </div>

                            <form autoComplete="off">
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="coverage_admission_value_code_sequenceNumber"
                                            name="sequenceNumber"
                                            value={values4?.sequenceNumber}
                                            label="#"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 5 }}
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coverage_admission_value_code_valueCode"
                                            name="valueCode"
                                            value={values4?.valueCode}
                                            onChange={event => { setValues4({ ...values4, [event.target.name]: event.target.value }); }}
                                            label="Code"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 2 }}
                                            helperText={null}
                                            error={null}
                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            id="coverage_admission_value_code_amount"
                                            name="valueAmount"
                                            value={values4?.valueAmount}
                                            onChange={event => { setValues4({ ...values4, [event.target.name]: event.target.value }); }}
                                            label="Amount"
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            inputProps={{ maxLength: 13 }}
                                            helperText={null}
                                            error={null}
                                        />
                                    </div>

                                </div>
                            </form>
                        </div>
                    ) : null}
                </div>
            </div>
            <div className="tabs-container mt-2">
                <div className="tab-header">
                    <h3 className="tab-heading pb-0 float-left">
                        Payer
                        </h3>
                </div>
                <div className="tab-body">
                    <TableComponent print={print} headCells={payerCells} tableData={[]} onTableRowClick={editRow1} defaultSortColumn="providerID" />
                </div>
            </div>
        </>
    )
}

export default CoverageAndAdmission;