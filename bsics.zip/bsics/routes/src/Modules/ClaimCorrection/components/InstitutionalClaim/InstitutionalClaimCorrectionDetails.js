
import React, { useState, useEffect, useRef } from 'react';
import { Button } from 'react-bootstrap';
import TextField from '@material-ui/core/TextField';
import * as ErrorMessageConstants from '../../../../SharedModules/Messages/ErrorMsgConstants';
import * as serviceEndPoint from '../../../../SharedModules/services/service';
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import TabPanel from '../../../../SharedModules/TabPanel/TabPanel';
import BreadCrumbs from "../../../../SharedModules/BreadCrumb/BreadCrumb";
import Axios from 'axios';
import Claim from './Claim';
import QuickLinks from '../../../ClaimsEntry/Components/InstitutionalClaim/QuickLinks';
import Member from './Member';
import CoverageAdmissionMain from './Coverage&AdmissionMain';
import OtherPayer from '../../../ClaimsEntry/Components/InstitutionalClaim/OtherPayer';
import LineItems from '../../../ClaimsEntry/Components/InstitutionalClaim/LineItems/LineItem';
import PaymentProvider from './Payment&Provider';
import ReplacementVoids from './ReplacementVoid';
import History from './History';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import AttachmentsComponent from '../../../ClaimsEntry/Components/InstitutionalClaim/LineItems/AttachmentsComponent';
import ManualEobsComponent from '../../../ClaimsEntry/Components/InstitutionalClaim/LineItems/ManualEobsComponent';
import AdditionalRemarksComponent from '../../../ClaimsEntry/Components/InstitutionalClaim/LineItems/AdditionalRemarksComponent';
import OverrideException from '../../../ClaimsEntry/Components/InstitutionalClaim/OverrideException';
import * as Dropdowns from '../../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS } from '../../../../SharedModules/Dropdowns/actions';
import { useDispatch, useSelector } from 'react-redux';
import { useConfirm } from '../../../../SharedModules/MUIConfirm/index';
import ExceptionView from '../InstitutionalClaim/ExceptionView';
import OtherServiceInfo from '../OtherServiceInfo';
import ClaimsOtherInfo from '../DentalOtherInfo';
import BasicClaimInfo from '../InstitutionalClaim/BasicClaimInfo';
import dateFnsFormat from 'date-fns/format';
import * as moment from "moment";
import "moment-range";
import NavigationPrompt from "react-router-navigation-prompt";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import * as ErrorConst from '../../../../SharedModules/Messages/ErrorMsgConstants';
import OtherClaimInfo  from '../InstitutionalClaim/OtherClaimInfo';
import OtherServicesInfo  from '../InstitutionalClaim/OtherServicesInfo';
import InpatientPricing from '../../../ClaimsEntry/Components/InstitutionalClaim/InpatientPricing';
import DiagnosisAndProcedureCodes from './Diagnosis&Procedure';
import ErrorComponent from '../../../../SharedModules/Errors/TimeOutErrorMsg';
import SuccessComponent from '../../../../SharedModules/Errors/TimeOutSuccessMsg';
const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

function a11yProps(index) {
    return {
        id: `scrollable-auto-tab-${index}`,
        'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
}

function ClaimCorrectionDetails(props) {
    const classes = useStyles();
    const muiconfirm = useConfirm();
    const [tabValue, setTabValue] = useState(0);
    //const [claimDetailsData, setClaimDetailsData] = React.useState(props.location.getClaimCorrection)
    const data = props.location && props.location.getClaimCorrection ? props.location.getClaimCorrection : {};
    let d = data.data ? data.data : {};
    if (data.data && data.data.payment.medicalRecordNumber == null && data.data.additionalClaimData.medicalRecordNumber) {
        data.data.payment.medicalRecordNumber = data.data.additionalClaimData.medicalRecordNumber;
    }
    if (data.data && data.data.professionalClaim.unableToWorkFromDate == null && data.data.additionalClaimData.unableToWorkFromDate) {
        data.data.professionalClaim.unableToWorkFromDate = data.data.additionalClaimData.unableToWorkFromDate;
    }
    if (data.data && data.data.professionalClaim.unableToWorkToDate == null && data.data.additionalClaimData.unableToWorkToDate) {
        data.data.professionalClaim.unableToWorkToDate = data.data.additionalClaimData.unableToWorkToDate;
    }
    if (data.data && data.data.medicareDetails && data.data.medicareDetails.deductibleAmount == null && data.data.additionalClaimData.deductibleAmount) {
        data.data.medicareDetails.deductibleAmount = data.data.additionalClaimData.deductibleAmount;
    }
    if (data.data && data.data.medicareDetails && data.data.medicareDetails.coInsuranceAmount == null && data.data.additionalClaimData.coInsuranceAmount) {
        data.data.medicareDetails.coInsuranceAmount = data.data.additionalClaimData.coInsuranceAmount;
    }
    if (data.data && data.data.medicareDetails && data.data.medicareDetails.paidAmount == null && data.data.additionalClaimData.paidAmount) {
        data.data.medicareDetails.paidAmount = data.data.additionalClaimData.paidAmount;
    }
    if (data.data && data.data.payment && data.data.payment.mic == null && data.data.additionalClaimData.mic) {
        data.data.payment.mic = data.data.additionalClaimData.mic;
    }
    if (data.data && data.data.payment && data.data.payment.eombDate == null && data.data.additionalClaimData.eombDate) {
        data.data.payment.eombDate = data.data.additionalClaimData.eombDate;
    }
    if (data.data && data.data.claimMember && data.data.claimMember.sex == null && data.data.additionalClaimData.sex) {
        data.data.claimMember.sex = data.data.additionalClaimData.sex;
    }
    if (data.data && data.data.batchInfo && data.data.batchInfo.paymentTypeCode == null && data.data.additionalClaimData.paymentTypeCode) {
        data.data.batchInfo.paymentTypeCode = data.data.additionalClaimData.paymentTypeCode;
    }
    d.professionalClaim.outlabAmount = d.professionalClaim.outlabAmount ? Number.parseFloat(d.professionalClaim.outlabAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.claimTPLInfo.map(eachTPLInfo => {
                  eachTPLInfo.claimTPLAmountInfo.map(eachAmount => {
                    eachAmount.allowedAmount= eachAmount.allowedAmount ? Number.parseFloat(eachAmount.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.billedAmount= eachAmount.billedAmount ? Number.parseFloat(eachAmount.billedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.coPayAmount= eachAmount.coPayAmount ? Number.parseFloat(eachAmount.coPayAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.coinsuranceAmount= eachAmount.coinsuranceAmount ? Number.parseFloat(eachAmount.coinsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.deductibleAmount= eachAmount.deductibleAmount ? Number.parseFloat(eachAmount.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.paidAmount= eachAmount.paidAmount ? Number.parseFloat(eachAmount.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.patientResponsibleAmount= eachAmount.patientResponsibleAmount ? Number.parseFloat(eachAmount.patientResponsibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  });
                });
                d.enterpriseClaimLineItem.map(eachline => {
                  eachline.submitChargeAmount = eachline.submitChargeAmount ? Number.parseFloat(eachline.submitChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.submitUnits = eachline.submitUnits ? Number.parseFloat(eachline.submitUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
                  eachline.baseRateAmount = eachline.baseRateAmount ? Number.parseFloat(eachline.baseRateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.calculatedAllowedAmount = eachline.calculatedAllowedAmount ? Number.parseFloat(eachline.calculatedAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.allowedChargeAmount = eachline.allowedChargeAmount ? Number.parseFloat(eachline.allowedChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.allowedUnitQty = eachline.allowedUnitQty ? Number.parseFloat(eachline.allowedUnitQty).toFixed(1) : Number.parseFloat(0).toFixed(1);
                  eachline.tplAmount = eachline.tplAmount ? Number.parseFloat(eachline.tplAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.reimbursementAmount = eachline.reimbursementAmount ? Number.parseFloat(eachline.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.reimbursementUnits = eachline.reimbursementUnits ? Number.parseFloat(eachline.reimbursementUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
                  let medDetails = eachline.medicareDetails ? eachline.medicareDetails : {};
                  medDetails.allowedAmount = medDetails.allowedAmount ? Number.parseFloat(medDetails.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.coInsuranceAmount = medDetails.coInsuranceAmount ? Number.parseFloat(medDetails.coInsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.deductibleAmount = medDetails.deductibleAmount ? Number.parseFloat(medDetails.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.paidAmount = medDetails.paidAmount ? Number.parseFloat(medDetails.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.medicareDetails = medDetails;
                  let institutionalLineItem = eachline.institutionalLineItem ? eachline.institutionalLineItem : {};
                  institutionalLineItem.rateAmount = institutionalLineItem.rateAmount ? Number.parseFloat(institutionalLineItem.rateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  institutionalLineItem.nonCoveredAmount = institutionalLineItem.nonCoveredAmount ? Number.parseFloat(institutionalLineItem.nonCoveredAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.institutionalLineItem = institutionalLineItem;
                });
                let claimPricing = d.claimPricing ? d.claimPricing : {};
                claimPricing.grouperAllowedAmount = claimPricing.grouperAllowedAmount ? Number.parseFloat(claimPricing.grouperAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.outlierAmount = claimPricing.outlierAmount ? Number.parseFloat(claimPricing.outlierAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.drgOutlierAmount = claimPricing.drgOutlierAmount ? Number.parseFloat(claimPricing.drgOutlierAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.drgAllowedAmount = claimPricing.drgAllowedAmount ? Number.parseFloat(claimPricing.drgAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.baseRateAmount = claimPricing.baseRateAmount ? Number.parseFloat(claimPricing.baseRateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.calculatedAllowedAmount = claimPricing.calculatedAllowedAmount ? Number.parseFloat(claimPricing.calculatedAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.allowedAmount = claimPricing.allowedAmount ? Number.parseFloat(claimPricing.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.coveredChargeAmount = claimPricing.coveredChargeAmount ? Number.parseFloat(claimPricing.coveredChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.nonCoveredChargeAmount = claimPricing.nonCoveredChargeAmount ? Number.parseFloat(claimPricing.nonCoveredChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.calculatedCoveredChargeAmount = claimPricing.calculatedCoveredChargeAmount ? Number.parseFloat(claimPricing.calculatedCoveredChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.claimPricing = claimPricing;
                let medDetails = d.medicareDetails ? d.medicareDetails : {};
                  medDetails.allowedAmount = medDetails.allowedAmount ? Number.parseFloat(medDetails.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.coInsuranceAmount = medDetails.coInsuranceAmount ? Number.parseFloat(medDetails.coInsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.deductibleAmount = medDetails.deductibleAmount ? Number.parseFloat(medDetails.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.paidAmount = medDetails.paidAmount ? Number.parseFloat(medDetails.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  d.medicareDetails = medDetails;
                d.totalChargeAmount = d.totalChargeAmount ? Number.parseFloat(d.totalChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.totalTPLAmount = d.totalTPLAmount ? Number.parseFloat(d.totalTPLAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.totalNetChargeAmount = d.totalNetChargeAmount ? Number.parseFloat(d.totalNetChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
      let payment = d.payment ? d.payment : {};
      payment.reimbursementAmount = payment.reimbursementAmount ? Number.parseFloat(payment.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
      d.payment = payment;
      if(!d.institutionalClaim.coverageAdmission){
        d.institutionalClaim.coverageAdmission = {
              "typeOfBillCode": null,
              "coveredDays": null,
              "medicalRecord": null,
              "patientStatusCode": null,
              "admitSourceCode": null,
              "admitTypeCode": null,
              "billedHours": null,
              "nonCoveredDays": null,
              "lengthOfStay": null,
              "conditionCode": [],
              "occurrenceCode": [],
              "occurrenceSpan": [],
              "surgicalProcedure": [],
              "value": [],
              "fundCode": null,
              "admitHour": null,
              "dischargeHour": null
            };         
      }
      data.data = d;
    const [spinnerLoader, setspinnerLoader] = useState(false);
    const [errorMessages, seterrorMessages] = useState([]);
    const [lineItemData, setLineItemData] = useState([]);
    const [claimEntryData, setClaimEntryData] = useState(data.data);
    const [defaultClaimEntryData, setDefaultClaimEntryData] = useState(JSON.parse(JSON.stringify(claimEntryData)));
    const [successMessages, setSuccessMessages] = useState([]);
    const [conditionCodes, setConditionCodes] = useState([]);
    const [occurrenceCodes, setOccurrenceCodes] = useState([]);
    const [occurrenceSpans, setOccurrenceSpans] = useState([]);
    const [valueCodes, setValueCodes] = useState([]);
    const [surgicalProcCodes, setSurgicalProcCodes] = useState([]);
    const [clearDiagnosis, setClearDiagnosis] = useState(false);
    const [updateDiagnosis, setUpdateDiagnosis] = useState([]);
    const [exceptionCodeList, setExceptionCodeList] = React.useState();
    const [exceptionDetail, setExceptionDetail] = useState([]);
    const [showDetails, setShowDetails] = useState(false);
    const [lineNum, setShowLineNum] = useState();
    const [showExceptionCode, setShowExceptionCode] = useState();
    const [readResolution, setReadResolution] = useState(false);
    const [adTabId, setAdTabId] = useState([]);
    const dispatch = useDispatch();
    const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
    const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
    const [quickLinks,setQuickLinks] = useState(["Claim", "Member", "Coverage & Admission", "Other Payer", "Line Items", "Payment & Provider", "Replacement / Void", "History", "Attachments", "Override Exceptions", "Additional Remarks", "Manual EOBs"]);
    const [diagnosis, setDiagnosis] = useState([]);   
    const [accidentIllnessDate, setAccidentIllnessDate] = useState(null);
    const [{billedDateErr, dobDateErr, accidentIllErr, payTotalChrgErr, payNetAmtErr,
        medAllowAmtInvErr, medDeductAmtInvErr, medCoinsAmtInvErr, medPaidAmtInvErr,medEombDateErr,
        unWorkBeginDateErr,unWorkEndDateErr,hospBeginErr,hospEndErr,outLabAmtErr, inpatientBaseRateAmtErr}, setFieldError] = useState(false);
    const [{billedDate,dateOfBitrh}, setInputDates] = useState({});
    const [prompt, setPrompt] = useState(false)
    const [cancelType, setCancelType] = useState(false);
    const [confirm, setConfirm] = useState(false);
    const [attachmentSeqNum, setAttachmentSeqNum] = useState(1);
    const [claimMainErr,setClaimMainErr] = useState({});
    const [showQuickLink, setShowQuickLink] = useState(true);
    const [updateException, setUpdateException] = useState(new Date());
    const handelPromptSet = (set) => {
        if (set)
            setPrompt(true);
      }
    useEffect(() => {
        onDropdowns([Dropdowns.VV_PROVIDER_ROLE, Dropdowns.VV_PROVIDER_ROLE_ID_TYPE, Dropdowns.PRESCRIPTION_QUALIFIER]);
        setLineItemData(data.data.enterpriseClaimLineItem);   
        let intBilledDate = data.data && data.data.billedDate ? data.data.billedDate : "";
        let intDateBirth = data.data && data.data.claimMember && data.data.claimMember.dateOfBirth ? dateFnsFormat(new Date(data.data.claimMember.dateOfBirth),"MM/dd/yyyy") : "01/01/0001";
        setInputDates({billedDate: intBilledDate, dateOfBitrh: intDateBirth});
        let max = data.data && data.data.claimAttachment && data.data.claimAttachment.length > 0 ? Math.max.apply(Math, data.data.claimAttachment.map(function(o) { return o.sequenceNumber; })) : 0;
        setAttachmentSeqNum(max + 1);
        if (data.data.relatedCauseCode1 || data.data.relatedCauseCode2 || data.data.relatedCauseCode3) {
            setAccidentIllnessDate(data.data && data.data.enterpriseClaimAux && data.data.enterpriseClaimAux.accidentDateTime ? data.data.enterpriseClaimAux.accidentDateTime : null );
          } else {
            setAccidentIllnessDate(data.data && data.data.illnessDate ? data.data.illnessDate : null);
          }  
          setDiagnosis(data.data && data.data.diagnosis ? data.data.diagnosis : []);
          setUpdateDiagnosis(data.data && data.data.diagnosis ? data.data.diagnosis : []);
          setConditionCodes(data.data && data.data.professionalClaim && data.data.professionalClaim.conditionCode ? data.data.professionalClaim.conditionCode : []);
        if (props.location.type && props.location.type == 'entry_validated' || props.location.type && props.location.type == 'correction_validated') {
            setSuccessMessages([ErrorMessageConstants.CLAIM_ENTRY_VALIDATE]);
        }
    },[]);
    useEffect(() => {

    }, [adTabId, setAdTabId]);
    const handleAdjustment = '';

    if (!data) {
        props.history.push({ pathname: '/Entry' });
    }

    const handleTabChange = (event, newValue) => {
        setTabValue(newValue);
        if(newValue == 0){
            setQuickLinks(["Claim", "Member", "Coverage & Admission", "Other Payer", "Line Items", "Payment & Provider", "Replacement / Void", "History", "Attachments", "Override Exceptions", "Additional Remarks", "Manual EOBs"]);
        }
        if(newValue == 1){
            setQuickLinks(["Provider Information", "Member Information", "Claim Information", "Basic Line Item Information"]);
        }
        if(newValue == 2){
            setQuickLinks(["Claim  Information  ", "Claim Provider Information", "Coordination of Benefits"]);
        }
        if(newValue == 3){
            setQuickLinks(["Service Line Information", "Service Line Provider Information", "Other Payer Service Line Provider Information"]);
        }
    }
    const setManualEobsValues = (val) => {
        setClaimEntryData({...claimEntryData,manualEOB:val.manualEOB?val.manualEOB:[]});
    };
    const setAdditionalRemarksValues = (val) => {
        setClaimEntryData({...claimEntryData,additionalRemark:val.additionalRemark?val.additionalRemark:[]});
    };
    const setAttachmentsValues = (val) => {
        setClaimEntryData({...claimEntryData,claimAttachment:val.attachment?val.attachment:[]});
    };
    const handelDeleteFunc = () => {
        seterrorMessages([]);
        setspinnerLoader(true);
        muiconfirm({title:"", description: 'Are you sure that you want to delete?',dialogProps: { fullWidth: false}})
        .then(() => {
            if (props.location.type && props.location.type == 'entry_validated') {
                setConfirm(true);
                props.history.push({
                    pathname: '/Entry',
                    message: ErrorMessageConstants.BENIFIT_PLAN_DELETE_SUCCESS
                });
            } else {
                let values = {
                    "tcn": data.data.tcn,
                    "statusCode": "Z",
                    "userId": data.data.userId
                }
                Axios.post(`${serviceEndPoint.CLAIM_CORRECTION_DELETE_ENDPOINT}`, values).then(res => {
                    setspinnerLoader(false);
                    setConfirm(true);                    
                    if(res.data) {
                        props.history.push({
                            pathname: '/Correction',
                            message: ErrorMessageConstants.BENIFIT_PLAN_DELETE_SUCCESS
                        });
                    }else{                             
                        seterrorMessages(['Claim Correction is not Deleted']);
                    }
                })
                .catch(e => {
                    setspinnerLoader(false);
                    seterrorMessages([ErrorMessageConstants.ERROR_OCCURED_DURING_TRANSACTION]);
                });
            }
        });
    };

    const cancelFunc = () => {
    setCancelType(true);
    if (props.location.type && props.location.type == 'entry_validated') {
        props.history.push({
            pathname: '/Entry',
            currentTab: props.location.tabValue
            });
    } else {
        props.history.push({
        pathname: '/Correction',
        currentTab: props.location.tabValue
        });
    }
  };

  const releaseLockFunc = () => {
    let values = {
        "tcnNum": claimEntryData.tcn,
      "memSysId":claimEntryData.claimMember.altMemberID,
      "userId":"Naga",
      "deleteOrSelect":true,
      "ediIndicator":false
    }
    axios.post(`${serviceEndPoint.CLAIM_CORRECTION_RELEASE_LOCK_ENDPOINT}`, values) 
};
   
    
    const correctClaim = (claimSource) => {
        const errorMessagesArray = [];        
        seterrorMessages([]);
        setSuccessMessages([]);
        setClaimMainErr({});
        if(claimEntryData.payment.overrideLocationCode || claimEntryData.overrideUserID){
        if(!claimEntryData.payment.overrideLocationCode){
            setClaimMainErr({overrideLocReq:true});
            seterrorMessages([ErrorMessageConstants.CC_OVR_LOC_REQ]);
            return false;
        }
        if(!claimEntryData.overrideUserID){
            setClaimMainErr({userIdReq:true});
            seterrorMessages([ErrorMessageConstants.CC_OVR_USR_REQ]);
            return false;
        }
        }
        setspinnerLoader(true);
        setFieldError({
            dobDateErr: dateOfBitrh && (!moment(dateOfBitrh, 'MM/DD/YYYY',true).isValid() || new Date(dateOfBitrh).toString() == "Invalid Date" ) ? (() => {errorMessagesArray.push(ErrorConst.MEMBER_DATE_ERR); return true;})() : false,
            billedDateErr: (billedDate && billedDate.toString() == "Invalid Date") || billedDate == null ? (() => {errorMessagesArray.push(ErrorConst.BILLED_DATE_ERR); return true;})() : false,
            accidentIllErr: (accidentIllnessDate && new Date(accidentIllnessDate).toString() == "Invalid Date") ? (() => {errorMessagesArray.push(ErrorConst.VISIT_ILLNESS_ERROR); return true;})() : false,
            payTotalChrgErr: claimEntryData.totalChargeAmount && (isNaN(claimEntryData.totalChargeAmount) || claimEntryData.totalChargeAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.PAYMENT_TOTAL_CHRG_ERR); return true;})() : false,
            payNetAmtErr: claimEntryData.totalNetChargeAmount && (isNaN(claimEntryData.totalNetChargeAmount) || claimEntryData.totalNetChargeAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.PAYMENT_NET_AMT_ERR); return true;})() : false,
            medAllowAmtInvErr: claimEntryData.medicareDetails.allowedAmount && (isNaN(claimEntryData.medicareDetails.allowedAmount) || claimEntryData.medicareDetails.allowedAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.MEDCAIR_ALLOW_AMT_INV); return true;})() : false,
            medDeductAmtInvErr: claimEntryData.medicareDetails.deductibleAmount && (isNaN(claimEntryData.medicareDetails.deductibleAmount) || claimEntryData.medicareDetails.deductibleAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.MEDI_DEDUCT_AMT_INV); return true;})() : false,
            medCoinsAmtInvErr: claimEntryData.medicareDetails.coInsuranceAmount && (isNaN(claimEntryData.medicareDetails.coInsuranceAmount) || claimEntryData.medicareDetails.coInsuranceAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.MEDI_COINS_AMT_INV); return true;})() : false,
            medPaidAmtInvErr: claimEntryData.medicareDetails.paidAmount && (isNaN(claimEntryData.medicareDetails.paidAmount) || claimEntryData.medicareDetails.paidAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.MEDI_PAID_AMT_INV); return true;})() : false,
            medEombDateErr: claimEntryData.payment && claimEntryData.payment.eombDate && new Date(claimEntryData.payment.eombDate).toString() == "Invalid Date" ? (() => {errorMessagesArray.push(ErrorConst.EOMB_DATE_INV); return true;})() : false,
            unWorkBeginDateErr: claimEntryData.additionalClaimData && claimEntryData.additionalClaimData.unableToWorkFromDate && new Date(claimEntryData.additionalClaimData.unableToWorkFromDate).toString() == "Invalid Date" ? (() => {errorMessagesArray.push(ErrorConst.UNABLE_WORK_BEGIN_ERR); return true;})() : false,
            unWorkEndDateErr: claimEntryData.additionalClaimData && claimEntryData.additionalClaimData.unableToWorkToDate && new Date(claimEntryData.additionalClaimData.unableToWorkToDate).toString() == "Invalid Date" ? (() => {errorMessagesArray.push(ErrorConst.UNABLE_WORK_END_ERR); return true;})() : false,
            hospBeginErr: claimEntryData.admitDateTime && new Date(claimEntryData.admitDateTime).toString() == "Invalid Date" ? (() => {errorMessagesArray.push(ErrorConst.VISIT_HOSP_BEGIN_ERR); return true;})() : false,
            hospEndErr: claimEntryData.dischargeDateTime && new Date(claimEntryData.dischargeDateTime).toString() == "Invalid Date" ? (() => {errorMessagesArray.push(ErrorConst.VISIT_HOSP_END_ERR); return true;})() : false,
            outLabAmtErr: claimEntryData.professionalClaim && claimEntryData.professionalClaim.outlabAmount && (isNaN(claimEntryData.professionalClaim.outlabAmount) || claimEntryData.professionalClaim.outlabAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.OUT_LAB_AMT_ERR); return true;})() : false,
            inpatientBaseRateAmtErr: claimEntryData.claimPricing && claimEntryData.claimPricing.baseRateAmount && (isNaN(claimEntryData.claimPricing.baseRateAmount) || claimEntryData.claimPricing.baseRateAmount < 0) ? (() => {errorMessagesArray.push(ErrorConst.INPATIENT_BASE_RATE_AMT_INV); return true;})() : false
          });
          if (errorMessagesArray.length > 0) {
            seterrorMessages(errorMessagesArray);
            setspinnerLoader(false);
            return false;
          }
          let linedataMod = JSON.parse(JSON.stringify(lineItemData));
    let submittedProviderList = [];
    let attachmentList = [];
    submittedProviderList.push(...JSON.parse(JSON.stringify(claimEntryData.claimProviderID)));
    attachmentList.push(...JSON.parse(JSON.stringify(claimEntryData.claimAttachment)));
    linedataMod.map((each) => {
        each.claimSubmittedProvider ? submittedProviderList.push(...JSON.parse(JSON.stringify(each.claimSubmittedProvider))) : submittedProviderList;
        each.attachment ? attachmentList.push(...JSON.parse(JSON.stringify(each.attachment))) : attachmentList;
    });
    const uniqueSubmittedProvider = Array.from(new Set(submittedProviderList.map(each => `${each.lineNumber}/${each.providerRoleCode}/${each.providerIDType}`)))
        .map(id => submittedProviderList.find(each => each.lineNumber == id.split('/')[0] && each.providerRoleCode == id.split('/')[1] && each.providerIDType == id.split('/')[2]));
    const uniqueAttachments = Array.from(new Set(attachmentList.map(each => each.sequenceNumber)))
        .map(id => attachmentList.find(each => each.sequenceNumber == id))
    linedataMod.map(each => {
      each.claimSubmittedProvider = uniqueSubmittedProvider.filter(e => e.lineNumber == each.lineNumber);
      each.attachment = uniqueAttachments.filter(e => e.lineNumber == each.lineNumber);
    });
    claimEntryData.enterpriseClaimLineItem = linedataMod;
    claimEntryData.claimProviderID = uniqueSubmittedProvider; 
    claimEntryData.claimAttachment = uniqueAttachments;
          claimEntryData.billedDate = billedDate && billedDate != '01/01/0001' ? billedDate : "";
          claimEntryData.claimMember.dateOfBirth = dateOfBitrh && dateOfBitrh != '01/01/0001' ? moment(dateOfBitrh.replace("/",'-')).format("YYYY-MM-DD") : "";
            claimEntryData.illnessDate = accidentIllnessDate;
        if(claimEntryData.claimProcessFields){
            claimEntryData.claimProcessFields["claimSource"] = claimSource;
        }else{
            claimEntryData.claimProcessFields = {
                "auditUserID": "test",
                "auditTimeStamp": null,
                "addedAuditUserID": "test",
                "addedAuditTimeStamp": null,
                "versionNo": 0,
                "medicareAssignmentCode": "",
                "ruleCode": "",
                "drgReturnCode": "",
                "mdcCode": "",
                "mdcTitle": "",
                "drgGrouperVersion": "",
                "drgTitle": "",
                "reimbInvocationCount": 0,
                "networkStatusCode": "",
                "spendDownLeft": 0,
                "spendDownSpanSeqNumber": 0,
                "finDataExists": false,
                "replacedClaimStatus": "",
                "adjustmentReasonCode": "",
                "faultName": "",
                "claimSourceID": "",
                "saLowerOfLogicIndicator": false,
                "pricingIdentifier": "",
                "procedureCodeSwitchIndicator": false,
                "memberLocked": false,
                "payeeCode": "",
                "submittedRemarksNotInSL": false,
                "autoAdjustment": false,
                "bundledClaim": false,
                "accidentIndicator": false,
                "billingProviderCmnEntitySK": "",
                "renderingProviderCmnEntitySK": "",
                "attendingProviderCmnEntitySK": "",
                "referringProviderCmnEntitySK": "",
                "payToProviderCmnEntitySK": "",
                "memberCmnEntitySK": "",
                "replacedMemberID": "",
                "doAdjustmentsIndicator": false,
                "gender": "",
                "systemListParamUseHeaderIndicator": false,
                "systemListParamDate": "",
                "coeCodeFlag": false,
                "patStatusFlag": false,
                "defaultLowDate": "",
                "defaultHighDate": "",
                "compoundDrugIndicator": false,
                "usedFundCodeSK": "",
                "usedClaimTypeSK": "",
                "bypassDupChkAndUR": false,
                "profitIndicator": false,
                "creditClaim": false,
                "bhConnectivityFlag": false,
                "originalClaimUserId": "",
                "claimSource": "ONLINE_VALIDATE",
                "isStaleClaim": false,
                "proceducreLTCIndicator": false
            };
            claimEntryData.claimProcessFields["claimSource"] = claimSource;
        }
        if ( props.location.type && props.location.type == 'entry_validated') {
            claimEntryData.operationType = "Save";
        } else {claimEntryData.operationType = "Update";}
        if (diagnosis.length > 0 && !claimEntryData.icdVersion) {
            claimEntryData.icdVersion = '10';
          }
        claimEntryData.diagnosis = diagnosis.filter(e => e.sequenceNumber !== null || e.sequenceNumber !== "");       
        if (claimEntryData.batchInfo.batchTypeCode == null && claimEntryData.additionalClaimData.batchTypeCode) {
            claimEntryData.batchInfo.batchTypeCode = claimEntryData.additionalClaimData.batchTypeCode;
        }
        if (claimEntryData.institutionalClaim == null) {
            claimEntryData.institutionalClaim = {};
            claimEntryData.institutionalClaim.coverageAdmission = {};
        } else if (claimEntryData.institutionalClaim && claimEntryData.institutionalClaim.coverageAdmission == null) {
            claimEntryData.institutionalClaim.coverageAdmission = {};
        }
        claimEntryData.institutionalClaim.coverageAdmission.conditionCode = conditionCodes;
        claimEntryData.institutionalClaim.coverageAdmission.occurrenceCode = occurrenceCodes;
        claimEntryData.institutionalClaim.coverageAdmission.occurrenceSpan = occurrenceSpans;
        claimEntryData.institutionalClaim.coverageAdmission.value = valueCodes;
        claimEntryData.institutionalClaim.coverageAdmission.surgicalProcedure = surgicalProcCodes;
        //increasing timeout to 5mins for testing
        Axios.post(`${serviceEndPoint.CLAIMS_INSTITUTIONAL_ENTER_CLAIM}`, claimEntryData)
          .then(response => {
            if (response.data.status === 'Success') {
                  if (claimSource == 'ONLINE_SAVE') {
                      if ( props.location.type && props.location.type == 'entry_validated') {
                        setConfirm(true);
                        claimEntryRedirect();
                      }
                      setSuccessMessages([ErrorMessageConstants.SUCCESSFULLY_SAVED_INFORMATION]);
                  }
                if (claimSource == 'ONLINE_VALIDATE') {
                    let d = JSON.parse(response.data.data)
                    let billedDate = d.billedDate ?  d.billedDate : "";
                    let DateOfBirthconst = d.claimMember ? d.claimMember.dateOfBirth ? dateFnsFormat(new Date(d.claimMember.dateOfBirth),"MM/dd/yyyy") : "01/01/0001" : "01/01/0001";
                    setInputDates({billedDate: billedDate, dateOfBitrh: DateOfBirthconst});
                    if (d.relatedCauseCode1 || d.relatedCauseCode2 || d.relatedCauseCode3) {
                        setAccidentIllnessDate(d.enterpriseClaimAux.accidentDateTime);
                      } else {
                        setAccidentIllnessDate(d.illnessDate);
                      }
                      d.claimAttachment = d.claimAttachment.filter(e => e.sequenceNumber != null);
                  d.enterpriseClaimLineItem.map(eachLine => {
                    eachLine.attachment = eachLine.attachment ? eachLine.attachment.filter(e => e.sequenceNumber != null && e.lineNumber == eachLine.lineNumber) : [];
                  });
                  d.professionalClaim.outlabAmount = d.professionalClaim.outlabAmount ? Number.parseFloat(d.professionalClaim.outlabAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.claimTPLInfo.map(eachTPLInfo => {
                  eachTPLInfo.claimTPLAmountInfo.map(eachAmount => {
                    eachAmount.allowedAmount= eachAmount.allowedAmount ? Number.parseFloat(eachAmount.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.billedAmount= eachAmount.billedAmount ? Number.parseFloat(eachAmount.billedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.coPayAmount= eachAmount.coPayAmount ? Number.parseFloat(eachAmount.coPayAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.coinsuranceAmount= eachAmount.coinsuranceAmount ? Number.parseFloat(eachAmount.coinsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.deductibleAmount= eachAmount.deductibleAmount ? Number.parseFloat(eachAmount.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.paidAmount= eachAmount.paidAmount ? Number.parseFloat(eachAmount.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                    eachAmount.patientResponsibleAmount= eachAmount.patientResponsibleAmount ? Number.parseFloat(eachAmount.patientResponsibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  });
                });
                d.enterpriseClaimLineItem.map(eachline => {
                  eachline.submitChargeAmount = eachline.submitChargeAmount ? Number.parseFloat(eachline.submitChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.submitUnits = eachline.submitUnits ? Number.parseFloat(eachline.submitUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
                  eachline.baseRateAmount = eachline.baseRateAmount ? Number.parseFloat(eachline.baseRateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.calculatedAllowedAmount = eachline.calculatedAllowedAmount ? Number.parseFloat(eachline.calculatedAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.allowedChargeAmount = eachline.allowedChargeAmount ? Number.parseFloat(eachline.allowedChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.allowedUnitQty = eachline.allowedUnitQty ? Number.parseFloat(eachline.allowedUnitQty).toFixed(1) : Number.parseFloat(0).toFixed(1);
                  eachline.tplAmount = eachline.tplAmount ? Number.parseFloat(eachline.tplAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.reimbursementAmount = eachline.reimbursementAmount ? Number.parseFloat(eachline.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.reimbursementUnits = eachline.reimbursementUnits ? Number.parseFloat(eachline.reimbursementUnits).toFixed(1) : Number.parseFloat(0).toFixed(1);
                  let medDetails = eachline.medicareDetails ? eachline.medicareDetails : {};
                  medDetails.allowedAmount = medDetails.allowedAmount ? Number.parseFloat(medDetails.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.coInsuranceAmount = medDetails.coInsuranceAmount ? Number.parseFloat(medDetails.coInsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.deductibleAmount = medDetails.deductibleAmount ? Number.parseFloat(medDetails.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.paidAmount = medDetails.paidAmount ? Number.parseFloat(medDetails.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.medicareDetails = medDetails;
                  let institutionalLineItem = eachline.institutionalLineItem ? eachline.institutionalLineItem : {};
                  institutionalLineItem.rateAmount = institutionalLineItem.rateAmount ? Number.parseFloat(institutionalLineItem.rateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  institutionalLineItem.nonCoveredAmount = institutionalLineItem.nonCoveredAmount ? Number.parseFloat(institutionalLineItem.nonCoveredAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  eachline.institutionalLineItem = institutionalLineItem;
                });
                let claimPricing = d.claimPricing ? d.claimPricing : {};
                claimPricing.grouperAllowedAmount = claimPricing.grouperAllowedAmount ? Number.parseFloat(claimPricing.grouperAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.outlierAmount = claimPricing.outlierAmount ? Number.parseFloat(claimPricing.outlierAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.drgOutlierAmount = claimPricing.drgOutlierAmount ? Number.parseFloat(claimPricing.drgOutlierAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.drgAllowedAmount = claimPricing.drgAllowedAmount ? Number.parseFloat(claimPricing.drgAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.baseRateAmount = claimPricing.baseRateAmount ? Number.parseFloat(claimPricing.baseRateAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.calculatedAllowedAmount = claimPricing.calculatedAllowedAmount ? Number.parseFloat(claimPricing.calculatedAllowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.allowedAmount = claimPricing.allowedAmount ? Number.parseFloat(claimPricing.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.coveredChargeAmount = claimPricing.coveredChargeAmount ? Number.parseFloat(claimPricing.coveredChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.nonCoveredChargeAmount = claimPricing.nonCoveredChargeAmount ? Number.parseFloat(claimPricing.nonCoveredChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                claimPricing.calculatedCoveredChargeAmount = claimPricing.calculatedCoveredChargeAmount ? Number.parseFloat(claimPricing.calculatedCoveredChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.claimPricing = claimPricing;
                let medDetails = d.medicareDetails ? d.medicareDetails : {};
                  medDetails.allowedAmount = medDetails.allowedAmount ? Number.parseFloat(medDetails.allowedAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.coInsuranceAmount = medDetails.coInsuranceAmount ? Number.parseFloat(medDetails.coInsuranceAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.deductibleAmount = medDetails.deductibleAmount ? Number.parseFloat(medDetails.deductibleAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  medDetails.paidAmount = medDetails.paidAmount ? Number.parseFloat(medDetails.paidAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  d.medicareDetails = medDetails;
                d.totalChargeAmount = d.totalChargeAmount ? Number.parseFloat(d.totalChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.totalTPLAmount = d.totalTPLAmount ? Number.parseFloat(d.totalTPLAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                d.totalNetChargeAmount = d.totalNetChargeAmount ? Number.parseFloat(d.totalNetChargeAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  let payment = d.payment ? d.payment : {};
                  payment.reimbursementAmount = payment.reimbursementAmount ? Number.parseFloat(payment.reimbursementAmount).toFixed(2) : Number.parseFloat(0).toFixed(2);
                  d.payment = payment;
                  setClearDiagnosis(false);
                  setLineItemData(d.enterpriseClaimLineItem);
                    setClaimEntryData(d);
                    setSuccessMessages([ErrorMessageConstants.CLAIM_ENTRY_VALIDATE]);
                    setUpdateException(new Date());
                  setConfirm(true);
                  props.history.push({
                    pathname: '/'
                  });                  
                  props.history.push({
                    pathname: '/InstitutionalCorrectionDetails',     
                    getClaimCorrection: {data: d},
                    type: props.location.type?props.location.type:"correction_validated",
                    batchDetails: props.location.batchDetails,
                  });
                }
            } else {
              seterrorMessages([ErrorMessageConstants.ERROR_OCCURED_DURING_TRANSACTION]);
            }
          })
          .catch(error => {
            seterrorMessages([ErrorMessageConstants.ERROR_OCCURED_DURING_TRANSACTION]);
          })
          .then(function () {
            setspinnerLoader(false);
            
          });
    };

    const claimEntryRedirect = () => {
        Axios.post(`${serviceEndPoint.CLAIMS_ENTER_DOCUMENT}`, { "batchDate":  props.location.batchDetails.batchDate, "batchNo":  props.location.batchDetails.batchNo })
        .then(response => {
            if (response.data.status == 200) {
                if (response.data.data) {
                    props.history.push({pathname:"/InstitutionalClaimEntry",state:{detail:response.data.data, batchDetails:props.location.batchDetails, type: "corrextion_success" }})
                } else {
                    setConfirm(true);
                    props.history.push({pathname:"/Entry", state: {type: "total_documents_entered"}});
                }
            }else if(response.data.status == 500 || !response.data){
                setConfirm(true);
                props.history.push({pathname:"/Entry", state: {type: "total_documents_entered"}});
            }else {
                setConfirm(true);
            props.history.push({pathname:"/Entry", state: {type: "total_documents_entered"}});
            }
        })
        .catch(error => {
            setConfirm(true);
        props.history.push({pathname:"/Entry"});
        })
    }
    const handelDocFunc = () => { 
        window.open(`/ViewDocuments`, "_blank");   
    };  
    const handelNotesFunc = () => { 
        window.open(`/Notes`, "_blank");   
    };  
    return (
        <div className="pos-relative">
            <NavigationPrompt
          when={(crntLocation, nextLocation) => {if (confirm) {return false} else {handelPromptSet(nextLocation); return true}}}
          // when={true}
      >
          {({ onConfirm, onCancel }) => (
              <Dialog
                  open={prompt}
                  aria-labelledby="alert-dialog-title"
                  aria-describedby="alert-dialog-description"
                  className="custom-alert-box"
              >
                  <DialogContent>
                  <DialogContentText id="alert-dialog-description">
                      {cancelType ? "Are you sure that you want to Cancel?" : 
                      (<>Unsaved changes will be lost. <br/>
                        Are you sure you want to continue?</>)}
                  </DialogContentText>
                  </DialogContent>
                  {cancelType ? (<DialogActions>
                      <Button onClick={() => {onConfirm(); releaseLockFunc()}} color="primary" className="btn btn-success">
                          Ok
                      </Button>
                      <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" autoFocus>
                          Cancel
                      </Button>
                  </DialogActions>) : (<DialogActions>
                      <Button onClick={() => {setPrompt(false); setCancelType(false); onCancel()}} color="primary" className="btn btn-transparent">
                      STAY ON THIS PAGE!
                      </Button>
                      <Button onClick={onConfirm} color="primary" className="btn btn-success" autoFocus>
                      CONTINUE <i className="fa fa-arrow-right ml-1"></i>
                      </Button>
                  </DialogActions>)}
              </Dialog>
          )}
      </NavigationPrompt>
            {spinnerLoader
                ? <Spinner />
                : null}
            {/* {errorMessages.length
                ? (
                    <div className="alert alert-danger custom-alert" role="alert">
                        {errorMessages.map(message => <li>{message}</li>)}
                    </div>
                )
                : null
            }
            {successMessages.length > 0 ? (
        <div className="alert alert-success custom-alert" role="alert">
          {successMessages.map(message => <li>{message}</li>)
          }
        </div>
      ) : null} */}
      { successMessages.length > 0 ? (<SuccessComponent successMessages={successMessages} setSuccessMessages={setSuccessMessages} />) : null}
      { errorMessages.length > 0 ? (<ErrorComponent errorMessages={errorMessages} setErrorMessages={seterrorMessages} />) : null}
            <div className="mb-2">
                <BreadCrumbs
                    parent="Claims"
                    child1="Claim Correction"
                    path="Correction"
                />
            </div>

            <div className="tabs-container">
                <div className="tab-header claim-btnarea-bdr pb-2 mb-3">
                    <h1 className="page-heading float-left"> Internal Claim Correction - Institutional </h1>
                    <div className="float-right th-btnGroup">
                        <Button title="Save &amp; Submit" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={()=>{correctClaim("ONLINE_SAVE")}} disabled={props.privileges && !props.privileges.update? 'disabled':''}> Save &amp; Submit</Button>
                        <Button title="Validate" variant="outlined" color="primary" className="btn btn-ic btn-validate" onClick={()=>{correctClaim("ONLINE_VALIDATE")}}> Validate</Button>
                        <Button title="Notes" variant="outlined" color="primary" className="btn btn-ic btn-notes" onClick={() => handelNotesFunc()}> Notes </Button>
                        <Button title="View Documents" className="btn btn-ic btn-view"  onClick={() => handelDocFunc()}>View Documents</Button>
                        <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => handelDeleteFunc()} disabled={props.privileges && !props.privileges.update? 'disabled':''}>Delete</Button>
                        <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => {setClaimEntryData({...defaultClaimEntryData});}}>Reset</Button>
                        <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => cancelFunc()} > Cancel</Button>
                        <Button title="Print" className="btn btn-ic btn-print">Print </Button>
                        <Button title="Help" className="btn btn-ic btn-help"> Help</Button>
                    </div>
                </div>
                <div className="clm-inquiry-tabData pull-left">
                    <div className="tab-body-bordered my-2">
                        <div className='tab-holder custom-tabber pb-3'>
                            <AppBar position='static' color="default">
                                <Tabs value={tabValue} onChange={handleTabChange}
                                    indicatorColor="primary"
                                    textColor="primary"
                                    variant="scrollable"
                                    scrollButtons="auto"
                                    aria-label='simple tabs example'
                                >
                                    <Tab title="Main" label="Main" {...a11yProps(0)} />
                                    <Tab title="Basic Claim Info" label="Basic Claim Info"{...a11yProps(1)} onClick={() => setShowQuickLink(true)} />
                                    <Tab title="Other Claim Info" label="Other Claim Info" {...a11yProps(2)} onClick={() => setShowQuickLink(true)} />
                                    <Tab title="Other Service Info" label="Other Service Info" {...a11yProps(3)} onClick={() => setShowQuickLink(false)} />
                                </Tabs>
                            </AppBar>
                            <TabPanel value={tabValue} index={0}>
                                <div id="Claim Div Id">
                                    <Claim
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} history={props.history}
                                        claimMainErr={claimMainErr}/>
                                </div>
                                <div id="Member Div Id">
                                    <Member
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} 
                                        dates={{billedDate,dateOfBitrh}} setInputDates={setInputDates}
                                        errors={{dobDateErr}}
                                      />
                                </div>
                                <div id="Coverage & Admission Div Id">
                                    <CoverageAdmissionMain
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData}
                                        setConditionCodes={setConditionCodes}
                                        setOccurrenceCodes={setOccurrenceCodes}
                                        setOccurrenceSpans={setOccurrenceSpans}
                                        setValueCodes={setValueCodes}
                                        addDropdowns={addDropdowns}
                                        seterrorMessages={seterrorMessages}/>
                                </div>
                                <div id="Other Payer Div Id">
                                    <OtherPayer
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} 
                                        seterrorMessages={seterrorMessages} 
                                        setsuccessMessages = {setSuccessMessages}
                                        type="correction"/>
                                </div>
                                <div id="Diagnosis & Procedure Code Div Id">
                                    <DiagnosisAndProcedureCodes
                                    data={claimEntryData}
                                    setClaimEntryData={setClaimEntryData}
                                    diagnosis={diagnosis} setDiagnosis={setDiagnosis}
                                    setSurgicalProcCodes={setSurgicalProcCodes}
                                    clearDiagnosis={clearDiagnosis} setClearDiagnosis={setClearDiagnosis}
                                    updateDiagnosis={updateDiagnosis}
                                    addDropdowns={addDropdowns}
                                    seterrorMessages={seterrorMessages}
                                    />
                                </div>
                                <div id="Line Items Div Id">
                                    <LineItems lineItemData={lineItemData} headerSubmittedProvider={claimEntryData.claimProviderID} setLineItemData={setLineItemData} seterrorMessages={seterrorMessages} addDropdowns={addDropdowns} type="correction"
                                    attachmentSeqNum={attachmentSeqNum} setAttachmentSeqNum={setAttachmentSeqNum}
                                    setsuccessMessages={setSuccessMessages} mainData={claimEntryData}
                                    setClaimEntryData={setClaimEntryData} />
                                </div>
                                <div id="Payments & Provider Div Id">
                                    <PaymentProvider
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData} seterrorMessages={seterrorMessages}
                                        lineItemDate={lineItemData} setLineItemData={setLineItemData}
                                        dates={{billedDate,dateOfBitrh}} setInputDates={setInputDates}
                                        errors={{billedDateErr, payTotalChrgErr, payNetAmtErr, medAllowAmtInvErr, medDeductAmtInvErr, medCoinsAmtInvErr, medPaidAmtInvErr,medEombDateErr}}
                                        setsuccessMessages={setSuccessMessages}/>
                                </div>
                                <div id="Inpatient Pricing Div Id">
                                    <InpatientPricing
                                    data={claimEntryData}
                                    setClaimEntryData={setClaimEntryData}
                                    errors={{inpatientBaseRateAmtErr}} type="correction" />
                                </div>
                                <div id="Replacement/Void Div Id">
                                    <ReplacementVoids
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData}
                                        onSearchParent={handleAdjustment} />
                                </div>
                                <div id="History Div Id">
                                    <History 
                                        data={claimEntryData}
                                        setClaimEntryData={setClaimEntryData}
                                        onSearchParent={handleAdjustment}
                                        adTabId={adTabId}
                                        setAdTabId={setAdTabId}
                                        setTabValue={setTabValue} 
                                    />                                   
                                </div>
                                <div className="pos-relative">
                                    <div className="tabs-container custom-panel">
                                        <div className='tab-holder CustomExpansion-panel my-3'>
                                            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                                <ExpansionPanelSummary
                                                    expandIcon={<ExpandMoreIcon />}
                                                    aria-controls="tpl-summary"
                                                    id="expansion-panel-tpl-summary">
                                                    <Typography className={classes.heading}> Additional Details</Typography>
                                                </ExpansionPanelSummary>
                                                <ExpansionPanelDetails>
                                                    <div id="Attachments Div Id">
                                                        <AttachmentsComponent attachmentSeqNum={attachmentSeqNum} setAttachmentSeqNum={setAttachmentSeqNum} values={{"attachment":claimEntryData?claimEntryData.claimAttachment?claimEntryData.claimAttachment:[]:[]}} setValues={setAttachmentsValues} seterrorMessages={seterrorMessages} usedFor="additionalDetails"/>
                                                    </div>
                                                    <div id="Override Exception Div Id">
                                                        <OverrideException data={claimEntryData} setClaimEntryData={setClaimEntryData} seterrorMessages={seterrorMessages} claimType="correction"/>
                                                    </div>
                                                    <div id="Additional Remarks Div Id">
                                                        <AdditionalRemarksComponent values={{"additionalRemark":claimEntryData?claimEntryData.additionalRemark?claimEntryData.additionalRemark:[]:[]}} setValues={setAdditionalRemarksValues} seterrorMessages={seterrorMessages} />
                                                    </div>
                                                    <div id="Manual Eobs Div Id">
                                                        <ManualEobsComponent values={{"manualEOB":claimEntryData?claimEntryData.manualEOB?claimEntryData.manualEOB:[]:[]}} setValues={setManualEobsValues} seterrorMessages={seterrorMessages} />
                                                    </div>
                                                </ExpansionPanelDetails>
                                            </ExpansionPanel >
                                        </div>
                                    </div>
                                </div>
                            </TabPanel>
                            <TabPanel value={tabValue} index={1}>
                                <BasicClaimInfo data={claimEntryData}  setClaimEntryData={setClaimEntryData} />
                            </TabPanel>
                            <TabPanel value={tabValue} index={2}>
                                <OtherClaimInfo  data={claimEntryData} />
                            </TabPanel>
                            <TabPanel value={tabValue} index={3}>
                                <OtherServicesInfo data={claimEntryData}  setClaimEntryData={setClaimEntryData} />
                            </TabPanel>
                        </div>
                    </div>
                </div>
                <div className="clm-inquiry-exceptionData pull-left mb-3">
                    <ExceptionView value = {claimEntryData} setClaimEntryData={setClaimEntryData} updateException={updateException} correctClaim= {() => correctClaim("ONLINE_VALIDATE")}/>
                    {/* <div className="clm-inquiry-exceptionData pull-left"> */}
                    {showQuickLink ? (
                    <QuickLinks links={quickLinks} enableExpand={true} />
                    ) : null }
                    {/* </div> */}
                    <div className="clearfix"></div>
                </div>
                <div className="clearfix"></div>
            </div>
        </div>
    );

}

export default ClaimCorrectionDetails;