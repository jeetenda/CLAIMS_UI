import React, { useState } from 'react';
import { withRouter } from 'react-router';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../../SharedModules/Table/Table';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import TextField from '@material-ui/core/TextField';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from '@material-ui/core/InputAdornment';
import Alert from '@material-ui/lab/Alert';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
    small: {
        width: theme.spacing(3),
        height: theme.spacing(3),
    },
    txtfullwidth: {
        width: '100%',
    }
}));

function OtherServicesInfo(props) {
    const classes = useStyles();

    const [lineItemNum, setLineItemNum] = useState(1);
    const claimsInfo = props?.data?.enterpriseClaimAux?.c837ClaimHdr || {};

    // const data = lineItemOtherServiceMap[lineItemNum] ? lineItemOtherServiceMap[lineItemNum] : {};
    // const contactInfoVOList = contactInfoMap[lineItemNum] && contactInfoMap[lineItemNum].contactInfoVOList ? contactInfoMap[lineItemNum].contactInfoVOList : [];
    const serviceInfodates = claimsInfo?.c837SpecializedService?.c837ProfessionalLineItems || {};
    const miscellaneousLineInfoVO = claimsInfo?.c837ServiceLineItems[0] || {};
    const claimPricingData = claimsInfo?.c837ServiceLineItems[0]?.repricedClaimInfo || {};
    const claimAttachments = [claimsInfo?.c837Attachments] || [];
    const renderingProviderInfo = claimsInfo?.c837LineItemProviders[0]?.renderingProvider?.providerName || {};
    const secIDsData = props?.data?.claimProviderID || [];
    const referringProviderInfo = claimsInfo?.c837LineItemProviders[0]?.referringProvider1?.ProviderName || {};
    const operatingProviderInfo = claimsInfo?.c837ClaimProvider?.operatingProvider || {};
    const otherOperatingProviderInfo = claimsInfo?.c837LineItemProviders[0]?.otherProvider || {};
    const attendingProviderInfo = claimsInfo?.c837LineItemProviders[0]?.attendingProvider || {};
    const orderingProviderInfoList = [claimsInfo?.c837LineItemProviders[0]?.orderingProvider] || [];
    var cobClaimTplSequenceNumber = [props?.data?.claimTPLInfo[0]] || []
    const coboOtherPayerInsuranceList = [claimsInfo?.c837OtherPayerAdjustments[0]] || [];

    const serviceLineSeqNum = props?.data?.claimTPLInfo[0] || {};
    console.log("testtin-------------------------")
    console.log(serviceLineSeqNum?.sequenceNumber || '')

    const serviceLineAdjudication = claimsInfo?.c837OtherPayerAdjustments[0] || {};
    console.log(serviceLineAdjudication)
    const lineLevelAdjudicationList = props?.data?.claimAdjustmentReasons || [];
    const submittedProvidersData = props?.data?.otherPayerSubmittedProviderIDs || [];
    var j = coboOtherPayerInsuranceList.length;
    var coordinationOfBenefitInformation = [];
    if(coboOtherPayerInsuranceList.length > 0 && cobClaimTplSequenceNumber.length > 0){  
        for(var i=0;i<j;i++){      
            coordinationOfBenefitInformation.push({
                'paidUnitCount': coboOtherPayerInsuranceList[i]?.paidUnitCount || '',
                'otherPayerID': coboOtherPayerInsuranceList[i]?.otherPayerID || '',
                'serviceCode': coboOtherPayerInsuranceList[i]?.serviceCode || '',
                'otherPayerPaidAmount': coboOtherPayerInsuranceList[i]?.otherPayerPaidAmount.toFixed(2) || '',
                'sequenceNumber': cobClaimTplSequenceNumber[i]?.sequenceNumber || '',
                'otherPayerPaidDate': coboOtherPayerInsuranceList[i]?.otherPayerPaidDate || ''
            })
        }
        
    }

    const supervisingProviderInfo = claimsInfo && claimsInfo.c837LineItemProviders && claimsInfo.c837LineItemProviders.length > 0 && claimsInfo.c837LineItemProviders[0].SupervisingProvider ? claimsInfo.c837LineItemProviders[0].SupervisingProvider.ProviderName : {};
    // const durableMedicalEquipment = claimsInfo && claimsInfo.c837SpecializedService && claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].dmercInfo ? claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].dmercInfo : {};
    const oxygenTherapy = claimsInfo && claimsInfo.c837SpecializedService && claimsInfo.c837SpecializedService.c837ProfessionalLineItems && claimsInfo.c837SpecializedService.c837ProfessionalLineItems.length > 0 && claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].oxygenTherapy
        ? claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].oxygenTherapy : {};
    const serviceInfoAmbulance = claimsInfo && claimsInfo.c837SpecializedService && claimsInfo.c837SpecializedService.c837ProfessionalLineItems && claimsInfo.c837SpecializedService.c837ProfessionalLineItems.length > 0 && claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].ambulanceInfo
        ? claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].ambulanceInfo : {};
    const serviceInfoAmbulancePickUp = claimsInfo && claimsInfo.c837ServiceLineItems && claimsInfo.c837ServiceLineItems.length > 0 && claimsInfo.c837ServiceLineItems[0].ambulancePickupLocation && claimsInfo.c837ServiceLineItems[0].ambulancePickupLocation.address
        ? claimsInfo.c837ServiceLineItems[0].ambulancePickupLocation.address : {};
    const serviceInfoAmbulanceDropOff = claimsInfo && claimsInfo.c837ServiceLineItems && claimsInfo.c837ServiceLineItems.length > 0 && claimsInfo.c837ServiceLineItems[0].ambulanceDropoffLocation&& claimsInfo.c837ServiceLineItems[0].ambulanceDropoffLocation.address
        ? claimsInfo.c837ServiceLineItems[0].ambulanceDropoffLocation.address : {};

    const serviceInfoSpinalInfo = claimsInfo && claimsInfo.c837SpecializedService && claimsInfo.c837SpecializedService.c837ProfessionalLineItems && claimsInfo.c837SpecializedService.c837ProfessionalLineItems.length > 0 && claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].spinalPatientInfo
        ? claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].spinalPatientInfo : {};
    const testDataResults = claimsInfo && claimsInfo.c837SpecializedService && claimsInfo.c837SpecializedService.c837ProfessionalLineItems && claimsInfo.c837SpecializedService.c837ProfessionalLineItems.length > 0 && claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].testInfo
        ? claimsInfo.c837SpecializedService.c837ProfessionalLineItems[0].testInfo : {};
    const serviceLineAdjudicationList = claimsInfo && claimsInfo.c837OtherPayerAdjustments ? claimsInfo.c837OtherPayerAdjustments : [];
    
    
    
    const otherPayerSA = claimsInfo && claimsInfo.c837LineItemProviders && claimsInfo.c837LineItemProviders.length > 0 && claimsInfo.c837LineItemProviders[0].otherPayer1 ? claimsInfo.c837LineItemProviders[0].otherPayer1 : {};
    const otherPayerSACellsList = claimsInfo && claimsInfo.c837LineItemProviders && claimsInfo.c837LineItemProviders.length > 0 && claimsInfo.c837LineItemProviders[0].otherPayer1 ? claimsInfo.c837LineItemProviders[0].otherPayer1.priorAuthorizationInfoA : [];
    const characterRemaining = miscellaneousLineInfoVO?.thridPartyOrgRepricedNoteText || 80;
    const [showViewOtherPayer, setShowViewOtherPayer] = useState(false);
    const [LLAData, setLLAData] = useState({});
    const [showLLA, setShowLLA] = useState(false);
    const serviceLineAttachment = [
        {
            id: 'priorAuthQualifierCode', numeric: false, disablePadding: false, label: 'Type Attachment', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'priorAuthID', numeric: false, disablePadding: false, label: 'Delivery Method', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'priorAuthID', numeric: false, disablePadding: false, label: 'Attachment Control#', enableHyperLink: false, fontSize: 12
        }
    ];
    const otherPayerSACells = [
        {
            id: 'priorAuthQualifierCode', numeric: false, disablePadding: false, label: 'Number Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'priorAuthID', numeric: false, disablePadding: false, label: 'SA or Referral Number', enableHyperLink: false, fontSize: 12
        }
    ];
    const serviceLineAdjustmentVOListCells = [
        {
            id: 'adjustmentGroupCode', numeric: false, disablePadding: true, label: 'Claim Adjustment Group Code', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'adjustmentReasonCode', numeric: false, disablePadding: false, label: 'Reason Code', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'adjustmentReasonAmount', numeric: false, disablePadding: false, label: 'Amount', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'adjustmentUnitQuantity', numeric: false, disablePadding: false, label: 'Quantity', enableHyperLink: false, fontSize: 12
        }
    ];
    const testResultLineItemVOListCells = [
        {
            id: 'testMeasurementID', numeric: false, disablePadding: true, label: 'Test Measurement ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'testMeasurementQual', numeric: false, disablePadding: false, label: 'Test measurement Qualifier', enableHyperLink: false, fontSize: 12
        }, {
            id: 'testResult', numeric: false, disablePadding: true, label: 'Test Result', enableHyperLink: false, fontSize: 12
        }
    ];
    const OtherPayerSeriveInfoCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: 'Sequence Number', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'otherPayerID', numeric: false, disablePadding: false, label: 'Other Payer Primary ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'serviceCode', numeric: false, disablePadding: false, label: 'Procedure Code', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'paidUnitCount', numeric: false, disablePadding: false, label: 'Paid Service Unit Count', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerPaidAmount', numeric: false, disablePadding: false, label: 'Service Line Paid Amount', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerPaidDate', numeric: false, disablePadding: false, label: 'Adjudicated or Pay Date', enableHyperLink: false, fontSize: 12
        }
    ];

    const SecIDs = [
        {
            id: 'providerIDType', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12
        }
    ];
    const ContactInfoCells = [
        {
            id: 'contactName', numeric: false, disablePadding: true, label: 'Name', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'communicationNumber1', numeric: false, disablePadding: false, label: 'Phone / Ext.', enableHyperLink: false, fontSize: 12, width: 200
        },
        {
            id: 'communicationQualifierCode1', numeric: false, disablePadding: false, label: 'Fax', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'email', numeric: false, disablePadding: false, label: 'Email', enableHyperLink: false, fontSize: 12
        }
    ];
    const previousLineItem = () => {
        if (lineItemNum == 1) {
            return false;
        }
        setLineItemNum(lineItemNum - 1);
    };
    const nextLineItem = () => {
        if (lineItemNum == Object.keys(lineItemOtherServiceMap).length) {
            return false;
        }
        setLineItemNum(lineItemNum + 1);
    };
    const viewOtherInfo = row => (event) => {
        setShowViewOtherPayer(true);
    };
    const viewLLA = row => (event) => {
        setLLAData(row);
        console.log(LLAData)
        setShowLLA(true);
    };
    return (
        <div>
            <div className='tabs-container my-3'>
                <div className='tab-header'>
                    <h1 className="tab-heading float-left">Line #{serviceInfodates.lineNumber}</h1>
                    <div className="float-right th-btnGroup">
                        <Button variant="outlined" color="primary" className="btn btn-primary" onClick={previousLineItem}>
                            <i className="fa fa-arrow-left" />
                    Previous
                </Button>
                        <Button variant="outlined" color="primary" className="btn btn-primary" onClick={nextLineItem}>
                            Next
                     <i className="fa fa-arrow-right ml-1" />
                        </Button>
                    </div>
                </div>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3'>
                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panelp1a-content1"
                            id="panelp1a-header1">
                            <Typography className={classes.heading}>Service Line Information</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>


                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header26893">
                                    <Typography className={classes.heading}>Miscellaneous Line Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="lineItemControl#"
                                                label="Line Item Control #"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.controlNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Repriced Line Item"
                                                label="Repriced Line Item Reference Number"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.repriceReferenceNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="salestaxamount"
                                                label="Adjusted Repriced Line Item Reference Number"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.adjustedRepriceReferenceNumber || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="approvedamount"
                                                label="Procedure Description"
                                                placeholder=""
                                                value={miscellaneousLineInfoVO?.procedureCodeDescription || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                           
                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header3">
                                    <Typography className={classes.heading}>Claims Pricing/Repricing</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                    <div className="form-wrapper wrap-form-label">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="pricingmethodologycode"
                                                label="Pricing Methodology Code"
                                                placeholder=""
                                                value={claimPricingData?.methodologyCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serallowedamount"
                                                label="Allowed Amount"
                                                placeholder=""
                                                value={claimPricingData?.repriceAllowedAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="sersavingsamount"
                                                label="Savings Amount"
                                                placeholder=""
                                                value={claimPricingData?.savingsAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorganizationidentifier"
                                                label="Organization Identifier"
                                                placeholder=""
                                                value={claimPricingData?.organizationID || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serperdiemorflatrateamnt"
                                                label="Per Diem or Flat Rate Amount"
                                                placeholder=""
                                                value={claimPricingData?.repricePerDiemRate || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprvddrgcode"
                                                label="Approved APG Code"
                                                placeholder=""
                                                value={claimPricingData?.repriceAPGCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprvdrgamnt"
                                                label="Approved APG Amount"
                                                placeholder=""
                                                value={claimPricingData?.repriceAPGAmount || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                                InputProps={{
                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="repricedaprvdsrvccode"
                                                label="Approved Revenue Code"
                                                placeholder=""
                                                value={claimPricingData?.revenueCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprunitqunty"
                                                label="Procedure Service Qualifier Code"
                                                placeholder=""
                                                value={claimPricingData?.serviceQualifierCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprunitqunty"
                                                label="Procedure Service Code"
                                                placeholder=""
                                                value={claimPricingData?.serviceCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprunitqunty"
                                                label="Approved Unit Basis of Measurement Code"
                                                placeholder=""
                                                value={claimPricingData?.unitCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seraprunitqunty"
                                                label="Approved Service Units"
                                                placeholder=""
                                                value={claimPricingData?.unitQuantity || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrjectionrsncode"
                                                label="Rejection Reason Code"
                                                placeholder=""
                                                value={claimPricingData?.rejectReasonCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serpolicycompliancecode"
                                                label="Policy Compliance Code"
                                                placeholder=""
                                                value={claimPricingData?.policyComplianceCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serexceipitoncode"
                                                label="Exception Code"
                                                placeholder=""
                                                value={claimPricingData?.exceptionCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>Third Party Organization Notes</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                
                                <div className="form-wrapper">                                        
                                            <div className="mui-custom-form input-md field-xl">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="dddwdsghsgtertrSD"
                                                    id="dddwdsghsgtertrSD-label">Note Text</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    aria-label="minimum-height"
                                                    id="claim_notes"
                                                    placeholder=""
                                                    value={miscellaneousLineInfoVO?.thridPartyOrgRepricedNoteText || ""}
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                                </div>
                                                <div className="mt-1"><Chip avatar={<Avatar>{characterRemaining&&characterRemaining.length ? 80-characterRemaining.length : 80}</Avatar>} label="Characters remaining" /></div>
                                            </div>
                                        </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header36913">
                                    <Typography className={classes.heading}>Service Line Attachment</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="tabs-container mt-2">
                                        {/* <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div> */}
                                        <TableComponent headCells={serviceLineAttachment} tableData={claimAttachments} onTableRowClick={() => { return false; }} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>

                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panelp1a-content2"
                            id="panelp1a-header27902">
                            <Typography className={classes.heading}>Service Line Provider Information</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content3"
                                    id="panelp1a-header36913">
                                    <Typography className={classes.heading}>Rendering Provider</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={renderingProviderInfo?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={renderingProviderInfo?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi"
                                                label="MI"
                                                placeholder=""
                                                value={renderingProviderInfo?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={renderingProviderInfo?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>



                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={secIDsData} onTableRowClick={() => { return false; }} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header27902">
                                    <Typography className={classes.heading}>Referring Provider </Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={referringProviderInfo?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={referringProviderInfo?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi"
                                                label="MI"
                                                placeholder=""
                                                value={referringProviderInfo?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={referringProviderInfo?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>



                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={secIDsData} onTableRowClick={() => { return false; }} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header279034432">
                                    <Typography className={classes.heading}>Operating Physician Information</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    {/* <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Additional Primary Care Provider Information </h2>
                                        </div> */}
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={operatingProviderInfo?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={operatingProviderInfo?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi"
                                                label="MI"
                                                placeholder=""
                                                value={operatingProviderInfo?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={operatingProviderInfo?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>


                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={secIDsData} onTableRowClick={() => { return false; }} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header279034432">
                                    <Typography className={classes.heading}>Other Operating Physician</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>

                                    {/* <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Additional Purchased Service Provider Information </h2>
                                        </div> */}
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entityqulifserorgorlastname"
                                                label="Entity Qualifier"
                                                placeholder=""
                                                value={otherOperatingProviderInfo?.entityTypeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serorgorlastname"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={otherOperatingProviderInfo?.providerName?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="otherserfirstname"
                                                label="First Name"
                                                placeholder=""
                                                value={otherOperatingProviderInfo?.providerName?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersermi"
                                                label="MI"
                                                placeholder=""
                                                value={otherOperatingProviderInfo?.providerName?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="othersersuffux"
                                                label="Suffix"
                                                placeholder=""
                                                value={otherOperatingProviderInfo?.providerName?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>

                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={secIDsData} onTableRowClick={() => { return false; }} defaultSortColumn="idtype" />
                                    </div>
                                </ExpansionPanelDetails>
                            </ExpansionPanel>



                            <ExpansionPanel className="collapsable-panel">
                                <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content2"
                                    id="panelp1a-header279477502">
                                    <Typography className={classes.heading}>Attending Provider</Typography>
                                </ExpansionPanelSummary>
                                <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entityqulifserorgorlastname"
                                                label="Entity Qualifier"
                                                placeholder=""
                                                value={attendingProviderInfo?.entityTypeCode || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrorglastnam11e"
                                                label="Org / Last Name"
                                                placeholder=""
                                                value={attendingProviderInfo?.providerName?.lastName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrrotherserfirstname1"
                                                label="First Name"
                                                placeholder=""
                                                value={attendingProviderInfo?.providerName?.firstName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="seeerotherserm1i"
                                                label="MI"
                                                placeholder=""
                                                value={attendingProviderInfo?.providerName?.middleName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="serrrothersersuffux1"
                                                label="Suffix"
                                                placeholder=""
                                                value={attendingProviderInfo?.providerName?.suffixName || ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>                                       
                                        </div>
                                       


                                    <div className="tabs-container mt-2">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left"> Secondary ID </h2>
                                        </div>
                                        <TableComponent headCells={SecIDs} tableData={secIDsData} onTableRowClick={() => { return false; }} defaultSortColumn="idtype" />
                                    </div>

                                </ExpansionPanelDetails>
                            </ExpansionPanel>

                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>

                <div className='tab-holder CustomExpansion-panel my-3'>
                    <ExpansionPanel className="collapsable-panel">
                        <ExpansionPanelSummary
                            expandIcon={<ExpandMoreIcon />}
                            aria-controls="panelp1a-content4"
                            id="panelp1a-header4412902">
                            <Typography className={classes.heading}>Other Payer Service Line Provider Information</Typography>
                        </ExpansionPanelSummary>
                        <ExpansionPanelDetails>
                            <div className="tabs-container">
                                <div className="tab-header">
                                    <h2 className="tab-heading float-left"> Other Payer Service Information</h2>
                                </div>
                                <TableComponent headCells={OtherPayerSeriveInfoCells} tableData={coordinationOfBenefitInformation} onTableRowClick={viewOtherInfo} defaultSortColumn="groupCode" />
                                {showViewOtherPayer ? (
                                    <div className="tabs-container mt-3">
                                        <div className="tab-header">
                                            <h2 className="tab-heading float-left">
                                                View Other Payer Service Information
                                        </h2>
                                            <div className="float-right th-btnGroup">
                                                <Button variant="outlined" color="primary" className="btn btn-primary" onClick={() => { setShowViewOtherPayer(false); }}>
                                                    Close
                                            </Button>
                                            </div>
                                        </div>
                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content13"
                                                id="panelp1a-heaf5fgder13">
                                                <Typography className={classes.heading}>Service Line Adjudication</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="form-wrapper">
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="serorseqgorlastname"
                                                            label="Sequence Number"
                                                            placeholder=""
                                                            value={serviceLineSeqNum?.sequenceNumber || ''}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="dddesd"
                                                            label="Other Payer Primary ID"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.otherPayerID || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="othe3srsermi"
                                                            label="Service Line Paid Amount"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.otherPayerPaidAmount || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                                        <div className="mui-custom-form input-md with-select">
                                                            <KeyboardDatePicker
                                                                disabled
                                                                id="DatesdaLastsdfSeen"
                                                                label="Adjudicated or Pay Date"
                                                                format="MM/dd/yyyy"
                                                                InputLabelProps={{
                                                                    shrink: true
                                                                }}
                                                                placeholder="mm/dd/yyyy"
                                                                value={
                                                                    serviceLineAdjudication?.otherPayerPaidDate || null
                                                                }
                                                                KeyboardButtonProps={{
                                                                    "aria-label": "change date"
                                                                }}
                                                            />
                                                        </div>
                                                    </MuiPickersUtilsProvider>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="dgftr45fg"
                                                            label="Paid Service Unit Count"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.paidUnitCount || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="dgf5grttr45fg"
                                                            label="Bundled Line Number"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.bundlingLineNumber || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <div className="form-wrapper">
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="asdfn454fgh"
                                                            label="Procedure Qualifier"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.serviceQualifierCode || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="44456nfgh"
                                                            label="Procedure Code"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.serviceCode || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="othesdfg4d3srsermi"
                                                            label="Procedure Code Description"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.serviceDescription || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                        />
                                                    </div>

                                                </div>
                                                <div className="form-wrapper">
                                                    <div className="tab-header w-100 ml-2"><h2 className="tab-heading float-left">Procedure Code</h2></div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="Zipasdf"
                                                            label=" Modifier 1"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.procedureModifier1 || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            // InputProps={{
                                                            //     startAdornment: <InputAdornment position="start">1</InputAdornment>,
                                                            // }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="ZipdsandasEx2tension1"
                                                            label="Modifier 2"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.procedureModifier2 || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            // InputProps={{
                                                            //     startAdornment: <InputAdornment position="start">2</InputAdornment>,
                                                            // }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="ZipdsandasExt3ension1"
                                                            label="Modifier 3"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.procedureModifier3 || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            // InputProps={{
                                                            //     startAdornment: <InputAdornment position="start">3</InputAdornment>,
                                                            // }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="ZipdsandasEx4tension1"
                                                            label="Modifier 4"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.procedureModifier4 || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            // InputProps={{
                                                            //     startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                            // }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="Revenue_Code"
                                                            label="Revenue Code"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.revenueCode || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            // InputProps={{
                                                            //     startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                            // }}
                                                        />
                                                    </div>
                                                    <div className="mui-custom-form input-md">
                                                        <TextField
                                                            disabled
                                                            id="asdrffn454fgh"
                                                            label="Remaining Patient Liability"
                                                            placeholder=""
                                                            value={serviceLineAdjudication?.remainingPatientLiabilityAmount || ""}
                                                            InputLabelProps={{
                                                                shrink: true,
                                                            }}
                                                            InputProps={{
                                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                                    <ExpansionPanelSummary
                                                        expandIcon={<ExpandMoreIcon />}
                                                        aria-controls="panelp1a-content13"
                                                        id="panesr34lp1a-header13">
                                                        <Typography className={classes.heading}>Service Adjustment</Typography>
                                                    </ExpansionPanelSummary>
                                                    <ExpansionPanelDetails>
                                                        <div className="tabs-container mt-2">
                                                            <div className="tab-header">
                                                                <h2 className="tab-heading float-left"> Line Level Adjustments </h2>
                                                            </div>
                                                            <TableComponent headCells={serviceLineAdjustmentVOListCells} tableData={lineLevelAdjudicationList} onTableRowClick={viewLLA} defaultSortColumn="idtype" />
                                                            {showLLA ?
                                                                <div className="tabs-container">
                                                                    <div className="tab-header">
                                                                        <h2 className="tab-heading float-left">
                                                                            View Line Level Adjustments
                                            </h2>
                                                                        <div className="float-right th-btnGroup">
                                                                            <Button variant="outlined" color="primary" className="btn btn-primary" onClick={() => { setShowLLA(false); }}>
                                                                                Close
                                                </Button>
                                                                        </div>
                                                                    </div>
                                                                    <div className="set-form-wrapper">
                                                                    <div className="form-wrapper wrap-form-label">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="serorseqgorlasrtname"
                                                                                label="Claim Adjustment Group Code"
                                                                                placeholder=""
                                                                                value={LLAData?.adjustmentGroupCode || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="ffesdf"
                                                                                label="Reason Code"
                                                                                placeholder=""
                                                                                value={LLAData?.adjustmentReasonCode || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf3sermi"
                                                                                label="Amount"
                                                                                placeholder=""
                                                                                value={LLAData?.adjustmentReasonAmount || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4rf5fg"
                                                                                label="Quantity"
                                                                                placeholder=""
                                                                                value={LLAData?.adjustmentUnitQuantity || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                    required: true
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="ffesd4fgf"
                                                                                label="Reason Code 2"
                                                                                placeholder=""
                                                                                value={LLAData?.reason2 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf3srseermi"
                                                                                label="Amount 2"
                                                                                placeholder=""
                                                                                value={LLAData?.amount2?.replace('$0.0','') || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4r3df5fg"
                                                                                label="Quantity 2"
                                                                                placeholder=""
                                                                                value={LLAData?.quantity2 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="ffe333sdf"
                                                                                label="Reason Code 3"
                                                                                placeholder=""
                                                                                value={LLAData?.reason3 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf333sermi"
                                                                                label="Amount 3"
                                                                                placeholder=""
                                                                                value={LLAData?.amount3?.replace('$0.0','') || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4333rf5fg"
                                                                                label="Quantity 3"
                                                                                placeholder=""
                                                                                value={LLAData?.quantity3 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="4444f4s"
                                                                                label="Reason Code 4"
                                                                                placeholder=""
                                                                                value={LLAData?.reason4 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3s444rf3sermi"
                                                                                label="Amount 4"
                                                                                placeholder=""
                                                                                value={LLAData?.amount4?.replace('$0.0','') || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4rf54444fg"
                                                                                label="Quantity 4"
                                                                                placeholder=""
                                                                                value={LLAData?.quantity4 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="5555sdg34"
                                                                                label="Reason Code 5"
                                                                                placeholder=""
                                                                                value={LLAData?.reason5 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="555sdr4324"
                                                                                label="Amount 5"
                                                                                placeholder=""
                                                                                value={LLAData?.amount5?.replace('$0.0','') || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr555554rf5fg"
                                                                                label="Quantity 5"
                                                                                placeholder=""
                                                                                value={LLAData?.quantity5 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                    <div className="form-wrapper">
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="6666we4sdf"
                                                                                label="Reason Code 6"
                                                                                placeholder=""
                                                                                value={LLAData?.reason6 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="othe3srf3ser55666mi"
                                                                                label="Amount 6"
                                                                                placeholder=""
                                                                                value={LLAData?.amount6?.replace('$0.0','') || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                                InputProps={{
                                                                                    startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                        <div className="mui-custom-form input-md">
                                                                            <TextField
                                                                                disabled
                                                                                id="dgftr4rf6665fg"
                                                                                label="Quantity 6"
                                                                                placeholder=""
                                                                                value={LLAData?.quantity6 || ""}
                                                                                InputLabelProps={{
                                                                                    shrink: true,
                                                                                }}
                                                                            />
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                </div>
                                                                : null}
                                                        </div>
                                                    </ExpansionPanelDetails>
                                                </ExpansionPanel>
                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>

                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Rendering Provider</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container mx-0">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>


                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hesdfsdfe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Referring Provider</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container mx-0">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>

                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4esdfbs4bader32">
                                                <Typography className={classes.heading}>Other Payer Operating Physician</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container mx-0">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>


                                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                                            <ExpansionPanelSummary
                                                expandIcon={<ExpandMoreIcon />}
                                                aria-controls="panelp1a-content32"
                                                id="panelp1a-hefe4e4bader32">
                                                <Typography className={classes.heading}>Other Payer Other Operating Physician</Typography>
                                            </ExpansionPanelSummary>
                                            <ExpansionPanelDetails>
                                                <div className="tabs-container inner-collapse-container mx-0">
                                                    <div className="tab-header">
                                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                                    </div>
                                                    <TableComponent headCells={SecIDs} tableData={submittedProvidersData} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                                </div>

                                            </ExpansionPanelDetails>
                                        </ExpansionPanel>


                                    </div>) : null}
                            </div>
                        </ExpansionPanelDetails>
                    </ExpansionPanel>
                </div>
            </div >
        </div >
    );
}
export default withRouter(OtherServicesInfo);