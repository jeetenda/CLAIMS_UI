import React from 'react';
import { withRouter } from 'react-router';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../../SharedModules/Table/Table';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import TextField from '@material-ui/core/TextField';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from '@material-ui/core/InputAdornment';
import Alert from '@material-ui/lab/Alert';
import { setZeroAtdecimalPoint } from "../ClaimUtility";

const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

function OtherClaimCoordinatesOfBenefits(props) {
    const classes = useStyles();
    const [adjustmentsData, setAdjustmentsData] = React.useState(false);
    const [showData, setShowData] = React.useState([]);
    const otherSubscriberInfo = props?.tableData?.c837OtherPayers[0]?.otherSubscriberInfo || {};
    const otherSubscriberInfoTable = props?.tableData?.c837OtherPayers[0]?.otherSubscriberInfo || {};
    const otherSubscriberList = [];
    otherSubscriberInfoTable.additionalID1 != null 
        ? otherSubscriberList.push({"additionalQualifierCode":otherSubscriberInfoTable.additionalQualifierCode1,"additionalID":otherSubscriberInfoTable.additionalID1}) : null
    otherSubscriberInfoTable.additionalID2 != null ? otherSubscriberList.push({"additionalQualifierCode":otherSubscriberInfoTable.additionalQualifierCode2,"additionalID":otherSubscriberInfoTable.additionalID2}): null
    otherSubscriberInfoTable.additionalID3 != null ? otherSubscriberList.push({"additionalQualifierCode":otherSubscriberInfoTable.additionalQualifierCode3,"additionalID":otherSubscriberInfoTable.additionalID2}): null

    const additionalOtherSubscriberInfo = props.tableData && props.tableData.c837OtherPayers[0].otherSubscriberInfo ? props.tableData && props.tableData.c837OtherPayers[0].otherSubscriberInfo : {};
    const otherPayerQualifier = props.tableData && props.tableData.c837OtherPayers[0].otherPayerQualifierCode ? props.tableData.c837OtherPayers[0].otherPayerQualifierCode : {};
    const medicareOPInfo = props?.tableData?.c837OtherPayers[0]?.otherPayerMedicareInfo || {};
    const additionalOtherPayerInfo = props?.tableData?.c837OtherPayers[0] || {};
    const contactInfoData = props.tableData && props.tableData.c837OtherPayers[0].contactInfo ? [props.tableData.c837OtherPayers[0].contactInfo] : [];
    const otherOperatingProviderInfo = props?.tableData?.c837LineItemProviders[0]?.otherProvider || {};
    const attendingProviderInfo = props?.tableData?.c837LineItemProviders[0]?.attendingProvider || {};
 
    const claimLevelAdjustments = props.professoionalData && props.professoionalData.claimAdjustmentReasons ? props.professoionalData.claimAdjustmentReasons : [];
    const submittedProviderID = props.professoionalData && props.professoionalData.otherPayerSubmittedProviderIDs ? props.professoionalData.otherPayerSubmittedProviderIDs : [];
    const cobmonitaryAmount = props?.tableData?.c837OtherPayers[0]?.otherPayerTPLInfo || {};

    const ClaimProviderOtherPayerInfoCells = [
        {
            id: 'additionalQualifierCode', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'additionalID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'additionalID', numeric: false, disablePadding: false, label: 'Payer ID', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'additionalID', numeric: false, disablePadding: false, label: "Employer's Identification Number", enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'additionalID', numeric: false, disablePadding: false, label: 'Claim Office Number', enableHyperLink: false, fontSize: 12, width: "15%"
        },
        {
            id: 'additionalID', numeric: false, disablePadding: false, label: 'NAIC Code', enableHyperLink: false, fontSize: 12, width: "15%"
        }
    ];

    const ClaimProviderOtherPayerContactInfoCells = [
        {
            id: 'contactName1', numeric: false, disablePadding: false, label: 'Name', enableHyperLink: false, fontSize: 12, width: "25%"
        },
        {
            id: 'communicationNumber1A', numeric: false, disablePadding: false, label: 'Phone / Ext.', enableHyperLink: false, fontSize: 12, width: "25%"
        },
        {
            id: 'fax', numeric: false, disablePadding: false, label: 'Fax', enableHyperLink: false, fontSize: 12, width: "25%"
        },
        {
            id: 'email', numeric: false, disablePadding: false, label: 'Email', enableHyperLink: false, fontSize: 12, width: "25%"
        }
    ];

    const ClaimLevelAdjustmentsInfoCells = [
        {
            id: 'adjustmentGroupCode', numeric: false, disablePadding: false, label: 'Claim Adjustment Group Code', enableHyperLink: true, fontSize: 12, width: "25%"
        },
        {
            id: 'adjustmentReasonCode', numeric: false, disablePadding: false, label: 'Reason Code', enableHyperLink: false, fontSize: 12, width: "25%"
        },
        {
            id: 'adjustmentReasonAmount', numeric: false, disablePadding: false, label: 'Amount', enableHyperLink: false, fontSize: 12, width: "25%"
        },
        {
            id: 'adjustmentUnitQuantity', numeric: false, disablePadding: false, label: 'Quantity', enableHyperLink: false, fontSize: 12, width: "25%"
        }
    ];

    const ClaimProviderInfoCells = [
        {
            id: 'providerIDType', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12, width: "50%"
        }
    ];


    // const getTableData2 = (data) => {
    //     if (data && data.length) {
    //       let tData = JSON.stringify(data); 
    //       tData = JSON.parse(tData);     
    //       tData.map((each,index) => {
    //             each.idtypeShortDesc = each.idtypeShortDesc!=""&& each.idtypeShortDesc!=null?each.idtypeShortDesc:each.idtype;                					
    //             each.index = index;

    //       });          
    //       return tData;           
    //     }else{
    //       return [];
    //     }
    //   }

    const editRow = row => (event) => {
        setAdjustmentsData(true)
        setShowData(row)
    };

    const cancelAdjustPage = () => {
        setAdjustmentsData(false)
    }

    const cancelCOBPage = () => {
        props.setCoordinates(false)
    }
    return (
        <div className='tab-holder CustomExpansion-panel my-3'>
            <div className='tab-holder CustomExpansion-panel my-3'>
                <div className="tabs-container">
                    <div className="tab-header">
                        <h2 className="tab-heading float-left">View Other Insurance</h2>
                        <div className="float-right th-btnGroup">
                            <button color="primary" type="button" className="btn btn-primary" onClick={cancelCOBPage}>Close</button>
                        </div>
                    </div>
                </div>


                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Subscriber Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>

                        <div className="form-wrapper wrap-form-label px-0">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Group or Policy #"
                                    label="Group or Policy #"
                                    placeholder=""
                                    value={otherSubscriberInfo?.policyNumber || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}

                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Group or Plan Name"
                                    label="Group or Plan Name"
                                    placeholder=""
                                    value={otherSubscriberInfo?.planName || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}

                                />
                            </div>

                        </div>
                        <div className="form-wrapper wrap-form-label">

                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Entity Qualifier"
                                    label="Entity Qualifier"
                                    placeholder=""
                                    value={additionalOtherSubscriberInfo?.entityQualifierCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>

                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="relation to individual"
                                    label="Relation To Individual"
                                    placeholder=""
                                    value={additionalOtherSubscriberInfo?.additionalID1 || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Claim Filing Code"
                                    label="Claim Filing Code"
                                    placeholder=""
                                    value={additionalOtherSubscriberInfo?.claimFilingCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Payer Responsibility Seq # Code"
                                    label="Payer Responsibility Seq # Code"
                                    placeholder=""
                                    value={additionalOtherSubscriberInfo?.payerSequenceCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                        </div>

                        <div className="tabs-container pb-2 mb-2">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>

                    </ExpansionPanelDetails>
                </ExpansionPanel>


                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>  Other Insurance Coverage </Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <div className="mt-0 mb-3">
                            <div className="form-wrapper wrap-form-label">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Benefits Assignment Certification:"
                                        label="Benefits Assignment Certification:"
                                        placeholder=""
                                        value={otherSubscriberInfo?.benefitCertificationCode || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Release of Information"
                                        label="Release of Information"
                                        placeholder=""
                                        value={otherSubscriberInfo?.informationReleaseCode || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                            </div>

                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>
                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Medicare Inpatient Adjudication Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <div className="mt-0 mb-3">
                            <div className="form-wrapper wrap-form-label">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Covered Days or Visits Count"
                                        label="Covered Days or Visits Count"
                                        placeholder=""
                                        value={medicareOPInfo?.coveredDays || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Lifetime Reverse Days Count"
                                        label="Lifetime Reverse Days Count"
                                        placeholder=""
                                        value={medicareOPInfo?.reserveDays || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Lifetime Psychiatric Count"
                                        label="Lifetime Psychiatric Count"
                                        placeholder=""
                                        value={medicareOPInfo?.psychiatricDays || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim DRG Amount"
                                        label="Claim DRG Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.drgAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code"
                                        label="Remark Code"
                                        placeholder=""
                                        value={medicareOPInfo?.inPatientRemarkCode5 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim Disproportionate Share Amount"
                                        label="Claim Disproportionate Share Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.disproportionateShareAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim MSP Pass-Through Amount"
                                        label="Claim MSP Pass-Through Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.mspPassThroughAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim PSS Capital Amount"
                                        label="Claim PSS Capital Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.ppsCapitalAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="PSS Capital FSP Drug Amount"
                                        label="PSS Capital FSP Drug Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.fspDRGAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="PSS Capital HSP Drug Amount"
                                        label="PSS Capital HSP Drug Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.hspDRGAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="PSS Capital DSH Drug Amount"
                                        label="PSS Capital DSH Drug Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.ppsCapitalDSHDRGAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Old Capital Amount"
                                        label="Old Capital Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.oldCapitalAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="PSS Capital IME Amount"
                                        label="PSS Capital IME Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.ppsCapitalIMEAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="PSS Operating Hospital Specific DRG Amount"
                                        label="PSS Operating Hospital Specific DRG Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.ppsCapitalHSPDRGAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Cost Report Day Count"
                                        label="Cost Report Day Count"
                                        placeholder=""
                                        value={medicareOPInfo?.costReportDays || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="PSS Operating Federal Specific DRG Amount"
                                        label="PSS Operating Federal Specific DRG Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.federalDRGAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim PPS Capital Outlier Amount"
                                        label="Claim PPS Capital Outlier Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.ppsCapitalOutlierAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim Indirect Teaching Amount"
                                        label="Claim Indirect Teaching Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.indirectTeachingAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Non-Payable Professional Component Amount"
                                        label="Non-Payable Professional Component Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.professionalAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="PPS Capital Exception Amount"
                                        label="PPS Capital Exception Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.ppsCapitalExceptionAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 1"
                                        label="Remark Code 1"
                                        placeholder=""
                                        value={medicareOPInfo?.inPatientRemarkCode1 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 2"
                                        label="Remark Code 2"
                                        placeholder=""
                                        value={medicareOPInfo?.inPatientRemarkCode2 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 3"
                                        label="Remark Code 3"
                                        placeholder=""
                                        value={medicareOPInfo?.inPatientRemarkCode3 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 4"
                                        label="Remark Code 4"
                                        placeholder=""
                                        value={medicareOPInfo?.inPatientRemarkCode4 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                            </div>

                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Medicare Outpatient Adjudication Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <div className="mt-0 mb-3">
                            <div className="form-wrapper wrap-form-label">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Reimbursement Rate"
                                        label="Reimbursement Rate"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientReimburseRate || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="HCPCS Payable Amount"
                                        label="HCPCS Payable Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientHCPCSAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                            </div>
                            <div className="form-wrapper wrap-form-label">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 1"
                                        label="Remark Code 1"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientRemarkCode1 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 2"
                                        label="Remark Code 2"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientRemarkCode2 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 3"
                                        label="Remark Code 3"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientRemarkCode3 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 4"
                                        label="Remark Code 4"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientRemarkCode4 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remark Code 5"
                                        label="Remark Code 5"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientRemarkCode5 || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                    />
                                </div>
                            </div>
                            <div className="form-wrapper wrap-form-label">
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="ESRD Paid Amount"
                                        label="ESRD Paid Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientESRDAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Professional Component Amount"
                                        label="Professional Component Amount"
                                        placeholder=""
                                        value={medicareOPInfo?.outPatientProfessionalAmount || ""}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                            </div>

                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>

                        <div className="form-wrapper wrap-form-label px-0">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Payer/Carrier ID Qualifier"
                                    label="Payer/Carrier ID Qualifier"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.otherPayerQualifierCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}

                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="ID"
                                    label="ID"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.otherPayerID || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="ID Type"
                                    label="ID Type"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.otherPayerQualifierCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                        </div>

                           
                        <div className="form-wrapper wrap-form-label">
                            <div className="mui-custom-form input-md field-xl">
                                <TextField
                                    disabled
                                    id="Address 1"
                                    label="Address 1"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.addressLine1 || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md field-xl">
                                <TextField
                                    disabled
                                    id="Address 2"
                                    label="Address 2"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.addressLine2 || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="City"
                                    label="City"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.cityName || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="State"
                                    label="State"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.stateCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <div className="cndt-row">
                                    <div className="cndt-col-6">
                                        <TextField
                                            disabled
                                            id="Zip and Extension"
                                            label="Zip and Extension"
                                            placeholder=""
                                            value={additionalOtherPayerInfo?.zipCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="cndt-col-6">
                                        <TextField
                                            disabled
                                            id="Zip and Extension1"
                                            placeholder=""
                                            value={additionalOtherPayerInfo?.zipCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                                
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Country12"
                                    label="Country"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.countryCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Subdivision Code"
                                    label="Subdivision Code"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.paidCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>

                        </div>
                        <div className="form-wrapper wrap-form-label">
                            <MuiPickersUtilsProvider utils={DateFnsUtils}>

                                <div className="mui-custom-form input-md with-select" >
                                    <KeyboardDatePicker
                                        disabled
                                        id="Adjudication Date"
                                        label="Adjudication Date"
                                        format="MM/dd/yyyy"
                                        placeholder="mm/dd/yyyy"
                                        InputLabelProps={{
                                            shrink: true
                                        }}
                                        value={additionalOtherPayerInfo?.paidDate || null}
                                        KeyboardButtonProps={{
                                            'aria-label': 'change date',
                                        }}
                                    />
                                </div>
                            </MuiPickersUtilsProvider>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Number Type"
                                    label="Number Type"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.referralQualifierCode1 || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="SA / Referral #"
                                    label="SA / Referral #"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.referralID1 || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>

                        </div>
                        <div className="tabs-container pb-2">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderOtherPayerInfoCells} tableData={otherSubscriberList} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>

                    </ExpansionPanelDetails>
                </ExpansionPanel>



                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>COB Monetary Amounts</Typography>
                    </ExpansionPanelSummary>


                    <ExpansionPanelDetails>

                        <div className="mt-0 mb-3">


                            <div className="form-wrapper wrap-form-label">

                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="COD Total Submitted Charge Amount"
                                        label="COD Total Submitted Charge Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.approvedAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>

                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim DRG Outlier Amount"
                                        label="Claim DRG Outlier Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.patientResponsibilityAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Remaining Patient Liability Amount"
                                        label="Remaining Patient Liability Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.nonCoveredAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Total Medicare Paid Amount"
                                        label="Total Medicare Paid Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.coverdAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Medicare Paid at 100% Amount"
                                        label="Medicare Paid at 100% Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.discountAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Medicare Paid at 80% Amount"
                                        label="Medicare Paid at 80% Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.perDayAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div> 
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Paid from Part A medicare Trust Fund Amount"
                                        label="Paid from Part A medicare Trust Fund Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.taxAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div> 
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Paid from Part B medicare Trust Fund Amount"
                                        label="Paid from Part B medicare Trust Fund Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.beforeTaxAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div> 
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Non-Covered Charge Amount"
                                        label="Non-Covered Charge Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.remainingPatientLiabilityAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                                <div className="mui-custom-form input-md">
                                    <TextField
                                        disabled
                                        id="Claim Total Denied Charge Amount"
                                        label="Claim Total Denied Charge Amount"
                                        placeholder=""
                                        value={cobmonitaryAmount?.remainingPatientLiabilityAmount || "0.00"}
                                        InputLabelProps={{
                                            shrink: true,
                                        }}
                                        InputProps={{
                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                        }}
                                    />
                                </div>
                            </div>
                        </div>

                    </ExpansionPanelDetails>
                </ExpansionPanel>



                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Claim Level Adjustments</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>
                        <div className="tab-body-bordered mt-3 mb-3">
                            <div className="tabs-container pb-2">
                                <TableComponent headCells={ClaimLevelAdjustmentsInfoCells} tableData={claimLevelAdjustments} onTableRowClick={editRow} defaultSortColumn="id" />
                            </div>
                            {adjustmentsData ? <>
                                <div className="tabs-container">
                                    <div className="tab-header ml-3 mr-3">
                                        <h2 className="tab-heading float-left">View Claim Level Adjustments</h2>
                                        <div className="float-right th-btnGroup">
                                            <button color="primary" type="button" className="btn btn-primary" onClick={cancelAdjustPage}>Close</button>
                                        </div>
                                    </div>
                                    <ExpansionPanelDetails>

                                        <div className="tab-body-bordered mt-0">


                                            <div className="form-wrapper wrap-form-label">

                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Claim Adjustment Group Code"
                                                        label="Claim Adjustment Group Code"
                                                        placeholder=""
                                                        value={showData?.adjustmentGroupCode || null}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                            required: true
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-wrapper wrap-form-label">
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Reason Code"
                                                        label="Reason Code"
                                                        placeholder=""
                                                        value={showData?.adjustmentReasonCode || " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                            required: true
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Amount"
                                                        label="Amount"
                                                        placeholder=""
                                                        value={showData?.adjustmentReasonAmount || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                            required: true
                                                        }}
                                                        InputProps={{
                                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Quantity"
                                                        label="Quantity"
                                                        placeholder=""
                                                        value={showData?.adjustmentUnitQuantity || " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>

                                            </div>

                                            <div className="form-wrapper wrap-form-label">
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Reason Code 2"
                                                        label="Reason Code 2"
                                                        placeholder=""
                                                        value={showData?.adjustmentReasonCode2 || " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Amount 2"
                                                        label="Amount 2"
                                                        placeholder=""
                                                        value={showData?.adjustmentReasonAmount2 || ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                        InputProps={{
                                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                        }}

                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Quantity 2"
                                                        label="Quantity 2"
                                                        placeholder=""
                                                        value={showData?.adjustmentUnitQuantity2 || " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-wrapper wrap-form-label">
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Reason Code 3"
                                                        label="Reason Code 3"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonCode3 ? showData.adjustmentReasonCode3 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Amount 3"
                                                        label="Amount 3"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonAmount3 ? showData.adjustmentReasonAmount3 : ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                        InputProps={{
                                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Quantity 3"
                                                        label="Quantity 3"
                                                        placeholder=""
                                                        value={showData.adjustmentUnitQuantity3 ? showData.adjustmentUnitQuantity3 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-wrapper wrap-form-label">
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Reason Code 4"
                                                        label="Reason Code 4"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonCode4 ? showData.adjustmentReasonCode4 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Amount 4"
                                                        label="Amount 4"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonAmount4 ? showData.adjustmentReasonAmount4 : ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                        InputProps={{
                                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Quantity 4"
                                                        label="Quantity 4"
                                                        placeholder=""
                                                        value={showData.adjustmentUnitQuantity4 ? showData.adjustmentUnitQuantity4 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-wrapper wrap-form-label">
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Reason Code 5"
                                                        label="Reason Code 5"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonCode5 ? showData.adjustmentReasonCode5 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Amount 5"
                                                        label="Amount 5"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonAmount5 ? showData.adjustmentReasonAmount5 : ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                        InputProps={{
                                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Quantity 5"
                                                        label="Quantity 5"
                                                        placeholder=""
                                                        value={showData.adjustmentUnitQuantity5 ? showData.adjustmentUnitQuantity5 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                            <div className="form-wrapper wrap-form-label">
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Reason Code 6"
                                                        label="Reason Code 6"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonCode6 ? showData.adjustmentReasonCode6 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Amount 6"
                                                        label="Amount 6"
                                                        placeholder=""
                                                        value={showData.adjustmentReasonAmount6 ? showData.adjustmentReasonAmount6 : ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                        InputProps={{
                                                            startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                                        }}
                                                    />
                                                </div>
                                                <div className="mui-custom-form input-md">
                                                    <TextField
                                                        disabled
                                                        id="Quantity 6"
                                                        label="Quantity 6"
                                                        placeholder=""
                                                        value={showData.adjustmentUnitQuantity6 ? showData.adjustmentUnitQuantity6 : " "}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </div>

                                    </ExpansionPanelDetails>
                                </div>
                            </>
                                : null}
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>



                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Patient Information</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>
                        <div className="form-wrapper px-0">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="ID"
                                    label="ID"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.patientMemberID || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}

                                />
                            </div>
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="IDType"
                                    label="ID Type"
                                    placeholder=""
                                    value={additionalOtherPayerInfo?.providerIDType || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}

                                />
                            </div>
                        </div>
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>



                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Rendering Provider</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>
                       
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>



                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Service Facility Provider</Typography>
                    </ExpansionPanelSummary>

                    <ExpansionPanelDetails>
                       
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>



                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Referring Provider</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Attending Provider</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                    <div className="form-wrapper px-0">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Entity Qualifier"
                                    label="Entity Qualifier"
                                    placeholder=""
                                    value={attendingProviderInfo?.entityTypeCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                        </div>
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Operating Physician</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                     
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Other Operating Physician</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                    <div className="form-wrapper px-0">
                            <div className="mui-custom-form input-md">
                                <TextField
                                    disabled
                                    id="Entity Qualifier"
                                    label="Entity Qualifier"
                                    placeholder=""
                                    value={otherOperatingProviderInfo?.entityTypeCode || ""}
                                    InputLabelProps={{
                                        shrink: true,
                                    }}
                                />
                            </div>
                        </div>
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

                <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content11"
                        id="panelp1a-header11">
                        <Typography className={classes.heading}>Other Payer Billing Provider</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <div className="tabs-container pb-2 mb-3">
                            <div className="tab-header">
                                <h2 className="tab-heading float-left"> Secondary IDs </h2>
                            </div>
                            <TableComponent headCells={ClaimProviderInfoCells} tableData={submittedProviderID} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                        </div>
                    </ExpansionPanelDetails>
                </ExpansionPanel>

            </div>
        </div>
    );
}
export default withRouter(OtherClaimCoordinatesOfBenefits);