import React, { useState } from 'react';
import { withRouter } from 'react-router';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../../SharedModules/Table/Table';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import TextField from '@material-ui/core/TextField';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from '@material-ui/core/InputAdornment';
import Alert from '@material-ui/lab/Alert';
import OtherClaimCoordinatesOfBenefits from './OtherClaimCoordinatesOfBenefits';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
    small: {
        width: theme.spacing(3),
        height: theme.spacing(3),
    },
    txtfullwidth: {
        width: '100%',
    }
}));



export const unwantedFunc = () => {
    return false;
};

function OtherClaimInfo(props) {
    const characterRemaining = claimNotesInfo?.noteText || 80;
    const classes = useStyles();
    const [lineItemNum, setLineItemNum] = useState(0);
    const [benefitsData, setBenefitsData] = React.useState(false);
    const [coordinates, setCoordinates] = React.useState(false);
    const [visiondata, setVisionData] = React.useState(false);
    const claimsInfo = props?.data?.enterpriseClaimAux?.c837ClaimHdr || {};
    const claimInfodates = claimsInfo?.c837Claim || {};
    const claimServiceInfo = claimsInfo?.c837ServiceLineItems[0]?.ambulatoryPatientGroup || {};
    const claimNotesInfo = claimsInfo?.c837ServiceLineItems[0] || {};


    const claimDetailMisc = claimsInfo?.c837InstitutionalClaims[0] || {};
    const claimTreatmentCodes = claimsInfo?.c837InstitutionalClaims[0]?.treatmentCodes || {};
    const claimHealthCareInfo = claimsInfo?.c837InstitutionalClaims[0]?.homeHealthCareCertification || {};
    const claimHealthCareFuncLimit = claimsInfo?.c837InstitutionalClaims[0]?.homeHealthCareFunctionalLimitation || {};
    const claimActivites = claimsInfo?.c837InstitutionalClaims[0]?.homeHealthActivities || {};
    const claimMentalStatus = claimsInfo?.c837InstitutionalClaims[0]?.homeHealthMentalStatus || {};
    const fileInfoVOList = claimsInfo?.c837ServiceLineItems[0]?.fileFormatInfo || [];
    const repricedClaim =  claimsInfo?.c837SpecializedService?.repricedClaimInfo || {};
    const epsdtData =  claimsInfo?.c837SpecializedService || {};
    const claimInfoHomeHealthCare = claimsInfo?.c837HomeHealthPlans || {};

    const claimInfoAmbulance = claimsInfo && claimsInfo.c837SpecializedService && claimsInfo.c837SpecializedService.ambulanceInfo ? claimsInfo.c837SpecializedService.ambulanceInfo : {};
    const claimInfoAmbulancePickup = claimsInfo && claimsInfo.c837ServiceLineItems && claimsInfo.c837ServiceLineItems.length > 0 ? claimsInfo.c837ServiceLineItems[0].ambulancePickupLocation : {};
    const claimInfoAmbulanceDrop = claimsInfo && claimsInfo.c837ServiceLineItems && claimsInfo.c837ServiceLineItems.length > 0 ? claimsInfo.c837ServiceLineItems[0].ambulanceDropoffLocation : {};

    const claimInfoSpinalInfo = claimsInfo && claimsInfo.c837SpecializedService ? claimsInfo.c837SpecializedService : {};

    const vision = claimsInfo && claimsInfo.c837SpecializedService && claimsInfo.c837SpecializedService.patientVisionCondition 
        ? claimsInfo.c837SpecializedService.patientVisionCondition : {};
        
    const visionList = [];
    vision.visionCode1 != null ? visionList.push({"visionConditionIndicator1":vision.visionConditionIndicator1,"visionCode":vision.visionCode1, "conditionCode1": vision.conditionCode1A, "conditionCode2": vision.conditionCode1B, "conditionCode3": vision.conditionCode1C, "conditionCode4": vision.conditionCode1D, "conditionCode5": vision.conditionCode1E}) : null
    vision.visionCode2 != null ? visionList.push({"visionConditionIndicator1":vision.visionConditionIndicator2,"visionCode":vision.visionCode2, "conditionCode1": vision.conditionCode2A, "conditionCode2": vision.conditionCode2B, "conditionCode3": vision.conditionCode2C, "conditionCode4": vision.conditionCode2D, "conditionCode5": vision.conditionCode2E}): null
    vision.visionCode3 != null ? visionList.push({"visionConditionIndicator1":vision.visionConditionIndicator3,"visionCode":vision.visionCode3, "conditionCode1": vision.conditionCode3A, "conditionCode2": vision.conditionCode3B, "conditionCode3": vision.conditionCode3C, "conditionCode4": vision.conditionCode3D, "conditionCode5": vision.conditionCode3E}): null

    

    const claimInfoServiceFacilityInfo = claimsInfo?.serviceFacility?.serviceFacilityName || {};
    const additionalPrimaryCareProviderInformation = claimsInfo?.c837ClaimProvider?.referringProvider1?.providerName || {};
    const purchasedServiceProvider = claimsInfo?.c837ClaimProvider?.purchasedServiceProvider || {};
    const supervisingProvider = claimsInfo?.c837ClaimProvider?.supervisingProvider?.providerName || {};
    const claimInfoServiceFacilityInfoIdInfo = props.data && props.data.claimProviderID ? props.data.claimProviderID : [];
    var cobClaimTplSequenceNumber = props.data && props.data.claimTPLInfo[0] ? [props.data.claimTPLInfo[0]] : []
    const coboOtherPayerInsuranceList = claimsInfo && claimsInfo.c837OtherPayers && claimsInfo.c837OtherPayers[0] ? [claimsInfo.c837OtherPayers[0]] : [];
    
    var j = coboOtherPayerInsuranceList.length;
    var coordinationOfBenefitInformation = [];
    if(coboOtherPayerInsuranceList.length > 0 && cobClaimTplSequenceNumber.length > 0){  
        for(var i=0;i<j;i++){      
            coordinationOfBenefitInformation.push({
                'subscriberQualifierCode': coboOtherPayerInsuranceList[i] && coboOtherPayerInsuranceList[i].otherSubscriberInfo ? coboOtherPayerInsuranceList[i].otherSubscriberInfo.subscriberID : '',
                'otherPayerID': coboOtherPayerInsuranceList[i] && coboOtherPayerInsuranceList[i].otherPayerID ? coboOtherPayerInsuranceList[i].otherPayerID : '',
                'tplPaidAmount': coboOtherPayerInsuranceList[i] && coboOtherPayerInsuranceList[i].otherPayerTPLInfo ? coboOtherPayerInsuranceList[i].otherPayerTPLInfo.tplPaidAmount.toFixed(2) : '',
                'sequenceNumber': cobClaimTplSequenceNumber[i].sequenceNumber,
                'otherPayerName': cobClaimTplSequenceNumber[i].otherPayerName
            })
        }
        
    }
    //  const editRowOtherPayer = () => {
    //      console.log("..............callling....")
    //     setCoordinates(true)
    //     // setVisionData(row)
    // };
    const ClaimProviderInfoCells = [
        {
            id: 'providerIDType', numeric: false, disablePadding: false, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: "50%"
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12
        }
    ];
    const CoordinationOfBenefitsCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: 'Sequence Number', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'subscriberQualifierCode', numeric: false, disablePadding: false, label: 'Subscriber ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerID', numeric: false, disablePadding: false, label: 'Payer/Carrier ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerName', numeric: false, disablePadding: false, label: 'Payer/Insurance Org', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'tplPaidAmount', numeric: false, disablePadding: false, label: 'Payer Paid Amount', enableHyperLink: false, fontSize: 12
        }
    ];

   
    

    return (
        <div className='tab-holder CustomExpansion-panel my-3'>
            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content1"
                        id="panelp1a-header1">
                        <Typography className={classes.heading}>Claim Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                       
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content12"
                                id="panelp1a-header12">
                                <Typography className={classes.heading}>Miscellaneous Claim</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label form-3-column">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Investigational_Device_Exempt_ID"
                                            label="Investigational Device Exempt ID"
                                            data-test="device_exempt_id"
                                            placeholder=""
                                            value={claimInfodates?.investExemptionID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Demonstration_project_id"
                                            label="Demonstration Project Id"
                                            data-test="project_id"
                                            placeholder=""
                                            value={claimInfodates?.demoProjectID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Repriced_Claim#"
                                            label="Repriced Claim #"
                                            data-test="repriced_claim_num"
                                            placeholder=""
                                            value={claimServiceInfo?.repricedClaimNumber || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Adjusted_Repriced_Claim_#"
                                            label="Adjusted Repriced Claim #"
                                            data-test="adj_repriced_claim"
                                            placeholder=""
                                            value={claimInfodates?.adjustedRepricedClaimNumber || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Service_Authorization_Exception_Code"
                                            label="Service Authorization Exception Code"
                                            data-test="service_auth_exp_code"
                                            placeholder=""
                                            value={claimInfodates?.exceptionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Peer_Review_Authorization_Number"
                                            label="Peer Review Authorization Number"
                                            data-test="peer_review_auth_num"
                                            placeholder=""
                                            value={claimDetailMisc?.peerReviewAuthorizationNumber || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                   
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header14">
                                <Typography className={classes.heading}>Contract Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label form-3-column">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Type Code"
                                            label="Contract Type Code"
                                            placeholder=""
                                            data-test="contract_type_code"
                                            value={claimInfodates?.contractTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Amount"
                                            label="Contract Amount"
                                            placeholder=""
                                            data-test="contract_Amount"
                                            value={claimInfodates?.contractAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Percent"
                                            label="Contract Percent"
                                            data-test="contract_percent"
                                            placeholder=""
                                            value={claimInfodates?.contractPercentage || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Code"
                                            label="Contract Code"
                                            placeholder=""
                                            data-test="contract_code"
                                            value={claimInfodates?.contractCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Terms Discount Percent"
                                            label="Terms Discount Percent"
                                            placeholder=""
                                            data-test="total_discount_percent"
                                            value={claimInfodates?.contractDiscountPercentage || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Contract Version ID"
                                            label="Contract Version ID"
                                            placeholder=""
                                            data-test="contract_version_id"
                                            value={claimInfodates?.contractVersionID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content15"
                                id="panelp1a-header15">
                                <Typography className={classes.heading}>Claims Pricing/Repricing</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label form-3-column">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Pricing Methodology Code"
                                            label="Pricing Methodology Code"
                                            data-test="pricing_method_code"
                                            placeholder=""
                                            value={repricedClaim?.methodologyCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Allowed Amount"
                                            label="Allowed Amount"
                                            placeholder=""
                                            value={repricedClaim?.repriceAllowedAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Savings Amount"
                                            label="Savings Amount"
                                            placeholder=""
                                            value={repricedClaim?.savingsAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Organization Identifier"
                                            label="Organization Identifier"
                                            placeholder=""
                                            value={repricedClaim?.organizationID || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Per Diem or Falt Rate Amount"
                                            label="Per Diem or Flat Rate Amount"
                                            placeholder=""
                                            value={repricedClaim?.repricePerDiemRate || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved APG Code"
                                            label="Approved APG Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceAPGCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved APG Amount"
                                            label="Approved APG Amount"
                                            placeholder=""
                                            value={repricedClaim?.repriceAPGAmount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved Revenue Code"
                                            label="Approved Revenue Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceRejectReasonCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved Units Basis of Measurement Code"
                                            label="Approved Units Basis of Measurement Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceComplianceCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved Service Units"
                                            label="Approved Service Units"
                                            placeholder=""
                                            value={repricedClaim?.repriceComplianceCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Rejection Reason Code"
                                            label="Rejection Reason Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceComplianceCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Policy Compliance Code"
                                            label="Policy Compliance Code"
                                            placeholder=""
                                            value={repricedClaim.repriceComplianceCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Exception Code"
                                            label="Exception Code"
                                            placeholder=""
                                            value={repricedClaim?.repriceExceptionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header14">
                                <Typography className={classes.heading}>EPSDT Referral</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                <div className="mui-custom-form input-md field-xl">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                            <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink">Condition Indicator:</label>
                                            </div>
                                            <div className="sub-radio m-0">
                                                <RadioGroup
                                                    row
                                                    aria-label="eftactive"
                                                    name="dmerccci"
                                                    value={epsdtData?.epsdtIndicator || "No"}
                                                >
                                                    <FormControlLabel
                                                        disabled
                                                        value="Yes"
                                                        control={<Radio color="primary" />}
                                                        label="Yes"
                                                    />
                                                    <FormControlLabel
                                                        disabled
                                                        value="No"
                                                        control={<Radio color="primary" />}
                                                        label="No"
                                                    />
                                                </RadioGroup>
                                            </div>
                                        </div>
                                        </div>
                                <div className="form-wrapper wrap-form-label form-3-column set-top-10">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Condition Code1"
                                            label="Condition Code1"
                                            placeholder=""
                                            value={epsdtData?.espdtConditionCode1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="ConditionCode2"
                                            label="Condition Code2"
                                            placeholder=""
                                            value={epsdtData?.espdtConditionCode2 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Condition Code3"
                                            label="Condition Code3"
                                            placeholder=""
                                            value={epsdtData?.espdtConditionCode3 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content13"
                                id="panelp1a-header13">
                                <Typography className={classes.heading}>File Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label form-3-column">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 1"
                                            label="File Information 1"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 2"
                                            label="File Information 2"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation2 ||""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 3"
                                            label="File Information 3"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation3 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 4"
                                            label="File Information 4"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation4 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 5"
                                            label="File Information 5"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation5 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 6"
                                            label="File Information 6"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation6 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 7"
                                            label="File Information 7"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation7 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 8"
                                            label="File Information 8"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation8 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 9"
                                            label="File Information 9"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation9 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="File Information 10"
                                            label="File Information 10"
                                            placeholder=""
                                            value={fileInfoVOList?.fileInformation10 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header14">
                                <Typography className={classes.heading}>Claims Quantity</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                
                                        <div className="form-wrapper form-3-column">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Quantity Qualifier"
                                            label="Quantity Qualifier"
                                            placeholder=""
                                            value={claimDetailMisc?.claimsQuantity?.quantityQualifier1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Claim Days Count"
                                            label="Claim Days Count"
                                            placeholder=""
                                            value={claimDetailMisc?.claimsQuantity?.claimDays1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>                                    
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

            
            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content3"
                        id="panelp1a-header3">
                        <Typography className={classes.heading}>Claim Provider Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content31"
                                id="panelp1a-header31">
                                <Typography className={classes.heading}>Service Facility</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper form-3-column">
                                <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname"
                                            label="Org/ Last Name"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.lastName || ""}
                                            InputLabelProps={{
                                                shrink: true
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper form-3-column">
                                  
                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="address41"
                                            label="Address 1"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.addressLine1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md field-xl">
                                        <TextField
                                            disabled
                                            id="address42"
                                            label="Address 2"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.addressLine2 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="city41"
                                            label="City"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.cityName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="state41"
                                            label="State"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.stateCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <div className="cndt-row">
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="zipandextension41"
                                                    label="Zip &amp; Extension"
                                                    placeholder=""
                                                    value={claimInfoServiceFacilityInfo?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                            <div className="cndt-col-6">
                                                <TextField
                                                    disabled
                                                    id="zipandextension412"
                                                    placeholder=""
                                                    value={claimInfoServiceFacilityInfo?.zipCode || ""}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                            </div>
                                        </div>

                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="country41"
                                            label="Country"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.countryCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="subdivision41"
                                            label="Subdivision Code"
                                            placeholder=""
                                            value={claimInfoServiceFacilityInfo?.countrySubDivisionCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>

                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content32"
                                id="panelp1a-header32">
                                <Typography className={classes.heading}>Referring Provider Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname32b"
                                            label="Org / Last Name"
                                            placeholder=""
                                            value={additionalPrimaryCareProviderInformation?.lastName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="fname32b"
                                            label="First Name"
                                            placeholder=""
                                            value={ additionalPrimaryCareProviderInformation?.firstName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="mi32b"
                                            label="MI"
                                            placeholder=""
                                            value={additionalPrimaryCareProviderInformation?.middleName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="suffix32b"
                                            label="Suffix"
                                            placeholder=""
                                            value={additionalPrimaryCareProviderInformation?.suffixName || null}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content33"
                                id="panelp1a-header33">
                                <Typography className={classes.heading}>Operating Physician Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                               
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname32bc"
                                            label="Org / Last Name"
                                            placeholder=""
                                            value={purchasedServiceProvider?.providerName?.lastName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="fname32bc"
                                            label="First Name"
                                            placeholder=""
                                            value={purchasedServiceProvider?.providerName?.firstName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="mi32bc"
                                            label="MI"
                                            placeholder=""
                                            value={purchasedServiceProvider?.providerName?.middleName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="suffix32bc"
                                            label="Suffix"
                                            placeholder=""
                                            value={purchasedServiceProvider?.providerName?.suffixName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0">Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content34"
                                id="panelp1a-header34">
                                <Typography className={classes.heading}>Other Operating Physician Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                 <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="entityqualifier32b"
                                            label="Entity Qualifier"
                                            placeholder=""
                                            value={purchasedServiceProvider?.entityTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orglastname32bcd"
                                            label="Org / Last Name"
                                            placeholder=""
                                            value={supervisingProvider?.lastName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="fname32bcd"
                                            label="First Name"
                                            placeholder=""
                                            value={supervisingProvider?.firstName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="mi32bcd"
                                            label="MI"
                                            placeholder=""
                                            value={supervisingProvider?.middleName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="suffix32bcd"
                                            label="Suffix"
                                            placeholder=""
                                            value={supervisingProvider?.suffixName || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={unwantedFunc} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content2"
                        id="panelp1a-header2">
                        <Typography className={classes.heading}>Specialized Services Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content21"
                                id="panelp1a-header21">
                                <Typography className={classes.heading}>Home Health Care Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label form-3-column px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Prognosis Code"
                                            label="Prognosis Code"
                                            placeholder=""
                                            value={claimHealthCareInfo?.prognosisCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Patient Facility Discharge Type Code"
                                            label="Patient Facility Discharge Type Code"
                                            placeholder=""
                                            value={claimHealthCareInfo?.dischargeFacilityTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Home Health Certification From Date"
                                                    label="Home Health Certification From Date"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.firstCertificationDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Home Health Certification To Date"
                                                    label="Home Health Certification To Date"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.lastCertificationDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Last Admission Period From Date"
                                                    label="Last Admission Period From Date"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.InpatientbeginDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Last Admission Period To Date"
                                                    label="Last Admission Period To Date"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.InpatientEndDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Daignosis Date"
                                                    label="Daignosis Date"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.diagnosisDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Skilled Nursing Facility Indicator"
                                            label="Skilled Nursing Facility Indicator"
                                            placeholder=""
                                            value={
                                                claimHealthCareInfo?.skilledNursingFacilityIndicator ||  null
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Medicare Covered Indicator"
                                            label="Medicare Covered Indicator"
                                            placeholder=""
                                            value={
                                                claimHealthCareInfo?.medicareCoveredIndicator ||  null
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Certification Type Indicator"
                                            label="Certification Type Indicator"
                                            placeholder=""
                                            value={
                                                claimHealthCareInfo?.typeCode ||  null
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Surgical Procedure Performed"
                                                    label="Date Surgical Procedure Performed"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.surgicalProcedureDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Surgical Procedure Code"
                                            label="Surgical Procedure Code"
                                            placeholder=""
                                            value={
                                                claimHealthCareInfo?.surgicalProcedureCode ||  null
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Surgical Procedure Type Code"
                                            label="Surgical Procedure Type Code"
                                            placeholder=""
                                            value={
                                                claimHealthCareInfo?.surgicalProcedureQualifierCode ||  null
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Physician order Date"
                                            label="Physician Order Date"
                                            placeholder=""
                                            value={
                                                claimHealthCareInfo?.physicianOrderDate ||  null
                                            }
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Physician Last Saw Patient"
                                                    label="Date Physician Last Saw Patient"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.physicalVisitDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Service From Date"
                                                    label="Service From Date"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.serviceFromDate ||  null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        </div>
                                        <div className="form-wrapper  wrap-form-label form-3-column">
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Last Contacted Physician"
                                                    label="Date Last Contacted Physician"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo.setPhysicianLastVisitDate ? claimHealthCareInfo.setPhysicianLastVisitDate : null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        </div>
                                        <div className="form-wrapper wrap-form-label form-3-column">
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Secondary Diagnosis 1"
                                                    label="Date Secondary Diagnosis 1"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.secondaryDiagnosisDate1 || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Secondary Diagnosis 2"
                                                    label="Date Secondary Diagnosis 2"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.secondaryDiagnosisDate2 || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Secondary Diagnosis 3"
                                                    label="Date Secondary Diagnosis 3"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.secondaryDiagnosisDate3 || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                                            <div className="mui-custom-form input-md with-select">
                                                <KeyboardDatePicker
                                                    disabled
                                                    id="Date Secondary Diagnosis 4"
                                                    label="Date Secondary Diagnosis 4"
                                                    format="MM/dd/yyyy"
                                                    InputLabelProps={{
                                                        shrink: true
                                                    }}
                                                    placeholder="mm/dd/yyyy"
                                                    value={
                                                        claimHealthCareInfo?.secondaryDiagnosisDate4 || null
                                                    }
                                                    KeyboardButtonProps={{
                                                        "aria-label": "change date"
                                                    }}
                                                />
                                            </div>
                                        </MuiPickersUtilsProvider>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content22"
                                id="panelp1a-header22">
                                <Typography className={classes.heading}>Home Health Care Functional Limitations</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                <div className="mui-custom-form input-md field-xl">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Certification Condition Code</label>
                                                </div>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        disabled
                                                        row
                                                        aria-label="eftactive"
                                                        name="HideInactiveProviders"
                                                        value={claimHealthCareFuncLimit.certificationIndicator1 || " "}
                                                    >
                                                        <FormControlLabel
                                                            value="Yes"
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value="No"
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                </div>
                                <div className="form-wrapper wrap-form-label form-3-column set-top-10">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Functional Limitation Code 1"
                                            label="Functional Limitation Code 1"
                                            placeholder=""
                                            value={claimHealthCareFuncLimit.conditionCode1A || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Functional Limitation Code 2"
                                            label="Functional Limitation Code 2"
                                            placeholder=""
                                            value={claimHealthCareFuncLimit.conditionCode1B || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Functional Limitation Code 3"
                                            label="Functional Limitation Code 3"
                                            placeholder=""
                                            value={claimHealthCareFuncLimit.conditionCode1C || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                           
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Functional Limitation Code 4"
                                            label="Functional Limitation Code 4"
                                            placeholder=""
                                            value={claimHealthCareFuncLimit.conditionCode1D || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Functional Limitation Code 5"
                                            label="Functional Limitation Code 5"
                                            placeholder=""
                                            value={claimHealthCareFuncLimit.conditionCode1E || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                          
                                        />
                                    </div>
                                    </div>
                                
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content23"
                                id="panelp1a-header23">
                                <Typography className={classes.heading}>Home Health Activities Permitted</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                            <div className="form-wrapper">
                                <div className="mui-custom-form input-md field-xl">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Certification Condition Code</label>
                                                </div>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        disabled
                                                        row
                                                        aria-label="eftactive"
                                                        name="HideInactiveProviders"
                                                        value={claimActivites?.certificationIndicator1 || " "}
                                                    >
                                                        <FormControlLabel
                                                            value="Yes"
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value="No"
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                </div>
                                <div className="form-wrapper wrap-form-label form-3-column set-top-10">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Activities Permitted Code 1"
                                            label="Activities Permitted Code 1"
                                            placeholder=""
                                            value={claimActivites?.conditionCode1A || " "}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Activities Permitted Code 2"
                                            label="Activities Permitted Code 2"
                                            placeholder=""
                                            value={claimActivites?.conditionCode1B || " "}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Activities Permitted Code 3"
                                            label="Activities Permitted Code 3"
                                            placeholder=""
                                            value={claimActivites?.conditionCode1C || " "}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                           
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Activities Permitted Code 4"
                                            label="Activities Permitted Code 4"
                                            placeholder=""
                                            value={claimActivites?.conditionCode1D || " "}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                          
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Activities Permitted Code 5"
                                            label="Activities Permitted Code 5"
                                            placeholder=""
                                            value={claimActivites?.conditionCode1E || " "}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            
                                        />
                                    </div>
                                    </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content24"
                                id="panelp1a-header24">
                                <Typography className={classes.heading}>Home Mental Health Status</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                            <div className="form-wrapper">
                                <div className="mui-custom-form input-md field-xl">
                                                <div className="MuiFormControl-root MuiTextField-root">
                                                    <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled">Certification Condition Code</label>
                                                </div>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        disabled
                                                        row
                                                        aria-label="eftactive"
                                                        name="HideInactiveProviders"
                                                        value={claimMentalStatus?.certificationIndicator1 || " "}
                                                    >
                                                        <FormControlLabel
                                                            value="Yes"
                                                            control={<Radio color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value="No"
                                                            control={<Radio color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div>
                                </div>
                                <div className="form-wrapper wrap-form-label form-3-column set-top-10">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Mental Status Code 1"
                                            label="Mental Status Code 1"
                                            placeholder=""
                                            value={claimMentalStatus?.conditionCode1A || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Mental Status Code 2"
                                            label="Mental Status Code 2"
                                            placeholder=""
                                            value={claimMentalStatus?.conditionCode1B || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Mental Status Code 3"
                                            label="Mental Status Code 3"
                                            placeholder=""
                                            value={claimMentalStatus?.conditionCode1C || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="MentalStatusCode4"
                                            label="Mental Status Code 4"
                                            placeholder=""
                                            value={claimMentalStatus?.conditionCode1D || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Mental Status Code 5"
                                            label="Mental Status Code 5"
                                            placeholder=""
                                            value={claimMentalStatus?.conditionCode1E || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>Home Health Care Plan Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label form-3-column">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Discipline Type Code"
                                            label="Discipline Type Code"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.disciplineTypeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Total Visits Rendered"
                                            label="Total Visits Rendered"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.priorVisitsCount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Certification Period Projected Visit Count"
                                            label="Certification Period Projected Visit Count"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.projectedVisitsCount ||""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>Health Care Services Delivery</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label form-3-column">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Number Of Visits"
                                            label="Number Of Visits"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.visitsCount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Frequency Period"
                                            label="Frequency Period"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.frequencyPeriodCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Frequency Count"
                                            label="Frequency Count"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.frequencyCount || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Duration of Visits Units"
                                            label="Duration of Visits Units"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.unitQualifierCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Duration of Visits Number of Units"
                                            label="Duration of Visits Number of Units"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.unitsQuantity || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Ship, Delivery or Calender Pattern Code"
                                            label="Ship, Delivery or Calender Pattern Code"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.patternCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Delivery Pattern Time Code"
                                            label="Delivery Pattern Time Code"
                                            placeholder=""
                                            value={claimInfoHomeHealthCare?.patternTimeCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>Claim Note</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="TypeCode"
                                            label="Type Code"
                                            placeholder=""
                                            value={claimNotesInfo?.noteCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                </div>
                                <div className="form-wrapper">                                        
                                            <div className="mui-custom-form input-md field-xl">
                                            <div className="MuiFormControl-root MuiTextField-root">
                                                <label className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl MuiInputLabel-animated MuiInputLabel-shrink Mui-disabled Mui-disabled"
                                                    data-shrink="true"
                                                    htmlFor="dddwdsghsgtertrSD"
                                                    id="dddwdsghsgtertrSD-label">Notes</label>
                                            </div>
                                            <div className="disabled-form pt-1">
                                                <TextareaAutosize
                                                    className={classes.txtfullwidth}
                                                    aria-label="minimum-height"
                                                    id="claim_notes"
                                                    placeholder=""
                                                    value={claimNotesInfo?.noteText || ""}
                                                    disabled
                                                    rowsMin={6}
                                                    rowsMax={6}
                                                    InputLabelProps={{
                                                        shrink: true,
                                                    }}
                                                />
                                                </div>
                                                <div className="mt-1"><Chip avatar={<Avatar>{characterRemaining&&characterRemaining.length ? 80-characterRemaining.length : 80}</Avatar>} label="Characters remaining" /></div>
                                            </div>
                                        </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>DRG Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper px-0">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="DRGCode"
                                            label="DRG Code"
                                            placeholder=""
                                            value={claimDetailMisc?.drgCode || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                </div>
                                
                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                       

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>Treatment Code Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="TreatmentCode1"
                                            label="Treatment Code 1"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode1 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code2"
                                            label="Treatment Code 2"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode2 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code3"
                                            label="Treatment Code 3"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode3 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code4"
                                            label="Treatment Code 4"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode4 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code5"
                                            label="Treatment Code 5"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode5 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="TreatmentCode6"
                                            label="Treatment Code 6"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode6 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code7"
                                            label="Treatment Code 7"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode7 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code8"
                                            label="Treatment Code 8"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode8 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code9"
                                            label="Treatment Code 9"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode9 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code10"
                                            label="Treatment Code 10"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode10 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code11"
                                            label="Treatment Code 11"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode11 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code12"
                                            label="Treatment Code 12"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode12 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code13"
                                            label="Treatment Code 13"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode13 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code14"
                                            label="Treatment Code 14"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode14 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code15"
                                            label="Treatment Code 15"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode15 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code16"
                                            label="Treatment Code 16"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode16 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code17"
                                            label="Treatment Code 17"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode17 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code18"
                                            label="Treatment Code 18"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode18 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code19"
                                            label="Treatment Code 19"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode19 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code20"
                                            label="Treatment Code 20"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode20 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code21"
                                            label="Treatment Code 21"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode21 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code22"
                                            label="Treatment Code 22"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode22 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code23"
                                            label="Treatment Code 23"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode23 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Treatment Code24"
                                            label="Treatment Code 24"
                                            placeholder=""
                                            value={claimTreatmentCodes?.treatmentCode24 || ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>                                   
                                </div>
                                
                            </ExpansionPanelDetails>
                        </ExpansionPanel>


                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>


            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content4"
                        id="panelp1a-header4">
                        <Typography className={classes.heading}>Coordination Of Benefits</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>

                        <div className="tabs-container">
                            <div className="tab-header mt-1">
                                <h2 className="tab-heading float-left"> Other Insurance </h2>
                            </div>

                            <TableComponent id="table-claim" headCells={CoordinationOfBenefitsCells} tableData={coordinationOfBenefitInformation} onTableRowClick={()=>{setCoordinates(true)}} defaultSortColumn="payerSeq" />
                            {coordinates ? <OtherClaimCoordinatesOfBenefits tableData={claimsInfo} professoionalData={props.data}
                                setCoordinates={setCoordinates}
                            /> : null}
                        </div>

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

        </div>
    );
}
export default withRouter(OtherClaimInfo);