import React, {useState}  from 'react';
import { withRouter } from 'react-router';
import { makeStyles } from "@material-ui/core/styles";
import ExpansionPanel from '@material-ui/core/ExpansionPanel';
import ExpansionPanelSummary from '@material-ui/core/ExpansionPanelSummary';
import ExpansionPanelDetails from '@material-ui/core/ExpansionPanelDetails';
import Typography from '@material-ui/core/Typography';
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import TableComponent from '../../../SharedModules/Table/Table';
import { KeyboardDatePicker, MuiPickersUtilsProvider } from "@material-ui/pickers";
import DateFnsUtils from "@date-io/date-fns";
import TextField from '@material-ui/core/TextField';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import InputAdornment from '@material-ui/core/InputAdornment';
import Alert from '@material-ui/lab/Alert';
import { Divider } from "@material-ui/core";
import ClaimOtherDentalCoordinateOfBenefits from './ClaimOtherDentalCoordinateOfBenefits'
const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));

function DentalOtherInfo(props) {
    const classes = useStyles();
    const [benefitsData, setBenefitsData] = React.useState(false);

    var secondaryTableSFArray = [];
    var secondaryTableRFArray = [];
    var secondaryTablePCArray = [];
    var secondaryTableASArray = [];
    var secondaryTableSUArray = [];
    const claimHdr = props.data && props.data.enterpriseClaimAux ? props.data.enterpriseClaimAux : {};
    const mainDataList = claimHdr && claimHdr.c837ClaimHdr ? claimHdr.c837ClaimHdr : {};
    const claimInfoServiceFacilityInfoSecondaryTable = props.data && props.data.claimProviderID ? props.data.claimProviderID : [];
    const secondaryTableSf = claimInfoServiceFacilityInfoSecondaryTable.filter((e)=> e.providerRoleCode === 'SF' && e.lineNumber == 0).map(e => secondaryTableSFArray.push({'providerIDTypeDesc': e.providerIDTypeDesc,'providerID': e.providerID}));
    //const secondaryTableRf = claimInfoServiceFacilityInfoSecondaryTable.filter((e)=> e.providerRoleCode === 'RF' && e.lineNumber == 0).map(e => secondaryTableRFArray.push({'providerIDTypeDesc': e.providerIDTypeDesc,'providerID': e.providerID}));
    const secondaryTablePc = claimInfoServiceFacilityInfoSecondaryTable.filter((e)=> e.providerRoleCode === 'PC' && e.lineNumber == 0).map(e => secondaryTablePCArray.push({'providerIDTypeDesc': e.providerIDTypeDesc,'providerID': e.providerID}));
    const secondaryTableAs = claimInfoServiceFacilityInfoSecondaryTable.filter((e)=> e.providerRoleCode === 'AS' && e.lineNumber == 0).map(e => secondaryTableASArray.push({'providerIDTypeDesc': e.providerIDTypeDesc,'providerID': e.providerID}));
    const secondaryTableSu = claimInfoServiceFacilityInfoSecondaryTable.filter((e)=> e.providerRoleCode === 'SU' && e.lineNumber == 0).map(e => secondaryTableSUArray.push({'providerIDTypeDesc': e.providerIDTypeDesc,'providerID': e.providerID}));

    const [lineIndex, setLineIndex] = useState(0);
    //const claimInformationOrthoDontic = props.data.enterpriseClaimAux && props.data.enterpriseClaimAux.c837ClaimHdr.c837DentalClaims && props.data.enterpriseClaimAux.c837ClaimHdr.c837DentalClaims[lineIndex] ? props.data.enterpriseClaimAux.c837ClaimHdr.c837DentalClaims[lineIndex] : [];
    const claimInformationOrthoDontic = mainDataList && mainDataList.c837DentalClaims && mainDataList.c837DentalClaims[lineIndex] ? mainDataList.c837DentalClaims[lineIndex] : [];
    var orthoIndicator = claimInformationOrthoDontic.orthoPurposeCode;
    var indicatorOrtho;
    if(orthoIndicator == 'TRUE'){indicatorOrtho = 'Yes'}else if(orthoIndicator == 'FALSE'){indicatorOrtho = 'No'}else{indicatorOrtho = ''}
    var toothStatusTable = [];
    var toothStatus = mainDataList && mainDataList.c837DentalClaims && mainDataList.c837DentalClaims[lineIndex] ? mainDataList.c837DentalClaims[lineIndex].toothStatusInfo : {}
    
    if(toothStatus != null){
        var tooth1 = toothStatus.toothNumber1; var toothStatus1 = toothStatus.toothStatusCode1;
        var tooth2 = toothStatus.toothNumber2; var toothStatus2 = toothStatus.toothStatusCode2;
        if(tooth1 != null || toothStatus1 != null ){
            toothStatusTable.push({'toothNumber': toothStatus.toothNumber1, 'toothStatus': toothStatus.toothStatusCode1});
        }
        if(tooth2 != null || toothStatus2 != null ){
            toothStatusTable.push({'toothNumber': toothStatus.toothNumber2, 'toothStatus': toothStatus.toothStatusCode2});
        }
    }
    
    //const referingProviderInformation = props.data.enterpriseClaimAux && props.data.enterpriseClaimAux.c837ClaimHdr && props.data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider ? props.data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider : {};
    const referingProviderInformation = mainDataList && mainDataList.c837ClaimProvider && mainDataList.c837ClaimProvider ? mainDataList.c837ClaimProvider : {};
   
    const additionalReferringProviderInformation = referingProviderInformation.referringProvider1 && referingProviderInformation.referringProvider1.providerName ? referingProviderInformation.referringProvider1.providerName : [];
    const referingProviderEntityQual = referingProviderInformation.referringProvider2 && referingProviderInformation.referringProvider2.entityTypeCode ? referingProviderInformation.referringProvider2.entityTypeCode : "";
    const primaryCareProviderInformation = props.data.enterpriseClaimAux && props.data.enterpriseClaimAux.c837ClaimHdr && props.data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider ? props.data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider : {};
    const additionalPrimaryCareProviderInformation = primaryCareProviderInformation.referringProvider2 && primaryCareProviderInformation.referringProvider2.providerName ? primaryCareProviderInformation.referringProvider2.providerName : [];
    const supervisingProviderInformation = props.data.enterpriseClaimAux && props.data.enterpriseClaimAux.c837ClaimHdr && props.data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider ? props.data.enterpriseClaimAux.c837ClaimHdr.c837ClaimProvider : {};
    const supervisingProviderInfo = supervisingProviderInformation.supervisingProvider && supervisingProviderInformation.supervisingProvider.providerName ? supervisingProviderInformation.supervisingProvider.providerName : [];
    
    const cobTable = [];
    //const coordinationOfBenefitInformation = props.data && props.data.claimTPLInfo ? props.data.claimTPLInfo : {}
    var cobClaimTplSequenceNumber = props.data && props.data.claimTPLInfo ? props.data.claimTPLInfo : {}
    // const claimTplSequenceNumber = props.data && props.data.claimTPLInfo ? props.data.claimTPLInfo[lineIndex].sequenceNumber : {}
    // const claimTplOtherPayerName = props.data && props.data.claimTPLInfo ? props.data.claimTPLInfo[lineIndex].otherPayerName : {}
     const cobTblOtherPayers = mainDataList && mainDataList.c837OtherPayers ? mainDataList.c837OtherPayers : [];

    var cobTblOtherPayersArr = cobTblOtherPayers.length;
    var j = cobClaimTplSequenceNumber.length;
    var coordinationOfBenefitInformation = [];

    if(cobTblOtherPayers.length > 0 && cobClaimTplSequenceNumber.length > 0){
        //for(var i=0;i<cobTblOtherPayersArr;i++){      
        for(var i=0;i<j;i++){      
            coordinationOfBenefitInformation.push({
                'subscriberQualifierCode': cobTblOtherPayers[i] && cobTblOtherPayers[i].otherSubscriberInfo ? cobTblOtherPayers[i].otherSubscriberInfo.subscriberID : '',
                'otherPayerID': cobTblOtherPayers[i] && cobTblOtherPayers[i].otherPayerID ? cobTblOtherPayers[i].otherPayerID : '',
                'tplPaidAmount': cobTblOtherPayers[i] && cobTblOtherPayers[i].otherPayerTPLInfo ? cobTblOtherPayers[i].otherPayerTPLInfo.tplPaidAmount.toFixed(2) : '',
                'sequenceNumber': i < j ? cobClaimTplSequenceNumber[i].sequenceNumber : '',
                'otherPayerName': i < j ? cobClaimTplSequenceNumber[i].otherPayerName : ''
            })
        }
    }


    const claimIformationDiagnosis = props.data && props.data.diagnosis[lineIndex] ? props.data.diagnosis[lineIndex] : {}
    const claimInfoServiceFacilityInfo = mainDataList && mainDataList.c837ClaimProvider && mainDataList.c837ClaimProvider.serviceFacility ? mainDataList.c837ClaimProvider.serviceFacility : {}
    const serviceFacilityLastName = claimInfoServiceFacilityInfo && claimInfoServiceFacilityInfo.serviceFacilityName ? claimInfoServiceFacilityInfo.serviceFacilityName : {}

    const assistantSurgeonInformation = mainDataList && mainDataList.c837DentalClaims ? mainDataList.c837DentalClaims : {};
    const assistantSurgeonInformationData = assistantSurgeonInformation[lineIndex] ? assistantSurgeonInformation[lineIndex] : {};
    const assistantSurgeonInformationList = assistantSurgeonInformationData && assistantSurgeonInformationData.assistantSurgeonInfo ? assistantSurgeonInformationData.assistantSurgeonInfo : {};
    const assistantSurgeonInfo = assistantSurgeonInformationList && assistantSurgeonInformationList.assistantSurgeonName ? assistantSurgeonInformationList.assistantSurgeonName:{};
    
    const claimInformation = mainDataList && mainDataList.c837ServiceLineItems ? mainDataList.c837ServiceLineItems : {};
    const serviceLineItems = claimInformation[lineIndex] ? claimInformation[lineIndex] : [];

    //const contractInformationVO = serviceLineItems && serviceLineItems ? serviceLineItems : [];
    //const contractInformationVO = serviceLineItems ? serviceLineItems : [];

    const contractInformationVO = props.data.enterpriseClaimAux && props.data.enterpriseClaimAux.c837ClaimHdr && props.data.enterpriseClaimAux.c837ClaimHdr.c837Claim ? props.data.enterpriseClaimAux.c837ClaimHdr.c837Claim : {};


    const fileInformationVO = serviceLineItems && serviceLineItems.fileFormatInfo ? serviceLineItems.fileFormatInfo : {};
    const repricedClaim = props.data.enterpriseClaimAux && props.data.enterpriseClaimAux.c837ClaimHdr && props.data.enterpriseClaimAux.c837ClaimHdr.c837SpecializedService && props.data.enterpriseClaimAux.c837ClaimHdr.c837SpecializedService.repricedClaimInfo ? props.data.enterpriseClaimAux.c837ClaimHdr.c837SpecializedService.repricedClaimInfo : {};
    //const toothStatus = mainDataList && mainDataList.c837DentalClaims ? mainDataList.c837DentalClaims : {};
    //const toothStatusList = toothStatus && toothStatus[lineIndex].toothStatusInfo ? toothStatus[lineIndex].toothStatusInfo : {};
    //console.log('Orthodontic', claimInformationOrthoDontic);
    //console.log('Service facility: ', claimInfoServiceFacilityInfo);
    //.log('Assistant Sergeone: ', assistantSurgeonInfo);
    // console.log('Contract Information: ', contractInformationVO);
    // console.log('File Format: ', fileInformationVO);
    // console.log('Repriced: ', repricedClaim);
    //console.log('Tooth Status: ',toothStatusList);
    
    
    const ClaimProviderInfoCells = [
        {
            id: 'providerIDTypeDesc', numeric: false, disablePadding: true, label: 'ID Type', enableHyperLink: false, fontSize: 12, width: '50%'
        },
        {
            id: 'providerID', numeric: false, disablePadding: false, label: 'ID Number', enableHyperLink: false, fontSize: 12, width: '50%'
        }
    ];

    const toothStatusCells = [
        {
            id: 'toothNumber', numeric: false, disablePadding: true, label: 'Tooth #', enableHyperLink: false, fontSize: 12, width: '50%'
        },
        {
            id: 'toothStatus', numeric: false, disablePadding: false, label: 'Tooth Status', enableHyperLink: false, fontSize: 12, width: '50%'
        }
    ];

    const CoordinationOfBenefitsCells = [
        {
            id: 'sequenceNumber', numeric: false, disablePadding: true, label: 'Sequence Number', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'subscriberQualifierCode', numeric: false, disablePadding: false, label: 'Subscriber ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerID', numeric: false, disablePadding: false, label: 'Payer/Carrier ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'otherPayerName', numeric: false, disablePadding: false, label: 'Payer/Insurance Org', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'tplPaidAmount', numeric: false, disablePadding: false, label: 'Payer Paid Amount', enableHyperLink: false, fontSize: 12
        }
    ];
    const decimals=".00";
    const editRow = row => (event) => {
        setBenefitsData(true)
    };
    return (
        <div className='tab-holder CustomExpansion-panel my-3'>
            <div className='tab-holder CustomExpansion-panel my-3' id="Claim  Information  Div Id">
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content2"
                        id="panelp1a-header2">
                        <Typography className={classes.heading}>Claim Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content21"
                                id="panelp1a-header21">
                                <Typography className={classes.heading}>Orthodontics</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper wrap-form-label">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orthodontic_treatment_months_count"
                                            label="Orthodontic Treatment Months Count"
                                            placeholder=""
                                            data-test='other-claim-info-orthtretcount'
                                            value={claimInformationOrthoDontic.orthoTreatmentMonths ? claimInformationOrthoDontic.orthoTreatmentMonths : "0"}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orthodontic_treatment_months_remaining_count"
                                            label="Orthodontic Treatment Months Remaining Count"
                                            placeholder=""
                                            data-test='other-claim-info-orthtretmonths'
                                            value={claimInformationOrthoDontic.orthoTreatmentMonthsRemaining ? claimInformationOrthoDontic.orthoTreatmentMonthsRemaining : "0"}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="orthodontic_treatment_indicator"
                                            label="Orthodontic Treatment Indicator"
                                            placeholder=""
                                            data-test='other-claim-info-orthtretind'
                                            value={claimInformationOrthoDontic.orthoPurposeCode ? indicatorOrtho : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>

                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header26">
                                <Typography className={classes.heading}>Tooth Status</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="tabs-container inner-collapse-container mt-2">

                                    {/* <TableComponent headCells={toothStatusCells} tableData={toothStatusList} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                                    <TableComponent headCells={toothStatusCells} tableData={toothStatusTable} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content21"
                                id="panelp1a-header22a">
                                <Typography className={classes.heading}>Diagnosis Codes</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="principal_diag_code_diag_code"
                                            label="Principal Diag Code"
                                            placeholder=""
                                            data-test='other-claim-info-princdiagcode'
                                            value={claimIformationDiagnosis.diagnosisType ? claimIformationDiagnosis.diagnosisType : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}

                                        />
                                    </div>

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="other_diagnosis_code1_diag_code"
                                            label="Other Diagnosis Code 1"
                                            placeholder=""
                                            data-test='other-claim-info-othdiagcode1'
                                            ////value={claimDiagnosis.diagCode1 ? claimDiagnosis.diagCode1 : ""}
											value={claimIformationDiagnosis.diagnosisCode ? claimIformationDiagnosis.diagnosisCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="other_diagnosis_code2_diag_code"
                                            label="Other Diagnosis Code 2"
                                            placeholder=""
                                            data-test='other-claim-info-othdiagcode2'
                                            //value={claimDiagnosis.diagCode2 ? claimDiagnosis.diagCode2 : ""}
											value={claimIformationDiagnosis.diagnosisCode ? claimIformationDiagnosis.diagnosisCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="other_diagnosis_code3_diag_code"
                                            label="Other Diagnosis Code 3"
                                            placeholder=""
                                            data-test='other-claim-info-othdiagcode3'
                                            //value={claimDiagnosis.diagCode3 ? claimDiagnosis.diagCode3 : ""}
											value={claimIformationDiagnosis.diagnosisCode ? claimIformationDiagnosis.diagnosisCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>

                                </div>
                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content22"
                                id="panelp1a-header22">
                                <Typography className={classes.heading}>Contract Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>

                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="contract_type_code"
                                            label="Contract Type Code"
                                            placeholder=""
                                            data-test='other-claim-info-conctypecode'
                                            value={contractInformationVO.contractTypeCode ? contractInformationVO.contractTypeCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="contract_amount"
                                            label="Contract Amount"
                                            placeholder=""
                                            data-test='other-claim-info-concamt'
                                            value={contractInformationVO.contractAmount ? contractInformationVO.contractAmount.toFixed(2) : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="contract_percent"
                                            label="Contract Percent"
                                            placeholder=""
                                            data-test='other-claim-info-contperc'
                                            value={contractInformationVO.contractPercentage ? contractInformationVO.contractPercentage.toFixed(2) : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="contract_code"
                                            label="Contract Code"
                                            placeholder=""
                                            data-test='other-claim-info-contcode'
                                            value={contractInformationVO.contractCode ? contractInformationVO.contractCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="terms_discount_percent"
                                            label="Terms Discount Percent"
                                            placeholder=""
                                            data-test='other-claim-info-descperc'
                                            value={contractInformationVO.contractDiscountPercentage ? contractInformationVO.contractDiscountPercentage.toFixed(2) : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                endAdornment: <InputAdornment position="end">%</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="contract_version-id"
                                            label="Contract Version ID"
                                            placeholder=""
                                            data-test='other-claim-info-contid'
                                            value={contractInformationVO.contractVersionID ? contractInformationVO.contractVersionID : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content25"
                                id="panelp1a-header25">
                                <Typography className={classes.heading}>File Information</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>
                                <div className="form-wrapper">
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_1"
                                            label="File Information 1"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo1'
                                            value={fileInformationVO.fileInformation1 ? fileInformationVO.fileInformation1 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_2"
                                            label="File Information 2"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo2'
                                            value={fileInformationVO.fileInformation2 ? fileInformationVO.fileInformation2 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_3"
                                            label="File Information 3"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo3'
                                            value={fileInformationVO.fileInformation3 ? fileInformationVO.fileInformation3 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_4"
                                            label="File Information 4"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo4'
                                            value={fileInformationVO.fileInformation4 ? fileInformationVO.fileInformation4 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_5"
                                            label="File Information 5"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo5'
                                            value={fileInformationVO.fileInformation5 ? fileInformationVO.fileInformation5 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_6"
                                            label="File Information 6"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo6'
                                            value={fileInformationVO.fileInformation6 ? fileInformationVO.fileInformation6 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_7"
                                            label="File Information 7"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo7'
                                            value={fileInformationVO.fileInformation7 ? fileInformationVO.fileInformation7 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_8"
                                            label="File Information 8"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo8'
                                            value={fileInformationVO.fileInformation8 ? fileInformationVO.fileInformation8 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_9"
                                            label="File Information 9"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo9'
                                            value={fileInformationVO.fileInformation9 ? fileInformationVO.fileInformation9 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="file_information_10"
                                            label="File Information 10"
                                            placeholder=""
                                            data-test='other-claim-info-fileinfo10'
                                            value={fileInformationVO.fileInformation10 ? fileInformationVO.fileInformation10 : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content23"
                                id="panelp1a-header23">
                                <Typography className={classes.heading}>Claims Pricing/Repricing</Typography>
                            </ExpansionPanelSummary>
                            <ExpansionPanelDetails>

                                <div className="form-wrapper wrap-form-label">

                                {/* <div className="form-wrapper wrap-form-label"> */}

                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="pricing_methodology_code_price_reprice"
                                            label="Pricing Methodology Code"
                                            placeholder=""
                                            data-test='other-claim-info-pricmethcode'
                                            value={repricedClaim.methodologyCode ? repricedClaim.methodologyCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="allowed_amount_price_reprice"
                                            label="Allowed Amount"
                                            placeholder=""
                                            data-test='other-claim-info-allowamt'
                                            value={repricedClaim.repriceAllowedAmount ? repricedClaim.repriceAllowedAmount.toFixed(2) : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="savings_amount_price_reprice"
                                            label="Savings Amount"
                                            placeholder=""
                                            data-test='other-claim-info-savingamt'
                                            value={repricedClaim.savingsAmount ? repricedClaim.savingsAmount.toFixed(2) : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="organization_identifier_price_reprice"
                                            label="Organization Identifier"
                                            placeholder=""
                                            data-test='other-claim-info-orgident'
                                            value={repricedClaim.organizationID ? repricedClaim.organizationID : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="per_diem_falt_rate_amount_price_reprice"
                                            label="Per Diem or Flat Rate Amt"
                                            placeholder=""
                                            data-test='other-claim-info-rateamt'
                                            value={repricedClaim.repricePerDiemRate ? repricedClaim.repricePerDiemRate.toFixed(2) : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="approved-DRG_code_price_reprice"
                                            label="Approved DRG Code"
                                            placeholder=""
                                            data-test='other-claim-info-approvdrgcode'
                                            value={repricedClaim.repriceAPGCode ? repricedClaim.repriceAPGCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    {/* <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved-APG-Amount"
                                            label="Approved APG Amount"
                                            placeholder=""
                                            //value={repricedClaim.repriceApprovedAPGAmount ? repricedClaim.repriceApprovedAPGAmount : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                            InputProps={{
                                                startAdornment: <InputAdornment position="Start">$</InputAdornment>,
                                            }}
                                        />
                                    </div> */}
                                    {/* <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved-Revenue-Code"
                                            label="Approved Revenue Code"
                                            placeholder=""
                                            //value={repricedClaim.approvedRevenueCode ? repricedClaim.approvedRevenueCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved-Units-Basis-of-Measurement-Code"
                                            label="Approved Units Basis of Measurement Code"
                                            placeholder=""
                                            //value={repricedClaim.approvedUnitCode ? repricedClaim.approvedUnitCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="Approved-Service-Units"
                                            label="Approved Service Units"
                                            placeholder=""
                                            //value={repricedClaim.approvedServiceUnits ? repricedClaim.approvedServiceUnits : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div> */}
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="rejection_reason_code_price_reprice"
                                            label="Rejection Reason Code"
                                            placeholder=""
                                            data-test='other-claim-info-regreasoncode'
                                            value={repricedClaim.repriceRejectReasonCode ? repricedClaim.repriceRejectReasonCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="policy_compliance_code_price_reprice"
                                            label="Policy Compliance Code"
                                            placeholder=""
                                            data-test='other-claim-info-policycomptcode'
                                            value={repricedClaim.repriceComplianceCode ? repricedClaim.repriceComplianceCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                    <div className="mui-custom-form input-md">
                                        <TextField
                                            disabled
                                            id="exception_code_price_reprice"
                                            label="Exception Code"
                                            placeholder=""
                                            data-test='other-claim-info-execcode'
                                            value={repricedClaim.repriceExceptionCode ? repricedClaim.repriceExceptionCode : ""}
                                            InputLabelProps={{
                                                shrink: true,
                                            }}
                                        />
                                    </div>
                                </div>

                            </ExpansionPanelDetails>
                        </ExpansionPanel>

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3' id="Claim Provider Information Div Id">
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content3"
                        id="panelp1a-header3">
                        <Typography className={classes.heading}>Claim Provider Information</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header3a">
                                <Typography className={classes.heading}>Service Facility</Typography>
                            </ExpansionPanelSummary>

                            <ExpansionPanelDetails>
                               
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="org_lastName_ser_facility"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='other-claim-info-lastname'
                                                value={serviceFacilityLastName.lastName  ? serviceFacilityLastName.lastName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    
                                        <div className="mui-custom-form input-md input-md-1-col">
                                            <TextField
                                                disabled
                                                id="address1_ser_facility"
                                                label="Address 1"
                                                placeholder=""
                                                data-test='other-claim-info-add1'
                                                value={claimInfoServiceFacilityInfo.addressLine1 ? claimInfoServiceFacilityInfo.addressLine1 : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md input-md-1-col">
                                            <TextField
                                                disabled
                                                id="address2_ser_facility"
                                                label="Address 2"
                                                placeholder=""
                                                data-test='other-claim-info-add2'
                                                value={claimInfoServiceFacilityInfo.addressLine2 ? claimInfoServiceFacilityInfo.addressLine2 : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                   
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="city_ser_facility"
                                                label="City"
                                                placeholder=""
                                                data-test='other-claim-info-city'
                                                value={claimInfoServiceFacilityInfo.cityName ? claimInfoServiceFacilityInfo.cityName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="state_ser_facility"
                                                label="State"
                                                placeholder=""
                                                data-test='other-claim-info-state'
                                                value={claimInfoServiceFacilityInfo.stateCode ? claimInfoServiceFacilityInfo.stateCode : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="custom-form-wrapp-inner flex-inner p-0">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Zip_and_Extension"
                                                label="Zip & Extension"
                                                placeholder=""
                                                data-test='other-claim-info-zip'
                                                value={claimInfoServiceFacilityInfo.zipCode ? claimInfoServiceFacilityInfo.zipCode.toString().substring(0,5) : ''}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="Zip_and_Extension"
                                                label=""
                                                placeholder=""
                                                data-test='other-claim-info-extension'
                                                value={claimInfoServiceFacilityInfo.zipCode ? claimInfoServiceFacilityInfo.zipCode.toString().substring(5) : ''}
                                                InputLabelProps={{ shrink: true }}
                                            />
                                        </div>
                                        </div>
                                        {/* <div className="mui-custom-form input-md">
                                            <div className="cndt-row">
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="zip_ser_facility"
                                                        label="Zip and Extension"
                                                        placeholder=""
                                                        value={claimInfoServiceFacilityInfo.zipCode ? claimInfoServiceFacilityInfo.zipCode : ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                                <div className="cndt-col-6">
                                                    <TextField
                                                        disabled
                                                        id="ext_ser_facility"
                                                        placeholder=""
                                                        //value={claimInfoServiceFacilityInfo.extension ? claimInfoServiceFacilityInfo.extension : ""}
                                                        InputLabelProps={{
                                                            shrink: true,
                                                        }}
                                                    />
                                                </div>
                                            </div>
                                        </div> */}
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="country_ser_facility"
                                                label="Country"
                                                placeholder=""
                                                data-test='other-claim-info-country'
                                                value={claimInfoServiceFacilityInfo.countryCode ? claimInfoServiceFacilityInfo.countryCode : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="sub_div_code_ser_facility"
                                                label="Subdivision Code"
                                                placeholder=""
                                                data-test='other-claim-info-subdivcode'
                                                value={claimInfoServiceFacilityInfo.countrySubDivisionCode ? claimInfoServiceFacilityInfo.countrySubDivisionCode : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>

                                

                                <Divider className="mt-4" />
                                
                                <div className="tabs-container pb-2">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left"> Secondary IDs </h2>
                                    </div>
                                    {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={secondaryTableSFArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                </div>
                            </ExpansionPanelDetails>

                        </ExpansionPanel>
                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header2a">
                                <Typography className={classes.heading}>Referring Provider</Typography>
                            </ExpansionPanelSummary>

                            <ExpansionPanelDetails>
                                
                                
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="entity_qualifier_ref_prov_info"
                                                label="Entity Qualifier"
                                                placeholder=""
                                                data-test='other-claim-info-entyqualify'
                                                value={referingProviderEntityQual ? referingProviderEntityQual : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="org_lname_ref_prov_info"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='other-claim-info-orglastname'
                                                value={additionalReferringProviderInformation.lastName ? additionalReferringProviderInformation.lastName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="fname_ref_prov_info"
                                                label="First Name"
                                                placeholder=""
                                                data-test='other-claim-info-firstname'
                                                value={additionalReferringProviderInformation.firstName ? additionalReferringProviderInformation.firstName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mi_ref_prov_info"
                                                label="MI"
                                                placeholder=""
                                                data-test='other-claim-info-mi'
                                                value={additionalReferringProviderInformation.middleName ? additionalReferringProviderInformation.middleName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="suffix_ref_prov_info"
                                                label="Suffix"
                                                placeholder=""
                                                data-test='other-claim-info-suffix'
                                                value={additionalReferringProviderInformation.suffixName ? additionalReferringProviderInformation.suffixName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                
                                <Divider className="mt-4" />
                                <div className="tabs-container pb-2">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={claimInfoServiceFacilityInfoSecondaryTable} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                    {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={secondaryTableRFArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                                </div>
                            </ExpansionPanelDetails>

                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header2b">
                                <Typography className={classes.heading}>Primary Care Provider</Typography>
                            </ExpansionPanelSummary>

                            <ExpansionPanelDetails>
                               
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="org_lname_prim_care_prov"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='other-claim-info-primlastname'
                                                value={additionalPrimaryCareProviderInformation.lastName ? additionalPrimaryCareProviderInformation.lastName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="fname_prim_care_prov"
                                                label="First Name"
                                                placeholder=""
                                                data-test='other-claim-info-primfirstname'
                                                value={additionalPrimaryCareProviderInformation.firstName ? additionalPrimaryCareProviderInformation.firstName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mi_prim_care_prov"
                                                label="MI"
                                                placeholder=""
                                                data-test='other-claim-info-primmi'
                                                value={additionalPrimaryCareProviderInformation.middleName ? additionalPrimaryCareProviderInformation.middleName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="suffix_prim_care_prov"
                                                label="Suffix"
                                                placeholder=""
                                                data-test='other-claim-info-primsuffix'
                                                value={additionalPrimaryCareProviderInformation.suffixName ? additionalPrimaryCareProviderInformation.suffixName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                
                                <Divider className="mt-4" />
                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={additionalPrimaryCareProviderInformationIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={secondaryTablePCArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                </div>
                            </ExpansionPanelDetails>

                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header2c">
                                <Typography className={classes.heading}>Assistant Surgeon</Typography>
                            </ExpansionPanelSummary>

                            <ExpansionPanelDetails>
                                
                                
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="org_lname_assist_surgeon"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='other-claim-info-assistlastname'
                                                value={assistantSurgeonInfo.lastName ? assistantSurgeonInfo.lastName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="fname_assist_surgeon"
                                                label="First Name"
                                                placeholder=""
                                                data-test='other-claim-info-assistfirstname'
                                                value={assistantSurgeonInfo.firstName ? assistantSurgeonInfo.firstName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mi_assist_surgeon"
                                                label="MI"
                                                placeholder=""
                                                data-test='other-claim-info-assistmi'
                                                value={assistantSurgeonInfo.middleName ? assistantSurgeonInfo.middleName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="suffix_assist_surgeon"
                                                label="Suffix"
                                                placeholder=""
                                                data-test='other-claim-info-assistsuffix'
                                                value={assistantSurgeonInfo.suffixName ? assistantSurgeonInfo.suffixName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                
                                <Divider className="mt-4" />
                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={additionalAssistantSurgeonIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={secondaryTableASArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                </div>
                            </ExpansionPanelDetails>

                        </ExpansionPanel>

                        <ExpansionPanel className="collapsable-panel">
                            <ExpansionPanelSummary
                                expandIcon={<ExpandMoreIcon />}
                                aria-controls="panelp1a-content2"
                                id="panelp1a-header2d">
                                <Typography className={classes.heading}>Supervising Provider</Typography>
                            </ExpansionPanelSummary>
                            {/* <ExpansionPanelDetails>
                            <ExpansionPanel className="collapsable-panel my-3 collapse-wrapper-inner-form"> */}
                            {/* <ExpansionPanelSummary
                                    expandIcon={<ExpandMoreIcon />}
                                    aria-controls="panelp1a-content21"
                                    id="panelp1a-header23">
                                    <Typography className={classes.heading}>Additional Supervising Provider Information</Typography>
                                </ExpansionPanelSummary> */}
                            <ExpansionPanelDetails>
                                
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="org_lname_sup_prov_info"
                                                label="Org / Last Name"
                                                placeholder=""
                                                data-test='other-claim-info-supprovlastname'
                                                value={supervisingProviderInfo.lastName ? supervisingProviderInfo.lastName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="fname_sup_prov_info"
                                                label="First Name"
                                                placeholder=""
                                                data-test='other-claim-info-supprovfirstname'
                                                value={supervisingProviderInfo.firstName ? supervisingProviderInfo.firstName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="mi_sup_prov_info"
                                                label="MI"
                                                placeholder=""
                                                data-test='other-claim-info-supprovmi'
                                                value={supervisingProviderInfo.middleName ? supervisingProviderInfo.middleName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                        <div className="mui-custom-form input-md">
                                            <TextField
                                                disabled
                                                id="suffix_sup_prov_info"
                                                label="Suffix"
                                                placeholder=""
                                                data-test='other-claim-info-supprovsuffix'
                                               value={supervisingProviderInfo.suffixName ? supervisingProviderInfo.suffixName : ""}
                                                InputLabelProps={{
                                                    shrink: true,
                                                }}
                                            />
                                        </div>
                                    </div>
                                
                                <Divider className="mt-4" />
                                <div className="tabs-container inner-collapse-container">
                                    <div className="tab-header">
                                        <h2 className="tab-heading float-left pt-0"> Secondary IDs </h2>
                                    </div>
                                    {/* <TableComponent headCells={ClaimProviderInfoCells} tableData={additionalSupervisingProviderInformationIdInfo} onTableRowClick={() => { return false; }} defaultSortColumn="id" /> */}
                                    <TableComponent headCells={ClaimProviderInfoCells} tableData={secondaryTableSUArray} onTableRowClick={() => { return false; }} defaultSortColumn="id" />
                                </div>
                            </ExpansionPanelDetails>
                            {/* </ExpansionPanel>

                        </ExpansionPanelDetails> */}
                        </ExpansionPanel>

                    </ExpansionPanelDetails>


                </ExpansionPanel>
            </div>

            <div className='tab-holder CustomExpansion-panel my-3' id="Coordination of Benefits Div Id">
                <ExpansionPanel className="collapsable-panel">
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panelp1a-content4"
                        id="panelp1a-header4">
                        <Typography className={classes.heading} id="cust-label">Coordination of Benefits</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails>

                        <div className="tabs-container">
                            <div className="tab-header mt-1">
                                <h2 className="tab-heading float-left"> Other Insurance </h2>
                            </div>

                            {/* <TableComponent headCells={CoordinationOfBenefitsCells} tableData={coboOtherPayerInsuranceList} onTableRowClick={editRow} defaultSortColumn="payerSeq" /> */}
                            <TableComponent headCells={CoordinationOfBenefitsCells} tableData={coordinationOfBenefitInformation.map((o)=>({...o,tplPaidAmount: o.tplPaidAmount != "" ? '$'+o.tplPaidAmount : o.tplPaidAmount}))}  onTableRowClick={editRow} defaultSortColumn="payerSeq" />
                            {benefitsData ? <ClaimOtherDentalCoordinateOfBenefits tableData={props.data}
                                setBenefitsData={setBenefitsData}

                            /> : null}
                        </div>

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>


        </div>
    );
}

export default withRouter(DentalOtherInfo);