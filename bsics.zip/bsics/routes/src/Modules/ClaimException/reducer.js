import * as actionTypes from './actionTypes';

const axiosPayLoad = {
  payload: null,
  searchFields: null,
  codeExceptionDetails: null,
  type: 'Add',
  exceptionDeleteResponse: null,
  auditLog: {},
  pageLevelAuditLog: null,
  codeIndiAuditLog: null,
  copyData: null,
};
const reducer = (state = axiosPayLoad, action) => {
  switch (action.type) {
    case actionTypes.RESETDATA:
      return axiosPayLoad;
    case actionTypes.CLAIM_EXCEPTION_DETAILS_RESETDATA:
      return { ...state, codeExceptionDetails: null, type: 'Add' };
    case actionTypes.CLAIM_EXCEPTION_SEARCH_TYPE:
      return { ...state, payload: action.claimExceptionSearchData, exceptionSearchTime: new Date(),claimExceptionData:action.claimExceptionData }
    case actionTypes.CLAIM_EXCEPTION_VIEW_DETAILS_TYPE:
      return { ...state, codeExceptionDetails: action.claimExceptionSearchData, codeExceptionDetailsTime: new Date(), type: 'Edit' }
    case actionTypes.CLAIM_EXCEPTION_DELETE:
      return { ...state, exceptionDeleteResponse: action.claimExceptionDeleteData, deleteResponseTime: new Date() }
    case actionTypes.GET_LOCATION_DROPDOWN:
      return { ...state, locationPayload: action.locationData }
    case actionTypes.GET_USER_DROPDOWN:
      return { ...state, userPayload: action.userData }
    case actionTypes.GET_ADJ_RSN_DROPDOWN:
      return { ...state, adjRsnPayload: action.adjRsnData }
    case actionTypes.GET_EOB_DROPDOWN:
      return { ...state, eobPayload: action.eobData }
    case actionTypes.GET_REMARK_DROPDOWN:
      return { ...state, remarkPayload: action.remarkData }
    case actionTypes.AUDIT_LOG: {
      return { ...state, auditLog: { ...state.auditLog, [action.auditType]: action.response } }
    }
    case actionTypes.RESET_AUDIT_DATA: {
      return { ...state, auditLog: {} }
    }
    case actionTypes.CLAIM_EXCEPTION_COPY_DATA:
      return { ...state, codeExceptionDetails: null, type: 'Add', copyData: action.copyData }
    case actionTypes.CLEAR_COPY_DATA_EXCEPTION: 
      return { ...state, copyData: null }
    default: return state;
  }
};

export default reducer;
