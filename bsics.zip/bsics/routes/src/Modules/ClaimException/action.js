/* eslint-disable arrow-parens */
import axios from 'axios';
import * as actionTypes from './actionTypes';
import * as serviceEndPoint from '../../SharedModules/services/service';
import { getLoginUserDetails } from "../../SharedModules/utility/utilityFunction";

const userDetails = getLoginUserDetails();
export const resetSearchClaimException = () => ({
    type: actionTypes.RESETDATA,
    resetData: []
});

export const resetDetailsClaimException = () => ({
    type: actionTypes.CLAIM_EXCEPTION_DETAILS_RESETDATA,
});

export const dispatchClaimExceptionCreate = (response) => ({
    type: actionTypes.CLAIM_EXCEPTION_CREATE,
    claimExceptionCreateData: response
});

export const dispatchClaimExceptionSearch = (response,otherResponse) => ({
    type: actionTypes.CLAIM_EXCEPTION_SEARCH_TYPE,
    claimExceptionSearchData: response,
    claimExceptionData:otherResponse
});

export const dispatchClaimExceptionViewDetails = (response) =>
    ({
        type: actionTypes.CLAIM_EXCEPTION_VIEW_DETAILS_TYPE,
        claimExceptionSearchData: response
    });
export const dispatchLocationDropdown = (response) => ({
    type: actionTypes.GET_LOCATION_DROPDOWN,
    locationData: response,
});
export const dispatchUserDropdown = (response) => ({
    type: actionTypes.GET_USER_DROPDOWN,
    userData: response,
});

export const dispatchAdjRsnDropdown = (response) => ({
    type: actionTypes.GET_ADJ_RSN_DROPDOWN,
    adjRsnData: response,
});
export const dispatchEOBDropdown = (response) => ({
    type: actionTypes.GET_EOB_DROPDOWN,
    eobData: response,
});
export const dispatchRemarkDropdown = (response) => ({
    type: actionTypes.GET_REMARK_DROPDOWN,
    remarkData: response,
});

export const dispatchClaimExceptionUpdate = (response) => ({
    type: actionTypes.CLAIM_EXCEPTION_UPDATE,
    claimExceptionUpdateData: response
});

export const dispatchClaimExceptionDelete = (response) => ({
    type: actionTypes.CLAIM_EXCEPTION_DELETE,
    claimExceptionDeleteData: response
});
export const resetAuditLog = () => ({
    type: actionTypes.RESET_AUDIT_DATA,
    resetData: []
});
export const dispatchAuditLog = (auditData,auditType) => ({
    type: actionTypes.AUDIT_LOG,
    response: auditData && auditData.responseAuditLogDetails?auditData.responseAuditLogDetails:[],
    auditType:auditType
});

export const dispatchAuditLogSk = (auditData,auditType) => ({
    type: actionTypes.AUDIT_LOG,
    response: auditData ?auditData:[],
    auditType:auditType
});

export const dispatchCopyFunction = (copyData) => ({
    type: actionTypes.CLAIM_EXCEPTION_COPY_DATA,
    copyData: copyData
});

export const dispatchClearCopyData = () => ({
    type: actionTypes.CLEAR_COPY_DATA_EXCEPTION
});

export const getAuditLogSkCodeDataAction = (obj, skCodeMap) => dispatch => {

    let auditLogServiceArray = [];
    Object.keys(skCodeMap).forEach((value) => {
        if (value && skCodeMap[value]) {
            let objData = {

                "tableName": obj.tableName,
                "keyValue": {
                    "r_proc_cd": obj.r_proc_cd,
                    [obj.keyName]: skCodeMap[value]
                }
            }
            auditLogServiceArray.push(axios.post(`${serviceEndPoint.AUDIT_LOG_DETAILS}`, objData));
        }
    });
    Promise.all(auditLogServiceArray).then(function (responses) {
        // Get a JSON object from each of the responses
        return Promise.all(responses.map(function (response) {
            return response && response.data && response.data.responseAuditLogDetails?response.data.responseAuditLogDetails : '';
        }));
    }).then(function (data) {
        // Log the data to the console
        // You would do something with both sets of data here
        let uniqueArr=[];
        const flattened = [].concat(...data);
        // let myMap = new Map();
        // uniqueArr = flattened.filter(el=>{
        //     const stringfy = JSON.stringify(el);
        //     const val = myMap.get(stringfy);
        //     if(val){
        //         return false;
        //     }
        //     myMap.set(stringfy,true);
        //     return true;
        // })
       
        dispatch(dispatchAuditLogSk(flattened,obj.auditType));
        
    }).catch(function (error) {
        // if there's an error, log it
        console.log(error);
    });


};

export const getAuditLogDataAction = (values,auditType) => dispatch => {
    return axios.post(`${serviceEndPoint.AUDIT_LOG_DETAILS}`, values)
    .then(response => {
            dispatch(dispatchAuditLog(response.data,auditType));
        
    })
    .catch(error => {
            dispatch(dispatchAuditLog(error.data,auditType));
    })
   
};

export const claimExceptionCreate = (values) => dispatch => {
    const body = values;
    return axios.post(`${serviceEndPoint.ADD_CLAIM_EXCEPTION + '/' + userDetails.loginUserID}`, body)
        .then(response => {
            dispatch(dispatchClaimExceptionCreate(response.data));
        })
        .catch(error => {
            dispatch(dispatchClaimExceptionCreate(error.response.data));
        });
}
export const claimExceptionUpdate = (values) => dispatch => {
    const body = values;
    return axios.post(`${serviceEndPoint.UPDATE_CLAIM_EXCEPTION + '/' + userDetails.loginUserID}`, body)
        .then(response => {
            dispatch(dispatchClaimExceptionUpdate(response.data));
        })
        .catch(error => {
            dispatch(dispatchClaimExceptionUpdate(error.response.data));
        });
}

export const claimExceptionDelete = (values) => dispatch => {
    const body = values;
    return axios.post(`${serviceEndPoint.DELETE_CLAIM_EXCEPTION + '/' + userDetails.loginUserID}`, body)
        .then(response => {
            dispatch(dispatchClaimExceptionDelete(response.data));
        })
        .catch(error => {
            dispatch(dispatchClaimExceptionDelete(error.data));
        });
}


export const searchClaimExceptionAction = (values) => async dispatch => {
    try {
        const response = await axios.post(serviceEndPoint.SEARCH_CLAIM_EXCEPTION, values)
        if (response) {
            dispatch(dispatchClaimExceptionSearch(response.data.data,response.data));
        }

    } catch (error) {
        dispatch(dispatchClaimExceptionSearch(error.data));
    }

}


export const getClaimExceptionDetails = values => dispatch => {

    return axios.get(serviceEndPoint.DETAILS_CLAIM_EXCEPTION + "/" + values.exceptionCode)
        .then(response => {
            dispatch(dispatchClaimExceptionViewDetails(response.data));
        })
        .catch(error => {
            dispatch(dispatchClaimExceptionViewDetails(error.data));
        })
}

export const locationDropdownAction = () => dispatch => {
    return axios.post(`${serviceEndPoint.SERVICE_LOCATION_DROPDOWN_ENDPOINT}`, {})
        .then(response => {
            dispatch(dispatchLocationDropdown(response.data));

        })
        .catch(error => {
            dispatch(dispatchLocationDropdown(error.data));
        })
}

export const userDropdownAction = () => dispatch => {
    return axios.post(`${serviceEndPoint.SERVICE_USER_DROPDOWN_ENDPOINT}`, {})
        .then(response => {
            dispatch(dispatchUserDropdown(response.data));
        })
        .catch(error => {
            dispatch(dispatchUserDropdown(error.data));
        })
}

export const adjRsnDropdownAction = () => dispatch => {
    return axios.get(`${serviceEndPoint.ADJ_RSN_DROPDOWN}`)
        .then(response => {
            dispatch(dispatchAdjRsnDropdown(response.data));
        })
        .catch(error => {
            dispatch(dispatchAdjRsnDropdown(error.data));
        })
}
export const remarkDropdownAction = () => dispatch => {
    return axios.get(`${serviceEndPoint.REMARK_DROPDOWN}`)
        .then(response => {
            dispatch(dispatchRemarkDropdown(response.data));
        })
        .catch(error => {
            dispatch(dispatchRemarkDropdown(error.data));
        })
}
export const eobDropdownAction = () => dispatch => {
    return axios.get(`${serviceEndPoint.EOB_DROPDOWN}`)
        .then(response => {
            dispatch(dispatchEOBDropdown(response.data));
        })
        .catch(error => {
            dispatch(dispatchEOBDropdown(error.data));
        })
}