import React, { useState, useEffect, useRef } from 'react'
import { withRouter } from 'react-router';
import { Button } from 'react-bootstrap';
import { useDispatch, useSelector } from 'react-redux';
import Tabs from '@material-ui/core/Tabs';
import Tab from '@material-ui/core/Tab';
import AppBar from '@material-ui/core/AppBar';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import TabPanel from '../../../SharedModules/TabPanel/TabPanel';
import Spinner from '../../../SharedModules/Spinner/Spinner';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';
import ErrorComponent from '../../../SharedModules/Errors/TimeOutErrorMsg';
import SuccessComponent from '../../../SharedModules/Errors/TimeOutSuccessMsg';
import dateFnsFormat from "date-fns/format";
import Main from "./Main/Main";
import * as Dropdowns from '../../../SharedModules/Dropdowns/dropdowns';
import { GET_APP_DROPDOWNS } from '../../../SharedModules/Dropdowns/actions';
import ResponseEdit from './Response/ResponseEdit';
import { getLoginUserDetails } from "../../../SharedModules/utility/utilityFunction";
import { claimExceptionUpdate,claimExceptionDelete,locationDropdownAction,userDropdownAction,adjRsnDropdownAction,remarkDropdownAction,eobDropdownAction,getClaimExceptionDetails,getAuditLogDataAction,resetAuditLog,getAuditLogSkCodeDataAction,dispatchCopyFunction } from "../action";
import DispositionDetails from './Disposition/DispositionDetails';
import ClaimExceptionMajor from "./ClaimExceptionMajor";
import Resolution from './Resolution/Resolution';
import * as ComponentMsg from '../../../SharedModules/Messages/ErrorMsgConstants';
import * as moment from "moment";
import "moment-range";
import { useConfirm } from "../../../SharedModules/MUIConfirm/index";
import Axios from 'axios';
import * as serviceEndPoint from '../../../SharedModules/services/service';
import AuditLog from '../../../SharedModules/AuditLog/AuditLog';
import * as AuditConstant from '../../../SharedModules/AuditLog/AuditLogConstants';


function ClaimExcpetionEdit(props) {
  const muiconfirm = useConfirm();
  const [tabValue, setTabValue] = useState(0);
  const onSearchView = searchvalues => dispatch(getClaimExceptionDetails(searchvalues));
  const updateClaimException = (values) => dispatch(claimExceptionUpdate(values));
  const deleteClaimException = (values) => dispatch(claimExceptionDelete(values));
  const onCopyView = (values) => dispatch(dispatchCopyFunction(values));
  const codeExceptionDetails = useSelector(state => state.claimException.codeExceptionDetails);
  const codeExceptionDetailsTime = useSelector(state => state.claimException.codeExceptionDetailsTime);
  const exceptionDeleteResponse = useSelector(state => state.claimException.exceptionDeleteResponse);
  const deleteResponseTime = useSelector(state => state.claimException.deleteResponseTime);
  const [claimExceptionLocationVO, setClaimExceptionLocationVO] = useState([]);
  const [claimExceptionRemarkVO, setClaimExceptionRemarkVO] = useState([]);
  const [claimExceptionResponseVO, setClaimExceptionResponseVO] = useState([]);
  const [spinnerLoader, setspinnerLoader] = useState(false);
  const disposition = useRef();
  const printRef = useRef();
  const resolutionTabRef = useRef(null);
  const [errorMessages, seterrorMessages] = useState([]);
  const [successMessages, setSuccessMessages] = useState([]);
  const dispatch = useDispatch();
  const onDropdowns = (values) => dispatch(GET_APP_DROPDOWNS(values));
  const addDropdowns = useSelector(state => state.appDropDowns.appdropdowns);
  const userDetails = getLoginUserDetails();
  const [dispositionTableData, setDispositionTableData] = useState([]);
  const [dispositionValues, setDispositionValues] = useState(codeExceptionDetails && codeExceptionDetails.data?codeExceptionDetails.data.dispositionKeyVO : {});
  const [claimExceptionResolutionVO,setClaimExceptionResolutionVO] = useState([]);
  const [majorEdit,setMajorEdit] = useState(true);
  const [{excCodeReqErr, biginDateReqErr, endDateReqErr, beginDateInvalidErr, endDateInvalidErr, beginDateGrtEndDateErr,
    shortDescReqErr, longDescReqErr, lobFilterErr, tracNumInvErr, excCodeInvErr, adjustmentDuplicateErr,reasonDuplicateErr,
    despositionCheck}, setMajorCompErrors] = useState(false);
    const [values, setValues] = useState(codeExceptionDetails);

  const getLocationDropDown = () => dispatch(locationDropdownAction());
  const getUserDropDown = () => dispatch(userDropdownAction());
  const getAdjRsnDropDown = () => dispatch(adjRsnDropdownAction());
  const getRemarkDropDown = () => dispatch(remarkDropdownAction());
  const getEOBDropDown = () => dispatch(eobDropdownAction());
  const locationDropdown = useSelector(state => state.claimException.locationPayload);
  const userDropDown = useSelector(state => state.claimException.userPayload);
  const adjRsnDropdown = useSelector(state => state.claimException.adjRsnPayload);
  const remarkDropDown = useSelector(state => state.claimException.remarkPayload);
  const eobDropDown = useSelector(state => state.claimException.eobPayload);
  const [locationDeleteList,setLocationDeleteList] = useState([]);
  const [dispositionDeleteList, setDispositionDeleteList] = useState([]);
  const [remarkDeleteList,setRemarkDeleteList] = useState([]);
  const [majorValues, setMajorValues] = useState({
    exceptionCode: "",
    beginDate: null,
    endDate: null,
    shortDescription: "",
    longDescription: "",
    lobCode: "MED",
    lobDesc: "MED-MEDICAID"
  });

  const [claimExceptionDefaultVO, setClaimExceptionDefaultVO] = useState({
    "versionNo" : 0,
    "adjustmentReasonCode1": "-1",
    "adjustmentReasonCode2": "-1",
    "adjustmentReasonCode3": "-1",
    "remarkCode1": "-1",
    "remarkCode2": "-1",
    "remarkCode3": "-1",
    "eobCode": "-1",
    "locationCode":"-1",
    "userID": "-1",
    "trackingNum": "",
    "uncleanClaim": false,
    "reportType": "S",
    "autoRecycle": "0"
  });

  const [responseFormData, setResponseFormData] = useState({
    "mediaTypeSel": "",       
    "mediaType": "-1",
    "copyMediaType": "-1",
    "responseText": "",
    "void": "0",
    "copyFlag":true
  });

  const handleMajorValuesChanges = name => (event) => {
    // if (name == "lobCode") {
    //   setMajorValues({ ...majorValues, [name]: event.target.value, lobDesc: event.nativeEvent.target.textContent });
    // } else {
      setMajorValues({ ...majorValues, [name]: event.target.value });
    // }
  };

  const handleMajorValuesDCDtChange = (name, date) => {
    setMajorValues({ ...majorValues, [name]: date });
  };

  const handleDefaultExceptionChanges = name => (event) => {
    setClaimExceptionDefaultVO({ ...claimExceptionDefaultVO, [name]: event.target.value });
  };

   function a11yProps(index) {
    return {
      id: `scrollable-auto-tab-${index}`,
      'aria-controls': `scrollable-auto-tabpanel-${index}`,
    };
  } 

  const handelFilter = () => {
    seterrorMessages([]);
    setSuccessMessages([]);
    if (majorValues.lobCode == '-1') {
      seterrorMessages([ComponentMsg.CLAIM_LOB_FILTER]);
      return false;
    }
    if (addDropdowns['Claims#R_LOB_CD'] && addDropdowns['Claims#R_LOB_CD'].length > 0) {
      addDropdowns['Claims#R_LOB_CD'].map(each => {
        if (each.code == majorValues.lobCode) {
          setMajorValues({ ...majorValues, lobDesc: each.description });
        }
      })
    }
  };

  useEffect(() => {
    onDropdowns([
      Dropdowns.CLAIM_EXC_C_BATCH_DOC_TY_CD,
      Dropdowns.CLAIM_EXC_C_BATCH_MEDIA_SRC_CD,
      Dropdowns.CLAIM_EXC_C_TY_CD,
      Dropdowns.CLAIM_EXC_R_TXT_LOCN_CD,
      Dropdowns.CLAIM_EXC_R_ADJ_RSN_CD,
      Dropdowns.CLAIM_EXC_R_RMK_CD,
      Dropdowns.CLAIM_EXC_R_CLM_EOB_CD,
      Dropdowns.CLAIMS_INQUIRY_MEDIA,
      Dropdowns.VV_DOC_TYPE,
      Dropdowns.DISPOSITION_TYPE,
      Dropdowns.FORCE_PAY,
      Dropdowns.FORCE_DENY,
      Dropdowns.REV_LOB,
    ]);
    getLocationDropDown();
    getUserDropDown();
    getAdjRsnDropDown();
    getRemarkDropDown();
    getEOBDropDown();
    if (props.showSuccessMessage) {
      setSuccessMessages(["Claim Exception added successfully."]);
      props.setShowSuccessMessage(false);
    }   
    if(props.location.tab){
      setTabValue(+props.location.tab);
    }
  }, []);

  const [newDataUpdate, setNewDataUpdate] = useState(false);

  const getLobDetail = (code) => {
    if (addDropdowns['Claims#R_LOB_CD'] && addDropdowns['Claims#R_LOB_CD'].length > 0) {
      let desc = ""
      addDropdowns['Claims#R_LOB_CD'].map(each => {
        if (each.code == majorValues.lobCode) {
          desc = each.description
        }
      });
      return desc;
    } else {
      return ""
    }
  };

  useEffect(() => {
    if (codeExceptionDetails && codeExceptionDetails.data) {
      let claimExceptionLocation = codeExceptionDetails.data.claimExceptionLocationVO;
      setClaimExceptionLocationVO(claimExceptionLocation);
      let claimExceptionRemark = codeExceptionDetails.data.claimExceptionRemarkVO;
      setClaimExceptionRemarkVO(claimExceptionRemark);
      setDispositionValues(codeExceptionDetails.data.dispositionKeyVO);
      setMajorValues({
        exceptionCode: codeExceptionDetails.data.exceptionCode,
        beginDate: codeExceptionDetails.data.beginDate,
        endDate: codeExceptionDetails.data.endDate,
        shortDescription: codeExceptionDetails.data.shortDescription,
        longDescription: codeExceptionDetails.data.longDescription,
        lobCode: codeExceptionDetails.data.lobCode,
        lobDesc: getLobDetail(codeExceptionDetails.data.lobCode)
      });
      if (codeExceptionDetails.data.claimExceptionDefaultVO && codeExceptionDetails.data.claimExceptionDefaultVO.length > 0) {
        setClaimExceptionDefaultVO({
          "versionNo" : codeExceptionDetails.data.claimExceptionDefaultVO[0].versionNo,
          "adjustmentReasonCode1": codeExceptionDetails.data.claimExceptionDefaultVO[0].adjustmentReasonCode1,
          "adjustmentReasonCode2": codeExceptionDetails.data.claimExceptionDefaultVO[0].adjustmentReasonCode2,
          "adjustmentReasonCode3": codeExceptionDetails.data.claimExceptionDefaultVO[0].adjustmentReasonCode3,
          "remarkCode1": codeExceptionDetails.data.claimExceptionDefaultVO[0].remarkCode1,
          "remarkCode2": codeExceptionDetails.data.claimExceptionDefaultVO[0].remarkCode2,
          "remarkCode3": codeExceptionDetails.data.claimExceptionDefaultVO[0].remarkCode3,
          "eobCode": codeExceptionDetails.data.claimExceptionDefaultVO[0].eobCode,
          "locationCode":codeExceptionDetails.data.claimExceptionDefaultVO[0].locationCode,
          "userID": codeExceptionDetails.data.claimExceptionDefaultVO[0].userID,
          "trackingNum": codeExceptionDetails.data.claimExceptionDefaultVO[0].trackingNum,
          "uncleanClaim": codeExceptionDetails.data.claimExceptionDefaultVO[0].uncleanClaim,
          "reportType": codeExceptionDetails.data.claimExceptionDefaultVO[0].reportType,
          "autoRecycle": codeExceptionDetails.data.claimExceptionDefaultVO[0].autoRecycle
        });
      }
      let claimExceptionResponse=codeExceptionDetails.data.claimExceptionExternalRespVO;
      setClaimExceptionResponseVO(claimExceptionResponse);
      setClaimExceptionResolutionVO(codeExceptionDetails.data.claimExceptionResolutionVO?codeExceptionDetails.data.claimExceptionResolutionVO:[]);
      setNewDataUpdate(true);
    }
  }, [codeExceptionDetailsTime])
  const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
  const auditRef = useRef();
  const [showAuditLog, setShowAuditLog] = useState(false);
  const [subAuditLogData, setAuditLogData] = useState({});
  const getAuditLogData = (data,type) => dispatch(getAuditLogDataAction(data,type));
  const getAuditLogSkCodeData  = (dataObj,skCodeMap) => dispatch(getAuditLogSkCodeDataAction(dataObj,skCodeMap));
  const [auditLogQueryData, setAuditLogQueryData] = useState(
    {
      [AuditConstant.AUDIT_LOG_CLM_EXC_LOC]: {
        tableName: "r_clm_exc_locn_tb",
        keyName: "r_clm_exc_locn_sk"
      },
      [AuditConstant.AUDIT_LOG_CLM_EXC_RMK]: {
        tableName: "r_clm_exc_rmk_tb",
        keyName: "r_clm_exc_rmk_sk"
      },
     

    }
  )
  const onAuditLog = (auditLogVal, scroll) => {
    if (auditLogVal) {
      let obj = {
        "tableName": "r_clm_exc_tb",
        "keyValue": {
          "r_clm_exc_cd": majorValues.exceptionCode
        }
      }
      if (scroll) {
        setTimeout(function () {
          scrollToRef(auditRef);
        }.bind(this), 1000);
      }
      getAuditLogData(obj, AuditConstant.PAGE_LEVEL);
    }
  }
   
  const getAuditLogTab = (keyValue, auditType) => {
    let obj = {
      "tableName": auditLogQueryData[auditType].tableName,
      "keyValue": {
        "r_clm_exc_cd": majorValues.exceptionCode,
        [auditLogQueryData[auditType].keyName]: keyValue,
      }

    }
    getAuditLogData(obj, auditType);
  }

  
  

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return "";
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };
  let responseDataObj={
    "auditUserID": userDetails.loginUserName,
    "auditTimeStamp": new Date(),
    "addedAuditUserID": userDetails.loginUserName,
    "addedAuditTimeStamp": new Date(),
    "versionNo": 0,
    "dbRecord": false,
    "sortColumn": null,
    "responseText": "",
    "mediaType": "",
    "tempMediaType": null,
    "responseMediaTypeCode": null,
    "externalRespSK": null,
    "voidDate": null,
    "showVoids": false,
    "showVoidRecord": true,
    "copyMediaType": null,
    "cexValue": null,
    "cexVersionNo": 0,
    "responseFlag": false,
    "mediaTypeDesc": null,
    "tempVoidDate": null
}
const serviceSuccessHandel = () => {
  setSuccessMessages(["Claim exception updated successfully."])
  onSearchView({ exceptionCode: majorValues.exceptionCode });
}

const defaultResolutionTabData = {  
  "versionNo": 0,
  "mediaType": "",
  "resolutionText":""
};

const getResolutionTabData = () => {
  let resolutionTabData = resolutionTabRef.current.getState();
  let claimExceptionResolution = [];
  if(resolutionTabData.mediaTypeSelect=="all"){
    claimExceptionResolution = resolutionTabData.editMediaSrcLeft.map(each => ({
      ...defaultResolutionTabData,
      mediaType:each.code,
      resolutionText:resolutionTabData.resolutionText,
      voidDate:resolutionTabData.voidCheckYesNo=="true"?formatDate(new Date()):null
    }));                 
  }
  if(resolutionTabData.mediaTypeSelect=="specific" && resolutionTabData.mediaType!="-1"){
    claimExceptionResolution.push(
      {...defaultResolutionTabData,
        mediaType:resolutionTabData.mediaType,
        resolutionText:resolutionTabData.resolutionText,
        voidDate:resolutionTabData.voidCheckYesNo=="true"?formatDate(new Date()):null
      });
  }
  return [...claimExceptionResolutionVO,...claimExceptionResolution];
};

  const majorSave = () => {
    setSuccessMessages([]);
    if (majorValidations()) {  
      let errorMessagesArray = [];
      setMajorCompErrors({
        tracNumInvErr: (claimExceptionDefaultVO.trackingNum != '' && claimExceptionDefaultVO.trackingNum != null) && !isNumaric(claimExceptionDefaultVO.trackingNum) ? (() => {errorMessagesArray.push(ComponentMsg.TRACK_NUM_INVALID); return true})() : false,
        // lobFilterErr: majorValues.lobCode == "-1" ? (() => {errorMessagesArray.push(ComponentMsg.CLAIM_LOB_FILTER); return true})() : false
        despositionCheck: dispositionValues.length == 0 || claimExceptionRemarkVO.length == 0 || claimExceptionLocationVO.length == 0 ? (() => {errorMessagesArray.push(ComponentMsg.CLAIM_REQ_TABS); return true})() : false,
        adjustmentDuplicateErr: duplicateCheck([claimExceptionDefaultVO.adjustmentReasonCode1, claimExceptionDefaultVO.adjustmentReasonCode2, claimExceptionDefaultVO.adjustmentReasonCode3]) ? (() => {errorMessagesArray.push(ComponentMsg.DUPLICATE_ADJUSTMENT_ERR); return true})() : false, 
        reasonDuplicateErr: duplicateCheck([claimExceptionDefaultVO.remarkCode1, claimExceptionDefaultVO.remarkCode2, claimExceptionDefaultVO.remarkCode3]) ? (() => {errorMessagesArray.push(ComponentMsg.DUPLICATE_REASON_CODE); return true})() : false, 
        despoDenyOrSuspErr: checkDespositionDenyOrSuspend() ? (() => {errorMessagesArray.push(ComponentMsg.DENT_SUSP_DESP); return true})() : false, 
        despoSuspendErr: checkDespositionSusoend() ? (() => {errorMessagesArray.push(ComponentMsg.SUSP_DESP_ERR); return true})() : false, 
    });
    if (errorMessagesArray.length > 0) {
        seterrorMessages(errorMessagesArray);
        setspinnerLoader(false);
        return false;
    }
      let tabResponseData=[];  
      let responsePayloadData=[]
      if(responseFormData.mediaTypeSel==='all'){
        let editMediaTypeArray=claimExceptionResponseVO.map(e =>(
          e.mediaType
      ));
      //tabResponseData
      tabResponseData= addDropdowns && addDropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'] && addDropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => {
          if ( editMediaTypeArray.indexOf(each.code) == -1 ){           
             return {...responseDataObj,mediaType:each.code,responseText:responseFormData.responseText};           
        } 
        }); 
        tabResponseData = tabResponseData.filter(item => item !== undefined && item !== null);     

      }else{
        if(responseFormData.mediaType!=="-1"){
        responseDataObj.mediaType=responseFormData.mediaType;
        responseDataObj.responseText=responseFormData.responseText;
        responseDataObj.voidDate=responseFormData.void==="1" ? formatDate(new Date()) : "";
        tabResponseData.push(responseDataObj);
        }        
      }
      if(responseFormData.copyMediaType!=="-1" && !responseFormData.copyFlag){
        let copyMediaUpdate=claimExceptionResponseVO.map(each => {    
          if(each.mediaType==responseFormData.copyMediaType){
            each.responseText=responseFormData.responseText;
            each.voidDate=responseFormData.void==="1" ? formatDate(new Date()) : "";
          }   
          return each;
        }); 
        responsePayloadData=  copyMediaUpdate;         
      }else{
        responsePayloadData=tabResponseData.concat(claimExceptionResponseVO);
      }
      
      let dataObj = {
        "auditUserID": userDetails.loginUserName,
        "auditTimeStamp": new Date(),
        "addedAuditUserID": userDetails.loginUserName,
        "addedAuditTimeStamp": new Date(),
        "versionNo": values.data.versionNo ? values.data.versionNo : 0,
        "beginDate": moment(majorValues.beginDate).format('MM/DD/YYYY'),
        "exceptionCode": majorValues.exceptionCode,
        "endDate": moment(majorValues.endDate).format('MM/DD/YYYY'),
        "longDescription": majorValues.longDescription,
        "shortDescription": majorValues.shortDescription,
        "lobCode": majorValues.lobCode,
        "claimExceptionDefaultVO": [{
          "auditUserID": userDetails.loginUserName,
          "auditTimeStamp": new Date(),
          "addedAuditUserID": userDetails.loginUserName,
          "addedAuditTimeStamp": new Date(),
          "versionNo": claimExceptionDefaultVO.versionNo,
          "adjustmentReasonCode1": claimExceptionDefaultVO.adjustmentReasonCode1 == "-1" ? null : claimExceptionDefaultVO.adjustmentReasonCode1,
          "adjustmentReasonCode2": claimExceptionDefaultVO.adjustmentReasonCode2 == "-1" ? null : claimExceptionDefaultVO.adjustmentReasonCode2,
          "adjustmentReasonCode3": claimExceptionDefaultVO.adjustmentReasonCode3 == "-1" ? null : claimExceptionDefaultVO.adjustmentReasonCode3,
          "remarkCode1": claimExceptionDefaultVO.remarkCode1 == "-1" ? null : claimExceptionDefaultVO.remarkCode1,
          "remarkCode2": claimExceptionDefaultVO.remarkCode2 == "-1" ? null : claimExceptionDefaultVO.remarkCode2,
          "remarkCode3": claimExceptionDefaultVO.remarkCode3 == "-1" ? null : claimExceptionDefaultVO.remarkCode3,
          "eobCode": claimExceptionDefaultVO.eobCode == "-1" ? null : claimExceptionDefaultVO.eobCode,
          "locationCode":claimExceptionDefaultVO.locationCode == "-1" ? null : claimExceptionDefaultVO.locationCode,
          "userID": claimExceptionDefaultVO.userID == "-1" ? null : claimExceptionDefaultVO.userID,
          "trackingNum": claimExceptionDefaultVO.trackingNum,
          "uncleanClaim": claimExceptionDefaultVO.uncleanClaim,
          "reportType": claimExceptionDefaultVO.reportType,
          "autoRecycle": claimExceptionDefaultVO.autoRecycle
        }],
        "claimExceptionExternalRespVO": responsePayloadData,
        "claimExceptionLocationVO": claimExceptionLocationVO,
        "claimExceptionRemarkVO": claimExceptionRemarkVO,
        "claimExceptionResolutionVO": getResolutionTabData(),
        "dispositionKeyVO":dispositionValues,
        "deletedLocationsObjectsSet": locationDeleteList.length>0?locationDeleteList:null,
        "deleteRemarkObjectsSet": remarkDeleteList.length>0?remarkDeleteList:null,
        "deleteDispositionObjectsSet":  dispositionDeleteList
      }
      setspinnerLoader(true);
      Axios.post(`${serviceEndPoint.UPDATE_CLAIM_EXCEPTION+"/"+userDetails.loginUserID}`,dataObj).then(res=>{      
        setspinnerLoader(false);
        if(res.data.success === true){
          serviceSuccessHandel();
        }
        else{
          
            seterrorMessages(["Claim Exception not added!"]);
        
        }
      }).catch(e=>{
        setspinnerLoader(false);      
        seterrorMessages([e.message]);
      });
    }
  }

  const handleTabChange = (event, newValue) => {
    setTabValue(newValue);
    // if (tabValue == 0) {
    //   setTabValue(newValue);
    // } else if (tabValue == 1) {
    //   setTabValue(newValue);
    // } else if (tabValue == 2) {
    //   setTabValue(newValue);
    // } else if (tabValue == 3) {
    //   setTabValue(newValue);
    // } else {
    //   setTabValue(newValue);
    // }
  };

  const handleDispositionFormChanges = (name) => event => {
    setDispositionValues({ ...dispositionValues, [name]: event.target.value });
  };


  const cancelClaimException = () => {
    props.setCancelType(true);
    props.history.push({
      pathname: '/ClaimException'
    })
  }

  const isAlphaNumaric = (str) => {
    return /^[A-Za-z0-9]+$/.test(str);
  };

  const isNumaric = (str) => {
    return /^[0-9]+$/.test(str);
  };

  const duplicateCheck = (arr) => {
    let check = arr.filter((item, index) => arr.indexOf(item) != index);
    let fCheck = check.filter((item, index) => item != "" && item != null && item != "-1");
    return fCheck.length > 0
  };

  const checkDespositionDenyOrSuspend = () => {
    if (dispositionValues.length > 0) {
    let check = false;
    dispositionValues.map(eachDesposition => {
      eachDesposition.dispositionDetails && eachDesposition.dispositionDetails.map(each => {
        if (each.disposition == '3' || each.disposition == '4') {
          check = true
        }
      })
    });
    if (check && (!(
      claimExceptionDefaultVO.adjustmentReasonCode1 != '-1' && claimExceptionDefaultVO.adjustmentReasonCode1 != null ||
      claimExceptionDefaultVO.adjustmentReasonCode2 != '-1' && claimExceptionDefaultVO.adjustmentReasonCode2 != null ||
      claimExceptionDefaultVO.adjustmentReasonCode3 != '-1' && claimExceptionDefaultVO.adjustmentReasonCode3 != null
      ) || !(claimExceptionDefaultVO.eobCode != '-1' && claimExceptionDefaultVO.eobCode != null))) {
      return true;
    };
    return false;
  }
  return false
  };

  const checkDespositionSusoend = () => {
    if (dispositionValues.length > 0) {
    let check = false;
    dispositionValues.map(eachDesposition => {
      eachDesposition.dispositionDetails.map(each => {
        if (each.disposition == '4') {
          check = true
        }
      })
    });
    if (check && !(claimExceptionDefaultVO.locationCode != '-1' && claimExceptionDefaultVO.locationCode != null)) {
      return true;
    };
    return false;
  }
  return false
  };

  const majorValidations = () => {
    seterrorMessages([]);
    let errorMessagesArray = [];
    setMajorCompErrors({
        excCodeReqErr: majorValues.exceptionCode == "" ? (() => {errorMessagesArray.push(ComponentMsg.URC_ExeptionCode_Req_Error); return true})() : false, 
        excCodeInvErr: majorValues.exceptionCode != "" && !isAlphaNumaric(majorValues.exceptionCode) ? (() => {errorMessagesArray.push(ComponentMsg.EXCEP_NUM); return true})() : false,
        biginDateReqErr: majorValues.beginDate ? false : (() => {errorMessagesArray.push(ComponentMsg.Begin_Date_Error); return true})(), 
        endDateReqErr: majorValues.endDate ? false : (() => {errorMessagesArray.push(ComponentMsg.End_Date_Error); return true})(), 
        beginDateInvalidErr: majorValues.beginDate && majorValues.beginDate.toString() == "Invalid Date" ? (() => {errorMessagesArray.push(ComponentMsg.Invalid_Begin_Date_Error); return true})() : false, 
        endDateInvalidErr: majorValues.endDate && majorValues.endDate.toString() == "Invalid Date" ? (() => {errorMessagesArray.push(ComponentMsg.The_Invalid_End_Date_Error); return true})() : false, 
        beginDateGrtEndDateErr: majorValues.endDate && majorValues.beginDate && majorValues.beginDate.toString() != "Invalid Date" && majorValues.endDate.toString() != "Invalid Date" && moment(majorValues.beginDate).isSameOrAfter(majorValues.endDate) ? (() => {errorMessagesArray.push(ComponentMsg.BEGIN_DT_GRT_END_DT); return true})() : false,
        shortDescReqErr: majorValues.shortDescription ? false : (() => {errorMessagesArray.push(ComponentMsg.Short_Desc_Error); return true})(), 
        longDescReqErr: majorValues.longDescription ? false : (() => {errorMessagesArray.push(ComponentMsg.Long_Desc_Error); return true})(),
    });
    if (errorMessagesArray.length > 0) {
        seterrorMessages(errorMessagesArray);
        setspinnerLoader(false);
        return false;
    }
    return true;
  }

  const handleChangesResponse = (obj) => {
    setResponseFormData({ ...responseFormData,...obj });
  };

  const handelExceptionDelete = () => {
    muiconfirm({
      title: "",
      description: "Are you sure that you want to delete.",
      dialogProps: { fullWidth: false },
    }).then(() => {
      seterrorMessages([]);
      setSuccessMessages([]);
      if (new Date(majorValues.beginDate) < new Date(new Date().setHours(0, 0, 0, 0))) {
        seterrorMessages([ComponentMsg.BDT_LT_CDT_DELETE_ERROR]);
        return false;
      }
      setspinnerLoader(true);
      deleteClaimException(values.data);
    });
  };

  const [deleteRedirect, setDeleteRedirect] = useState(0);
  useEffect(() => {
    if (exceptionDeleteResponse) {
      if (exceptionDeleteResponse.success) {
        props.setConfirm(true);
        setDeleteRedirect(1);
      } else {
        seterrorMessages([ComponentMsg.ERROR_OCCURED_DURING_TRANSACTION])
      }
    }
  }, [deleteResponseTime]);

  useEffect(() => {
    if (deleteRedirect == 1){
      props.history.push({
        pathname: '/ClaimException',
        state: {type: "Delete_Success"}
      })
  }},[deleteRedirect]);

  const handelCopyFunction = () => {
    setspinnerLoader(true);
    let coptData = {
      claimExceptionLocationVO,
      claimExceptionRemarkVO,
      dispositionValues,
      claimExceptionDefaultVO,
      claimExceptionResponseVO,
      claimExceptionResolutionVO
    };
    onCopyView(coptData);
  };

  return (
    <div className="pos-relative">
      {spinnerLoader ? <Spinner /> : null}
      <ErrorComponent errorMessages={errorMessages} setErrorMessages={seterrorMessages} />
      <SuccessComponent successMessages={successMessages} setSuccessMessages={setSuccessMessages} />
      <div className="mb-2">
        <BreadCrumbs
          parent="Rules Management"
          child1="Search Claim Exception"
          child2="Edit Claim Exception"
          path="ClaimException"
        />
      </div>
      <div className="tabs-container" ref={printRef}>
        <div className="tab-header claim-btnarea-bdr pb-2 mb-3">
          <h1 className="tab-heading page-heading float-left">
            Claim Exception
            </h1>
          <div className="float-right th-btnGroup">
            <Button title="Save" variant="outlined" color="primary" className="btn btn-ic btn-save" onClick={() => majorSave()}>
              Save
              </Button>
            <Button title="Copy" variant="outlined" color="primary" className="btn btn-ic btn-copy" onClick={() => handelCopyFunction()}>
              Copy
              </Button>
            <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete" onClick={() => handelExceptionDelete()} >
              Delete
              </Button>
            <Button title="Notes" variant="outlined" color="primary" className="btn btn-ic btn-notes" >
              Notes
            </Button>
            <Button title="Audit Log" variant="outlined" color="primary" className={showAuditLog?"btn btn-ic btn-audit selected" :"btn btn-ic btn-audit"} onClick={() => {onAuditLog(!showAuditLog,true); setShowAuditLog(!showAuditLog);}}>
              Audit Log
            </Button>
            <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => cancelClaimException()}>
              Cancel
              </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
                Print
                </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
              Help
              </Button>
          </div>
        </div>
        <div className="clm-inquiry-tabData pull-left">
          <ClaimExceptionMajor type="edit"
          values={majorValues} handleChanges={handleMajorValuesChanges}
          handelDateChanges={handleMajorValuesDCDtChange}
          errors={{excCodeReqErr, biginDateReqErr, endDateReqErr, beginDateInvalidErr, endDateInvalidErr, beginDateGrtEndDateErr,
            shortDescReqErr, longDescReqErr, excCodeInvErr, tracNumInvErr}} />

          <div className="tab-body-bordered my-2">
            <div className='tab-holder custom-tabber'>
              <AppBar position='static' color="default">
                <Tabs value={tabValue} onChange={handleTabChange}
                  indicatorColor="primary"
                  textColor="primary"
                  variant="scrollable"
                  scrollButtons="auto"
                  aria-label="scrollable auto tabs example">
                  <Tab title="Main" label="Main" {...a11yProps(0)} />
                  <Tab title="Disposition" label="Disposition" {...a11yProps(1)} />
                  <Tab title="Resolution" label="Resolution" {...a11yProps(2)} />
                  <Tab title="Response" label="Response" {...a11yProps(3)} />
                </Tabs>
              </AppBar>
              <TabPanel value={tabValue} index={0}>
                <Main
                  dropdowns={addDropdowns}
                  isEditOp={true}
                  majorValues={majorValues}
                  seterrorMessages={seterrorMessages}
                  majorValidations={majorValidations}
                  newDataUpdate={newDataUpdate}
                  claimExceptionDefaultVO={claimExceptionDefaultVO}
                  handleDefaultExceptionChanges={handleDefaultExceptionChanges}
                  setClaimExceptionLocationVO={setClaimExceptionLocationVO}
                  claimExceptionLocationVO={claimExceptionLocationVO}
                  claimExceptionRemarkVO={claimExceptionRemarkVO}
                  setClaimExceptionRemarkVO={setClaimExceptionRemarkVO}
                  locationDropdown ={locationDropdown }
                  userDropDown = {userDropDown }
                  adjRsnDropdown={adjRsnDropdown}
                  remarkDropDown={remarkDropDown}
                  eobDropDown={eobDropDown}
                  setLocationDeleteList = {setLocationDeleteList}
                  setRemarkDeleteList = {setRemarkDeleteList}
                  locationDeleteList={locationDeleteList}
                  remarkDeleteList={remarkDeleteList}
                  errors={{tracNumInvErr}}
                  auditProps={{showAuditLog:showAuditLog,getAuditLogTab:getAuditLogTab,subAuditLogData:subAuditLogData}}
                />
              </TabPanel>
              <TabPanel value={tabValue} index={1}>
                <DispositionDetails
                  dropdown={addDropdowns}
                  handleChanges={handleDispositionFormChanges}
                  tableData={dispositionTableData}
                  dispositionValues={dispositionValues}
                  setDispositionValues={setDispositionValues}
                  errorMessages={errorMessages}
                  seterrorMessages={seterrorMessages}
                  setSuccessMessages={setSuccessMessages}
                  majorEdit = {majorEdit}
                  setMajorEdit={setMajorEdit}
                  setDispositionDeleteList ={setDispositionDeleteList} />
              </TabPanel>
              <TabPanel value={tabValue} index={2}>
              <Resolution 
               ref={resolutionTabRef} 
               dropdown={addDropdowns} 
               isEditOp={true} 
               data={claimExceptionResolutionVO}
               seterrorMessages={seterrorMessages}
              />  
              </TabPanel>
              <TabPanel value={tabValue} index={3}>
              <ResponseEdit 
               dropdowns={addDropdowns}
               isEditOp={true}
               values={null}
               data={claimExceptionResponseVO}
               seterrorMessages={seterrorMessages}
              handleChangesResponse={handleChangesResponse}
              />
              </TabPanel>
            </div>
          </div>
          {showAuditLog ?
            <div ref={auditRef}>
              <AuditLog auditLogData={subAuditLogData && subAuditLogData[AuditConstant.PAGE_LEVEL] ? subAuditLogData[AuditConstant.PAGE_LEVEL] : []} />
            </div>
            : ""}
        </div>
        <div className="clm-inquiry-exceptionData pull-left mb-3">
          <div className="tab-body data-panel mb-4">
            <div className="tab-header">
              <h2 className="tab-heading float-left"> Filter </h2>
            </div>
            <div className="mui-custom-form with-select input-md">
              <TextField
                id="MIDS-lob"
                select
                label="Display Detail for LOB"
                value={majorValues.lobCode}
                onChange={handleMajorValuesChanges('lobCode')}
                placeholder="Please Select One"
                InputLabelProps={{
                  shrink: true,
                }}
              >
                <MenuItem value="-1">Please Select One</MenuItem>
                {addDropdowns &&  addDropdowns['Claims#R_LOB_CD'] && addDropdowns['Claims#R_LOB_CD'].map( each => (
                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                ))}
              </TextField>
            </div>

            <div className="text-right p-2 data-panel-title view-more">
              <Button title="Validate" variant="outlined" color="primary" className="btn btn-ic btn-validate" onClick={handelFilter}>
                Filter
                      </Button>
            </div>
          </div>
        </div>
        <div className="clearfix" />
        <Footer print />
      </div>
    </div>
  )
}

export default withRouter(ClaimExcpetionEdit)