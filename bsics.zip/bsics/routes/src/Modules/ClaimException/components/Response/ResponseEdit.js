import React, { useState, useEffect } from 'react';
import TableComponent from '../../../../SharedModules/Table/Table';
import Checkbox from '@material-ui/core/Checkbox';
import { Button } from 'react-bootstrap';
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import * as ErrorConst from '../../../../SharedModules/Messages/ErrorMsgConstants';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';
import { values } from 'mobx';

const headCellsPresumptiveEligibility = [
    {
        id: 'mediaTypeDesc', numeric: false, disablePadding: true, label: 'Text', enableHyperLink: true, fontSize: 12, width: '50%'
    },
    {
        id: 'voidDate', numeric: false, disablePadding: true, label: 'Void Date', enableHyperLink: false, fontSize: 12, width: '50%'
    }
];

function Response(props) {
    const [showForm, setShowForm] = useState(false);
  //  const [values, setFormData] = useState({});
    const [tableData, setTableData] = useState([]);
    const [editMediaTypeArray, setEditMediaTypeArray] = useState([]);
    const [voidCheck, setVoidCheck] = useState(false);
    const [{ mediaSrcReqErr, mediaSrcPaperErr }, setErrors] = useState(false);
    const [addDropdowns, setaddDropdowns] = useState([]);
    const mediaTypeDrpDwn = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'] && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));

    const copyTextMediaTypeDrpDwn = props.data && props.data.map(each => (
        <MenuItem selected key={each.mediaType} responseText={each.responseText} value={each.mediaType}>{each.mediaTypeDesc}</MenuItem>
    ));

    const mediaTypeDrpDwnForEdit = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'] && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => {
        if(props.data){
            if ( editMediaTypeArray.indexOf(each.code) == -1 ){
                return <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
            }
            //if(each.mediaType!=)
        }else{
            return <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
        }        
    });


    const [mediaTypeFlag, SetMediaTypeFlag]=useState(false);
    const handleVoidCheck = (e) => {
        setVoidCheck(!voidCheck);
        mapPEVoid(!voidCheck);
    };

    const defaultFormData = {
        "mediaTypeSel": "",       
        "mediaType": "-1",
        "copyMediaType": "-1",
        "responseText": "",
        "void": "0",
        "copyFlag":true
    };
    const [formData, setFormData] = useState(defaultFormData);

    const mediaTypeControl = (e) =>{
        if(e.target.value==='all'){
            SetMediaTypeFlag(true);
        }else{
            SetMediaTypeFlag(false); 
        }        
        setFormData({...formData,"mediaTypeSel":event.target.value}) 
        props.handleChangesResponse({"mediaTypeSel":event.target.value});         
    }


    const editRow = row => (e) => {   
        setErrors({mediaSrcReqErr:false,mediaSrcPaperErr:false});
        props.seterrorMessages([]);   
      setFormData({...formData,"responseText":row.responseText,"copyMediaType":row.mediaType,"mediaType":"-1","copyFlag":false}) 
      props.handleChangesResponse({"copyFlag":false,"copyMediaType":row.mediaType,"responseText":row.responseText});
    };
   
    const handleChanges = (name) => (event) => {       
        setFormData({ ...formData, [name]: event.target.value });
        props.handleChangesResponse({[name]: event.target.value});
      };
    
      const copyText =() =>{
        setErrors({mediaSrcReqErr:false,mediaSrcPaperErr:false})
        props.seterrorMessages([])
        if(formData.mediaTypeSel===""){
            setErrors({mediaSrcReqErr:false,mediaSrcPaperErr:false});
            props.seterrorMessages([ErrorConst.CLAIM_EXP_RES_MT]);
            return false;
          }
        if(formData.mediaType==="-1" && formData.copyMediaType==="-1" && formData.mediaTypeSel==='Specific' ){           
            props.seterrorMessages([ErrorConst.CLAIM_EXP_RES_MT_TO,ErrorConst.CLAIM_EXP_RES_MT_FROM]);
            setErrors({mediaSrcReqErr:true,mediaSrcPaperErr:true});
            return false;
        }
        if(formData.mediaType==="-1" && formData.mediaTypeSel!=='all'){
            setErrors({mediaSrcReqErr:true,mediaSrcPaperErr:false});
            props.seterrorMessages([ErrorConst.CLAIM_EXP_RES_MT_TO]);
            return false;
          }
         
          if(formData.copyMediaType==="-1"){
            setErrors({mediaSrcReqErr:false,mediaSrcPaperErr:true});
            props.seterrorMessages([ErrorConst.CLAIM_EXP_RES_MT_FROM]);
            return false;
          }

        if(props.isEditOp){
            if (props.data && props.data.length) {
                let responseSelectedObj=props.data.filter(a => a.mediaType == formData.copyMediaType);
                setFormData({...formData,"responseText": responseSelectedObj ? responseSelectedObj[0].responseText : "","copyFlag":false}) 
                props.handleChangesResponse({"responseText":responseSelectedObj ? responseSelectedObj[0].responseText : "","copyFlag":true});
            }
        }
      }
    const mapPEVoid = (isChecked) => {
       // setShowForm(false);
        if (props.data && props.data.length) {
            if (isChecked) {
                setTableData(props.data);
            } else {               
                setTableData(props.data.filter(a => a.voidDate ? false : true));               
            }
            let mediaTypeArray=props.data.map(e =>(
                e.mediaType
            ));
            setEditMediaTypeArray(mediaTypeArray);
        } else {
            setTableData([]);
        }
    };
    useEffect(() => {
        setFormData({...formData,...props.data}) ;
        setVoidCheck(props.showVoid);
        mapPEVoid(props.showVoid);
    }, [props.data]);
   // console.log('vvvv',tableData);
   const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data); 
      tData = JSON.parse(tData);     
      tData.map((each,index) => {
        each.voidDate = each.voidDate ? each.voidDate.substring(0, 10) : '';
      }); 
      return tData;           
    }else{
      return [];
    }
  }
    return (
        <div className="tabs-container my-3" >
            <div className="tab-body-bordered px-3">
                <div className="tabs-container mt-2">
                    <div className="tab-header">
                        <h2 className="tab-heading float-left txt-trans-none">
                        Response Text applies to all Lines of Business</h2>
                        
                    </div>
                    <div className="tab-holder">
                    <div className="set-form-wrapper">
                        <div className="form-wrapper p-0 sm-flex-end">
                    {props.isEditOp && (
                        <div className="mui-custom-form with-select input-md lg-field-xl">
                            <div className="MuiFormLabel-root MuiInputLabel-shrink"> Void </div>
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="paymentType"
                                    name="paymentType"
                                    value={formData.void ? formData.void : "0"}
                                >
                                    <FormControlLabel
                                        disabled={false}
                                        onChange={handleChanges('void')}
                                        value="1"
                                        control={<Radio color="primary" />}
                                        label="Yes"
                                    />
                                    <FormControlLabel
                                        disabled={false}
                                        value="0"
                                        control={<Radio color="primary" />}
                                        label="No"
                                    />
                                </RadioGroup>
                            </div>
                        </div>
                        )}
                        <div className="mui-custom-form with-select input-md  sm-field-md">
                        <div className="MuiFormLabel-root MuiInputLabel-shrink"> Media Type </div>

                        <div className="sub-radio mt-sub-radio mt-0">
                            <RadioGroup
                                row
                                aria-label="paymentType"
                                name="mediaTypeSel"
                              //  value={formData.mediaTypeSel ? formData.mediaTypeSel : ""}
                                onChange={mediaTypeControl}
                            >
                                <FormControlLabel
                                    disabled={false}
                                    value="all"
                                    control={<Radio color="primary" />}
                                    label="All"
                                />
                                <FormControlLabel
                                    disabled={false}
                                    value="specific"
                                    control={<Radio color="primary" />}
                                    label="Specific"
                                />
                            </RadioGroup>
                        </div>
                        
                        <TextField
                            id="response-media-sorce"
                            select
                            required
                            disabled={mediaTypeFlag}                          
                            value={formData.mediaType ? formData.mediaType : "-1"}
                            inputProps={{ maxLength: 2 }}
                            onChange={handleChanges('mediaType')}
                            placeholder="Please Select One"
                            className="m-0 set-no-margin"
                            helperText={mediaSrcReqErr ? ErrorConst.CLAIM_EXP_RES_MT_TO : null}
                           error={mediaSrcReqErr ? ErrorConst.CLAIM_EXP_RES_MT_TO : null}
                            InputLabelProps={{
                                shrink: true
                            }}
                        >
                            <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                            {mediaTypeDrpDwnForEdit}
                        </TextField>
                        </div>
                    
                        <div className="mui-custom-form with-select input-md set-flex-label  sm-field-md">
                        <TextField
                            label="Copy Text From Media Type"
                            id="response-media-copy"
                            select                            
                            disabled={false}                           
                            value={formData.copyMediaType ? formData.copyMediaType : "-1"}
                            inputProps={{ maxLength: 2 }}
                            onChange={handleChanges('copyMediaType')}
                            placeholder="Please Select One"
                           helperText={mediaSrcPaperErr ? ErrorConst.CLAIM_EXP_RES_MT_FROM : null}
                           error={mediaSrcPaperErr ? ErrorConst.CLAIM_EXP_RES_MT_FROM : null}
                            InputLabelProps={{
                                shrink: true
                            }}                           
                        >                            
                            <MenuItem value="-1">Please Select One</MenuItem> 
                            {copyTextMediaTypeDrpDwn} 
                                                 
                        </TextField>                        
                    </div>
                    <div className="mui-custom-form input-md set-flex-label">
                    <div className="MuiFormControl-root MuiTextField-root">
                        <div className="MuiFormLabel-root MuiInputLabel-root MuiInputLabel-formControl sm-hide"> &nbsp;  </div>
                        <div className="MuiInputBase-root MuiInput-root no-border p-0 sm-mt-0 sm-flex-end"> 
                        <Button title="Copy" variant="outlined" color="primary" className="btn btn-ic btn-copy" onClick={copyText}>
                            Copy
                        </Button>
                        </div>
                    </div>
                    </div>
                    </div>                   
                    </div>
                    </div>
                </div>
                {props.isEditOp && (
                <div className="tabs-container mt-1">
                    <div className="tab-header">
                        <h2 className="tab-heading float-left">
                            Text Exists for Media Types</h2>
                    </div>
                    <div className="mui-custom-form m-0 pb-2">
                        <div className="sub-radio m-0">
                            <label className="MuiFormControlLabel-root inline-radio-label float-left" for="response_void">
                                <Checkbox
                                    checked={voidCheck}
                                    type="checkbox"
                                    id="response_void"
                                    onChange={handleVoidCheck}
                                />
                                <span className="MuiFormControlLabel-label">Show Voids</span>
                            </label>
                            <div className="clearfix" />
                        </div>
                    </div>
                   
                    <TableComponent headCells={headCellsPresumptiveEligibility} tableData={getTableData(tableData)} onTableRowClick={editRow} defaultSortColumn="mediaTypeDesc" />
                   
                </div>
                )}
                <div className="tabs-container mt-2">
                    <div className="tab-header">
                        <h2 className="tab-heading float-left">
                        Response Text</h2>
                    </div>
                    <div className="custom-form-feild mt-2">
                    <TextareaAutosize
                        id="response-response-text"                          
                        rowsMin= {10}          
                        rowsMax= {20}                         
                        value={formData.responseText ? formData.responseText : ""}            
                        onChange={handleChanges('responseText')}
                        placeholder=""                         
                        className="wid-100"     
                      />
                    </div>
                </div>
            </div>
        </div>
    );
}
export default Response;
