export const DOC_TYPE_REQ_ERROR = "Document Type is required.";
export const MEDIA_TYPE_REQ_ERROR = "Media Type is required.";
export const CLAIM_TYPE_REQ_ERROR = "Claim Type is required.";
export const DISPOSITION_REQ_ERROR = "Disposition is required.";
export const FORCE_PAY_REQ_ERROR = "Force Pay is required.";
export const FORCE_DENY_REQ_ERROR = "Force Deny is required.";
export const CLAIM_TYPE_DUP_REQ_ERROR = "Claim Type entered is already in the system for selected Disposition Key.  Duplicate Claim Type entry is not allowed.";
