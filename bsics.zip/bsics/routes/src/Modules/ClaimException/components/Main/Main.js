import React, { useState, useEffect } from 'react';
import { withRouter } from 'react-router';
import TableComponent from '../../../../SharedModules/Table/Table';
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import { Button } from 'react-bootstrap';
import { ExpansionPanel, ExpansionPanelSummary, Typography, ExpansionPanelDetails, TextField } from "@material-ui/core";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import { makeStyles } from "@material-ui/core/styles";
import Checkbox from '@material-ui/core/Checkbox';
import PropTypes from "prop-types"
import { Link } from 'react-router-dom';
import SuspendedClaimRouting from './SuspendedClaimRouting';
import RATextDefaultOverride from './RATextDefaultOverride';
import AdjudicationDetailsOverride from './AdjudicationDetailsOverride';





const useStyles = makeStyles(theme => ({
    root: {
        width: '100%',
    },
    heading: {
        fontSize: theme.typography.pxToRem(15),
        fontWeight: theme.typography.fontWeightRegular,
    },
}));
function Main(props) {
     const onPanelChange = ()=>{
         props.majorValidations();
     }

    return (
        <>
            <div className="pb-1">
                <div className="tcn-title pb-1"> Line of Business : {props.majorValues.lobDesc}</div>
            </div>
            <div className="tab-header">
                <h2 className="tab-heading float-left"> Medical </h2>
            </div>
            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel" onChange={onPanelChange}>
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header">
                        <Typography > Adjudication Defaults Override </Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails className="clear-block">

                        <AdjudicationDetailsOverride values={props.claimExceptionDefaultVO} handleChanges={props.handleDefaultExceptionChanges}
                        adjRsnDropdown={props.adjRsnDropdown}
                        remarkDropDown={props.remarkDropDown}
                        eobDropDown={props.eobDropDown}
                        locationDropdown={props.locationDropdown}
                        userDropDown={props.userDropDown}
                        newDataUpdate={props.newDataUpdate}
                        errors={props.errors} />
                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>
            <div className='tab-holder CustomExpansion-panel my-3'>

                <ExpansionPanel className="collapsable-panel" onChange={onPanelChange}>
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header">
                        <Typography > Suspended Claim Routing Default Override</Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails className="clear-block">
                        <SuspendedClaimRouting
                            dropdowns={props.dropdowns}
                            isEditOp={props.isEditOp}
                            seterrorMessages={props.seterrorMessages}
                            majorValidations={props.majorValidations}
                            setTableData={props.setClaimExceptionLocationVO}
                            claimExceptionLocationVO={props.claimExceptionLocationVO}
                            locationDropdown={props.locationDropdown}
                            userDropDown={props.userDropDown}
                            setDeleteList = {props.setLocationDeleteList?props.setLocationDeleteList:''}
                            deleteList={props.isEditOp  ?props.locationDeleteList:null}
                            auditProps={props.isEditOp?props.auditProps:null}
                        />

                    </ExpansionPanelDetails>
                </ExpansionPanel>
            </div>
            <div className='tab-holder CustomExpansion-panel my-3'>
                <ExpansionPanel className="collapsable-panel" onChange={onPanelChange}>
                    <ExpansionPanelSummary
                        expandIcon={<ExpandMoreIcon />}
                        aria-controls="panel1a-content"
                        id="panel1a-header">
                        <Typography > RA Text Default Override </Typography>
                    </ExpansionPanelSummary>
                    <ExpansionPanelDetails className="clear-block">
                        <RATextDefaultOverride
                            dropdowns={props.dropdowns}
                            isEditOp={props.isEditOp}
                            seterrorMessages={props.seterrorMessages}
                            majorValidations={props.majorValidations}
                            setTableData={props.setClaimExceptionRemarkVO}
                            claimExceptionRemarkVO={props.claimExceptionRemarkVO}
                            adjRsnDropdown={props.adjRsnDropdown}
                            remarkDropDown={props.remarkDropDown}
                            eobDropDown={props.eobDropDown}
                            setDeleteList={props.isEditOp?props.setRemarkDeleteList:''}
                            deleteList={props.isEditOp?props.remarkDeleteList:null}
                            auditProps={props.isEditOp?props.auditProps:null}
                        />

                    </ExpansionPanelDetails>
                </ExpansionPanel>


            </div>
        </>
    );
}
export default withRouter(Main);
