import React, { useState, useEffect, useRef } from 'react';
import { withRouter } from 'react-router';
import { Button } from 'react-bootstrap';
import { makeStyles } from "@material-ui/core/styles";
import Checkbox from '@material-ui/core/Checkbox';
import Moment from "react-moment";
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import TableComponent from '../../../../SharedModules/Table/Table';
import { getLoginUserDetails } from '../../../../SharedModules/utility/utilityFunction';
import * as ErrorMsgConstants from '../../../../SharedModules/Messages/ErrorMsgConstants';
import { useConfirm } from '../../../../SharedModules/MUIConfirm/index';
import TooltipComponent from '../../../../SharedModules/Tooltip/Tooltip';
import dateFnsFormat from 'date-fns/format';
import * as AuditConstant from '../../../../SharedModules/AuditLog/AuditLogConstants';
import AuditLogRow from "../../../../SharedModules/AuditLog/AuditLogRow";



const useStyles = makeStyles((theme) => ({

    pd0bd0: {
        padding: "0 !important",
        border: "0 !important"
    }
}));



function SuspendedClaimRouting(props, ref) {
    const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
    const addClaimRouting = useRef(null);
    const [deleteList, setDeleteList] = useState([]);
    const classes = useStyles();
    const voidRef = useRef();
    const muiconfirm = useConfirm();
    const [showForm, setShowForm] = useState(false);
    const defaultFormData = {

        "documentType": "-1",
        "claimType": "-1",
        "mediaType": "-1",
        "userID": "-1",
        "locationCode": "-1"
    };
    let errors = {
        docReqErr: false,
        claimReqErr: false,
        mediaReqErr: false,
        locReqErr: false,
        duplicateErr: false
    };
    const [formData, setFormData] = useState(defaultFormData);
    const [resetformData, setResetFormData] = useState(defaultFormData);
    const [success, setSuccess] = useState(false);
    const [multiDelete, setMultiDelete] = useState([]);
    const [tableData, setTableData] = useState([]);
    const [{ claimReqErr, docReqErr, mediaReqErr, locReqErr, duplicateErr }, setFormErrors] = useState(false);
    const userDetails = getLoginUserDetails();
    const headCells = [
        {
            id: 'documentTypeDesc', numeric: false, dateHyperLink: true, disablePadding: true, label: 'Document Type', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'mediaTypeDesc', numeric: false, disablePadding: false, label: 'Media Type', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'claimTypeDesc', numeric: false, disablePadding: false, label: 'Claim Type', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'userID', numeric: false, disablePadding: false, label: 'User ID', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'locationCode', numeric: false, disablePadding: false, label: 'Location', enableHyperLink: false, fontSize: 12
        },

        props.isEditOp ? {
            id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date', enableHyperLink: false, fontSize: 12
        } : {
                id: '', numeric: false, disablePadding: false, label: '', enableHyperLink: false, fontSize: 12
            }
    ];

    useEffect(() => {
        let data = props.claimExceptionLocationVO ? props.claimExceptionLocationVO : [];
        if (props.isEditOp) {
            setTableData(voidRef.current && voidRef.current.checked ? data : data.filter((a) => { return a.voidDate ? false : true }))
        } else {
            setTableData(data);
        }
    }, [props.claimExceptionLocationVO]);

    const docTypeDrpDwn = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'] && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));
    const mediaTypeDrpDwn = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'] && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));
    const claimTypeDrpDwn = props.dropdowns && props.dropdowns['ClaimException#C_TY_CD'] && props.dropdowns['ClaimException#C_TY_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));

    const locDrpDwn = props.locationDropdown && props.locationDropdown.searchResultsValues ? props.locationDropdown.searchResultsValues : [];
    const locationDropDown = locDrpDwn ? locDrpDwn.map(each => (
        <MenuItem selected key={each.locationCode} value={each.locationCode}>{each.locationCode}</MenuItem>
    )) : [];
    const userDropDown = props.userDropDown && props.userDropDown.searchResultsValues ? props.userDropDown.searchResultsValues.map(each => (
        <MenuItem selected key={each.userid} value={each.userid}>{each.lastName + ", " + each.firstName + "-" + each.userid}</MenuItem>
    )) : [];

    const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        dt = new Date(dt);
        if (dt.toString() == "Invalid Date") {
            return "";
        } else {
            return dateFnsFormat(dt, "MM/dd/yyyy");
        }
    };

    const getDetail = (detailName, value) => {
        let desc = "";

        if (detailName.includes("loc")) {
            desc = locDrpDwn.filter(each =>
                each.locationCode === value)
        }
        if (desc && desc[0]) {
            return desc[0].locationText.split("-").length > 1 ? desc[0].locationText.split("-")[1] : "";
        }


    }




    const minorValidations = () => {
        setFormErrors(false);
        setSuccess(false);
        props.seterrorMessages([]);
        let errorMessages = [];
        if (formData.documentType === "-1") {
            errors.docReqErr = true;
            errorMessages.push([ErrorMsgConstants.DOC_TYPE_REQ_ERR])
        }
        if (formData.mediaType === "-1") {
            errors.mediaReqErr = true;
            errorMessages.push([ErrorMsgConstants.MEDIA_TYPE_REQ_ERR])
        }
        if (formData.claimType === "-1") {
            errors.claimReqErr = true;
            errorMessages.push([ErrorMsgConstants.CLAIM_TYPE_REQ_ERR])
        }
        if (formData.locationCode === "-1") {
            errors.locReqErr = true;
            errorMessages.push([ErrorMsgConstants.LOCATION_REQ_ERR])
        }
        if (errorMessages.length > 0) {
            props.seterrorMessages(errorMessages);
            setFormErrors(errors);
            return false;
        }
        const duplicate = tableData.length > 0 && !(tableData.length==1 && formData.index>-1) && tableData.filter((i, index) => {
            if (formData.index=== undefined || (formData.index !== index)) {
                return (i.documentType === formData.documentType &&
                    i.mediaType === formData.mediaType &&
                    i.claimType === formData.claimType)
            }
        });

        if (duplicate && duplicate.length > 0) {
            errors.duplicateErr = true
            errorMessages.push(ErrorMsgConstants.DUP_CLAIM_ROUTING_ERR)
        }
        if (errorMessages.length > 0) {
            props.seterrorMessages(errorMessages);
            setFormErrors(errors);
            return false;
        }

        return true;
    }
    const saveFormData = () => {
        setFormErrors(false);
        setSuccess(false);
        props.seterrorMessages([]);
        if (minorValidations()) {
            let tmpTableData = tableData;
            let data = {
                "auditUserID": userDetails.loginUserName,
                "auditTimeStamp": new Date(),
                "addedAuditUserID": userDetails.loginUserName,
                "addedAuditTimeStamp": new Date(),
                "versionNo": 0,
                "dbRecord": false,
                "sortColumn": null,
                "auditKeyList": [],
                "auditKeyListFiltered": false,
                "documentType": formData.documentType !== "-1" ? formData.documentType.split('-')[0] : "",
                "mediaType": formData.mediaType !== "-1" ? formData.mediaType.split('-')[0] : "",
                "claimType": formData.claimType ? formData.claimType.split('-')[0] : "",
                "userID": formData.userID !== "-1" ? formData.userID : "",
                "locationCode": formData.locationCode,
                "voidDate": formData.void === 'Yes' ? (formData && formData.voidDate ? formData.voidDate : formatDate(new Date())) : null,
                "claimTypeDesc": formData.claimTypeDesc,
                "documentTypeDesc": formData.documentTypeDesc,
                "mediaTypeDesc": formData.mediaTypeDesc,
                "showVoids": false,
                "showVoidRecord": false,
                "tempVoidDate": null
            }
            if (formData.index > -1) {
                data.exceptionLocationSK = formData.exceptionLocationSK ? formData.exceptionLocationSK : null;
            }
            formData.index > -1 ? tmpTableData[formData.index] = data : tmpTableData.push(data);
            setTableData(tmpTableData);
            setSuccess(true);
            props.setTableData(tmpTableData);
            setShowForm(false);
        }
    }

    const editRow = row => (event) => {

        setShowForm(true);
        setSuccess(false);
        setFormData({ ...row, void: row.voidDate ? 'Yes' : 'No' });
        setResetFormData({ ...row, void: row.voidDate ? 'Yes' : 'No' });
        props.seterrorMessages([]);
        setFormErrors(false);
        if (props.isEditOp && props.auditProps && props.auditProps.showAuditLog) {
            props.auditProps.getAuditLogTab(row.exceptionLocationSK ? row.exceptionLocationSK : null, AuditConstant.AUDIT_LOG_CLM_EXC_LOC)
        }


    }

    const getTableData = (data) => {
        if (data && data.length) {
            let tData = JSON.stringify(data);
            tData = JSON.parse(tData);
            tData.map((each, index) => {
                let docTypeDesc = props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'] && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'].filter(value => value.code === each.documentType);

                let mediaTypeDesc = props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'] && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'].filter(value => value.code === each.mediaType);

                let claimTypeDesc = props.dropdowns['ClaimException#C_TY_CD'] && props.dropdowns['ClaimException#C_TY_CD'].filter(value => value.code === each.claimType);
                each.documentTypeDesc = docTypeDesc && docTypeDesc.length > 0 ? docTypeDesc[0].description : '';
                each.claimTypeDesc = claimTypeDesc && claimTypeDesc.length > 0 ? claimTypeDesc[0].description : '';
                each.mediaTypeDesc = mediaTypeDesc && mediaTypeDesc.length > 0 ? mediaTypeDesc[0].description : '';
                each.voidDate = each.voidDate;
                each.locDetail = each.locationCode ? getDetail('locDetail', each.locationCode) : "";
                each.index = index;
            });
            if (voidRef.current && voidRef.current.checked) {
                return tData;
            } else {
                return tData.filter((a) => { return a.voidDate ? false : true });
            }
        } else {
            return [];
        }
    }

    const handleMultiDelete = () => {
        muiconfirm({ title: "", description: 'Are you sure that you want to delete.', dialogProps: { fullWidth: false } })
            .then(() => {
                let t = tableData;
                let newArray = [];

                multiDelete.map(value => {
                    let curIndex = t.findIndex(i => (i.documentType) === (value.documentType) && (i.claimType) === (value.claimType) && (i.mediaType) === (value.mediaType));

                    newArray.push(t[curIndex]);

                    t.splice(curIndex, 1);
                });

                setTableData(t);
                props.setTableData(t);
                setShowForm(false);
                if (props.isEditOp) {
                    props.setDeleteList([...props.deleteList, ...newArray])
                }
                setSuccess(false);
                props.seterrorMessages([]);
                setMultiDelete([]);
            });
    }

    const handelVoidCheck = () => {
        const data = props.claimExceptionLocationVO
        setTableData(voidRef.current.checked ? data : data.filter((a) => { return a.voidDate ? false : true }))
    }

    const minorDelete = () => {
        muiconfirm({ title: "", description: 'Are you sure that you want to delete.', dialogProps: { fullWidth: false } })
            .then(() => {
                let t = tableData;
                let valueRemoved = t[formData.index];
                if (props.isEditOp) {
                    props.setDeleteList([...props.deleteList, valueRemoved])
                }
                t.splice(formData.index, 1);
                setTableData(t);
                props.setTableData(t);
                setSuccess(false);
                setShowForm(false);
                props.seterrorMessages([]);
            });
    }

    return (
        <>


            <div className="tab-container">
                {success ? (
                    <div className="alert alert-success custom-alert" role="alert">
                        {ErrorMsgConstants.SUCCESSFULLY_SAVED_INFORMATION}
                    </div>
                ) : null}
                <div className="tab-header">
                    <h2 className="tab-heading float-left">
                        Claim Routing
                </h2>
                    <div className="float-right th-btnGroup">
                        <Button title="Delete" variant="outlined" color="primary" disabled={multiDelete.length == 0} className="btn btn-transparent btn-icon-only" onClick={() => handleMultiDelete()}
                         data-test="test_del_btn"
                        >
                            <i className="fa fa-trash" />
                        </Button>
                        <Button title="Add Claim Routing" color="primary" className="btn btn-secondary btn-icon-only"
                            onClick={() => {

                                setTimeout(function () {
                                    scrollToRef(addClaimRouting);
                                }.bind(this), 1000);
                                setShowForm(true);
                                setSuccess(false);
                                setFormData(defaultFormData);


                            }}
                            data-test="test_add_btn"
                        >
                            <i className="fa fa-plus" />
                        </Button>
                    </div>
                </div>
                {props.isEditOp ? (<div className="mui-custom-form m-0">
                    <div className="sub-radio m-0">
                        <label className="MuiFormControlLabel-root inline-radio-label float-left">
                            <Checkbox
                                type="checkbox"
                                value="void"
                                id="fcVoidId"
                                inputRef={voidRef}
                                onChange={handelVoidCheck}
                            />
                            <span className="MuiFormControlLabel-label">Show Voids</span>
                        </label>
                        <div className="clearfix" />
                    </div>
                </div>) : null}
                <div className="tab-holder mt-1">
                    <TableComponent headCells={headCells}
                        selected={multiDelete}
                        multiDelete
                        setSelected={setMultiDelete}
                        tableData={getTableData(tableData)}
                        onTableRowClick={editRow}
                        defaultSortColumn="beginDate"
                    />
                    {showForm
                        ?
                        <>
                            <div className="tab-header mt-3" ref={addClaimRouting}>
                                <h2 className="tab-heading float-left">{formData.index > -1 ? "Edit" : "Add"} Claim Routing</h2>
                                <div className="float-right th-btnGroup">
                                    <Button
                                        title={formData.index > -1 ? 'Update Claim Routing' : 'Add Claim Routing'}
                                        color="primary"
                                        className={formData.index > -1 ? 'btn btn-ic btn-save' : 'btn btn-ic btn-add'} onClick={saveFormData}
                                        data-test="test_addUpd_btn"
                                        >
                                        {formData.index > -1 ? 'Update' : 'Add'}</Button>
                                    {formData.index > -1 ?
                                        <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete"
                                            onClick={minorDelete}
                                        >
                                            Delete
                                        </Button> : null}
                                    {formData.index > -1 ?
                                        <Button title="Reset" color="primary" className="btn btn-ic btn-reset"
                                            onClick={() => {
                                                setFormData(resetformData);
                                                setFormErrors(false);
                                                props.seterrorMessages([]);
                                                setSuccess(false);

                                            }}
                                        >
                                            Reset</Button> :
                                        <Button title="Reset" color="primary" className="btn btn-ic btn-reset"
                                            onClick={() => {
                                                setFormData({ ...defaultFormData, "index": formData.index });
                                                setFormErrors(false);
                                                props.seterrorMessages([]);
                                                setSuccess(false);

                                            }}
                                            data-test="test_reset"
                                        >
                                            Reset</Button>
                                    }
                                    <Button title="Cancel" color="primary" className="btn btn-cancel"
                                        onClick={() => {
                                            setShowForm(false);
                                            props.seterrorMessages([]);
                                            setSuccess(false);
                                            setFormErrors(false);
                                        }}
                                        data-test="test_cancel"
                                    >Cancel</Button>
                                </div>
                            </div>
                            <div className="tab-body-bordered mt-2">
                                <form autoComplete="off">
                                    <div className="form-wrapper">
                                        {props.isEditOp && formData.index > -1 ?
                                            <div className="mui-custom-form input-md">
                                                <label class="MuiFormLabel-root MuiInputLabel-shrink">Void</label>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        row
                                                        aria-label="eftactive"
                                                        name="HideInactiveProviders"
                                                        value={formData.void}
                                                        onChange={(event) => {
                                                            setFormData({ ...formData, "void": event.target.value });
                                                        }}
                                                    >
                                                        <FormControlLabel
                                                            value="Yes"
                                                            id="yes-claim-routing"
                                                            control={<Radio id="fcVoidYes" color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value="No"
                                                            id="no-claim-routing"
                                                            control={<Radio id="fcVoidNo" color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div> : null}
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="standard-select-document-type"
                                                select
                                                label="Document Type"
                                                value={formData.documentType ? formData.documentType : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => { setFormData({ ...formData, "documentType": event.target.value }); }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                                helperText={
                                                    docReqErr ? ErrorMsgConstants.DOC_TYPE_REQ_ERR
                                                        : duplicateErr ? ErrorMsgConstants.DUP_CLAIM_ROUTING_ERR
                                                            : null
                                                }
                                                error={
                                                    docReqErr ? ErrorMsgConstants.DOC_TYPE_REQ_ERR
                                                        : duplicateErr ? ErrorMsgConstants.DUP_CLAIM_ROUTING_ERR
                                                            : null
                                                }
                                                data-test="test_doc"
                                            >
                                                <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                                                {docTypeDrpDwn}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="standard-select-media-type"
                                                select
                                                label="Media Type"
                                                value={formData.mediaType ? formData.mediaType : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => { setFormData({ ...formData, "mediaType": event.target.value }); }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                                helperText={
                                                    mediaReqErr ? ErrorMsgConstants.MEDIA_TYPE_REQ_ERR : null
                                                }
                                                error={
                                                    mediaReqErr ? ErrorMsgConstants.MEDIA_TYPE_REQ_ERR : null
                                                }
                                                data-test="test_mediaType"
                                            >
                                                <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                                                {mediaTypeDrpDwn}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="standard-select-claim-type"
                                                select
                                                label="Claim Type"
                                                value={formData.claimType ? formData.claimType : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => { setFormData({ ...formData, "claimType": event.target.value }); }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                                helperText={
                                                    claimReqErr ? ErrorMsgConstants.CLAIM_TYPE_REQ_ERR : null
                                                }
                                                error={
                                                    claimReqErr ? ErrorMsgConstants.CLAIM_TYPE_REQ_ERR : null
                                                }
                                                data-test="test_claimType"
                                            >
                                                <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                                                {claimTypeDrpDwn}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="standard-select-userid"
                                                select
                                                label="User ID"
                                                value={formData.userID ? formData.userID : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => { setFormData({ ...formData, "userID": event.target.value }); }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                data-test="test_userId"
                                            >
                                                <MenuItem selected key=" Please Select One" value="-1">Please Select One</MenuItem>
                                                {userDropDown}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md pos-rel">
                                            <TooltipComponent title="Location Details" desc={formData.locDetail} />

                                            <TextField
                                                id="standard-select-location"
                                                select
                                                label="Location"
                                                value={formData.locationCode ? formData.locationCode : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => {
                                                    setFormData({
                                                        ...formData, "locationCode": event.target.value,
                                                        "locDetail": getDetail("locDetail", event.target.value)
                                                    });
                                                }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                                helperText={
                                                    locReqErr ? ErrorMsgConstants.LOCATION_REQ_ERR : null
                                                }
                                                error={
                                                    locReqErr ? ErrorMsgConstants.LOCATION_REQ_ERR : null
                                                }
                                                data-test="test_loc"
                                            >
                                                <MenuItem selected key=" Please Select One" value="-1">Please Select One</MenuItem>
                                                {locationDropDown}
                                            </TextField>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            {props.auditProps && props.auditProps.showAuditLog && formData.index > -1 ?
                                <AuditLogRow auditLogData={props.auditProps.subAuditLogData &&
                                    props.auditProps.subAuditLogData[AuditConstant.AUDIT_LOG_CLM_EXC_LOC]
                                    ? props.auditProps.subAuditLogData[AuditConstant.AUDIT_LOG_CLM_EXC_LOC]
                                    : []} />
                                : ""
                            }
                        </>
                        : ''}

                </div>
            </div>


        </>

    );
}
export default withRouter(SuspendedClaimRouting);
