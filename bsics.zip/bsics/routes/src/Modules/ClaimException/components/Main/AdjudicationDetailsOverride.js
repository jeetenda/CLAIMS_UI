import React, {useState, useEffect} from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import Radio from '@material-ui/core/Radio';
import { Button } from 'react-bootstrap';
import DateFnsUtils from '@date-io/date-fns';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import {
    KeyboardDatePicker,
    MuiPickersUtilsProvider
} from '@material-ui/pickers';
import dateFnsFormat from 'date-fns/format';
import  TooltipComponent from '../../../../SharedModules/Tooltip/Tooltip';
import * as ComponentMsg from '../../../../SharedModules/Messages/ErrorMsgConstants';

export default function AdjudicationDetailsOverride(props) {
    const [details, setDetails] = useState({
        "adjustmentReasonCode1": "",
        "adjustmentReasonCode2": "",
        "adjustmentReasonCode3": "",
        "remarkCode1": "",
        "remarkCode2": "",
        "remarkCode3": "",
        "eobCode": "",
        "locationCode":"",
    });

    const getDetails = (dropDowns, value, type) => {
        if (dropDowns && dropDowns.length > 0) {
            let desc = "";
            dropDowns.map(each => {
                if (type == 'adjustment') {
                    if (each.reasonCode == value) {
                        desc = each.description;
                    }
                }
                if (type == 'remark') {
                    if (each.remarkCode == value) {
                        desc = each.description;
                    }
                }
                if (type == 'eob') {
                    if (each.clmEobCode == value) {
                        desc = each.eobDes;
                    }
                }
                if (type == 'location') {
                    if (each.locationCode == value) {
                        desc = each.locationText;
                    }
                }
            })
            return desc;
        } else {
            return "";
        }
    };

    useEffect(() => {
        if (props.adjRsnDropdown && props.adjRsnDropdown.searchResultsValues && props.newDataUpdate) {
            console.log(props.values);
            setDetails({
                 adjustmentReasonCode1: getDetails(props.adjRsnDropdown.searchResultsValues, props.values.adjustmentReasonCode1, 'adjustment'),
                 adjustmentReasonCode2: getDetails(props.adjRsnDropdown.searchResultsValues, props.values.adjustmentReasonCode2, 'adjustment'),
                 adjustmentReasonCode3: getDetails(props.adjRsnDropdown.searchResultsValues, props.values.adjustmentReasonCode3, 'adjustment'),
                 eobCode: getDetails(props.eobDropDown.searchResultsValues, props.values.eobCode, 'eob'),
                 remarkCode1: getDetails(props.remarkDropDown.searchResultsValues, props.values.remarkCode1, 'remark'),
                 remarkCode2: getDetails(props.remarkDropDown.searchResultsValues, props.values.remarkCode2, 'remark'),
                 remarkCode3: getDetails(props.remarkDropDown.searchResultsValues, props.values.remarkCode3, 'remark'),
                 locationCode: getDetails(props.locationDropdown.searchResultsValues, props.values.locationCode, 'location')
                });
        }
    }, [props.adjRsnDropdown && props.eobDropDown && props.remarkDropDown && props.locationDropdown && props.newDataUpdate]);

    return (
        <form autoComplete="off">
            <div className="tab-body mt-2">
                <div className="form-wrapper">
                    <div className="mui-custom-form with-select input-md pos-rel">
                        <TooltipComponent title="Adjustment Reason" desc={details.adjustmentReasonCode1} />
                        <TextField
                            id="Adjustment-Reason1-Adjudication-Details-Override"
                            label="Adjustment Reason"
                            className="inline-lable-ttl"
                            select
                            value={props.values.adjustmentReasonCode1 ? props.values.adjustmentReasonCode1 : "-1"}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('adjustmentReasonCode1')(event); 
                                setDetails({...details, adjustmentReasonCode1: getDetails(props.adjRsnDropdown.searchResultsValues, event.target.value, 'adjustment')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_adj_rsn'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.adjRsnDropdown && props.adjRsnDropdown.searchResultsValues && props.adjRsnDropdown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.reasonCode} value={each.reasonCode} >{each.reasonCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md pos-rel">
                        <TooltipComponent title="Information" desc={details.adjustmentReasonCode2} />
                        <TextField
                            id="Adjustment-Reason2-Adjudication-Details-Override"
                            className="inline-lable-ttl"
                            select
                            value={props.values.adjustmentReasonCode2 ? props.values.adjustmentReasonCode2 : "-1"}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('adjustmentReasonCode2')(event);
                                setDetails({...details, adjustmentReasonCode2: getDetails(props.adjRsnDropdown.searchResultsValues, event.target.value, 'adjustment')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_adj_rsn2'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.adjRsnDropdown && props.adjRsnDropdown.searchResultsValues && props.adjRsnDropdown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.reasonCode} value={each.reasonCode} >{each.reasonCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md pos-rel">
                        <TooltipComponent title="Information" desc={details.adjustmentReasonCode3} />
                        <TextField
                            id="Adjustment-Reason3-Adjudication-Details-Override"
                            className="inline-lable-ttl"
                            select
                            value={props.values.adjustmentReasonCode3 ? props.values.adjustmentReasonCode3 : '-1'}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('adjustmentReasonCode3')(event);
                                setDetails({...details, adjustmentReasonCode3: getDetails(props.adjRsnDropdown.searchResultsValues, event.target.value, 'adjustment')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_adj_rsn3'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.adjRsnDropdown && props.adjRsnDropdown.searchResultsValues && props.adjRsnDropdown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.reasonCode} value={each.reasonCode} >{each.reasonCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                </div>
                <div className="form-wrapper">
                    <div className="mui-custom-form with-select input-md pos-rel">
                        <TooltipComponent title="Remark Code" desc={details.remarkCode1} />
                        <TextField
                            id="Remark-Code1-Adjudication-Details-Override"
                            label="Remark Code"
                            className="inline-lable-ttl"
                            select
                            value={props.values.remarkCode1 ? props.values.remarkCode1 : "-1"}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('remarkCode1')(event);
                                setDetails({...details, remarkCode1: getDetails(props.remarkDropDown.searchResultsValues, event.target.value, 'remark')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_adj_rmk'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.remarkDropDown && props.remarkDropDown.searchResultsValues && props.remarkDropDown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.remarkCode} value={each.remarkCode}>{each.remarkCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md pos-rel">
                    <TooltipComponent title="Information" desc={details.remarkCode2} />
                        <TextField
                            id="Remark-Code2-Adjudication-Details-Override"
                            className="inline-lable-ttl"
                            select
                            value={props.values.remarkCode2 ? props.values.remarkCode2 : '-1'}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('remarkCode2')(event);
                                setDetails({...details, remarkCode2: getDetails(props.remarkDropDown.searchResultsValues, event.target.value, 'remark')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_adj_rmk2'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.remarkDropDown && props.remarkDropDown.searchResultsValues && props.remarkDropDown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.remarkCode} value={each.remarkCode}>{each.remarkCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md pos-rel">
                    <TooltipComponent title="Information" desc={details.remarkCode3} />
                        <TextField
                            id="Remark-Code3-Adjudication-Details-Override"
                            className="inline-lable-ttl"
                            select
                            value={props.values.remarkCode3 ? props.values.remarkCode3 : "-1"}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('remarkCode3')(event);
                                setDetails({...details, remarkCode3: getDetails(props.remarkDropDown.searchResultsValues, event.target.value, 'remark')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_adj_rmk3'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.remarkDropDown && props.remarkDropDown.searchResultsValues && props.remarkDropDown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.remarkCode} value={each.remarkCode}>{each.remarkCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                </div>
                <div className="form-wrapper">
                    <div className="mui-custom-form with-select input-md pos-rel">
                        <TooltipComponent title="EOB" desc={details.eobCode} />
                        <TextField
                            id="EOB-Adjudication-Details-Override"
                            label="EOB"
                            className="inline-lable-ttl"
                            select
                            value={props.values.eobCode ? props.values.eobCode : "-1"}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('eobCode')(event);
                                setDetails({...details, eobCode: getDetails(props.eobDropDown.searchResultsValues, event.target.value, 'eob')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_adj_eob'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.eobDropDown && props.eobDropDown.searchResultsValues && props.eobDropDown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.clmEobCode} value={each.clmEobCode}>{each.clmEobCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md pos-rel">
                        <TooltipComponent title="Location" desc={details.locationCode} />
                        <TextField
                            id="Location-Adjudication-Details-Override"
                            label="Location"
                            className="inline-lable-ttl"
                            select
                            value={props.values.locationCode ? props.values.locationCode : "-1"}
                            inputProps={{ maxLength: 15 }}
                            onChange={(event) => {props.handleChanges('locationCode')(event);
                                setDetails({...details, locationCode: getDetails(props.locationDropdown.searchResultsValues, event.target.value, 'location')})}}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_loc'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.locationDropdown && props.locationDropdown.searchResultsValues.length > 0 && props.locationDropdown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.locationCode} value={each.locationCode}>{each.locationCode}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                    <div className="mui-custom-form with-select input-md ">
                        <TextField
                            id="User-ID-Adjudication-Details-Override"
                            label="User ID"
                            className="inline-lable-ttl"
                            select
                            value={props.values.userID ? props.values.userID : "-1"}
                            inputProps={{ maxLength: 15 }}
                            onChange={props.handleChanges('userID')}
                            placeholder=""
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_userid'
                        >
                            <MenuItem value="-1">Please Select One</MenuItem>
                            {props.userDropDown && props.userDropDown.searchResultsValues && props.userDropDown.searchResultsValues.map(each => (
                                <MenuItem selected key={each.userid} value={each.userid}>{each.lastName + ", " + each.firstName + "-" + each.userid}</MenuItem>
                            ))}
                        </TextField>
                    </div>
                    <div className="mui-custom-form input-md ">
                        <TextField
                            id="Tracking-Number-Adjudication-Details-Override"
                            label="Tracking Number"
                            className="inline-lable-ttl"
                            value={props.values.trackingNum}
                            inputProps={{ maxLength: 10 }}
                            onChange={props.handleChanges('trackingNum')}
                            placeholder=""
                            helperText={props.errors.tracNumInvErr ? ComponentMsg.TRACK_NUM_INVALID : null}
                            error={props.errors.tracNumInvErr}
                            InputLabelProps={{
                                shrink: true,
                            }}
                            data-test='test_trackingNum'
                        />
                    </div>
                </div>
                <div className="form-wrapper form-3-column">
                    <div className="mui-custom-form input-md">
                        <label className="MuiFormLabel-root MuiInputLabel-shrink"  data-test='test_unclearclaim'>Unclear Claim</label>
                        <div className="sub-radio set-sub-radio mt-1">
                            <Radio
                                type="radio"
                                value={true}
                                id="Unclear-Claim-yes"
                                checked={props.values.uncleanClaim}
                                onChange={props.handleChanges('uncleanClaim')}
                            />
                            <label className="text-black">Yes</label>
                            <Radio
                                type="radio"
                                value={false}
                                id="Unclear-Claim-no"
                                checked={!props.values.uncleanClaim}
                                onChange={props.handleChanges('uncleanClaim')}
                                className="ml-2"
                            />
                            <label className="text-black">No</label>
                        </div>
                    </div>
                    <div className="mui-custom-form input-md">
                        <label className="MuiFormLabel-root MuiInputLabel-shrink" data-test='test_reportType'>Report Type</label>
                        <div className="sub-radio set-sub-radio mt-1">
                            <Radio
                                type="radio"
                                value="S"
                                id="Report-Type-Summary"
                                checked={props.values.reportType == 'S'}
                            onChange={props.handleChanges('reportType')}
                            />
                            <label className="text-black">Summary</label>
                            <Radio
                                type="radio"
                                value="D"
                                id="Report-Type-Detail"
                                checked={props.values.reportType == 'D' }
                                onChange={props.handleChanges('reportType')}
                                className="ml-2"
                            />
                            <label className="text-black">Detail</label>
                        </div>
                    </div>
                    <div className="mui-custom-form input-md">
                        <label className="MuiFormLabel-root MuiInputLabel-shrink" data-test='test_autoRecycle'>Auto Recycle</label>
                        <div className="sub-radio set-sub-radio mt-1">
                            <Radio
                                type="radio"
                                disabled
                                value="1"
                                id="Auto-Recycle-Yes"
                                checked={props.values.autoRecycle == '1'}
                                onChange={props.handleChanges('autoRecycle')}
                            />
                            <label className="text-black">Yes</label>
                            <Radio
                                type="radio"
                                disabled
                                value="0"
                                id="Auto-Recycle-No"
                                checked={props.values.autoRecycle == '0' }
                                onChange={props.handleChanges('autoRecycle')}
                                className="ml-2"
                            />
                            <label className="text-black">No</label>
                        </div>
                    </div>
                </div>
            </div>
            <div className="clearfix" />
        </form>
    );
}
