import React, { useState, useEffect, useRef } from 'react';
import { withRouter } from 'react-router';
import { Button, InputGroup } from 'react-bootstrap';
import { withStyles, makeStyles } from '@material-ui/core/styles';
import Checkbox from '@material-ui/core/Checkbox';
import Moment from "react-moment";
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import RadioGroup from "@material-ui/core/RadioGroup";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import TableComponent from '../../../../SharedModules/Table/Table';
import { getLoginUserDetails } from '../../../../SharedModules/utility/utilityFunction';
import * as ErrorMsgConstants from '../../../../SharedModules/Messages/ErrorMsgConstants';
import { useConfirm } from '../../../../SharedModules/MUIConfirm/index';
import DisplayErrorMessages from '../../../../SharedModules/Errors/TimeOutErrorMsg';
import TooltipComponent from '../../../../SharedModules/Tooltip/Tooltip';
import dateFnsFormat from 'date-fns/format';
import * as AuditConstant from '../../../../SharedModules/AuditLog/AuditLogConstants';
import AuditLogRow from "../../../../SharedModules/AuditLog/AuditLogRow";



const useStyles = makeStyles((theme) => ({

    pd0bd0: {
        padding: "0 !important",
        border: "0 !important"
    }
}));




function RATextDefaultOverride(props) {
    const scrollToRef = (ref) => ref.current.scrollIntoView({ behavior: 'smooth' });
    const addRAText = useRef();

    const classes = useStyles();
    const voidRef = useRef();
    const adjustReasonRef = useRef();
    const muiconfirm = useConfirm();
    const [showForm, setShowForm] = useState(false);
    const defaultFormData = {

        "documentType": "-1",
        "claimType": "-1",
        "mediaType": "-1",
        "adjustReason": "-1",
        "adjudRemark": "-1",
        "adjudEOB": "-1",
        "suspenseRemark": "-1",
        "suspenseEOB": "-1",
        "adjRsnDetail": "",
        "adjudRemarkDetail": "",
        "adjudEOBDetail": "",
        "suspenseRemarkDetail": "",
        "suspenseEOBDetail": ""
    };
    let errors = {
        docReqErr: false,
        claimReqErr: false,
        mediaReqErr: false,
        duplicateErr:false
    };
    const [formData, setFormData] = useState(defaultFormData);
    const [resetformData, setResetFormData] = useState(defaultFormData);
    const [success, setSuccess] = useState(false);
    const [multiDelete, setMultiDelete] = useState([]);
    const [tableData, setTableData] = useState([]);
    const [{ claimReqErr, docReqErr, mediaReqErr, duplicateErr }, setFormErrors] = useState(false);
    const userDetails = getLoginUserDetails();
    const headCells = [
        {
            id: 'documentTypeDesc', numeric: false, dateHyperLink: true, disablePadding: true, label: 'Document Type', enableHyperLink: true, fontSize: 12
        },
        {
            id: 'mediaTypeDesc', numeric: false, disablePadding: false, label: 'Media Type', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'claimTypeDesc', numeric: false, disablePadding: false, label: 'Claim Type', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'adjustReason', numeric: false, disablePadding: false, label: 'Adjustment Reason', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'adjudRemark', numeric: false, disablePadding: false, label: 'Adjudication Remark', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'adjudEOB', numeric: false, disablePadding: false, label: 'Adjudication EOB', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'suspenseRemark', numeric: false, disablePadding: false, label: 'Suspense Remark', enableHyperLink: false, fontSize: 12
        },
        {
            id: 'suspenseEOB', numeric: false, disablePadding: false, label: 'Suspense EOB', enableHyperLink: false, fontSize: 12
        },

        props.isEditOp ? {
            id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date', enableHyperLink: false, fontSize: 12
        } : {
                id: '', numeric: false, disablePadding: false, label: '', enableHyperLink: false, fontSize: 12
            }
    ];
    useEffect(() => {
        let data = props.claimExceptionRemarkVO ? props.claimExceptionRemarkVO : [];
        if (props.isEditOp) {
            setTableData(voidRef.current && voidRef.current.checked ? data : data.filter((a) => { return a.voidDate ? false : true }))
        } else {
            setTableData(data);
        }
    }, [props.claimExceptionRemarkVO]);
    const docTypeDrpDwn = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'] && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));
    const mediaTypeDrpDwn = props.dropdowns && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'] && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));
    const claimTypeDrpDwn = props.dropdowns && props.dropdowns['ClaimException#C_TY_CD'] && props.dropdowns['ClaimException#C_TY_CD'].map(each => (
        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
    ));

    const [adjustReasonObj, setAdjustReasonObj] = useState({});
    const [eobObj, setEobObj] = useState({});
    const [remarkObj, setRemarkObj] = useState({});



    useEffect(() => {
        if (props.adjRsnDropdown && props.adjRsnDropdown.searchResultsValues) {
            let obj = {};
            props.adjRsnDropdown.searchResultsValues.forEach((value) => {
                obj[value.reasonCode] = value;
            });
            setAdjustReasonObj(obj);
        }
    }, [props.adjRsnDropdown]);
    useEffect(() => {
        if (props.eobDropDown && props.eobDropDown.searchResultsValues) {
            let obj = {};
            props.eobDropDown.searchResultsValues.forEach((value) => {
                obj[value.clmEobCode] = value
            });
            setEobObj(obj);
        }
    }, [props.eobDropDown])
    useEffect(() => {
        if (props.remarkDropDown && props.remarkDropDown.searchResultsValues) {
            let obj = {};
            props.remarkDropDown.searchResultsValues.forEach((value) => {
                obj[value.remarkCode] = value
            });
            setRemarkObj(obj);
        }
    }, [props.remarkDropDown])



    const adjRsnDrpDwn = props.adjRsnDropdown && props.adjRsnDropdown.searchResultsValues && props.adjRsnDropdown.searchResultsValues.map(each => (
        <MenuItem selected key={each.reasonCode} value={each.reasonCode} >{each.reasonCode}</MenuItem>
    ));
    const eobDrpDwn = props.eobDropDown && props.eobDropDown.searchResultsValues && props.eobDropDown.searchResultsValues.map(each => (
        <MenuItem selected key={each.clmEobCode} value={each.clmEobCode}>{each.clmEobCode}</MenuItem>
    ));
    const remarkDrpDwn = props.remarkDropDown && props.remarkDropDown.searchResultsValues && props.remarkDropDown.searchResultsValues.map(each => (
        <MenuItem selected key={each.remarkCode} value={each.remarkCode}>{each.remarkCode}</MenuItem>
    ));
    const adjRsnDropdown = [];
    const remarkDropDown = [];
    const eobDropDown = [];
    const getDetail = (detailName, value) => {
        let desc = "";
        if (detailName.includes("adjRsn")) {
            desc = adjRsnDropdown.filter(each =>
                each.reasonCode === value
            )
            return desc && desc[0] ? desc[0].description : "";
        }
        else if (detailName.includes("Remark")) {
            desc = remarkDropDown.filter(each =>
                each.remarkCode === value
            )
            return desc && desc[0] ? desc[0].description : "";
        }
        else if (detailName.includes("EOB")) {
            desc = eobDropDown.filter(each =>
                each.clmEobCode === value)
        }
        return desc && desc[0] ? desc[0].eobDes : ""


    }


    const minorValidations = () => {
        setFormErrors(false);
        setSuccess(false);
        props.seterrorMessages([]);
        let errorMessages = [];
        if (formData.documentType === "-1") {
            errors.docReqErr = true;
            errorMessages.push([ErrorMsgConstants.DOC_TYPE_REQ_ERR])
        }
        if (formData.mediaType === "-1") {
            errors.mediaReqErr = true;
            errorMessages.push([ErrorMsgConstants.MEDIA_TYPE_REQ_ERR])
        }
        if (formData.claimType === "-1") {
            errors.claimReqErr = true;
            errorMessages.push([ErrorMsgConstants.CLAIM_TYPE_REQ_ERR])
        }
        if (errorMessages.length > 0) {
            props.seterrorMessages(errorMessages);
            setFormErrors(errors);
            return false;
        }
        const duplicate = tableData.length > 0 && !(tableData.length==1 && formData.index>-1) && tableData.filter((i, index) => {
            if (formData.index=== undefined || (formData.index !== index)) {
                return (i.documentType === formData.documentType &&
                    i.mediaType === formData.mediaType &&
                    i.claimType === formData.claimType)
            }
        });

        if (duplicate && duplicate.length > 0) {
            errors.duplicateErr = true
            errorMessages.push(ErrorMsgConstants.DUP_RA_ERR)
        }
        if (errorMessages.length > 0) {
            props.seterrorMessages(errorMessages);
            setFormErrors(errors);
            return false;
        }

        return true;
    }
    const formatDate = (dt) => {
        if (!dt) {
            return "";
        }
        dt = new Date(dt);
        if (dt.toString() == "Invalid Date") {
            return "";
        } else {
            return dateFnsFormat(dt, "MM/dd/yyyy");
        }
    };
    const saveFormData = () => {
        setFormErrors(false);
        setSuccess(false);
        props.seterrorMessages([]);
        if (minorValidations()) {
            let tmpTableData = tableData;
            let data = {
                "auditUserID": userDetails.loginUserName,
                "auditTimeStamp": new Date(),
                "addedAuditUserID": userDetails.loginUserName,
                "addedAuditTimeStamp": new Date(),
                "versionNo": 0,
                "dbRecord": false,
                "sortColumn": null,
                "auditKeyList": [],
                "auditKeyListFiltered": false,
                "documentType": formData.documentType,
                "claimType": formData.claimType,
                "mediaType": formData.mediaType,
                "adjustReason": formData.adjustReason !== "-1" ? formData.adjustReason : null,
                "adjudRemark": formData.adjudRemark !== "-1" ? formData.adjudRemark : null,
                "suspenseRemark": formData.suspenseRemark !== "-1" ? formData.suspenseRemark : null,
                "adjudEOB": formData.adjudEOB !== "-1" ? formData.adjudEOB : null,
                "suspenseEOB": formData.suspenseEOB !== "-1" ? formData.suspenseEOB : null,
                "voidDate": formData.void === 'Yes' ? (formData && formData.voidDate ? formData.voidDate : formatDate(new Date())) : null,
                "showVoids": false,
                "showVoidRecord": false,
                "claimTypeDesc": formData.claimTypeDesc,
                "documentTypeDesc": formData.documentTypeDesc,
                "mediaTypeDesc": formData.mediaTypeDesc,
                "tempVoidDate": null
            }
            if (formData.index > -1) {
                data["exceptionRemarkSK"] = formData["exceptionRemarkSK"] ? formData["exceptionRemarkSK"] : null
            }
            formData.index > -1 ? tmpTableData[formData.index] = data : tmpTableData.push(data);
            setTableData(tmpTableData);
            setSuccess(true);
            props.setTableData(tmpTableData);
            setFormData(defaultFormData);
            setShowForm(false);
        }
    }

    const editRow = row => (event) => {
            setShowForm(true);
            setSuccess(false);
            setFormData({
                 ...row,
                  void: row.voidDate ? 'Yes' : 'No' ,
                
                });
            setResetFormData({ ...row, void: row.voidDate ? 'Yes' : 'No' });
            props.seterrorMessages([]);
            setFormErrors(false);
            if(props.isEditOp && props.auditProps && props.auditProps.showAuditLog){
                props.auditProps.getAuditLogTab(row.exceptionRemarkSK?row.exceptionRemarkSK:null, AuditConstant.AUDIT_LOG_CLM_EXC_RMK)
            }
    }

    const getTableData = (data) => {
        if (data && data.length) {
            let tData = JSON.stringify(data);
            tData = JSON.parse(tData);
            tData.map((each, index) => {


                let docTypeDesc = props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'] && props.dropdowns['ClaimException#C_BATCH_DOC_TY_CD'].filter(value => value.code === each.documentType);

                let mediaTypeDesc = props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'] && props.dropdowns['ClaimException#C_BATCH_MEDIA_SRC_CD'].filter(value => value.code === each.mediaType);

                let claimTypeDesc = props.dropdowns['ClaimException#C_TY_CD'] && props.dropdowns['ClaimException#C_TY_CD'].filter(value => value.code === each.claimType);
                each.documentTypeDesc = docTypeDesc && docTypeDesc.length > 0 ? docTypeDesc[0].description : '';
                each.claimTypeDesc = claimTypeDesc && claimTypeDesc.length > 0 ? claimTypeDesc[0].description : '';
                each.mediaTypeDesc = mediaTypeDesc && mediaTypeDesc.length > 0 ? mediaTypeDesc[0].description : '';
                each.adjRsnDetail = each.adjustReason && Object.keys(adjustReasonObj).length !== 0 && adjustReasonObj[each.adjustReason] ? adjustReasonObj[each.adjustReason].description : '';
                each.adjudRemarkDetail = each.adjudRemark && Object.keys(remarkObj).length !== 0 && remarkObj[each.adjudRemark] ? remarkObj[each.adjudRemark].description : "";
                each.adjudEOBDetail = each.adjudEOB && Object.keys(eobObj).length !== 0 && eobObj[each.adjudEOB] ? eobObj[each.adjudEOB].eobDes : "";
                each.suspenseRemarkDetail = each.suspenseRemark && Object.keys(remarkObj).length !== 0 && remarkObj[each.suspenseRemark] ? remarkObj[each.suspenseRemark].descripton : "";
                each.suspenseEOBDetail = each.suspenseEOB && Object.keys(eobObj).length !== 0 && eobObj[each.suspenseEOB] ? eobObj[each.suspenseEOB].eobDes : "";
                each.voidDate = each.voidDate;
                each.index = index;
                
            });
            if (voidRef.current && voidRef.current.checked) {
                return tData;
            } else {
                return tData.filter((a) => { return a.voidDate ? false : true });
            }
        } else {
            return [];
        }
    }

    const handleMultiDelete = () => {
        muiconfirm({ title: "", description: 'Are you sure that you want to delete.', dialogProps: { fullWidth: false } })
            .then(() => {
                let t = tableData;
                let newArray = [];

                multiDelete.map(value => {
                    let curIndex = t.findIndex(i => (i.documentType) === (value.documentType) && (i.claimType) === (value.claimType) && (i.mediaType) === (value.mediaType));
                        newArray.push(t[curIndex]);
                    t.splice(curIndex, 1);
                })
                setTableData(t);
                props.setTableData(t);
                setShowForm(false);
                props.seterrorMessages([]);
                if(props.isEditOp){
                    props.setDeleteList([...props.deleteList,  ...newArray])
                }
                 setSuccess(false);
                setMultiDelete([]);
            });
    }

    const handelVoidCheck = () => {
        const data = props.claimExceptionRemarkVO;
        setTableData(voidRef.current.checked ? data : data.filter((a) => { return a.voidDate ? false : true }))
    }

    const minorDelete = () => {
        muiconfirm({ title: "", description: 'Are you sure that you want to delete.', dialogProps: { fullWidth: false } })
            .then(() => {
                let t = tableData;
                let valueRemoved = t[formData.index];
                if(props.isEditOp){
                    props.setDeleteList([...props.deleteList,  valueRemoved])
                }
                t.splice(formData.index, 1);
                setTableData(t);
                props.setTableData(t);
                setShowForm(false);
                props.seterrorMessages([]);
            });
    }


    return (
        <>

            <div className="tab-container">
                {success ? (
                    <div className="alert alert-success custom-alert" role="alert">
                        {ErrorMsgConstants.SUCCESSFULLY_SAVED_INFORMATION}
                    </div>
                ) : null}
                <div className="tab-header">
                    <h2 className="tab-heading float-left">
                        RA Text Override
                </h2>
                    <div className="float-right th-btnGroup">
                        <Button title="Delete" variant="outlined" color="primary" disabled={multiDelete.length == 0} className="btn btn-transparent btn-icon-only" onClick={() => handleMultiDelete()}
                        data-test='test_del_btn'
                        >
                            <i className="fa fa-trash" />
                        </Button>
                        <Button title="Add RA Text Override" color="primary" className="btn btn-secondary btn-icon-only"
                            onClick={() => {
                                setTimeout(function () {
                                    scrollToRef(addRAText);
                                }.bind(this), 1000);
                                    setShowForm(true);
                                    setSuccess(false);
                                    setFormData(defaultFormData);

                                
                            }}
                            data-test='test_add_btn'
                        >
                            <i className="fa fa-plus" />
                        </Button>
                    </div>

                </div>
                {props.isEditOp ? (<div className="mui-custom-form m-0">
                    <div className="sub-radio m-0">
                        <label className="MuiFormControlLabel-root inline-radio-label float-left">
                            <Checkbox
                                type="checkbox"
                                value="void"
                                id="fcVoidId"
                                inputRef={voidRef}
                                onChange={handelVoidCheck}
                            />
                            <span className="MuiFormControlLabel-label">Show Voids</span>
                        </label>
                        <div className="clearfix" />
                    </div>
                </div>) : null}
                <div className="tab-holder mt-1">
                    <TableComponent headCells={headCells}
                        selected={multiDelete} multiDelete setSelected={setMultiDelete} tableData={getTableData(tableData)} onTableRowClick={editRow} defaultSortColumn="beginDate"
                    />
                    {showForm
                        ?
                        <>
                            <div className="tab-header mt-3" ref={addRAText}>
                                <h2 className="tab-heading float-left">
                                    {formData.index > -1 ? "Edit" : "Add"} RA Text Override
                                </h2>
                                <div className="float-right th-btnGroup">
                                    <Button
                                        title={formData.index > -1 ? 'Update RA text override' : 'Add RA text override'}
                                        color="primary"
                                        className={formData.index > -1 ? 'btn btn-ic btn-save' : 'btn btn-ic btn-add'} onClick={saveFormData}
                                        data-test='test_addUpd_btn'
                                        >
                                        {formData.index > -1 ? 'Update' : 'Add'}</Button>
                                    {formData.index > -1 ?
                                        <Button title="Delete" variant="outlined" color="primary" className="btn btn-ic btn-delete"
                                            onClick={minorDelete}
                                        >
                                            Delete
                                        </Button> : null}
                                    {formData.index > -1 ?
                                        <Button title="Reset" color="primary" className="btn btn-ic btn-reset"
                                            onClick={() => {
                                                setFormData(resetformData);
                                                setFormErrors(false);
                                                props.seterrorMessages([]);
                                                setSuccess(false);

                                                ;
                                            }}
                                        >
                                            Reset</Button> :
                                        <Button title="Reset" color="primary" className="btn btn-ic btn-reset"
                                            onClick={() => {
                                                setFormData({ ...defaultFormData, "index": formData.index });
                                                setFormErrors(false);
                                                props.seterrorMessages([]);
                                                setSuccess(false);
                                            }}
                                            data-test='test_reset'
                                        >
                                            Reset</Button>
                                    }
                                    <Button title="Cancel" color="primary" className="btn btn-cancel"
                                        onClick={() => {
                                            setShowForm(false);
                                            props.seterrorMessages([]);
                                            setSuccess(false);

                                        }}
                                        data-test='test_cancel'
                                    >Cancel</Button>
                                </div>

                            </div>

                            <div className="tab-body-bordered mt-2">
                                <form autoComplete="off">
                                    <div className="form-wrapper">
                                        {props.isEditOp && formData.index > -1 ?
                                            <div className="mui-custom-form input-md">
                                                <label class="MuiFormLabel-root MuiInputLabel-shrink">Void</label>
                                                <div className="sub-radio mt-0">
                                                    <RadioGroup
                                                        row
                                                        aria-label="eftactive"
                                                        name="HideInactiveProviders"
                                                        value={formData.void}
                                                        onChange={(event) => {
                                                            setFormData({ ...formData, "void": event.target.value });
                                                        }}
                                                    >
                                                        <FormControlLabel
                                                            value="Yes"
                                                            id="yes-ra-text"
                                                            control={<Radio id="fcVoidYes" color="primary" />}
                                                            label="Yes"
                                                        />
                                                        <FormControlLabel
                                                            value="No"
                                                            id="no-ra-text"
                                                            control={<Radio id="fcVoidNo" color="primary" />}
                                                            label="No"
                                                        />
                                                    </RadioGroup>
                                                </div>
                                            </div> : null}
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="standard-select-document-type-ra-text"
                                                select
                                                label="Document Type"
                                                value={formData.documentType ? formData.documentType : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => { setFormData({ ...formData, "documentType": event.target.value }); }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                                helperText={
                                                    docReqErr ? ErrorMsgConstants.DOC_TYPE_REQ_ERR 
                                                    :duplicateErr?ErrorMsgConstants.DUP_RA_ERR
                                                    : null
                                                }
                                                error={
                                                    docReqErr ? ErrorMsgConstants.DOC_TYPE_REQ_ERR 
                                                    :duplicateErr?ErrorMsgConstants.DUP_RA_ERR
                                                    : null
                                                }
                                                data-test='test_doc'
                                            >
                                                <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                                                {docTypeDrpDwn}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="standard-select-media-type-ra-text"
                                                select
                                                label="Media Type"
                                                value={formData.mediaType ? formData.mediaType : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => { setFormData({ ...formData, "mediaType": event.target.value }); }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                                helperText={
                                                    mediaReqErr ? ErrorMsgConstants.MEDIA_TYPE_REQ_ERR : null
                                                }
                                                error={
                                                    mediaReqErr ? ErrorMsgConstants.MEDIA_TYPE_REQ_ERR : null
                                                }
                                                data-test='test_mediaType'
                                            >
                                                <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                                                {mediaTypeDrpDwn}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md">
                                            <TextField
                                                id="standard-select-claim-type-ra-text"
                                                select
                                                label="Claim Type"
                                                value={formData.claimType ? formData.claimType : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => { setFormData({ ...formData, "claimType": event.target.value }); }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true,
                                                    required: true
                                                }}
                                                helperText={
                                                    claimReqErr ? ErrorMsgConstants.CLAIM_TYPE_REQ_ERR : null
                                                }
                                                error={
                                                    claimReqErr ? ErrorMsgConstants.CLAIM_TYPE_REQ_ERR : null
                                                }
                                                data-test='test_claimType'
                                            >
                                                <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                                                {claimTypeDrpDwn}
                                            </TextField>
                                        </div>
                                    </div>
                                    <div className="form-wrapper">
                                        <div className="mui-custom-form with-select input-md pos-rel">
                                            <TooltipComponent title="Adjustment Reason Details" desc={formData.adjRsnDetail} />

                                            <TextField
                                                id="standard-select-adjustment-reason-ra-text"
                                                select
                                                label="Adjustment Reason"
                                                value={formData.adjustReason ? formData.adjustReason : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => {
                                                    setFormData({
                                                        ...formData, "adjustReason": event.target.value,
                                                        "adjRsnDetail": adjustReasonObj ? adjustReasonObj[event.target.value].description : ""
                                                    });
                                                }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                data-test='test_adj_rsn'
                                            >

                                                <MenuItem selected key=" Please Select One" value="-1">Please Select One</MenuItem>
                                                {adjRsnDrpDwn}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md pos-rel">

                                            <TooltipComponent title="Adjudication Remark Details" desc={formData.adjudRemarkDetail} />
                                            <TextField
                                                id="standard-select-adjud-remark-ra-text"
                                                select
                                                label="Adjudication Remark"
                                                value={formData.adjudRemark ? formData.adjudRemark : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => {
                                                    setFormData({
                                                        ...formData, "adjudRemark": event.target.value,
                                                        "adjudRemarkDetail": remarkObj ? remarkObj[event.target.value].description : ""
                                                    });
                                                }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                data-test='test_adj_rmk'
                                            >
                                                <MenuItem selected key=" Please Select One" value="-1">Please Select One</MenuItem>
                                                {remarkDrpDwn}
                                            </TextField>
                                        </div>
                                        <div className="mui-custom-form with-select input-md pos-rel">
                                            <TooltipComponent title="Adjudication EOB Details" desc={formData.adjudEOBDetail} />
                                            <TextField
                                                id="standard-select-adjud-EOB-ra-text"
                                                select
                                                label="Adjudication EOB"
                                                value={formData.adjudEOB ? formData.adjudEOB : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => {
                                                    setFormData({
                                                        ...formData, "adjudEOB": event.target.value,
                                                        "adjudEOBDetail": eobObj ? eobObj[event.target.value].eobDes : ""
                                                    });
                                                }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                data-test='test_adj_eob'
                                            >
                                                <MenuItem selected key=" Please Select One" value="-1">Please Select One</MenuItem>
                                                {eobDrpDwn}
                                            </TextField>

                                        </div>
                                        <div className="mui-custom-form with-select input-md pos-rel">
                                            <TooltipComponent title="Suspense Remark Details" desc={formData.suspenseRemarkDetail} />
                                            <TextField
                                                id="standard-select-suspense-Mark-ra-text"
                                                select
                                                label="Suspense Remark"
                                                value={formData.suspenseRemark ? formData.suspenseRemark : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => {
                                                    setFormData({
                                                        ...formData, "suspenseRemark": event.target.value,
                                                        "suspenseRemarkDetail": remarkObj ? remarkObj[event.target.value].description : ""
                                                    });
                                                }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                data-test='test_suspense_rmk'
                                            >
                                                <MenuItem selected key=" Please Select One" value="-1">Please Select One</MenuItem>
                                                {remarkDrpDwn}
                                            </TextField>

                                        </div>
                                        <div className="mui-custom-form with-select input-md pos-rel">
                                            <TooltipComponent title="Suspense EOB Details" desc={formData.suspenseEOBDetail} />
                                            <TextField
                                                id="standard-select-suspense-EOB-ra-text"
                                                select
                                                label="Suspense EOB"
                                                value={formData.suspenseEOB ? formData.suspenseEOB : "-1"}
                                                inputProps={{ maxLength: 2 }}
                                                onChange={(event) => {
                                                    setFormData({
                                                        ...formData, "suspenseEOB": event.target.value,
                                                        "suspenseEOBDetail": eobObj ? eobObj[event.target.value].eobDes : ""
                                                    });
                                                }}
                                                placeholder="Please Select One"
                                                InputLabelProps={{
                                                    shrink: true
                                                }}
                                                data-test='test_suspense_eob'
                                            >
                                                <MenuItem selected key=" Please Select One" value="-1">Please Select One</MenuItem>
                                                {eobDrpDwn}}
                                            </TextField>

                                        </div>
                                    </div>

                                </form>
                            </div>
                            {props.auditProps && props.auditProps.showAuditLog &&  formData.index > -1?
                                <AuditLogRow auditLogData={props.auditProps.subAuditLogData &&
                                    props.auditProps.subAuditLogData[AuditConstant.AUDIT_LOG_CLM_EXC_RMK]
                                    ? props.auditProps.subAuditLogData[AuditConstant.AUDIT_LOG_CLM_EXC_RMK]
                                    : []} />
                                : ""
                            }
                        </>
                        : ''}

                </div>
            </div>


        </>

    );
}
export default withRouter(RATextDefaultOverride);
