import React from 'react';
import { withRouter } from 'react-router';
import { Button } from 'react-bootstrap';
import TextField from '@material-ui/core/TextField';
import MenuItem from "@material-ui/core/MenuItem";
import * as ClaimExceptionConstant from '../ClaimExceptionConstant';

function AddDispositionCommonForm(props) {
  return (
    <div className="tab-holder mt-3">
      <div className="tab-header">
        <div className="tab-heading float-left">
          {`${props.type} ${props.header} Disposition Key`}
        </div>
        <div className="float-right th-btnGroup">
          <Button title={"Add " + props.header + " Disposition Key"} variant="outlined" color="primary" className="btn btn-ic btn-save"
            onClick={() => props.handelSave()} >
            {props.type === 'Edit' ? 'Update' : 'Add'}
        </Button>
          <Button title="Reset" variant="outlined" color="primary" className="btn btn-ic btn-reset" onClick={() => props.handelReset()} >
            Reset
        </Button>
          <Button title="Cancel" variant="outlined" color="primary" className="btn btn-cancel" onClick={() => props.handelCancleFn()} >
            Cancel
        </Button>
        </div>
        <div className="clearfix" />
      </div>
      <div className="tab-body-bordered mt-2" data-test='disp-key-add-component'>
        <form autoComplete="off">
          <div className="form-wrapper">
            <div className="mui-custom-form input-md with-select" data-test='claim-type'>
              {props.majorEdit && props.type === 'Edit' ? (
                <>
                <span className="inline-title"> Claim Type </span>
                <div className="fw-600 primary-text py-1 pr-3"> 
                    {props.values.claimTypeDescription}
                </div>
                </>
              ):
              <TextField
                id="bc-document-type"
                select
                required
                // disabled={edit}
                label="Claim Type"
                value={props.values.claimType}
                inputProps={{ maxLength: 2 }}
                onChange={props.handelKeyChange('claimType')}
                placeholder="Please Select One"
                InputLabelProps={{ shrink: true }}
                helperText={
                  props.showClaimTypeErr
                    ? ClaimExceptionConstant.CLAIM_TYPE_REQ_ERROR
                    : props. showClaimDupErr 
                    ? ClaimExceptionConstant.CLAIM_TYPE_DUP_REQ_ERROR
                    : null
                }
                error={
                  props.showClaimTypeErr
                    ? ClaimExceptionConstant.CLAIM_TYPE_REQ_ERROR
                    :  props. showClaimDupErr 
                    ? ClaimExceptionConstant.CLAIM_TYPE_DUP_REQ_ERROR
                    :null
                }>
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.claimsDropdown && props.claimsDropdown.map(each => (
                  <MenuItem selected key={each.id} value={each.id}>{each.claimType}</MenuItem>
                ))}
              </TextField>
            
              }
              </div>
            <div className="mui-custom-form input-md with-select" data-test='disposition'>
            <TextField
                id="bc-document-type"
                select
                required
                // disabled={edit}
                label="Disposition"
                value={props.values.disposition}
                inputProps={{ maxLength: 2 }}
                onChange={props.handelKeyChange('disposition')}
                placeholder="Please Select One"
                InputLabelProps={{ shrink: true }}
                helperText={
                  props.showDispositionErr 
                    ? ClaimExceptionConstant.DISPOSITION_REQ_ERROR
                    : null
                }
                error={
                  props.showDispositionErr
                    ? ClaimExceptionConstant.DISPOSITION_REQ_ERROR
                    : null
                }>
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.dropdown && props.dropdown['Claims#R_CLM_EXC_DISP_CD'] && props.dropdown['Claims#R_CLM_EXC_DISP_CD'].map(each => (
                  <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                ))}
              </TextField>
            </div>
            <div className="mui-custom-form input-md with-select" data-test='force-pay'>
            <TextField
                id="bc-document-type"
                select
                required
                // disabled={edit}
                label="Force Pay"
                value={props.values.forcePay}
                inputProps={{ maxLength: 2 }}
                onChange={props.handelKeyChange('forcePay')}
                placeholder="Please Select One"
                InputLabelProps={{ shrink: true }}
                helperText={
                  props.showPayErr
                    ? ClaimExceptionConstant.FORCE_PAY_REQ_ERROR
                    : null
                }
                error={
                  props.showPayErr
                    ? ClaimExceptionConstant.FORCE_PAY_REQ_ERROR
                    : null
                }>
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.dropdown && props.dropdown['Claims#R_EXC_FORCE_APP_CD'] && props.dropdown['Claims#R_EXC_FORCE_APP_CD'].map(each => (
                  <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                ))}
              </TextField>
            </div>
            <div className="mui-custom-form input-md with-select" data-test='force-deny'>
            <TextField
                id="bc-document-type"
                select
                required
                // disabled={edit}
                label="Force Deny"
                value={props.values.forceDeny}
                inputProps={{ maxLength: 2 }}
                onChange={props.handelKeyChange('forceDeny')}
                placeholder="Please Select One"
                InputLabelProps={{ shrink: true }}
                helperText={
                  props.showDenyErr
                    ? ClaimExceptionConstant.FORCE_DENY_REQ_ERROR
                    : null
                }
                error={
                  props.showDenyErr
                    ? ClaimExceptionConstant.FORCE_DENY_REQ_ERROR
                    : null
                }>
                <MenuItem value="-1">Please Select One</MenuItem>
                {props.dropdown && props.dropdown['Claims#R_FORCE_DENY_CD'] && props.dropdown['Claims#R_FORCE_DENY_CD'].map(each => (
                  <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                ))}
              </TextField>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};

export default withRouter(AddDispositionCommonForm);