import React, {
  useState,
  useEffect,
  useImperativeHandle,
} from "react";
import { makeStyles } from "@material-ui/core/styles";
import { Button } from "react-bootstrap";
import DispositionKeyTable from "./DispositionKeyTable";
import AddDispositionCommonForm from "./AddDispositionCommonForm";
import { getLoginUserDetails } from "../../../../SharedModules/utility/utilityFunction";
import * as ClaimExceptionConstant from '../ClaimExceptionConstant';
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';
import { withRouter } from "react-router";

import * as ErrorMsgConstants from '../../../../SharedModules/Messages/ErrorMsgConstants';

const useStyles = makeStyles((theme) => ({
  root: {
    width: "100%",
  },
  heading: {
    fontSize: theme.typography.pxToRem(15),
    fontWeight: theme.typography.fontWeightRegular,
  },
}));

function AddDispositionKeyForm(props, ref) {

  const [tableData, setTableData] = useState();
  const [isMinorEdit, setIsMinorEdit] = useState(false);
  const [deleteArray, setDeleteArray] = useState([]);
  const [defaultFormData, setDefaultFormData] = useState({
    claimType: '-1',
    disposition: 'Z',
    forcePay: '0',
    forceDeny: '0'
  })
  const [formValues, setFormValues] = useState({});
  const [resetValues, setResetValues] = useState({});
  const userDetails = getLoginUserDetails();
  const [success, setSuccess] = useState(false);
  const [{ showClaimTypeErr, showDispositionErr, showDenyErr, showPayErr }, setError] = useState(false)
  const [{ showClaimDupErr }, setDupErr] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);

  useEffect(() => {
    if(props.componentData.length > 0){
      const data = props.componentData;
      setTableData(data);
      setFormValues({
        claimType: props.componentData.claimType,
        disposition: props.componentData.disposition,
        forceDeny: props.componentData.forceDeny,
        forcePay: props.componentData.forcePay
      })
      setResetValues({
        claimType: props.componentData.claimType,
        disposition: props.componentData.disposition,
        forceDeny: props.componentData.forceDeny,
        forcePay: props.componentData.forcePay
      })
    }else{
      setTableData([]);
      setFormValues(defaultFormData);
      setResetValues(defaultFormData);
    }
  }, [props.componentData]);

  const handelReset = () => {
    setFormValues(resetValues);
  };

  const handelKeyChange = (name) => (event) => {
    setFormValues({ ...formValues, [name]: event.target.value });
  };

  // useImperativeHandle(ref, () => {
  //   return {
  //     minorValidations,
  //   };
  // });

  const minorValidations = async () => {
    let reqFieldArr = [];
    setError({
      showClaimTypeErr: formValues.claimType !== '-1' ? false : (() => { reqFieldArr.push(ClaimExceptionConstant.CLAIM_TYPE_REQ_ERROR); return true; })(),
      showDispositionErr: formValues.disposition !== '-1' ? false : (() => { reqFieldArr.push(ClaimExceptionConstant.DISPOSITION_REQ_ERROR); return true; })(),
      showDenyErr: formValues.forceDeny !== '-1' ? false : (() => { reqFieldArr.push(ClaimExceptionConstant.FORCE_DENY_REQ_ERROR); return true; })(),
      showPayErr: formValues.forcePay !== '-1' ? false : (() => { reqFieldArr.push(ClaimExceptionConstant.FORCE_PAY_REQ_ERROR); return true; })(),
      //showClaimDupErr: props.componentData.some((i) => i.claimType === formValues.claimType) ? false : (() => { reqFieldArr.push(ClaimExceptionConstant.CLAIM_TYPE_DUP_REQ_ERROR); return true; })(),
      });

    const duplicate = props.componentData.some((i) => i.claimType === formValues.claimType);
    if (duplicate && !isMinorEdit) {
      setDupErr({
        showClaimDupErr: (() => { reqFieldArr.push(ClaimExceptionConstant.CLAIM_TYPE_DUP_REQ_ERROR); return true; })(),
      })
    } else {
      setDupErr({
        showClaimDupErr: false
      })
    }
    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      props.setDisErr(true)
      return false;
    }
    return true;
  };

  const handelSave = async () => {
    setSuccess(false);
    let validations = await minorValidations();
    if (validations) {
      let dataTable = props.componentData;
      let data = {
        auditUserID: userDetails.loginUserName,
        auditTimeStamp: new Date(),
        addedAuditUserID: userDetails.loginUserName,
        addedAuditTimeStamp: new Date(),
        versionNo: formValues.versionNo ? formValues.versionNo : 0,
        dbRecord: true,
        sortColumn: null,
        auditKeyList: [],
        auditKeyListFiltered: false,
        claimType: formValues.claimType,
        claimTypeDescription: null,
        disposition: formValues.disposition,
        forcePay: formValues.forcePay,
        forceDeny: formValues.forceDeny,
        dispositionDesc: null,
        forcePayDesc: null,
        forceDenyDesc: null,
        voidDate: null,
        voiddt: null,
      };
      if (formValues.index > -1) {
        data["claimExceptionDispSK"] = formValues.claimExceptionDispSK ? formValues.claimExceptionDispSK : null
      }
      formValues.index > -1
        ? (dataTable[formValues.index] = data)
        : dataTable.push(data);
      props.setComponentData(dataTable);
      setTableData(dataTable)
      props.setShowForm(false);
      setSuccess(true);
      setIsMinorEdit(false);
      props.setDisErr(false);
    }
  };

  const handelCancleFn = () => {
    props.setShowForm(false);
    setSuccess(false);
  };

  const handelAddEditClick = (row) => {
    props.setShowForm(true);
    setSuccess(false);
    if (row === null) {
      setFormValues({
        claimType: '-1',
        disposition: 'Z',
        forcePay: '0',
        forceDeny: '0'
      });
      setResetValues({
        claimType: '-1',
        disposition: 'Z',
        forcePay: '0',
        forceDeny: '0'
      });
      setIsMinorEdit(false)
    } else {
      setFormValues({ ...row });
      setResetValues({ ...row });
      setIsMinorEdit(true)      
    }
  }
  const multiDelete = () => {
    setDialogOpen(false);
    props.setShowForm(false);
    props.setDispositionKeyDelete(selectDeleteArray);
    if (selectDeleteArray.length > 0) {
      let DT = tableData;
      selectDeleteArray.map((value, index) => {
        let curIndex = DT.findIndex(i => i.claimType === value.claimType);        
        DT.splice(curIndex, 1);
      });
      setTableData(DT);
      setSelectDeleteArray([]);
    }
  }

  return (
    <>
      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to delete?
        </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button title="Ok" onClick={multiDelete} color="primary" className="btn btn-success">
            Ok
            </Button>
          <Button title="Cancel" onClick={() => { setDialogOpen(false) }} color="primary" autoFocus>
            Cancel
            </Button>
        </DialogActions>
      </Dialog>
      <div className="tab-header" data-test='disp-key-form-component'>
        <h2 className="tab-heading float-left">{props.header}</h2>
        <div className="float-right">
          <Button title="Delete Dispositon Key Information" data-test="disp-key-trash-btn" disabled={selectDeleteArray.length == 0} variant="outlined" color="primary" onClick={() => { setDialogOpen(true); setSuccess(false) }} className="btn btn-transparent btn-icon-only">
            <i className="fa fa-trash" />
          </Button>
          <Button
            title={"Add " + props.header}
            variant="outlined"
            color="primary"
            className="btn btn-secondary btn-icon-only"
            data-test="disp-key-add-btn"
            onClick={() => {
              handelAddEditClick(null);
            }}
          >
            <i className="fa fa-plus" />
            <span className="hide-elm"> Add {props.header} </span>
          </Button>
        </div>
        <div className="clearfix" />
      </div>
      <div className="tab-body mt-2">
      {success ? (
                    <div className="alert alert-success custom-alert" role="alert">
                        {ErrorMsgConstants.SUCCESSFULLY_SAVED_INFORMATION}
                    </div>
                ) : null}
        <DispositionKeyTable
          tableData={tableData}
          handelAddEditClick={handelAddEditClick}
          dropdown={props.dropdown}
          selectDeleteArray={selectDeleteArray}
          setSelectDeleteArray={setSelectDeleteArray}
          data-test="disp-key-table"
        />
      </div>
      {props.showForm ? (
        <>
          <AddDispositionCommonForm
            header={props.header}
            type={formValues.index > -1 ? "Edit" : "Add"}
            values={formValues}
            handelReset={handelReset}
            handelSave={handelSave}
            majorEdit = {props.majorEdit}
            handelKeyChange={handelKeyChange}
            handelCancleFn={handelCancleFn}
            dropdown={props.dropdown}
            claimsDropdown={props.claimsDropdown}
            showClaimTypeErr={showClaimTypeErr}
            showDispositionErr={showDispositionErr}
            showPayErr={showPayErr}
            showDenyErr={showDenyErr}
            showClaimDupErr={showClaimDupErr}
            setSuccess= {setSuccess}
          />
        </>
      ) : null}
    </>
  );
}

export default withRouter(AddDispositionKeyForm);
