import React, { useEffect, useState } from 'react';
import { withRouter } from 'react-router';
import TableComponent from '../../../../SharedModules/Table/Table';

function DispositionKeyTable(props) {
  const headCells = [
    {
      id: 'claimTypeDescription', numeric: false, isDate: false, disablePadding: true, label: 'Claim Type', enableHyperLink: true, fontSize: 12, width:110
    },
    {
      id: 'dispositionDesc', numeric: false, isDate: false, disablePadding: false, label: 'Disposition', enableHyperLink: false, fontSize: 12, width:110
    },
    {
        id: 'forcePayDesc', numeric: false, isDate: false, disablePadding: false, label: 'Force Pay', enableHyperLink: false, fontSize: 12, width:110
      },
      {
        id: 'forceDenyDesc', numeric: false, isDate: false, disablePadding: false, label: 'Force Deny', enableHyperLink: false, fontSize: 12, width:110
      },
  ];  

  const getTableData = (data) => {
    if (data && data.length) {
      let tData = JSON.stringify(data); 
      tData = JSON.parse(tData);     
      tData.map((each,index) => {
        let claimTypeDescription = props.dropdown['ClaimException#C_TY_CD'] && props.dropdown['ClaimException#C_TY_CD'].filter(value => value.code === each.claimType);
        let dispositionDesc = props.dropdown['Claims#R_CLM_EXC_DISP_CD'] && props.dropdown['Claims#R_CLM_EXC_DISP_CD'].filter(value => value.code === each.disposition);    
        let forcePayDesc = props.dropdown['Claims#R_EXC_FORCE_APP_CD'] && props.dropdown['Claims#R_EXC_FORCE_APP_CD'].filter(value => value.code === each.forcePay);
        let forceDenyDesc = props.dropdown['Claims#R_FORCE_DENY_CD'] && props.dropdown['Claims#R_FORCE_DENY_CD'].filter(value => value.code === each.forceDeny);    
                     
        each.index = index;
        each.claimTypeDescription = claimTypeDescription && claimTypeDescription.length > 0 ? claimTypeDescription[0].description : '';;
        each.dispositionDesc = dispositionDesc && dispositionDesc.length > 0 ? dispositionDesc[0].description : '';
        each.forcePayDesc = forcePayDesc && forcePayDesc.length > 0 ? forcePayDesc[0].description : '';
        each.forceDenyDesc = forceDenyDesc && forceDenyDesc.length > 0 ? forceDenyDesc[0].description : '';
      }); 
      return tData;           
    }else{
      return [];
    }
  }
  
  const editRow = row => (event) => {    
    props.handelAddEditClick(row);
  };  

  return (    
    <TableComponent headCells={headCells} selected={props.selectDeleteArray} 
    setSelected={props.setSelectDeleteArray} 
    multiDelete tableData={getTableData(props.tableData)} onTableRowClick={editRow} defaultSortColumn="diagnosisCode" />    
  );
}
export default withRouter(DispositionKeyTable);
