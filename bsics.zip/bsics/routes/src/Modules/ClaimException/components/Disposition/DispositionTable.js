import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../../SharedModules/Table/Table';

const headCells = [
    {
        id: 'documentTypeDesc', numeric: false, disablePadding: true, label: 'Document Type', enableHyperLink: true, width: 120, fontSize: 12
    },
    {
        id: 'mediaTypeDesc', numeric: false, disablePadding: false, label: 'Media Type', enableHyperLink: false, width: 120, fontSize: 12
    },
    {
        id: 'voidDate', numeric: false, disablePadding: false, label: 'Void Date', enableHyperLink: false, width: 120, fontSize: 12
    }

];

function DispositionTable(props) {

    const getTableData = (data) => {
        if (data && data.length) {
            let tData = JSON.stringify(data);
            tData = JSON.parse(tData);
            tData.map((each, index) => {
                each.index = index;
                each.documentTypeDesc = codeToDesc(each.documentTypeCode);
                each.mediaTypeDesc = codeToDesc(each.mediaTypeCode);
                each.voidDate = each.voidDate;
            });
            if (props.voidRef.current && props.voidRef.current.checked) {
                return tData;
            } else {
                return tData.filter((a) => { return a.voidDate ? false : true });
            }
        } else {
            return [];
        }
    }

    const codeToDesc = (c) => {
        if (c === 'A') {
            return 'A-Adjustment';
        }
        if (c === 'C') {
            return 'C-FFS';
        }
        if (c === 'E') {
            return 'E-Encounter';
        }
        if (c === 'J') {
            return 'J-EncAdjust';
        }
        if (c === 'Y') {
            return 'Y';
        }
        if (c === '1') {
            return '1-Web';
        }
        if (c === '2') {
            return '2-Elec Xover';
        }
        if (c === '3') {
            return '3-EMC';
        }
        if (c === '4') {
            return '4-System Gen';
        }
        if (c === '5') {
            return '5-Encounter';
        }
        if (c === '7') {
            return '7-OCR';
        }
        if (c === '8') {
            return '8-Paper';
        }
    }

    const editRow = row => (event) => {
          props.handleRowClick(row);
          props.setSuccess(false);
    };

    return (
        <TableComponent headCells={headCells} headCells={headCells} selected={props.selectDeleteArray} 
        setSelected={props.setSelectDeleteArray} 
        multiDelete tableData={getTableData(props.tableData)} onTableRowClick={editRow} />
    );
}
export default withRouter(DispositionTable);
