import React, { useState, useEffect, useRef } from 'react';
import { withRouter } from 'react-router';
import { Button } from 'react-bootstrap';
import { ExpansionPanel, ExpansionPanelSummary, Typography, ExpansionPanelDetails, TextField } from "@material-ui/core";
import MenuItem from "@material-ui/core/MenuItem";
import ExpandMoreIcon from '@material-ui/icons/ExpandMore';
import DispositionTable from './DispositionTable';
import AddDispositionKeyForm from './AddDispositionKeyForm';
import { getLoginUserDetails } from '../../../../SharedModules/utility/utilityFunction';
import * as ErrorMsgConstants from '../../../../SharedModules/Messages/ErrorMsgConstants';
import * as ClaimExceptionConstant from '../ClaimExceptionConstant';
import RadioGroup from "@material-ui/core/RadioGroup";
import Radio from "@material-ui/core/Radio";
import dateFnsFormat from 'date-fns/format';
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Checkbox from "@material-ui/core/Checkbox";
import Dialog from '@material-ui/core/Dialog';
import DialogActions from '@material-ui/core/DialogActions';
import DialogContent from '@material-ui/core/DialogContent';
import DialogContentText from '@material-ui/core/DialogContentText';

function DispositionDetails(props) {

  const [tableData, setTableData] = useState([]);
  const userDetails = getLoginUserDetails();
  const [success, setSuccess] = useState(false);
  const [{ showDocTypeErr, showMediaTypeErr }, setDisShowError] = React.useState(false);
  const [disErr, setDisErr] = useState(false);
  const [showFinForm, setShowFinForm] = useState(false);
  const [showProForm, setShowProForm] = useState(false);
  const [showInsForm, setShowInsForm] = useState(false);
  const [showPhrForm, setShowPhrForm] = useState(false);
  const [showDenForm, setShowDenForm] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [selectDeleteArray, setSelectDeleteArray] = useState([]);
  const [tableFinancialData, setTableFinancialData] = useState([]);
  const [tableProfessionalData, setTableProfessionalData] = useState([]);
  const [tableInstitutionalData, setTableInstitutionalData] = useState([]);
  const [tablePharmacyData, setTablePharmacyData] = useState([]);
  const [tableDentalData, setTableDentalData] = useState([]);

  //Claim type dropdowns
  const [ClaimTypeFDropdown, setClaimTypeFDropdown] = useState([
    { "id": "F", "claimType": "Fin Tran" }, { "id": "Z", "claimType": "Void Req" }, { "id": "R", "claimType": "Repl Req" }
  ]);
  const [ClaimTypeProDropdown, setClaimTypeProDropdown] = useState([
    { "id": "C", "claimType": "Capitation" }, { "id": "Y", "claimType": "Prof Xover" }, { "id": "M", "claimType": "Medical" }
  ]);
  const [ClaimTypePharDropdown, setClaimTypePharDropdown] = useState([{ "id": "P", "claimType": "Pharmacy" }]);
  const [ClaimTypeDenDropdown, setClaimTypeDenDropdown] = useState([{ "id": "D", "claimType": "Dental" }]);
  const [ClaimTypeInsDropdown, setClaimTypeInsDropdown] = useState([
    { "id": "I", "claimType": "Inpatient" }, { "id": "W", "claimType": "Inp Xover" },
    { "id": "N", "claimType": "Nurse Hm" }, { "id": "O", "claimType": "Outpatient" }, { "id": "X", "claimType": "Outp Xover" }
  ]);

  const [isEdit, setIsEdit] = useState(false);

  const [showDispositionAddForm, setShowDispositionAddForm] = useState(false);
  const [deleteList, setDeleteList] = useState({});
  const [financialKeyDelete, setFinancialKeyDelete] = useState([]);
  const [professionalKeyDelete, setProfessionalKeyDelete] = useState([]);
  const [institutionalKeyDelete, setInstitutionalKeyDelete] = useState([]);
  const [pharmacyKeyDelete, setPharmacyKeyDelete] = useState([]);
  const [dentalKeyDelete, setDentalKeyDelete] = useState([]);
  const defaultFormData = {
    "documentTypeCode": "-1",
    "mediaTypeCode": "-1",
    // "voidIndicator": '0',
  };
  const [formData, setFormData] = useState([]);
  const [resetformData, setResetFormData] = useState([]);
  const voidRef = useRef();
  // const [voidIndicator, setVoidIndicator] = useState(false);

  useEffect(() => {
    console.log("disposition values",props.dispositionValues)
    if (props.dispositionValues) {
      setTableData(props.dispositionValues);
      setFormData(props.dispositionValues);
      setResetFormData(props.dispositionValues);
    } else {
      setTableData([]);
      setFormData(defaultFormData)
      setResetFormData(defaultFormData);
    }
  }, [props.dispositionValues])

  const minorValidation = () => {
    let reqFieldArr = [];
    setDisShowError({
      showDocTypeErr: formData.documentTypeCode !== '-1' ? false : (() => { reqFieldArr.push(ClaimExceptionConstant.DOC_TYPE_REQ_ERROR); return true; })(),
      showMediaTypeErr: formData.mediaTypeCode !== '-1' ? false : (() => { reqFieldArr.push(ClaimExceptionConstant.MEDIA_TYPE_REQ_ERROR); return true; })(),
    });
    if (reqFieldArr.length) {
      props.seterrorMessages(reqFieldArr);
      return false;
    }

    if (disErr === true) {
      return false;
    }
    return true;
  }

  const formatDate = (dt) => {
    if (!dt) {
      return "";
    }
    dt = new Date(dt);
    if (dt.toString() == "Invalid Date") {
      return "";
    } else {
      return dateFnsFormat(dt, "MM/dd/yyyy");
    }
  };

  const saveFormData = () => {
    setSuccess(false);
    props.seterrorMessages([]);
    if (minorValidation()) {
      let fCheck = tableData.filter((item, index) => item.documentTypeCode == formData.documentTypeCode && item.mediaTypeCode ==formData.mediaTypeCode);
      if(formData.index > -1){
        

      }else{
        if(fCheck.length > 0){
          props.seterrorMessages(["The Document Type and Media type combination exists for this exception code. Duplicate Document Type and Media Type combinations are not allowed for Claim exception Disposition."]);
         return false;
        }
      }
     
      let tmpTableData = tableData;
      let data = {
        "auditUserID": userDetails.loginUserName,
        "auditTimeStamp": new Date(),
        "addedAuditUserID": userDetails.loginUserName,
        "addedAuditTimeStamp": new Date(),
        "versionNo": 0,
        "dbRecord": false,
        "sortColumn": null,
        "auditKeyList": [],
        "auditKeyListFiltered": false,
        "documentTypeCode": formData.documentTypeCode,
        "mediaTypeCode": formData.mediaTypeCode,
        "documentTypeDesc": formData.documentTypeDesc,
        "mediaTypeDesc": formData.mediaTypeDesc,
        "dispositionDetails": [...tableFinancialData, ...tableProfessionalData, ...tableInstitutionalData, ...tablePharmacyData, ...tableDentalData],
        "lobCode": "N",
        "voidDate": formData.void === 'Yes' ? (formData && formData.voidDate ? formData.voidDate : formatDate(new Date())) : null,
        "showVoids": false,
        "showVoidRecord": false,
        "voidDispRecord": false,
        "tempVoidDate": null
      }
      // if (formData.index > -1) {
      //   data["exceptionRemarkSK"] = data["exceptionRemarkSK"] ? data["exceptionRemarkSK"] : null
      // }
      formData.index > -1 ? tmpTableData[formData.index] = data : tmpTableData.push(data);
      setTableData(tableData);
      setSuccess(true);
      if(props.setClaimExceptionDispositionVO){
        props.setClaimExceptionDispositionVO(tableData);
      }
      setFormData(defaultFormData);
      setTableFinancialData([]);
      setTableProfessionalData([]);
      setTableInstitutionalData([]);
      setTablePharmacyData([]);
      setTableDentalData([]);
      setShowDispositionAddForm(false);
      if(props.majorEdit){
      let dispositionDeleteArray = [...financialKeyDelete, ...professionalKeyDelete, ...institutionalKeyDelete, ...pharmacyKeyDelete, ...dentalKeyDelete]    
        if(dispositionDeleteArray.length > 0) {
          props.setDispositionDeleteList([{
          "auditUserID": userDetails.loginUserName,
          "auditTimeStamp": new Date(),
          "addedAuditUserID": userDetails.loginUserName,
          "addedAuditTimeStamp": new Date(),
          "versionNo": 0,
          "dbRecord": false,
          "sortColumn": null,
          "auditKeyList": [],
          "auditKeyListFiltered": false,
          "documentTypeCode": formData.documentTypeCode,
          "mediaTypeCode": formData.mediaTypeCode,
          "documentTypeDesc": formData.documentTypeDesc,
          "mediaTypeDesc": formData.mediaTypeDesc,
          "dispositionDetails": dispositionDeleteArray,
          "lobCode": "N",
          "voidDate": formData.void === 'Yes' ? (formData && formData.voidDate ? formData.voidDate : formatDate(new Date())) : null,
          "showVoids": false,
          "showVoidRecord": false,
          "voidDispRecord": false,
          "tempVoidDate": null
          }])
        } else  props.setDispositionDeleteList(null);   
      }   
    }
  }

  const handleRowClick = (rowData) => {

    setShowDispositionAddForm(true);
    setFormData({ ...rowData, void: rowData.void ? 'Yes' : 'No' });
    setResetFormData({ ...rowData, void: rowData.void ? 'Yes' : 'No' });
    setIsEdit(true);

    setTableFinancialData(rowData.dispositionDetails.filter(item => item.claimType === 'Z' || item.claimType === 'F' || item.claimType === 'R'));
    setTableProfessionalData(rowData.dispositionDetails.filter(item => item.claimType === 'C' || item.claimType === 'Y' || item.claimType === 'M'));
    setTableInstitutionalData(rowData.dispositionDetails.filter(item => item.claimType === 'I' || item.claimType === 'W' || item.claimType === 'N' || item.claimType === 'O' || item.claimType === 'X'));
    setTablePharmacyData(rowData.dispositionDetails.filter(item => item.claimType === 'P'));
    setTableDentalData(rowData.dispositionDetails.filter(item => item.claimType === 'D'));
  }

  const cancelDispositionAdd = () => {
    setShowDispositionAddForm(false);
  }

  const handleVoidCheck = () => {
    const data = props.dispositionValues;
    setTableData(voidRef.current.checked ? data : data.filter((a) => { return a.voidDate ? false : true }))
  }

  const resetDispositionAdd = () => {
    // resetformData
    setDisShowError({});
    props.seterrorMessages([]);
    setFormData(defaultFormData);
  }

  const showDispositionAdd = () => {
    setShowDispositionAddForm(true);
    setFormData(defaultFormData);
    setTableFinancialData([]);
    setTableProfessionalData([]);
    setTableInstitutionalData([]);
    setTablePharmacyData([]);
    setTableDentalData([]);
    setShowFinForm(false);
    setShowProForm(false);
    setShowInsForm(false);
    setShowPhrForm(false);
    setShowDenForm(false);
  }

  const multiDelete = () => {
    setDialogOpen(false);
    props.seterrorMessages([]);
    props.setSuccessMessages([]);
    setShowDispositionAddForm(false);
    if (selectDeleteArray.length > 0) {
      let DT = tableData;
      let deleteArray= [];
      selectDeleteArray.map((value, index) => {
        let curIndex = DT.findIndex(i => i.documentTypeCode === value.documentTypeCode);
        deleteArray.push(DT[curIndex])
        setDeleteList({ ...deleteList, deleteArray});
        DT.splice(curIndex, 1);
      });
      setTableData(DT);
      setSelectDeleteArray([]);
      setShowDispositionAddForm(false);
    }
  }

  return (
    <>
      <Dialog
        open={dialogOpen}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        className="custom-alert-box"
      >
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure that you want to delete?
        </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button title="Ok" onClick={multiDelete} color="primary" className="btn btn-success">
            Ok
            </Button>
          <Button title="Cancel" onClick={() => { setDialogOpen(false) }} color="primary" autoFocus>
            Cancel
            </Button>
        </DialogActions>
      </Dialog>

      <div className='tab-holder CustomExpansion-panel my-3' data-test='disp-details-component'>
        <ExpansionPanel className="collapsable-panel">
          <ExpansionPanelSummary
            expandIcon={<ExpandMoreIcon />}
            aria-controls="panel1a-content"
            id="panel1a-header">
            <Typography > Dispositon Key Information </Typography>
          </ExpansionPanelSummary>
          <ExpansionPanelDetails className="clear-block">
            {success ? (
              <div className="alert alert-success custom-alert" role="alert">
                {ErrorMsgConstants.SUCCESSFULLY_SAVED_INFORMATION}
              </div>
            ) : null}
            <div className="tabs-container mt-2">
              <div className="tab-header">
                <h3 className="tab-heading float-left">Dispositon Key Information </h3>
                <div className="float-right th-btnGroup">
                  <Button title="Delete Dispositon Key Information" data-test='test-btn-trash' disabled={selectDeleteArray.length == 0} variant="outlined" color="primary" className="btn btn-transparent btn-icon-only" onClick={() => { setDialogOpen(true) }}>
                    <i className="fa fa-trash" />
                    <span className="hide-elm"> Add Dispositon Key Information</span>
                  </Button>
                  <Button title="Add Dispositon Key Information" variant="outlined" color="primary"
                    className="btn btn-secondary btn-icon-only" data-test='test-btn-plus' onClick={showDispositionAdd}>
                    <i className="fa fa-plus" />
                    <span className="hide-elm"> Delete  Dispositon Key Information </span>
                  </Button>
                </div>
              </div>
              {/* {true ? ( */}
              {props.majorEdit ? (
                <div className="mui-custom-form m-0">
                  <label for="voidId" className="sub-radio m-0">
                    <Checkbox
                      className="pull-left"
                      type="checkbox"
                      inputRef={voidRef}
                      id="voidId"
                      onChange={handleVoidCheck}
                    />
                    <span className="text-black pull-left">Show Voids</span>
                  </label>
                </div>
              ) : null}
              <div className="clearfix"></div>
              <div className="tab-holder mt-3">
                <DispositionTable
                  tableData={tableData}
                  handleRowClick={handleRowClick}
                  dropdowns={props.dropdown}
                  setSuccess={setSuccess}
                  voidRef={voidRef}
                  selectDeleteArray={selectDeleteArray}
                  setSelectDeleteArray={setSelectDeleteArray}
                  data-test='disp-table'
                />
              </div>
              {showDispositionAddForm ? (
                <div className="tabs-container mt-3">
                  <div className="tab-header">
                    <h3 className="tab-heading float-left">
                      {formData.index > -1 ? "Edit" : "Add"} Dispositon Key</h3>
                    <div className="float-right th-btnGroup">
                      <Button title="Add" color="primary" className="btn btn-ic btn-save" onClick={saveFormData}>
                        {formData.index > -1 ? "Update" : "Add"}
                      </Button>
                      <Button title="Reset" color="primary" className="btn btn-ic btn-reset" onClick={resetDispositionAdd}>Reset</Button>
                      <Button title="Cancel" color="primary" className="btn btn-primary" onClick={cancelDispositionAdd}>
                        Cancel</Button>
                    </div>
                  </div>
                  <div className="tab-holder CustomExpansion-panel pt-2">
                    <div className="tabs-container">
                      <div className="tab-body-bordered">
                        <div className="form-wrapper pb-0">
                          {/* {true ? ( */}
                          {props.majorEdit && formData.index > -1 ? (
                            <div className="mui-custom-form input-md">
                              <div className="MuiFormLabel-root MuiInputLabel-shrink">Void</div>
                              <div className="sub-radio mt-0">
                                <RadioGroup
                                  row
                                  aria-label="eftactive"
                                  name="HideInactiveProviders"
                                  value={formData.void}
                                  onChange={(event) => {
                                    setFormData({
                                      ...formData,
                                      "void": event.target.value,
                                    });
                                  }}
                                >
                                  <FormControlLabel
                                    value="Yes"
                                    id="yes-ra-text"
                                    control={<Radio id="fcVoidYes" color="primary" />}
                                    label="Yes"
                                  />
                                  <FormControlLabel
                                    value="No"
                                    id="no-ra-text"
                                    control={<Radio id="fcVoidNo" color="primary" />}
                                    label="No"
                                  />
                                </RadioGroup>
                              </div>
                            </div>
                          ) : null}
                          <div className="mui-custom-form with-select input-md">
                            <TextField
                              id="bc-document-type"
                              select
                              required
                              // disabled={edit}
                              label="Document Type"
                              data-test="document-type"
                              value={formData.documentTypeCode}
                              inputProps={{ maxLength: 2 }}
                              onChange={(event) => { setFormData({ ...formData, "documentTypeCode": event.target.value }); }}
                              placeholder="Please Select One"
                              InputLabelProps={{ shrink: true }}
                              helperText={
                                showDocTypeErr
                                  ? ClaimExceptionConstant.DOC_TYPE_REQ_ERROR
                                  : null
                              }
                              error={
                                showDocTypeErr
                                  ? ClaimExceptionConstant.DOC_TYPE_REQ_ERROR
                                  : null
                              }>
                              <MenuItem value="-1">Please Select One</MenuItem>
                              {props.dropdown && props.dropdown['Claims#C_BATCH_DOC_TY_CD'] && props.dropdown['Claims#C_BATCH_DOC_TY_CD'].map(each => (
                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                              ))}
                            </TextField>
                          </div>
                          <div className="mui-custom-form with-select input-md">
                            <TextField
                              id="bc-media-sorce"
                              select
                              required
                              // disabled={edit}
                              data-test="media-type"
                              label="Media Type"
                              value={formData.mediaTypeCode}
                              inputProps={{ maxLength: 2 }}
                              onChange={(event) => { setFormData({ ...formData, "mediaTypeCode": event.target.value }); }}
                              placeholder="Please Select One"
                              InputLabelProps={{ shrink: true }}
                              helperText={
                                showMediaTypeErr
                                  ? ClaimExceptionConstant.MEDIA_TYPE_REQ_ERROR
                                  : null
                              }
                              error={
                                showMediaTypeErr
                                  ? ClaimExceptionConstant.MEDIA_TYPE_REQ_ERROR
                                  : null
                              }>
                              <MenuItem value="-1">Please Select One</MenuItem>
                              {props.dropdown && props.dropdown['Claims#C_BATCH_MEDIA_SRC_CD'] && props.dropdown['Claims#C_BATCH_MEDIA_SRC_CD'].map(each => (
                                <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                              ))}
                            </TextField>
                          </div>
                        </div>
                        <div className="p-3">
                          {/* Financial Add */}
                          <AddDispositionKeyForm header="Financial"
                            componentData={tableFinancialData}
                            setComponentData={setTableFinancialData}
                            dropdown={props.dropdown}
                            claimsDropdown={ClaimTypeFDropdown}
                            seterrorMessages={props.seterrorMessages}
                            showForm={showFinForm}
                            setShowForm={setShowFinForm}
                            setDisErr={setDisErr}
                            isEdit={isEdit}
                            majorEdit={props.majorEdit}
                            setMajorEdit={props.setMajorEdit}
                            setDispositionKeyDelete={setFinancialKeyDelete }
                          />
                          {/* Professional Add */}
                          <div className="tab-holder mt-3">
                            <AddDispositionKeyForm
                              header="Professional"
                              componentData={tableProfessionalData}
                              setComponentData={setTableProfessionalData}
                              dropdown={props.dropdown}
                              claimsDropdown={ClaimTypeProDropdown}
                              seterrorMessages={props.seterrorMessages}
                              showForm={showProForm}
                              setShowForm={setShowProForm}
                              setDisErr={setDisErr}
                              isEdit={isEdit}
                              setMajorEdit={props.setMajorEdit}
                              majorEdit={props.majorEdit}
                              setDispositionKeyDelete={setProfessionalKeyDelete}
                            />

                          </div>
                          {/* Institutional Add */}
                          <div className="tab-holder mt-3">
                            <AddDispositionKeyForm
                              header="Institutional"
                              componentData={tableInstitutionalData}
                              setComponentData={setTableInstitutionalData}
                              dropdown={props.dropdown}
                              claimsDropdown={ClaimTypeInsDropdown}
                              setDisErr={setDisErr}
                              setMajorEdit={props.setMajorEdit}
                              majorEdit={props.majorEdit}
                              seterrorMessages={props.seterrorMessages}
                              showForm={showInsForm}
                              setShowForm={setShowInsForm}
                              isEdit={isEdit}
                              setDispositionKeyDelete={setInstitutionalKeyDelete}
                            />
                          </div>
                          {/* Pharmacy Add */}
                          <div className="tab-holder mt-3">
                            <AddDispositionKeyForm
                              header="Pharmacy"
                              componentData={tablePharmacyData}
                              setComponentData={setTablePharmacyData}
                              dropdown={props.dropdown}
                              claimsDropdown={ClaimTypePharDropdown}
                              setDisErr={setDisErr}
                              seterrorMessages={props.seterrorMessages}
                              showForm={showPhrForm}
                              majorEdit={props.majorEdit}
                              setShowForm={setShowPhrForm}
                              isEdit={isEdit}
                              setMajorEdit={props.setMajorEdit}
                              setDispositionKeyDelete={setPharmacyKeyDelete}
                            />
                          </div>
                          {/* Dental Add */}
                          <div className="tab-holder mt-3">
                            <AddDispositionKeyForm
                              header="Dental"
                              componentData={tableDentalData}
                              setComponentData={setTableDentalData}
                              dropdown={props.dropdown}
                              claimsDropdown={ClaimTypeDenDropdown}
                              setDisErr={setDisErr}
                              seterrorMessages={props.seterrorMessages}
                              showForm={showDenForm}
                              majorEdit={props.majorEdit}
                              setMajorEdit={props.setMajorEdit}
                              setShowForm={setShowDenForm}
                              isEdit={isEdit}
                              setDispositionKeyDelete={setDentalKeyDelete}
                            />
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : null}
            </div>

          </ExpansionPanelDetails>
        </ExpansionPanel>
      </div>
    </>
  );
}
export default withRouter(DispositionDetails);
