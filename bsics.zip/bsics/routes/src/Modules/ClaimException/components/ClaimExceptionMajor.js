import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import DateFnsUtils from '@date-io/date-fns';
import Chip from '@material-ui/core/Chip';
import Avatar from '@material-ui/core/Avatar';
import {
	KeyboardDatePicker,
	MuiPickersUtilsProvider	
} from '@material-ui/pickers';
import dateFnsFormat from 'date-fns/format';
import * as ComponentMsg from '../../../SharedModules/Messages/ErrorMsgConstants';

export default function ClaimExceptionMajor(props) {
    const [charactersRem, setCharactersRem] = React.useState(320);
    
    const checkCharacterRem = (event) => {
		setCharactersRem(320 - event.target.value.length);
    }
    const formatDate = (dt) => {
		if(!dt){
			return ""; 
		 }
		dt = new Date(dt);
		if (dt.toString() == "Invalid Date") {
		  return dt;
		} else {
		  return dateFnsFormat(dt, "MM/dd/yyyy");
		}
	  };
    
	return (
		<form autoComplete="off">
            <div className="tab-body mt-2">
                <div className="form-wrapper">
                <div className="mui-custom-form input-md ">
                    <TextField
                        id="Exception-Code-Claim-Exception-Major"
                        label="Exception Code"
                        className="inline-lable-ttl"
                        disabled={props.type == "edit"}
                        value={props.values.exceptionCode}
                        inputProps={{ maxLength: 4 }}
                        onChange={props.handleChanges('exceptionCode')}
                        placeholder=""
                        helperText={props.errors.excCodeReqErr ? ComponentMsg.URC_ExeptionCode_Req_Error : 
                            props.errors.excCodeInvErr ? ComponentMsg.EXCEP_NUM : null}
                        InputLabelProps={{
                            shrink: true,
                        }}
                        required={props.type != "edit"}
                        error={props.errors.excCodeReqErr || props.errors.excCodeInvErr}
                        data-test='test_exc_code'
                    />
                </div>
                <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select">
                                <KeyboardDatePicker
                                    id="Begin-Date-Claim-Exception-Major"
                                    label="Begin Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true,
                                        required: true
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.beginDate ? props.values.beginDate : null}
                                    onChange={(dt) => props.handelDateChanges("beginDate", formatDate(dt))}
                                    helperText={props.errors.biginDateReqErr ? ComponentMsg.Begin_Date_Error :
                                        props.errors.beginDateInvalidErr ? ComponentMsg.Invalid_Begin_Date_Error :
                                        props.errors.beginDateGrtEndDateErr ? ComponentMsg.Bgndt_GT_Enddt_Err : null}
                                    error={props.errors.biginDateReqErr || props.errors.beginDateInvalidErr || props.errors.beginDateGrtEndDateErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                    data-test='test_begin_dt'
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                        <MuiPickersUtilsProvider utils={DateFnsUtils}>
                            <div className="mui-custom-form input-md with-select" >
                                <KeyboardDatePicker
                                    id="End-Date-Claim-Exception-Major"
                                    label="End Date"
                                    format="MM/dd/yyyy"
                                    InputLabelProps={{
                                        shrink: true,
                                        required: true
                                    }}
                                    placeholder="mm/dd/yyyy"
                                    value={props.values.endDate ? props.values.endDate : null}
                                    onChange={(dt) => props.handelDateChanges("endDate", formatDate(dt))}
                                    helperText={props.errors.endDateReqErr ? ComponentMsg.End_Date_Error : 
                                        props.errors.endDateInvalidErr ? ComponentMsg.The_Invalid_End_Date_Error : null}
                                    error={props.errors.endDateReqErr || props.errors.endDateInvalidErr}
                                    KeyboardButtonProps={{
                                        'aria-label': 'change date',
                                    }}
                                    data-test='test_end_dt'
                                />
                            </div>
                        </MuiPickersUtilsProvider>
                    </div>
                <div className="form-wrapper">
                    <div className="mui-custom-form input-md sm-field-lg">
                    <TextField
                        id="Short-Description-Claim-Exception-Major"
                        label="Short Description"
                        className="inline-lable-ttl"
                        value={props.values.shortDescription}
                        inputProps={{ maxLength: 30 }}
                        onChange={props.handleChanges('shortDescription')}
                        placeholder=""
                        helperText={props.errors.shortDescReqErr ? ComponentMsg.Short_Desc_Error : null}
                        InputLabelProps={{
                            shrink: true,
                            required: true
                        }}
                        error={props.errors.shortDescReqErr}
                        data-test='test_short_desc'
                    />
                </div>
                <div className="mui-custom-form input-md field-md md-field-lg sm-field-xl">
                    <TextField
                        id="Long-Description-Claim-Exception-Major"
                        label="Long Description"
                        className="inline-lable-ttl"
                        value={props.values.longDescription}
                        inputProps={{ maxLength: 320 }}
                        onChange={props.handleChanges('longDescription')}
                        placeholder=""
                        onKeyUp={checkCharacterRem}
                        helperText={props.errors.longDescReqErr ? ComponentMsg.Long_Desc_Error : null}
                        InputLabelProps={{
                            shrink: true,
                            required: true
                        }}
                        error={props.errors.longDescReqErr}
                        data-test='test_long_desc'
                    />
                    <div className="mt-1"><Chip avatar={<Avatar>{charactersRem}</Avatar>} label="Characters remaining" /></div>
                </div>
                </div>
            </div>
                <div className="clearfix" />
        </form>
	);
}
