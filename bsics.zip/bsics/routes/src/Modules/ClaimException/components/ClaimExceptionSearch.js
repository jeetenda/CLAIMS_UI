import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import BreadCrumbs from "../../../SharedModules/BreadCrumb/BreadCrumb";
import Spinner from '../../../SharedModules/Spinner/Spinner';
import ReactToPrint from 'react-to-print';
import { setPrintLayout} from '../../../SharedModules/Dropdowns/actions';
import Footer from '../../../SharedModules/Layout/footer';

function ClaimExceptionSearch(props) {
    const [spinnerLoader, setspinnerLoader] = useState(false);
    const printRef = useRef();
    const printLayout = useSelector(state => state.appDropDowns.printLayout);

    const dispatch = useDispatch();

  const addClaimException = () => {
    props.history.push({
      pathname: '/ClaimExceptionDetails'
    })
  }

  
  return (
    <div className="pos-relative">
        {spinnerLoader ? <Spinner /> : null}
      <div className="mb-2">
        <BreadCrumbs
            parent="Rules Management"
            child1="Search Claim Exception"
            path="ClaimException"
        />
      </div>

      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="tab-heading page-heading float-left">
            Search Claim Exception
          </h1>
          <div className="float-right th-btnGroup">
            <Button title="Add Claim Exception" variant="outlined" color="primary" className="btn btn-ic btn-add" onClick={() => addClaimException()}>
              Add
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))}
              }
              trigger={() => (<Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
              Print
            </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
              Help
            </Button>
        </div>
        </div>
      {/* <div className="clearfix"></div> */}
        <div className="tab-body mt-2">
        {/* Claim Search Form Here */}
        <div className="tab-body mt-2">
          {/* <ClaimExceptionSearchForm /> */}
        </div>
        <Footer print />
        </div>
      </div>
    </div>
  );
}
export default withRouter(ClaimExceptionSearch);
