import React, { useState, useEffect, useRef } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { Button } from 'react-bootstrap';
import { withRouter } from 'react-router';
import BreadCrumbs from "../../../../SharedModules/BreadCrumb/BreadCrumb";
import Spinner from '../../../../SharedModules/Spinner/Spinner';
import ReactToPrint from 'react-to-print';
import { setPrintLayout } from '../../../../SharedModules/Dropdowns/actions';
import Footer from '../../../../SharedModules/Layout/footer';
import ClaimExceptionSearchForm from "./ClaimExceptionSearchForm";
import ClaimExceptionSearchTable from "./ClaimExceptionSearchTable";
import { searchClaimExceptionAction,resetSearchClaimException, resetDetailsClaimException, getClaimExceptionDetails } from '../../action';
import * as ExceptionCodeConstants from '../../../../SharedModules/Messages/ErrorMsgConstants';

function ClaimExceptionSearch(props) {
  const onReset = () => dispatch(resetSearchClaimException());
  const onDetailsReset = () => dispatch(resetDetailsClaimException());
  const [spinnerLoader, setspinnerLoader] = useState(false);
  const [showTable, setShowTable] = useState(false);
  const printRef = useRef();
  const printLayout = useSelector(state => state.appDropDowns.printLayout);
  const resetClaimException = () => dispatch(resetSearchClaimException());
  const [redirect, setRedirect] = useState(false);

  const [values, setValues] = useState({
    "claimExceptionCode": "",
    "description": "",
    "lobCode": "",
    "descriptionStartsOrContains": "",
    "claimExceptionCodeStartsWith": false,
    "sortColumn": "",
    "isAscending": true
  });

  const [showNoRecords, setShowNoRecords] = useState(false);
  const [errorMessages, seterrorMessages] = React.useState([]);
  const [redirectCheck, setRedirectCheck] = useState(false);
  const [payloadCheck, setPayloadCheck] = useState(false);
  const [urlSearch, setUrlSearch] = useState('');

  const payload = useSelector(state => { return state.claimException.payload })
  const exceptionSearchTime = useSelector(state => { return state.claimException.exceptionSearchTime })
  const claimExceptionData = useSelector(state => { return state.claimException.claimExceptionData })


  const codeExceptionDetails = useSelector(state => state.claimException.codeExceptionDetails);
  const codeExceptionDetailsTime = useSelector(state => state.claimException.codeExceptionDetailsTime);

  const dispatch = useDispatch();

  const addClaimException = () => {
    props.history.push({
      pathname: '/ClaimExceptionDetails'
    })
  }

  useEffect(() => {
    resetClaimException();
   // dispatch(searchClaimExceptionAction(values));
    setPayloadCheck(true);
    if (props.location.state && props.location.state.type == "Delete_Success") {
      seterrorMessages(['System successfully deleted the information.'])
    }

    onDetailsReset();
    if(props&&props.location&&props.location.search){
      let query = new URLSearchParams(props.location.search);
      let vals = query.get('exceptioncode');
      if (vals) {
        setValues({ ...values, claimExceptionCode: vals });
        setUrlSearch(new Date());
      }
   }
  }, [])

  useEffect(() => {if (urlSearch != '') searchCheck()},[urlSearch]);

  useEffect(() => {
    if (payload  && payload.searchResults.length && payloadCheck) {
      if(payload.searchResults.length >1)
      {
        setspinnerLoader(false);
        setShowTable(true);
        setRedirectCheck(true);
        setShowNoRecords(false);
      }
      if(payload.searchResults.length===1)
      {
        const exceptionCode = {exceptionCode: payload.searchResults[0].exceptionCode}
        //setspinnerLoader(false);
        setShowTable(false);
        setRedirectCheck(true);
        setShowNoRecords(false);
        dispatch(getClaimExceptionDetails(exceptionCode))
      }
    }
  
  }, [payload]);

  useEffect(() => {
    if (claimExceptionData && claimExceptionData.data==null && exceptionSearchTime) {
      setspinnerLoader(false);
      setShowNoRecords(true);
    }
    
  }, [exceptionSearchTime]);


  useEffect(() => {    
    if(codeExceptionDetails != null && redirectCheck){
      if (codeExceptionDetails.errorCode === null || codeExceptionDetails.errorCode === undefined || codeExceptionDetails.isRecordExist) {
        props.history.push({
          pathname: '/ClaimExceptionDetails',
          tab: props.location?.hash?.substring(1)
        });
      } 
    }
  },[codeExceptionDetailsTime]);

  // reset table
  const resetTable = () => {
    seterrorMessages([]);
    setShowNoRecords(false)
   const resetData = {        
    "claimExceptionCode":"",
    "description":"",
    "lobCode":"",
    "descriptionStartsOrContains":"",
    "claimExceptionCodeStartsWith":false,
    "sortColumn":"",
    "isAscending":true      
  }
  onReset();
  setValues(resetData);
   // return dispatch(searchClaimExceptionAction(resetData))

    //setShowTable(false);

  };


  const handleChanges = name => (event) => {
    let stateValue = event.target.value

    if(name==="claimExceptionCodeStartsWith")
    {
      if(stateValue ==="true"){
        stateValue = true
      }
      else{
        stateValue = false
      }
    }

    setValues({ ...values, [name]: stateValue });
  };

  const searchCheck = () => {

    const errorMessagesArray = []
    if (values.claimExceptionCodeStartsWith && values.claimExceptionCode.length < 2) {
      //showproceedureCodeError = true;
      errorMessagesArray.push(ExceptionCodeConstants.Starts_With_Contains_Error);
    }
    if (values.descriptionStartsOrContains && values.description.length < 2) {
      //showdescriptionError = true;
      errorMessagesArray.push(ExceptionCodeConstants.Starts_With_Contains_Error);
    }


    if (!errorMessagesArray.length) {
      seterrorMessages([]);
      setspinnerLoader(true)
      return dispatch(searchClaimExceptionAction(values)) 
    }

    else {
      seterrorMessages(errorMessagesArray);
      setShowTable(false);
    }
    
  }

  return (
    <div className="pos-relative">
      {spinnerLoader && <Spinner />}

      {errorMessages.length > 0 && (
        <div className="alert alert-danger custom-alert hide-on-print" role="alert">
          {errorMessages.map(message => <li>{message}</li>)}
        </div>
      )
      }

      {showNoRecords &&   (
        <div className="alert alert-danger custom-alert hide-on-print" role="alert">
          <li>{ExceptionCodeConstants.NO_RECORDS_WITHSEARCH}</li>
        </div>
      )
      }

      <div className="mb-2">
        <BreadCrumbs
          parent="Rules Management"
          child1="Search Claim Exception"
          path="ClaimException"
        />
      </div>

      <div className="tabs-container" ref={printRef}>
        <div className="tab-header">
          <h1 className="tab-heading page-heading float-left">
            Search Claim Exception
          </h1>
          <div className="float-right th-btnGroup">
            <Button title="Add Claim Exception" variant="outlined" color="primary" className="btn btn-ic btn-add" onClick={() => addClaimException()}>
              Add
            </Button>
            <ReactToPrint
              onBeforeGetContent={() => {
                dispatch(setPrintLayout(true));
                setspinnerLoader(true);
                return new Promise((resolve) => setTimeout(() => resolve(), 100));
              }}
              onAfterPrint={() => {
                setspinnerLoader(false);
                dispatch(setPrintLayout(false))
              }
              }
              trigger={() => (
                <Button title="Print" variant="outlined" color="primary" className="btn btn-ic btn-print">
                  Print
                </Button>)}
              content={() => printRef.current}
            />
            <Button title="Help" variant="outlined" color="primary" className="btn btn-ic btn-help">
              Help
            </Button>
          </div>
        </div>

        {/* Search Claim Exception form start */}
        <div className="tab-body mt-2">
          <ClaimExceptionSearchForm handleChanges={handleChanges} values={values} searchCheck={searchCheck} resetTable={resetTable} />
          
          {
            showTable && payload && payload.searchResults.length > 0 ? (
              <div className="tab-holder mr-3 ml-3 pb-2">
                <div class="fw-600 mb-2">Search Results</div>
                    <ClaimExceptionSearchTable
                      print
                      tableData={payload.searchResults}
                      // tableErrorFunction={tableErrorFunction}
                      setspinnerLoader={setspinnerLoader}
                      setRedirect={setRedirect}
                      redirect={redirect}
                    />
                  
                </div>
            ) : null
          }
        </div>
        {/* Search Claim Exception form end */}

        {/* <div className="clearfix"></div> */}
        <div className="tab-body mt-2">
         
          <Footer print />
        </div>
      </div>
    </div>
  );
}
export default withRouter(ClaimExceptionSearch);
