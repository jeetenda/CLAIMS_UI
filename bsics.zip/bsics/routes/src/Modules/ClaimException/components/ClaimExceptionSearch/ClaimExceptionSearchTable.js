import React, { useEffect } from 'react';
import { withRouter } from 'react-router';
// eslint-disable-next-line no-unused-vars
import TableComponent from '../../../../SharedModules/Table/Table';
import { useDispatch, useSelector } from 'react-redux';
import { getClaimExceptionDetails } from '../../action';


const headCells = [
  {
    id: 'exceptionCode', numeric: false, disablePadding: true, label: 'Exception', enableHyperLink: true, fontSize: 12, width: '20%'
  },
  {
    id: 'longDescription', numeric: false, disablePadding: false, label: 'Description', enableHyperLink: false, fontSize: 12
  },

];

function ClaimExceptionSearchTable(props) {
  const errorMessagesArray = [];
  const [showTable, setShowTable] = React.useState(false);

  const dispatch = useDispatch();
  const onSearchView = searchvalues => dispatch(getClaimExceptionDetails(searchvalues));
  const codeExceptionDetails = useSelector(state => state.claimException.codeExceptionDetails);
  const codeExceptionDetailsTime = useSelector(state => state.claimException.codeExceptionDetailsTime);
  

  
  useEffect(() => {
    if (props.tableData && props.tableData.length > 0) {
      setShowTable(true);
    }
  }, [props.tableData]);

  useEffect(() => {
    if(codeExceptionDetails != null && props.redirect ){
      props.setRedirect(false);
      props.setspinnerLoader(false);
      if (codeExceptionDetails.errorCode === null || codeExceptionDetails.errorCode === undefined || codeExceptionDetails.isRecordExist) {
        props.history.push({
          pathname: '/ClaimExceptionDetails',
        });
      } else {
        // errorMessagesArray.push(ProcedureCodeConstants.ERROR_OCCURED_DURING_TRANSACTION);
        // props.tableErrorFunction(errorMessagesArray)
      }
    }
  },[codeExceptionDetailsTime]);
  
  const editRow = row => (event) => {
     onSearchView({ exceptionCode: row.exceptionCode });
    props.setspinnerLoader(true);
    props.setRedirect(true);
  };
  const tableComp = <TableComponent print={props.print} headCells={headCells}  tableData={props.tableData ? props.tableData : []} onTableRowClick={editRow} defaultSortColumn="exceptionCode" />;
  return (
    showTable ? tableComp : null

  );
}
export default withRouter(ClaimExceptionSearchTable);
