import React from 'react';
import TextField from '@material-ui/core/TextField';
import MenuItem from '@material-ui/core/MenuItem';
import { Button } from 'react-bootstrap';
//import * as ProcedureCodeConstants from '../../../SharedModules/Messages/ErrorMsgConstants';
import Checkbox from '@material-ui/core/Checkbox';
import Radio from '@material-ui/core/Radio';
import RadioGroup from '@material-ui/core/RadioGroup';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import PropTypes from "prop-types"

function ClaimExceptionSearchForm(props) {
	return (
		<form autoComplete="off">

			<div className="form-wrapper">
				<div className="mui-custom-form input-md">
					<TextField
						id="standard-exception-code"
						label="Exception Code"
						value={props.values.claimExceptionCode}
						inputProps={{ maxLength: 4 }}
						onChange={props.handleChanges('claimExceptionCode')}
						placeholder=""
						//helperText={props.errors.showproceedureCodeError ? ProcedureCodeConstants.Starts_With_Contains_Error : null}
						InputLabelProps={{
							shrink: true,
						}}
						//error={props.errors.showproceedureCodeError ? ProcedureCodeConstants.Starts_With_Contains_Error : null}
					/>
					{/* <div className="sub-radio">
						<Checkbox
							value={true}
							color="primary"
							inputProps={{ 'aria-label': 'secondary checkbox' }}
							id="starts-with-exception-code"
							checked={props.values.claimExceptionCodeStartsWith === true}
							onChange={props.handleChanges('claimExceptionCodeStartsWith')}
						/>
						<label className="text-black" htmlFor="StartsWithCheckbox">Starts With</label>
					</div> */}
					<div className="sub-radio">
					<FormControlLabel
					control={
						<Checkbox
						value={true}
						color="primary"
						inputProps={{ 'aria-label': 'secondary checkbox' }}
						id="starts-with-exception-code"
						checked={props.values.claimExceptionCodeStartsWith === true}
						onChange={props.handleChanges('claimExceptionCodeStartsWith')}
						/>
					}
					label="Starts With"
					/>
          </div>
				</div>
				<div className="mui-custom-form input-md field-md">
					<TextField
						id="standard-description"
						label="Description"
						value={props.values.description}
						inputProps={{ maxLength: 30 }}
						onChange={props.handleChanges('description')}
						placeholder=""
						//helperText={props.errors.showdescriptionError ? ProcedureCodeConstants.Starts_With_Contains_Error : null}
						InputLabelProps={{
							shrink: true,
						}}
					//error={props.errors.showdescriptionError ? ProcedureCodeConstants.Starts_With_Contains_Error : null}
					/>
					<div className="sub-radio mt-0">
						<RadioGroup
							row
							aria-label="Procedure Description"
							onChange={props.handleChanges('descriptionStartsOrContains')}
						>
							<FormControlLabel
								value="0"
								id="starts-with-description"
								control={<Radio color="primary" />}
								label="Starts With"
								checked={props.values.descriptionStartsOrContains === '0'}
							/>
							<FormControlLabel
								value="1"
								id="contains-description"
								control={<Radio color="primary" />}
								label="Contains"
								checked={props.values.descriptionStartsOrContains === '1'}
							/>
						</RadioGroup>
					</div>
				</div>
			</div>
			<div className="float-right th-btnGroup mr-3 mb-3">
				<Button
					title="Search"
					variant="outlined"
					color="primary"
					className="btn btn-ic btn-search"
					onClick={props.searchCheck}
					disabled={props.privileges && !props.privileges.search ? 'disabled' : ''}
					data-test="btn_search"
				>
					{' '}
					Search
          {' '}

				</Button>
				<Button
					title="Reset"
					variant="outlined"
					color="primary"
					className="btn btn-ic btn-reset"
					onClick={props.resetTable}
					data-test="btn_reset"
				>
					{' '}
					Reset
          {' '}

				</Button>
			</div>
			<div className="clearfix"></div>

		</form>
	);
}

ClaimExceptionSearchForm.propTypes = {
	values: PropTypes.shape({
		claimExceptionCode: PropTypes.string,
		claimExceptionCodeStartsWith: PropTypes.bool,
		description: PropTypes.string,
		descriptionStartsOrContains: PropTypes.string,
		isAscending: PropTypes.bool,
		lobCode: PropTypes.string,
		sortColumn: PropTypes.string
	})
}


export default ClaimExceptionSearchForm
