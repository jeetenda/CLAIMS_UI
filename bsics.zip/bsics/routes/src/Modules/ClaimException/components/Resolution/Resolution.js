import React, { useState, useEffect } from 'react';
import TableComponent from '../../../../SharedModules/Table/Table';
import Checkbox from '@material-ui/core/Checkbox';
import { Button } from 'react-bootstrap';
import TextField from "@material-ui/core/TextField";
import MenuItem from "@material-ui/core/MenuItem";
import FormControlLabel from "@material-ui/core/FormControlLabel";
import Radio from "@material-ui/core/Radio";
import RadioGroup from "@material-ui/core/RadioGroup";
import * as ErrorConst from '../../../../SharedModules/Messages/ErrorMsgConstants';
import TextareaAutosize from '@material-ui/core/TextareaAutosize';

const headCells = [
    {
        id: 'mediaTypeDesc', numeric: false, disablePadding: true, label: 'Text', enableHyperLink: true, fontSize: 12, width: '50%'
    },
    {
        id: 'voidDate', numeric: false, disablePadding: true, label: 'Void Date', enableHyperLink: false, fontSize: 12, width: '50%'
    }
];

const Resolution = React.forwardRef((props, ref) => {    
    const [tableData, setTableData] = useState([]);
    const [voidCheckYesNo, setVoidCheckYesNo] = useState("false");
    const [disableVoidYesNo, setDisableVoidYesNo] = useState(false);
    const [voidCheck, setVoidCheck] = useState(false);
    const [{ mediaSrcTo, mediaSrcFrom , mediaSrcMT}, setErrors] = useState(false);
    const [disableMediaSource, setDisableMediaSource] = useState(false);
    const [mediaTypeSelect, setMediaTypeSelect] = useState("none");
    const [mediaSource, setMediaSource] = useState("-1");
    const [copyMediaSource, setCopyMediaSource] = useState("-1");
    const [resolutionText, setResolutionText] = useState("");
    const [mediaTypeDrpDwn, setMediaTypeDrpDwn] = useState(null);
    const [mediaTypeCopyDrpDwn, setMediaTypeCopyDrpDwn] = useState(null);
    const [editMediaSrcLeft,setEditMediaSrcLeft] = useState([]);

    const handleVoidCheck = (e) => {
        setVoidCheck(!voidCheck);
        mapPEVoid(!voidCheck);
    };
    const editRow = row => (e) => {
        setCopyMediaSource(row.mediaType);
        setResolutionText(row.resolutionText);
        if (row.voidDate) {
            setVoidCheckYesNo("true");
            setDisableVoidYesNo(true);
        } else {
            setVoidCheckYesNo("false");
            setDisableVoidYesNo(false);
        }
    };   
    const mapPEVoid = (isChecked) => {
        if (props.data && props.data.length) {
            if (isChecked) {
                setTableData(
                    props.data                        
                );
            } else {
                setTableData(
                    props.data
                        .filter(a => !a.voidDate)                        
                );
            }
        } else {
            setTableData([]);
        }
    };
    const handleMediaTypeChange = (e) => {
        setMediaTypeSelect(e.target.value);
        setDisableMediaSource(e.target.value == "all" ? true : false);
    };
    const createDropDown = () => {
        if(props.dropdown && props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD'] && props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD'].length){
            if(props.isEditOp){
                let m = props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD']
                .filter(each => props.data.findIndex((a)=>each.code==a.mediaType)==-1);
                setEditMediaSrcLeft(m);
                setMediaTypeDrpDwn(
                m.map(each => (
                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                )));
                // setMediaTypeCopyDrpDwn(props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD']
                // .filter(each => props.data.findIndex((a)=>each.code==a.mediaType)>-1)
                // .map(each => (
                //     <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                // )));
                const copyTextMediaType = props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD']
                .filter(each => props.data.findIndex((a)=>each.code==a.mediaType))

                if(copyTextMediaType >-1)
                {
                    setMediaTypeCopyDrpDwn(copyTextMediaType.map(each => (
                        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                    )))
                  
                }

                else
                {
                    setMediaTypeCopyDrpDwn(props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => (
                        <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                    )))
                    
                }

            }else{
                setMediaTypeDrpDwn(props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => (
                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                )));

                setMediaTypeCopyDrpDwn(props.dropdown['ClaimException#C_BATCH_MEDIA_SRC_CD'].map(each => (
                    <MenuItem selected key={each.code} value={each.code}>{each.description}</MenuItem>
                )));
            }           
        }
    };
    useEffect(() => {
        mapPEVoid(false); 
        setVoidCheck(false);      
        setMediaSource("-1");
        setCopyMediaSource("-1");
        setMediaTypeSelect("none");  
        setVoidCheckYesNo("false");    
        setDisableVoidYesNo(false);  
        setDisableMediaSource(false);
        setResolutionText("");
        createDropDown();
        setErrors({});
    }, [props.data]);
    useEffect(() => {
        createDropDown();
    }, [props.dropdown]);
    React.useImperativeHandle(ref, () => ({ getState: () => { return { mediaTypeSelect: mediaTypeSelect, mediaType: mediaSource, resolutionText: resolutionText, voidCheckYesNo: voidCheckYesNo,editMediaSrcLeft: editMediaSrcLeft } } }));
    const copyMediaType = () => {
      if(props.isEditOp){
        let errors = {}, errorMsg = [];
        props.seterrorMessages(errorMsg);
        setErrors(errors);
        if(props.isEditOp){
            if(mediaTypeSelect=="none"){
                errorMsg.push(ErrorConst.CLAIM_EXP_RES_MT);
                errors["mediaSrcMT"] = true;
            } else if (mediaTypeSelect == "all") {
                if (copyMediaSource == "-1") {
                    errorMsg.push(ErrorConst.CLAIM_EXP_RES_MT_FROM);
                    errors["mediaSrcFrom"] = true;
            }
            } else {
            if(mediaSource == "-1"){
                errorMsg.push(ErrorConst.CLAIM_EXP_RES_MT_TO);
                    errors["mediaSrcTo"] = true;
            }
            if(copyMediaSource == "-1"){
                errorMsg.push(ErrorConst.CLAIM_EXP_RES_MT_FROM);
                    errors["mediaSrcFrom"] = true;
                }
            }
            if(errorMsg.length){
                setErrors(errors);
                props.seterrorMessages(errorMsg);
                return false;
            }
            setResolutionText(props.data.find(e => e.mediaType==copyMediaSource).resolutionText);
        }
     }        
    };
    return (
        <div className="tabs-container mt-4 mb-4" >
            <div className="tab-body-bordered px-3">
                <div className="tabs-container set-form-wrapper mt-2">
                    <div className="tab-header">
                        <h2 className="tab-heading float-left txt-trans-none">
                            Resolution Text applies to all Line of Business</h2>
                    </div>
                    <div className="form-wrapper frm-resolution">
                        {props.isEditOp ?
                            <div className="mui-custom-form with-select input-md rmv-ml">
                                <label className="MuiFormLabel-root MuiInputLabel-shrink"> Void </label>
                                <div className="sub-radio mt-0">
                                    <RadioGroup
                                        row
                                        aria-label="resolutionTabVoidRadioId"
                                        name="resolutionTabVoidRadioId"
                                        value={voidCheckYesNo}
                                        onChange={(e)=>{setVoidCheckYesNo(e.target.value);}}
                                    >
                                        <FormControlLabel
                                            disabled={disableVoidYesNo}
                                            value="true"
                                            control={<Radio color="primary" inputProps={{ 'aria-label': 'Yes', 'id': 'resolutionTabVoidYesId' }}/>}
                                            label="Yes"
                                        />
                                        <FormControlLabel
                                            disabled={disableVoidYesNo}
                                            value="false"
                                            control={<Radio color="primary" inputProps={{ 'aria-label': 'No', 'id': 'resolutionTabVoidNoId' }}/>}
                                            label="No"
                                        />
                                    </RadioGroup>
                                </div>
                            </div>
                            : null}
                        <div className="mui-custom-form with-select input-md">
                            <label className="MuiFormLabel-root MuiInputLabel-shrink"> Media Type </label>
                            <div className="sub-radio mt-0">
                                <RadioGroup
                                    row
                                    aria-label="resolutionMediaType"
                                    name="resolutionMediaType"
                                    value={mediaTypeSelect}
                                    onChange={handleMediaTypeChange}
                                >
                                    <FormControlLabel
                                        disabled={false}
                                        value="all"
                                        control={<Radio color="primary" inputProps={{ 'aria-label': 'All', 'id': 'resolutionMediaTypeAll' }} />}
                                        label="All"
                                    />
                                    <FormControlLabel
                                        disabled={false}
                                        value="specific"
                                        control={<Radio color="primary" inputProps={{ 'aria-label': 'Specific', 'id': 'resolutionMediaTypeSpecific' }} />}
                                        label="Specific"
                                    />
                                </RadioGroup>
                            </div>
                            <TextField
                                id="bc-media-sorce"
                                select
                                required
                                disabled={disableMediaSource}
                                value={mediaSource}
                                inputProps={{ maxLength: 2 }}
                                onChange={(e) => { setMediaSource(e.target.value); }}
                                placeholder="Please Select One"
                                helperText={mediaSrcMT ? ErrorConst.CLAIM_EXP_RES_MT : mediaSrcTo ? ErrorConst.CLAIM_EXP_RES_MT_TO : null}
                                error={mediaSrcMT || mediaSrcTo}
                                InputLabelProps={{
                                    shrink: true
                                }}
                            >
                                <MenuItem selected key="Please Select One" value="-1">Please Select One</MenuItem>
                                {mediaTypeDrpDwn}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md  sm-field-md">
                            <label for="bc-media-sorce" className="MuiFormLabel-root MuiInputLabel-shrink brk-label">Copy Text From Media Type</label>

                            <TextField
                                id="bc-media-sorce"
                                select
                                className="mt-4"
                                required
                                disabled={false}
                                value={copyMediaSource}
                                inputProps={{ maxLength: 2 }}
                                onChange={(e)=>{setCopyMediaSource(e.target.value);}}
                                placeholder="Please Select One"
                                helperText={ mediaSrcFrom ? ErrorConst.CLAIM_EXP_RES_MT_FROM : null}
                                error={mediaSrcFrom}
                                InputLabelProps={{
                                    shrink: true
                                }}
                            >
                                <MenuItem selected key="Please Select One Copy" value="-1">Please Select One</MenuItem>
                                {mediaTypeCopyDrpDwn}
                            </TextField>
                        </div>
                        <div className="mui-custom-form with-select input-md align-bot">
                            <Button title="Copy" variant="outlined" color="primary" className="btn btn-ic btn-copy mb-1" onClick={copyMediaType}>
                                Copy
                            </Button>
                        </div>
                    </div>
                </div>
                {props.isEditOp ?
                    <div className="tabs-container mt-1">
                        <div className="tab-header">
                            <h2 className="tab-heading float-left">
                                Text Exists for Media Types</h2>
                        </div>
                        <div className="mui-custom-form m-1">
                            <div className="sub-radio m-0">
                                <label className="MuiFormControlLabel-root inline-radio-label float-left" for="resolutionTabShowVoidChk">
                                    <Checkbox
                                        checked={voidCheck}
                                        type="checkbox"
                                        id="resolutionTabShowVoidChk"
                                        onChange={handleVoidCheck}
                                    />
                                    <span className="MuiFormControlLabel-label">Show Voids</span>
                                </label>
                                <div className="clearfix" />
                            </div>
                        </div>
                        <TableComponent headCells={headCells} tableData={tableData} onTableRowClick={editRow} defaultSortColumn="mediaTypeDesc" />
                    </div>
                    : null}
                <div className="tabs-container mt-2">
                    <div className="tab-header">
                        <h2 className="tab-heading float-left">
                            Resolution Text</h2>
                    </div>
                    <TextareaAutosize
                        id="response-text"
                        rowsMin={10}
                        rowsMax={20}
                        value={resolutionText?resolutionText:""}
                        onChange={(e) => { setResolutionText(e.target.value); }}
                        placeholder=""
                        style={{ width: "100%", padding: "7px", marginBottom: "15px" }}
                    />
                </div>
            </div>
        </div>
    );
});
export default Resolution;
