import React from "react";
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import thunk from 'redux-thunk';
import checkPropTypes from "check-prop-types";
import SuspendedClaimRouting from "../components/Main/SuspendedClaimRouting";

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

describe('Rendering Suspended Claim Routing Component', () => {

    let store, wrapper

    // intitial state for component
    const initialState = {}

    // intitial props for component
    const componentProps = {
        handleChanges: jest.fn(),
        values: {
            "documentType": "-1",
            "claimType": "-1",
            "mediaType": "-1",
            "userID": "-1",
            "locationCode": "-1"
        },
        errors:
        {
            docReqErr: false,
            claimReqErr: false,
            mediaReqErr: false,
            locReqErr: false,
            duplicateErr: false
        },
        showForm: true

    }

    //beforeEach Run before testcases is run  

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><SuspendedClaimRouting  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive()
    })

    it('should render the delete button without error', () => {
        const component = wrapper.find("[data-test='test_del_btn']");
        expect(component.length).toBe(1)
    })
    it('should render the add button without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        expect(component.length).toBe(1)
    })

    // simulate click
    it('should render the document type without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_doc']")
        expect(component2.length).toBe(1);
    })
    it('should render the media type without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_mediaType']")
        expect(component2.length).toBe(1);
    })
    it('should render the claim type without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_claimType']")
        expect(component2.length).toBe(1);
    })
    it('should render the userid without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_userId']")
        expect(component2.length).toBe(1);
    })
    it('should render the loc without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_loc']")
        expect(component2.length).toBe(1);
    })
    it('should render the add/update button without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_addUpd_btn']")
        expect(component2.length).toBe(1);
    })
    it('should render the reset without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_reset']")
        expect(component2.length).toBe(1);
    })
    it('should render the cancel without error', () => {
        const component = wrapper.find("[data-test='test_add_btn']");
        (component).simulate("click");
        const component2 = wrapper.find("[data-test='test_cancel']")
        expect(component2.length).toBe(1);
    })
    
})

describe('check prop types for suspended claim routing form', () => {

    it('should check prop types without error', () => {

        const expectedProps = {
            values: {
                "documentType": "-1",
                "claimType": "-1",
                "mediaType": "-1",
                "userID": "-1",
                "locationCode": "-1"
            }
        }
        const propErr = checkPropTypes(SuspendedClaimRouting.propTypes, expectedProps, 'props', SuspendedClaimRouting.name)
        expect(propErr).toBeUndefined()
    })

})


