import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import ResponseEdit from "../components/Response/ResponseEdit";
const middlewares = [thunk] 
describe('ClaimException', () => {
  
  const mockStore = configureStore(middlewares)
  let store, wrapper
 
  // intitial state for component
  const initialState = {}
 
  // intitial props for component
  const componentProps = {
    handleChangesResponse: jest.fn(),
    dropdowns: null,
    isEditOp:true,
    data:null,
    values:null,
    seterrorMessages:jest.fn()
  }
 
  //beforeEach Run before testcases is run  
 
  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><ResponseEdit  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()

    //console.log(wrapper.debug())
  })
  it('Response Edit component should render without error', () => {
    let component = wrapper.find('#response-media-sorce')
    expect(component.length).toBe(1);      
  });

  it('Response Edit component should should have media sorce', () => {
    let component = wrapper.find('#response-media-sorce')
    expect(component.length).toBe(1);      
  });

  it('Response Edit component should should have Copy Text From Media Type', () => {
    let component = wrapper.find('#response-media-copy')
    expect(component.length).toBe(1);      
  });

  it('Response Edit component should should have response text', () => {
    let component = wrapper.find('#response-response-text')
    expect(component.length).toBe(1);      
  });

  it('Response Edit check handleChangesResponse function', () => {
    let input = wrapper.find('#response-media-sorce');       
    input.simulate('focus');
    input.simulate('change', { target: { value: 'Changed' } }); 
    expect(componentProps.handleChangesResponse).toHaveBeenCalled();    
  });
 
 
  })
