import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'


import ResponseAdd from "../components/Resolution/Resolution";

const middlewares = [thunk]
 
 
describe('ClaimException', () => {
  
  const mockStore = configureStore(middlewares)
  let store, wrapper
 
  // intitial state for component
  const initialState = {}
 
  // intitial props for component
  const componentProps = {
    handleChangesResponse: jest.fn(),
    dropdowns: null,
    isEditOp:false,
    data:null
  }
 
  //beforeEach Run before testcases is run  
 
  beforeEach(() => {
    store = mockStore(initialState)
    wrapper = shallow(<Provider store={store}><Router><ResponseAdd  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
  })
  it('Resolution component source should render without error', () => {
    let component = wrapper.find('#response-text')
    expect(component.length).toBe(1);     
  });

  it('Resolution component should have media sorce', () => {
    let component = wrapper.find('#response-text')
    expect(component.length).toBe(1);      
  });

  it('Resolution component should should have resolution void check', () => {
    let component = wrapper.find('#response-text')
    expect(component.length).toBe(1);  
  });

  it('Resolution component should should have response text', () => {
    let component = wrapper.find('#response-text')
    expect(component.length).toBe(1);      
  });

  it('Resolution component check onChange function', () => {
    let component = wrapper.find('#response-text')
    expect(component.length).toBe(1);   
  });
 
 
  })
