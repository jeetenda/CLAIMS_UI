import React from "react"
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store'
import { Provider } from 'react-redux'
import { BrowserRouter as Router } from 'react-router-dom'
import thunk from 'redux-thunk'
import "babel-polyfill";
import DispositionDetails from "../components/Disposition/DispositionDetails";
import AddDispositionKeyForm from '../components/Disposition/AddDispositionKeyForm';
import AddDispositionCommonForm from '../components/Disposition/AddDispositionCommonForm';

const middlewares = [thunk]

/**
   * describe() is used to handle rendering Exception Search Component.
   * get element selector from componen using expect method of jest
   * @Date 10-Sep-2020
   * @author Divya Chauhan
*/

describe('Claim Type Disposition Tab Component', () => {

    const mockStore = configureStore(middlewares)
    let store, wrapper, dispKeyWrapper, addDispKeyWrapper
    // intitial state for component
    const initialState = {}

    const compProps = {
        values: {
            claimType: '-1',
            disposition: 'Z',
            forcePay: '0',
            forceDeny: '0'
        },
        header: "Financial",
        majorEdit: false,
        showClaimTypeErr: false,
        showDispositionErr: false,
        showPayErr: false,
        showDenyErr: false,
        showClaimDupErr: false,
        handelKeyChange : jest.fn()
    }

    //beforeEach Run before testcases is run  

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><DispositionDetails /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive()
        dispKeyWrapper = shallow(<Provider store={store}><Router><AddDispositionKeyForm /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive()
        addDispKeyWrapper = shallow(<Provider store={store}><Router><AddDispositionCommonForm {...compProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive().dive().dive()
    })

    describe('Claim Type Disposition Tab for Add/Edit test cases', function () {

        it('should render Disposition Details Component for Add/Edit  without error', () => {
            const component = wrapper.find("[data-test='disp-details-component']")
            expect(component.length).toBe(1);
        })

        it('should render plus button without error', () => {
            const component = wrapper.find("[data-test='test-btn-plus']").at(0)
            expect(component.length).toBeLessThanOrEqual(1);
        })

        it('should render trash button without error', () => {
            const component = wrapper.find("[data-test='test-btn-trash']").at(0)
            expect(component.length).toBeLessThanOrEqual(1);
        })

        it('should render Disposition table without error', () => {
            const component = wrapper.find("[data-test='disp-table']").at(0)
            expect(component.length).toBeLessThanOrEqual(1);
        })

        it('should render Document Type Selection without error', () => {
            const component = wrapper.find("[data-test='document-type']").at(0)
            expect(component.length).toBeLessThanOrEqual(1);
        })

        it('should render Media Type Selection without error', () => {
            const component = wrapper.find("[data-test='media-type']").at(0)
            expect(component.length).toBeLessThanOrEqual(1);
        })

        it('should render Disposition Key Form Component for Add/Edit  without error', () => {
            const component = dispKeyWrapper.find("[data-test='disp-key-form-component']")
            expect(component.length).toBe(1);
        })

        it('should render Disposition Key Form Add button for Add/Edit  without error', () => {
            const component = dispKeyWrapper.find("[data-test='disp-key-add-btn']")
            expect(component.length).toBe(1);
        })

        it('should render Disposition Key Form Trash button for Add/Edit  without error', () => {
            const component = dispKeyWrapper.find("[data-test='disp-key-trash-btn']")
            expect(component.length).toBe(1);
        })

        it('should render Disposition Key Form Table for Add/Edit  without error', () => {
            const component = dispKeyWrapper.find("[data-test='disp-key-table']")
            expect(component.length).toBe(1);
        })

        it('should render Disposition Key Add Details Component for Add/Edit  without error', () => {
            const component = addDispKeyWrapper.find("[data-test='disp-key-add-component']")
            expect(component.length).toBe(1);
        })

        it('should render Claim Type for Add/Edit  without error', () => {
            const component = addDispKeyWrapper.find("[data-test='claim-type']")
            expect(component.length).toBe(1);
        })

        it('should render Disposition for Add/Edit  without error', () => {
            const component = addDispKeyWrapper.find("[data-test='disposition']")
            expect(component.length).toBe(1);
        })

        it('should render Force Pay for Add/Edit  without error', () => {
            const component = addDispKeyWrapper.find("[data-test='force-pay']")
            expect(component.length).toBe(1);
        })

        it('should render Force Deny for Add/Edit  without error', () => {
            const component = addDispKeyWrapper.find("[data-test='force-deny']")
            expect(component.length).toBe(1);
        })
    })
})