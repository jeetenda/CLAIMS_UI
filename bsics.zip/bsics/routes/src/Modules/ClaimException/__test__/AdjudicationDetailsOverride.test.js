import React from "react";
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import thunk from 'redux-thunk';
import checkPropTypes from "check-prop-types";
import AdjudicationDetailsOverride from "../components/Main/AdjudicationDetailsOverride";

const middlewares = [thunk];
const mockStore = configureStore(middlewares);

describe('Rendering Adjudication Details Override Component', () => {

    let store, wrapper

    // intitial state for component
    const initialState = {}

    // intitial props for component
    const componentProps = {
        handleChanges: jest.fn(),
        values: {
            "adjustmentReasonCode1": "",
        "adjustmentReasonCode2": "",
        "adjustmentReasonCode3": "",
        "remarkCode1": "",
        "remarkCode2": "",
        "remarkCode3": "",
        "eobCode": "",
        "locationCode":"",
        },
        errors:
        {
            docReqErr: false,
            claimReqErr: false,
            mediaReqErr: false,
            locReqErr: false,
            duplicateErr: false
        }

    }

    //beforeEach Run before testcases is run  

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><AdjudicationDetailsOverride  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
    })

    

    it('should render the adjustment reason without error', () => {
        const component = wrapper.find("[data-test='test_adj_rsn']")
        expect(component.length).toBe(1);
    })
    it('should render the adjustment reason 2 without error', () => {
        const component = wrapper.find("[data-test='test_adj_rsn2']")
        expect(component.length).toBe(1);
    })
    it('should render the adjustment reason 3 without error', () => {
        const component = wrapper.find("[data-test='test_adj_rsn3']")
        expect(component.length).toBe(1);
    })
    it('should render the Adjudication Remark without error', () => {
        const component = wrapper.find("[data-test='test_adj_rmk']")
        expect(component.length).toBe(1);
    })
    it('should render the Adjudication Remark 2 without error', () => {
        const component = wrapper.find("[data-test='test_adj_rmk2']")
        expect(component.length).toBe(1);
    })
    it('should render the Adjudication Remark 3 without error', () => {
        const component = wrapper.find("[data-test='test_adj_rmk3']")
        expect(component.length).toBe(1);
    })
    it('should render the Adjudication EOB without error', () => {
        const component = wrapper.find("[data-test='test_adj_eob']")
        expect(component.length).toBe(1);
    })
    it('should render the location without error', () => {
        const component = wrapper.find("[data-test='test_loc']")
        expect(component.length).toBe(1);
    })
    it('should render the userid without error', () => {
        const component = wrapper.find("[data-test='test_userid']")
        expect(component.length).toBe(1);
    })
    it('should render the tracking number without error', () => {
        const component = wrapper.find("[data-test='test_trackingNum']")
        expect(component.length).toBe(1);
    })
    it('should render the unclear claim without error', () => {
        const component = wrapper.find("[data-test='test_unclearclaim']")
        expect(component.length).toBe(1);
    })
    it('should render the report type without error', () => {
        const component = wrapper.find("[data-test='test_reportType']")
        expect(component.length).toBe(1);
    })
    it('should render the auto recycle without error', () => {
        const component = wrapper.find("[data-test='test_autoRecycle']")
        expect(component.length).toBe(1);
    })

})

describe('check prop types for Adjudication Details Override form', () => {

    it('should check prop types without error', () => {

        const expectedProps = {
            values: {
                "adjustmentReasonCode1": "",
        "adjustmentReasonCode2": "",
        "adjustmentReasonCode3": "",
        "remarkCode1": "",
        "remarkCode2": "",
        "remarkCode3": "",
        "eobCode": "",
        "locationCode":"",
            }
        }
        const propErr = checkPropTypes(AdjudicationDetailsOverride.propTypes, expectedProps, 'props', AdjudicationDetailsOverride.name)
        expect(propErr).toBeUndefined()
    })

})


