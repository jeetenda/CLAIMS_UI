import React from "react";
import { shallow } from 'enzyme';
import configureStore from 'redux-mock-store';
import { Provider } from 'react-redux';
import { BrowserRouter as Router } from 'react-router-dom';
import thunk from 'redux-thunk';
import checkPropTypes from "check-prop-types";
import ClaimExceptionMajor from "../components/ClaimExceptionMajor";
import { claimExceptionCreate, claimExceptionUpdate } from '../action';
import * as actionTypes from '../actionTypes';
import moxios from 'moxios';


const middlewares = [thunk];
const mockStore = configureStore(middlewares);
const initialState = {};
const store = mockStore(initialState);

//api sucees and error method
const mockSuccess = data => ({ status: 200, response: data })
const mockError = data => ({ status: 500, response: data })


describe('Rendering Claim Exception add/edit Component', () => {

    let store, wrapper

    // intitial state for component
    const initialState = {}

    // intitial props for component
    const componentProps = {
        handleChanges: jest.fn(),
        values: {
            exceptionCode: "",
            beginDate: null,
            endDate: '12/31/9999',
            shortDescription: "",
            longDescription: "",
            lobCode: "MED",
            lobDesc: "MED-MEDICAID"
        },
        errors:
        {
        }

    }

    //beforeEach Run before testcases is run  

    beforeEach(() => {
        store = mockStore(initialState)
        wrapper = shallow(<Provider store={store}><Router><ClaimExceptionMajor  {...componentProps} /></Router></Provider>).dive().dive().dive().dive().dive().dive()
    })



    it('should render the exception code without error', () => {
        const component = wrapper.find("[data-test='test_exc_code']")
        expect(component.length).toBe(1);
    })
    it('should render the begin date without error', () => {
        const component = wrapper.find("[data-test='test_begin_dt']")
        expect(component.length).toBe(1);
    })
    it('should render the end date without error', () => {
        const component = wrapper.find("[data-test='test_end_dt']")
        expect(component.length).toBe(1);
    })
    it('should render the long description without error', () => {
        const component = wrapper.find("[data-test='test_long_desc']")
        expect(component.length).toBe(1);
    })
    it('should render the short description without error', () => {
        const component = wrapper.find("[data-test='test_short_desc']")
        expect(component.length).toBe(1);
    })

})

describe('check prop types for Major form', () => {

    it('should check prop types without error', () => {

        const expectedProps = {
            values: {
                exceptionCode: "",
                beginDate: null,
                endDate: '12/31/9999',
                shortDescription: "",
                longDescription: "",
                lobCode: "MED",
                lobDesc: "MED-MEDICAID"
            }
        }
        const propErr = checkPropTypes(ClaimExceptionMajor.propTypes, expectedProps, 'props', ClaimExceptionMajor.name)
        expect(propErr).toBeUndefined()
    })

})

describe('Claim Exception Api Test Case', function () {
    const store = mockStore({});
    beforeEach(function () {
        // import and pass your custom axios instance to this method
        moxios.install()
    })

    afterEach(function () {
        // import and pass your custom axios instance to this method
        moxios.uninstall()
    })

    // function 

    const reqBody = {
        "auditUserID": "wf_NH_MC_CLM_EXC_CDV30",
        "auditTimeStamp": "2013-01-30T23:30:44.000+0000",
        "addedAuditUserID": "wf_NH_MC_CLM_EXC_CDV30",
        "addedAuditTimeStamp": "2013-01-30T23:30:44.000+0000",
        "versionNo": 0,
        "beginDate": "01/01/1964",
        "exceptionCode": "AA18",
        "endDate": "12/31/2020",
        "longDescription": "long desc",
        "shortDescription": "short desc",
        "lobCode": "MED",
        "claimExceptionDefaultVO": [{
            "auditUserID": "wf_NH_MC_CLM_EXC_CDV30",
            "auditTimeStamp": "2013-01-30T23:30:44.000+0000",
            "addedAuditUserID": "wf_NH_MC_CLM_EXC_CDV30",
            "addedAuditTimeStamp": "2013-01-30T23:30:44.000+0000",
            "versionNo": 1,
            "adjustmentReasonCode1": "44",
            "adjustmentReasonCode2": "45",
            "adjustmentReasonCode3": "46",
            "remarkCode1": "M18",
            "remarkCode2": "M19",
            "remarkCode3": "M20",
            "eobCode": 1020,
            "locationCode": "010",
            "userID": "wf_NH_MC_CLM_EXC_CDV30",
            "trackingNum": "10",
            "uncleanClaim": true,
            "reportType": "S",
            "autoRecycle": "1"
        }],
        "claimExceptionExternalRespVO": [
            {
                "auditUserID": "wf_NH_MC_CLM_EXC_CDV30",
                "auditTimeStamp": "2013-01-30T23:30:44.000+0000",
                "addedAuditUserID": "wf_NH_MC_CLM_EXC_CDV30",
                "addedAuditTimeStamp": "2013-01-30T23:30:44.000+0000",
                "versionNo": 0,
                "responseText": "Test ext resp",
                "mediaType": "5"
            }],
        "claimExceptionLocationVO": [{
            "auditUserID": "wf_NH_MC_CLM_EXC_CDV3",
            "auditTimeStamp": "2012-12-13T23:00:26.000+0000",
            "addedAuditUserID": "wf_NH_MC_CLM_EXC_CDV3",
            "addedAuditTimeStamp": "2012-12-13T23:00:26.000+0000",
            "versionNo": 0,
            "documentType": "A",
            "mediaType": "8",
            "claimType": "W",
            "userID": "DWILLIAMS150891",
            "locationCode": "240"
        }],
        "claimExceptionRemarkVO": [
            {
                "auditUserID": "SMOKETEST57",
                "auditTimeStamp": "2016-02-28T18:13:22.684+0000",
                "addedAuditUserID": "SMOKETEST57",
                "addedAuditTimeStamp": "2016-02-28T18:13:22.684+0000",
                "versionNo": 0,
                "documentType": "A",
                "claimType": "C",
                "mediaType": "1",
                "adjustReason": "44",
                "adjudRemark": "M18",
                "suspenseRemark": "M19",
                "adjudEOB": "A109",
                "suspenseEOB": "A110"
            }
        ],
        "claimExceptionResolutionVO": [
            {
                "auditUserID": "DTOWLESU05",
                "auditTimeStamp": "2020-07-26T19:13:39.833+0000",
                "addedAuditUserID": "wf_NH_MC_CLM_EXC_CDV47",
                "addedAuditTimeStamp": "2013-01-30T23:34:40.000+0000",
                "versionNo": 0,
                "mediaType": "8",
                "resolutionText": "Test resolution"
            }],
        "dispositionKeyVO": [
            {
                "auditUserID": "DTOWLESU05",
                "auditTimeStamp": "2020-07-26T19:13:39.833+0000",
                "addedAuditUserID": "wf_NH_MC_CLM_EXC_CDV47",
                "addedAuditTimeStamp": "2013-01-30T23:34:40.000+0000",
                "versionNo": 0,
                "documentTypeCode": "A",
                "mediaTypeCode": "8",
                "dispositionDetails": [
                    {
                        "auditUserID": "wf_NH_MC_CLM_EXC_CDV30",
                        "auditTimeStamp": "2013-01-30T23:30:44.000+0000",
                        "addedAuditUserID": "wf_NH_MC_CLM_EXC_CDV30",
                        "addedAuditTimeStamp": "2013-01-30T23:30:44.000+0000",
                        "versionNo": 0,
                        "claimType": "D",
                        "disposition": "1",
                        "forcePay": "1",
                        "forceDeny": "1"
                    }
                ]
            }]
    }

    it('should be success the add api call', () => {
        const reqResponse = {
            status: "success"
        }
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockSuccess(reqResponse))
        })
        const dispatchAddSuccess = {
            type: actionTypes.CLAIM_EXCEPTION_CREATE,
            claimExceptionCreateData: reqResponse
        };
        return store.dispatch(claimExceptionCreate(reqBody))
            .then(() => {
                const actions = store.getActions();
                expect(actions[0]).toEqual(dispatchAddSuccess);
            })
    })

    it('should be fail the add api call', () => {
        const errResponse = {
            status: "fail"
        }
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockError(errResponse))
        })
        const dispatchAddError = {
            type: actionTypes.CLAIM_EXCEPTION_CREATE,
            claimExceptionCreateData: errResponse
        };
        return store.dispatch(claimExceptionCreate(reqBody))
            .then(() => {
                const actions = store.getActions()
                expect(actions[1]).toEqual(dispatchAddError);
            })

    })

    it('should be success the update api call', () => {
        const reqResponse = {
            status: "success"
        }
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockSuccess(reqResponse))
        })
        const dispatchAddSuccess = {
            type: actionTypes.CLAIM_EXCEPTION_UPDATE,
            claimExceptionUpdateData: reqResponse
        };
        return store.dispatch(claimExceptionUpdate(reqBody))
            .then(() => {
                const actions = store.getActions();
                expect(actions[2]).toEqual(dispatchAddSuccess);
            })
    })

    it('should be fail the update api call', () => {
        const errResponse = {
            status: "fail"
        }
        moxios.wait(() => {
            let request = moxios.requests.mostRecent()
            request.respondWith(mockError(errResponse))
        })
        const dispatchAddError = {
            type: actionTypes.CLAIM_EXCEPTION_UPDATE,
            claimExceptionUpdateData: errResponse
        };
        return store.dispatch(claimExceptionUpdate(reqBody))
            .then(() => {
                const actions = store.getActions()
                expect(actions[3]).toEqual(dispatchAddError);
            })

    })

})


